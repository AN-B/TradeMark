/**
* @apiDefine POST_TransferManagerExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var transferManager = {
*        OldManagerMemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*        NewManagerMemberId: '1139cf30-7103-11e5-a9bd-29f2977b44c4',
*        MemberIds: [],
*        TransferItems: {
*            TransferCredit: 'Yes',
*            TransferPerform: 'Yes',
*            TransferProfile: 'Yes',
*            TransferTracks: 'Yes',
*            TransferPoints: 'Yes'
*         }
*       };
*      
*      var dataString = JSON.stringify(transferManager);
*      var postheaders = {
*            'Accept' : 'application/json',  
*            'Content-Type' : 'application/json',
*            'clientkey' : '[Your API Key]',
*            'Content-Length' : dataString.length
*       };
*      
*      var options = {
*        host: 'api.highground.com',
*        port: 443,
*        path: '/1.0/Manager/TransferManager',
*        method: 'POST',
*        headers: postheaders,
*        body: dataString
*      };
*      
*      var reqGet = https.request(options, function(response) {
*      var buffer = "", data;
*      response.on('data', function (chunk) {
*          buffer += chunk;
*      });
*      response.on('end', function (err) {
*          data = JSON.parse(buffer);
*          console.log('statusCode: ', response.statusCode);
*          console.log('data:', data);
*      });
*      });
*      
*      reqGet.on('error', function(e) {
*        console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      require "json/ext"
*      
*      def transfer_manager
*        uri = URI.parse("https://api.highground.com/1.0/Manager/TransferManager/")
*        request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})
*        request['clientkey'] = "Your API key"
*        request.body = {
*            OldManagerMemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*            NewManagerMemberId: '1139cf30-7103-11e5-a9bd-29f2977b44c4',
*            MemberIds: [],
*            TransferItems: {
*               TransferCredit: 'Yes',
*               TransferPerform: 'Yes',
*               TransferProfile: 'Yes',
*               TransferTracks: 'Yes',
*               TransferPoints: 'Yes'
*         }
*        }.to_json
*        res = Net::HTTP.start(uri.host, uri.port,
*          :use_ssl => uri.scheme == 'https') {|http|
*          http.request(request)
*        }
*        puts "response #{res}"
*        rescue => e
*            puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import json
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def transfer_manager():
*        headers = {
*            'Accept' : 'application/json',
*            'Content-type': 'application/json',
*            'clientkey' : API_ACCESS_KEY
*       }
*       payload = json.dumps({
*            "OldManagerMemberId": 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*            "NewManagerMemberId": '1139cf30-7103-11e5-a9bd-29f2977b44c4',
*            "MemberIds": [],
*            "TransferItems": {
*                "TransferCredit": 'Yes',
*                "TransferPerform": 'Yes',
*                "TransferProfile": 'Yes',
*                "TransferTracks": 'Yes',
*                "TransferPoints": 'Yes'
*            }
*       })
*       r = requests.post(
*            'https://api.highground.com/1.0/Manager/TransferManager/',
*            headers=headers,
*            data=payload,
*       )
*       print (r.status_code)
*       print (r.text)
*      
*     transfer_manager()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Manager/TransferManager/';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*        "Accept: application/json",
*        "Content-Type:application/json",
*        "clientkey:[Your API Key]"
*      );
*      
*      $curl_post_data = array(
*        'OldManagerMemberId' => 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*        'NewManagerMemberId' => 'UserName',
*        'MemberIds' => array(
*             'MemberId' =>  '1a7484e0-519c-11e5-8bbd-a385a1c75a10',
*        ),
*        'TransferItems' => array(
*             'TransferCredit' => 'Yes',
*             'TransferPerform' => 'Yes',
*             'TransferProfile' => 'Yes',
*             'TransferTracks' => 'Yes',
*             'TransferPoints' => 'Yes',
*          )
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      curl_setopt($curl, CURLOPT_POST, true);
*      curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*        $info = curl_getinfo($curl);
*        curl_close($curl);
*        die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*        die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*      using System;
*      using System.IO;
*      using System.Net;
*      using System.Text;
*      using System.ServiceModel;
*      using System.Runtime.Serialization;
*      using System.ServiceModel.Web;
*      using System.Web.Script.Serialization;
*      
*      namespace Rextester
*      {
*        public class Program
*        {
*            public const string uri = "https://api.highground.com/1.0/Manager/TransferManager";
*            public class TransferManager
*            {
*                public String OldManagerMemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*                public String NewManagerMemberId = "1139cf30-7103-11e5-a9bd-29f2977b44c4";
*                public List<String> MemberIds = new List<String>();
*                public TransferItems TransferItems;
*            }
*            public class TransferItems
*            {
*                public String TransferCredit = "Yes";
*                public String TransferPerform = "Yes";
*                public String TransferProfile = "Yes";
*                public String TransferTracks = "Yes";
*                public String TransferPoints = "Yes";
*            }
*            public static void Main(string[] args)
*            {
*                var transferManager = new TransferManager();
*                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
*                request.Method = "POST";
*                request.ContentType = "application/json;charset=utf-8";
*                var json = new JavaScriptSerializer().Serialize(transferManager);
*                System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
*                byte[] bytes = encoding.GetBytes(json);
*                request.ContentLength = bytes.Length;
*                using (Stream requestStream = request.GetRequestStream())
*                {
*                    requestStream.Write(bytes, 0, bytes.Length);
*                }
*                request.BeginGetResponse((x) =>
*                {
*                    using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))
*                    {
*                        if (callback != null)
*                        {
*                            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));
*                            callback(ser.ReadObject(response.GetResponseStream()) as Response);
*                        }
*                    }
*                }, null);
*            }
*        }
*      }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.io.OutputStream;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      import java.util.HashMap;
*      import java.util.Map;
*      import com.google.gson.Gson;
*      
*      
*      class Rextester
*      {
*        public static void main(String args[])
*        {
*            try 
*            {
*                URL url = new URL("https://api.highground.com/1.0/Manager/TransferManager/");
*                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                conn.setRequestMethod("POST");
*                conn.setRequestProperty("Content-Type", "application/json");
*                conn.setRequestProperty("clientkey", "[Your API Key]");
*                
*                HashMap<String, Object> transferManager = new HashMap<String, Object>();
*                transferManager.put("OldManagerMemberId", "d9d14d00-41ca-11e5-95f3-29dbd151f43c");
*                transferManager.put("NewManagerMemberId", "1139cf30-7103-11e5-a9bd-29f2977b44c4");
*      
*                HashMap<String, Object> transferItems = new HashMap<String, Object>();
*                transferItems.put("TransferCredit", "Yes");
*                transferItems.put("TransferPerform", "Yes");
*                transferItems.put("TransferProfile", "Yes");
*                transferItems.put("TransferTracks", "Yes");
*                transferItems.put("TransferPoints", "Yes");
*                transferManager.put("TransferItems", transferItems);
*      
*                Gson gson = new Gson();
*                String json = gson.toJson(transferManager);
*                
*                OutputStream os = conn.getOutputStream();
*                os.write(json.getBytes());
*                os.flush();
*                
*                if (conn.getResponseCode() != 200) {
*                    throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                }
*                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                String output;
*                while ((output = br.readLine()) != null) {
*                    System.out.println(output);
*                }
*                conn.disconnect();
*           } 
*            catch (MalformedURLException e) { e.printStackTrace(); }
*            catch (IOException e) { e.printStackTrace(); }
*        }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X POST "https://api.highground.com/1.0/Manager/TransferManager/" \
*      --data '{"OldManagerMemberId":"d9d14d00-41ca-11e5-95f3-29dbd151f43c", \
                "NewManagerMemberId":"1139cf30-7103-11e5-a9bd-29f2977b44c4","MemberIds": [], \
                "TransferItems":{"TransferCredit":"Yes","TransferPerform":"Yes","TransferProfile":"Yes","TransferTracks":"Yes","TransferPoints":"Yes"}}'
*/