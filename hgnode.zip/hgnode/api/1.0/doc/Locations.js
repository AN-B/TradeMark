/**
* @apiDefine GET_LocationExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var header = {
*          host: 'api.highground.com',
*          port: 443,
*          clientkey: '[Your API Key]',
*          path: '/1.0/Locations/',
*          method: 'GET'
*      };
*      
*      var reqGet = https.request(header, function(response) {
*          var buffer = "", data;
*          
*          response.on('data', function (chunk) {
*              buffer += chunk;
*          });
*      
*          response.on('end', function (err) {
*              data = JSON.parse(buffer);
*              console.log('statusCode: ', response.statusCode);
*              console.log('data:', data);
*          });
*      });
*      
*      reqGet.on('error', function(e) {
*        console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      
*      def get_locations
*          uri = URI.parse("https://api.highground.com/1.0/Locations/")
*          request = Net::HTTP::Get.new(uri)
*          request['clientkey'] = "Your API key"
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def get_locations_info():
*          headers = {
*              'Accept' : 'application/json',
*              'clientkey' : API_ACCESS_KEY
*          }
*          r = requests.get(
*                          'https://api.highground.com/1.0/Locations/',
*                          headers=headers
*          )
*          print (r.status_code)
*          print (r.text)
*          
*      get_locations_info()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Locations';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*          "Accept: application/json",
*          "clientkey:[Your API Key]"
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*          $info = curl_getinfo($curl);
*          curl_close($curl);
*          die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*          die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*    using System;
*    using System.IO;
*    using System.Net;
*    using System.Text;
*
*    namespace Rextester
*    {
*        public class Program
*        {
*            public const string EndPoint = "https://api.highground.com/1.0/Locations/";
*            
*            public static void Main(string[] args)
*            {
*                var request = (HttpWebRequest)WebRequest.Create(EndPoint);
*                request.Method = "GET";
*                request.ContentLength = 0;
*                request.ContentType = "application/json";
*                request.Headers.Add("clientkey", "[Your API Key]");
*                using (var response = (HttpWebResponse)request.GetResponse())
*                {
*                  var responseValue = string.Empty;
*                  if (response.StatusCode != HttpStatusCode.OK)
*                  {
*                    var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
*                    throw new ApplicationException(message);
*                  }
*                  using (var responseStream = response.GetResponseStream())
*                  {
*                    if (responseStream != null)
*                      using (var reader = new StreamReader(responseStream))
*                      {
*                        responseValue = reader.ReadToEnd();
*                      }
*                  }
*                  Console.Write(responseValue);
*                }
*            }
*        }
*    }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      
*      class Rextester
*      {  
*          public static void main(String args[])
*          {
*              try 
*              {
*                  URL url = new URL("https://api.highground.com/1.0/Locations/");
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("GET");
*                  conn.setRequestProperty("Accept", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X GET "https://api.highground.com/1.0/Locations/" 
*/

/**
* @apiDefine POST_LocationExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var updateLocations = [
*           {
*              Name: 'New Location Name',
*              LocationCode: 'NewLocationCode',
*              Description: 'New Location Description',
*              Language: 'en',
*              TimeZone' : 'Central Time',
*              Address: {
*                  Address1: '363 W Erie St.',
*                  Address2: 'Suite 500',
*                  City: 'Chicago',
*                  State: 'IL',
*                  Zip: '60654',
*                  Country: 'United States'
*              },
*              Phone: '1234567890'
*           },
*           {
*              LocationId: '3f187010-fc9d-11e6-91d3-bf98e3690106',
*              Name: 'Updated Location Name',
*              LocationCode: 'LocationCode',
*              Description: 'Updated Location Description',
*              Language: 'en',
*              TimeZone: 'central time',
*              Address: {
*                  Address1: '123 Main Street.',
*                  Address2: 'Suite 500',
*                  City: 'Chicago',
*                  State: 'IL',
*                  Zip: '60654',
*                  Country: 'United States'
*              }
*           }];
*      var dataString = JSON.stringify(updateLocations);
*      var postheaders = {
*              'Accept' : 'application/json',  
*              'Content-Type' : 'application/json',
*              'clientkey' : '[Your API Key]',
*              'Content-Length' : dataString.length
*          };
*      
*      var options = {
*          host: 'api.highground.com',
*          port: 443,
*          path: '/1.0/Locations/',
*          method: 'POST',
*          headers: postheaders,
*          body: dataString
*      };
*      
*      var reqGet = https.request(options, function(response) {
*        var buffer = "", data;
*        response.on('data', function (chunk) {
*          buffer += chunk;
*        });
*        response.on('end', function (err) {
*          data = JSON.parse(buffer);
*          console.log('statusCode: ', response.statusCode);
*          console.log('data:', data);
*        });
*      });
*      
*      reqGet.on('error', function(e) {
*          console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      require "json/ext"
*      
*      def update_locations
*          uri = URI.parse("https://api.highground.com/1.0/Locations/")
*          request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})
*          request['clientkey'] = "Your API key"
*          request.body = [
*           {
*              Name: 'New Location Name',
*              LocationCode: 'NewLocationCode',
*              Description: 'New Location Description',
*              Language: 'en',
*              TimeZone' : 'Central Time',
*              Address: {
*                  Address1: '363 W Erie St.',
*                  Address2: 'Suite 500',
*                  City: 'Chicago',
*                  State: 'IL',
*                  Zip: '60654',
*                  Country: 'United States'
*              },
*              Phone: '1234567890'
*           },
*           {
*              LocationId: '3f187010-fc9d-11e6-91d3-bf98e3690106',
*              Name: 'Updated Location Name',
*              LocationCode: 'LocationCode',
*              Description: 'Updated Location Description',
*              Language: 'en',
*              TimeZone: 'central time',
*              Address: {
*                  Address1: '123 Main Street.',
*                  Address2: 'Suite 500',
*                  City: 'Chicago',
*                  State: 'IL',
*                  Zip: '60654',
*                  Country: 'United States'
*              }
*           }].to_json
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res.body}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import json
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def update_locations():
*        headers = {
*            'Accept' : 'application/json',
*            'Content-type': 'application/json',
*            'clientkey' : API_ACCESS_KEY
*        }
*        payload = json.dumps([
*           {
*              "Name": "New Location Name",
*              "LocationCode": "NewLocationCode",
*              "Description": "New Location Description",
*              "Language": "en",
*              "TimeZone" : "Central Time",
*              "Address": {
*                  "Address1": "363 W Erie St.",
*                  "Address2": "Suite 500",
*                  "City": "Chicago",
*                  "State": "IL",
*                  "Zip": "60654",
*                  "Country": "United States"
*              },
*              "Phone": "1234567890"
*           },
*           {
*              "LocationId": "3f187010-fc9d-11e6-91d3-bf98e3690106",
*              "Name": "Updated Location Name",
*              "LocationCode": "LocationCode",
*              "Description": "Updated Location Description",
*              "Language": "en",
*              "TimeZone": "central time",
*              "Address": {
*                  "Address1": "123 Main Street.",
*                  "Address2": "Suite 500",
*                  "City": "Chicago",
*                  "State": "IL",
*                  "Zip": "60654",
*                  "Country": "United States"
*           }])
*
*        r = requests.post(
*                        'https://api.highground.com/1.0/Locations/',
*                        headers=headers,
*                        data=payload,
*        )
*        print (r.status_code)
*        print (r.text)
*        
*      update_locations()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Locations/';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*         "Accept: application/json",
*         "Content-Type:application/json",
*         "clientkey:[Your API Key]"
*      );
*      
*      $newLocation = array(
*         'Name' => 'New Location Name',
*         'LocationCode' => 'NewLocationCode',
*         'Description' => 'New Location Description',
*         'Language' => 'en',
*         'TimeZone' => 'Central Time',
*         'Address' =>  array(
*             'Address1' =>  '363 W Erie St.',
*             'Address2' =>  'Suite 500',
*             'City' =>  'Chicago',
*             'State' =>  'IL',
*             'Zip' =>  '60654',
*             'Country' =>  'United States'
*          ),
*         'Phone' => '1234567890'
*      );
*
*      $updateLocation = array(
*         'LocationId' => '3f187010-fc9d-11e6-91d3-bf98e3690106',
*         'Name' => 'Updated Location Name',
*         'LocationCode' => 'LocationCode',
*         'Description' => 'Updated Location Description',
*         'Language' => 'en',
*         'TimeZone' => 'central time',
*         'Address' =>  array(
*             'Address1' =>  '123 Main Street.',
*             'Address2' =>  'Suite 500',
*             'City' =>  'Chicago',
*             'State' =>  'IL',
*             'Zip' =>  '60654',
*             'Country' =>  'United States'
*          ),
*         'Phone' => '1234567890'
*      );
*      $curl_post_data = array($newLocation, $updateLocation);
*
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      curl_setopt($curl, CURLOPT_POST, true);
*      curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*        $info = curl_getinfo($curl);
*        curl_close($curl);
*        die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*        die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*  using System;
*  using System.IO;
*  using System.Collections.Generic;
*  using System.Collections;
*  using System.Net;
*  using System.Text;
*  using System.serviceModel;
*  using System.Runtime.Serialization;
*  using System.ServiceModel.Web;
*  using System.Web.Script.Serialization;
*  
*  namespace Rextester
*  {
*      public class Program
*      {
*          public const string uri = "https://api.highground.com/1.0/Locations/";
*          public class Location
*          {
*              public String LocationId;
*              public String Name;
*              public String LocationCode;
*              public String Description;
*              public String Language;
*              public String TimeZone;
*              public String Phone;
*              public Address Address;
*          }
*          public class Address
*          {
*              public String Address1;
*              public String Address2;
*              public String City;
*              public String State;
*              public String Zip;
*              public String Country;
*          }
*  
*          public static void Main(string[] args)
*          {
*              var locations = new List<Location>();
*              var newLocation = new Location();
*              newLocation.Name = "New Location Name";
*              newLocation.LocationCode = "NewLocationCode";
*              newLocation.Description = "New Location Description";
*              newLocation.Language = "en";
*              newLocation.TimeZone = "Central Time";
*              newLocation.Phone = "1234567890";
*              newLocation.Address = new Address {
*                  Address1 = "363 W Erie St.",
*                  Address2 = "Suite 500",
*                  City = "Chicago",
*                  State = "IL",
*                  Zip = "60654",
*                  Country = "United States"
*              };
*              locations.Add(newLocation);
*              
*              var updatedLocation = new Location();
*              updatedLocation.LocationId = "3f187010-fc9d-11e6-91d3-bf98e3690127";
*              updatedLocation.Name = "Updated Location Name";
*              updatedLocation.LocationCode = "LocationCode";
*              updatedLocation.Description = "Updated Location Description";
*              updatedLocation.Language = "en";
*              updatedLocation.TimeZone = "central time";
*              updatedLocation.Address = new Address {
*                  Address1 = "123 Main Street.",
*                  Address2 = "Suite 500",
*                  City = "Chicago",
*                  State = "IL",
*                  Zip = "60654",
*                  Country = "United States"
*              };
*              locations.Add(updatedLocation);
*              
*              HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
*              request.Method = "POST";
*              request.ContentType = "application/json;charset=utf-8";
*              var json = new JavaScriptSerializer().Serialize(locations);
*              System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
*              byte[] bytes = encoding.GetBytes(json);
*              request.ContentLength = bytes.Length;
*              using (Stream requestStream = request.GetRequestStream())
*              {
*                  requestStream.Write(bytes, 0, bytes.Length);
*              }
*              request.BeginGetResponse((x) =>
*              {
*                  using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))
*                  {
*                      if (callback != null)
*                      {
*                          DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));
*                          callback(ser.ReadObject(response.GetResponseStream()) as Response);
*                      }
*                  }
*              }, null);
*          }
*      }
*  }
*  
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.io.OutputStream;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      import java.util.HashMap;
*      import java.util.Map;
*      import com.google.gson.Gson;
*      
*      class Rextester
*      {
*          public static void main(String args[])
*          {
*              try 
*              {
*                  URL url = new URL("https://api.highground.com/1.0/Locations/");
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("POST");
*                  conn.setRequestProperty("Content-Type", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  HashMap<String, Object> locations = new HashMap<String, Object>();
*                  HashMap<String, Object> newLocation = new HashMap<String, Object>();
*                  newLocation.put("Name", "New Location Name");
*                  newLocation.put("LocationCode", "NewLocationCode");
*                  newLocation.put("Description", "New Location Description);
*                  newLocation.put("Language", "en");
*                  newLocation.put("TimeZone", "Central Time'");
*                  newLocation.put("Phone", "1234567890");
*                  HashMap<String, Object> newlocationAddress = new HashMap<String, Object>();
*                  newlocationAddress.put("Address1", "363 W Erie St.");
*                  newlocationAddress.put("Address2", "Suite 500");
*                  newlocationAddress.put("City", "Chicago");
*                  newlocationAddress.put("State", "IL");
*                  newlocationAddress.put("Zip", "60654);
*                  newlocationAddress.put("Country", "United States");
*                  newLocation.put("Address", newlocationAddress);
*                  locations.put("location", newLocation);
*
*                  HashMap<String, Object> updateLocation = new HashMap<String, Object>();
*                  updateLocation.put("LocationId", "3f187010-fc9d-11e6-91d3-bf98e3690106");
*                  updateLocation.put("Name", "New Location Name");
*                  updateLocation.put("LocationCode", "NewLocationCode");
*                  updateLocation.put("Description", "New Location Description);
*                  updateLocation.put("Language", "en");
*                  updateLocation.put("TimeZone", "Central Time'");
*                  HashMap<String, Object> updatelocationAddress = new HashMap<String, Object>();
*                  updatelocationAddress.put("Address1", "123 Main Street.");
*                  updatelocationAddress.put("Address2", "Suite 500");
*                  updatelocationAddress.put("City", "Chicago");
*                  updatelocationAddress.put("State", "IL");
*                  updatelocationAddress.put("Zip", "60654);
*                  updatelocationAddress.put("Country", "United States");
*                  updateLocation.put("Address", updatelocationAddress);
*                  locations.put("location", updateLocation);
*                  
*                  Gson gson = new Gson();
*                  String json = gson.toJson(locations);
*                  OutputStream os = conn.getOutputStream();
*                  os.write(json.getBytes());
*                  os.flush();
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X POST "https://api.highground.com/1.0/Locations/" \
*      --data '[{"Name": "New Location Name","LocationCode": "NewLocationCode","Description": "New Location Description","Language": "en","TimeZone" : "Central Time","Address": {"Address1": "363 W Erie St.","Address2": "Suite 500","City": "Chicago","State": "IL","Zip": "60654","Country": "United States"},"Phone": "1234567890"},{"LocationId": "3f187010-fc9d-11e6-91d3-bf98e3690106","Name": "Updated Location Name","LocationCode": "LocationCode","Description": "Updated Location Description","Language": "en","TimeZone": "central time","Address": {"Address1": "123 Main Street.","Address2": "Suite 500","City": "Chicago","State": "IL","Zip": "60654","Country": "United States"}]'
*/