/**
* @apiDefine GET_DepartmentExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var header = {
*          host: 'api.highground.com',
*          port: 443,
*          clientkey: '[Your API Key]',
*          path: '/1.0/Departments/',
*          method: 'GET'
*      };
*      
*      var reqGet = https.request(header, function(response) {
*          var buffer = "", data;
*          
*          response.on('data', function (chunk) {
*              buffer += chunk;
*          });
*      
*          response.on('end', function (err) {
*              data = JSON.parse(buffer);
*              console.log('statusCode: ', response.statusCode);
*              console.log('data:', data);
*          });
*      });
*      
*      reqGet.on('error', function(e) {
*        console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      
*      def get_departments
*          uri = URI.parse("https://api.highground.com/1.0/Departments/")
*          request = Net::HTTP::Get.new(uri)
*          request['clientkey'] = "Your API key"
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def get_department_info():
*          headers = {
*              'Accept' : 'application/json',
*              'clientkey' : API_ACCESS_KEY
*          }
*          r = requests.get(
*                          'https://api.highground.com/1.0/Departments/',
*                          headers=headers
*          )
*          print (r.status_code)
*          print (r.text)
*          
*      get_department_info()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Departments/';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*          "Accept: application/json",
*          "clientkey:[Your API Key]"
*      );
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*          $info = curl_getinfo($curl);
*          curl_close($curl);
*          die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*          die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*    using System;
*    using System.IO;
*    using System.Net;
*    using System.Text;
*
*    namespace Rextester
*    {
*        public class Program
*        {
*            public const string EndPoint = "https://api.highground.com/1.0/Departments/";
*            
*            public static void Main(string[] args)
*            {
*                var request = (HttpWebRequest)WebRequest.Create(EndPoint);
*                request.Method = "GET";
*                request.ContentLength = 0;
*                request.ContentType = "application/json";
*                request.Headers.Add("clientkey", "[Your API Key]");
*                using (var response = (HttpWebResponse)request.GetResponse())
*                {
*                  var responseValue = string.Empty;
*                  if (response.StatusCode != HttpStatusCode.OK)
*                  {
*                    var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
*                    throw new ApplicationException(message);
*                  }
*                  using (var responseStream = response.GetResponseStream())
*                  {
*                    if (responseStream != null)
*                      using (var reader = new StreamReader(responseStream))
*                      {
*                        responseValue = reader.ReadToEnd();
*                      }
*                  }
*                  Console.Write(responseValue);
*                }
*            }
*        }
*    }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      
*      class Rextester
*      {  
*          public static void main(String args[])
*          {
*              try 
*              {
*                  URL url = new URL("https://api.highground.com/1.0/Departments/");
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("GET");
*                  conn.setRequestProperty("Accept", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X GET "https://api.highground.com/1.0/Departments/" 
*/