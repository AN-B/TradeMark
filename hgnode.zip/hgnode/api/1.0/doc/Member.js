/**
* @apiDefine GET_MemberExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var header = {
*          host: 'api.highground.com',
*          port: 443,
*          clientkey: '[Your API Key]',
*          path: '/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          method: 'GET'
*      };
*      
*      var reqGet = https.request(header, function(response) {
*          var buffer = "", data;
*          
*          response.on('data', function (chunk) {
*              buffer += chunk;
*          });
*      
*          response.on('end', function (err) {
*              data = JSON.parse(buffer);
*              console.log('statusCode: ', response.statusCode);
*              console.log('data:', data);
*          });
*      });
*      
*      reqGet.on('error', function(e) {
*        console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      
*      def get_departments
*          uri = URI.parse("https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c")
*          request = Net::HTTP::Get.new(uri)
*          request['clientkey'] = "Your API key"
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def get_member_info():
*          headers = {
*              'Accept' : 'application/json',
*              'clientkey' : API_ACCESS_KEY
*          }
*          payload = {
*              'MemberId': 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          }
*          r = requests.get(
*                          'https://api.highground.com/1.0/Member/',
*                          headers=headers,
*                          params=payload,
*          )
*          print (r.status_code)
*          print (r.text)
*          
*      get_member_info()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*          "Accept: application/json",
*          "clientkey:[Your API Key]"
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*          $info = curl_getinfo($curl);
*          curl_close($curl);
*          die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*          die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*    using System;
*    using System.IO;
*    using System.Net;
*    using System.Text;
*
*    namespace Rextester
*    {
*        public class Program
*        {
*            public const string EndPoint = "https://api.highground.com/1.0/Member/";
*            
*            public static void Main(string[] args)
*            {
*                public String MemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*                var request = (HttpWebRequest)WebRequest.Create(EndPoint + MemberId);
*                request.Method = "GET";
*                request.ContentLength = 0;
*                request.ContentType = "application/json";
*                request.Headers.Add("clientkey", "[Your API Key]");
*                using (var response = (HttpWebResponse)request.GetResponse())
*                {
*                  var responseValue = string.Empty;
*                  if (response.StatusCode != HttpStatusCode.OK)
*                  {
*                    var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
*                    throw new ApplicationException(message);
*                  }
*                  using (var responseStream = response.GetResponseStream())
*                  {
*                    if (responseStream != null)
*                      using (var reader = new StreamReader(responseStream))
*                      {
*                        responseValue = reader.ReadToEnd();
*                      }
*                  }
*                  Console.Write(responseValue);
*                }
*            }
*        }
*    }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      
*      class Rextester
*      {  
*          public static void main(String args[])
*          {
*              try 
*              {
*                  String MemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*                  URL url = new URL("https://api.highground.com/1.0/Member/" + MemberId);
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("GET");
*                  conn.setRequestProperty("Accept", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X GET "https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c" 
*/

/**
* @apiDefine PUT_MemberExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var updateMember = {
*          MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          Birthdate: 'MM/DD/YYYY',
*          UserName: 'UserName',
*          Email: 'email@highground.com',
*          HomeZip: '12345',
*          WorkZip: '98765',
*          FirstName: 'FirstName',
*          LastName: 'LastName',
*          FullName: 'FirstName LastName',      
*          Position: 'CEO',
*          StartingDate: 'MM/DD/YYYY',
*          MyManagers: [{
*               EmployeeId: 'Manager EmployeeId', //EmployeeId or MemberId is required
*               MemberId: '158f0270-519c-11e5-927c-7d3b5e612a77',
*               FullName: 'Manager FullName' // Optional
*          }],
*          Location: {
*              LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',
*              Name: 'Chicago'
*          },
*          GroupDepartment: {
*              DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',
*              Name: 'IT'
*          },
*          Role: 'Employee',
*          GravatarEmail: 'gravataremail@highground.com',
*          EmployeeId: 'HG001'
*      };
*      var dataString = JSON.stringify(updateMember);
*      var postheaders = {
*              'Accept' : 'application/json',  
*              'Content-Type' : 'application/json',
*              'clientkey' : '[Your API Key]',
*              'Content-Length' : dataString.length
*          };
*      
*      var options = {
*          host: 'api.highground.com',
*          port: 443,
*          path: '/1.0/Member/',
*          method: 'PUT',
*          headers: postheaders,
*          body: dataString
*      };
*      
*      var reqGet = https.request(options, function(response) {
*        var buffer = "", data;
*        response.on('data', function (chunk) {
*          buffer += chunk;
*        });
*        response.on('end', function (err) {
*          data = JSON.parse(buffer);
*          console.log('statusCode: ', response.statusCode);
*          console.log('data:', data);
*        });
*      });
*      
*      reqGet.on('error', function(e) {
*          console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      require "json/ext"
*      
*      def update_member
*          uri = URI.parse("https://api.highground.com/1.0/Member/")
*          request = Net::HTTP::Put.new(uri, initheader = {'Content-Type' =>'application/json'})
*          request['clientkey'] = "Your API key"
*          request.body = {
*              MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*              Birthdate: 'MM/DD/YYYY',
*              UserName: 'UserName',
*              Email: 'email@highground.com',
*              HomeZip: '12345',
*              WorkZip: '98765',
*              FirstName: 'FirstName',
*              LastName: 'LastName',
*              FullName: 'FirstName LastName',
*              Position: 'CEO',
*              StartingDate: 'MM/DD/YYYY',
*              MyManagers: [{
*                  EmployeeId: 'Manager EmployeeId', //EmployeeId or MemberId is required
*                  MemberId: '158f0270-519c-11e5-927c-7d3b5e612a77',
*                  FullName: 'Manager FullName' // Optional
*              }],
*              Location: {
*                  LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',
*                  Name: 'Chicago'
*              },
*              GroupDepartment: {
*                  DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',
*                  Name: 'IT'
*              },
*              Role: 'Employee',
*              GravatarEmail: 'gravataremail@highground.com',
*              EmployeeId: 'HG001'
*          }.to_json
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import json
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def update_member():
*        headers = {
*            'Accept' : 'application/json',
*            'Content-type': 'application/json',
*            'clientkey' : API_ACCESS_KEY
*        }
*        payload = json.dumps({
*              "MemberId": "d9d14d00-41ca-11e5-95f3-29dbd151f43c",
*              "Birthdate": "MM/DD/YYYY",
*              "UserName": "UserName",
*              "Email": "email@highground.com",
*              "HomeZip": "12345",
*              "WorkZip": "98765",
*              "FirstName": "FirstName",
*              "LastName": "LastName",
*              "FullName": "FirstName LastName",
*              "Position": "CEO",
*              "StartingDate": "MM/DD/YYYY",
*              "MyManagers": [{
*                   EmployeeId: 'Manager EmployeeId', //EmployeeId or MemberId is required
*                   MemberId: '158f0270-519c-11e5-927c-7d3b5e612a77',
*                   FullName: 'Manager FullName' // Optional
*              }],
*              "Location": {
*                  "LocationId": "158f0270-519c-11e5-927c-7d3b5e612a77",
*                  "Name": "Chicago"
*              },
*              "GroupDepartment": {
*                  "DepartmentId": "17ce6b20-519c-11e5-9f79-f10b3b47f7d2",
*                  "Name": "IT"
*              },
*              "Role": "Employee",
*              "GravatarEmail": "gravataremail@highground.com",
*              "EmployeeId": "HG001"
*          })
*        r = requests.put(
*                        'https://api.highground.com/1.0/Member/',
*                        headers=headers,
*                        data=payload,
*        )
*        print (r.status_code)
*        print (r.text)
*        
*      update_member()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Member/';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*         "Accept: application/json",
*         "Content-Type:application/json",
*         "clientkey:[Your API Key]"
*      );
*      
*      $curl_post_data = array(
*         'Birthdate' => 'MM/DD/YYYY',
*         'UserName' => 'UserName',
*         'Email' => 'email@highground.com',
*         'HomeZip' => '12345',
*         'WorkZip' => '98765',
*         'FirstName' => 'FirstName',
*         'LastName' => 'LastName',
*         'FullName' => 'FirstName LastName',
*         'Position' => 'CEO',
*         'StartingDate' => 'MM/DD/YYYY',
*         'Role' => 'Employee',
*         'GravatarEmail' => 'gravataremail@highground.com',
*         'EmployeeId' => 'HG001',
*         'MyManagers' =>  array(
*             'MemberId' =>  '1a7484e0-519c-11e5-8bbd-a385a1c75a10', //EmployeeId or MemberId is required
*             'EmployeeId' => 'Manager EmployeeId',
*             'FullName' =>  'Manager FullName' // optional
*          ),
*         'Location' =>  array(
*             'LocationId' =>  '158f0270-519c-11e5-927c-7d3b5e612a77',
*             'Name' =>  'Chicago'
*          ),
*         'GroupDepartment' =>  array(
*             'DepartmentId' =>  '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',
*             'Name' =>  'IT'
*         )
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
*      curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*        $info = curl_getinfo($curl);
*        curl_close($curl);
*        die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*        die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*  using System;
*  using System.IO;
*  using System.Net;
*  using System.Text;
*  using System.ServiceModel;
*  using System.Runtime.Serialization;
*  using System.ServiceModel.Web;
*  using System.Web.Script.Serialization;
*
*  namespace Rextester
*  {
*      public class Program
*      {
*          public const string uri = "https://api.highground.com/1.0/Member";
*          public class Member
*          {
*              public String MemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*              public DateTime Birthdate = "MM/DD/YYYY";
*              public String UserName = "UserName";
*              public String Email = "email@highground.com";
*              public String HomeZip = "12345";
*              public String WorkZip = "98765";
*              public String EmployeeId = "HG001";
*              public String FirstName = "FirstName";
*              public String LastName = "LastName";
*              public String FullName = "FullName";
*              public String Position = "CEO";
*              public DateTime StartingDate = "MM/DD/YYYY";
*              public String Role = "Employee";
*              public String GravatarEmail = "gravataremail@highground.com";
*              public Manager MyManagers;
*              public Location Location;
*              public Department GroupDepartment;
*          }
*          public class Manager
*          {
*               //EmployeeId or MemberId is required
*              public String MemberId = "1a7484e0-519c-11e5-8bbd-a385a1c75a10";
*              public String EmployeeId = "Manaver EmployeeId";
*              public String FullName = "Manager FullName"; //optional
*          }
*          public class Location
*          {
*              public String LocationId = "158f0270-519c-11e5-927c-7d3b5e612a77";
*              public String Name = "Chicago"; 
*          }
*          public class Department
*          {
*              public String DepartmentId = "17ce6b20-519c-11e5-9f79-f10b3b47f7d2";
*              public String Name = "IT"; 
*          }
*          public static void Main(string[] args)
*          {
*              var member = new Member();
*              member.MyManagers = new Manager();
*              member.Location = new Location();
*              member.GroupDepartment = new Department();
*              
*              HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
*              request.Method = "PUT";
*              request.ContentType = "application/json;charset=utf-8";
*              var json = new JavaScriptSerializer().Serialize(member);
*              System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
*              byte[] bytes = encoding.GetBytes(json);
*              request.ContentLength = bytes.Length;
*              using (Stream requestStream = request.GetRequestStream())
*              {
*                  requestStream.Write(bytes, 0, bytes.Length);
*              }
*              request.BeginGetResponse((x) =>
*              {
*                  using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))
*                  {
*                      if (callback != null)
*                      {
*                          DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));
*                          callback(ser.ReadObject(response.GetResponseStream()) as Response);
*                      }
*                  }
*              }, null);
*          }
*      }
*  }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.io.OutputStream;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      import java.util.HashMap;
*      import java.util.Map;
*      import com.google.gson.Gson;
*      
*      class Rextester
*      {
*          public static void main(String args[])
*          {
*              try 
*              {
*                  URL url = new URL("https://api.highground.com/1.0/Member/");
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("PUT");
*                  conn.setRequestProperty("Content-Type", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  HashMap<String, Object> memberData = new HashMap<String, Object>();
*                  memberData.put("MemberId", "d9d14d00-41ca-11e5-95f3-29dbd151f43c");
*                  memberData.put("Birthdate", "MM/DD/YYYY");
*                  memberData.put("UserName", "UserName");
*                  memberData.put("Email", "email@highground.com");
*                  memberData.put("HomeZip", "12345");
*                  memberData.put("WorkZip", "98765");
*                  memberData.put("EmployeeId", "HG001");
*                  memberData.put("FirstName", "FirstName");
*                  memberData.put("LastName", "LastName");
*                  memberData.put("FullName", "FullName");
*                  memberData.put("Position", "CEO");
*                  memberData.put("StartingDate", "MM/DD/YYYY");
*                  memberData.put("Role", "Employee");
*                  memberData.put("GravatarEmail", "gravataremail@highground.com");
*      
*                  HashMap<String, Object> managerData = new HashMap<String, Object>();
*                  //EmployeeId or MemberId is required
*                  managerData.put("MemberId", "1a7484e0-519c-11e5-8bbd-a385a1c75a10");
*                  managerData.put("EmployeeId", "Manager EmployeeId");
*                   //Optional
*                  managerData.put("FullName", "Manager FullName");
*                  memberData.put("MyManagers", managerData);
*                  
*                  HashMap<String, Object> locationData = new HashMap<String, Object>();
*                  locationData.put("LocationId", "158f0270-519c-11e5-927c-7d3b5e612a77");
*                  locationData.put("Name", "FirstName");
*                  memberData.put("Location", locationData);
*                  
*                  HashMap<String, Object> departmentData = new HashMap<String, Object>();
*                  departmentData.put("LocationId", "17ce6b20-519c-11e5-9f79-f10b3b47f7d2");
*                  departmentData.put("Name", "IT");
*                  memberData.put("GroupDepartment", departmentData);
*                  
*                  Gson gson = new Gson();
*                  String json = gson.toJson(memberData);
*                  OutputStream os = conn.getOutputStream();
*                  os.write(json.getBytes());
*                  os.flush();
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X PUT "https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c" \
*      --data '{"Birthdate":"MM/DD/YYYY","UserName":"UserName","Email":"email@highground.com","HomeZip":"12345","WorkZip":"98765","FirstName":"FirstName","LastName":"LastName","FullName":"FirstName LastName","Position":"CEO","StartingDate":"MM/DD/YYYY","MyManagers":{"MemberId":"1a7484e0-519c-11e5-8bbd-a385a1c75a10","Email":"manageremail@highground.com","FullName":"Manager FullName"},"Location":{"LocationId":"158f0270-519c-11e5-927c-7d3b5e612a77","Name":"Chicago"},"GroupDepartment":{"DepartmentId":"17ce6b20-519c-11e5-9f79-f10b3b47f7d2","Name":"IT"},"Role":"Employee","GravatarEmail":"gravataremail@highground.com","EmployeeId":"HG001"}'
*/

/**
* @apiDefine DELETE_MemberExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var offBoardMember = {
*          MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          UserName: 'UserName',
*          FirstName: 'FirstName',
*          LastName: 'LastName',
*          OffBoardType: 'Voluntary',
*          OffBoardDate: 'MM/DD/YYYY',
*          NotificationEmail: 'notificationemail@highground.com'
*      };
*      
*      var dataString = JSON.stringify(offBoardMember);
*      var postheaders = {
*              'Accept' : 'application/json',  
*              'Content-Type' : 'application/json',
*              'clientkey' : '[Your API Key]',
*              'Content-Length' : dataString.length
*          };
*      
*      var options = {
*          host: 'api.highground.com',
*          port: 443,
*          path: '/1.0/Member/',
*          method: 'DELETE',
*          headers: postheaders,
*          body: dataString
*      };
*      
*      var reqGet = https.request(options, function(response) {
*        var buffer = "", data;
*        response.on('data', function (chunk) {
*            buffer += chunk;
*        });
*        response.on('end', function (err) {
*            data = JSON.parse(buffer);
*            console.log('statusCode: ', response.statusCode);
*            console.log('data:', data);
*        });
*      });
*      
*      reqGet.on('error', function(e) {
*          console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      require "json/ext"
*      
*      def offboard_member
*          uri = URI.parse("https://api.highground.com/1.0/Member/")
*          request = Net::HTTP::Delete.new(uri, initheader = {'Content-Type' =>'application/json'})
*          request['clientkey'] = "Your API key"
*          request.body = {
*              MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*              UserName: 'UserName',
*              FirstName: 'FirstName',
*              LastName: 'LastName',
*              OffBoardType: 'Voluntary',
*              OffBoardDate: 'MM/DD/YYYY',
*              NotificationEmail: 'notificationemail@highground.com'
*          }.to_json
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import json
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def offboard_member():
*        headers = {
*            'Accept' : 'application/json',
*            'Content-type': 'application/json',
*            'clientkey' : API_ACCESS_KEY
*        }
*        payload = json.dumps({
*          "MemberId": "d9d14d00-41ca-11e5-95f3-29dbd151f43c",
*          "UserName": "UserName",
*          "FirstName": "FirstName",
*          "LastName": "LastName",
*          "OffBoardType": "Voluntary",
*          "OffBoardDate": "MM/DD/YYYY",
*          "NotificationEmail": "notificationemail@highground.com"
*        })
*        r = requests.delete(
*                        'https://api.highground.com/1.0/Member/',
*                        headers=headers,
*                        data=payload,
*        )
*        print (r.status_code)
*        print (r.text)
*        
*      offboard_member()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Member';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*        "Accept: application/json",
*        "Content-Type:application/json",
*        "clientkey:[Your API Key]"
*      );
*      
*      $curl_post_data = array(
*          'MemberId' => 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          'UserName' => 'UserName',
*          'FirstName' => 'FirstName',
*          'LastName' => 'LastName',
*          'OffBoardType' => 'Voluntary',
*          'OffBoardDate' => 'MM/DD/YYYY',
*          'NotificationEmail' => 'notificationemail@highground.com'
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
*      curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*        $info = curl_getinfo($curl);
*        curl_close($curl);
*        die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*        die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*  using System;
*  using System.IO;
*  using System.Net;
*  using System.Text;
*  using System.ServiceModel;
*  using System.Runtime.Serialization;
*  using System.ServiceModel.Web;
*  using System.Web.Script.Serialization;
*  
*  namespace Rextester
*  {
*      public class Program
*      {
*          public const string uri = "https://api.highground.com/1.0/Member";
*          public class MemberOffBoard
*          {
*              public String MemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*              public String UserName = "UserName";
*              public String FirstName = "FirstName";
*              public String LastName = "LastName";
*              public String OffBoardType = "Voluntary";
*              public DateTime OffBoardDate = "MM/DD/YYYY";
*              public String NotificationEmail = "notificationemail@highground.com";
*          }
*          public static void Main(string[] args)
*          {
*              var offBoardMember = new MemberOffBoard();
*              HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
*              request.Method = "DELETE";
*              request.ContentType = "application/json;charset=utf-8";
*              var json = new JavaScriptSerializer().Serialize(offBoardMember);
*              System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
*              byte[] bytes = encoding.GetBytes(json);
*              request.ContentLength = bytes.Length;
*              using (Stream requestStream = request.GetRequestStream())
*              {
*                  requestStream.Write(bytes, 0, bytes.Length);
*              }
*              request.BeginGetResponse((x) =>
*              {
*                  using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))
*                  {
*                      if (callback != null)
*                      {
*                          DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));
*                          callback(ser.ReadObject(response.GetResponseStream()) as Response);
*                      }
*                  }
*              }, null);
*          }
*      }
*  }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.io.OutputStream;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      import java.util.HashMap;
*      import java.util.Map;
*      import com.google.gson.Gson;
*      
*      
*      class Rextester
*      {
*          public static void main(String args[])
*          {
*              try 
*              {
*                  URL url = new URL("https://api.highground.com/1.0/Member/");
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("DELETE");
*                  conn.setRequestProperty("Content-Type", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  HashMap<String, Object> offBoardMember = new HashMap<String, Object>();
*                  offBoardMember.put("MemberId", "d9d14d00-41ca-11e5-95f3-29dbd151f43c");
*                  offBoardMember.put("UserName", "UserName");
*                  offBoardMember.put("FirstName", "FirstName");
*                  offBoardMember.put("LastName", "LastName");
*                  offBoardMember.put("OffBoardType", "Voluntary");
*                  offBoardMember.put("OffBoardDate", "MM/DD/YYYY");
*                  offBoardMember.put("NotificationEmail", "notificationemail@highground.com");
*      
*                  Gson gson = new Gson();
*                  String json = gson.toJson(offBoardMember);
*                  
*                  OutputStream os = conn.getOutputStream();
*                  os.write(json.getBytes());
*                  os.flush();
*                  
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X DELETE "https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c" \
*      --data '{"UserName":"UserName","FirstName":"FirstName","LastName":"LastName","OffBoardType":"Voluntary","OffBoardDate":"MM/DD/YYYY","NotificationEmail":"notificationemail@highground.com"}'
*/

/**
* @apiDefine POST_MemberExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var updateMember = {
*          Birthdate: 'MM/DD/YYYY',
*          UserName: 'UserName',
*          Email: 'email@highground.com',
*          HomeZip: '12345',
*          WorkZip: '98765',
*          FirstName: 'FirstName',
*          LastName: 'LastName',
*          FullName: 'FirstName LastName',      
*          Position: 'CEO',
*          StartingDate: 'MM/DD/YYYY',
*          MyManagers: [{ 
*              MemberId: '1a7484e0-519c-11e5-8bbd-a385a1c75a10',
*              EmployeeId: 'Manager EmployeeId',
*              FullName: 'Manager FullName' 
*          }],
*          Location: {
*              LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',
*              Name: 'Chicago'
*          },
*          GroupDepartment: {
*              DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',
*              Name: 'IT'
*          },
*          Role: 'Employee',
*          GravatarEmail: 'gravataremail@highground.com',
*          EmployeeId: 'HG001'
*      };
*      var dataString = JSON.stringify(updateMember);
*      var postheaders = {
*              'Accept' : 'application/json',  
*              'Content-Type' : 'application/json',
*              'clientkey' : '[Your API Key]',
*              'Content-Length' : dataString.length
*          };
*      
*      var options = {
*          host: 'api.highground.com',
*          port: 443,
*          path: '/1.0/Member/',
*          method: 'POST',
*          headers: postheaders,
*          body: dataString
*      };
*      
*      var reqGet = https.request(options, function(response) {
*        var buffer = "", data;
*        response.on('data', function (chunk) {
*          buffer += chunk;
*        });
*        response.on('end', function (err) {
*          data = JSON.parse(buffer);
*          console.log('statusCode: ', response.statusCode);
*          console.log('data:', data);
*        });
*      });
*      
*      reqGet.on('error', function(e) {
*          console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      require "json/ext"
*      
*      def onboard_member
*          uri = URI.parse("https://api.highground.com/1.0/Member/")
*          request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})
*          request['clientkey'] = "Your API key"
*          request.body = {
*              Birthdate: 'MM/DD/YYYY',
*              UserName: 'UserName',
*              Email: 'email@highground.com',
*              HomeZip: '12345',
*              WorkZip: '98765',
*              FirstName: 'FirstName',
*              LastName: 'LastName',
*              FullName: 'FirstName LastName',
*              Position: 'CEO',
*              StartingDate: 'MM/DD/YYYY',
*              MyManagers: [{
*                  MemberId: '1a7484e0-519c-11e5-8bbd-a385a1c75a10',
*                  EmployeeId: 'Manager EmployeeId',
*                  FullName: 'Manager FullName'
*              }],
*              Location: {
*                  LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',
*                  Name: 'Chicago'
*              },
*              GroupDepartment: {
*                  DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',
*                  Name: 'IT'
*              },
*              Role: 'Employee',
*              GravatarEmail: 'gravataremail@highground.com',
*              EmployeeId: 'HG001'
*          }.to_json
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res.body}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import json
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def onboard_member():
*        headers = {
*            'Accept' : 'application/json',
*            'Content-type': 'application/json',
*            'clientkey' : API_ACCESS_KEY
*        }
*        payload = json.dumps({
*              "Birthdate": "MM/DD/YYYY",
*              "UserName": "UserName",
*              "Email": "email@highground.com",
*              "HomeZip": "12345",
*              "WorkZip": "98765",
*              "FirstName": "FirstName",
*              "LastName": "LastName",
*              "FullName": "FirstName LastName",
*              "Position": "CEO",
*              "StartingDate": "MM/DD/YYYY",
*              "MyManagers": [{
*                  "MemberId": "1a7484e0-519c-11e5-8bbd-a385a1c75a10",
*                  "EmployeeId": "Manager EmployeeId",
*                  "FullName": "Manager FullName"
*              }],
*              "Location": {
*                  "LocationId": "158f0270-519c-11e5-927c-7d3b5e612a77",
*                  "Name": "Chicago"
*              },
*              "GroupDepartment": {
*                  "DepartmentId": "17ce6b20-519c-11e5-9f79-f10b3b47f7d2",
*                  "Name": "IT"
*              },
*              "Role": "Employee",
*              "GravatarEmail": "gravataremail@highground.com",
*              "EmployeeId": "HG001"
*          })
*        r = requests.post(
*                        'https://api.highground.com/1.0/Member/',
*                        headers=headers,
*                        data=payload,
*        )
*        print (r.status_code)
*        print (r.text)
*        
*      onboard_member()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Member/';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*         "Accept: application/json",
*         "Content-Type:application/json",
*         "clientkey:[Your API Key]"
*      );
*      
*      $curl_post_data = array(
*         'Birthdate' => 'MM/DD/YYYY',
*         'UserName' => 'UserName',
*         'Email' => 'email@highground.com',
*         'HomeZip' => '12345',
*         'WorkZip' => '98765',
*         'FirstName' => 'FirstName',
*         'LastName' => 'LastName',
*         'FullName' => 'FirstName LastName',
*         'Position' => 'CEO',
*         'StartingDate' => 'MM/DD/YYYY',
*         'Role' => 'Employee',
*         'GravatarEmail' => 'gravataremail@highground.com',
*         'EmployeeId' => 'HG001',
*         'MyManagers' =>  array(
*             'MemberId' =>  '1a7484e0-519c-11e5-8bbd-a385a1c75a10',
*             'EmployeeId' =>  'Manager EmployeeId',
*             'FullName' =>  'Manager FullName'
*          ),
*         'Location' =>  array(
*             'LocationId' =>  '158f0270-519c-11e5-927c-7d3b5e612a77',
*             'Name' =>  'Chicago'
*          ),
*         'GroupDepartment' =>  array(
*             'DepartmentId' =>  '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',
*             'Name' =>  'IT'
*         )
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      curl_setopt($curl, CURLOPT_POST, true);
*      curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*        $info = curl_getinfo($curl);
*        curl_close($curl);
*        die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*        die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*  using System;
*  using System.IO;
*  using System.Net;
*  using System.Text;
*  using System.ServiceModel;
*  using System.Runtime.Serialization;
*  using System.ServiceModel.Web;
*  using System.Web.Script.Serialization;
* 
*  namespace Rextester
*  {
*      public class Program
*      {
*          public const string uri = "https://api.highground.com/1.0/Member";
*          public class Member
*          {
*              public DateTime Birthdate = "MM/DD/YYYY";
*              public String UserName = "UserName";
*              public String Email = "email@highground.com";
*              public String HomeZip = "12345";
*              public String WorkZip = "98765";
*              public String EmployeeId = "HG001";
*              public String FirstName = "FirstName";
*              public String LastName = "LastName";
*              public String FullName = "FullName";
*              public String Position = "CEO";
*              public DateTime StartingDate = "MM/DD/YYYY";
*              public String Role = "Employee";
*              public String GravatarEmail = "gravataremail@highground.com";
*              public Manager MyManagers;
*              public Location Location;
*              public Department GroupDepartment;
*          }
*          public class Manager
*          {
*              public String MemberId = "1a7484e0-519c-11e5-8bbd-a385a1c75a10";
*              public String UserId = "158f0270-519c-11e5-927c-7d3b5e612a77";
*              public String FullName = "Manager FullName";
*          }
*          public class Location
*          {
*              public String LocationId = "158f0270-519c-11e5-927c-7d3b5e612a77";
*              public String Name = "Chicago"; 
*          }
*          public class Department
*          {
*              public String DepartmentId = "17ce6b20-519c-11e5-9f79-f10b3b47f7d2";
*              public String Name = "IT"; 
*          }
*          public static void Main(string[] args)
*          {
*              var member = new Member();
*              member.MyManagers = new Manager();
*              member.Location = new Location();
*              member.GroupDepartment = new Department();
*              
*              HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
*              request.Method = "POST";
*              request.ContentType = "application/json;charset=utf-8";
*              var json = new JavaScriptSerializer().Serialize(member);
*              System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
*              byte[] bytes = encoding.GetBytes(json);
*              request.ContentLength = bytes.Length;
*              using (Stream requestStream = request.GetRequestStream())
*              {
*                  requestStream.Write(bytes, 0, bytes.Length);
*              }
*              request.BeginGetResponse((x) =>
*              {
*                  using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))
*                  {
*                      if (callback != null)
*                      {
*                          DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));
*                          callback(ser.ReadObject(response.GetResponseStream()) as Response);
*                      }
*                  }
*              }, null);
*          }
*      }
*  }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.io.OutputStream;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      import java.util.HashMap;
*      import java.util.Map;
*      import com.google.gson.Gson;
*      
*      class Rextester
*      {
*          public static void main(String args[])
*          {
*              try 
*              {
*                  URL url = new URL("https://api.highground.com/1.0/Member/");
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("POST");
*                  conn.setRequestProperty("Content-Type", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  HashMap<String, Object> memberData = new HashMap<String, Object>();
*                  memberData.put("Birthdate", "MM/DD/YYYY");
*                  memberData.put("UserName", "UserName");
*                  memberData.put("Email", "email@highground.com");
*                  memberData.put("HomeZip", "12345");
*                  memberData.put("WorkZip", "98765");
*                  memberData.put("EmployeeId", "HG001");
*                  memberData.put("FirstName", "FirstName");
*                  memberData.put("LastName", "LastName");
*                  memberData.put("FullName", "FullName");
*                  memberData.put("Position", "CEO");
*                  memberData.put("StartingDate", "MM/DD/YYYY");
*                  memberData.put("Role", "Employee");
*                  memberData.put("GravatarEmail", "gravataremail@highground.com");
*      
*                  HashMap<String, Object> managerData = new HashMap<String, Object>();
*                  managerData.put("MemberId", "1a7484e0-519c-11e5-8bbd-a385a1c75a10");
*                  managerData.put("EmployeeId", "Manager EmployeeId");
*                  managerData.put("FullName", "Manager FullName");
*                  memberData.put("MyManagers", managerData);
*                  
*                  HashMap<String, Object> locationData = new HashMap<String, Object>();
*                  locationData.put("LocationId", "158f0270-519c-11e5-927c-7d3b5e612a77");
*                  locationData.put("Name", "FirstName");
*                  memberData.put("Location", locationData);
*                  
*                  HashMap<String, Object> departmentData = new HashMap<String, Object>();
*                  departmentData.put("LocationId", "17ce6b20-519c-11e5-9f79-f10b3b47f7d2");
*                  departmentData.put("Name", "IT");
*                  memberData.put("GroupDepartment", departmentData);
*                  
*                  Gson gson = new Gson();
*                  String json = gson.toJson(memberData);
*                  OutputStream os = conn.getOutputStream();
*                  os.write(json.getBytes());
*                  os.flush();
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X POST "https://api.highground.com/1.0/Member/" \
*      --data '{"Birthdate":"MM/DD/YYYY","UserName":"UserName","Email":"email@highground.com","HomeZip":"12345","WorkZip":"98765","FirstName":"FirstName","LastName":"LastName","FullName":"FirstName LastName","Position":"CEO","StartingDate":"MM/DD/YYYY","MyManagers":{"MemberId":"1a7484e0-519c-11e5-8bbd-a385a1c75a10","EmployeeId":"Manager EmployeeId","FullName":"Manager FullName"},"Location":{"LocationId":"158f0270-519c-11e5-927c-7d3b5e612a77","Name":"Chicago"},"GroupDepartment":{"DepartmentId":"17ce6b20-519c-11e5-9f79-f10b3b47f7d2","Name":"IT"},"Role":"Employee","GravatarEmail":"gravataremail@highground.com","EmployeeId":"HG001"}'
*/
/**
* @apiDefine ResendWelcomeEmail_MemberExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var header = {
*          host: 'api.highground.com',
*          port: 443,
*          clientkey: '[Your API Key]',
*          path: '/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          method: 'POST'
*      };
*      
*      var reqGet = https.request(header, function(response) {
*          var buffer = "", data;
*          
*          response.on('data', function (chunk) {
*              buffer += chunk;
*          });
*      
*          response.on('end', function (err) {
*              data = JSON.parse(buffer);
*              console.log('statusCode: ', response.statusCode);
*              console.log('data:', data);
*          });
*      });
*      
*      reqGet.on('error', function(e) {
*        console.error('error', e);
*      })
*      
*      reqGet.end();
*
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      
*      def get_departments
*          uri = URI.parse("https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c")
*          request = Net::HTTP::Post.new(uri)
*          request['clientkey'] = "Your API key"
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def resend_welcome_email_to_member():
*          headers = {
*              'Accept' : 'application/json',
*              'Content-type': 'application/json',
*              'clientkey' : API_ACCESS_KEY
*          }
*          r = requests.post(
*                          'https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c',
*                          headers=headers
*          )
*          print (r.status_code)
*          print (r.text)
*      
*      resend_welcome_email_to_member()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*        "Accept: application/json",
*        "clientkey:[Your API Key]"
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      curl_setopt($curl, CURLOPT_POST, true);
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*        $info = curl_getinfo($curl);
*        curl_close($curl);
*        die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*        die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*    using System;
*    using System.IO;
*    using System.Net;
*    using System.Text;
*
*    namespace Rextester
*    {
*        public class Program
*        {
*            public const string EndPoint = "https://api.highground.com/1.0/Member/resendWelcomeEmail/";
*            
*            public static void Main(string[] args)
*            {
*                public String MemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*                var request = (HttpWebRequest)WebRequest.Create(EndPoint + MemberId);
*                request.Method = "POST";
*                request.ContentLength = 0;
*                request.ContentType = "application/json";
*                request.Headers.Add("clientkey", "[Your API Key]");
*                using (var response = (HttpWebResponse)request.GetResponse())
*                {
*                  var responseValue = string.Empty;
*                  if (response.StatusCode != HttpStatusCode.OK)
*                  {
*                    var message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
*                    throw new ApplicationException(message);
*                  }
*                  using (var responseStream = response.GetResponseStream())
*                  {
*                    if (responseStream != null)
*                      using (var reader = new StreamReader(responseStream))
*                      {
*                        responseValue = reader.ReadToEnd();
*                      }
*                  }
*                  Console.Write(responseValue);
*                }
*            }
*        }
*    }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      
*      class Rextester
*      {  
*          public static void main(String args[])
*          {
*              try 
*              {
*                  String MemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*                  URL url = new URL("https://api.highground.com/1.0/Member/resendWelcomeEmail/" + MemberId);
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("POST");
*                  conn.setRequestProperty("Accept", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X POST "https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c" 
*/

/**
* @apiDefine Reinstate_MemberExample
*
* @apiExample {Node} Node
*      var https = require('https');
*      
*      var reinstateMember = {
*          MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          Email: 'membernewemail@highground.com'
*      };
*      
*      var dataString = JSON.stringify(reinstateMember);
*      var postheaders = {
*              'Accept' : 'application/json',  
*              'Content-Type' : 'application/json',
*              'clientkey' : '[Your API Key]',
*              'Content-Length' : dataString.length
*          };
*      
*      var options = {
*          host: 'apipoc.highground.com',
*          port: 443,
*          path: '/1.0/Member/reinstate/',
*          method: 'POST',
*          headers: postheaders,
*          body: dataString
*      };
*      
*      var reqGet = https.request(options, function(response) {
*        var buffer = "", data;
*        response.on('data', function (chunk) {
*          console.log('here', chunk);
*            buffer += chunk;
*        });
*        response.on('end', function (err) {
*            data = JSON.parse(buffer);
*            console.log('statusCode: ', response.statusCode);
*            console.log('data:', data);
*        });
*      });
*      
*      reqGet.on('error', function(e) {
*          console.error('error', e);
*      })
*      
*      reqGet.end();
*
* @apiExample {Ruby} Ruby
*      require "net/http"
*      require "net/https"
*      require "uri"
*      require "json/ext"
*      
*      def reinstate_member
*          uri = URI.parse("https://api.highground.com/1.0/Member/reinstate/")
*          request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})
*          request['clientkey'] = "Your API key"
*          request.body = {
*              MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*              Email: 'email@highground.com'
*          }.to_json
*          res = Net::HTTP.start(uri.host, uri.port,
*            :use_ssl => uri.scheme == 'https') {|http|
*            http.request(request)
*          }
*          puts "response #{res}"
*          rescue => e
*              puts "failed #{e}"
*      end
*
* @apiExample {Python} Python
*      import json
*      import requests
*      
*      API_ACCESS_KEY='[Your API Key]'
*      
*      def reinstate_member():
*          headers = {
*              'Accept' : 'application/json',
*              'Content-type': 'application/json',
*              'clientkey' : API_ACCESS_KEY
*          }
*          payload = json.dumps({
*            "MemberId": "d9d14d00-41ca-11e5-95f3-29dbd151f43c",
*            "Email": "email@highground.com"
*          })
*          r = requests.post(
*                          'https://api.highground.com/1.0/reinstate/',
*                          headers=headers,
*                          data=payload,
*          )
*          print (r.status_code)
*          print (r.text)
*          
*      reinstate_member()
*
* @apiExample {Php} Php
*      <?php
*      // You need to install and configure CURL to use following sample code
*      $service_url = 'https://api.highground.com/1.0/reinstate/';
*      $curl = curl_init($service_url);
*      
*      $headers = array (
*        "Accept: application/json",
*        "Content-Type:application/json",
*        "clientkey:[Your API Key]"
*      );
*      
*      $curl_post_data = array(
*          'MemberId' => 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',
*          'Email' => 'email@highground.com'
*      );
*      
*      curl_setopt($ch, CURLOPT_URL, $service_url);
*      curl_setopt($ch, CURLOPT_HEADER, $headers);
*      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
*      curl_setopt($curl, CURLOPT_POST, true);
*      curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));
*      
*      $curl_response = curl_exec($curl);
*      if ($curl_response === false) {
*        $info = curl_getinfo($curl);
*        curl_close($curl);
*        die('error occured during curl exec. Additioanl info: ' . var_export($info));
*      }
*      curl_close($curl);
*      $decoded = json_decode($curl_response);
*      if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
*        die('error occured: ' . $decoded->response->errormessage);
*      }
*      echo 'response ok!';
*      var_export($decoded->response);
*      ?>
*
* @apiExample {CSharp} C#
*  using System;
*  using System.IO;
*  using System.Net;
*  using System.Text;
*  using System.ServiceModel;
*  using System.Runtime.Serialization;
*  using System.ServiceModel.Web;
*  using System.Web.Script.Serialization;
* 
*  namespace Rextester
*  {
*      public class Program
*      {
*          public const string uri = "https://api.highground.com/1.0/reinstate/";
*          public class MemberReinstate
*          {
*              public String MemberId = "d9d14d00-41ca-11e5-95f3-29dbd151f43c";
*              public String Email = "email@highground.com";
*          }
*          public static void Main(string[] args)
*          {
*              var memberReinstate = new MemberReinstate();
*              HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
*              request.Method = "POST";
*              request.ContentType = "application/json;charset=utf-8";
*              var json = new JavaScriptSerializer().Serialize(memberReinstate);
*              System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
*              byte[] bytes = encoding.GetBytes(json);
*              request.ContentLength = bytes.Length;
*              using (Stream requestStream = request.GetRequestStream())
*              {
*                  requestStream.Write(bytes, 0, bytes.Length);
*              }
*              request.BeginGetResponse((x) =>
*              {
*                  using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))
*                  {
*                      if (callback != null)
*                      {
*                          DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));
*                          callback(ser.ReadObject(response.GetResponseStream()) as Response);
*                      }
*                  }
*              }, null);
*          }
*      }
*  }
*
* @apiExample {Java} Java
*      import java.io.BufferedReader;
*      import java.io.IOException;
*      import java.io.InputStreamReader;
*      import java.io.OutputStream;
*      import java.net.HttpURLConnection;
*      import java.net.MalformedURLException;
*      import java.net.URL;
*      import java.util.HashMap;
*      import java.util.Map;
*      import com.google.gson.Gson;
*      
*      
*      class Rextester
*      {
*          public static void main(String args[])
*          {
*              try 
*              {
*                  URL url = new URL("https://api.highground.com/1.0/Member/");
*                  HttpURLConnection conn = (HttpURLConnection) url.openConnection();
*                  conn.setRequestMethod("POST");
*                  conn.setRequestProperty("Content-Type", "application/json");
*                  conn.setRequestProperty("clientkey", "[Your API Key]");
*                  
*                  HashMap<String, Object> memberReinstate = new HashMap<String, Object>();
*                  memberReinstate.put("MemberId", "d9d14d00-41ca-11e5-95f3-29dbd151f43c");
*                  memberReinstate.put("Email", "email@highground.com");
*      
*                  Gson gson = new Gson();
*                  String json = gson.toJson(memberReinstate);
*                  OutputStream os = conn.getOutputStream();
*                  os.write(json.getBytes());
*                  os.flush();
*                  
*                  if (conn.getResponseCode() != 200) {
*                      throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
*                  }
*                  BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
*                  String output;
*                  while ((output = br.readLine()) != null) {
*                      System.out.println(output);
*                  }
*                  conn.disconnect();
*             } 
*              catch (MalformedURLException e) { e.printStackTrace(); }
*              catch (IOException e) { e.printStackTrace(); }
*          }
*      }
*
* @apiExample {Curl} Curl
*      curl -i \
*      -H "Accept: application/json" \
*      -H "Content-Type:application/json" \
*      -H "clientkey:[Your API Key]" \
*      -X POST "https://api.highground.com/1.0/Member/reinstate/" \
*      --data '{"MemberId":"d9d14d00-41ca-11e5-95f3-29dbd151f43c","Email":"email@highground.com"}'
*/