/*jslint node:true es5:true*/
'use strict';
var StatusCodes = require('../../enums/HttpResponseCodes.js'),
    DefaultErrors = require('../DefaultErrors'),
    async = require('async'),
    validator = require('mongoose-validator').validatorjs,
    DTOUtil = require('../../util/DTOUtil.js'),
    TeamErrors = require('./enums/TeamErrors.js'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    paramsUtil = require('../../util/params.js'),
    Location = require('./datacontract/Location.js').Location,
    BulkMapper = require('./datacontract/Location.js').BulkMapper,
    MapToDB = require('./datacontract/Location.js').DBMapper,
    HgLog = require('../../framework/HgLog.js'),
    guid = require('node-uuid'),
    TAKE_LIMIT = 25,
    RATE_LIMIT = 100,
    LocationsService = function () {
        /**
         * @apiDefine MemberIdsParam
         * @apiParam (body) {String[]} body An array of Member unique IDs, max size is 100 records
         */

        /**
         * @apiDefine MemberArrayParam
         * @apiParam (body) {Member[]} body An array of Members
         */
        function locationsValidation(params, callback) {
            var validationErrors = {},
                locaitonHash = {},
                dupeErrors = {};
            async.each(params.data, function (item, aeCb) {
                var location = new Location(item),
                    locationErrorArray = [],
                    location_key;
                location.validate(function (error) {
                    var i,
                        len,
                        keys;
                    if (error && error.errors) {
                        keys = Object.keys(error.errors);
                        for (i = 0, len = keys.length; i < len; i += 1) {
                            locationErrorArray.push(error.errors[keys[i]].message);
                        }
                    }
                    location_key = (item.LocationCode || item.Name || "").trim().toLowerCase();
                    if (!locaitonHash[location_key]) {
                        locaitonHash[location_key] = true;
                    } else {
                        dupeErrors[location.Name] = TeamErrors.DuplicateLocationCode.Description;
                    }
                    if (locationErrorArray.length) {
                        validationErrors[location.Name || "Name"] = locationErrorArray;
                    }
                    aeCb();
                });
            }, function () {
                if (Object.keys(validationErrors).length) {
                    return callback(TeamErrors.MissingRequiredLocationInfo, validationErrors);
                }
                if (Object.keys(dupeErrors).length) {
                    return callback(TeamErrors.DuplicateLocationCode, dupeErrors);
                }
                callback();
            });
        }
        function mapTOBulkSchema(params) {
            return params.data.map(function (item) {
                return new BulkMapper(new Location(item));
            });
        }
        /**
         * @api {get} /1.0/Locations/ Get Locations
         * @apiVersion 1.0.0
         * @apiName GetLocations
         * @apiGroup Locations
         * @apiDescription Return an array of Locations
         *
         * @apiUse AccessHeader
         *
         * @apiParam (query) {Number} [skip] The number of records to skip
         * @apiParam (query) {Number} [take] The number of records to return (max 25)
         *
         * @apiUse InvalidTakeValue
         * @apiUse InvalidSkipValue
         * @apiUse UnknownError
         *
         * @apiUse LocationArraySuccessDTO
         *
         * @apiUse GET_LocationExample
         */
        this.get = function (context, callback) {
            if (!paramsUtil.IsPositiveNumber(context.query.take) || context.query.take > TAKE_LIMIT) {
                return callback(DefaultErrors.InvalidTakeValue);
            }
            if (!paramsUtil.IsPositiveNumber(context.query.skip)) {
                return callback(DefaultErrors.InvalidSkipValue);
            }
            var teamInternalService = new InternalServiceCache.Team(context.correlationId);
            teamInternalService.GetLocationsByGroupId({
                GroupId: context.groupid,
                Skip: context.query.skip || 0,
                Take: context.query.take || TAKE_LIMIT,
                ExcludeMemberCount: true
            }, function (error, locations) {
                if (error) {
                    return callback(DefaultErrors.UnknownError);
                }
                callback(null, {
                    StatusCode: StatusCodes.Success.OK,
                    data: locations.map(function (item) {
                        return DTOUtil.CreateResponse({
                            LocationId: item.hgId,
                            Name: item.Name,
                            LocationCode: item.LocationCode,
                            Description: item.Description,
                            Address: item.Address,
                            TimeZone: item.tz,
                            Phone: item.Phone,
                            Language: item.i18n
                        }, 'Object', Location);
                    })
                });
            });
        };
        /**
         * @api {post} /1.0/Locations Add or Update Locations
         * @apiVersion 1.0.0
         * @apiName UpdateLocations
         * @apiGroup Locations
         *
         * @apiUse AccessHeader
         *
         * @apiUse LocationArraySuccessDTO
         *
         * @apiUse MissingRequiredLocationInfo
         * @apiUse InvalidTimeZone
         * @apiUse CountryNotFound
         * @apiUse UnknownError
         * @apiUse DuplicateLocationCode
         *
         * @apiUse POST_LocationExample
         *
         * @apiSuccess {String} message Message confirming Locations has been imported successfully
         * @apiSuccessExample {json} Example Successful Response:
         *  {
         *      "message": "Locations has been imported successfully."
         *  }
         */
        this.post = function (context, callback) {
            if (context.body.length > RATE_LIMIT) {
                return callback(TeamErrors.RateLimitExceed);
            }
            locationsValidation({ data: context.body }, function (error, data) {
                if (error) {
                    return callback(error, data);
                }
                var newlocations = [],
                    updateLocations = [],
                    locations = [],
                    location,
                    teamInternalService = new InternalServiceCache.Team(context.correlationId);
                locations = mapTOBulkSchema({data: context.body});
                async.eachLimit(locations, 10, function (item, aeCb) {
                    location = new MapToDB(new Location(item));
                    location.GroupId = context.groupid;
                    teamInternalService.GetLocationByLocationCode({
                        LocationCode: location.LocationCode,
                        GroupId: location.GroupId
                    }, function (error, loc) {
                        if (error) {
                            if (error !== 'Cannot retrieve Team') {
                                return aeCb(DefaultErrors.UnknownError);
                            }
                        }
                        if (!loc) {
                            newlocations.push(location);
                        } else {
                            loc.Name = location.Name;
                            loc.Description = location.Description;
                            loc.i18n = location.Language;
                            loc.tz = location.TimeZone;
                            loc.Phone = location.Phone;
                            loc.Address.Address1 = location.Address.Address1;
                            loc.Address.Address2 = location.Address.Address2;
                            loc.Address.City = location.Address.City;
                            loc.Address.State = location.Address.State;
                            loc.Address.Zip = location.Address.Zip;
                            loc.Address.Country = location.Address.Country;
                            updateLocations.push(loc);
                        }
                        return aeCb();
                    });
                }, function (error) {
                    if (error) {
                        HgLog.error('API: Error Locations POST', error);
                        return callback(DefaultErrors.UnknownError);
                    }
                    teamInternalService.CreateLocations({ Locations: newlocations }, function (error) {
                        if (error) {
                            HgLog.error('API: CreateLocations', error);
                            return callback(DefaultErrors.UnknownError);
                        }
                        teamInternalService.UpdateLocationsForProvision({ Locations: updateLocations }, function (error) {
                            if (error) {
                                HgLog.error('API: UpdateLocationsForProvision', error);
                                return callback(DefaultErrors.UnknownError);
                            }
                            callback(null, {
                                StatusCode: StatusCodes.Success.OK,
                                data: { message: 'Locations has been imported successfully.'}
                            });
                        });
                    });
                });
            });
        };
    };

module.exports = LocationsService;