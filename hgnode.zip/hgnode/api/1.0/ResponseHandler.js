'use strict';

var ResponseHandler = function (correlationId) {
    var RequestManager = require('../../framework/RequestManager');

    this.handleResponse = function (error, response) {
        if (error) {
            RequestManager.sendHttpCodeAndJson(correlationId, error.StatusCode, {
                error: error.Description,
                details: response
            });
            return;
        }
        RequestManager.sendHttpCodeAndJson(correlationId, response.StatusCode, response.data);
    };
};

module.exports = ResponseHandler;