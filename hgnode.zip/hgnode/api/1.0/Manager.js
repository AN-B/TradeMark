/*jslint node:true es5:true*/
'use strict';
var StatusCodes = require('../../enums/HttpResponseCodes.js'),
    ManagerErrors = require('./enums/ManagerErrors.js'),
    EntityEnums = require('../../enums/EntityEnums.js'),
    DefaultErrors = require('../DefaultErrors'),
    validator = require('mongoose-validator').validatorjs,
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    config = require('../../configurations/config.js'),
    Async = require('async'),
    TransferManager = require('./datacontract/TransferManager.js').TransferManager,
    HgLog = require('../../framework/HgLog.js'),
    ManagerService = function () {
        /**
        * @api {post} /1.0/Manager/TransferManager/ Transfer Manager
        * @apiVersion 1.0.0
        * @apiName TransferManager
        * @apiGroup Manager
        * @apiDescription Transfer members from one manager to other manager
        *
        * @apiUse AccessHeader
        * @apiUse TransferManagerDTO
        *
        * @apiUse InvalidTransferManagerInfo
        * @apiUse OldManagerNotFound
        * @apiUse NewManagerNotFound
        * @apiUse ManagerWithoutDirectReports
        * @apiUse NewManagerInvalidStatus
        * @apiUse OldManagerInvalidStatus
        * @apiUse SameOldAndNewManagerId
        * @apiUse UnknownError
        * @apiUse MemberIdsPassedInDontMatchManagerDirectReports
        *
        * @apiSuccess {String} message Message confirming the Transfer Manager was completed
        * @apiSuccessExample {json} Example Successful Response:
        *  {
        *      "message": "Transfer manager has been completed successfully."
        *  }
        *
        * @apiUse POST_TransferManagerExample
        */
        this.TransferManager = function (context, callback) {
            var transferManager = new TransferManager(context.body),
                params = {
                    correlationId: context.correlationId,
                    GroupId: context.groupid,
                    GroupName: context.clientname,
                    UserId: config.APIGlobalUserId
                },
                directReportsArr,
                memberInternalService = new InternalServiceCache.Member(context.correlationId);
            transferManager.validate(function (validationErrors) {
                if (validationErrors) {
                    return callback(ManagerErrors.InvalidTransferManagerInfo, validationErrors);
                }
                if (transferManager.OldManagerMemberId === transferManager.NewManagerMemberId) {
                    return callback(ManagerErrors.SameOldAndNewManagerId);
                }
                Async.waterfall([
                    //1. Get Direct Reports
                    function (fcallback) {
                        memberInternalService.GetSubordinateMembers({
                            correlationId: context.correlationId,
                            MemberId: transferManager.OldManagerMemberId,
                            GroupId: context.groupid
                        }, function (error, directReports) {
                            if (error) {
                                HgLog.error(error);
                                return fcallback(DefaultErrors.UnknownError);
                            }
                            if (!directReports || !directReports.length) {
                                return fcallback(ManagerErrors.ManagerWithoutDirectReports);
                            }

                            directReportsArr = directReports.reduce(function (memo, item) {
                                if (context.body.MemberIds.indexOf(item.hgId) !== -1) {
                                    memo.push(item.hgId);
                                }
                                return memo;
                            }, []);

                            if (!directReportsArr.length) {
                                return fcallback(ManagerErrors.MemberIdsPassedInDontMatchManagerDirectReports);
                            }

                            params.TransferRequest = {
                                OldManager: {},
                                NewManager: {},
                                DirectReports: directReportsArr,
                                TransferItems: {
                                    Profile: transferManager.TransferItems.TransferProfile,
                                    Points: transferManager.TransferItems.TransferPoints,
                                    Credits: transferManager.TransferItems.TransferCredit,
                                    Tracks: transferManager.TransferItems.TransferTracks,
                                    Perform: transferManager.TransferItems.TransferPerform
                                }
                            };
                            fcallback();
                        });
                    },
                    //2. Get old manager information
                    function (fcallback) {
                        memberInternalService.GetCompleteMemberRecord({
                            correlationId: context.correlationId,
                            MemberId: transferManager.OldManagerMemberId
                        }, function (error, oldMember) {
                            if (error || !oldMember) {
                                if (error === 'services.int.mem.mnf') {
                                    return fcallback(ManagerErrors.OldManagerNotFound);
                                }
                                return fcallback(DefaultErrors.UnknownError);
                            }
                            if (oldMember && oldMember.Member.MembershipStatus !== EntityEnums.MembershipStatus.Active) {
                                return fcallback(ManagerErrors.OldManagerInvalidStatus);
                            }
                            params.TransferRequest.OldManager = {
                                hgId: oldMember.Member.hgId,
                                UserId: oldMember.Member.UserId,
                                FullName: oldMember.Member.FullName,
                                FirstName: oldMember.Member.FirstName,
                                LastName: oldMember.Member.LastName,
                                Position: oldMember.Member.Position
                            };
                            fcallback();
                        });
                    },
                    //3. Get new manager information
                    function (fcallback) {
                        memberInternalService.GetCompleteMemberRecord({
                            correlationId: context.correlationId,
                            MemberId: transferManager.NewManagerMemberId
                        }, function (error, newMember) {
                            if (error || !newMember) {
                                if (error === 'services.int.mem.mnf') {
                                    return fcallback(ManagerErrors.NewManagerNotFound);
                                }
                                return fcallback(DefaultErrors.UnknownError);
                            }
                            if (newMember && newMember.Member.MembershipStatus !== EntityEnums.MembershipStatus.Active) {
                                return fcallback(ManagerErrors.NewManagerInvalidStatus);
                            }
                            params.TransferRequest.NewManager = {
                                hgId: newMember.Member.hgId,
                                UserId: newMember.Member.UserId,
                                FullName: newMember.Member.FullName,
                                FirstName: newMember.Member.FirstName,
                                LastName: newMember.Member.LastName,
                                Position: newMember.Member.Position
                            };
                            fcallback();
                        });
                    },
                    //4. Transfer Manager
                    function (fcallback) {
                        memberInternalService.TransferManager(params, function (error) {
                            if (error) {
                                HgLog.error('Manager API TransferManager', error);
                                return fcallback(DefaultErrors.UnknownError);
                            }
                            fcallback();
                        });
                    }
                ], function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: {message: 'Transfer manager has been completed successfully.'}
                    });
                });
            });
        };
    };

module.exports = ManagerService;