/*jslint node:true es5:true*/
'use strict';
var httpResponseCodes = require('../../enums/HttpResponseCodes.js'),
    DefaultErrors = require('../DefaultErrors'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    EventBusService = function () {
        this.post = function (context, callback) {
            var newParams = {
                    correlationId: context.correlationId,
                    ClientId: context.clientId,
                    ClientName: context.clientname,
                    Payload: context.body.Payload,
                    EventType: context.body.EventType,
                    EntityType: context.body.EntityType,
                    EntityId: context.body.EntityId
                },
                eventBusInternalService = new InternalServiceCache.EventBus(context.correlationId);
            eventBusInternalService.CreateEvent(newParams, function (error, data) {
                if (error) {
                    return callback(DefaultErrors.UnknownError);
                }
                callback(null, {
                    StatusCode: httpResponseCodes.Success.OK,
                    data: data
                });
            });
        };
    };

module.exports = EventBusService;