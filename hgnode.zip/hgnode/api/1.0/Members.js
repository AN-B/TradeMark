/*jslint node:true es5:true*/
'use strict';
var StatusCodes = require('../../enums/HttpResponseCodes.js'),
    ProvisionEnums = require('../../enums/ProvisionEnums.js'),
    EntityEnums = require('../../enums/EntityEnums.js'),
    MemberErrors = require('./enums/MemberErrors.js'),
    DefaultErrors = require('../DefaultErrors'),
    validator = require('mongoose-validator').validatorjs,
    DTOUtil = require('../../util/DTOUtil.js'),
    paramUtil = require('../../util/params.js'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    config = require('../../configurations/config.js'),
    Member = require('./datacontract/Member.js').Member,
    BulkMapper = require('./datacontract/Member.js').BulkMapper,
    MemberOffBoard = require('./datacontract/MemberOffBoard.js').MemberOffBoard,
    MemberReinstate = require('./datacontract/MemberReinstate.js').MemberReinstate,
    MemberSearch = require('./datacontract/MemberSearch.js').MemberSearch,
    MapToDTO = require('./datacontract/Member.js').DTOMapper,
    async = require('async'),
    RATE_LIMIT = 100,
    operationType = {
        Update: 'Update',
        Onboard: 'Onboard'
    },
    MembersService = function () {
        /**
         * @apiDefine MemberIdsParam
         * @apiParam (body) {String[]} body An array of Member unique IDs, max size is 100 records
         */

        /**
         * @apiDefine MemberArrayParam
         * @apiParam (body) {Member[]} body An array of Members
         */
        function membersValidation(params, callback) {
            var validationErrors = {};
            async.each(params.data, function (item, callback) {
                var member = new Member(item),
                    memberErrorArray = [];
                member.validate(function (error) {
                    if (params.operation === operationType.Update) {
                        if (!member.MemberId) {
                            memberErrorArray.push(MemberErrors.MissingMemberId.Description);
                        } else {
                            if (!validator.isUUID(member.MemberId)) {
                                memberErrorArray.push(MemberErrors.InvalidMemberId.Description);
                            }
                        }
                    }
                    var i,
                        len,
                        keys;
                    if (error && error.errors) {
                        keys = Object.keys(error.errors);
                        for (i = 0, len = keys.length; i < len; i += 1) {
                            memberErrorArray.push(error.errors[keys[i]].message);
                        }
                    }
                    if (memberErrorArray.length) {
                        validationErrors[member.FullName] = memberErrorArray;
                    }
                    callback();
                });
            }, function () {
                if (Object.keys(validationErrors).length) {
                    return callback(MemberErrors.InvalidMembersInfo, validationErrors);
                }
                return callback();
            });
        }
        function mapTOBulkSchema(params) {
            return params.data.map(function (item) {
                return new BulkMapper(new Member(item));
            });
        }
        /**
         * @api {get} /1.0/Members Get Members
         * @apiVersion 1.0.0
         * @apiName GetMembers
         * @apiGroup Members
         *
         * @apiUse AccessHeader
         *
         * @apiParam (query) {Number} [skip] The number of records to skip
         * @apiParam (query) {Number} [take] The number of records to return (max 25)
         * @apiParam (query) {Date} [since] The beginning date range of a Member's StartingDate
         * @apiParam (query) {Date} [until] The end date range of a Member's StartingDate
         * @apiParam (query) {String} [fullname] Member's full name to search against. Default is exact match, or start with 'like:' for names containing that string
         * @apiParam (query) {String=Active,OffBoarded} [status] Member's status
         * @apiParam (query) {Boolean} [hierarchy] Pull member's information in the hierarchy format. If this option is used, you can only query by manager's exact full name. All other query string fields are ignored
         *
         * @apiUse InvalidSearchCriteria
         * @apiUse MemberNotFound
         * @apiUse UnknownError
         *
         * @apiSuccess {Member[]} body An array of Members
         */

        this.get = function (context, callback) {
            var memberSearch = new MemberSearch(paramUtil.lowercaseObjectKey(context.query)),
                memberInternalService = new InternalServiceCache.Member(context.correlationId);
            function hierarchySearch() {
                memberInternalService.GetMembersInHierarchy({
                    correlationId: context.correlationId,
                    GroupId: context.groupid,
                    FullName: paramUtil.EscapeBadChars(context.query.fullname)
                }, function (error, data) {
                    if (error) {
                        return callback(DefaultErrors.UnknownError);
                    }
                    if (!data) {
                        return callback(MemberErrors.MemberNotFound);
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: data
                    });
                });
            }
            function regularSearch() {
                //not best idea but since case insensitive match on mongo will not use index field so for better performance.
                if (memberSearch.status) {
                    if (memberSearch.status.toLowerCase() === 'active') {
                        memberSearch.status = EntityEnums.MembershipStatus.Active;
                    } else if (memberSearch.status.toLowerCase() === 'offboarded') {
                        memberSearch.status = EntityEnums.MembershipStatus.OffBoarded;
                    }
                }
                memberSearch.validate(function (validationErrors) {
                    if (validationErrors) {
                        return callback(DefaultErrors.InvalidSearchCriteria, validationErrors);
                    }
                    memberInternalService.SearchMembers({
                        correlationId: context.correlationId,
                        GroupId: context.groupid,
                        MembershipStatus: memberSearch.status,
                        FullName: paramUtil.EscapeBadChars((memberSearch.fullname && memberSearch.fullname.indexOf('like:') !== -1) ? memberSearch.fullname.replace('like:', '') : memberSearch.fullname || ''),
                        Since: memberSearch.since ? new Date(memberSearch.since).getTime() : null,
                        Until: memberSearch.until ? new Date(memberSearch.until).getTime() : null,
                        DateField: memberSearch.datefield,
                        Take: memberSearch.take,
                        Skip: memberSearch.skip,
                        SortBy: memberSearch.sortby,
                        IsStartWith: (memberSearch.fullname && memberSearch.fullname.indexOf('like:') !== -1)
                    }, function (error, data) {
                        if (error) {
                            return callback(DefaultErrors.UnknownError);
                        }
                        if (!data) {
                            return callback(MemberErrors.MemberNotFound);
                        }
                        var members = [],
                            item;
                        Object.keys(data).map(function (key) {
                            item = data[key];
                            var member = new Member(new MapToDTO(item.Member));
                            member.UserName = (item.UserInfo && item.UserInfo.UserName) ? item.UserInfo.UserName : null;
                            member.HomeZip = (item.UserInfo && item.UserInfo.Preference && item.UserInfo.Preference.HomeZip) ? item.UserInfo.Preference.HomeZip : null;
                            member.WorkZip = (item.UserInfo && item.UserInfo.Preference && item.UserInfo.Preference.WorkZip) ? item.UserInfo.Preference.WorkZip : null;
                            member.Email = (item.UserInfo && item.UserInfo.UserPersonal && item.UserInfo.UserPersonal.PrimaryEmail) ? item.UserInfo.UserPersonal.PrimaryEmail : null;
                            member.GravatarEmail = (item.UserInfo && item.UserInfo.UserContext && item.UserInfo.UserContext.GravatarEmail) ? item.UserInfo.UserContext.GravatarEmail : null;
                            members.push(member);
                        });
                        callback(null, {
                            StatusCode: StatusCodes.Success.OK,
                            data: members
                        });
                    });
                });
            }
            if (memberSearch.hierarchy) {
                return hierarchySearch();
            }
            return regularSearch();
        };

        /**
         * @api {post} /1.0/Members Onboard Members
         * @apiVersion 1.0.0
         * @apiName Onboard Members
         * @apiGroup Members
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberArrayParam
         *
         * @apiUse InvalidMembersInfo
         * @apiUse RateLimitExceeded
         * @apiUse UnknownError
         *
         * @apiSuccess {String} BatchId
         * @apiSuccess {String} AuditId
         */
        this.post = function (context, callback) {
            if (context.body.length > RATE_LIMIT) {
                return callback(MemberErrors.RateLimitExceed);
            }
            var onboardInternalService = new InternalServiceCache.Onboard(context.correlationId);
            membersValidation({ data: context.body, operation: operationType.Onboard }, function (error, data) {
                if (error) {
                    return callback(error, data);
                }
                onboardInternalService.CreateAPIBatchRecord({
                    correlationId: context.correlationId,
                    UserId: config.APIGlobalUserId,
                    MemberId: config.APIGlobalUserId,
                    FullName: context.clientname,
                    GroupId: context.groupid,
                    Members: mapTOBulkSchema({data: context.body}),
                    Type: ProvisionEnums.Type.APIOnboard
                }, function (error, result) {
                    if (error) {
                        return callback(DefaultErrors.UnknownError);
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: result
                    });
                });
            });
        };

        /**
         * @api {put} /1.0/Members Update Members
         * @apiVersion 1.0.0
         * @apiName Update Members
         * @apiGroup Members
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberArrayParam
         *
         * @apiUse InvalidMembersInfo
         * @apiUse RateLimitExceeded
         * @apiUse UnknownError
         *
         * @apiSuccess {String} BatchId
         * @apiSuccess {String} AuditId
         */
        this.put = function (context, callback) {
            if (context.body.length > RATE_LIMIT) {
                return callback(MemberErrors.RateLimitExceed);
            }
            var onboardInternalService = new InternalServiceCache.Onboard(context.correlationId);
            membersValidation({ data: context.body, operation: operationType.Update }, function (error, data) {
                if (error) {
                    return callback(error, data);
                }
                onboardInternalService.CreateAPIBatchRecord({
                    correlationId: context.correlationId,
                    UserId: config.APIGlobalUserId,
                    MemberId: config.APIGlobalUserId,
                    FullName: context.clientname,
                    GroupId: context.groupid,
                    Members: mapTOBulkSchema({data: context.body}),
                    Type: ProvisionEnums.Type.APIUpdate
                }, function (error, result) {
                    if (error) {
                        return callback(DefaultErrors.UnknownError);
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: result
                    });
                });
            });
        };

        /**
         * @api {delete} /1.0/Members Offboard Members
         * @apiVersion 1.0.0
         * @apiName Offboard Members
         * @apiGroup Members
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberIdsParam
         *
         * @apiUse InvalidMembersInfo
         * @apiUse InvalidMemberId
         * @apiUse RateLimitExceeded
         * @apiUse UnknownError
         *
         * @apiSuccess {String} BatchId
         * @apiSuccess {String} AuditId
         */
        this.delete = function (context, callback) {
            if (context.body.length > RATE_LIMIT) {
                return callback(MemberErrors.RateLimitExceed);
            }
            var onboardInternalService = new InternalServiceCache.Onboard(context.correlationId),
                validationErrors = {},
                memberOffboards = [];
            async.each(context.body, function (item, callback) {
                var memberOffboard = new MemberOffBoard(item),
                    memberErrorArray = [];
                memberOffboard.validate(function (error) {
                    if (memberOffboard.MemberId && !validator.isUUID(memberOffboard.MemberId)) {
                        memberErrorArray.push(MemberErrors.InvalidMemberId.Description);
                    }
                    var i,
                        len,
                        keys;
                    if (error && error.errors) {
                        keys = Object.keys(error.errors);
                        for (i = 0, len = keys.length; i < len; i += 1) {
                            memberErrorArray.push(error.errors[keys[i]].message);
                        }
                    }
                    if (memberErrorArray.length) {
                        validationErrors[memberOffboard.UserName] = memberErrorArray;
                    }
                    memberOffboards.push(memberOffboard);
                    callback();
                });
            }, function () {
                if (Object.keys(validationErrors).length) {
                    return callback(MemberErrors.InvalidMembersInfo, validationErrors);
                }
                onboardInternalService.CreateAPIBatchRecord({
                    correlationId: context.correlationId,
                    UserId: config.APIGlobalUserId,
                    MemberId: config.APIGlobalUserId,
                    FullName: context.clientname,
                    GroupId: context.groupid,
                    Members: memberOffboards,
                    Type: ProvisionEnums.Type.APIOffboard
                }, function (error, result) {
                    if (error) {
                        return callback(DefaultErrors.UnknownError);
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: result
                    });
                });
            });
        };
        /**
         * @api {post} /1.0/Members/resendWelcomeEmail Resend welcome emails
         * @apiVersion 1.0.0
         * @apiName ResendWelcomeEmail To Members
         * @apiGroup Members
         *
         * @apiUse MemberIdsParam
         *
         * @apiUse MissingMemberId
         * @apiUse InvalidMemberId
         * @apiUse RateLimitExceeded
         * @apiUse InvalidMembersInfo
         * @apiUse UnknownError
         *
         * @apiSuccess {String} BatchId
         * @apiSuccess {String} AuditId
         */
        this.resendWelcomeEmail = function (context, callback) {
            if (context.body.length > RATE_LIMIT) {
                return callback(MemberErrors.RateLimitExceed);
            }
            var onboardInternalService = new InternalServiceCache.Onboard(context.correlationId),
                validationErrors = {},
                Members = context.body.filter(function (item) {
                    return item && item.MemberId;
                });
            Members.forEach(function (item) {
                if (!validator.isUUID(item.MemberId)) {
                    validationErrors[item.MemberId] = [MemberErrors.InvalidMemberId.Description];
                }
            });
            if (Object.keys(validationErrors).length) {
                return callback(MemberErrors.InvalidMembersInfo, validationErrors);
            }
            onboardInternalService.CreateAPIBatchRecord({
                correlationId: context.correlationId,
                UserId: config.APIGlobalUserId,
                MemberId: config.APIGlobalUserId,
                FullName: context.clientname,
                GroupId: context.groupid,
                Members: Members,
                Type: ProvisionEnums.Type.APISendWelcomeEmail
            }, function (error, result) {
                if (error) {
                    return callback(DefaultErrors.UnknownError);
                }
                callback(null, {
                    StatusCode: StatusCodes.Success.OK,
                    data: result
                });
            });
        };
    };
module.exports = MembersService;