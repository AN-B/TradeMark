'use strict';
var StatusCodes = require('../../../enums/HttpResponseCodes');

module.exports = {
    /**
     * @apiDefine InvalidTransferManagerInfo
     * @apiError (Error 4xx) InvalidTransferManagerInfo The information provided did not pass validation. More information will be in the 'details' property
     */
    InvalidTransferManagerInfo: {
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Transfer Manager information provided is not valid'
    },
    /**
     * @apiDefine OldManagerNotFound
     * @apiError (Error 4xx) OldManagerNotFound Old Manager was not found in the system
     */
    OldManagerNotFound: {
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'Old Manager was not found in the system'
    },
    /**
     * @apiDefine NewManagerNotFound
     * @apiError (Error 4xx) NewManagerNotFound New Manager was not found in the system
     */
    NewManagerNotFound: {
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'New Manager was not found in the system'
    },
    /**
     * @apiDefine NewManagerInvalidStatus
     * @apiError (Error 4xx) NewManagerInvalidStatus New Manager status is not Active in the system
     */
    NewManagerInvalidStatus: {
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'New Manager status is not Active in the system'
    },
    /**
     * @apiDefine OldManagerInvalidStatus
     * @apiError (Error 4xx) OldManagerInvalidStatus Old Manager status is not Active in the system
     */
    OldManagerInvalidStatus: {
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'Old Manager status is not Active in the system'
    },
    /**
     * @apiDefine SameOldAndNewManagerId
     * @apiError (Error 4xx) SameOldAndNewManagerId OldManagerId and NewManagerId values are same.
     */
    SameOldAndNewManagerId: {
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'OldManagerId and NewManagerId values are same'
    },
    /**
     * @apiDefine ManagerWithoutDirectReports
     * @apiError (Error 4xx) ManagerWithoutDirectReports No direct reports found for the selected manager.
     */
    ManagerWithoutDirectReports: {
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'No direct reports found for the selected manager'
    },
    /**
     * @apiDefine MemberIdsPassedInDontMatchManagerDirectReports
     * @apiError (Error 4xx) The member Id's passed in don't match the old manager's direct reports.
     */
    MemberIdsPassedInDontMatchManagerDirectReports: {
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'The member Id\'s passed in don\'t match the old manager\'s direct reports'
    }
};