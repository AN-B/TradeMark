'use strict';
var StatusCodes = require('../../../enums/HttpResponseCodes');

module.exports = {
    MemberNotFound: {
        Name: 'MemberNotFound',
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'Member Id is not found in the system'
    }
};