'use strict';
var StatusCodes = require('../../../enums/HttpResponseCodes');

module.exports = {
    /**
     * @apiDefine InvalidEventType
     * @apiError (Error 4xx) InvalidEventType Invalid Event Type.
     */
    InvalidEventType: {
        Name: 'InvalidEventType',
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'Invalid EventType.'
    },
    /**
     * @apiDefine InvalidRulesEnginePayload
     * @apiError (Error 4xx) InvalidRulesEnginePayload Amount and UserEmail expected in payload.
     */
    InvalidRulesEnginePayload: {
        Name: 'InvalidPayload',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Amount and UserEmail expected in payload.'
    },
    /**
     * @apiDefine InvalidRulesEngineAmount
     * @apiError (Error 4xx) InvalidRulesEngineAmount Amount must be numeric value.
     */
    InvalidRulesEngineAmount: {
        Name: 'InvalidRulesEngineAmount',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Amount must be numeric value.'
    }
};