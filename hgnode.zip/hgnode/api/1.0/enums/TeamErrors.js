'use strict';
var StatusCodes = require('../../../enums/HttpResponseCodes');

module.exports = {
    /**
     * @apiDefine DepartmentNotFound
     * @apiError (Error 4xx) DepartmentNotFound Department Id is not found in the system
     */
    DepartmentNotFound: {
        Name: 'DepartmentNotFound',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Department Id is not found in the system'
    },
    /**
     * @apiDefine LocationNotFound
     * @apiError (Error 4xx) LocationNotFound Location Id is not found in the system
     */
    LocationNotFound: {
        Name: 'LocationNotFound',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Location Id is not found in the system'
    },
    /**
     * @apiDefine RateLimitExceeded
     * @apiError (Error 4xx) RateLimitExceeded The maximum limit is 100 records
     */
    RateLimitExceed: {
        Name: 'RateLimitExceed',
        StatusCode: StatusCodes.ClientError.EnhanceYourCalm,
        Description: 'Rate limit exceed. Permitted maximum limit is 100 records'
    },
    /**
     * @apiDefine MissingLocationId
     * @apiError (Error 4xx) MissingLocationId Location Id is not provided
     */
    MissingLocationId: {
        Name: 'MissingLocationId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Location Id is not provided'
    },
    /**
     * @apiDefine MissingLocationName
     * @apiError (Error 4xx) MissingLocationName Location Name is not provided
     */
    MissingLocationName: {
        Name: 'MissingLocationName',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Location Name is not provided'
    },
    /**
     * @apiDefine MissingRequiredLocationInfo
     * @apiError (Error 4xx) MissingRequiredLocationInfo The information provided did not pass validation. More information will be in the 'details' property
     */
    MissingRequiredLocationInfo: {
        Name: 'MissingRequiredLocationInfo',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Missing required location information'
    },
    /**
     * @apiDefine DuplicateLocationCode
     * @apiError (Error 4xx) Duplicate Location name or code. More information will be in the 'details' property
     */
    DuplicateLocationCode: {
        Name: 'DuplicateLocationCode',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Duplicate Location name or code'
    },
    /**
     * @apiDefine InvalidTimeZone
     * @apiError (Error 4xx) InvalidTimeZone An Invalid TimeZone was provided
     */
    InvalidTimeZone: {
        Name: 'InvalidTimeZone',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Invalid TimeZone'
    },
    /**
     * @apiDefine CountryNotFound
     * @apiError (Error 4xx) CountryNotFound Country is not found in the system
     */
    CountryNotFound: {
        Name: 'CountryNotFound',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Country is not found in the system'
    }
};