'use strict';
var StatusCodes = require('../../../enums/HttpResponseCodes');

module.exports = {
    /**
     * @apiDefine MissingMemberId
     * @apiError (Error 4xx) MissingMemberId Member Id is not provided
     */
    MissingMemberId: {
        Name: 'MissingMemberId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Member Id is not provided'
    },
    /**
     * @apiDefine InvalidMemberId
     * @apiError (Error 4xx) InvalidMemberId An invalid Member Id was provided
     */
    InvalidMemberId: {
        Name: 'InvalidMemberId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Member Id provided is not valid'
    },
    /**
     * @apiDefine MemberNotFound
     * @apiError (Error 4xx) MemberNotFound Member was not found in the system
     */
    MemberNotFound: {
        Name: 'MemberNotFound',
        StatusCode: StatusCodes.ClientError.NotFound,
        Description: 'Member is not found in the system'
    },
    /**
     * @apiDefine DuplicateMemberId
     * @apiError (Error 4xx) DuplicateMemberId The Member Id already exists in the system
     */
    DuplicateMemberId: {
        Name: 'DuplicateMemberId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Member Id already exist in the system'
    },
    /**
     * @apiDefine RateLimitExceeded
     * @apiError (Error 4xx) RateLimitExceeded The maximum limit is 100 records
     */
    RateLimitExceed: {
        Name: 'RateLimitExceed',
        StatusCode: StatusCodes.ClientError.EnhanceYourCalm,
        Description: 'Rate limit exceed. Permitted maximum limit is 100 records'
    },
    /**
     * @apiDefine InvalidMembersInfo
     * @apiError (Error 4xx) InvalidMembersInfo The information provided did not pass validation. More information will be in the 'details' property
     */
    InvalidMembersInfo: {
        Name: 'InvalidMembersInfo',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Members information provided is not valid'
    },
    /**
     * @apiDefine InvalidSearchCriteria
     * @apiError (Error 4xx) InvalidSearchCriteria The information provided did not pass validation. More information will be in the 'details' property
     */
    InvalidSearchCriteria: {
        Name: 'InvalidSearchCriteria',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Search information provided is not valid'
    },
    /**
     * @apiDefine InvalidMemberStatus
     * @apiError (Error 4xx) InvalidMemberStatus An unknown error occurred
     */
    InvalidMemberStatus: {
        Name: 'InvalidMemberStatus',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Member staus is not valid'
    },
    /**
     * @apiDefine InvalidMemberName
     * @apiError (Error 4xx) InvalidMemberName An unknown error occurred
     */
    InvalidMemberName: {
        Name: 'InvalidMemberName',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Member name contains invalid chars'
    },
    /**
     * @apiDefine DuplicateEmployeeId
     * @apiError (Error 4xx) DuplicateEmployeeId EmployeeId is already in use
     */
    DuplicateEmployeeId: {
        Name: 'InvalidEmployeeId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'EmployeeId is already in use'
    },
    /**
     * @apiDefine DuplicateManagerMemberId
     * @apiError (Error 4xx) DuplicateManagerMemberId MemberIds is duplicated
     */
    DuplicateManagerMemberId: {
        Name: 'DuplicateManagerMemberId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Duplicate Manager MemberIds found'
    },
     /**
     * @apiDefine DuplicateManagerEmployeeId
     * @apiError (Error 4xx) DuplicateManagerEmployeeId EmployeeIds is duplicated
     */
    DuplicateManagerEmployeeId: {
        Name: 'DuplicateManagerEmployeeId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Duplicate Manager EmployeeIds found'
    },
     /**
     * @apiDefine InvalidManagerMemberId
     * @apiError (Error 4xx) InvalidManagerMemberId Manager MemberId is not valid
     */
    InvalidManagerMemberId: {
        Name: 'InvalidManagerMemberId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Manager MemberId is not valid'
    },
    /**
     * @apiDefine InvalidManagerEmployeeId
     * @apiError (Error 4xx) InvalidManagerEmployeeId Manager MemberId is not valid
     */
    InvalidManagerEmployeeId: {
        Name: 'InvalidManagerEmployeeId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Manager EmployeeId is not valid'
    },
    /**
     * @apiDefine ManagerWithMemberIdIsNotActive
     * @apiError (Error 4xx) ManagerWithMemberIdIsNotActive Manager with MemberId is not active
     */
    ManagerWithMemberIdIsNotActive: {
        Name: 'ManagerWithMemberIdIsNotActive',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Manager with MemberId is not active'
    },
    /**
     * @apiDefine ManagerWithEmployeeIdIsNotActive
     * @apiError (Error 4xx) ManagerWithEmployeeIdIsNotActive Manager with EmployeeId is not active
     */
    ManagerWithEmployeeIdIsNotActive: {
        Name: 'ManagerWithEmployeeIdIsNotActive',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Manager with EmployeeId is not active'
    },
    /**
     * @apiDefine ManagerMemberIdDoesNotMatchEmployeeId
     * @apiError (Error 4xx) ManagerMemberIdDoesNotMatchEmployeeId Manager EmployeeId does not match Manager EmployeeId in the System
     */
    ManagerMemberIdDoesNotMatchEmployeeId: {
        Name: 'ManagerMemberIdDoesNotMatchEmployeeId',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Manager EmployeeId does not match Manager EmployeeId in the System'
    }
};