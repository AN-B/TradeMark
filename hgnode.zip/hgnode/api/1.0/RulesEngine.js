/*jslint node:true es5:true*/
'use strict';
var httpResponseCodes = require('../../enums/HttpResponseCodes.js'),
    DefaultErrors = require('../DefaultErrors'),
    RulesEngineErrors = require('./enums/RulesEngineErrors.js'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    cfg = require('../../configurations/config'),
    RulesEngineService = function () {
        /**
         * @api {get} /1.0/RulesEngine Get RulesEngine EventType names
         * @apiVersion 1.0.0
         * @apiName GetRulesEngineEventTypes
         * @apiGroup RulesEngine
         * @apiDescription Retrieve the list of EventTypes for a given client
         *
         * @apiUse AccessHeader
         *
         * @apiUse UnknownError
         *
         * @apiSuccess {Object[]} body.RulesEngineEventType              An array of RulesEngine EventTypes
         *
         * @apiUse GETRulesEngineExample
         */
        this.get = function (context, callback) {
            var groupInternalService = new InternalServiceCache.Group(context.correlationId);
            groupInternalService.GetRulesEngineEventTypeNames({
                GroupId: context.groupid
            }, function (error, data) {
                if (error) {
                    return callback(DefaultErrors.UnknownError);
                }
                callback(null, {
                    StatusCode: httpResponseCodes.Success.OK,
                    data: {
                        RulesEngineEventType: data
                    }
                });
            });
        };

        /**
         * @api {post} /1.0/RulesEngine/create/:EventType Create a RulesEngine event
         * @apiVersion 1.0.0
         * @apiName CreateRulesEngineEvent
         * @apiGroup RulesEngine
         * @apiDescription Creates a RuleEngine Event
         *
         * @apiUse AccessHeader
         *
         * @apiUse UnknownError
         * @apiUse InvalidEventType
         * @apiUse InvalidRulesEnginePayload
         * @apiUse InvalidRulesEngineAmount
         *
         * @apiSuccess {String} body.Result              Success message
         *
         * @apiUse POST_RulesEngineExample
         */
        this.post = function (context, callback) {
            var groupInternalService = new InternalServiceCache.Group(context.correlationId),
                eventBusInternalService = new InternalServiceCache.EventBus(context.correlationId);
            groupInternalService.GetRulesEngineEventTypeNames({
                GroupId: context.groupid
            }, function (error, data) {
                if (error) {
                    return callback(DefaultErrors.UnknownError);
                }
                if (data.indexOf(context.eventtype) === -1) {
                    return callback(RulesEngineErrors.InvalidEventType);
                }
                if (!context.body.Amount || !context.body.UserEmail) {
                    return callback(RulesEngineErrors.InvalidRulesEnginePayload);
                }
                if (isNaN(parseInt(context.body.Amount, 10))) {
                    return callback(RulesEngineErrors.InvalidRulesEngineAmount);
                }
                eventBusInternalService.CreateEvent({
                    EventType: context.eventtype,
                    UserId: cfg.APIGlobalUserId,
                    GroupId: context.groupid,
                    Payload: {
                        CreatedBy: cfg.APIGlobalUserId,
                        Amount: context.body.Amount,
                        UserEmail: context.body.UserEmail
                    }
                });
                callback(null, {
                    StatusCode: httpResponseCodes.Success.Created,
                    data: {
                        Result: 'Success.'
                    }
                });
            });
        };
    };

module.exports = RulesEngineService;