/*jslint node:true es5:true*/
'use strict';
var StatusCodes = require('../../enums/HttpResponseCodes.js'),
    MemberErrors = require('./enums/MemberErrors.js'),
    TeamErrors = require('./enums/TeamErrors.js'),
    DefaultErrors = require('../DefaultErrors'),
    validator = require('mongoose-validator').validatorjs,
    DTOUtil = require('../../util/DTOUtil.js'),
    paramsUtil = require('../../util/params.js'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    config = require('../../configurations/config.js'),
    Member = require('./datacontract/Member.js').Member,
    MapToDTO = require('./datacontract/Member.js').DTOMapper,
    MapToDB = require('./datacontract/Member.js').DBMapper,
    MemberReinstate = require('./datacontract/MemberReinstate.js').MemberReinstate,
    HgLog = require('../../framework/HgLog.js'),
    TeamEnums = require('../../enums/TeamEnums.js'),
    MemberOffBoard = require('./datacontract/MemberOffBoard.js').MemberOffBoard,
    ArrayUtil = require('../../util/arrayUtil'),
    i18nHelper = require('../../helpers/i18nHelper'),
    MemberService = function () {
        /**
         * @apiDefine MemberIdUrlParam
         * @apiParam (URL) {String} id Member's unique ID
         */

        function validateId(id, callback) {
            if (!id) {
                return callback(MemberErrors.MissingMemberId);
            }
            if (!validator.isUUID(id)) {
                return callback(MemberErrors.InvalidMemberId);
            }
            callback();
        }

        /**
         * @api {get} /1.0/Member/:id Get Member
         * @apiVersion 1.0.0
         * @apiName GetMember
         * @apiGroup Member
         * @apiDescription Retrieve a Member by their unique ID
         *
         * @apiUse AccessHeader
         * @apiUse MemberIdUrlParam
         *
         * @apiUse MissingMemberId
         * @apiUse InvalidMemberId
         * @apiUse MemberNotFound
         * @apiUse UnknownError
         *
         * @apiUse MemberSuccessDTO
         *
         * @apiUse GET_MemberExample
         */
        this.getid = function (context, callback) {
            validateId(context.id, function (error) {
                if (error) {
                    return callback(error);
                }
                var memberInternalService = new InternalServiceCache.Member(context.correlationId);
                memberInternalService.GetCompleteMemberRecord({
                    correlationId: context.correlationId,
                    GroupId: context.GroupId,
                    MemberId: context.id
                }, function (error, data) {
                    if (error) {
                        HgLog.error(error);
                        if (error === 'services.int.mem.mnf') {
                            return callback(MemberErrors.MemberNotFound);
                        }
                        return callback(DefaultErrors.UnknownError);
                    }
                    var member = new Member(new MapToDTO(data.Member));
                    if (data.UserInfo) {
                        member.Email = (data.UserInfo.UserPersonal && data.UserInfo.UserPersonal.PrimaryEmail) ? data.UserInfo.UserPersonal.PrimaryEmail : '';
                        member.UserName = data.UserInfo.UserName || '';
                        member.HomeZip = (data.UserInfo.Preference && data.UserInfo.Preference.HomeZip) ? data.UserInfo.Preference.HomeZip : '';
                        member.WorkZip = (data.UserInfo.Preference && data.UserInfo.Preference.WorkZip) ? data.UserInfo.Preference.WorkZip : '';
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: member
                    });
                });
            });
        };

        /**
         * @api {put} /1.0/Member/:id Update Member
         * @apiVersion 1.0.0
         * @apiName UpdateMember
         * @apiGroup Member
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberIdUrlParam
         * @apiUse MemberParamDTO
         *
         * @apiUse MissingMemberId
         * @apiUse InvalidMemberId
         * @apiUse InvalidMembersInfo
         * @apiUse MemberNotFound
         * @apiUse DepartmentNotFound
         * @apiUse LocationNotFound  
         * @apiUse UnknownError
         * @apiUse DuplicateEmployeeId
         * @apiUse DuplicateManagerMemberId
         * @apiUse DuplicateManagerEmployeeId
         * @apiUse InvalidManagerMemberId
         * @apiUse InvalidManagerEmployeeId
         * @apiUse ManagerWithMemberIdIsNotActive
         * @apiUse ManagerWithEmployeeIdIsNotActive
         * @apiUse ManagerMemberIdDoesNotMatchEmployeeId
         * @apiUse MemberSuccessDTO
         *
         * @apiUse PUT_MemberExample
         */
        this.putid = function (context, callback) {
            validateId(context.id, function (error) {
                if (error) {
                    return callback(error);
                }
                var memberUpdate = new Member(context.body),
                    memberInternalService = new InternalServiceCache.Member(context.correlationId);
                memberUpdate.validate(function (validationErrors) {
                    if (validationErrors) {
                        return callback(MemberErrors.InvalidMembersInfo, validationErrors);
                    }
                    memberInternalService.GetCompleteMemberRecord({
                        correlationId: context.correlationId,
                        MemberId: context.id
                    }, function (error, dbMember) {
                        if (error) {
                            if (error === 'services.int.mem.mnf') {
                                return callback(MemberErrors.MemberNotFound);
                            }
                            return callback(DefaultErrors.UnknownError);
                        }
                        memberInternalService.UpdateMemberAPI({
                            correlationId: context.correlationId,
                            UserId: config.APIGlobalUserId,
                            GroupId: context.groupid,
                            Member: {
                                hgId: dbMember.Member.hgId,
                                FirstName: memberUpdate.FirstName || dbMember.Member.FirstName,
                                FullName: memberUpdate.FullName || dbMember.Member.FullName,
                                LastName: memberUpdate.LastName || dbMember.Member.LastName,
                                Position: memberUpdate.Position || dbMember.Member.Position,
                                StartingDate: memberUpdate.StartingDate || dbMember.Member.StartingDate,
                                Birthdate: memberUpdate.Birthdate || dbMember.Member.Birthdate,
                                EndingDate: memberUpdate.EndingDate || dbMember.Member.EndingDate,
                                // The member api data contract expects Role as a string
                                // however it must be stored in the database as an array string
                                RolesInGroup: memberUpdate.Role ? [memberUpdate.Role] :  dbMember.Member.Role,
                                GravatarEmail: memberUpdate.GravatarEmail || dbMember.Member.GravatarEmail,
                                MyManagers: memberUpdate.MyManagers || [],
                                Managers: memberUpdate.MyManagers || [],
                                UserName: memberUpdate.UserName || dbMember.UserInfo.UserName,
                                HomeZip: memberUpdate.HomeZip || ((dbMember.UserInfo.Preference && dbMember.UserInfo.Preference.HomeZip) ? dbMember.UserInfo.Preference.HomeZip : ''),
                                WorkZip: memberUpdate.WorkZip || ((dbMember.UserInfo.Preference && dbMember.UserInfo.Preference.WorkZip) ? dbMember.UserInfo.Preference.WorkZip : ''),
                                EmployeeId: memberUpdate.EmployeeId || dbMember.Member.EmployeeId,
                                ModifiedBy: config.APIGlobalUserId,
                                DepartmentId: memberUpdate.GroupDepartment.DepartmentId,
                                DepartmentName: memberUpdate.GroupDepartment.Name,
                                LocationId: memberUpdate.Location.LocationId,
                                LocationName: memberUpdate.Location.Name,
                                UserId: dbMember.UserInfo.hgId,
                                GroupId: dbMember.Member.GroupId
                            }
                        }, function (error, data) {
                            if (error || !data) {
                                HgLog.error(error);
                                if (error === TeamEnums.APITeamErrorCode.DepartmentIdNotFound) {
                                    return callback(TeamErrors.DepartmentNotFound);
                                }
                                if (error === TeamEnums.APITeamErrorCode.LocationIdNotFound) {
                                    return callback(TeamErrors.LocationNotFound);
                                }
                                if (error === MemberErrors.DuplicateManagerMemberId.Name) {
                                    return callback(MemberErrors.DuplicateManagerMemberId);
                                }
                                if (error === MemberErrors.DuplicateManagerEmployeeId.Name) {
                                    return callback(MemberErrors.DuplicateManagerEmployeeId);
                                }
                                if (error === MemberErrors.InvalidManagerMemberId.Name) {
                                    return callback(MemberErrors.InvalidManagerMemberId);
                                }
                                if (error === MemberErrors.InvalidManagerEmployeeId.Name) {
                                    return callback(MemberErrors.InvalidManagerEmployeeId);
                                }
                                if (error === MemberErrors.ManagerWithMemberIdIsNotActive.Name) {
                                    return callback(MemberErrors.ManagerWithMemberIdIsNotActive);
                                }
                                if (error === MemberErrors.ManagerWithEmployeeIdIsNotActive.Name) {
                                    return callback(MemberErrors.ManagerWithEmployeeIdIsNotActive);
                                }
                                if (error === MemberErrors.ManagerMemberIdDoesNotMatchEmployeeId.Name) {
                                    return callback(MemberErrors.ManagerMemberIdDoesNotMatchEmployeeId);
                                }
                                if (error === "server.hge.mem.meidiu") {
                                    if (data && data.message) {
                                        MemberErrors.DuplicateEmployeeId.Description = data.message;
                                    }
                                    return callback(MemberErrors.DuplicateEmployeeId);
                                }
                                return callback(DefaultErrors.UnknownError);
                            }
                            var member = new Member(new MapToDTO(data.Member));
                            if (data.UserInfo) {
                                member.Email = (data.UserInfo.UserPersonal && data.UserInfo.UserPersonal.PrimaryEmail) ? data.UserInfo.UserPersonal.PrimaryEmail : '';
                                member.UserName = data.UserInfo.UserName || '';
                                member.HomeZip = (data.UserInfo.Preference && data.UserInfo.Preference.HomeZip) ? data.UserInfo.Preference.HomeZip : '';
                                member.WorkZip = (data.UserInfo.Preference && data.UserInfo.Preference.WorkZip) ? data.UserInfo.Preference.WorkZip : '';
                            }
                            callback(null, {
                                StatusCode: StatusCodes.Success.OK,
                                data: member
                            });
                        });
                    });
                });
            });
        };

        /**
         * @api {delete} /1.0/Member/:id Offboard Member
         * @apiVersion 1.0.0
         * @apiName Offboard Member
         * @apiGroup Member
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberOffBoardParamDTO
         *
         * @apiUse MissingMemberId
         * @apiUse InvalidMemberId
         * @apiUse MemberNotFound
         * @apiUse InvalidMembersInfo
         * @apiUse UnknownError
         *
         * @apiUse DELETE_MemberExample
         *
         * @apiSuccess {String} message Message confirming the Member was offboarded
         * @apiSuccessExample {json} Example Successful Response:
         *  {
         *      "message": "Member has been successfully offboarded."
         *  }
         */
        this.deleteid = function (context, callback) {
            validateId(context.id, function (error) {
                if (error) {
                    return callback(error);
                }
                var memberOffBoard = new MemberOffBoard(context.body),
                    memberInternalService = new InternalServiceCache.Member(context.correlationId);
                memberOffBoard.validate(function (validationErrors) {
                    if (validationErrors) {
                        return callback(MemberErrors.InvalidMembersInfo, validationErrors);
                    }
                    memberInternalService.OffBoardMemberUI_Internal({
                        correlationId: context.correlationId,
                        GroupId: context.groupid,
                        MemberId: context.id,
                        UserId: config.APIGlobalUserId,
                        OffBoardMemberId: context.id,
                        OffBoardDate: memberOffBoard.OffBoardDate,
                        OffBoardType: memberOffBoard.OffBoardType,
                        IsEmailChange: !!memberOffBoard.NotificationEmail,
                        NotificationEmailAddress: memberOffBoard.NotificationEmail,
                        Lang: context.groupid + '/en'
                    }, function (error) {
                        if (error) {
                            HgLog.error(error);
                            if (error === 'services.int.mem.mnf') {
                                return callback(MemberErrors.MemberNotFound);
                            }
                            return callback(DefaultErrors.UnknownError);
                        }
                        callback(null, {
                            StatusCode: StatusCodes.Success.OK,
                            data: {message: 'Member has been successfully offboarded.'}
                        });
                    });
                });
            });
        };
        /**
         * @api {post} /1.0/Member Onboard Member
         * @apiVersion 1.0.0
         * @apiName Onboard Member
         * @apiGroup Member
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberParamDTO
         *
         * @apiUse InvalidMembersInfo
         * @apiUse DepartmentNotFound
         * @apiUse LocationNotFound
         * @apiUse DuplicateEmployeeId
         * @apiUse DuplicateManagerMemberId
         * @apiUse DuplicateManagerEmployeeId
         * @apiUse InvalidManagerMemberId
         * @apiUse InvalidManagerEmployeeId
         * @apiUse ManagerWithMemberIdIsNotActive
         * @apiUse ManagerWithEmployeeIdIsNotActive
         * @apiUse ManagerMemberIdDoesNotMatchEmployeeId
         * @apiUse UnknownError
         *
         * @apiUse POST_MemberExample
         *
         * @apiUse MemberSuccessDTO
         */
        this.post = function (context, callback) {
            var member = new Member(context.body),
                memberInternalService = new InternalServiceCache.Member(context.correlationId);
            member.validate(function (validationErrors) {
                if (validationErrors) {
                    return callback(MemberErrors.InvalidMembersInfo, validationErrors);
                }
                var dbMember = new MapToDB(member);
                dbMember.CreatedBy = config.APIGlobalUserId;
                dbMember.CreatedDate = Date.now();
                dbMember.ModifiedBy = config.APIGlobalUserId;
                dbMember.ModifiedDate = Date.now();
                dbMember.DepartmentId =  member.GroupDepartment.DepartmentId;
                dbMember.DepartmentName =  member.GroupDepartment.Name;
                dbMember.LocationId = member.Location.LocationId;
                dbMember.LocationName =  member.Location.Name;
                dbMember.Managers = member.MyManagers || [];
                memberInternalService.OnboardMemberAPI({
                    correlationId: context.correlationId,
                    UserId: config.APIGlobalUserId,
                    GroupId: context.groupid,
                    Member: dbMember
                }, function (error, result) {
                    if (error) {
                        HgLog.error(error);
                        if (error === TeamEnums.APITeamErrorCode.DepartmentIdNotFound) {
                            return callback(TeamErrors.DepartmentNotFound);
                        }
                        if (error === TeamEnums.APITeamErrorCode.LocationIdNotFound) {
                            return callback(TeamErrors.LocationNotFound);
                        }
                        if (error === MemberErrors.DuplicateManagerMemberId.Name) {
                            return callback(MemberErrors.DuplicateManagerMemberId);
                        }
                        if (error === MemberErrors.DuplicateManagerEmployeeId.Name) {
                            return callback(MemberErrors.DuplicateManagerEmployeeId);
                        }
                        if (error === MemberErrors.InvalidManagerMemberId.Name) {
                            return callback(MemberErrors.InvalidManagerMemberId);
                        }
                        if (error === MemberErrors.InvalidManagerEmployeeId.Name) {
                            return callback(MemberErrors.InvalidManagerEmployeeId);
                        }
                        if (error === MemberErrors.ManagerWithMemberIdIsNotActive.Name) {
                            return callback(MemberErrors.ManagerWithMemberIdIsNotActive);
                        }
                        if (error === MemberErrors.ManagerWithEmployeeIdIsNotActive.Name) {
                            return callback(MemberErrors.ManagerWithEmployeeIdIsNotActive);
                        }
                        if (error === MemberErrors.ManagerMemberIdDoesNotMatchEmployeeId.Name) {
                            return callback(MemberErrors.ManagerMemberIdDoesNotMatchEmployeeId);
                        }
                        if (error.indexOf("services.int.mem.mau") > -1) {
                            error = JSON.parse(error);
                            if (Array.isArray(error) && error.length === 2) {
                                MemberErrors.DuplicateEmployeeId.Description = i18nHelper.translate('en', 'services.int.mem.mau', error[1]);
                                return callback(MemberErrors.DuplicateEmployeeId);
                            }
                        }
                        return callback(DefaultErrors.UnknownError);
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: DTOUtil.CreateResponse(new MapToDTO(result), 'Object', Member)
                    });
                });
            });
        };
        /**
         * @api {post} /1.0/Member/resendWelcomeEmail/:id Resend welcome email
         * @apiVersion 1.0.0
         * @apiName Resend Welcome Email
         * @apiGroup Member
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberIdUrlParam
         *
         * @apiUse MissingMemberId
         * @apiUse InvalidMemberId
         * @apiUse MemberNotFound
         * @apiUse UnknownError
         *
         * @apiUse ResendWelcomeEmail_MemberExample
         *
         * @apiSuccess {String} message Message confirming the Member's welcome email was sent
         * @apiSuccessExample {json} Example Successful Response:
         *  {
         *      "message": "Member welcome email has been sent."
         *  }
         */
        this.resendWelcomeEmail = function (context, callback) {
            validateId(context.id, function (error) {
                if (error) {
                    return callback(error);
                }
                var memberInternalService = new InternalServiceCache.Member(context.correlationId);
                memberInternalService.GetMemberByMemberId({
                    MemberId: context.id,
                    GroupId: context.groupid
                }, function (error, data) {
                    if (error) {
                        return callback(DefaultErrors.UnknownError);
                    }
                    if (!data) {
                        return callback(MemberErrors.MemberNotFound);
                    }
                    memberInternalService.ResendWelcomeEmail({
                        correlationId: context.correlationId,
                        MemberId: context.id,
                        GroupId: context.groupid,
                        UserId: config.APIGlobalUserId
                    }, function (error) {
                        if (error) {
                            HgLog.error(error);
                            return callback(DefaultErrors.UnknownError);
                        }
                        callback(null, {
                            StatusCode: StatusCodes.Success.OK,
                            data: {message: 'Member welcome email has been sent.'}
                        });
                    });
                });
            });
        };

        /**
         * @api {post} /1.0/Member/reinstate Reinstate Member
         * @apiVersion 1.0.0
         * @apiName Reinstate Member
         * @apiGroup Member
         *
         * @apiUse AccessHeader
         *
         * @apiUse MemberReinstateParamDTO
         *
         * @apiUse MissingMemberId
         * @apiUse InvalidMemberId
         * @apiUse MemberNotFound
         * @apiUse UnknownError
         *
         * @apiUse Reinstate_MemberExample
         *
         * @apiSuccess {String} message Message confirming the Member was reinstated
         * @apiSuccessExample {json} Example Successful Response:
         *  {
         *      "message": "Member reinstated."
         *  }
         */

        this.reinstate = function (context, callback) {
            var member = new MemberReinstate(context.body),
                memberInternalService = new InternalServiceCache.Member(context.correlationId);
            member.validate(function (validationErrors) {
                if (validationErrors) {
                    return callback(MemberErrors.InvalidMembersInfo, validationErrors);
                }
                memberInternalService.ReinstateMemberAPI({
                    correlationId: context.correlationId,
                    ModifiedBy: config.APIGlobalUserId,
                    GroupId: context.groupid,
                    GroupName: context.clientname,
                    Email: member.Email,
                    MemberId: member.MemberId
                }, function (error) {
                    if (error) {
                        if (error === 'services.int.mem.mnf') {
                            return callback(MemberErrors.MemberNotFound);
                        }
                        return callback(DefaultErrors.UnknownError);
                    }
                    callback(null, {
                        StatusCode: StatusCodes.Success.OK,
                        data: {message: 'Member reinstated.'}
                    });
                });
            });
        };
    };

module.exports = MemberService;