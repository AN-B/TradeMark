'use strict';
var config = require('../../../configurations/config.js');

/**
 * @apiDefine RecognitionSuccessDTO recognition The Recognition object returned
 *
 * @apiSuccess {String} Id                          The Recognition's unique ID
 * @apiSuccess {Object} Giver                       The Giver of the Recognition
 * @apiSuccess {String} Giver.FullName                  The Giver's full name
 * @apiSuccess {String} Giver.Department                The Giver's department
 * @apiSuccess {String} Giver.Position                  The Giver's position
 * @apiSuccess {String} Giver.AvatarPath                The Giver's avatar URL
 * @apiSuccess {String} Giver.Email                     The Giver's email
 * @apiSuccess {Array} Receivers                    An array of the Receivers of a Recognition
 * @apiSuccess {String} Receivers.FullName              The Receiver's full name
 * @apiSuccess {String} Receivers.Department            The Receiver's department
 * @apiSuccess {String} Receivers.Position              The Receiver's position
 * @apiSuccess {String} Receivers.AvatarPath            The Receiver's avatar URL
 * @apiSuccess {String} Receivers.Email                 The Receiver's email
 * @apiSuccess {Object} Recognition                 The Recognition
 * @apiSuccess {String} Recognition.Title               The title of the recognition
 * @apiSuccess {String} Recognition.SubValue            The subvalue of the recognition (optional)
 * @apiSuccess {String} Recognition.SubValueDescription The subvalue description of the recognition (optional)
 * @apiSuccess {String} Recognition.URL                 The URL of the recognition as viewed in HighGround
 * @apiSuccess {String} Recognition.BadgeURL            The URL of the badge image of the recognition
 * @apiSuccess {String} Recognition.Description         The description of the recognition
 * @apiSuccess {String} Recognition.Message             The message of the recognition
 * @apiSuccess {Date} Recognition.CreatedDate           The date the recognition was given (in UTC Unix timestamp format)
 * @apiSuccess {Number} Recognition.NumberOfLikes       The number of likes the recognition has received
 * @apiSuccess {Number} Recognition.NumberOfComments    The number of comments the recognition has received
 * @apiSuccess {Number} Recognition.NumberOfGifts       The number of gifts the recognition has received
 */

function MapToDTO(recognitions, userEmailMapping) {
    if (typeof recognitions.toObject === 'function') {
        recognitions = recognitions.toObject();
    }

    var recognition = recognitions.rows[0],
        DTO = {
            Id: recognition.Id,
            Receivers: []
        },
        getSubValueDescription = function (subValues, value) {
            var data = recognition.SubValues.filter(function (item) {
                return item.Name === value;
            });
            return data.length ? data[0].Description : '';
        };

    if (recognition.GiverUserId) {
        DTO.Giver = {
            FullName: recognition.GiverFullName,
            Department: recognition.GiverDepartment,
            Position: recognition.GiverPosition,
            AvatarPath: [config.protocol, config.s3store.imageStore[config.nextIndex()], '/user/', recognition.GiverUserId, '.jpg'].join(''),
            Email: userEmailMapping[recognition.GiverUserId]
        };
    } else if (recognition.TriggerInfo) {
        DTO.Giver = {
            FullName: recognition.TriggerInfo.GroupName,
            AvatarPath: [config.protocol, config.s3store.imageStore[config.nextIndex()], '/user/', recognition.TriggerInfo.AvatarId, '.jpg'].join('')
        };
    } else {
        DTO.Giver = {
            FullName: recognition.PublicCreatorInfo.FullName,
            Email: recognition.PublicCreatorInfo.Email
        };
    }

    DTO.Recognition = {
        Title: recognition.Title,
        URL: config.protocol + config.baseUrl + '#/Recognize/Iso/' + recognition.Id,
        BadgeUrl: [config.protocol, config.s3store.imageStore[config.nextIndex()], '/badges/group/', recognition.FriendlyGroupId, '/', recognition.TemplateId, '.svg'].join(''),
        Description: recognition.Description,
        Message: recognition.Message,
        CreatedDate: recognition.CreatedDate,
        NumberOfLikes: recognition.NumberOfLikes,
        NumberOfComments: recognition.NumberOfComments,
        NumberOfGifts: recognition.NumberOfGifts,
        SubValue: recognition.SubValue || '',
        SubValueDescription: recognition.SubValues && recognition.SubValues.length ? getSubValueDescription(recognition.SubValues, recognition.SubValue || '') : ''
    };

    recognitions.rows.forEach(function (item) {
        DTO.Receivers.push({
            Email: (item.ReceiverUserId) ? (userEmailMapping[item.ReceiverUserId] || '') : '',
            FullName: item.ReceiverFullName,
            Department: item.ReceiverDepartment,
            Position: item.ReceiverPosition,
            AvatarPath: [config.protocol, config.s3store.imageStore[config.nextIndex()], '/user/', item.ReceiverUserId, '.jpg'].join('')
        });
    });

    return DTO;
}

exports.MapToDTO = MapToDTO;