/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js'),
    EntityEnums = require('../../../enums/EntityEnums.js'),
    customValidators = require('./MemberValidators');

/**
 * @apiDefine MemberOffBoardParamDTO
 *
 * @apiParam (body) {String} [MemberId]                             The Member's unique ID
 * @apiParam (body) {String}  UserName                              The Member's username
 * @apiParam (body) {String} [FirstName]                            The Member's first name
 * @apiParam (body) {String} LastName                               The Member's last name
 * @apiParam (body) {String=Voluntary,InVoluntary} OffBoardType     Pick OffBoardType from available list.
 * @apiParam (body) {Date} OffBoardDate                             The date when member is being OffBoarded
 * @apiParam (body) {String} [NotificationEmail]                    Email address where all future Member's email supposed to be forwarded.
 */

var MemberOffBoardSchema = new DataContractSchema({
    MemberId: {type: String, required: false},
    UserName: {type: String, required: true}, // required see paramsutil.js  (userinfo schema)
    FirstName: {type: String, required: false},
    LastName: {type: String, required: false},
    OffBoardType: {type: String, required: true, enum: Object.keys(EntityEnums.OffBoardType)},
    OffBoardDate: {type: Date, required: true},
    NotificationEmail: {type: String, required: false, validate: customValidators.notificationEmailValidator}
});

exports.MemberOffBoard = mongoose.model('MemberOffBoard', MemberOffBoardSchema);
