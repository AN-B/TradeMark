/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js');

var GRSOrderSchema = new DataContractSchema({
    pin: {type: String},
    employeeId: {type: String},
    shipName: {type: String},
    shipCompany: {type: String},
    shipAddress1: {type: String},
    shipAddress2: {type: String},
    shipCity: {type: String},
    shipProvinceState: {type: String},
    shipCountry: {type: String},
    shipPostal: {type: String},
    shipTelephone: {type: String},
    shipEmail: {type: String},
    businessAddress: {type: String},
    orderNumber: {type: String},
    pointsPurchased: {type: Number},
    pointsPurchasedCost: {type: Number},
    pointsPurchasedCurrency: {type: String},
    orderItems: [{
        lineItemId: {type: String},
        orderId: {type: String},
        orderedAt: {type: Date},
        name: {type: String},
        description: {type: String},
        quantity: {type: Number},
        pointCost: {type: Number}
    }]
});

exports.GRSOrder = mongoose.model('GRSOrder', GRSOrderSchema);