/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js'),
    CountryEnums = require('../../../enums/CountryEnums.js'),
    GRSMemberSchema = new DataContractSchema({
        pin: {type: String},
        employeeid: {type: String},
        firstName: {type: String},
        lastName: {type: String},
        pointBalance: {type: String},
        email: {type: String},
        address1: {type: String},
        address2: {type: String},
        city: {type: String},
        provinceState: {type: String},
        country: {type: String},
        telephone: {type: String, default: ''},
        language: {type: String, default: 'en'}
    }),
    GRSMemberDTO = mongoose.model('GRSMember', GRSMemberSchema),
    MapToDTO = function (data) {
        return new GRSMemberDTO({
            pin: data.GRSMemberId,
            employeeid: data.encryptedHgId,
            firstName: data.member.Member.FirstName,
            lastName: data.member.Member.LastName,
            pointBalance: data.pointBalance,
            email: data.member.UserInfo.UserPersonal.PrimaryEmail,
            address1: data.team.Address.Address1,
            address2: data.team.Address.Address2,
            city: data.team.Address.City,
            provinceState: data.team.Address.State,
            country: CountryEnums.GetByValue(data.team.Address.Country) || 'US',
            telephone: '',  //need to get this from the group
            language: data.Language
        });
    };

module.exports = {
    GRSMember: GRSMemberDTO,
    MapToDTO: MapToDTO
};