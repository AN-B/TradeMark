/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    EntityEnums = require('../../../enums/EntityEnums.js'),
    config = require('../../../configurations/config.js'),
    customValidators = require('./MemberValidators'),
    DataContractSchema = require('../../../common/DataContractSchema.js');

function MapToBulkMemberSchema(data) {
    data = data.toObject();
    data.i18n = data.Language || 'en';

    if (data.Address) {
        data.Address.Country = data.Address.Country || 'US';
    }
    return data;
}

function MapToDB(data) {
    data = data.toObject();
    if (data.LocationId) {
        data.hgId = data.LocationId;
        delete data.LocationId;
    }
    if (data.TimeZone) {
        data.tz = data.TimeZone;
    }
    if (data.Language) {
        data.i18n = data.Language;
    }
    data.Status = EntityEnums.TeamStatus.Active;
    data.Type = EntityEnums.TeamType.Location;
    data.ModifiedBy = config.APIGlobalUserId;
    data.CreatedBy = config.APIGlobalUserId;
    return data;
}

/**
 * @apiDefine LocationSuccessDTO
 *
 * @apiSuccess {String} LocationId          The Location's unique ID
 * @apiSuccess {String} Name                The Location's name
 * @apiSuccess {String} LocationCode        The Location's code
 * @apiSuccess {String} Description         The Location's description
 * @apiSuccess {Object} Address             The Location's address information
 * @apiSuccess {String} Address.Address1        The address's line 1
 * @apiSuccess {String} Address.Address2        The address's line 2
 * @apiSuccess {String} Address.City            The address's city
 * @apiSuccess {String} Address.State           The address's state
 * @apiSuccess {String} Address.Zip             The address's zip
 * @apiSuccess {String} Address.Country         The address's country
 * @apiSuccess {String} TimeZone            The Location's timezone
 * @apiSuccess {String} Phone               The Location's contact phone number
 * @apiSuccess {String} Language            The Location's Language
 */

/**
 * @apiDefine LocationArraySuccessDTO
 *
 * @apiSuccess {Object[]} body                  An array of Locations
 * @apiSuccess {String} [body.LocationId]           The Location's unique ID
 * @apiSuccess {String} body.Name                   The Location's name
 * @apiSuccess {String} body.LocationCode           The Location's code
 * @apiSuccess {String} [body.Description]            The Location's description
 * @apiSuccess {Object} body.Address                The Location's address information
 * @apiSuccess {String} body.Address.Address1           The address's line 1
 * @apiSuccess {String} body.Address.Address2           The address's line 2
 * @apiSuccess {String} body.Address.City               The address's city
 * @apiSuccess {String} body.Address.State              The address's state
 * @apiSuccess {String} body.Address.Zip                The address's zip
 * @apiSuccess {String} body.Address.Country            The address's country
 * @apiSuccess {String} body.TimeZone               The Location's timezone
 * @apiSuccess {String} [body.Phone]                The Location's contact phone number
 * @apiSuccess {String} [body.Language]             The Location's Language
 */
var LocationSchema = new DataContractSchema({
    LocationId: {type: String},
    Name: {type: String, required: true},
    LocationCode: {type: String, required: true},
    Description: {type: String, required: true},
    Address: {
        Address1: {type: String, required: true},
        Address2: {type: String, required: true},
        City: {type: String, required: true},
        State: {type: String, required: true},
        Zip: {type: String, required: true},
        Country: {
            type: String,
            required: true,
            default: 'US',
            validate: [customValidators.countryValidator, 'Invalid Country.']
        }
    },
    Language: {type: String, required: true, default: 'en'},
    TimeZone: {
        type: String,
        required: true,
        validate: [customValidators.timezoneValidator, 'Invalid TimeZone.']
    },
    Phone: {type: String}
});

exports.Location = mongoose.model('Location', LocationSchema);
exports.BulkMapper = MapToBulkMemberSchema;
exports.DBMapper = MapToDB;