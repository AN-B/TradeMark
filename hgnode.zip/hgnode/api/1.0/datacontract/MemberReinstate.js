/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js'),
    customValidators = require('./MemberValidators');

/**
 * @apiDefine MemberReinstateParamDTO
 *
 * @apiParam (body) {String} MemberId    The Member's unique ID
 * @apiParam (body) {String} Email       Member new email address
 */

var MemberReinstateSchema = new DataContractSchema({
    MemberId: {type: String, required: true, validate: customValidators.memberIdValidator },
    Email: {type: String, required: true, validate: customValidators.emailValidator }
});

exports.MemberReinstate = mongoose.model('MemberReinstate', MemberReinstateSchema);