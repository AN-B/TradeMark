'use strict';
var validator = require('mongoose-validator');

module.exports = {
    MemberIdsValidator: function (values) {
        return values.every(function (value) {
            return validator.validatorjs.isUUID(value);
        });
    }
};