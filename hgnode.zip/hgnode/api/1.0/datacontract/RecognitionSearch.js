'use strict';
var mongoose = require('mongoose'),
    validator = require('mongoose-validator'),
    DataContractSchema = require('../../../common/DataContractSchema.js'),
    RecognitionEnums = require('../../../enums/RecognitionEnums.js'),
    paramsUtil = require('../../../util/params.js'),
    nonNegativeNumber = function (value) {
        return paramsUtil.IsPositiveNumber(value);
    },
    isEmail = [validator({
        validator: 'isEmail',
        passIfEmpty: true,
        message: 'Email address is not valid'
    })],
    startDate = [validator({
        validator: 'isDate',
        message: 'Start date is not valid'
    })],
    endDate = [validator({
        validator: 'isDate',
        message: 'End Date is not valid'
    })],
    RecognitionSearchSchema = new DataContractSchema({
        skip: {type: Number, required: false, validate: [nonNegativeNumber, 'skip must be a non-negative number']},
        take: {type: Number, required: false, default: RecognitionEnums.DEFAULT_API_TAKE, validate: [nonNegativeNumber, 'take must be a non-negative number']},
        giveremail: {type: String, required: false, validate: isEmail},
        receiveremail: {type: String, required: false, validate: isEmail},
        startdate: {type: Date, required: false, validate: startDate},
        enddate: {type: Date, required: false, validate: endDate}
    });

exports.RecognitionSearch = mongoose.model('RecognitionSearch', RecognitionSearchSchema);