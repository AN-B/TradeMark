/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js'),
    EntityEnums = require('../../../enums/EntityEnums.js'),
    customValidators = require('./MemberValidators'),
    paramsUtil = require('../../../util/params.js');

function nonNegativeNumberValidator(value) {
    return paramsUtil.IsPositiveNumber(value);
}
var MemberSearchSchema = new DataContractSchema({
    status: {type: String, required: false, enum: Object.keys(EntityEnums.MembershipStatus)},
    since: {type: Date, required: false, validate: customValidators.sinceDateValidator},
    until: {type: Date, required: false, validate: customValidators.untilDateValidator},
    datefield: {type: String, required: false, default: 'StartingDate'},
    take: {type: Number, required: false, default: 25, validate: [nonNegativeNumberValidator, 'take must be non-negative number']},
    skip: {type: Number, required: false, validate: [nonNegativeNumberValidator, 'skip must be non-negative number']},
    hierarchy: {type: Boolean, required: false, default: false},
    fullname: {type: String, required: false, validate: paramsUtil.ALPHABET_DOT_SPACE_DASH},
    sortby: {type: String, required: false, default: 'FullName'}
});

exports.MemberSearch = mongoose.model('MemberSearch', MemberSearchSchema);
