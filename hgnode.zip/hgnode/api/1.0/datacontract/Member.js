/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js'),
    customValidators = require('./MemberValidators'),
    EntityEnums = require('../../../enums/EntityEnums.js'),
    paramsUtil = require('../../../util/params.js');

function MapToDTO(data) {
    if (typeof data.toObject === 'function') {
        data = data.toObject();
    }
    data.MemberId = data.hgId;
    data.GroupDepartment = {
        DepartmentId: data.GroupDepartmentId,
        Name: data.GroupDepartmentName
    };
    if (data.Location) {
        data.Location = {
            LocationId: data.Location.hgId,
            Name: data.Location.Name
        };
    }
    if (data.RolesInGroup && data.RolesInGroup.length) {
        data.Role = data.RolesInGroup[0];
    }
    delete data.hgId;
    return data;
}
function MapToDB(data) {
    data = data.toObject();
    if (data.GroupDepartment) {
        data.Team = {
            hgId: data.GroupDepartment.DepartmentId,
            Name: data.GroupDepartment.Name
        };
    }
    if (data.Location) {
        data.Location = {
            hgId: data.Location.LocationId,
            Name: data.Location.Name
        };
    }
    data.RolesInGroup = data.Role;
    data.BirthDate = data.Birthdate ? new Date(data.Birthdate).getTime() : null;
    data.StartDate = data.StartingDate ? new Date(data.StartingDate).getTime() : null;
    data.EndDate = data.EndingDate ? new Date(data.EndingDate).getTime() : null;
    delete data.Birthdate;
    delete data.StartingDate;
    delete data.EndingDate;
    delete data.GroupDepartment;
    return data;
}
function MapToBulkMemberSchema(data) {
    data = data.toObject();
    data.Password = paramsUtil.GenerateRandomPassword();
    data.StartDate = data.StartingDate ? new Date(data.StartingDate).getTime() : null;
    data.BirthDate = data.Birthdate ? new Date(data.Birthdate).getTime() : null;
    data.EmpID = data.EmployeeId || '';

    if (data.GroupDepartment) {
        data.Department = data.GroupDepartment.Name;
    }
    if (data.MyManagers && data.MyManagers.length) {
        data.ManagerUserIds = data.MyManagers.map(function (manager) {
            return manager.UserId;
        });
    }
    if (data.Location) {
        data.Location = data.Location.Name;
    }
    delete data.Birthdate;
    delete data.StartingDate;
    delete data.GroupDepartment;
    delete data.EmployeeId;
    delete data.MyManagers;
    return data;
}

/**
 * @apiDefine MemberSuccessDTO member The Member object returned
 *
 * @apiSuccess {String} MemberId                        The Member's unique ID
 * @apiSuccess {Date} Birthdate                         The Member's birthdate
 * @apiSuccess {String} UserName                        The Member's username
 * @apiSuccess {String} Email                           The Member's email
 * @apiSuccess {String} HomeZip                         The Member's home zip code
 * @apiSuccess {String} WorkZip                         The Member's work zip code
 * @apiSuccess {String} EmployeeId                      The Member's employee ID
 * @apiSuccess {String} FirstName                       The Member's first name
 * @apiSuccess {String} LastName                        The Member's last name
 * @apiSuccess {String} FullName                        The Member's full name
 * @apiSuccess {String} Position                        The Member's position
 * @apiSuccess {Date} StartingDate                      The Member's starting date
 * @apiSuccess {Date} EndingDate                        The Member's offboarded date
 * @apiSuccess {Object[]} MyManagers                      This is an array of Member's manager information
 * @apiSuccess {String} MyManagers.MemberId                 The Manager's MemberId
 * @apiSuccess {String} MyManagers.Email                    The Manager's EmployeeId
 * @apiSuccess {String} MyManagers.FullName                 The Manager's full name
 * @apiSuccess {Object} Location                        The Member's location information
 * @apiSuccess {String} Location.LocationId                 The location's unique ID
 * @apiSuccess {String} Location.Name                       The location's name
 * @apiSuccess {String} Role                            The Member's role
 * @apiSuccess {Object} GroupDepartment                 Member's department information
 * @apiSuccess {String} GroupDepartment.DepartmentId        The department's unique ID
 * @apiSuccess {String} GroupDepartment.Name                The department's name
 * @apiSuccess {String} GravatarEmail                   The Member's email associated with a Gravatar
 */

/**
 * @apiDefine MemberParamDTO member The Member object accepted as input
 *
 * @apiParam (body) {Date} Birthdate                           The Member's birthdate
 * @apiParam (body) {String} UserName                          The Member's username
 * @apiParam (body) {String} [Password]                        The Member's password (only used during onboarding)
 * @apiParam (body) {String} Email                             The Member's email
 * @apiParam (body) {String} [HomeZip]                         The Member's home zip code
 * @apiParam (body) {String} [WorkZip]                         The Member's work zip code
 * @apiParam (body) {String} [EmployeeId]                      The Member's employee ID
 * @apiParam (body) {String} FirstName                         The Member's first name
 * @apiParam (body) {String} LastName                          The Member's last name
 * @apiParam (body) {String} FullName                          The Member's full name
 * @apiParam (body) {String} Position                          The Member's position
 * @apiParam (body) {Date} StartingDate                        The Member's starting date
 * @apiParam (body) {Date} [EndingDate]                        The Member's offboarded date
 * @apiParam (body) {Object[]} [MyManagers]                    This is an array of Member's manager information. When Supplied, Manager EmployeeId or MemberId is required. 
 * @apiParam (body) {String} MyManagers.EmployeeId             The Manager's EmployeeId
 * @apiParam (body) {String} MyManagers.MemberId               The Manager's MemberId
 * @apiParam (body) {String} MyManagers.FullName               The Manager's full name
 * @apiParam (body) {Object} Location                          The Member's location information
 * @apiParam (body) {String} Location.LocationId                   The Location's unique ID
 * @apiParam (body) {String} Location.Name                         The Location's name
 * @apiParam (body) {String=Employee,Manager,Director,Executive,Admin,Owner,ResellerAdmin} Role The Member's role
 * @apiParam (body) {Object} GroupDepartment                   The Member's department information
 * @apiParam (body) {String} GroupDepartment.DepartmentId      The Department's unique ID
 * @apiParam (body) {String} GroupDepartment.Name              The Department's name
 * @apiParam (body) {string} [GravatarEmail]                   The Member's email associated with a Gravatar
 * @apiParam (body) {Boolean} [SuppressWelcomeMessage=true]    The Member's option to receive a welcome message when onboarding
 */

var MemberSchema = new DataContractSchema({
        MemberId: {type: String},
        Birthdate: {type: Date, required: true, validate: customValidators.birthdateValidator},
        UserName: {type: String, required: true, validate: paramsUtil.USERNAME_REGEXP}, // (userinfo schema)
        Password: {type: String, required: false}, // only used for onboard
        Email: {type: String, required: true, validate: customValidators.emailValidator}, //(userinfo schema)
        HomeZip: {type: String, required: false}, //(userinfo schema)
        WorkZip: {type: String, required: false}, //(userinfo schema)
        EmployeeId: {type: String, required: false, validate: customValidators.employeeIdValidator}, // allowed to be empty, must be a string
        FirstName: {type: String, required: true, validate: paramsUtil.ALPHABET_DOT_SPACE_DASH},
        LastName: {type: String, required: true, validate: paramsUtil.ALPHABET_DOT_SPACE_DASH},
        FullName: {type: String, required: true, validate: paramsUtil.ALPHABET_DOT_SPACE_DASH},
        Position: {type: String, required: true, validate: paramsUtil.ALPHABET_DOT_SPACE_DASH},
        StartingDate: {type: Date, required: true, validate: customValidators.startDateValidator},
        EndingDate: {type: Date, required: false, validate: customValidators.endDateValidator}, // not require, if provided then must be a valid date
        MyManagers: {
            type: Array,
            required: false,
            validate: [customValidators.managerValidator, 'Manager MemberId or EmployeeId is required, Full Name is optional values.']
        },
        Location: {
            type: {
                LocationId: {type: String},
                Name: {type: String}
            },
            required: true,
            validate: [customValidators.locationValidator, 'Either Location.LocationId or Location.Name is required.']
        },
        Role: {
            type: String,
            required: true,
            enum: Object.keys(EntityEnums.MembersRoleInGroup)
        }, // required, must match our internal defined roles
        GroupDepartment: {
            type: { //either Id or Name is required
                DepartmentId: {type: String},
                Name: {type: String}
            },
            required: true,
            validate: [customValidators.departmentValidator, 'Either GroupDepartment.DepartmentId or GroupDepartment.Name is required.']
        },
        GravatarEmail: {type: String, required: false, validate: customValidators.gravatarEmailValidator}, // option, string and valid email
        SuppressWelcomeMessage: {type: Boolean, default: true}
    }),
    MembersSchema = new DataContractSchema({
        members: []
    });

exports.Member = mongoose.model('Member', MemberSchema);
exports.Members = mongoose.model('Members', MembersSchema);
exports.DTOMapper = MapToDTO;
exports.DBMapper = MapToDB;
exports.BulkMapper = MapToBulkMemberSchema;
