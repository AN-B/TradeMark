/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js'),
    validator = require('mongoose-validator'),
    customValidators = require('./TransferManagerValidators');
/**
* @apiDefine TransferManagerDTO
*
* @apiParam (body) {String} OldManagerMemberId                The old manager member's identifier
* @apiParam (body) {String} NewManagerMemberId                The new manager member's identifier
* @apiParam (body) {String} MemberIds                         The list of member's identifier who reports to old manager
* @apiParam (body) {Object} TransferItems                     The list of items that needs to be transfer under new manager
* @apiParam (body) {String} TransferItems.TransferCredit      Is credit should be transfer to new manager? (Yes/No)
* @apiParam (body) {String} TransferItems.TransferPerform     Is performance review should be transfer to new manager? (Yes/No)
* @apiParam (body) {String} TransferItems.TransferProfile     Is direct report(s) should be transfer to new manager? (Yes/No)
* @apiParam (body) {String} TransferItems.TransferTracks      Is tracks should be transfer to new manager? (Yes/No)
* @apiParam (body) {String} TransferItems.TransferPoints      Is points should be transfer to new manager? (Yes/No)
*
*/
var transferItemValidator =  [
        {
            validator: function (value) { return value; },
            msg: 'TransferItems is required'
        },
        {
            validator: function (value) {
                return (value && value.TransferCredit && (value.TransferCredit === 'Yes' || value.TransferCredit === 'No'));
            },
            msg: 'TransferCredit is required and value must be either Yes or No'
        },
        {
            validator: function (value) {
                return (value && value.TransferPerform && (value.TransferPerform === 'Yes' || value.TransferPerform === 'No'));
            },
            msg: 'TransferPerform is required and value must be either Yes or No'
        },
        {
            validator: function (value) {
                return (value && value.TransferProfile && (value.TransferProfile === 'Yes' || value.TransferProfile === 'No'));
            },
            msg: 'TransferProfile is required and value must be either Yes or No'
        },
        {
            validator: function (value) {
                return (value && value.TransferTracks && (value.TransferTracks === 'Yes' || value.TransferTracks === 'No'));
            },
            msg: 'TransferTracks is required and value must be either Yes or No'
        },
        {
            validator: function (value) {
                return (value && value.TransferPoints && (value.TransferPoints === 'Yes' || value.TransferPoints === 'No'));
            },
            msg: 'TransferPoints is required and value must be either Yes or No'
        }
    ];
var oldManagerMemberIdValidator = [
        validator({
            validator: 'isUUID',
            message: 'Old manager memberId is not valid'
        })
    ];
var newManagerMemberIdValidator = [
        validator({
            validator: 'isUUID',
            message: 'New manager memberId is not valid'
        })
    ];
var TransferManagerSchema = new DataContractSchema({
    OldManagerMemberId: {type: String, required: true, validate: oldManagerMemberIdValidator},
    NewManagerMemberId: {type: String, required: true, validate: newManagerMemberIdValidator},
    MemberIds: {
        type: Array,
        required: true,
        validate: [customValidators.MemberIdsValidator, 'Member Ids must be an array of valid UUIDs.']
    },
    TransferItems: {
        type: {
            TransferCredit: {type: String, required: true },
            TransferPerform: {type: String, required: true },
            TransferProfile: {type: String, required: true },
            TransferTracks: {type: String, required: true },
            TransferPoints: {type: String, required: true }
        },
        required: true,
        validate: transferItemValidator
    }
});
exports.TransferManager = mongoose.model('TransferManager', TransferManagerSchema);
