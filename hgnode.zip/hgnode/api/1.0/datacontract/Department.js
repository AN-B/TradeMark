/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../../common/DataContractSchema.js');

/**
 * @apiDefine DepartmentSuccessDTO
 *
 * @apiSuccess {String} DepartmentId        The Department's unique ID
 * @apiSuccess {String} Name                The Department's name
 * @apiSuccess {String} Description         The Department's description
 */

/**
 * @apiDefine DepartmentArraySuccessDTO
 *
 * @apiSuccess {Object[]} body              An array of Departments
 * @apiSuccess {String} body.DepartmentId       The Department's unique ID
 * @apiSuccess {String} body.Name               The Department's name
 * @apiSuccess {String} body.Description        The Department's description
 */

var DepartmentSchema = new DataContractSchema({
    DepartmentId: {type: String, required: true},
    Name: {type: String, required: true},
    Description: {type: String, required: true}
});

exports.Department = mongoose.model('Department', DepartmentSchema);