'use strict';
var validator = require('mongoose-validator'),
    TimeZoneHelper = require('../../../enums/TimeZone.js'),
    CountryEnums = require('../../../enums/CountryEnums.js');

module.exports = {
    //MemberId
    memberIdValidator: [
        validator({
            validator: 'isUUID',
            message: 'MemberId is not valid'
        })
    ],
    //birthdate
    birthdateValidator: [
        validator({
            validator: 'isDate',
            message: 'Member birthdate is not valid'
        })
    ],
    //email
    emailValidator: [
        validator({
            validator: 'isEmail',
            message: 'Member email address is not valid'
        })
    ],
    //employee id
    employeeIdValidator: [
        validator({
            validator: 'isAlphanumeric',
            passIfEmpty: true,
            message: 'EmployeeId must contain alpha-numeric characters'
        })
    ],
    //userId
    userIdValidator: [
        validator({
            validator: 'isUUID',
            message: 'User id is not valid'
        })
    ],
    //startDate
    startDateValidator: [
        validator({
            validator: 'isDate',
            message: 'StartingDate is not valid'
        })
    ],
    //endDate
    endDateValidator: [
        validator({
            validator: 'isDate',
            passIfEmpty: true,
            message: 'EndingDate is not valid'
        })
    ],
    //gravatar email
    gravatarEmailValidator: [
        validator({
            validator: 'isEmail',
            passIfEmpty: true,
            message: 'GravatarEmail address is not valid'
        })
    ],
    notificationEmailValidator: [
        validator({
            validator: 'isEmail',
            passIfEmpty: true,
            message: 'NotificationEmail address is not valid'
        })
    ],
    sinceDateValidator: [
        validator({
            validator: 'isDate',
            message: 'Since date is not valid'
        })
    ],
    untilDateValidator: [
        validator({
            validator: 'isDate',
            passIfEmpty: true,
            message: 'Until date is not valid'
        })
    ],
    takeValidator: [
        validator({
            validator: 'isNumeric',
            passIfEmpty: true,
            message: 'Take value is not valid.It must be non-negative number'
        })
    ],
    skipValidator: [
        validator({
            validator: 'isNumeric',
            passIfEmpty: true,
            message: 'Skip value is not valid.It must be non-negative number'
        })
    ],
    locationValidator: function (value) {
        return !!(value.Name || (value.LocationId  && validator.validatorjs.isUUID(value.LocationId)));
    },
    timezoneValidator: function (value) {
        var  tzValueIndex = TimeZoneHelper.getTZIndex().tzValueIndex;
        return !!tzValueIndex[value.toLowerCase()];
    },
    countryValidator: function (value) {
        var countryList = CountryEnums.ReturnValues(),
            validCountry = !value || !countryList.some(function (c) {
                return c.toLowerCase() === value.toLowerCase();
            });
        return !validCountry;
    },
    departmentValidator: function (value) {
        var result = true;
        if (!value) {
            result = false;
        } else {
            if (!value.DepartmentId && !value.Name) {
                result = false;
            } else if (!value.Name && !validator.validatorjs.isUUID(value.DepartmentId)) {
                result = false;
            }
        }
        return result;
    },
    managerValidator: function (values) {
        if (values.length) {
            return values.some(function (value) {
                return !!((value.MemberId && validator.validatorjs.isUUID(value.MemberId)) || value.EmployeeId);
            });
        }
        return true;
    }
};