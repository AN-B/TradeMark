/*jslint node:true es5:true*/
'use strict';
var StatusCodes = require('../../enums/HttpResponseCodes.js'),
    DefaultErrors = require('../DefaultErrors'),
    validator = require('mongoose-validator').validatorjs,
    DTOUtil = require('../../util/DTOUtil.js'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    paramsUtil = require('../../util/params.js'),
    DepartmentDTO = require('./datacontract/Department.js').Department,
    TAKE_LIMIT = 25,
    DepartmentsService = function () {
        /**
         * @api {get} /1.0/Departments/ Get Departments
         * @apiVersion 1.0.0
         * @apiName GetDepartments
         * @apiGroup Departments
         * @apiDescription Returns an array of Departments
         *
         * @apiUse AccessHeader
         *
         * @apiParam (query) {Number} [skip] The number of records to skip
         * @apiParam (query) {Number} [take] The number of records to return (max 25)
         *
         * @apiUse InvalidTakeValue
         * @apiUse InvalidSkipValue
         * @apiUse UnknownError
         *
         * @apiUse DepartmentArraySuccessDTO
         *
         * @apiUse GET_DepartmentExample
         */
        this.get = function (context, callback) {
            if (!paramsUtil.IsPositiveNumber(context.query.take) || context.query.take > TAKE_LIMIT) {
                return callback(DefaultErrors.InvalidTakeValue);
            }
            if (!paramsUtil.IsPositiveNumber(context.query.skip)) {
                return callback(DefaultErrors.InvalidSkipValue);
            }
            var teamInternalService = new InternalServiceCache.Team(context.correlationId);
            teamInternalService.GetDepartmentsByGroupId_Internal({
                GroupId: context.groupid,
                Skip: context.query.skip || 0,
                Take: context.query.take || TAKE_LIMIT
            }, function (error, departments) {
                if (error) {
                    return callback(DefaultErrors.UnknownError);
                }
                callback(null, {
                    StatusCode: StatusCodes.Success.OK,
                    data: departments.map(function (item) {
                        return DTOUtil.CreateResponse({
                            DepartmentId: item.hgId,
                            Name: item.Name,
                            Description: item.Description
                        }, 'Object', DepartmentDTO);
                    })
                });
            });
        };
    };

module.exports = DepartmentsService;