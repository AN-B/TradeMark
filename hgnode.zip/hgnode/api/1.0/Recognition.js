/*jslint node:true es5:true*/
'use strict';
var httpResponseCodes = require('../../enums/HttpResponseCodes.js'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    HgLog = require('../../framework/HgLog'),
    DefaultErrors = require('../DefaultErrors'),
    config = require('../../configurations/config.js'),
    paramsUtil = require('../../util/params.js'),
    RecognitionSearch = require('./datacontract/RecognitionSearch.js').RecognitionSearch,
    RecognitionDataContract = require('./datacontract/Recognition.js'),
    RecognitionService = function () {

        /**
         * @api {get} /1.0/Recognition/ Get Recognitions
         * @apiVersion 1.0.0
         * @apiName GetRecognition
         * @apiGroup Recognition
         *
         * @apiUse AccessHeader
         *
         * @apiParam (query) {Number} [skip] The number of records to skip
         * @apiParam (query) {Number} [take] The number of records to return (max 25)
         * @apiParam (query) {String} [giveremail] The email of the giver of the Recognition
         * @apiParam (query) {String} [receiveremail] The email of the receiver of the Recognition
         * @apiParam (query) {Date} [startdate] The beginning date range
         * @apiParam (query) {Date} [enddate] The ending date range
         *
         * @apiUse InvalidSearchCriteria
         * @apiUse UnknownError
         *
         * @apiUse RecognitionSuccessDTO
         */
        this.get = function (context, callback) {
            var recognitionSearch = new RecognitionSearch(paramsUtil.lowercaseObjectKey(context.query)),
                recognitionInternalService = new InternalServiceCache.Recognition(context.correlationId);

            recognitionSearch.validate(function (validationErrors) {
                if (validationErrors) {
                    HgLog.debug("Recognition API search errors", validationErrors);
                    return callback(DefaultErrors.InvalidSearchCriteria, validationErrors);
                }

                recognitionInternalService.GetRecognitionsForAPIClient({
                    correlationId: context.correlationId,
                    groupid: context.groupid,
                    skip: recognitionSearch.skip,
                    take: recognitionSearch.take,
                    giveremail: recognitionSearch.giveremail,
                    receiveremail: recognitionSearch.receiveremail,
                    startdate: recognitionSearch.startdate,
                    enddate: recognitionSearch.enddate
                }, function (err, data) {
                    if (err) {
                        HgLog.error('Get Recognitions API error', err);
                        return callback(DefaultErrors.UnknownError, err);
                    }
                    var recognitions = [],
                        len = data.Recognitions.length,
                        i;

                    for (i = 0; i < len; i += 1) {
                        recognitions.push(RecognitionDataContract.MapToDTO(data.Recognitions[i], data.UserEmailMapping));
                    }

                    callback(null, {
                        StatusCode: httpResponseCodes.Success.OK,
                        data: recognitions
                    });
                });
            });
        };
    };

module.exports = RecognitionService;