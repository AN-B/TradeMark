/*jslint node:true es5:true*/
'use strict';
var StatusCodes = require('../../enums/HttpResponseCodes.js'),
    DefaultErrors = require('../DefaultErrors'),
    GRSErrors = require('./enums/GRSErrors.js'),
    InternalServiceCache = require('../../framework/InternalServiceCache.js'),
    GRSMember = require('./datacontract/GRSMember.js'),
    GRSOrder = require('./datacontract/GRSOrder.js').GRSOrder,
    i18nHelper = require('../../helpers/i18nHelper.js'),
    HgLog = require('../../framework/HgLog.js'),

    GRSService = function () {
        this.get = function (context, callback) {
            var grsInternalService = new InternalServiceCache.GRS(context.correlationId),
                id = context.query.id;

            HgLog.debug('GRS query for member', id);

            grsInternalService.GetMemberByEncryptedHgId({
                correlationId: context.correlationId,
                EncryptedHgId: id
            }, function (error, data) {
                if (error) {
                    if (error === 'services.int.mem.mnf') {
                        return callback(GRSErrors.MemberNotFound);
                    }
                    HgLog.error(error);
                    return callback(DefaultErrors.UnknownError);
                }
                callback(null, {
                    StatusCode: StatusCodes.Success.OK,
                    data: GRSMember.MapToDTO(data)
                });
            });
        };

        this.post = function (context, callback) {
            var grsInternalService = new InternalServiceCache.GRS(context.correlationId),
                order,
                jsonOrder,
                orderItemsObjects,
                orderItem;

            // have to parse context.body.order because it comes as a JSON string for whatever reason
            try {
                jsonOrder = JSON.parse(context.body.order);
                orderItemsObjects = jsonOrder.orderItems;
                jsonOrder.orderItems = [];

                for (orderItem in orderItemsObjects) {
                    if (orderItemsObjects.hasOwnProperty(orderItem)) {
                        jsonOrder.orderItems.push(orderItemsObjects[orderItem]);
                    }
                }

                HgLog.debug('GRS order json', jsonOrder);
                order = new GRSOrder(jsonOrder);
            } catch (e) {
                HgLog.error('Error parsing JSON', e);
                return callback(DefaultErrors.UnknownError);
            }

            grsInternalService.ProcessGRSOrder({
                correlationId: context.correlationId,
                order: order
            });     //don't need a callback, GRS doesn't care about our response

            callback(null, {
                StatusCode: StatusCodes.Success.OK,
                data: 'Success'
            });
        };
    };

module.exports = GRSService;