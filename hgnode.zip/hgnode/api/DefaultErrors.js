'use strict';
var StatusCodes = require('../enums/HttpResponseCodes');

module.exports = {
    /**
     * @apiDefine UnknownAPIVersion
     * @apiError (Error 5xx) UnknownAPIVersion The API Version is not supported
     */
    UnknownAPIVersion: {
        Name: 'UnknownAPIVersion',
        StatusCode: StatusCodes.ServerError.NotImplemented,
        Description: 'Unknown API version'
    },
    /**
     * @apiDefine UnknownResource
     * @apiError (Error 5xx) UnknownResource This endpoint does not have a resource associated with it
     */
    UnknownResource: {
        Name: 'UnknownResource',
        StatusCode: StatusCodes.ServerError.NotImplemented,
        Description: 'Unknown resource'
    },
    /**
     * @apiDefine NotImplemented
     * @apiError (Error 5xx) NotImplemented This resource does not support this action
     */
    NotImplemented: {
        Name: 'NotImplemented',
        StatusCode: StatusCodes.ServerError.NotImplemented,
        Description: 'Resource does not support this action'
    },
    /**
     * @apiDefine UnknownError
     * @apiError (Error 5xx) UnknownError An unknown error occurred
     */
    UnknownError: {
        Name: 'UnknownError',
        StatusCode: StatusCodes.ServerError.InternalServerError,
        Description: 'An unknown error occurred'
    },
    /**
     * @apiDefine InvalidSinceDate
     * @apiError (Error 4xx) InvalidSinceDate Since date provided is not valid
     */
    InvalidSinceDate: {
        Name: 'InvalidSinceDate',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Since date provided is not valid'
    },
    /**
     * @apiDefine InvalidUntilDate
     * @apiError (Error 4xx) InvalidUntilDate Until date provided is not valid
     */
    InvalidUntilDate: {
        Name: 'InvalidUntilDate',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Until date provided is not valid'
    },
    /**
     * @apiDefine InvalidTakeValue
     * @apiError (Error 4xx) InvalidTakeValue Take value has to be positive number and less than or equal to 25
     */
    InvalidTakeValue: {
        Name: 'InvalidTakeValue',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Take value has to be positive number and less than or equal to 25'
    },
    /**
     * @apiDefine InvalidSkipValue
     * @apiError (Error 4xx) InvalidSkipValue Skip value has to be positive number
     */
    InvalidSkipValue: {
        Name: 'InvalidSkipValue',
        StatusCode: StatusCodes.ClientError.BadRequest,
        Description: 'Skip value has to be positive number'
    }
};