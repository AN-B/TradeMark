/*jslint node:true es5:true*/
'use strict';
/**
 * @apiDefine URL URL Params
 */

/**
 * @apiDefine body Request Body
 */

/**
 * @apiDefine query Query String Params
 */

/**
 * @apiDefine AccessHeader
 * @apiHeader {String} clientkey Your API key
 */

var RestServices = {
    Versions: ['1.0'],
    '1.0': {
        Recognition: require('./1.0/Recognition.js'),
        EventBus: require('./1.0/EventBus.js'),
        Member: require('./1.0/Member.js'),
        Members: require('./1.0/Members.js'),
        Locations: require('./1.0/Locations.js'),
        Departments: require('./1.0/Departments.js'),
        Manager: require('./1.0/Manager.js'),
        GRS: require('./1.0/GRS.js'),
        RulesEngine: require('./1.0/RulesEngine.js')
    },
    ResponseHandlers: {
        '1.0': require('./1.0/ResponseHandler.js')
    }
};

module.exports = RestServices;