/*jslint node:true es5:true*/
var HgBaseService = require('../framework/HgService.js'),
    BadgeAdminService = function () {
        'use strict';
        HgBaseService.apply(this, arguments);
        var BadgeProcessor = new this.ProcessorCache.Badge(this.correlationId),
            RequestManager = this.RequestManager,
            EventEmitterCache = this.EventEmitterCache,
            onGeneralServiceCallComplate = function (eventData) {
                RequestManager.respondToEvent(eventData);
            };

        this.CreateBadge = function (params) {
            var badgeRequest = params.req.body,
                userId = params.currentuser.hgId,
                newParams = {
                    correlationId : params.correlationId,
                    EventName : EventEmitterCache.EventEnum.BadgeAdminService.CreateComplete,
                    UserId : userId,
                    BadgeRequest : badgeRequest
                };
            if (newParams.BadgeRequest.Federated && (newParams.BadgeRequest.Federated === 'true' || newParams.BadgeRequest.Federated === 'Yes')) {
                newParams.BadgeRequest.Federated = true;
            } else {
                newParams.BadgeRequest.Federated = false;
            }
            BadgeProcessor.Create(newParams);
        };

        this.GetBadges = function (params) {
            var skip = (params.req.query.skip || 0),
                take = (params.req.query.take || 0),
                newParams = {
                    correlationId : params.correlationId,
                    EventName : EventEmitterCache.EventEnum.BadgeAdminService.CreateComplete,
                    Skip : skip,
                    Take : take,
                    UserId : params.currentuser.hgId
                };
            BadgeProcessor.GetAllBadges(newParams);
        };

        this.CreateBadge_Internal = function (params) {
            var badgeRequest = params.BadgeRequest,
                userId = params.UserId,
                newParams = {
                    correlationId : params.correlationId,
                    EventName : EventEmitterCache.EventEnum.BadgeAdminService.InternalServiceCallComplete,
                    UserId : userId,
                    BadgeRequest : badgeRequest
                };
            if (newParams.BadgeRequest.Federated && (newParams.BadgeRequest.Federated === 'true' || newParams.BadgeRequest.Federated === 'Yes')) {
                newParams.BadgeRequest.Federated = true;
            } else {
                newParams.BadgeRequest.Federated = false;
            }
            BadgeProcessor.Create(newParams);
        };

        this.UpdateBadge = function (params) {
            var badgeRequest = params.req.body,
                userId = params.currentuser.hgId,
                newParams = {
                    correlationId : params.correlationId,
                    EventName : EventEmitterCache.EventEnum.BadgeAdminService.UpdateComplete,
                    UserId : userId,
                    BadgeRequest : badgeRequest
                };
            if (newParams.BadgeRequest.Federated && (newParams.BadgeRequest.Federated === 'true' || newParams.BadgeRequest.Federated === 'Yes')) {
                newParams.BadgeRequest.Federated = true;
            } else {
                newParams.BadgeRequest.Federated = false;
            }
            BadgeProcessor.Update(newParams);
        };

        EventEmitterCache.on(EventEmitterCache.EventEnum.BadgeAdminService.UpdateComplete, onGeneralServiceCallComplate);
        EventEmitterCache.on(EventEmitterCache.EventEnum.BadgeAdminService.CreateComplete, onGeneralServiceCallComplate);
    };

module.exports = BadgeAdminService;
