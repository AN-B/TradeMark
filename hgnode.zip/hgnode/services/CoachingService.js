/*jslint node:true es5:true*/
var HgBaseService = require('../framework/HgService.js'),
    CoachingService = function () {
        'use strict';
        HgBaseService.apply(this, arguments);
        var RequestManager = this.RequestManager,
            InternalServiceCache = this.InternalServiceCache,
            DTOUtil = require('../util/DTOUtil.js'),
            DateHelper = require('../util/DateHelper.js'),
            i18nHelper = require('../helpers/i18nHelper.js'),
            CoachingServiceDataContract = require('./datacontract/CoachingNote.js');
        this.GiveCoachingNote = function (params) {
            var newParams = {
                    Lang: i18nHelper.getRequestLanguageIndex(params),
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    FirstName: params.currentuser.UserPersonal.FirstName,
                    LastName: params.currentuser.UserPersonal.LastName,
                    MemberId: params.currentuser.UserContext.MemberIdInGroup,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    Note: params.req.body.Comment,
                    TrackId: params.req.body.TrackId,
                    MilestoneId: params.req.body.MilestoneId,
                    RecipientMemberId: params.req.body.RecipientMemberId,
                    Draft: params.req.body.Draft,
                    EmailRecipient: params.req.body.EmailRecipient,
                    IncludePerformance: params.req.body.IncludePerformance,
                    IsPublic: params.req.body.IsPublic
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            if (!newParams.Note || !newParams.RecipientMemberId) {
                RequestManager.error(params.correlationId, 'srv.cos.mnr');
            } else {
                coachingInternalService.GiveCoachingNote_Internal(newParams, function (error, data) {
                    if (error) {
                        RequestManager.error(params.correlationId, error);
                    } else {
                        RequestManager.send(newParams.correlationId, data);
                    }
                });
            }
        };
        this.GiveCoachingNoteToMembers = function (params) {
            var newParams = {
                    Lang: i18nHelper.getRequestLanguageIndex(params),
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    FirstName: params.currentuser.UserPersonal.FirstName,
                    LastName: params.currentuser.UserPersonal.LastName,
                    MemberId: params.currentuser.UserContext.MemberIdInGroup,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    Note: params.req.body.Note,
                    Header: params.req.body.Header,
                    TrackId: params.req.body.TrackId,
                    MilestoneId: params.req.body.MilestoneId,
                    RecipientMemberIds: params.req.body.RecipientMemberIds,
                    Draft: params.req.body.Draft,
                    EmailRecipient: params.req.body.EmailRecipient,
                    IncludePerformance: params.req.body.IncludePerformance,
                    IsPublic: params.req.body.IsPublic
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            if (!newParams.Note || !newParams.RecipientMemberIds || newParams.RecipientMemberIds.length < 1) {
                RequestManager.error(params.correlationId, 'srv.cos.mnr');
            } else {
                coachingInternalService.GiveCoachingNoteToMembers(newParams, function (error, data) {
                    if (error) {
                        RequestManager.error(params.correlationId, error);
                    } else {
                        RequestManager.send(newParams.correlationId, data);
                    }
                });
            }
        };
        this.UpdateCoachingNote = function (params) {
            var coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            coachingInternalService.UpdateCoachingNote_Internal({
                Lang: i18nHelper.getRequestLanguageIndex(params),
                correlationId: params.correlationId,
                UserId: params.currentuser.hgId,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                NoteId: params.req.body.NoteId,
                Note: params.req.body.Note,
                Header: params.req.body.Header,
                TrackId: params.req.body.TrackId,
                Draft: params.req.body.Draft,
                GroupId: params.currentuser.UserContext.CurrentGroupId
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };
        this.GetCoachingNotesForMember = function (params) {
            var newParams = {
                    correlationId : params.correlationId,
                    UserId : params.currentuser.hgId,
                    MemberId : params.currentuser.UserContext.MemberIdInGroup,
                    GroupId : params.currentuser.UserContext.CurrentGroupId,
                    RoleInGroup : params.currentuser.UserContext.RolesInGroup[0],
                    RecipientMemberId : params.req.body.RecipientMemberId,
                    Skip: (params.req.body.skip || 0),
                    Take: (params.req.body.take || 10)
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            coachingInternalService.GetCoachingNotesForMember_Internal(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(newParams.correlationId, data);
                }
            });
        };
        this.GetCoachingNoteById = function (params) {
            var newParams = {
                    correlationId : params.correlationId,
                    UserId : params.currentuser.hgId,
                    MemberId : params.currentuser.UserContext.MemberIdInGroup,
                    GroupId : params.currentuser.UserContext.CurrentGroupId,
                    RoleInGroup : params.currentuser.UserContext.RolesInGroup[0],
                    RecipientMemberId : params.req.body.RecipientMemberId,
                    NoteId : params.req.body.NoteId
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            coachingInternalService.GetCoachingNoteById_Internal(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(newParams.correlationId, data);
                }
            });
        };
        this.GetDraftNoteById = function (params) {
            var newParams = {
                    correlationId : params.correlationId,
                    UserId : params.currentuser.hgId,
                    MemberId : params.currentuser.UserContext.MemberIdInGroup,
                    GroupId : params.currentuser.UserContext.CurrentGroupId,
                    RoleInGroup : params.currentuser.UserContext.RolesInGroup[0],
                    NoteId : params.req.body.NoteId
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            coachingInternalService.GetDraftNoteById_Internal(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(newParams.correlationId, data);
                }
            });
        };
        this.GetForMilestoneOrGoal = function (params) {//note: the 
            var newParams = {
                    correlationId : params.correlationId,
                    UserId : params.currentuser.hgId,
                    MemberId : params.currentuser.UserContext.MemberIdInGroup,
                    GroupId : params.currentuser.UserContext.CurrentGroupId,
                    RoleInGroup : params.currentuser.UserContext.RolesInGroup[0],
                    MilestoneOrGoalId : params.req.body.MilestoneOrGoalId
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            coachingInternalService.GetForMilestoneOrGoal_Internal(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(newParams.correlationId, data);
                }
            });
        };
        this.GetCoachingGivenByMemberId = function (params) {
            var newParams = {
                    correlationId : params.correlationId,
                    UserId : params.currentuser.hgId,
                    MemberId : params.req.body.memberId,
                    StartDate : (params.req.body.startDate !== '') ? new Date(params.req.body.startDate).getTime() : '',
                    EndDate : (params.req.body.endDate !== '') ? DateHelper.setDateToEndOfDay(new Date(params.req.body.endDate).getTime()) : ''
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            coachingInternalService.GetCoachingGivenByMemberId_Internal(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(newParams.correlationId, DTOUtil.CreateResponse(data, 'Array', CoachingServiceDataContract.CoachingNoteDrillDown));
                }
            });
        };

        this.GetCoachingReceivedByMemberId = function (params) {
            var newParams = {
                    correlationId : params.correlationId,
                    UserId : params.currentuser.hgId,
                    MemberId : params.req.body.memberId,
                    StartDate : (params.req.body.startDate !== '') ? new Date(params.req.body.startDate).getTime() : '',
                    EndDate : (params.req.body.endDate !== '') ? DateHelper.setDateToEndOfDay(new Date(params.req.body.endDate).getTime()) : ''
                },
                coachingInternalService = new InternalServiceCache.Coaching(params.correlationId);
            coachingInternalService.GetCoachingReceivedByMemberId_Internal(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(newParams.correlationId, DTOUtil.CreateResponse(data, 'Array', CoachingServiceDataContract.CoachingNoteDrillDown));
                }
            });
        };
    };

module.exports = CoachingService;
