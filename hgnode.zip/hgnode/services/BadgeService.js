/*jslint node:true es5:true*/
var HgBaseService = require('../framework/HgService.js'),
    BadgeService = function () {
        'use strict';
        HgBaseService.apply(this, arguments);
        var BadgeProcessor = new this.ProcessorCache.Badge(this.correlationId),
            RequestManager = this.RequestManager,
            EventEmitterCache = this.EventEmitterCache,
            InternalServiceCache = this.InternalServiceCache,
            Enums = require('../enums/EntityEnums.js'),
            onGeneralServiceCallComplate = function (eventData) {
                RequestManager.respondToEvent(eventData);
            };

        this.GetBadgesForEverydayRecognition = function (params) {
            var badgeInternalService = new InternalServiceCache.Badge(params.correlationId);
            badgeInternalService.GetBadges_Internal({
                correlationId: params.correlationId,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                SearchTerm: params.req.query.searchTerm || '',
                Category: params.req.query.category || '',
                UserId: params.currentuser.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.Everyday]
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                    return;
                }
                badgeInternalService.GetCategories_Internal({
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    SpecialUsage: [Enums.SpecialUsages.Everyday]
                }, function (err, cat) {
                    if (err) {
                        RequestManager.error(params.correlationId, err);
                        return;
                    }
                    RequestManager.send(params.correlationId, {badges: data, cat: cat});
                });
            });
        };

        this.GetBadgesForCustomizedEveryday = function (params) {
            BadgeProcessor.GetBadges({
                correlationId: params.correlationId,
                EventName: EventEmitterCache.EventEnum.BadgeService.GetAllComplete,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                UserId: params.currentuser.hgId,
                GroupId: params.req.body.GroupId || params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.CustomizedEveryday]
            });
        };

        this.GetBadgesForAchievementRecognition = function (params) {
            var badgeInternalService = new InternalServiceCache.Badge(params.correlationId);
            badgeInternalService.GetBadges_Internal({
                correlationId: params.correlationId,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                SearchTerm: params.req.query.searchTerm || '',
                Category: params.req.query.category || '',
                UserId: params.currentuser.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.Achievement, Enums.SpecialUsages.Everyday]
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                    return;
                }
                badgeInternalService.GetCategories_Internal({
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    SpecialUsage: [Enums.SpecialUsages.Achievement, Enums.SpecialUsages.Everyday]
                }, function (err, cat) {
                    if (err) {
                        RequestManager.error(params.correlationId, err);
                        return;
                    }
                    RequestManager.send(params.correlationId, {badges: data, cat: cat});
                });
            });
        };

        this.GetBadgesForCustomizedRecognition = function (params) {
            var badgeInternalService = new InternalServiceCache.Badge(params.correlationId);
            badgeInternalService.GetBadgesForCustomizedRecognition_Internal({
                correlationId: params.correlationId,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                UserId: params.currentuser.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.CustomizedRecognition]
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                    return;
                }
                RequestManager.send(params.correlationId, data);
            });
        };


        this.GetSpecialUsages = function (params) {
            var newParams = {
                correlationId: params.correlationId,
                UserId: params.currentuser.hgId
            };
            RequestManager.send(newParams.correlationId, Object.keys(Enums.SpecialUsages));
        };
        this.GetBadgesForValueBorder = function (params) {
            BadgeProcessor.GetBadges({
                correlationId: params.correlationId,
                EventName: EventEmitterCache.EventEnum.BadgeService.GetAllComplete,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                UserId: params.currentuser.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.LevelBorder]
            });
        };
        this.GetBadgesForAchievementBackground = function (params) {
            var badgeInternalService = new InternalServiceCache.Badge(params.correlationId);
            badgeInternalService.GetBadges_Internal({
                correlationId: params.correlationId,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                SearchTerm: params.req.query.searchTerm || '',
                Category: params.req.query.category || '',
                UserId: params.currentuser.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.AchievementBackground]
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                    return;
                }
                badgeInternalService.GetCategories_Internal({
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    SpecialUsage: [Enums.SpecialUsages.AchievementBackground]
                }, function (err, cat) {
                    if (err) {
                        RequestManager.error(params.correlationId, err);
                        return;
                    }
                    RequestManager.send(params.correlationId, {badges: data, cat: cat});
                });
            });
        };
        this.GetBadgesForBackground = function (params) {
            var badgeInternalService = new InternalServiceCache.Badge(params.correlationId);
            badgeInternalService.GetBadges_Internal({
                correlationId: params.correlationId,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                SearchTerm: params.req.query.searchTerm || '',
                Category: params.req.query.category || '',
                UserId: params.currentuser.hgId,
                GroupId: params.req.body.GroupId || params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.Background]
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                    return;
                }
                badgeInternalService.GetCategories_Internal({
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    SpecialUsage: [Enums.SpecialUsages.Background]
                }, function (err, cat) {
                    if (err) {
                        RequestManager.error(params.correlationId, err);
                        return;
                    }
                    RequestManager.send(params.correlationId, {badges: data, cat: cat});
                });
            });
        };
        this.GetBadgesForValuesIcon = function (params) {
            var badgeInternalService = new InternalServiceCache.Badge(params.correlationId);
            badgeInternalService.GetBadges_Internal({
                correlationId: params.correlationId,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                SearchTerm: params.req.query.searchTerm || '',
                Category: params.req.query.category || '',
                UserId: params.currentuser.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: [Enums.SpecialUsages.ValuesIcon, Enums.SpecialUsages.Everyday]
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                    return;
                }
                badgeInternalService.GetCategories_Internal({
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    SpecialUsage: [Enums.SpecialUsages.ValuesIcon, Enums.SpecialUsages.Everyday]
                }, function (err, cat) {
                    if (err) {
                        RequestManager.error(params.correlationId, err);
                        return;
                    }
                    RequestManager.send(params.correlationId, {badges: data, cat: cat});
                });
            });
        };

        this.GetBadges = function (params) {
            var badgeInternalService = new InternalServiceCache.Badge(params.correlationId);
            badgeInternalService.GetBadges_Internal({
                correlationId: params.correlationId,
                Skip: params.req.query.skip || 0,
                Take: params.req.query.take || 0,
                SearchTerm: params.req.query.searchTerm || '',
                Category: params.req.query.category || '',
                UserId: params.currentuser.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                SpecialUsage: 'None'
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                    return;
                }
                badgeInternalService.GetCategories_Internal({
                    correlationId: params.correlationId,
                    UserId: params.currentuser.hgId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    SpecialUsage: 'None'
                }, function (err, cat) {
                    if (err) {
                        RequestManager.error(params.correlationId, err);
                        return;
                    }
                    RequestManager.send(params.correlationId, {badges: data, cat: cat});
                });
            });
        };


        this.GetBadgeById = function (params) {
            BadgeProcessor.GetBadgeById({
                correlationId: params.correlationId,
                BadgeId: params.req.params.Id,
                EventName: EventEmitterCache.EventEnum.BadgeService.GetAllComplete
            });
        };
        this.GetBadgeByFileName = function (params) {
            BadgeProcessor.GetBadgeByFileName({
                correlationId: params.correlationId,
                Filename: params.req.body.Filename,
                EventName: EventEmitterCache.EventEnum.BadgeService.GetAllComplete
            });
        };
        this.GetDefaultBadge = function (params) {
            BadgeProcessor.GetDefaultBadge({
                correlationId: params.correlationId,
                EventName: EventEmitterCache.EventEnum.BadgeService.GetAllComplete
            });
        };

        EventEmitterCache.on(EventEmitterCache.EventEnum.BadgeService.GetAllComplete, onGeneralServiceCallComplate);
    };

module.exports = BadgeService;