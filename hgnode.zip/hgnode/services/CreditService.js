/*jslint node:true es5:true*/
var HgBaseService = require('../framework/HgService.js'),
    CreditService = function () {
        'use strict';
        HgBaseService.apply(this, arguments);
        var userInfo = this.UserInfo,
            RequestManager = this.RequestManager,
            EventEmitterCache = this.EventEmitterCache,
            InternalServiceCache = this.InternalServiceCache,
            CreditAccountProcessor = new this.ProcessorCache.CreditAccount(this.correlationId),
            AuthorizeNetProcessor = new this.ProcessorCache.AuthorizeNet(this.correlationId),
            BillMeLaterProcessor = new this.ProcessorCache.BillMeLater(this.correlationId),
            EntityCache = require('../framework/EntityCache.js'),
            HgLog = require('../framework/HgLog.js'),
            HgError = require('../common/HgError.js'),
            NotificationsEnums = require('../enums/NotificationsEnums.js'),
            TransactionType = require('../enums/TransactionType'),
            TransactionStatus = require('../enums/TransactionStatus'),
            AccountType = require('../enums/AccountType.js'),
            PaymentType = require('../enums/PaymentType.js'),
            EventResponder = require('../util/EventResponder.js'),
            ParamUtil = require('../util/params.js'),
            PusherManager = require('../util/PusherManager'),
            self = this,
            Async = require('async'),
            onGeneralServiceCallComplate = function (eventData) {
                RequestManager.respondToEvent(eventData);
            },
            onTransferCreditComplete = function (eventData) {
                var notificationInternalService = new InternalServiceCache.Notification(eventData.correlationId),
                    TransactionInternalService = new InternalServiceCache.Transaction(eventData.correlationId),
                    recipients = eventData.payload.params.Recipients,
                    summaryFromProcessor = eventData.payload.data,
                    notificationParam,
                    i,
                    debitTransactionParams,
                    creditTransactionParams,
                    transactionCallback = function (err) {
                        if (err) {
                            HgLog.error(err);
                        }
                    },
                    len;

                for (i = 0; i < summaryFromProcessor.length; i += 1) {
                    debitTransactionParams = {
                        correlationId : eventData.correlationId,
                        AccountId : summaryFromProcessor[i].Recipient.FromAccountId,
                        UserId: userInfo.hgId,
                        UserName: userInfo.UserPersonal.FullName,
                        FirstName: userInfo.UserPersonal.FirstName,
                        LastName: userInfo.UserPersonal.LastName,
                        GroupId: userInfo.UserContext.CurrentGroupId,
                        GroupName: userInfo.UserContext.CurrentGroupName,
                        CreditQuantity : -summaryFromProcessor[i].Recipient.credits,
                        Status : TransactionStatus.Complete,
                        Type : TransactionType.Transfer,
                        Info: userInfo.UserPersonal.FullName + ' transferred ' + summaryFromProcessor[i].Recipient.credits + ' credits to ' + summaryFromProcessor[i].Recipient.RecipientMember.FirstName + (summaryFromProcessor[i].Recipient.Notes ? '. Notes: ' + summaryFromProcessor[i].Recipient.Notes : '')
                    };
                    TransactionInternalService.SaveTransaction_Internal(debitTransactionParams, transactionCallback);
                    creditTransactionParams = {
                        correlationId : eventData.correlationId,
                        AccountId : summaryFromProcessor[i].Recipient.FromAccountId,
                        UserId: summaryFromProcessor[i].Recipient.RecipientMember.UserId,
                        UserName: summaryFromProcessor[i].Recipient.RecipientMember.FullName,
                        FirstName: summaryFromProcessor[i].Recipient.RecipientMember.FirstName,
                        LastName: summaryFromProcessor[i].Recipient.RecipientMember.LastName,
                        GroupId: userInfo.UserContext.CurrentGroupId,
                        GroupName: userInfo.UserContext.CurrentGroupName,
                        CreditQuantity : summaryFromProcessor[i].Recipient.credits,
                        Status : TransactionStatus.Complete,
                        Type : TransactionType.Transfer,
                        Info: userInfo.UserPersonal.FullName + ' transferred ' + summaryFromProcessor[i].Recipient.credits + ' credits to ' + summaryFromProcessor[i].Recipient.RecipientMember.FirstName + (summaryFromProcessor[i].Recipient.Notes ? '. Notes: ' + summaryFromProcessor[i].Recipient.Notes : '')
                    };
                    TransactionInternalService.SaveTransaction_Internal(creditTransactionParams, transactionCallback);
                }
                len = recipients.length;
                Async.whilst(
                    function () {
                        len -= 1;
                        return len > -1;
                    },
                    function (callback) {
                        notificationParam = {
                            correlationId : eventData.correlationId,
                            Data : {
                                MemberId : recipients[len].hgId,
                                CreditQuantity : recipients[len].credits,
                                SenderName : userInfo.UserPersonal.FirstName,
                                Notes : recipients[len].Notes
                            },
                            NotificationEvent : NotificationsEnums.Event.TransferCreditsComplete.Name,
                            CompleteCallback : callback
                        };
                        notificationInternalService.NotifyQueue(notificationParam);
                    },
                    function (err) {
                        if (err) {
                            RequestManager.error(eventData.correlationId, err);
                        } else {
                            RequestManager.send(eventData.correlationId, 'msg.usr.ctc');
                        }
                    }
                );
            },
            onVerifyCreditBalanceComplete = function (eventData) {
                var userId = userInfo.hgId,
                    groupId = userInfo.UserContext.CurrentGroupId,
                    memberId = userInfo.UserContext.MemberIdInGroup,
                    newParams = {
                        correlationId : eventData.correlationId,
                        EventName : EventEmitterCache.EventEnum.CreditService.VerifyGroupTransferSettingComplete,
                        UserId : userId,
                        MemberId : memberId,
                        Recipients : eventData.payload.params.Recipients,
                        GroupId : groupId
                    };

                if (eventData.payload.data === true) {
                    CreditAccountProcessor.VerifyGroupTransferSetting(newParams);
                } else {
                    HgLog.error('There was an error transferring credits ' + eventData.errorMessage);
                    RequestManager.respondToEvent(eventData);
                }
            },
            onVerifyGroupTransferSettingComplete = function (eventData) {
                if (eventData.payload.data) {
                    CreditAccountProcessor.TransferCredit({
                        correlationId: eventData.correlationId,
                        EventName: EventEmitterCache.EventEnum.CreditService.TransferCreditComplete,
                        UserId: userInfo.hgId,
                        MemberId: userInfo.UserContext.MemberIdInGroup,
                        GroupId: userInfo.UserContext.CurrentGroupId,
                        Recipients: eventData.payload.params.Recipients
                    });
                } else {
                    RequestManager.respondToWrappedEvent(eventData);
                }
            },
            getCurrentUsersPaymentProfile = function (paymentProfileId) {
                var i;
                if (userInfo.UserFinance && userInfo.UserFinance.PaymentProfiles) {
                    for (i = 0; i < userInfo.UserFinance.PaymentProfiles.length; i += 1) {
                        if (userInfo.UserFinance.PaymentProfiles[i].HgId === paymentProfileId) {
                            return userInfo.UserFinance.PaymentProfiles[i];
                        }
                    }
                }
            },
            getAuthorizeNetPaymentProfileId = function (paymentSettingId) {
                var i;
                for (i = 0; i < userInfo.UserFinance.PaymentProfiles.length; i += 1) {
                    if (userInfo.UserFinance.PaymentProfiles[i].HgId === paymentSettingId) {
                        return userInfo.UserFinance.PaymentProfiles[i].AuthorizeNetPaymentProfileId;
                    }
                }
                return null;
            },
            onLoadPackTemplateComplete = function (eventData) {
                var userId = userInfo.hgId,
                    memberId = userInfo.UserContext.MemberIdInGroup,
                    packTemplate = eventData.payload.data,
                    purchaseRequest = eventData.payload.params.PurchaseRequest,
                    totalCost = packTemplate.Cost,
                    authorizeNetPaymentProfileId = getAuthorizeNetPaymentProfileId(purchaseRequest.PaymentSettingId),
                    PaymentProfile = getCurrentUsersPaymentProfile(purchaseRequest.PaymentSettingId),
                    newParams = {
                        correlationId: eventData.correlationId,
                        EventName: EventEmitterCache.EventEnum.CreditService.PaymentMade,
                        Amount: totalCost,
                        AuthorizeNetPaymentProfileId: authorizeNetPaymentProfileId,
                        WhomToBuy: purchaseRequest.WhomToBuy,
                        AuthorizeNetCustomerProfileId: userInfo.UserFinance.AuthorizeNetCustomerProfileId,
                        ClientIPAddress: eventData.payload.params.ClientIPAddress,
                        UserId: userId,
                        MemberId: memberId,
                        GroupId: userInfo.UserContext.CurrentGroupId,
                        CreditQuantity: packTemplate.CreditQuantity,
                        PackTemplate: packTemplate,
                        PurchaseRequest: purchaseRequest,
                        TransactionType: PaymentProfile ? PaymentProfile.Type : null
                    };
                if (PaymentProfile) {
                    if (PaymentProfile.Type === PaymentType.BillMeLater) {
                        BillMeLaterProcessor.BillMePayment(newParams);
                    } else if (PaymentProfile.Type === PaymentType.CreditCard || PaymentProfile.Type === PaymentType.eCheck) {
                        AuthorizeNetProcessor.Transact(newParams);
                    } else {
                        RequestManager.error(eventData.correlationId, 'services.cre.ser.unk');
                    }
                } else {
                    RequestManager.error(eventData.correlationId, 'services.cre.ser.inv');
                }
            },
            onPaymentMade = function (eventData) {
                var userId = userInfo.hgId,
                    memberId = userInfo.UserContext.MemberIdInGroup,
                    packTemplate = eventData.payload.params.PackTemplate,
                    purchaseRequest = eventData.payload.params.PurchaseRequest,
                    whomToBuy = purchaseRequest.WhomToBuy,
                    newParams = {
                        correlationId: eventData.correlationId,
                        EventName: EventEmitterCache.EventEnum.CreditService.PurchaseComplete,
                        UserId: userId,
                        MemberId: memberId,
                        CreditQuantity: eventData.payload.params.TransactionType === TransactionType.eCheck ? 0 : packTemplate.CreditQuantity,
                        WhomToBuy: whomToBuy,
                        PurchaseRequest: purchaseRequest,
                        PaymentResponse: eventData.payload.data,
                        PackTemplate: packTemplate,
                        TransactionType: eventData.payload.params.TransactionType
                    };

                if (!eventData.payload.data || eventData.payload.data.TransactionResult !== 'Approved') {
                    RequestManager.respondToWrappedEvent(eventData);
                } else {
                    CreditAccountProcessor.UpdateCreditForPurchase(newParams);
                }
            },
            onPurchaseComplete = function (eventData) {
                var notificationInternalService = new InternalServiceCache.Notification(eventData.correlationId),
                    TransactionInternalService = new InternalServiceCache.Transaction(eventData.correlationId),
                    purchaseRequest = eventData.payload.params.PurchaseRequest,
                    PaymentResponse = eventData.payload.params.PaymentResponse,
                    packTemplate = eventData.payload.params.PackTemplate,
                    notificationParams = {
                        correlationId: eventData.correlationId,
                        Data: {
                            TransactionId: PaymentResponse.TransactionId,
                            TransactionAmount: packTemplate.Cost,
                            CreditQuantity: packTemplate.CreditQuantity,
                            UserId: userInfo.hgId,
                            PaymentMethod: eventData.payload.params.TransactionType
                        }
                    },
                    accountId = eventData.payload.data.AccountId,
                    Info = userInfo.UserPersonal.FullName + ' purchased ' + packTemplate.CreditQuantity + ' credits for spending account in the amount of $' + packTemplate.Cost + '.',
                    TransStatus = eventData.payload.params.TransactionType === TransactionType.BillMeLater ? TransactionStatus.PendingAvailable : eventData.payload.params.TransactionType === TransactionType.eCheck ? TransactionStatus.Pending : TransactionStatus.Complete,
                    transactionParams = {
                        correlationId: eventData.correlationId,
                        AccountId: accountId,
                        UserId: userInfo.hgId,
                        UserName: userInfo.UserPersonal.FullName,
                        FirstName: userInfo.UserPersonal.FirstName,
                        LastName: userInfo.UserPersonal.LastName,
                        GroupId: userInfo.UserContext.CurrentGroupId,
                        GroupName: userInfo.UserContext.CurrentGroupName,
                        CreditQuantity: packTemplate.CreditQuantity,
                        Status: TransStatus,
                        ReferenceId: PaymentResponse.TransactionId,
                        Type: eventData.payload.params.TransactionType,
                        Info: Info
                    },
                    pusherParams = {
                        CreditAmount: eventData.payload.params.CreditQuantity,
                        AccountType: (eventData.payload.params.WhomToBuy === 'Myself') ? 'spend' : 'transfer',
                        UserId: eventData.payload.params.UserId
                    };
                if (pusherParams.CreditAmount !== 0) {
                    PusherManager.CreditsUpdated(pusherParams);
                }

                if (eventData.payload.params.TransactionType === PaymentType.BillMeLater) {
                    notificationParams.NotificationEvent = NotificationsEnums.Event.CreditBillMeLater.Name;
                } else {
                    notificationParams.NotificationEvent = NotificationsEnums.Event.CreditPurchased.Name;
                }

                if (purchaseRequest.WhomToBuy === 'MyGroup') {
                    transactionParams.Info = userInfo.UserPersonal.FullName + ' purchased ' + packTemplate.CreditQuantity + ' credits for group ' + userInfo.UserContext.CurrentGroupName + ' in the amount of $' + packTemplate.Cost + '.';
                }
                TransactionInternalService.SaveTransaction_Internal(transactionParams, function (err, data) {
                    if (err) {
                        HgLog.error(err);
                    }
                    if (data) {
                        notificationParams.Data.TransactionId = data.FriendlyId;
                        notificationInternalService.NotifyQueue(notificationParams);
                    }
                });
                if (eventData.payload.data) {
                    RequestManager.send(eventData.correlationId, 'services.cre.ser.pur');
                } else {
                    RequestManager.respondToWrappedEvent(eventData);
                }
            };

        this.PurchaseCredit = function (params) {
            var newparams = {
                    correlationId: params.correlationId,
                    UserId: userInfo.hgId,
                    EventName: EventEmitterCache.EventEnum.CreditService.LoadPackTemplateComplete,
                    MemberId: userInfo.UserContext.MemberIdInGroup,
                    PackTemplateId: params.req.body.PackTemplateId,
                    PurchaseRequest:  {
                        WhomToBuy: params.req.body.WhomToBuy,
                        PackTemplateId: params.req.body.PackTemplateId,
                        PaymentSettingId: params.req.body.PaymentSettingId
                    },
                    ClientIPAddress: params.req.connection.remoteAddress
                };
            EventResponder.RespondGeneric(EventEmitterCache, newparams, null, params.req.body);
        };

        this.TransferCreditGive = function (params) {
            var creditAccountInternalService = new InternalServiceCache.CreditAccount(params.correlationId),
                currentUser = params.currentuser,
                newParams = {
                    correlationId: params.correlationId,
                    AccountType: AccountType.Transfer,
                    OwnerId: currentUser.UserContext.MemberIdInGroup,
                    TotalCredit: 0,
                    Recipients: EntityCache.TransferCreditRequest(params.req.body).recipients, // This is so we can get rid of the context data cache later. Not being used yet --Demetri
                    OperationType: 'TransferCredit',
                    UserId: currentUser.hgId,
                    GroupId: currentUser.UserContext.CurrentGroupId,
                    MemberId: currentUser.UserContext.MemberIdInGroup,
                    UserInfo: currentUser
                };
            creditAccountInternalService.TransferCreditsPeers(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };
        this.TransferCreditSpend = function (params) {
            var creditAccountInternalService = new InternalServiceCache.CreditAccount(params.correlationId),
                currentUser = params.currentuser,
                newParams = {
                    correlationId: params.correlationId,
                    AccountType: AccountType.Spend,
                    OwnerId: currentUser.hgId,
                    TotalCredit: 0,
                    Recipients: EntityCache.TransferCreditRequest(params.req.body).recipients, // This is so we can get rid of the context data cache later. Not being used yet --Demetri
                    OperationType: 'TransferCredit',
                    UserId: currentUser.hgId,
                    GroupId: currentUser.UserContext.CurrentGroupId,
                    MemberId: currentUser.UserContext.MemberIdInGroup,
                    UserInfo: currentUser
                };
            creditAccountInternalService.TransferCreditsPeers(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };
        this.GetCreditAccountByOwnerIdAndAccontType_Internal = function (params, callback) {
            if (!ParamUtil.checkForRequiredParameters(['OwnerId', 'AccountType'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            CreditAccountProcessor.GetCreditAccountByOwnerId({
                correlationId: params.correlationId,
                OwnerId: params.OwnerId,
                AccountType: params.AccountType,
                GroupId: params.GroupId
            }, callback);
        };

        function modifyCreditsByAccountId_InternalComplete(eventData) {
            var UserId = eventData.payload.params.UserIdForPusherToNotify,
                CreditAccount = eventData.payload.data,
                Credits = eventData.payload.params.Credits,
                PusherParams;

            if (UserId && (CreditAccount.AccountType === AccountType.Spend || CreditAccount.AccountType === AccountType.Transfer)) {
                PusherParams = {
                    CreditAmount: Credits,
                    AccountType: CreditAccount.AccountType === AccountType.Spend ? 'spend' : 'transfer',
                    UserId: UserId
                };
                PusherManager.CreditsUpdated(PusherParams);
            }
            EventResponder.CompleteCallbackRequest(eventData);
        }

        this.DeductCreditsByAccountId_Internal = function (params, callback) {
            var TransactionInternalService = new InternalServiceCache.Transaction(params.correlationId),
                requiredParameters = ['AccountId', 'Credits', 'UserId', 'UserName', 'FirstName', 'LastName', 'GroupId', 'GroupName'],
                newParams = {
                    correlationId: params.correlationId,
                    EventName: EventEmitterCache.EventEnum.CreditService.DeductCreditsByAccountIdComplete,
                    Callback: callback,
                    AccountId: params.AccountId,
                    Credits: params.Credits,
                    UserIdForPusherToNotify: params.UserIdForPusherToNotify
                },
                transactionParams;
            if (ParamUtil.checkForRequiredParameters(requiredParameters, params)) {
                transactionParams = {
                    correlationId: params.correlationId,
                    AccountId: params.AccountId,
                    UserId: params.UserId,
                    UserName: params.UserName,
                    FirstName: params.FirstName,
                    LastName: params.LastName,
                    GroupId: params.GroupId,
                    GroupName: params.GroupName,
                    CreditQuantity: -params.Credits,
                    Status: TransactionStatus.Complete,
                    Type: TransactionType.Redemption,
                    Info: params.TransactionInfo
                };
                //Note: Need to save transaction only if credit deduction completes. -Demetri
                TransactionInternalService.SaveTransaction_Internal(transactionParams, function (saveTransactionError) {
                    if (!saveTransactionError) {
                        CreditAccountProcessor.DeductCreditsByAccountId(newParams);
                    } else {
                        callback(saveTransactionError);
                    }
                });
            } else {
                callback(HgError.Enums.Generic.MissingParameters);
            }
        };
        this.DeductCreditsByOwnerIdAndAccountType_Internal = function (params, callback) {
            var requiredParameters = ['OwnerId', 'AccountType', 'Credits', 'UserId', 'UserName', 'FirstName', 'LastName', 'GroupId', 'GroupName'];
            if (!ParamUtil.checkForRequiredParameters(requiredParameters, params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            this.GetCreditAccountByOwnerIdAndAccontType_Internal(params, function (errorGettingAccount, Account) {
                if (errorGettingAccount) {
                    return callback(errorGettingAccount);
                }
                self.DeductCreditsByAccountId_Internal({
                    correlationId: params.correlationId,
                    AccountId: Account.hgId,
                    Credits: params.Credits,
                    UserId: params.UserId,
                    UserName: params.UserName,
                    FirstName: params.FirstName,
                    LastName: params.LastName,
                    GroupId: params.GroupId,
                    GroupName: params.GroupName,
                    UserIdForPusherToNotify: params.UserIdForPusherToNotify,
                    TransactionInfo: params.TransactionInfo
                }, callback);
            });
        };

        this.VerifyAccountBalanceByAccountId_Internal = function (params, callback) {
            var verifyBalanceParams = {
                correlationId: params.correlationId,
                EventName: EventEmitterCache.EventEnum.CreditService.GeneralInternalServiceCallComplate,
                Callback: callback,
                AccountId: params.AccountId,
                Credits: params.Credits
            };
            CreditAccountProcessor.VerifyCreditBalanceByAccountId(verifyBalanceParams);
        };

        function onEarmarkCreditsComplete(wrappedEventData) {
            var TransactionInternalService = new InternalServiceCache.Transaction(wrappedEventData.correlationId),
                data = wrappedEventData.payload.data,
                originalParams = wrappedEventData.payload.params,
                callback = wrappedEventData.payload.params.Callback,
                transferTransactionParams;

            if (wrappedEventData.errorMessage !== undefined && wrappedEventData.errorMessage !== null) {
                callback(wrappedEventData.errorMessage, data);
            } else {
                transferTransactionParams = {
                    DebitTransaction: {
                        correlationId: wrappedEventData.correlationId,
                        AccountId: data.SourceAccountId,
                        UserId: originalParams.UserId,
                        UserName: originalParams.UserName,
                        FirstName: originalParams.FirstName,
                        LastName: originalParams.LastName,
                        GroupId: originalParams.GroupId,
                        GroupName: originalParams.GroupName,
                        CreditQuantity: -data.Credits,
                        Status: TransactionStatus.Complete,
                        Type: TransactionType.Transfer,
                        Info: 'Transfering ' + data.Credits + ' credits to earmark account. ' + (originalParams.Notes || '')
                    },
                    CreditTransaction: {
                        correlationId: wrappedEventData.correlationId,
                        AccountId: data.DestinationAccountId,
                        UserId: originalParams.UserId,
                        UserName: originalParams.UserName,
                        FirstName: originalParams.FirstName,
                        LastName: originalParams.LastName,
                        GroupId: originalParams.GroupId,
                        GroupName: originalParams.GroupName,
                        CreditQuantity: data.Credits,
                        Status: TransactionStatus.Complete,
                        Type: TransactionType.Transfer,
                        Info: 'Transfered ' + data.Credits + ' credits from spend/transfer account. ' + (originalParams.Notes || '')
                    }
                };
                TransactionInternalService.SaveTransferTransactions_Internal(transferTransactionParams, function (transactionError, transactionResult) {
                    var pusherParams = {
                            CreditAmount: -data.Credits,
                            AccountType: data.SourceAccountType === AccountType.Spend ? 'spend' : 'transfer',
                            UserId: originalParams.UserId
                        };
                    PusherManager.CreditsUpdated(pusherParams);
                    callback(transactionError, transactionResult);
                });
            }
        }

        function onReverseEarmarkCreditsComplete(wrappedEventData) {
            var TransactionInternalService = new InternalServiceCache.Transaction(wrappedEventData.correlationId),
                data = wrappedEventData.payload.data,
                originalParams = wrappedEventData.payload.params,
                callback = wrappedEventData.payload.params.Callback,
                transferTransactionParams;

            if (wrappedEventData.errorMessage !== undefined && wrappedEventData.errorMessage !== null) {
                callback(wrappedEventData.errorMessage, data);
            } else {
                transferTransactionParams = {
                    DebitTransaction: {
                        correlationId: wrappedEventData.correlationId,
                        AccountId: data.SourceAccountId,
                        UserId: originalParams.UserId,
                        UserName: originalParams.UserName,
                        FirstName: originalParams.FirstName,
                        LastName: originalParams.LastName,
                        GroupId: originalParams.GroupId,
                        GroupName: originalParams.GroupName,
                        CreditQuantity: -data.Credits,
                        Status: TransactionStatus.Complete,
                        Type: TransactionType.Transfer,
                        Info: 'Transfering ' + data.Credits + ' credits to spend/transfer account. ' + (originalParams.Notes || '')
                    },
                    CreditTransaction: {
                        correlationId: wrappedEventData.correlationId,
                        AccountId: data.DestinationAccountId,
                        UserId: originalParams.UserId,
                        UserName: originalParams.UserName,
                        FirstName: originalParams.FirstName,
                        LastName: originalParams.LastName,
                        GroupId: originalParams.GroupId,
                        GroupName: originalParams.GroupName,
                        CreditQuantity: data.Credits,
                        Status: TransactionStatus.Complete,
                        Type: TransactionType.Transfer,
                        Info: 'Transfered ' + data.Credits + ' credits from earmark account. ' + (originalParams.Notes || '')
                    }
                };
                TransactionInternalService.SaveTransferTransactions_Internal(transferTransactionParams, function (transactionError, transactionResult) {
                    var pusherParams = {
                            CreditAmount: data.Credits,
                            AccountType: data.DestinationAccountType === AccountType.Spend ? 'spend' : 'transfer',
                            UserId: originalParams.UserId
                        };
                    PusherManager.CreditsUpdated(pusherParams);
                    callback(transactionError, transactionResult);
                });
            }
        }

        this.EarmarkCreditsByOwnerIdAndType_Internal = function (params, callback) {
            var requiredParameters = ['OwnerId', 'AccountType', 'Credits', 'UserId', 'UserName', 'FirstName', 'LastName', 'GroupId', 'GroupName'];
            if (!ParamUtil.checkForRequiredParameters(requiredParameters, params)) {
                return callback('server.hge.gnr.spa');
            }
            CreditAccountProcessor.EarmarkCreditsByOwnerIdAndAccountType({
                correlationId: params.correlationId,
                EventName: EventEmitterCache.EventEnum.CreditService.EarmarkCreditsByOwnerIdAndTypeComplete,
                Callback: callback,
                AccountType: params.AccountType,
                OwnerId: params.OwnerId,
                Credits: params.Credits,
                UserId: params.UserId,
                UserName: params.UserName,
                FirstName: params.FirstName,
                LastName: params.LastName,
                GroupId: params.GroupId,
                GroupName: params.GroupName,
                Notes: params.Notes
            });
        };

        this.ReverseEarmarkCreditsByOwnerIdAndType_Internal = function (params, callback) {
            var requiredParameters = ['OwnerId', 'AccountType', 'Credits', 'UserId', 'UserName', 'FirstName', 'LastName', 'GroupId', 'GroupName'];
            if (!ParamUtil.checkForRequiredParameters(requiredParameters, params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            CreditAccountProcessor.ReverseEarmarkCreditsByOwnerIdAndAccountType({
                correlationId: params.correlationId,
                EventName: EventEmitterCache.EventEnum.CreditService.ReverseEarmarkCreditsByOwnerIdAndTypeComplete,
                Callback: callback,
                AccountType: params.AccountType,
                OwnerId: params.OwnerId,
                Credits: params.Credits,
                UserId: params.UserId,
                UserName: params.UserName,
                FirstName: params.FirstName,
                LastName: params.LastName,
                GroupId: params.GroupId,
                GroupName: params.GroupName,
                Notes: params.TransactionNotes
            });
        };

        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.VerifyGroupTransferSettingComplete, onVerifyGroupTransferSettingComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.VerifyCreditBalanceComplete, onVerifyCreditBalanceComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.TransferCreditComplete, onTransferCreditComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.LoadPackTemplateComplete, onLoadPackTemplateComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.PaymentMade, onPaymentMade);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.PurchaseComplete, onPurchaseComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.GeneralServiceCallComplate, onGeneralServiceCallComplate);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.GeneralInternalServiceCallComplate, EventResponder.CompleteCallbackRequest);

        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.EarmarkCreditsByAccountIdComplete, onEarmarkCreditsComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.EarmarkCreditsByOwnerIdAndTypeComplete, onEarmarkCreditsComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.ReverseEarmarkCreditsByOwnerIdAndTypeComplete, onReverseEarmarkCreditsComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.DeductCreditsByAccountIdComplete, modifyCreditsByAccountId_InternalComplete);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.DeductCreditsByOwnerIdAndAccountTypeComplete, EventResponder.CompleteCallbackRequest);
        EventEmitterCache.on(EventEmitterCache.EventEnum.CreditService.GetCreditAccountByOwnerIdAndAccontTypeComplete, EventResponder.CompleteCallbackRequest);

    };

module.exports = CreditService;