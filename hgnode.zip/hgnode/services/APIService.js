var HgBaseService = require('../framework/HgService'),
    APIService = function () {
        "use strict";
        HgBaseService.apply(this, arguments);
        var RequestManager = this.RequestManager,
            InternalServiceCache = this.InternalServiceCache,
            APISettingsDataContract = require('./datacontract/APISettings.js').APISettings,
            DTOUtil = require('../util/DTOUtil.js');

        this.GetAPIKeys = function (params) {
            var apiInternalService = new InternalServiceCache.API(params.correlationId);
            apiInternalService.GetAPIKeys({
                correlationId: params.correlationId,
                GroupId: params.currentuser.UserContext.CurrentGroupId
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, DTOUtil.CreateResponse(data, 'Array', APISettingsDataContract));
                }
            });
        };

        this.CreateAPISettings = function (params) {
            var apiInternalSercice = new InternalServiceCache.API(params.correlationId),
                newParams = {
                    correlationId: params.correlationId,
                    UserId : params.currentuser.hgId,
                    GroupId: params.req.body.GroupId,
                    GroupName: params.req.body.GroupName,
                    AvailableServices: params.req.body.AvailableServices,
                    APIKeyVersion: params.req.body.APIKeyVersion
                };
            apiInternalSercice.CreateAPISettings(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, DTOUtil.CreateResponse(data, 'Object', APISettingsDataContract));
                }
            });
        };

        this.GetClientAPIKeys = function (params) {
            var apiInternalService = new InternalServiceCache.API(params.correlationId);
            apiInternalService.GetAPIKeys({
                correlationId: params.correlationId,
                GroupId: params.req.query.groupId
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, DTOUtil.CreateResponse(data, 'Array', APISettingsDataContract));
                }
            });
        };

        this.UpdateClientAPISettings = function (params) {
            var apiInternalService = new InternalServiceCache.API(params.correlationId),
                newParams = {
                    correlationId: params.correlationId,
                    UserId : params.currentuser.hgId,
                    GroupId: params.req.body.GroupId,
                    GroupName: params.req.body.GroupName,
                    APIKey : params.req.body.APIKey,
                    AvailableServices: params.req.body.AvailableServices,
                    APIKeyVersion: params.req.body.APIKeyVersion,
                    APIKeyStatus: params.req.body.APIKeyStatus
                };
            apiInternalService.UpdateAPISettings(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };

        this.RegenerateAPIKey = function (params) {
            var apiInternalService = new InternalServiceCache.API(params.correlationId),
                newParams = {
                    correlationId: params.correlationId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    UserId : params.currentuser.hgId,
                    APIKey : params.req.body.APIKey
                };
            apiInternalService.RegenerateAPIKey(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };

        this.GetAvailableServices = function (params) {
            var apiInternalService = new InternalServiceCache.API(params.correlationId),
                newParams = {
                    correlationId: params.correlationId,
                    GroupId: params.currentuser.UserContext.CurrentGroupId,
                    UserId : params.currentuser.hgId
                };
            apiInternalService.GetAvailableServices(newParams, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };
    };

module.exports = APIService;