/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    NotificationAuditSchema = new DataContractSchema({
        hgId : {type : String, default : ''},
        Subject : {type : String, default : ''},
        CreatedDate : {type : Number, default: 0},
        RecipientList: [{
            Name: {type : String, default : ''},
            Address: {type : String, default : ''},
            WelcomeBadgePending: {type: Boolean, default: true}
        }],
        TemplateId : {type : Number, default: 0},
        TemplateName : {type : String, default : ''},
        AttemptNumber : {type : Number, default: 0},
        Action : {type : String, enum : ['SuccessfulAndRemove', 'FailedAndRemove', 'Retry', 'ModifyPayload']},
        ServerResponse : {type : String}
    });

exports.NotificationAudit = mongoose.model('NotificationAudit', NotificationAuditSchema, 'NotificationAudit');
