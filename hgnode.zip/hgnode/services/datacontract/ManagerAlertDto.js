/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DateHelper = require('../../util/DateHelper.js'),
    EntityEnums = require('../../enums/EntityEnums.js'),
    FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    i18nHelper = require('../../helpers/i18nHelper.js'),
    goalMapping = require('../../helpers/translateHelper.js').Goal;

function AlertDecorator(params) {
    var member = params.Member,
        currentUserMemberId = params.CurrentUserMemberId,
        memberId = params.MemberId,
        lang = params.lang,
        tz = params.tz * 60000,
        isDirectManager = currentUserMemberId === memberId ?
                member.MyManagers.filter(function (m) { return m.MemberId === memberId; })[0] : null;

    this.ProfileUpcomingBirthday = function (alert) {
        var localBirthday = DateHelper.convertToLocalDate(alert.Data.Birthday),
            newDate = new Date(new Date().getFullYear(), new Date(localBirthday).getMonth(), new Date(localBirthday).getDate()),
            daysCount = DateHelper.getDaysBetween(newDate, new Date(), tz),
            displayText = i18nHelper.translate(lang, daysCount === 1 ? 'team.action.pub' : 'team.action.pubs', {
                count_days_until_birthday: daysCount
            });
        return {
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText
        };
    };
    this.ProfileUpcomingAnniversary = function (alert) {
        var localAnniversary = DateHelper.convertToLocalDate(alert.Data.Startdate),
            newDate = new Date(new Date().getFullYear(), new Date(localAnniversary).getMonth(), new Date(localAnniversary).getDate()),
            yearsCount = DateHelper.getYearsBetween(new Date(localAnniversary), new Date(), tz),
            displayText;
        if (params.DemoData) {
            displayText = alert.Data.DisplayText;
        } else {
            displayText = i18nHelper.translate(lang, yearsCount === 1 ? 'team.action.pua' : 'team.action.puas', {
                anniversary_date: DateHelper.formatDateStringFromTimestamp(newDate),
                company_name: member.GroupName,
                count_years_since_hire: yearsCount
            });
        }
        return {
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText
        };
    };
    this.PerformPendingReview = function (alert) {
        var displayText = i18nHelper.translate(lang, 'team.action.ppr', {
                cycle_name: alert.Data.CycleName
            }),
            buttonUrl = isDirectManager ? ['/Profile/Perform/', member.UserId, '/', alert.Data.ReviewId].join('') : '',
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, alert.Status === EntityEnums.ManagerAlertStatus.Processing ? 'common.prc' : 'common.compt') : '';
        return {
            hgId: alert.hgId,
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonUrl: buttonUrl,
            ButtonDisplayText: buttonDisplayText
        };
    };
    this.PerformOverDueReview = function (alert) {
        var displayText = i18nHelper.translate(lang, 'team.action.por', {
                cycle_name: alert.Data.CycleName
            }),
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, 'common.rem') : '';
        return {
            hgId: alert.hgId,
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText,
            Data: alert.Data
        };
    };
    this.GoalCreationOverdue = function (alert) {
        var displayText = i18nHelper.translate(lang, 'team.action.gcc', {
                cycle_name: alert.Data.CycleName
            }),
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, 'common.rem') : '';
        return {
            hgId: alert.hgId,
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText,
            Data: alert.Data
        };
    };
    this.GoalPendingCreationApproval = function (alert) {
        var displayText = alert.Data.CycleName ?
                i18nHelper.translate(lang, 'team.action.gpa', {
                    cycle_name: alert.Data.CycleName
                }) :
                i18nHelper.translate(lang, 'team.action.ada', {
                    goal_name: alert.Data.GoalTitle
                }),
            buttonUrl = isDirectManager ? '/Profile/ApproveGoals/' + currentUserMemberId + '/' + member.hgId : '',
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, alert.Status === EntityEnums.ManagerAlertStatus.Processing ? 'common.prc' : 'common.rvw') : '';
        return {
            hgId: alert.hgId,
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText,
            ButtonUrl: buttonUrl
        };
    };
    this.GoalCloseOverdue = function (alert) {
        var displayText = i18nHelper.translate(lang, 'team.action.gco', {
                cycle_name: alert.Data.CycleName
            }),
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, 'common.rem') : '';
        return {
            hgId: alert.hgId,
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText,
            Data: alert.Data
        };
    };
    this.FeedbackCheckInDue = function (alert) {
        var displayText = i18nHelper.translate(lang, 'team.action.fdc', {
                employee_first_name: member.FirstName,
                cycle_name: alert.Data.CycleTitle
            }),
            buttonUrl = isDirectManager ? 'Profile/Feedback/SelfEvalView/' + alert.Data.SessionId : '',
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, 'common.chk') : '';
        return {
            hgId: alert.hgId || '',
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            Category: alert.Category,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText,
            ButtonUrl: buttonUrl,
            Data: alert.Data
        };
    };
    this.GoalPendingCloseApproval = function (alert) {
        var displayText = alert.Data.CycleName ?
                i18nHelper.translate(lang, 'team.action.gpc', {
                    cycle_name: alert.Data.CycleName
                }) :
                i18nHelper.translate(lang, 'team.action.adc', {
                    goal_name: alert.Data.GoalTitle
                }),
            buttonUrl = isDirectManager ? '/Profile/ApproveGoals/' + currentUserMemberId + '/' + member.hgId : '',
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, alert.Status === EntityEnums.ManagerAlertStatus.Processing ? 'common.prc' : 'common.rvw') : '';
        return {
            hgId: alert.hgId,
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText,
            ButtonUrl: buttonUrl
        };
    };
    this.RecognitionLastReceived = function (alert) {
        var displayText = i18nHelper.translate(lang, 'team.action.rlr', {
                count_of_days: alert.Data.LastActivity
            }),
            buttonUrl = '/Recognize/Profile/GiveEveryday/' + member.hgId + '/teamTab',
            buttonDisplayText = i18nHelper.translate(lang, 'common.rec');
        return {
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText,
            ButtonUrl: buttonUrl
        };
    };
    this.RecognitionLastGiven = function (alert) {
        var displayText = i18nHelper.translate(lang, 'team.action.rlg', {
                count_of_days: alert.Data.LastActivity
            }),
            buttonDisplayText = isDirectManager ? i18nHelper.translate(lang, 'common.rem') : '';
        return {
            AlertType: alert.AlertType,
            Severity: alert.Severity,
            DisplayText: displayText,
            ButtonDisplayText: buttonDisplayText
        };
    };
}

function StatsDecorator(member, lang) {

    this.RecognitionsIGave = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.rig'),
            DisplayNumber: stat.count.toString()
        };
    };
    this.RecognitionLastGiven = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.rlg'),
            DisplayDays: (DateHelper.getDaysBetween(new Date(stat.date), new Date())).toString()
        };
    };
    this.RecognitionLastReceived = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.rlr'),
            DisplayDays: (DateHelper.getDaysBetween(new Date(stat.date), new Date())).toString()
        };
    };
    this.RecognitionsIReceived = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.rir'),
            DisplayNumber: stat.count.toString()
        };
    };
    this.CoachingIGave = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.cig'),
            DisplayNumber: stat.count.toString()
        };
    };
    this.CoachingLastGiven = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.clg'),
            DisplayDays: (DateHelper.getDaysBetween(new Date(stat.date), new Date())).toString()
        };
    };
    this.CoachingLastReceived = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.clr'),
            DisplayDays: (DateHelper.getDaysBetween(new Date(stat.date), new Date())).toString()
        };
    };
    this.CoachingIReceived = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.cir'),
            DisplayNumber: stat.count.toString()
        };
    };
    this.FeedbackIReceived = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.fir'),
            DisplayNumber: stat.count.toString()
        };
    };
    this.PerformPendingReview = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.ppr'),
            DisplayNumber: stat.count.toString()
        };
    };
    this.PerformLastReview = function (stat) {
        return {
            DisplayText: i18nHelper.translate(lang, 'team.stats.plr'),
            DisplayDays: (DateHelper.getDaysBetween(new Date(stat.date), new Date())).toString()
        };
    };
}

function getMemberAlerts(params) {
    var alerts = [],
        alertData = params.Alerts.filter(function (alert) { return alert.ReportMemberId === params.Member.hgId; }),
        alertDecorator = new AlertDecorator({
            DemoData: params.DemoData,
            Member:  params.Member,
            Permissions: params.Permissions,
            CurrentUserMemberId: params.CurrentUserMemberId,
            MemberId: params.MemberId,
            lang: params.lang,
            tz: params.tz
        });
    alertData.forEach(function (alert) {
        if (alertDecorator[alert.AlertType]) {
            alerts.push(alertDecorator[alert.AlertType](alert));
        }
    });
    return alerts;
}

function shapeManagerAlerts(params) {
    var result = [],
        memberAlerts,
        directReports,
        countMap = {
            Urgent: 0,
            Warning: 0,
            Upcoming: 0
        };
    params.Data.DirectReports.forEach(function (item) {
        memberAlerts = getMemberAlerts({
            DemoData: params.Data.DemoData,
            Member: item,
            Alerts: params.Data.Alerts,
            Permissions: params.Permissions,
            CurrentUserMemberId: params.CurrentUserMemberId,
            MemberId: params.MemberId,
            lang: params.lang,
            tz: params.tz
        });
        directReports = params.Data.DirectReportCount.filter(function (report) { return report._id[0] === item.hgId; })[0];
        countMap.Urgent = 0;
        countMap.Warning = 0;
        countMap.Upcoming = 0;
        memberAlerts.forEach(function (a) {
            countMap[a.Severity] += 1;
        });
        result.push({
            hgId: item.hgId,
            UserId: item.UserId,
            FirstName: item.FirstName,
            FullName: item.FullName,
            Position: item.Position,
            Managers: item.MyManagers.map(function (manager) {
                return {
                    FullName: manager.FullName || '',
                    UserId: manager.UserId || '',
                    hgId: manager.MemberId || ''
                };
            }),
            Alerts: memberAlerts,
            DirectReportsCount: directReports ? directReports.count : 0,
            Weight: countMap.Urgent * 3 + countMap.Warning * 2 + countMap.Upcoming
        });
    });
    return result.sort(function (a, b) {
        return b.Weight - a.Weight;
    });
}

function getMemberStats(params) {
    var statstData = params.Stats.filter(function (s) { return s.hgId === params.Member.hgId; }),
        statDecorator = new StatsDecorator(params.Member, params.lang),
        stats = [];

    statstData.forEach(function (st) {
        if (statDecorator[st.alertType]) {
            stats.push(statDecorator[st.alertType](st));
        }
    });
    return stats;
}

function shapeStats(params) {
    var directReports;
    return params.DirectReports.map(function (item) {
        directReports = params.DirectReportCount.filter(function (report) { return report._id[0] === item.hgId; })[0];
        return {
            hgId: item.hgId,
            UserId: item.UserId,
            FirstName: item.FirstName,
            FullName: item.FullName,
            Position: item.Position,
            Manager: {
                FullName: item.MyManagers[0] ? item.MyManagers[0].FullName : '',
                UserId: item.MyManagers[0] ? item.MyManagers[0].UserId : '',
                hgId: item.MyManagers[0] ? item.MyManagers[0].MemberId : ''
            },
            Stats: getMemberStats({Member: item, Stats: params.Stats, lang: params.lang}),
            DirectReportsCount: directReports ? directReports.count : 0
        };
    });
}
function shapeTeamAlignedGoals(params) {
    if (!params.Goals || !params.Goals.length) {
        return [];
    }
    var getAlignedStats = function (goalId) {
            var alignedGoal = params.AlignedGoals[goalId];
            return {
                Aligned: {
                    Name: goalMapping.Status.Aligned,
                    Value: alignedGoal ? alignedGoal.OnTrack + alignedGoal.Behind + alignedGoal.AtRisk : 0
                },
                OnTrack: {
                    Name: goalMapping.Status.OnTrack,
                    Value: alignedGoal ? alignedGoal.OnTrack : 0
                },
                Behind: {
                    Name: goalMapping.Status.Behind,
                    Value: alignedGoal ? alignedGoal.Behind : 0
                },
                AtRisk: {
                    Name: goalMapping.Status.AtRisk,
                    Value: alignedGoal ? alignedGoal.AtRisk : 0
                }
            };
        };
    return params.Goals.map(function (item) {
        return {
            hgId: item.hgId,
            Name: item.Name,
            Status: item.ProgressStatus,
            StatusText: goalMapping.Status[item.ProgressStatus] || '',
            Owner: item.Owner.FullName,
            Progress: item.PercentCompletion ? Math.round(item.PercentCompletion * 100) / 100 : 0,
            Updated: item.LastCheckInDate,
            AlignedGoalStats: getAlignedStats(item.hgId),
            AlignedGoal: item.AlignedGoal && item.AlignedGoal.GoalId ? {
                GoalId: item.AlignedGoal.GoalId,
                Name: item.AlignedGoal.Name,
                Type: item.AlignedGoal.ParticipantType
            } : ''
        };
    });
}

function FilterDecorator(lang) {
    var memberMapping = require('../../helpers/translateHelper.js').Member;

    this.Department = function (departments) {
        var depKeys = Object.keys(departments || {});
        return {
            label: 'common.dpt',
            model: 'departmentId',
            isDisplay: depKeys.length > 1,
            data: depKeys.length ? depKeys.map(function (d) {
                return {id: d, name: departments[d]};
            }) : []
        };
    };
    this.Location = function (locations) {
        var locKeys = Object.keys(locations || {});
        return {
            label: 'common.loc',
            model: 'locationId',
            isDisplay: locKeys.length > 1,
            data: locKeys.length ? locKeys.map(function (l) {
                return {id: l, name: locations[l]};
            }) : []
        };
    };
    this.Role = function (roles) {
        var roleKeys = Object.keys(roles || {});
        return {
            label: 'common.rol',
            model: 'levelId',
            isDisplay: roleKeys.length > 1,
            data: roleKeys.length ? roleKeys.map(function (r) {
                return {id: r, name: memberMapping.Role[r]};
            }) : []
        };
    };
    this.Cycle = function (cycles) {
        var cycleKeys = Object.keys(cycles || {});
        return {
            label: 'common.cy',
            model: 'cycleId',
            isDisplay: cycleKeys.length > 1,
            data: cycleKeys.length ? cycleKeys.map(function (c) {
                return {id: c, name: cycles[c]};
            }) : []
        };
    };
}


function shapeGoalFilters(params) {
    var memberMapping = require('../../helpers/translateHelper.js').Member;
    return params.isDisplay ? [
        {
            label: 'common.dpt',
            model: 'departmentId',
            isDisplay: params.departments && Object.keys(params.departments).length && Object.keys(params.departments).length > 1,
            data: params.departments ? Object.keys(params.departments).map(function (d) {
                return {id: d, name: params.departments[d]};
            }) : []
        },
        {
            label: 'common.loc',
            model: 'locationId',
            isDisplay: params.locations && Object.keys(params.locations).length && Object.keys(params.locations).length > 1,
            data: params.locations ? Object.keys(params.locations).map(function (l) {
                return {id: l, name: params.locations[l]};
            }) : []
        },
        {
            label: 'common.rol',
            model: 'levelId',
            isDisplay: params.roles && Object.keys(params.roles).length && Object.keys(params.roles).length > 1,
            data: params.roles ? Object.keys(params.roles).map(function (r) {
                return {id: r, name: memberMapping.Role[r]};
            }) : []
        },
        {
            label: 'common.cy',
            model: 'cycleId',
            isDisplay: params.cycles && Object.keys(params.cycles).length && Object.keys(params.cycles).length > 1,
            data: params.cycles ? Object.keys(params.cycles).map(function (c) {
                return {id: c, name: params.cycles[c]};
            }) : []
        },
        {
            label: 'admin.gls.db.gt',
            model: 'goalType',
            isDisplay: params.goalTypes && Object.keys(params.goalTypes).length && Object.keys(params.goalTypes).length > 1,
            data: params.goalTypes ? Object.keys(params.goalTypes).map(function (g) {
                return {id: g, name: goalMapping.Type[g]};
            }) : []
        }
    ] : [];
}

function shapeCheckinFilters(params, lang) {
    var filterDecorator = new FilterDecorator(lang);
    return [
        filterDecorator.Department(params.departments),
        filterDecorator.Location(params.locations),
        filterDecorator.Role(params.roles),
        filterDecorator.Cycle(params.cycles)
    ];
}

function shapeCheckins(data) {
    var subject;
    if (!data.count && !data.checkins.length) {
        return data;
    }
    data.checkins = data.checkins.map(function (checkin) {
        subject = checkin.Participants.find(function (p) { return p.ParticipantType === FeedbackEnums.SessionParticipantType.Subject; });
        return {
            CycleId: checkin.hgId,
            Owner: subject ? subject.FullName : '',
            OwnerMemberId: subject ? subject.MemberId : '',
            CycleTitle: checkin.CycleTitle,
            Department: subject ? subject.DepartmentName : '',
            DueDate: subject ? subject.DueDate : '',
            Submitted: subject ? subject.SubmittedDate : '',
            Archived: checkin.ArchiveDate,
            Completed: subject ? subject.SubmittedDate : ''
        };
    });
    return data;
}
function shapeCheckinStats(data) {
    var vData = {
        Completed: 0,
        NeedsYourAction: 0,
        WaitingOnEmployee: 0,
        Archived: 0
    },
        total = 0;

    if (!data.length) {
        return vData;
    }
    data.forEach(function (item) {
        if (item._id.status === FeedbackEnums.SessionStatus.Submitted) {
            vData.NeedsYourAction += item.count;
        }
        if ([FeedbackEnums.SessionStatus.NotStarted,
                FeedbackEnums.SessionStatus.InProgress,
                FeedbackEnums.SessionStatus.Overdue].indexOf(item._id.status) > -1) {
            vData.WaitingOnEmployee += item.count;
        }
        if (item._id.status === FeedbackEnums.SessionStatus.PendingSignOff && item.count) {
            item.p.forEach(function (participant) {
                if (participant.participantStatus !== FeedbackEnums.SessionParticipantStatus.SignedOff && participant.NeedsSignOff) {
                    if (participant.participantType === FeedbackEnums.SessionParticipantType.Subject) {
                        vData.WaitingOnEmployee += 1;
                    } else if (participant.participantType === FeedbackEnums.SessionParticipantType.Reviewer) {
                        vData.NeedsYourAction += 1;
                    }
                }
            });
        }
        if (item._id.status === FeedbackEnums.SessionStatus.Completed) {
            vData.Completed += item.count;
        }
        if ([FeedbackEnums.SessionStatus.Expired,
                FeedbackEnums.SessionStatus.Archived].indexOf(item._id.status) > -1) {
            vData.Archived += item.count;
        }
        total += item.count;
    });
    return {
        Completed: Math.round(vData.Completed / total * 100),
        NeedsYourAction: Math.round(vData.NeedsYourAction / total * 100),
        WaitingOnEmployee: Math.round(vData.WaitingOnEmployee / total * 100),
        Archived: Math.round(vData.Archived / total * 100)
    };
}

module.exports = {
    shapeStats: shapeStats,
    shapeManagerAlerts: shapeManagerAlerts,
    shapeTeamAlignedGoals: shapeTeamAlignedGoals,
    shapeGoalFilters: shapeGoalFilters,
    shapeCheckinFilters: shapeCheckinFilters,
    shapeCheckins: shapeCheckins,
    shapeCheckinStats: shapeCheckinStats
};
