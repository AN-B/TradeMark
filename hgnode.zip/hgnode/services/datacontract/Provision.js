/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    ConfirmationSchema = new DataContractSchema({
        Id: {type: String},
        Type: {type: String},
        Company: {type: String},
        GroupId: {type: String},
        Notes: [{type: String}]
    }),
    ConfirmationModel = mongoose.model('Confirmation', ConfirmationSchema);

function defaultDocucment(params) {
    var data = new ConfirmationModel({
        Id: params._id,
        Type: params.Type,
        Company: params.Content.Company.Name,
        GroupId: params.GroupId
    });
    return data;
}
function ConfirmationDecorator() {
    this.Onboard = function (params) {
        var data = defaultDocucment(params);
        data.Notes.unshift(params.Content.Company.Name + ' Company will be  Added.');
        return data;
    };
    this.OffBoard = function (params) {
        var data = defaultDocucment(params);
        data.Notes.push('Users Status will be changed from Active to Off-Boarded. They will also be removed from their current respective Teams and Departments.');
        return data;
    };
    this.Update = function (params) {
        return defaultDocucment(params);
    };
}

function GetConfirmationDTO(data) {
    var confirmation = new ConfirmationDecorator();
    return confirmation[data.Type](data);
}

exports.GetConfirmationDTO = GetConfirmationDTO;

