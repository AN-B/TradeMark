/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    Enums = require('../../enums/EntityEnums.js'),

    MemberSubordinateSchema = new DataContractSchema({
        hgId : {type : String},
        FullName: {type : String, default : ''},
        UserId : {type : String}
    }),
    RecentlyOnBoardedMemberSchema = new DataContractSchema({
        hgId : {type : String},
        FullName: {type : String, default : ''},
        EmployeeId : {type : String}
    }),
    GetEditableMemberRecord =  function (params) {
        return {
            GroupId: params.Member.GroupId,
            hgId: params.Member.hgId,
            MyManagers: params.Member.MyManagers,
            FirstName: params.Member.FirstName,
            LastName: params.Member.LastName,
            FullName: params.Member.FullName,
            RolesInGroup: params.Member.RolesInGroup,
            GroupDepartmentName: params.Member.GroupDepartmentName,
            GroupDepartmentId: params.Member.GroupDepartmentId,
            EmployeeId: params.Member.EmployeeId,
            Position: params.Member.Position,
            StartingDate: params.Member.StartingDate,
            Birthdate: params.Member.Birthdate,
            EndingDate: params.Member.EndingDate,
            UserId: params.Member.UserId,
            UserName: params.UserInfo.UserName,
            MembershipStatus : params.Member.MembershipStatus,
            PrimaryEmail: params.UserInfo.UserPersonal.PrimaryEmail,
            Location : params.Member.Location,
            HomeZip: params.UserInfo.Preference.HomeZip,
            WorkZip: params.UserInfo.Preference.WorkZip
        };
    },
    GetProfileExcerpt =  function (userDetails) {
        if (!userDetails) {
            return {};
        }
        var manager = (userDetails &&
                userDetails.MyManagers &&
                userDetails.MyManagers.length) ? userDetails.MyManagers[0] : {};
        return {
            userId: userDetails.UserId,
            fullName: userDetails.FullName,
            Position: userDetails.Position,
            PrimaryEmail: userDetails.PrimaryEmail,
            GroupDepartmentName: userDetails.GroupDepartmentName,
            GroupDepartmentId: userDetails.GroupDepartmentId,
            Manager: manager.FullName || '',
            ManagerId: manager.MemberId || '',
            MemberId: userDetails.hgId,
            MembershipStatus : userDetails.MembershipStatus
        };
    },
    MapSsd = function (members) {
        return members.map(function (m) {
            return {
                Id: m.hgId,
                Name: m.FullName,
                UserId: m.UserId,
                AvatarId: m.UserId,
                Description: m.GroupDepartmentName,
                Type: 'Member'
            };
        });
    },
    GetProfileMemberRecord = function (params, memberId) {
        return {
            hgId: params.Member.hgId,
            UserId: params.Member.UserId,
            FullName: params.Member.FullName,
            Position: params.Member.Position,
            PrimaryEmail: params.UserInfo.UserPersonal.PrimaryEmail,
            GroupDepartmentName: params.Member.GroupDepartmentName,
            GroupDepartmentId: params.Member.GroupDepartmentId,
            MyManagers: params.Member.MyManagers,
            MembershipStatus: params.Member.MembershipStatus,
            GroupName: params.Member.GroupName,
            LoggedInMember: params.Member.hgId === memberId,
            ViewerManager: params.Member.AccessMode && Enums.ProfileAccess.None !== params.Member.AccessMode
        };
    },
    GetMergeMemberAcct = function (params) {
        return {
            GroupId: params.Member.GroupId,
            Id: params.Member.hgId,
            FullName: params.Member.FullName,
            Role: params.Member.RolesInGroup.length ? params.Member.RolesInGroup[0] : '',
            Department: params.Member.GroupDepartmentName,
            UserId: params.Member.UserId,
            MembershipStatus: params.Member.MembershipStatus,
            UserName: params.UserInfo.UserName,
            PrimaryEmail: params.UserInfo.UserPersonal.PrimaryEmail
        };
    };
module.exports = {
    GetProfileMemberRecord: GetProfileMemberRecord,
    GetEditableMemberRecord: GetEditableMemberRecord,
    MemberSubordinate: mongoose.model('MemberSubordinate', MemberSubordinateSchema, 'MemberSubordinate'),
    RecentlyOnBoardedMember: mongoose.model('RecentlyOnBoardedMember', RecentlyOnBoardedMemberSchema, 'RecentlyOnBoardedMember'),
    GetProfileExcerpt: GetProfileExcerpt,
    MapSsd: MapSsd,
    GetMergeMemberAcct: GetMergeMemberAcct
};
