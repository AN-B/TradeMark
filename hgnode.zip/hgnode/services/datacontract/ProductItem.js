/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    ProductItemSchema = new DataContractSchema({
        hgId: {type : String, default: ''},
        Name: {type : String, default: ''},
        Description : {type : String, default: ''},
        PointCost : {type : Number, default: 0},
        AvailableNumber : {type : Number, default : 0},
        FriendlyGroupId: {type : Number, default: -1},
        ExpireDate: {type: Number},
        GroupId : {type : String, default: ''},
        Status: {type: String, default: ''},
        Period: {type: String, default: ''},
        RedeemInstruction : {type : String, default: ''},
        ProductImageFile: {type: String, default: ''},
        CreatedDate: {type: Number},
        ProductType :  {type: String, default: ''},
        CampaignItem : {
            Backers: [
                {
                    MemberId: {type: String},
                    UserId: {type: String},
                    FullName: {type: String},
                    PledgePoint: {type: Number}
                }
            ],
            FundingGoal: {type: Number, default: 0},
            PledgedPrice: {type: Number, default: 0},
            SuccessFullyFundedDate: {type: Number},
            FundedPercentage: {type: Number, default: 0},
            DaysToGo: {type: Number, default: 0}
        },
        Accessibility : {
            RestrictByLocation : {type : Boolean, default: false},
            Locations : [{
                hgId: {type: String},
                Name: {type: String}
            }],
            RestrictByDept : {type : Boolean, default: false},
            Departments : [{
                hgId: {type: String},
                Name: {type: String}
            }]
        },
        Owner: {
            MemberId : {type : String, default: ''},
            UserId : {type : String, default: ''}
        },
        SuggestedBy: {
            FullName : {type : String, default: ''},
            Email : {type : String, default: ''}
        },
        Tags: [{
            TagId: {type: String},
            TagName: {type: String}
        }]
    }),
    ProductItem = mongoose.model('ProductItem', ProductItemSchema),
    MapSsd = function (tags) {
        return tags.map(function (m) {
            return {
                Id: m.hgId,
                Name: m.Name,
                Type: 'Member'
            };
        });
    };


exports.ProductItem = ProductItem;
exports.MapSsd = MapSsd;