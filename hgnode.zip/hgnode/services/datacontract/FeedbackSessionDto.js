/*jslint node:true es5:true*/
'use strict';
var FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    Enums = require('../../enums/EntityEnums.js'),
    HgLog = require('../../framework/HgLog'),
    GoalDto = require('./GoalDto.js'),
    postSubmitStatus = [
        FeedbackEnums.SessionStatus.Submitted,
        FeedbackEnums.SessionStatus.PendingSignOff,
        FeedbackEnums.SessionStatus.Completed,
        FeedbackEnums.SessionStatus.Closed
    ],
    selfEvalFcStatus = [
        FeedbackEnums.SessionStatus.NotStarted,
        FeedbackEnums.SessionStatus.InProgress,
        FeedbackEnums.SessionStatus.Submitted,
        FeedbackEnums.SessionStatus.PendingSignOff,
        FeedbackEnums.SessionStatus.Completed,
        FeedbackEnums.SessionStatus.Archived,
        FeedbackEnums.SessionStatus.Closed
    ],
    reviwerFcStatus = [
        FeedbackEnums.SessionStatus.NotStarted,
        FeedbackEnums.SessionStatus.InProgress,
        FeedbackEnums.SessionStatus.Submitted,
        FeedbackEnums.SessionStatus.PendingSignOff,
        FeedbackEnums.SessionStatus.Completed,
        FeedbackEnums.SessionStatus.Closed
    ],
    getAboutMembers = function (session) {
        return session.CycleType !== FeedbackEnums.CycleType.EvaluateOthers ? [] : session.Participants.filter(function (participant) {
            return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
        }).map(function (m) {
            return {
                FullName: m.FullName,
                UserId: m.UserId,
                hgId: m.MemberId
            };
        });
    },
    getQuestionDto = function (params) {
        var questions = params.Questions,
            includeManagerNotes = params.AccessMode === FeedbackEnums.SessionAccessMode.Reviewer ||
                params.AccessMode === FeedbackEnums.SessionAccessMode.Manager ||
                (params.AccessMode === FeedbackEnums.SessionAccessMode.Subject && params.ShowManagerNotes && params.SessionStatus === FeedbackEnums.SessionStatus.Completed);
        return questions.map(function (question) {
            return {
                hgId: question.hgId,
                Question: question.Question,
                QuestionHelp: question.QuestionHelp,
                Type: question.Type,
                Required: question.Required,
                OptionalComment: question.OptionalComment,
                Comment: question.Comment,
                Answer: question.Answers[0] || {},
                AnswerSelector: question.AnswerSelector,
                NotApplicableOptionText: question.NotApplicableOptionText,
                NotApplicableOption: question.NotApplicableOption,
                AnsweredDate: question.AnsweredDate,
                SortOrder: question.SortOrder,
                ManagerNotes: includeManagerNotes ? question.ManagerNotes : [],
                MinRange: question.MinRange,
                MaxRange: question.MaxRange
            };
        });
    },
    commonGetSessionById = function (data) {
        var session = data.Session,
            getTabs = function (data) {
                var i = 0,
                    sections = data.Sections || [],
                    tab = {},
                    len;
                for (i = 0, len = sections.length; i < len; i += 1) {
                    if (!tab[sections[i].Title]) {
                        tab[sections[i].Title] = {
                            sectionIds: [],
                            sectionIndex: 1,
                            subTabCount: 0,
                            index: i
                        };
                    }
                    tab[sections[i].Title].name = sections[i].Title;
                    tab[sections[i].Title].subTabCount += 1;
                    tab[sections[i].Title].sectionIds.push({
                        hgId: sections[i].hgId
                    });
                }
                return Object.keys(tab).map(function (item) {
                    return tab[item];
                });
            },
            managerNoteReleased = function () {
                if (!session.ShowManagerNotes) {
                    return false;
                }
                return session.Status === FeedbackEnums.SessionStatus.Completed ||
                    (session.Status === FeedbackEnums.SessionStatus.PendingSignOff && session.Participants.some(function (p) {
                        return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer && p.Status === FeedbackEnums.SessionParticipantStatus.SignedOff;
                    }));
            },
            shapeCard = function () {
                var flattenCard = function (card) {
                    if ([FeedbackEnums.CycleType.Request, FeedbackEnums.CycleType.EvaluateOthers, FeedbackEnums.CycleType.Give].indexOf(session.CycleType) === -1) {
                        var participant = session.Participants.find(function (p) {
                                return [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(p.ParticipantType) !== -1;
                            }),
                            memberId = participant ? participant.MemberId : '',
                            notes;
                        card.Sections.forEach(function (section) {
                            section.Questions.forEach(function (question) {
                                if (!question.Answers.length) {
                                    question.Answer = {};
                                } else {
                                    var ans = question.Answers.filter(function (answer) {
                                        return answer.MemberId === memberId;
                                    });
                                    question.Answer = ans.length ? ans[0] : {};
                                }
                                notes = question.ManagerNotes || [];
                                if (data.PrintPdf) {
                                    question.PdfManagerNotes = [];
                                    if ([FeedbackEnums.SessionAccessMode.Reviewer, FeedbackEnums.SessionAccessMode.Manager, FeedbackEnums.SessionAccessMode.Requester].indexOf(data.AccessMode) > -1 ||
                                            (data.AccessMode === FeedbackEnums.SessionAccessMode.Subject && data.Session.Status === FeedbackEnums.SessionStatus.Completed && data.Session.ShowManagerNotes) ||
                                            [Enums.ProfileAccess.Admin, Enums.ProfileAccess.Manager].indexOf(data.ProfileAccessMode) > -1) {
                                        question.PdfManagerNotes = notes;
                                    }
                                }
                                if (data.IsDirectManager) {
                                    question.MyManagerNotes = [];
                                    question.ManagerNotes = [];
                                    notes.forEach(function (item) {
                                        if (item.MemberId === data.ViewerMemberId) {
                                            question.MyManagerNotes.push(item);
                                        } else {
                                            question.ManagerNotes.push(item);
                                        }
                                    });
                                    question.MyManagerNotes = question.MyManagerNotes.length ? question.MyManagerNotes[0].Notes : '';
                                    question.ManagerView = !!question.MyManagerNotes;
                                }
                                if (data.AccessMode === FeedbackEnums.SessionAccessMode.Subject) {
                                    if (managerNoteReleased()) {
                                        question.ManagerNotes = notes;
                                    } else {
                                        question.ManagerNotes = [];
                                    }
                                }
                            });
                        });
                        card.Tabs = getTabs(card);
                        return card;
                    }
                    return {
                        hgId: card.hgId,
                        Title: card.Title,
                        Sections: card.UseSections ? card.Sections.map(function (section) {
                            return {
                                Title: section.Title,
                                Description: section.Description,
                                hgId: section.hgId,
                                Questions: getQuestionDto({
                                    Questions: section.Questions,
                                    AccessMode: data.AccessMode,
                                    SessionStatus: data.Session.Status,
                                    ShowManagerNotes: data.Session.ShowManagerNotes
                                })
                            };
                        }) : [],
                        Questions: !card.UseSections && card.Sections && card.Sections.length ? getQuestionDto({
                            Questions: card.Sections[0].Questions,
                            AccessMode: data.AccessMode,
                            SessionStatus: data.Session.Status,
                            ShowManagerNotes: data.Session.ShowManagerNotes
                        }) : {
                            Questions: []
                        },
                        SinglePageQuestion: card.SinglePageQuestion,
                        UseSections: card.UseSections
                    };
                };
                if (data.AccessMode === FeedbackEnums.SessionAccessMode.Manager) {
                    return flattenCard(data.Session.Card);
                }
                if (data.AccessMode === FeedbackEnums.SessionAccessMode.Requester && postSubmitStatus.indexOf(session.Status) > -1) {
                    return flattenCard(data.Session.Card);
                }
                if (data.AccessMode === FeedbackEnums.SessionAccessMode.Subject) {
                    if (postSubmitStatus.indexOf(session.Status) > -1 && [FeedbackEnums.CycleType.Request,  FeedbackEnums.CycleType.EvaluateOthers, FeedbackEnums.CycleType.Give].indexOf(session.CycleType) !== -1) {
                        return flattenCard(data.Session.Card);
                    }
                    if (selfEvalFcStatus.indexOf(session.Status) > -1 && session.CycleType === FeedbackEnums.CycleType.SelfEvaluation) {
                        return flattenCard(data.Session.Card);
                    }
                    return {};
                }
                if (data.AccessMode === FeedbackEnums.SessionAccessMode.Reviewer) {
                    if (reviwerFcStatus.indexOf(session.Status) > -1 && [FeedbackEnums.CycleType.Request,  FeedbackEnums.CycleType.EvaluateOthers, FeedbackEnums.CycleType.Give].indexOf(session.CycleType) !== -1) {
                        return flattenCard(data.Session.Card);
                    }
                    if (selfEvalFcStatus.indexOf(session.Status) > -1 && session.CycleType === FeedbackEnums.CycleType.SelfEvaluation) {
                        return flattenCard(data.Session.Card);
                    }
                    return {};
                }
            },
            getRequestNote = function () {
                return data.Session.RequestNote;
            },
            getSubjectRating = function () {
                if ([
                        FeedbackEnums.SessionAccessMode.Subject,
                        FeedbackEnums.SessionAccessMode.Manager
                    ].indexOf(data.AccessMode) > -1) {
                    return data.Session.SubjectRating;
                }
            },
            getRatingNote = function () {
                return data.Session.RatingNote;
            },
            getDeclineNote = function () {
                return data.Session.DeclineNote;
            },
            getParticipants = function () {
                return session.CycleType === FeedbackEnums.CycleType.EvaluateOthers ? session.Participants.filter(function (p) {
                    return p.ParticipantType !== FeedbackEnums.SessionParticipantType.Subject;
                }) : session.Participants;
            };
        return {
            hgId: session.hgId,
            RequestId: session.RequestId,
            CycleId: session.CycleId,
            CycleType: session.CycleType,
            CycleTitle: session.CycleTitle,
            CycleDescription: session.CycleDescription,
            ExpirationDate: session.ExpirationDate,
            ArchiveDate: session.ArchiveDate,
            AboutMembers: getAboutMembers(session),
            Card: shapeCard(),
            Participants: getParticipants(),
            RequestNote: getRequestNote(),
            SubjectRating: getSubjectRating(),
            RatingNote: getRatingNote(),
            DeclineNote: getDeclineNote(),
            GroupId: session.GroupId,
            Status: session.Status,
            IsPrivate: data.Cycle ? data.Cycle.IsPrivate : false,
            AccessMode: data.AccessMode,
            IsDirectManager: data.IsDirectManager,
            ShowManagerNotes: session.ShowManagerNotes,
            Note: session.Note,
            Mnro: managerNoteReleased()//stand for "manager note ready only"
        };
    },
    getRequesterTipURL = function (data) {
        var url = '';
        if (data.Cycle.RequesterTips === FeedbackEnums.TrainingPDFType.None) {
            url = '';
        } else if (data.Cycle.RequesterTips === FeedbackEnums.TrainingPDFType.HGTips) {
            url = '/files/Receiving_Feedback.pdf?';
        } else if (data.Cycle.RequesterTips === FeedbackEnums.TrainingPDFType.Custom) {
            url = '/svc/FeedbackCycle/GetFeedbackTips?type=RequesterTips&cycleId=' + data.Cycle.hgId;
        }
        return url;
    },
    GetSessionById = function (data) {
        var dto = commonGetSessionById(data);
        dto.TipUrl = getRequesterTipURL(data);
        return dto;
    },
    GetSelfEvaluationSessionById = function (data) {
        return commonGetSessionById(data);
    },
    GetSelfEvalPdfJson = function (data) {
        var dto,
            loadSingleGoalForSection = function (section) {
                var goalData = data.AuxiliaryDataForSections[section.hgId] ? data.AuxiliaryDataForSections[section.hgId].GoalData : null,
                    commentsData = data.AuxiliaryDataForSections[section.hgId] ? data.AuxiliaryDataForSections[section.hgId].CommentsData : null,
                    goalDto = goalData ? GoalDto.GetGoalDto(goalData, data.ViewerMemberId) : {},
                    commentsDto = commentsData ? GoalDto.GetCommentsDto({
                        Data: commentsData,
                        CurUserMemberId: data.ViewerMemberId,
                        Role: data.Role
                    }) : [];
                goalDto.Comments = commentsDto;
                goalDto.CommentTotalCount = commentsData ? commentsData.Count : 0;
                section.AuxiliaryData = goalDto;
            },
            loadGoalsForSection = function (section) {
                var goalData = data.AuxiliaryDataForSections[section.hgId];
                section.AuxiliaryData = goalData ? GoalDto.MapGoalDetails(goalData) : [];
            },
            loadAuxiliaryDataForOneSection = function (section) {
                if (section.Type === FeedbackEnums.SectionType.Generic) {
                    section.AuxiliaryData = {};
                }
                if (section.Type === FeedbackEnums.SectionType.Recognitions) {
                    section.AuxiliaryData = data.AuxiliaryDataForSections[section.hgId] || [];
                }
                if ([
                        FeedbackEnums.SectionType.CycleGoal,
                        FeedbackEnums.SectionType.AdhocGoal].indexOf(section.Type) > -1) {
                    if (section.QuestionForEachGoal) {
                        return loadSingleGoalForSection(section);
                    }
                    loadGoalsForSection(section);
                }
            };
        data.PrintPdf = true;
        dto = commonGetSessionById(data);
        if (dto.Card && dto.Card.Sections && dto.Card.Sections.length) {
            dto.Card.Sections.forEach(function (section) {
                loadAuxiliaryDataForOneSection(section);
            });
        }
        return dto;
    },
    AcceptRequest = function (data) {
        return {
            HasTip: data.Initiator && (data.Initiator.TipGivePending || data.Initiator.HasInstruction)
        };
    },
    GetMyTeamForCheckIn = function (data) {
        return data.DirectReports.map(function (member) {
            return {
                MemberId: member.hgId,
                UserId: member.UserId,
                FullName: member.FullName,
                DepartmentName: member.GroupDepartmentName,
                Position: member.Position,
                Role: member.RolesInGroup[0],
                LastCheckInDate: data.LastCheckInDates[member.hgId]
            };
        });
    },
    GetSessionByIdTip = function (data) {
        var dto = commonGetSessionById(data);
        delete dto.Card;
        dto.Instruction = data.Cycle.Note;
        dto.TipGivePending = data.Initiator ? data.Initiator.TipGivePending : false;
        if (data.Cycle.GiverTips === FeedbackEnums.TrainingPDFType.None) {
            dto.TipUrl = '';
        } else if (data.Cycle.GiverTips === FeedbackEnums.TrainingPDFType.HGTips) {
            dto.TipUrl = '/files/Providing_Feedback.pdf?';
        } else if (data.Cycle.GiverTips === FeedbackEnums.TrainingPDFType.Custom) {
            dto.TipUrl = '/svc/FeedbackCycle/GetFeedbackTips?type=GiverTips&cycleId=' + data.Cycle.hgId;
        }
        return dto;
    },
    MapCheckInHistory = function (data) {
        var getManagerCheckInNote = function (session) {
                if (session.Card && session.Card.Sections && session.Card.Sections.length &&
                        session.Card.Sections[0].Questions && session.Card.Sections[0].Questions.length &&
                        session.Card.Sections[0].Questions[0].Answers && session.Card.Sections[0].Questions[0].Answers.length) {
                    return session.Card.Sections[0].Questions[0].Answers[0].Text;
                }
                return "";
            },
            getManagerCheckInIssuer = function (session) {
                var reviwer = session.Participants.find(function (p) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                });
                if (reviwer) {
                    return {
                        UserId: reviwer.UserId,
                        MemberId: reviwer.MemberId,
                        FullName: reviwer.FullName
                    };
                }
                HgLog.error("MapCheckInHistory, Reviewer note found for session", session.hgId);
            };
        return data.map(function (session) {
            return {
                hgId: session.hgId,
                Title: session.CycleTitle,
                Type: session.CycleTitle,
                Note: getManagerCheckInNote(session),
                Issurer: getManagerCheckInIssuer(session),
                CreatedDate: session.CreatedDate
            };
        });
    },
    MapSessions = function (data) {
        var initiatorsHashedByCycleId = {},
            initiators = data.Initiators || [],
            getNextStepForRequestInProgress = function (session, memberIsSubject) {
                if (memberIsSubject) {
                    return FeedbackEnums.NextStep.View;
                }
                if (!initiatorsHashedByCycleId[session.CycleId]) {
                    return FeedbackEnums.NextStep.Tip;
                }
                if (initiatorsHashedByCycleId[session.CycleId].SkipGiveInstruction) {
                    return FeedbackEnums.NextStep.Answer;
                }
                if (initiatorsHashedByCycleId[session.CycleId].HasInstruction || initiatorsHashedByCycleId[session.CycleId].TipGivePending) {
                    return FeedbackEnums.NextStep.Tip;
                }
                return FeedbackEnums.NextStep.Answer;
            },
            getNextStepForSelfNotStartedInProgress = function (session, memberIsSubject) {
                if (!memberIsSubject) {
                    return FeedbackEnums.NextStep.SelfEvalView;
                }
                //now i'm the subject
                if (session.Note) {
                    return FeedbackEnums.NextStep.SelfEvalStart;
                }
                return FeedbackEnums.NextStep.SelfEvalAnswer;
            },
            resolveNextStep = function (session, memberIsSubject) {
                var mapping = {
                        Self: {//accessing your own tab
                            RequestInbox: {
                                Requesting: memberIsSubject ? FeedbackEnums.NextStep.View : FeedbackEnums.NextStep.Start,
                                Declined: FeedbackEnums.NextStep.View,
                                Expired: FeedbackEnums.NextStep.View,
                                NotStarted: FeedbackEnums.NextStep.Answer,
                                InProgress: getNextStepForRequestInProgress(session, memberIsSubject),
                                Completed: FeedbackEnums.NextStep.View,
                                Closed: FeedbackEnums.NextStep.View,
                                Archived: FeedbackEnums.NextStep.View
                            },
                            RequestCompleted: {
                                Requesting: FeedbackEnums.NextStep.View,
                                Declined: FeedbackEnums.NextStep.View,
                                Expired: FeedbackEnums.NextStep.View,
                                NotStarted: FeedbackEnums.NextStep.View,
                                InProgress: FeedbackEnums.NextStep.View,
                                Submitted: FeedbackEnums.NextStep.View,
                                Completed: FeedbackEnums.NextStep.View,
                                Closed: FeedbackEnums.NextStep.View,
                                Archived: FeedbackEnums.NextStep.View
                            },
                            CheckInInbox: {
                                Requesting: FeedbackEnums.NextStep.SelfEvalView,
                                Declined: FeedbackEnums.NextStep.SelfEvalView,
                                Expired: FeedbackEnums.NextStep.SelfEvalView,
                                NotStarted: getNextStepForSelfNotStartedInProgress(session, memberIsSubject),
                                InProgress: getNextStepForSelfNotStartedInProgress(session, memberIsSubject),
                                Submitted: FeedbackEnums.NextStep.SelfEvalView,
                                PendingSignOff: FeedbackEnums.NextStep.SelfEvalView,
                                Completed: FeedbackEnums.NextStep.SelfEvalView,
                                Closed: FeedbackEnums.NextStep.SelfEvalView,
                                Archived: FeedbackEnums.NextStep.SelfEvalView

                            },
                            CheckInCompleted: {
                                Requesting: FeedbackEnums.NextStep.SelfEvalView,
                                Declined: FeedbackEnums.NextStep.SelfEvalView,
                                Expired: FeedbackEnums.NextStep.SelfEvalView,
                                NotStarted: FeedbackEnums.NextStep.SelfEvalView,
                                InProgress: FeedbackEnums.NextStep.SelfEvalView,
                                Submitted: FeedbackEnums.NextStep.SelfEvalView,
                                PendingSignOff: FeedbackEnums.NextStep.SelfEvalView,
                                Completed: FeedbackEnums.NextStep.SelfEvalView,
                                Closed: FeedbackEnums.NextStep.SelfEvalView,
                                Archived: FeedbackEnums.NextStep.SelfEvalView
                            }
                        },
                        Manager: {//accessing other people's tab
                            RequestInbox: {
                                Requesting: FeedbackEnums.NextStep.View,
                                Declined: FeedbackEnums.NextStep.View,
                                Expired: FeedbackEnums.NextStep.View,
                                NotStarted: FeedbackEnums.NextStep.View,
                                InProgress: FeedbackEnums.NextStep.View,
                                Submitted: FeedbackEnums.NextStep.View,
                                Completed: FeedbackEnums.NextStep.View,
                                Closed: FeedbackEnums.NextStep.View,
                                Archived: FeedbackEnums.NextStep.View
                            },
                            RequestCompleted: {
                                Requesting: FeedbackEnums.NextStep.View,
                                Declined: FeedbackEnums.NextStep.View,
                                Expired: FeedbackEnums.NextStep.View,
                                NotStarted: FeedbackEnums.NextStep.View,
                                InProgress: FeedbackEnums.NextStep.View,
                                Submitted: FeedbackEnums.NextStep.View,
                                Completed: FeedbackEnums.NextStep.View,
                                Closed: FeedbackEnums.NextStep.View,
                                Archived: FeedbackEnums.NextStep.View
                            },
                            CheckInInbox: {
                                Requesting: FeedbackEnums.NextStep.SelfEvalView,
                                Declined: FeedbackEnums.NextStep.SelfEvalView,
                                Expired: FeedbackEnums.NextStep.SelfEvalView,
                                NotStarted: FeedbackEnums.NextStep.SelfEvalView,
                                InProgress: FeedbackEnums.NextStep.SelfEvalView,
                                Submitted: FeedbackEnums.NextStep.SelfEvalView,
                                PendingSignOff: FeedbackEnums.NextStep.SelfEvalView,
                                Completed: FeedbackEnums.NextStep.SelfEvalView,
                                Closed: FeedbackEnums.NextStep.SelfEvalView,
                                Archived: FeedbackEnums.NextStep.SelfEvalView
                            },
                            CheckInCompleted: {
                                Requesting: FeedbackEnums.NextStep.SelfEvalView,
                                Declined: FeedbackEnums.NextStep.SelfEvalView,
                                Expired: FeedbackEnums.NextStep.SelfEvalView,
                                NotStarted: FeedbackEnums.NextStep.SelfEvalView,
                                InProgress: FeedbackEnums.NextStep.SelfEvalView,
                                Submitted: FeedbackEnums.NextStep.SelfEvalView,
                                PendingSignOff: FeedbackEnums.NextStep.SelfEvalView,
                                Completed: FeedbackEnums.NextStep.SelfEvalView,
                                Closed: FeedbackEnums.NextStep.SelfEvalView,
                                Archived: FeedbackEnums.NextStep.SelfEvalView
                            }
                        }
                    },
                    selfOrManager = data.CurUserMemberId === data.MemberId ? 'Self' : "Manager";
                return mapping[selfOrManager][data.Tab][session.Status];
            },
            resolveParticipantType = {
                Request: {
                    Give: FeedbackEnums.SessionParticipantType.Subject,
                    Receive: FeedbackEnums.SessionParticipantType.Reviewer
                },
                SelfEvaluation: {
                    Give: FeedbackEnums.SessionParticipantType.Subject,
                    Receive: FeedbackEnums.SessionParticipantType.Reviewer
                }
            },
            resolveParticipantDate = function (session, type, field) {
                var sdate = session.Participants.filter(function (p) {
                    return type.indexOf(p.ParticipantType) !== -1;
                });
                return sdate.length ? sdate[0][field] || '' : '';
            };

        initiators.forEach(function (initiator) {
            if (!initiatorsHashedByCycleId[initiator.CycleId]) {
                initiatorsHashedByCycleId[initiator.CycleId] = initiator;
            }
        });
        return data.Sessions.map(function (session) {
            var meParticipant = session.Participants.find(function (p) {
                    return p.MemberId === data.MemberId;
                }) || {},
                iAmSubject = [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(meParticipant.ParticipantType) !== -1,
                filteredParticipants = session.Participants.filter(function (p) {
                    return p.MemberId !== data.MemberId;
                }).map(function (member) {
                    return {
                        Status: member.Status,
                        FullName: member.FullName,
                        UserId: member.UserId,
                        MemberId: member.MemberId,
                        ParticipantType: member.ParticipantType,
                        curMember: member.UserId === data.CurUserMemberId,
                        NeedsSignOff: member.NeedsSignOff
                    };
                }),
                resolveDisplayDate = {
                    Give: {
                        Date: function () {
                            var status = {
                                InProgress: function () {
                                    return session.CreatedDate;
                                },
                                Submitted: function () {
                                    return resolveParticipantDate(session, [FeedbackEnums.SessionParticipantType.Reviewer], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                },
                                Completed: function () {
                                    return resolveParticipantDate(session, [FeedbackEnums.SessionParticipantType.Reviewer], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                }
                            };
                            return status[session.Status] ? status[session.Status]() : '';
                        }
                    },
                    Request: {
                        Date: function () {
                            var status = {
                                InProgress: function () {
                                    return filteredParticipants[0].ParticipantType === FeedbackEnums.SessionParticipantType.Subject ? session.ExpirationDate : session.CreatedDate;
                                },
                                Requesting: function () {
                                    return filteredParticipants[0].ParticipantType === FeedbackEnums.SessionParticipantType.Subject ? session.ExpirationDate : session.CreatedDate;
                                },
                                Expired: function () {
                                    return session.ExpirationDate;
                                },
                                Declined: function () {
                                    return session.DeclinedDate;
                                },
                                Submitted: function () {
                                    return resolveParticipantDate(session, [FeedbackEnums.SessionParticipantType.Reviewer], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                },
                                Completed: function () {
                                    return resolveParticipantDate(session, [FeedbackEnums.SessionParticipantType.Reviewer], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                },
                                Closed: function () {
                                    return session.ModifiedDate;
                                }
                            };
                            return status[session.Status] ? status[session.Status]() : '';
                        }
                    },
                    EvaluateOthers: {
                        Date: function () {
                            var status = {
                                InProgress: function () {
                                    return filteredParticipants[0].ParticipantType === FeedbackEnums.SessionParticipantType.Requester ? session.ExpirationDate : session.CreatedDate;
                                },
                                Requesting: function () {
                                    return filteredParticipants[0].ParticipantType === FeedbackEnums.SessionParticipantType.Requester ? session.ExpirationDate : session.CreatedDate;
                                },
                                Expired: function () {
                                    return session.ExpirationDate;
                                },
                                Declined: function () {
                                    return session.DeclinedDate;
                                },
                                Submitted: function () {
                                    return resolveParticipantDate(session, [FeedbackEnums.SessionParticipantType.Reviewer], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                },
                                Completed: function () {
                                    return resolveParticipantDate(session, [FeedbackEnums.SessionParticipantType.Reviewer], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                },
                                Closed: function () {
                                    return session.ModifiedDate;
                                }
                            };
                            return status[session.Status] ? status[session.Status]() : '';
                        }
                    },
                    SelfEvaluation: {
                        Date: function () {
                            var status = {
                                NotStarted: function () {
                                    return resolveParticipantDate(session, [resolveParticipantType[session.CycleType][data.ActionMode]], FeedbackEnums.ParticipantDateType.DueDate);
                                },
                                InProgress: function () {
                                    return resolveParticipantDate(session, [resolveParticipantType[session.CycleType][data.ActionMode]], FeedbackEnums.ParticipantDateType.DueDate);
                                },
                                Submitted: function () {
                                    return resolveParticipantDate(session, [resolveParticipantType[session.CycleType][data.ActionMode]], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                },
                                PendingSignOff: function () {
                                    return resolveParticipantDate(session, [resolveParticipantType[session.CycleType][data.ActionMode]], FeedbackEnums.ParticipantDateType.SubmittedDate);
                                },
                                Archived: function () {
                                    return session.ArchiveDate;
                                },
                                Completed: function () {
                                    return session.CompletedDate;
                                },
                                Closed: function () {
                                    return session.ModifiedDate;
                                }
                            };
                            return status[session.Status] ? status[session.Status]() : '';
                        }
                    }
                },
                submittedDate = function () {
                    if (session.Status === FeedbackEnums.SessionStatus.Submitted) {
                        return resolveParticipantDate(session, [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester], FeedbackEnums.ParticipantDateType.SubmittedDate);
                    }
                    return;
                },
                resolveStatusDisplay = function () {
                    if (session.CycleType !== FeedbackEnums.CycleType.SelfEvaluation ||
                            [FeedbackEnums.SessionStatus.Submitted,
                                FeedbackEnums.SessionStatus.Completed].indexOf(session.Status) === -1 ||
                                resolveParticipantDate(session,
                                    [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester],
                                    FeedbackEnums.ParticipantDateType.SubmittedDate) < resolveParticipantDate(session,
                                    [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester], FeedbackEnums.ParticipantDateType.DueDate)) {
                        return session.Status;
                    }
                    return session.Status + "Late";
                },
                reviewer = session.Participants.find(function (p) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                }),
                subject = session.Participants.find(function (participant) {
                    return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
                }),
                isMultiManger = filteredParticipants.filter(function (participant) {
                    return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                }).length > 1,
                nextStep = resolveNextStep(session, iAmSubject),
                resolveOptions = function () {
                    if (data.Tab === FeedbackEnums.Tabs.CheckInInbox && data.CurUserMemberId === data.MemberId) {
                        return FeedbackEnums.UserAction.Archive;
                    }
                    if (session.CycleType === FeedbackEnums.CycleType.Give &&
                            [FeedbackEnums.NextStep.Answer, FeedbackEnums.NextStep.Start, FeedbackEnums.NextStep.Tip].indexOf(nextStep) !== -1) {
                        return FeedbackEnums.UserAction.Delete;
                    }
                },
                resolveRequestUser = function () {
                    var showRequestUser;
                    if (session.CycleType === FeedbackEnums.CycleType.Request) {
                        showRequestUser = iAmSubject ||
                                        (filteredParticipants[0].Status === FeedbackEnums.SessionStatus.Requesting && session.Status === FeedbackEnums.SessionStatus.Submitted) ||
                                        [FeedbackEnums.SessionStatus.InProgress,
                                        FeedbackEnums.SessionStatus.Requesting,
                                        FeedbackEnums.SessionStatus.Expired,
                                        FeedbackEnums.SessionStatus.Declined,
                                        FeedbackEnums.SessionStatus.Closed].indexOf(session.Status) > -1;
                    } else if (session.CycleType === FeedbackEnums.CycleType.Give) {
                        showRequestUser = filteredParticipants[0].ParticipantType !== FeedbackEnums.SessionParticipantType.Subject;
                    } else {
                        showRequestUser = true;
                    }
                    return showRequestUser;
                },
                isNew = function (session, participants) {
                    var map = {
                        Give: function () {
                            return session.Status === FeedbackEnums.SessionStatus.Submitted && !!participants.find(function (participant) {
                                return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                            });
                        },
                        Request: function () {
                            if (session.Status === FeedbackEnums.SessionStatus.Requesting) {
                                return !!participants.find(function (participant) {
                                    return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
                                });
                            }
                            return session.Status === FeedbackEnums.SessionStatus.Submitted && !!participants.find(function (participant) {
                                return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                            });
                        },
                        SelfEvaluation: function () {
                            return session.Status === FeedbackEnums.SessionStatus.Submitted && !!participants.find(function (participant) {
                                return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
                            });
                        },
                        EvaluateOthers: function () {
                            if (session.Status === FeedbackEnums.SessionStatus.Requesting) {
                                return !!participants.find(function (participant) {
                                    return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Requester;
                                });
                            }
                            return session.Status === FeedbackEnums.SessionStatus.Submitted && !!participants.find(function (participant) {
                                return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                            });
                        }
                    };
                    return map[session.CycleType] ? map[session.CycleType]() : false;
                },
                aboutMembers = session.CycleType === FeedbackEnums.CycleType.EvaluateOthers ? getAboutMembers(session) : [];
            if (session.CycleType === FeedbackEnums.CycleType.EvaluateOthers) {
                filteredParticipants = filteredParticipants.filter(function (p) {
                    return p.ParticipantType !== FeedbackEnums.SessionParticipantType.Subject;
                });
            }

            return {
                hgId: session.hgId,
                CycleId: session.CycleId,
                CycleTitle: session.CycleTitle,
                CycleType: session.CycleType,
                ShowOptions: resolveOptions(),
                CycleDescription: session.CycleDescription,
                RequestNote: session.RequestNote,
                ShowManagerNotes: session.ShowManagerNotes,
                DisplayDate: resolveDisplayDate[session.CycleType] ? resolveDisplayDate[session.CycleType].Date() : '',
                SubmittedDate: submittedDate(),
                AboutMembers: aboutMembers,
                Participants: filteredParticipants,
                ReviewerFullName: reviewer ? reviewer.FullName : '',
                IsMultiManager: isMultiManger,
                SubjectFullName: subject ? subject.FullName : '',
                SubjectNeedsSignOff: subject ? subject.Status !== FeedbackEnums.SessionParticipantStatus.SignedOff && subject.NeedsSignOff : false,
                Status: session.Status,
                NextStep: nextStep,
                IAmSubject: iAmSubject,
                WaitingOtherSignOff: session.Status === FeedbackEnums.SessionStatus.PendingSignOff && meParticipant &&
                            (!meParticipant.NeedsSignOff || meParticipant.Status === FeedbackEnums.SessionParticipantStatus.SignedOff),
                ShowSignOff: session.Status === FeedbackEnums.SessionStatus.PendingSignOff &&
                            meParticipant && meParticipant.NeedsSignOff &&
                            meParticipant.Status !== FeedbackEnums.SessionParticipantStatus.SignedOff &&
                            data.MemberId === data.CurUserMemberId,
                StatusDisplay: resolveStatusDisplay(),
                IsNew: isNew(session, filteredParticipants),
                ShowReview: session.CycleType === FeedbackEnums.CycleType.SelfEvaluation &&
                            subject.Status === FeedbackEnums.SessionParticipantStatus.Submitted &&
                            [FeedbackEnums.SessionStatus.PendingSignOff, FeedbackEnums.SessionStatus.Completed].indexOf(session.Status) === -1 && !iAmSubject,
                ShowRequestUser: resolveRequestUser(),
                ShowCompanyName: session.CycleType === FeedbackEnums.CycleType.SelfEvaluation && iAmSubject,
                ShowDraft: session.CycleType === FeedbackEnums.CycleType.Give && session.Status === FeedbackEnums.SessionStatus.InProgress
            };
        });
    },
    MapTalentInsightSessions = function (data, user) {
        if (!data.Initiator) {
            return null;
        }
        return {
            CycleId: data.Initiator.CycleId,
            CycleTitle:  data.Initiator.CycleTitle,
            Status: data.Initiator.Status,
            Description: data.Cycle.Note,
            Sessions: data.Sessions.map(function (sessionItem) {
                var subject = sessionItem.Participants.find(function (item) {
                    return [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(item.ParticipantType) !== -1;
                });
                return {
                    hgId: sessionItem.hgId,
                    InitiatorId: data.Initiator.hgId,
                    UserId: subject ? subject.UserId : '',
                    MemberId: subject ? subject.MemberId : '',
                    FullName: subject ? subject.FullName : '',
                    Role: subject ? subject.Role : '',
                    MemberTitle: user ? user.MemberTitleInGroup : '',
                    UseSections: true,
                    Sections: sessionItem.Card.Sections.map(function (section) {
                        return {
                            Title: section.Title,
                            Description: section.Description,
                            hgId: section.hgId,
                            Questions: getQuestionDto({
                                Questions: section.Questions
                            })
                        };
                    })
                };
            })
        };
    },
    MapComments = function (data) {
        return data.Comments.map(function (comment) {
            return {
                hgId: comment.hgId,
                Comment: comment.Comment,
                Type: comment.Type,
                UserhgId: comment.CommenterUserhgId,
                CreatedDate: comment.CreatedDate,
                MemberId: comment.MemberId,
                Name: comment.CommenterFirstName + ' ' + comment.CommenterLastName
            };
        });
    };
module.exports = {
    MapCheckInHistory: MapCheckInHistory,
    GetSessionById: GetSessionById,
    MapSessions: MapSessions,
    GetSessionByIdTip: GetSessionByIdTip,
    GetSelfEvaluationSessionById: GetSelfEvaluationSessionById,
    GetSelfEvalPdfJson: GetSelfEvalPdfJson,
    AcceptRequest: AcceptRequest,
    MapTalentInsightSessions: MapTalentInsightSessions,
    GetMyTeamForCheckIn: GetMyTeamForCheckIn,
    MapComments: MapComments
};
