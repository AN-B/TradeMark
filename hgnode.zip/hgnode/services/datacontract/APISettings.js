/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    APIKeyStatus = require('../../enums/APIKeyStatus.js'),
    APISettingsSchema = new DataContractSchema({
        APIKey: {type: String},
        APIKeyVersion: {type: String},
        APIKeyStatus: {type: String, default: APIKeyStatus.Active, enum: [APIKeyStatus.Active, APIKeyStatus.Disabled]},
        APIKeyLastAccessedAt: {type: Number, default: Date.now},
        GroupId: {type: String},
        AvailableServices: [String]
    }),
    APISettings = mongoose.model('APISettings', APISettingsSchema);
exports.APISettings = APISettings;
