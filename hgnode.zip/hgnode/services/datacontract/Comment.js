/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),

    CommentInFeedSchema = new DataContractSchema({
        hgId: {type : String, default : ''},
        Comment: { type : String, default: '' },
        EntityId: {type : String, required: true},
        CommenterFirstName: { type : String, default: '' },
        CommenterLastName: { type : String, default: '' },
        CommenterUserhgId: {type : String, default: ''},
        CreatedDate : {type: Number, default : Date.now}
    }),
    CommentInFeed = mongoose.model('CommentInFeed', CommentInFeedSchema);

exports.CommentInFeed = CommentInFeed;
