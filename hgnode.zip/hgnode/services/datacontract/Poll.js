/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    PollEnums = require('../../enums/PollEnums.js'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    PollSchema = new DataContractSchema({
        PollId: {type: String},
        PollQuestionId: {type: String},
        Question: {type: String},
        Description: {type: String},
        Status: {type: String},
        StartDate: {type: Number},
        EndDate: {type: Number},
        AnswerOptions: [{
            Value: {type: Number},
            Text: {type: String},
            _id: false
        }],
        AnswerResults: [{
            Text: {type: String},
            Vote: {type: Number}
        }],
        ParticipantsCount: {type: Number},
        OutstandingVotes: {type: Number}
    }),
    PollModel = mongoose.model('Poll', PollSchema),
    GetMyPoll = function (data) {
        var polls = [],
            pollHash = {},
            resultsHash = {};
        if (data && data.Questions && data.Polls) {
            data.Results.forEach(function (item) {
                resultsHash[item.PollQuestionId] = item;
            });
            data.Polls.forEach(function (item) {
                pollHash[item.PollQuestionId] = item;
            });
            data.Questions.forEach(function (item) {
                var newPoll = new PollModel({
                    PollId: pollHash[item.hgId] ? pollHash[item.hgId].hgId : null,
                    PollQuestionId: item.hgId,
                    Question: item.Question,
                    Description: item.Description,
                    Status: item.Status,
                    AnswerOptions: item.AnswerOptions,
                    StartDate: item.StartDate,
                    EndDate: item.EndDate
                });
                if (item.Status === PollEnums.Status.InProgress) {
                    if (!pollHash[item.hgId] || pollHash[item.hgId].Status !== PollEnums.QuestionStatus.Pending) {
                        delete newPoll.AnswerOptions;
                        newPoll.AnswerResults = resultsHash[item.hgId].result;
                        newPoll.OutstandingVotes = resultsHash[item.hgId].OutstandingVotes;
                        newPoll.ParticipantsCount = resultsHash[item.hgId].ParticipantsCount;
                    }
                }
                polls.push(newPoll);
            });
        }
        return polls;
    };
exports.GetMyPoll = GetMyPoll;
