/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    DateHelper = require('../../util/DateHelper.js'),

    CoachingNoteSchema = new DataContractSchema({
        hgId: {type : String, default : ''},
        Comment: { type : String},
        EntityId: {type : String},//if not empty, it's the hgId of associated track
        Header : {type : String},//"General Coaching Note", or the title of the track
        SubHeader : {type : String},//empty or the title of the milestone
        CommenterFirstName: { type : String},
        CommenterLastName: { type : String},
        CommenterUserhgId: {type : String},
        MemberId: {type : String, default: ''},//whoever made the comment
        Recipient : {
            MemberId : { type : String},
            UserId : { type : String},
            FullName : { type : String}
        },
        CreatedDate: {type: Number, default : Date.now},
        TrackId: {type : String},
        MilestoneId: {type : String},
        MilestoneTemplateId: {type : String},
        MilestoneFriendlyGroupId : {type: Number, default: -1},
        Status: { type : String},
        Comments : []
    }),
    CoachingNote = mongoose.model('CoachingNote', CoachingNoteSchema),

    CoachingNoteDrillDownSchema = new DataContractSchema({
        hgId: {type : String, default : ''},
        Header : {type : String},
        CommenterFirstName: { type : String},
        CommenterLastName: { type : String},
        MemberId : { type : String},
        Recipient : {
            MemberId : { type : String},
            FullName : { type : String}
        },
        CreatedDate: {type: Number, default : Date.now}
    }),
    CoachingNoteDrillDown = mongoose.model('CoachingNoteDrillDown', CoachingNoteDrillDownSchema),

    GetCoachingNoteByIdDTO = function (params, callback) {
        var result;

        function filterComments_Private(comment) {
            return (comment.Status === 'Active');
        }

        function setComment_Private(comment) {
            return {
                Name: comment.CommenterFirstName + ' ' + comment.CommenterLastName,
                CommenterUserhgId: comment.CommenterUserhgId,
                Message: comment.Comment,
                ModifiedDate: comment.ModifiedDate,
                hgId: comment.hgId
            };
        }

        function sortComments_Private(a, b) {
            return a.ModifiedDate > b.ModifiedDate;
        }

        result = {
            Header: params.Note.Header,
            Name: params.Note.CommenterFirstName + ' ' + params.Note.CommenterLastName,
            CreatedBy: params.Note.CreatedBy,
            CommenterUserhgId: params.Note.CommenterUserhgId,
            Note: params.Note.Comment,
            Comments: params.Comments.filter(filterComments_Private).map(setComment_Private).sort(sortComments_Private),
            Status: params.Note.Status,
            hgId: params.Note.hgId
        };
        if (params.Track) {
            result.TrackTitle = params.Track.CareerTrackTemplate.Title;
            result.TrackId = params.Note.TrackId;
            result.TrackDelegated = params.Track.AssignedMember.hgId !== params.Note.Recipient.MemberId;
        }
        callback(null, result);
    },
    GetCoachingNotesForMemberDTO = function (params, callback) {
        var Groups,
            Notes;

        function hasNotReadNote_Private(ReadBy) {
            return (ReadBy.indexOf(params.MemberId) === -1);
        }

        function setGroupNotes_Private(group, notes) {
            var GroupNotes = notes
                .sort(function (a, b) {
                    return b.ModifiedDate - a.ModifiedDate;
                })
                .filter(function (item, i, a) {
                    return group === DateHelper.getMonthYearLabel(a[i].ModifiedDate);
                });
            return GroupNotes;
        }

        function setCoachingNote_Private(note) {
            return {
                Header: note.Header,
                CreatedDate: note.CreatedDate,
                ModifiedDate: note.ModifiedDate,
                Name: note.CommenterFirstName + ' ' + note.CommenterLastName,
                CommenterUserhgId: note.CommenterUserhgId,
                Comment: note.Comment,
                Status: note.Status,
                Link: (note.Status === 'Draft') ? ['#/Profile/GiveCoaching/draft/', note.hgId].join('') :
                        ['#/Profile/Coaching/', params.RecipientMemberId, '/', note.hgId].join(''),
                Draft: (note.Status === 'Draft'),
                Unread: hasNotReadNote_Private(note.ReadBy),
                hgId: note.hgId
            };
        }

        Notes = params.Notes.map(setCoachingNote_Private);

        Groups = Notes
            .sort(function (a, b) {
                return b.ModifiedDate - a.ModifiedDate;
            })
            .map(function (note) {
                return DateHelper.getMonthYearLabel(note.ModifiedDate);
            })
            .filter(function (item, i, a) {
                return i === a.indexOf(item);
            })
            .map(function (group) {
                return {
                    Month: group,
                    Notes: setGroupNotes_Private(group, Notes)
                };
            });
        callback(null, Groups);
    };

exports.CoachingNote = CoachingNote;
exports.CoachingNoteDrillDown = CoachingNoteDrillDown;
exports.GetCoachingNoteByIdDTO = GetCoachingNoteByIdDTO;
exports.GetCoachingNotesForMemberDTO = GetCoachingNotesForMemberDTO;
