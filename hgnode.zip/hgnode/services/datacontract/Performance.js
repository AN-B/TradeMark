/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),

    RecognitionSchema = new DataContractSchema({
        hgId : {type : String},
        BadgeFilename: {type : String, default : ''},
        Message: {type : String, default : ''},
        LevelName: {type : String, default : ''},
        Template: {
            hgId : { type : String, default: '' },
            Title: { type : String, default: '' },
            FriendlyGroupId: {type : Number, default: -1},
            Category: { type : String, enum : ['Everyday', 'Achievement', 'Values', 'System'], default: 'Everyday'}
        },
        CreatorMember : {
            hgId: {type : String, default: ''},
            UserId: {type : String, default: ''},
            FullName: {type : String, default: ''}
        },
        RecipientMember : {
            hgId: {type : String, default: ''},
            UserId: {type : String, default: ''},
            FullName: {type : String, default: ''}
        },
        PublicCreatorInfo: {
            FullName: { type : String, default: '' },
            CompanyName: { type : String, default: '' },
            Email: { type : String, default: '' }
        },
        CreatedDate: {type: Number, default : Date.now}
    }),
    PerformanceCardSchema = new DataContractSchema({
        Title: {type: String, required: true, maxlength: 200}
    });
exports.Recognition = mongoose.model('Recognition', RecognitionSchema, 'Recognition');
exports.PerformanceCard = mongoose.model('PerformanceCard', PerformanceCardSchema, 'PerformanceCard');
