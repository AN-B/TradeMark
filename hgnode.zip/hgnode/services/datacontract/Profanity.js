/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    ProfanitySchema = new DataContractSchema({
        hgId: {type: String},
        Lang: {type: String},
        Word: {type: String},
        Level: {type: Number}
    });
exports.Profanity = mongoose.model('Profanity', ProfanitySchema);
