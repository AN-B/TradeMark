/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    FeedSearchSchema = new DataContractSchema({
        hgId: {type: String},
        Name: {type: String},
        MemberId: {type: String},
        SearchTerm: {type: String},
        UserIds: [],
        TeamIds: [],
        DepartmentIds: [],
        LocationIds: [],
        ManagerIds: [],
        DefaultSearch: {type: Boolean},
        RecognitionSource: {type: String, default: 'Both'},
        RelevancyFilter: {type: Boolean}
    });
FeedSearchSchema.virtual('IsFiltered').get(function () {
    return (this.hgId && (this.UserIds.length ||
            this.TeamIds.length ||
            this.DepartmentIds.length ||
            this.LocationIds.length ||
            this.ManagerIds.length ||
            this.RecognitionSource !== 'Both' ||
            this.SearchTerm.length ||
            this.RelevancyFilter));
});
FeedSearchSchema.set('toJSON', { virtuals: true });
exports.FeedSearch = mongoose.model('FeedSearch', FeedSearchSchema);
