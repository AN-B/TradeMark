/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    SnapshotSchema = new DataContractSchema({
        SpendTotal: {type : Number, default: 0},
        TransferTotal : {type : Number, default: 0},
        ItemCostTotal : {type : Number, default: 0},
        GroupId : {type : String, default: ''},
        GroupName : {type : String, default: ''},
        CreatedDate : {type : Number}
    }),
    Snapshot = mongoose.model('Snapshot', SnapshotSchema);


exports.Snapshot = Snapshot;
