/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),

    ProvisionedCompanyBatchesSchema = new DataContractSchema({
        hgId: {type : String, default : ''},
        FileName: {type : String, default: '' },
        CreatedDate: { type : Date, default: null },
        ModifiedDate: { type : Date, default: null }
    }),
    ProvisionedCompanyBatches = mongoose.model('ProvisionBatch', ProvisionedCompanyBatchesSchema);


exports.ProvisionedCompanyBatches = ProvisionedCompanyBatches;

