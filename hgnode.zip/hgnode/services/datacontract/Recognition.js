/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    GetLikedMemberRecord = function (data, currentMemberId) {
        return data.map(function (item) {
            return {
                hgId: item.hgId,
                FullName: item.FullName,
                UserId: item.UserId,
                canAcceptRecogntion: currentMemberId !== item.hgId && item.MembershipStatus === 'Active',
                active: item.MembershipStatus === 'Active'
            };
        });
    },
    GetUserTemplates = function (lang, templates) {
        var translatedVal,
            getTranslatedValues = function (tItem) {
                var returnValues = {},
                    val;
                if (tItem.TranslatedValues && tItem.TranslatedValues.length) {
                    val = tItem.TranslatedValues.filter(function (t) {
                        return t.lang === lang;
                    });
                    if (val.length) {
                        returnValues = val[0].values;
                    }
                }

                return returnValues;
            },
            getLevels = function (translatedLevels, itemLevels) {
                translatedLevels.forEach(function (trans, ind) {
                    if (!trans.Name) {
                        trans.Name = itemLevels[ind].Name;
                    }
                });
                return translatedLevels;
            },
            getSubValues = function (translatedSubValues, itemSubValues) {
                translatedSubValues.forEach(function (trans, ind) {
                    if (!trans.Name) {
                        trans.Name = itemSubValues[ind].Name;
                    }
                });
                return translatedSubValues;
            };
        return templates.map(function (item) {
            translatedVal = getTranslatedValues(item);
            return {
                hgId: item.hgId,
                Title: translatedVal.Title || item.Title,
                Description: translatedVal.Description || item.Description,
                Levels: translatedVal.Levels && translatedVal.Levels.length ? getLevels(translatedVal.Levels, item.Levels) : item.Levels,
                Type: item.Type,
                Tags: item.Tags,
                Category: item.Category,
                Publicity: item.Publicity,
                FriendlyGroupId: item.FriendlyGroupId,
                PointValue: item.PointValue,
                CreditValue: item.CreditValue,
                TeamId: item.TeamId,
                SubValues: translatedVal.SubValues && translatedVal.SubValues.length ? getSubValues(translatedVal.SubValues, item.SubValues) : item.SubValues,
                ForegroundFilename: item.ForegroundFilename,
                BackgroundFilename: item.BackgroundFilename,
                BadgeId: item.BadgeId,
                BackgroundBadgeId: item.BackgroundBadgeId,
                DepartmentName: item.DepartmentName,
                RestrictUsers: item.RestrictUsers,
                RestrictDepartments: item.RestrictDepartments,
                Message: item.Message || '',
                Gift: item.Gift
            };
        });
    },
    GetReceivedRecognitions = function (data) {
        if (!data || !data.feeds || !data.feeds.length) {
            return [];
        }
        return data.feeds.map(function (item) {
            return {
                hgId: item.hgId,
                BadgeId: item.hgId,
                title: item.title,
                description: item.description,
                congratsCount: item.congratsCount,
                message: item.message,
                badgeUrl: item.badgeUrl
            };
        });
    };

exports.GetLikedMemberRecord = GetLikedMemberRecord;
exports.GetUserTemplates = GetUserTemplates;
exports.GetReceivedRecognitions = GetReceivedRecognitions;
