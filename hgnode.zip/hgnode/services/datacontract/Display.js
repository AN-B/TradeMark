/*jslint node:true es5:true*/
'use strict';

var DataContractSchema = require('../../common/DataContractSchema.js'),

    GetGroupDisplaySettings = function (data) {
        return {
            hgId : (!data.displaySettings) ? '' : data.displaySettings.hgId,
            GroupRecognitionAvatarInterval: (!data.displaySettings) ? 5 : data.displaySettings.GroupRecognitionAvatarInterval,
            RecognitionInterval: (!data.displaySettings) ? 5 : data.displaySettings.RecognitionInterval,
            GroupId: (!data.displaySettings) ? '' : data.displaySettings.GroupId,
            SId : (!data.ip) ? '' : data.ip.hgId,
            IPRange : (!data.ip) ? [] : data.ip.IPRange
        };
    },
    GetDisplaySettings = function (data) {
        return {
            GroupRecognitionAvatarInterval: data.displaySettings.GroupRecognitionAvatarInterval || 5,
            RecognitionInterval: data.displaySettings.RecognitionInterval || 5,
            GroupId: data.displaySettings.GroupId,
            GiftEnabled : data.groupInfo.GiftEnabled
        };
    },
    GetRecognitions = function (data) {
        return data.filter(function (item) {
            return item.rows && item.rows.length;
        }).map(function (item) {
            var row = item.rows[0];
            return {
                Title: (row.SubValue) ? [row.SubValue, ' (', row.Title, ')'].join('') : row.Title,
                Message: row.Message,
                CreatedDate: row.CreatedDate,
                GiverFullName: row.GiverFullName || ((row.PublicCreatorInfo && row.PublicCreatorInfo.FullName) ? row.PublicCreatorInfo.FullName : ''),
                GiverUserId: row.GiverUserId || '',
                FriendlyGroupId: row.FriendlyGroupId,
                TemplateId: row.TemplateId,
                BadgeFilename: row.BadgeFilename,
                LikeCount: row.LikeCount,
                GiftCount: (row.GiftCount ? row.GiftCount.length : 0),
                Receivers: item.rows.map(function (dItem) {
                    return {
                        ReceiverFullName : dItem.ReceiverFullName,
                        ReceiverUserId : dItem.ReceiverUserId
                    };
                })
            };
        });
    };
exports.GetDisplaySettings = GetDisplaySettings;
exports.GetGroupDisplaySettings = GetGroupDisplaySettings;
exports.GetRecognitions = GetRecognitions;
