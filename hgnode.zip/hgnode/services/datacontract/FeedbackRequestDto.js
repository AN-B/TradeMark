/*jslint node:true es5:true*/
'use strict';
var FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    HgLog = require('../../framework/HgLog'),
    filterSessionsInRequest = function (data) {
        if (data.AccessMode === FeedbackEnums.SessionAccessMode.Requester) {
            return data.Request.Sessions;
        }
        if (data.AccessMode === FeedbackEnums.SessionAccessMode.Reviewer) {
            return data.Request.Sessions.filter(function (session) {
                return session.ReviewerMemberId === data.ImpersonatedMemberId;
            });
        }
        return [];
    },
    buildSummary = function (data) {
        var summary = {},
            declined = {};
        if (data.AccessMode !== FeedbackEnums.SessionAccessMode.Requester) {
            return summary;
        }
        data.Request.Sessions.forEach(function (session) {
            if (session.SessionStatus === FeedbackEnums.SessionStatus.Declined) {
                declined[session.SessionId] = session;
            }
            if (!summary[session.SessionStatus]) {
                summary[session.SessionStatus] = [session.ReviewerFullName];
            } else {
                summary[session.SessionStatus].push(session.ReviewerFullName);
            }
        });
        // consider InProgress and requesting as the same
        if (summary[FeedbackEnums.SessionStatus.InProgress]) {
            summary[FeedbackEnums.SessionStatus.Requesting] = (summary[FeedbackEnums.SessionStatus.Requesting] || []).concat(summary[FeedbackEnums.SessionStatus.InProgress]);
        }
        // if has data.Sessions, then override the Declined filed for more detail display
        if (data.Sessions) {
            summary[FeedbackEnums.SessionStatus.Declined] = [];
            data.Sessions.forEach(function (session) {
                if (session.Status === FeedbackEnums.SessionStatus.Declined) {
                    summary[session.Status].push({
                        Name: declined[session.hgId].ReviewerFullName,
                        UserId: declined[session.hgId].ReviewerUserId,
                        DeclineNote: session.DeclineNote,
                        DeclinedDate: session.DeclinedDate
                    });
                }
            });
            if (!summary[FeedbackEnums.SessionStatus.Declined].length) {
                delete summary[FeedbackEnums.SessionStatus.Declined];
            }
        }
        return summary;
    },
    mergeAnswers = function (destSections, srcSections) {
        var i,
            j,
            k;
        for (i = 0; i < destSections.length; i += 1) {
            for (j = 0; j < destSections[i].Questions.length; j += 1) {
                if (srcSections[i]) {
                    for (k = 0; k < srcSections[i].Questions[j].Answers.length; k += 1) {
                        destSections[i].Questions[j].Answers.push(srcSections[i].Questions[j].Answers[k]);
                    }
                }
            }
        }
    },
    giveRatingNote = function (sessions) {
        var ratingNote;
        if (sessions.length && sessions[0].CycleType === FeedbackEnums.CycleType.Give && sessions[0].RatingNote) {
            ratingNote = sessions[0].RatingNote;
        }
        return ratingNote;
    },
    giveSubjectRating = function (sessions) {
        var subjectRating;
        if (sessions.length > 0 && sessions[0].CycleType === FeedbackEnums.CycleType.Give && sessions[0].SubjectRating) {
            subjectRating = sessions[0].SubjectRating;
        }
        return subjectRating;
    },
    buildCardSummary = function (sections) {
        sections.forEach(function (section) {
            section.Questions.forEach(function (question) {
                var averageCount = 0;
                if (question.Type !== FeedbackEnums.QuestionType.ShortAnswer) {
                    question.AnswersSummary = {
                        Average: 0,
                        Total: question.Answers.length,
                        CountBySelectedValues: {}
                    };
                    question.Answers.forEach(function (answer) {
                        if (question.Type === FeedbackEnums.QuestionType.RatingScale && answer.SelectedValues[0] < question.AnswerSelector.length) {
                            question.AnswersSummary.Average += answer.SelectedValues[0] + 1;
                            averageCount += 1;
                        }
                        answer.SelectedValues.forEach(function (val) {
                            if (!question.AnswersSummary.CountBySelectedValues[val]) {
                                question.AnswersSummary.CountBySelectedValues[val] = [answer.MemberName];
                            } else {
                                question.AnswersSummary.CountBySelectedValues[val].push(answer.MemberName);
                            }
                        });
                    });
                    if (averageCount === 0) {
                        question.AnswersSummary.Average = "0.00";
                    } else {
                        question.AnswersSummary.Average = (question.AnswersSummary.Average / averageCount).toFixed(2);
                    }
                }
            });
        });
    },
    consolidateCardsAcrossSessions = function (sessions, DisplayConsolidate) {
        var securedSessions,
            firstcard,
            card,
            i,
            len;
        securedSessions = sessions.filter(function (session) {
            return session.Status !==  FeedbackEnums.SessionStatus.Declined && session.Card;
        });
        if (!securedSessions.length) {
            return {};
        }
        firstcard = securedSessions[0].Card;
        card = {
            Title: firstcard.Title,
            Description: firstcard.Description,
            UseSections: firstcard.UseSections,
            Sections: firstcard.Sections,
            Type: firstcard.Type,
            AllowSectionToBeSkipped: firstcard.AllowSectionToBeSkipped
        };
        for (i = 1, len = securedSessions.length; i < len; i += 1) {
            mergeAnswers(card.Sections, securedSessions[i].Card.Sections);
        }
        if (DisplayConsolidate && card) {
            buildCardSummary(card.Sections);
        }

        return card;
    },
    MapRequestTips = function (cycle) {
        var url = '';
        if (!cycle) {
            return url;
        }
        if (cycle.RequesterTips === FeedbackEnums.TrainingPDFType.HGTips) {
            return '/files/Receiving_Feedback.pdf?';
        }
        if (cycle.RequesterTips === FeedbackEnums.TrainingPDFType.Custom) {
            return '/svc/FeedbackCycle/GetFeedbackTips?type=RequesterTips&cycleId=' + cycle.hgId;
        }
        return url;
    },
    MapRequests = function (data) {
        return data.Requests.map(function (request) {
            var IAmRequester = request.RequesterMemberId === data.MemberId,
                IAmSubject = request.SubjectMemberId === data.MemberId,
                DisplayConsolidate = IAmRequester && request.Sessions.length > 1,
                getNextStepForRequestInProgress = function (request, memberIsRequester, memberIsSubject) {
                    if (memberIsRequester) {
                        return FeedbackEnums.NextStep.View;
                    }
                    return FeedbackEnums.NextStep.Answer;
                },
                mySession = request.Sessions.find(function (s) {
                    return s.ReviewerMemberId === data.MemberId;
                }) || {},
                resolveNextStep = function (request, memberIsRequester, memberIsSubject) {
                    var mapping = {
                            Self: {//accessing your own tab
                                RequestInbox: {
                                    Requesting: IAmRequester ? (request.CycleType === FeedbackEnums.CycleType.Give ? FeedbackEnums.NextStep.Answer : FeedbackEnums.NextStep.View) : FeedbackEnums.NextStep.Start,
                                    Declined: FeedbackEnums.NextStep.View,
                                    Expired: FeedbackEnums.NextStep.View,
                                    NotStarted: FeedbackEnums.NextStep.Answer,
                                    InProgress: getNextStepForRequestInProgress(request, memberIsRequester, memberIsSubject),
                                    Submitted: IAmSubject && request.CycleType === FeedbackEnums.CycleType.Give ? FeedbackEnums.NextStep.Rate : FeedbackEnums.NextStep.View,
                                    ReadyToComplete: FeedbackEnums.NextStep.View,
                                    Completed: FeedbackEnums.NextStep.View,
                                    Closed: FeedbackEnums.NextStep.View,
                                    Archived: FeedbackEnums.NextStep.View
                                },
                                RequestCompleted: {
                                    Requesting: FeedbackEnums.NextStep.View,
                                    Declined: FeedbackEnums.NextStep.View,
                                    Expired: FeedbackEnums.NextStep.View,
                                    NotStarted: FeedbackEnums.NextStep.View,
                                    InProgress: FeedbackEnums.NextStep.View,
                                    Submitted: FeedbackEnums.NextStep.View,
                                    ReadyToComplete: FeedbackEnums.NextStep.View,
                                    Completed: FeedbackEnums.NextStep.View,
                                    Closed: FeedbackEnums.NextStep.View,
                                    Archived: FeedbackEnums.NextStep.View
                                }
                            },
                            Manager: {//accessing other people's tab
                                RequestInbox: {
                                    Requesting: FeedbackEnums.NextStep.View,
                                    Declined: FeedbackEnums.NextStep.View,
                                    Expired: FeedbackEnums.NextStep.View,
                                    NotStarted: FeedbackEnums.NextStep.View,
                                    InProgress: FeedbackEnums.NextStep.View,
                                    Submitted: FeedbackEnums.NextStep.View,
                                    ReadyToComplete: FeedbackEnums.NextStep.View,
                                    Completed: FeedbackEnums.NextStep.View,
                                    Closed: FeedbackEnums.NextStep.View,
                                    Archived: FeedbackEnums.NextStep.View
                                },
                                RequestCompleted: {
                                    Requesting: FeedbackEnums.NextStep.View,
                                    Declined: FeedbackEnums.NextStep.View,
                                    Expired: FeedbackEnums.NextStep.View,
                                    NotStarted: FeedbackEnums.NextStep.View,
                                    InProgress: FeedbackEnums.NextStep.View,
                                    Submitted: FeedbackEnums.NextStep.View,
                                    ReadyToComplete: FeedbackEnums.NextStep.View,
                                    Completed: FeedbackEnums.NextStep.View,
                                    Closed: FeedbackEnums.NextStep.View,
                                    Archived: FeedbackEnums.NextStep.View
                                }
                            }
                        },
                        selfOrManager = data.CurUserMemberId === data.MemberId ? FeedbackEnums.ProfileAccessMode.Self : FeedbackEnums.ProfileAccessMode.Manager,
                        myStatus = IAmRequester ? request.Status : request.CycleType === FeedbackEnums.CycleType.Give ? request.Sessions[0].SessionStatus : mySession.SessionStatus;
                    return mapping[selfOrManager][data.Tab][myStatus];
                },
                NextStep = resolveNextStep(request, IAmRequester, IAmSubject),
                Summary = DisplayConsolidate ? buildSummary({
                    AccessMode: FeedbackEnums.SessionAccessMode.Requester,
                    Request: {
                        Sessions: request.Sessions
                    }
                }) : {},
                buildSessions = function (sessions) {
                    if (DisplayConsolidate || sessions.length === 1) {
                        return sessions;
                    }
                    return sessions.filter(function (session) {
                        return session.ReviewerMemberId === data.MemberId;
                    });
                },
                filteredSessions = buildSessions(request.Sessions),
                resolveRequestUser = function () {
                    var showRequestUser;
                    if (request.CycleType === FeedbackEnums.CycleType.Request) {
                        showRequestUser = IAmSubject ||
                                        [FeedbackEnums.SessionStatus.InProgress,
                                        FeedbackEnums.SessionStatus.Requesting,
                                        FeedbackEnums.SessionStatus.Expired,
                                        FeedbackEnums.SessionStatus.Declined,
                                        FeedbackEnums.SessionStatus.Closed].indexOf(request.Sessions[0].SessionStatus) > -1;
                    } else if (request.CycleType === FeedbackEnums.CycleType.Give) {
                        showRequestUser = IAmSubject;
                    } else {
                        showRequestUser = true;
                    }
                    return showRequestUser;
                },
                resolveUnreadInfo = function () {
                    if (data.MemberId !== data.CurUserMemberId || data.Tab !== FeedbackEnums.Tabs.RequestInbox) {
                        return false;
                    }
                    if (request.CycleType === FeedbackEnums.CycleType.Give) {
                        if (IAmSubject) {
                            return request.UnreadInfo;
                        }
                        return filteredSessions[0].UnreadInfo;
                    }
                    if (IAmRequester) {
                        return request.UnreadInfo;
                    }
                    return filteredSessions[0].UnreadInfo;
                },
                resolveShowReadResponse = function () {
                    return ((request.CycleType !== FeedbackEnums.CycleType.Give &&
                        request.Status === FeedbackEnums.RequestStatus.ReadyToComplete &&
                        IAmRequester) ||
                        !!Summary.Submitted);
                },
                resolveDisplayDate = function () {
                    if (request.CycleType === FeedbackEnums.CycleType.Give) {
                        return IAmRequester ? request.CreatedDate :
                                (request.Status === FeedbackEnums.RequestStatus.Completed ? request.CompletedDate : request.CreatedDate);
                    }
                    if (!IAmRequester && mySession.SessionStatus) {
                        if (mySession.SessionStatus === FeedbackEnums.SessionStatus.Declined) {
                            return mySession.DeclinedDate;
                        }
                        if ([FeedbackEnums.SessionStatus.Submitted, FeedbackEnums.SessionStatus.Completed].indexOf(mySession.SessionStatus) > -1) {
                            return mySession.SubmittedDate;
                        }
                        return request.ExpirationDate;
                    }
                    if (request.Status === FeedbackEnums.RequestStatus.ReadyToComplete) {
                        return DisplayConsolidate ? request.CreatedDate : request.Sessions[0].SubmittedDate;
                    }
                    if ([FeedbackEnums.RequestStatus.Requesting, FeedbackEnums.RequestStatus.InProgress].indexOf(request.Status) > -1) {
                        return request.CreatedDate;
                    }
                    if (request.Status === FeedbackEnums.RequestStatus.Completed) {
                        return request.CompletedDate;
                    }
                    if (request.Status === FeedbackEnums.RequestStatus.DeclinedDate) {
                        return request.Sessions[0].DeclinedDate;
                    }
                    if (request.Status === FeedbackEnums.RequestStatus.Expired) {
                        return request.ExpirationDate;
                    }
                    return request.ModifiedDate;
                },
                resolveDownloadAccess = function () {
                    return ((DisplayConsolidate && resolveShowReadResponse()) ||
                        (request.CycleType !== FeedbackEnums.CycleType.Give &&
                            DisplayConsolidate &&
                            [FeedbackEnums.RequestStatus.ReadyToComplete, FeedbackEnums.RequestStatus.Completed].indexOf(request.Status) > -1 &&
                            [FeedbackEnums.ProfileAccessMode.Self, FeedbackEnums.ProfileAccessMode.Admin, FeedbackEnums.ProfileAccessMode.Manager].indexOf(data.AccessMode) > -1));
                },
                resolveCompletedOptions = function () {
                    return (DisplayConsolidate &&
                        FeedbackEnums.RequestStatus.Completed === request.Status &&
                        request.CycleType !== FeedbackEnums.CycleType.Give &&
                        [FeedbackEnums.ProfileAccessMode.Self, FeedbackEnums.ProfileAccessMode.Admin, FeedbackEnums.ProfileAccessMode.Manager].indexOf(data.AccessMode) > -1);
                },
                resolveShowOption = function () {
                    return (request.CycleType === FeedbackEnums.CycleType.Give && request.Status === FeedbackEnums.RequestStatus.Requesting) || resolveDownloadAccess();
                };
            return {
                hgId: request.hgId,
                CycleId: request.CycleId,
                ProfileMemberId: data.MemberId,
                CycleTitle: request.CycleTitle,
                CycleType: request.CycleType,
                DisplayConsolidate: DisplayConsolidate, // boolean to make ui easier
                RequestNote: request.RequestNote,
                RequesterFullName: request.RequesterFullName,
                RequesterUserId: request.RequesterUserId, // display image purpose
                RequesterMemberId: request.RequesterMemberId,
                SubjectFullName: request.SubjectFullName,
                SubjectUserId: request.SubjectUserId,
                SubjectMemberId: request.SubjectMemberId,
                DisplayDate: resolveDisplayDate(),
                SubmittedDate: request.Status === FeedbackEnums.RequestStatus.ReadyToComplete ? request.ModifiedDate : '',
                Sessions: filteredSessions,
                Status: DisplayConsolidate ? request.Status : filteredSessions[0].SessionStatus,
                NextStep: NextStep,
                IAmRequester: IAmRequester,
                IAmSubject: IAmSubject,
                ShowResponse: resolveShowReadResponse(),
                UnreadInfo: resolveUnreadInfo(),
                StatusDisplay: request.Status,
                ShowRequestUser: resolveRequestUser(),
                Summary: Summary,
                ShowOptions: resolveShowOption(),
                CompletedShowOptions: resolveCompletedOptions(),
                CanDownloadPDF: resolveDownloadAccess(),
                CanArchive: request.CycleType === FeedbackEnums.CycleType.Give && request.Status === FeedbackEnums.RequestStatus.Requesting
            };
        });
    },
    MapSessions = function (data) {
        //NOTE: If you make any changes to this code section
        //Please ensure you test the PDF generation for Consolidated Feedback -ge-stalt
        var IAmRequester = data.Request.RequesterMemberId === data.ImpersonatedMemberId,
            IAmManager = data.AccessMode === FeedbackEnums.SessionAccessMode.Manager,
            IAmAdmin = data.AccessMode === FeedbackEnums.SessionAccessMode.Admin,
            DisplayConsolidate = (IAmRequester || IAmManager) && data.Request.Sessions.length > 1,
            resolveStatus = DisplayConsolidate ? data.Request.Status : data.Request.Sessions[0].SessionStatus,
            Summary = DisplayConsolidate ? buildSummary(data) : {},
            canDownloadPDF = function () {
                return ((IAmRequester || IAmManager || IAmAdmin) && data.Request.CycleType !== FeedbackEnums.CycleType.Give &&
                    (!!Summary.Submitted || !!Summary.Completed));
            };
        return {
            hgId: data.Request.hgId,
            RequestedDate: data.Request.CreatedDate,
            CycleTitle: data.Request.CycleTitle,
            CycleType: data.Request.CycleType,
            RequestNote: data.Request.RequestNote,
            ExpirationDate: data.Request.ExpirationDate,
            SubjectMemberId: data.Request.SubjectMemberId,
            SubjectUserId: data.Request.SubjectUserId,
            SubjectFullName: data.Request.SubjectFullName,
            RequesterMemberId: data.Request.RequesterMemberId,
            RequesterUserId: data.Request.RequesterUserId,
            RequesterFullName: data.Request.RequesterFullName,
            Status: resolveStatus,
            IAmRequester: IAmRequester,
            IAmManager: IAmManager,
            IAmAdmin: IAmAdmin,
            Card: consolidateCardsAcrossSessions(data.Sessions, DisplayConsolidate),
            RatingNote: giveRatingNote(data.Sessions),
            SubjectRating: giveSubjectRating(data.Sessions),
            Sessions: filterSessionsInRequest(data),
            AccessMode: data.AccessMode,
            DisplayConsolidate: DisplayConsolidate, // to make display easier
            DeclineNote: DisplayConsolidate ? "" : (data.Sessions[0] ? data.Sessions[0].DeclineNote : ''),
            Summary: DisplayConsolidate ? buildSummary(data) : {},
            CanDownloadPDF: canDownloadPDF(),
            ShowComplete: IAmRequester && data.Request.CycleType !== FeedbackEnums.CycleType.Give &&
                        [FeedbackEnums.RequestStatus.ReadyToComplete, FeedbackEnums.SessionStatus.Submitted].indexOf(resolveStatus) > -1
                        && data.ImpersonatedMemberId === data.CurUserMemberId
        };
    },
    StartGiveFeedback = function (request) {
        return {
            SessionId: request.Sessions && request.Sessions.length ? request.Sessions[0].SessionId : {}
        };
    };
module.exports = {
    MapRequestTips: MapRequestTips,
    MapSessions: MapSessions,
    MapRequests: MapRequests,
    StartGiveFeedback: StartGiveFeedback
};
