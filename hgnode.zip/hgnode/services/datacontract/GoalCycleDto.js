/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    GoalEnums = require('../../enums/GoalEnums.js'),
    AutocompleteEnums = require('../../enums/AutocompleteEnums.js'),
    GoalCycleSummarySchema = new DataContractSchema({
        hgId: {type: String},
        Title: {type: String},
        Status: {type: String},
        Description: {type: String},
        CloseDate: {type: Number},
        CreatedDate: {type: Number},
        ParticipantTypes: [{}],
        //metrics
        SetAndBeyondPercentage: {type: Number, default: 0},//percentage of participants who are in "InProgress", "SubmittedForClosure" or "Complete" status
        OnTimePercentage: {type: Number, default: 0},//percentage of goals that are updated on time
        AvgGoalCompletePercentage: {type: Number, default: 0},
        PendingClosure: {type: Boolean},
        ClosedPercentage : {type : Number, default: 0},
        PendingPercentage : {type : Number, default: 0},
        InProgressUserPercentage: {type : Number, default: 0},
        GoalWeighting: {type: Boolean}
    }),
    DraftGoalCycleSchema = new DataContractSchema({
        hgId: {type : String},
        teamParticipants: [{type : String}]
    }),
    GoalCycleSummary = mongoose.model('GoalCycleSummary', GoalCycleSummarySchema),
    DraftGoalCycle = mongoose.model('DraftGoalCycle', DraftGoalCycleSchema),

    MemberParticipantsForEditSchema = new DataContractSchema({
        MemberId: {type: String},
        UserId: {type: String},
        FullName: {type: String},
        Title: {type: String},
        Department: {type: String},
        IsInCycle: {type: Boolean},
        '_id': false
    }),
    MemberParticipantsForEdit = mongoose.model('MemberParticipantsForEdit', MemberParticipantsForEditSchema),

    CycleEditSchema = new DataContractSchema({
        hgId: {type: String},
        Cycle: {},
        Teams: [{
            hgId: {type: String},
            Name: {type: String},
            LeadByName: {type: String},
            IsInCycle: {type: Boolean},
            '_id': false
        }],
        Members: [{
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Role: {type: String},
            Department: {type: String},
            IsInCycle: {type: Boolean},
            '_id': false
        }],
        TotalMemberNumber: {type: Number},
        TotalTeamNumber: {type: Number},
        Note: {type: String},
        Editability: {}
    }),
    CycleEditDto = mongoose.model('CycleEditDto', CycleEditSchema),

    CycleDetailSchema = new DataContractSchema({
        hgId: {type: String},
        Title: {type: String},
        GoalWeighting: {type: Boolean},
        IndividualGoalsTotal: {type: Number},
        TeamParticipantsCount: {type: Number},
        CanEdit: {type: Boolean},
        Status: {type: String},
        CanDelete: {type: Boolean},
        CanClose: {type: Boolean},
        NextRoundDate: {type: Number},
        RecurrenceFrequency: {type: String},
        Overall: {
            GoalSet: {type: Number},
            GoalCurrent: {type: Number},
            AvgCompletion: {type: Number},
            CloseDate: {type: Number}
        },
        Company: {
            OwnerName: {type: String},
            OwnerUserId: {type: String},
            OwnerMemberId: {type: String},
            Title: {type: String},
            Goals: []
        },
        Teams: [{
            hgId: {type: String},
            TeamName: {type: String},
            OwnerName: {type: String},
            OwnerUserId: {type: String},
            OwnerMemberId: {type: String},
            Title: {type: String},
            GoalCount: {type: Number},
            Goals: [],
            '_id': false
        }],
        Individuals: [{
            hgId: {type: String},
            Status: {type: String},
            OwnerName: {type: String},
            OwnerMemberId: {type: String},
            OwnerUserId: {type: String},
            ManagerName: {type: String},
            ManagerMemberId: {type: String},
            ManagerUserId: {type: String},
            GoalName: {type: String},
            LastUpdated: {type: Number},
            UpdateFrequency: {type: String},
            Current: {type: Boolean},
            Completion: {type: Number},
            '_id': false
        }]
    }),
    CycleDetailDto = mongoose.model('CycleDetailDto', CycleDetailSchema),

    GoalInCycleSchema = new DataContractSchema({
        hgId: {type: String},
        Status: {type: String},
        GoalName: {type: String},
        Aligned: {type: Boolean},
        LastUpdated: {type: Number},
        UpdateFrequency: {type: String},
        Current: {type: Boolean},
        Completion: {type: Number}
    }),

    GoalInCycle = mongoose.model('GoalInCycle', GoalInCycleSchema),

    MapMemberParticipantsForEdit = function (data) {
        var memberIdHash = {};
        data.MemberParticipants.forEach(function (p) {
            memberIdHash[p.ParticipantId] = true;
        });
        return {
            Total: data.Total,
            Members: data.Members.map(function (member) {
                return {
                    MemberId: member.hgId,
                    UserId: member.UserId,
                    FullName: member.FullName,
                    Role: member.RolesInGroup[0] || '',
                    Department: member.GroupDepartmentName,
                    IsInCycle: !!memberIdHash[member.hgId]
                };
            })
        };
    },
    MapMemberParticipantsByCycleTemplateId = function (data) {
        return {
            Total: data.Total,
            Participants: data.Participants.map(function (participant) {
                return {
                    MemberId: participant.Owner.MemberId,
                    UserId: participant.Owner.UserId,
                    FullName: participant.Owner.FullName,
                    Department: participant.Owner.DeptName,
                    Location: participant.Owner.LocName,
                    Title: participant.Owner.Title,
                    IsAssigned: participant.TemplateIds.indexOf(data.TemplateId) > -1
                };
            })
        };
    },
    MapTeamParticipantsForEdit = function (data) {
        return data.Teams.map(function (team) {
            return {
                hgId: team.Id,
                Name: team.Name,
                LeadByName: team.GoalOwner ? team.GoalOwner.FullName : '',
                IsInCycle: data.TeamParticipants.some(function (teamParticipant) {
                    return teamParticipant.ParticipantId === team.Id;
                })
            };
        });
    },

    MapCycleEditDto = function (data) {
        var isDeliveryDateEditable = function (editability, participantType) {
                if (participantType === GoalEnums.ParticipantType.Member) {
                    return editability.MemberDeliveryDate;
                }
                if (participantType === GoalEnums.ParticipantType.Team) {
                    return editability.TeamDeliveryDate;
                }
                if (participantType === GoalEnums.ParticipantType.Company) {
                    return editability.CompanyDeliveryDate;
                }
                return false;
            },
            isSetDueDateEditable = function (editability, participantType) {
                if (participantType === GoalEnums.ParticipantType.Member) {
                    return editability.MemberSetDueDate;
                }
                if (participantType === GoalEnums.ParticipantType.Team) {
                    return editability.TeamSetDueDate;
                }
                if (participantType === GoalEnums.ParticipantType.Company) {
                    return editability.CompanySetDueDate;
                }
                return false;
            },
            deliveryMethods = data.Cycle.DeliveryMethods.map(
                function (method) {
                    return {
                        ApprovalFlags: method.ApprovalFlags,
                        CheckInFrequency: method.CheckInFrequency,
                        DeliveryDate: method.DeliveryDate,
                        DeliveryTrigger: method.DeliveryTrigger,
                        ParticipantType: method.ParticipantType,
                        SetDueDate: method.SetDueDate,
                        includeInCycle: true,
                        DeliveryDateEditable: isDeliveryDateEditable(data.Editability, method.ParticipantType),
                        SetDueDateEditable: isSetDueDateEditable(data.Editability, method.ParticipantType),
                        SkipSetApprove: method.SkipSetApprove,
                        SkipCloseApprove: method.SkipCloseApprove
                    };
                }
            ),
            editDto = new CycleEditDto({
                Cycle: {
                    CloseDate: data.Cycle.ClosePromptDate,
                    ClosePeriod: data.Cycle.ClosePeriod,
                    GoalWeighting: data.Cycle.GoalWeighting,
                    DeliveryMethods: deliveryMethods,
                    PeriodType: data.Cycle.PeriodType,
                    Status: data.Cycle.Status,
                    RecurrenceFrequency: data.Cycle.RecurrenceFrequency,
                    Title: data.Cycle.Title,
                    hgId: data.Cycle.hgId,
                    CompanyGoalOwner: data.Cycle.CompanyGoalOwner,
                    Note: data.Cycle.Note
                },
                Teams: data.Teams.map(function (team) {
                    return {
                        hgId: team.Id,
                        Name: team.Name,
                        LeadByName: team.GoalOwner ? team.GoalOwner.FullName : '',
                        IsInCycle: data.TeamParticipants.some(function (teamParticipant) {
                            return teamParticipant.ParticipantId === team.Id;
                        })
                    };
                }),
                Members: data.Members.map(function (member) {
                    return {
                        MemberId: member.hgId,
                        UserId: member.UserId,
                        FullName: member.FullName,
                        Role: member && member.RolesInGroup ? member.RolesInGroup[0] : '',
                        Department: member.GroupDepartmentName,
                        IsInCycle: data.MemberParticipants.some(function (memberParticipant) {
                            return memberParticipant.ParticipantId === member.hgId;
                        })
                    };
                }),
                TotalMemberNumber: data.TotalMemberNumber,
                TotalTeamNumber: data.TotalTeamNumber,
                Editability: data.Editability
            });
        return editDto;
    },

    MapGoalCycleSummaries = function (cycles) {
        var items = [];
        cycles.forEach(function (cycle) {
            var item = new GoalCycleSummary(cycle);
            item.ParticipantTypes = cycle.DeliveryMethods
                .map(function (method) {
                    return { type: method.ParticipantType, deliveryDate: method.DeliveryDate};
                });
            item.PendingClosure = Date.now() < cycle.ClosePromptDate;
            if (cycle.CycleSnapshot) {
                if (cycle.CycleSnapshot.TotalGoalNumber > 0) {
                    item.SetAndBeyondPercentage = (cycle.CycleSnapshot.InProgressGoalNumber + cycle.CycleSnapshot.SubmittedForClosureGoalNumber + cycle.CycleSnapshot.ClosedGoalNumber) / cycle.CycleSnapshot.TotalGoalNumber * 100;
                    if (!item.PendingClosure) {
                        item.ClosedPercentage = cycle.CycleSnapshot.ClosedGoalNumber / cycle.CycleSnapshot.TotalGoalNumber * 100;
                    }
                    item.AvgGoalCompletePercentage = cycle.CycleSnapshot.AvgGoalCompletePercentage;
                }
            }
            item.AvgGoalCompletePercentage = cycle.CycleSnapshot.AvgGoalCompletePercentage;
            if (cycle.CycleSnapshot.TotalParticipantNumWithGoals) {
                item.InProgressUserPercentage = cycle.CycleSnapshot.TotalParticipantNumWithGoals ? (1 - cycle.CycleSnapshot.PreInProgressParticipantNumWithGoals / cycle.CycleSnapshot.TotalParticipantNumWithGoals) * 100 : 0;
            }
            if (cycle.CycleSnapshot.InProgressGoalNumber > 0) {
                item.OnTimePercentage = cycle.CycleSnapshot.OntimeGoalNumber / cycle.CycleSnapshot.InProgressGoalNumber * 100;
            }
            item.PendingPercentage = cycle.CycleSnapshot.TotalParticipantNumWithGoals ? (1 - (cycle.CycleSnapshot.PreInProgressParticipantNumWithGoals / cycle.CycleSnapshot.TotalParticipantNumWithGoals)) * 100  : 0;
            item.CloseDate = cycle.ClosePromptDate;
            item.GoalWeighting = cycle.GoalWeighting;
            items.push(item);
        });
        return items;
    },
    MapTeamParticipantsForViewing = function (data) {
        var teamGoalCount = function (participantId) {
                var team = data.GoalCountsByTeams.filter(function (t) {
                        return t._id === participantId;
                    });
                return team.length ? team[0].count : 0;
            };
        if (!data.TeamParticipants) {
            return [];
        }
        return data.TeamParticipants.map(function (participant) {
            return {
                hgId: participant.ParticipantId,
                TeamName: participant.Name,
                OwnerName: participant.Owner.FullName,
                OwnerUserId: participant.Owner.UserId,
                OwnerMemberId: participant.Owner.MemberId,
                Title: participant.Owner.Title,
                GoalCount : teamGoalCount(participant.ParticipantId)
            };
        });
    },
    MapCycleDetailsDto = function (data) {
        var teamGoalCount = function (participantId) {
                var team = data.GoalCountsByTeams.filter(function (t) {
                        return t._id === participantId;
                    });
                return team.length ? team[0].count : 0;
            },
            getInProgressUserPercentage = function (snapshot) {
                return snapshot.TotalParticipantNumWithGoals ? (1 - snapshot.PreInProgressParticipantNumWithGoals / snapshot.TotalParticipantNumWithGoals) * 100 : 0;
            },
            getOnTimePercentage = function (snapshot) {
                return snapshot.InProgressGoalNumber ? snapshot.OntimeGoalNumber / snapshot.InProgressGoalNumber * 100 : 0;
            },
            resolveCanEdit = function (cycleStatus) {
                return [GoalEnums.CycleStatus.Draft, GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress].indexOf(cycleStatus) > -1;
            },
            clsDelStatusArray = [GoalEnums.CycleStatus.Draft, GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress],
            cycleDto = new CycleDetailDto({
                hgId: data.cycle.hgId,
                IndividualGoalsTotal: data.totalIndividualGoals,
                TeamParticipantsCount: data.TeamParticipantsCount,
                Title: data.cycle.Title,
                Status: data.cycle.Status,
                CanEdit: resolveCanEdit(data.cycle.Status),
                CanClose: clsDelStatusArray.indexOf(data.cycle.Status) > -1,
                CanDelete: clsDelStatusArray.indexOf(data.cycle.Status) > -1,
                NextRoundDate: data.Recurrence ? data.Recurrence.NextTriggerDate : null,
                RecurrenceFrequency: data.cycle.RecurrenceFrequency,
                GoalWeighting: data.cycle.GoalWeighting,
                Overall: {
                    GoalSet: getInProgressUserPercentage(data.cycle.CycleSnapshot),
                    GoalCurrent: getOnTimePercentage(data.cycle.CycleSnapshot),
                    AvgCompletion: data.cycle.CycleSnapshot.AvgGoalCompletePercentage,
                    CloseDate: data.cycle.ClosePromptDate
                },
                Company: {
                    OwnerName: data.cycle.CompanyGoalOwner.FullName,
                    OwnerUserId: data.cycle.CompanyGoalOwner.UserId,
                    OwnerMemberId: data.cycle.CompanyGoalOwner.MemberId,
                    Title:  data.cycle.CompanyGoalOwner.Title,
                    Goals: data.companyGoals ? data.companyGoals.map(function (goal) {
                        return new GoalInCycle({
                            hgId: goal.hgId,
                            Status: goal.Status,
                            GoalName: goal.Name,
                            Aligned: true,
                            LastUpdated: goal.ModifiedDate,
                            UpdateFrequency: goal.CheckInFrequency,
                            Current: goal.UpToDate,
                            Completion: goal.PercentCompletion
                        });
                    }) : []
                },
                Teams: data.teamParticipants ? data.teamParticipants.map(function (team) {
                    return {
                        hgId: team.ParticipantId,
                        TeamName: team.Name,
                        OwnerName: team.Owner.FullName,
                        OwnerUserId: team.Owner.UserId,
                        OwnerMemberId: team.Owner.MemberId,
                        Title: team.Owner.Title,
                        GoalCount : teamGoalCount(team.ParticipantId)
                    };
                }) : [],
                Individuals : data.memberGoals ? data.memberGoals.map(function (goal) {
                    return {
                        hgId: goal.hgId,
                        Status: goal.Status,
                        OwnerName: goal.Owner.FullName,
                        OwnerMemberId: goal.Owner.MemberId,
                        OwnerUserId: goal.Owner.UserId,
                        ManagerName: goal.Approver.FullName,
                        ManagerMemberId: goal.Approver.MemberId,
                        ManagerUserId: goal.Approver.UserId,
                        GoalName: goal.Name,
                        LastUpdated: goal.ModifiedDate,
                        UpdateFrequency: goal.CheckInFrequency,
                        Current: goal.UpToDate,
                        Completion: goal.PercentCompletion
                    };
                }) : []
            });
        return cycleDto;
    },
    ProcessNewGoalCycle = function (cycleAndParticipants) {
        var draftCycle = new DraftGoalCycle(cycleAndParticipants.cycle);
        draftCycle.teamParticipants = cycleAndParticipants.teamParticipants.map(function (participant) {
            return participant.ParticipantId;
        });
        return draftCycle;
    },
    MapCycleCandidates = function (cycles) {
        return cycles.map(function (cycle) {
            return {
                Id: cycle.hgId,
                Name: cycle.Title,
                UserId: cycle.hgId,
                AvatarId: cycle.hgId,
                Description: cycle.Description,
                ParticipantCount: cycle.ParticipantCount,
                Type: AutocompleteEnums.Entity.GoalCycle
            };
        });
    };

module.exports = {
    MapMemberParticipantsForEdit: MapMemberParticipantsForEdit,
    MapMemberParticipantsByCycleTemplateId: MapMemberParticipantsByCycleTemplateId,
    MapCycleEditDto: MapCycleEditDto,
    MapGoalCycleSummaries: MapGoalCycleSummaries,
    MapCycleDetailsDto: MapCycleDetailsDto,
    ProcessNewGoalCycle: ProcessNewGoalCycle,
    MapTeamParticipantsForEdit: MapTeamParticipantsForEdit,
    MapTeamParticipantsForViewing: MapTeamParticipantsForViewing,
    MapCycleCandidates: MapCycleCandidates
};
