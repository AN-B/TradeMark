/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    GoalEnums = require('../../enums/GoalEnums.js'),
    PetitionEnums = require('../../enums/PetitionEnums.js'),
    FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    EntityActivityEnums = require('../../enums/EntityActivityEnums.js'),
    i18nHelper = require('../../helpers/i18nHelper.js'),
    allGoalStatus = [GoalEnums.GoalStatus.Editing, GoalEnums.GoalStatus.SubmittedForSet, GoalEnums.GoalStatus.InProgress, GoalEnums.GoalStatus.PendingClosure, GoalEnums.GoalStatus.SubmittedForClosure, GoalEnums.GoalStatus.Closed],
    postSetGoalStatus = [GoalEnums.GoalStatus.InProgress, GoalEnums.GoalStatus.PendingClosure, GoalEnums.GoalStatus.SubmittedForClosure, GoalEnums.GoalStatus.Closed],
    GoalOverviewSchema = new DataContractSchema({
        IndividualCycleNumber: {type: Number},//number of active cycles i'm involved as an individual
        TeamCycleNumber: {type: Number},//number of active cycles i'm involved as an individual AND my team is involved
        CompanyCycleNumber: {type: Number},//number of active cycles i'm involved as an individual AND my company is involved
        ApprovalNumber: {type: Number},
        ClosedGoalNumber: {type: Number},
        DirectToCreateAdhoc: {type: Boolean, default: false},
        IsSubordinate: {type: Boolean, default: false}
    }),
    GoalOverview = mongoose.model('GoalOverview', GoalOverviewSchema),

    GoalSummarySchema = new DataContractSchema({
        ParticipantId: {type: String},
        ParticipantType: {type: String},
        ParticipantName: {type: String},
        ParticipantStatus: {type: String},
        GoalWeighting: {type: Boolean},
        WeightingStatus: {type: String},
        GoalWeightType: {type: String},
        WeightingFlags: {//applicable when abovel GoalWeighting is true
            CanWeight: {type: Boolean},//owner can weight goals. Set to true when owner has Editing goals OR latest weighting is NOT pending
            CanSubmit: {type: Boolean}//owner has "Editing" goals to submit
        },
        SetReqApproval: {type: Boolean, default: false},
        CloseReqApproval: {type: Boolean, default: false},
        Message: {type: String},
        MyRole: {type: String, enum: ['Owner', 'Observer']},
        CycleId: {type: String},
        CycleTitle: {type: String},
        SetDueDate: {type: Number},
        ClosePromptDate: {type: Number},
        CloseDueDate: {type: Number},
        PastDue: {type: Boolean},
        Goals: [{
            hgId: {type: String},
            Name: {type: String},
            Status: {type: String},
            StatusText: {type: String},
            ProgressStatus: {type: String},
            ProgressStatusText: {type: String},
            IsPublic: {type: Boolean},
            Rejected: {type: Boolean},
            LastCheckInDate: {type: Number},
            CheckInFrequency: {type: Number},
            PercentCompletion: {type: Number},
            UpToDate: {type: Boolean},
            Owner: {
                MemberId: {type: String},
                UserId: {type: String},
                FullName: {type: String}
            },
            Operations: {
                Edit: {type: Boolean},
                EditInProgress: {type: Boolean},
                Delete: {type: Boolean},
                Close: {type: Boolean},//for now just for adhoc
                Update: {type: Boolean},//update key result progress
                Set: {type: Boolean},//for adhoc goals that have an approver,
                Reopen: {type: Boolean}
            },
            '_id': false
        }]
    }),
    GoalSummary = mongoose.model('GoalSummary', GoalSummarySchema),

    ApprovalSummarySchema = new DataContractSchema({
        CycleId: {type: String},
        CycleTitle: {type: String},
        GoalId: {type: String},
        Name: {type: String},
        Status: {type: String},
        Owner: {
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String}
        }
    }),
    ApprovalSummary = mongoose.model('ApprovalSummary', ApprovalSummarySchema),
    GoalDetailSchema = new DataContractSchema({
        hgId: {type: String},
        OwnerName: {type: String},
        OwnerMemberId: {type: String},
        OwnerUserId: {type: String},
        ManagerName: {type: String},
        ManagerMemberId: {type: String},
        ManagerUserId: {type: String},
        Status: {type: String},
        GoalName: {type: String},
        Aligned: {type: Boolean},
        LastUpdated: {type: Number},
        UpdateFrequency: {type: String},
        Current: {type: Boolean},
        Completion: {type: Number},
        KrNumber: {type: Number}
    }),
    GoalDetail = mongoose.model('GoalDetail', GoalDetailSchema),
    getStatusText = function (status) {
        return {
            Editing: 'goal.int.edi',
            SubmittedForSet: 'goal.int.sfs',
            InProgress: 'goal.int.ipr',
            PendingClosure: 'goal.int.pcl',
            SubmittedForClosure: 'goal.int.sfc',
            Closed: 'goal.int.cls'
        }[status] || 'server.hge.na';
    },
    getProgressStatusText = function (status) {
        return {
            Behind: 'profile.goals.prgs.beh',
            OnTrack: 'profile.goals.prgs.ont',
            AtRisk: 'profile.goals.prgs.risk'
        }[status] || '';
    },
    getAvailableOperations = function (params) {
        var goal = params.Goal,
            memberId = params.MemberId,
            cycleStatus = params.CycleStatus,
            iAmOwner = goal.Owner.MemberId === memberId,
            iAmAprover = goal.Approver.MemberId === memberId;

        return {
            Edit: (goal.Status === GoalEnums.GoalStatus.Editing && (iAmAprover || iAmOwner)) ||
                (goal.Status === GoalEnums.GoalStatus.InProgress && !goal.TemplateId && ((iAmOwner && !goal.Approver.MemberId) || iAmAprover)),
            EditInProgress: goal.Status === GoalEnums.GoalStatus.InProgress &&
                iAmOwner && goal.Approver.MemberId && goal.CycleId && !goal.TemplateId &&
                goal.Participant.ParticipantType === GoalEnums.ParticipantType.Member,
            Delete: !goal.TemplateId && (goal.Status === GoalEnums.GoalStatus.Editing ||
                ((!goal.CycleId && goal.Status === GoalEnums.GoalStatus.InProgress && !goal.Approver.MemberId) && iAmOwner) ||
                (iAmOwner && !goal.Approver.MemberId && [GoalEnums.GoalStatus.Closed, GoalEnums.GoalStatus.Archived].indexOf(goal.Status) === -1 && goal.Participant.ParticipantType === GoalEnums.ParticipantType.Member)),
            Update: goal.Status === GoalEnums.GoalStatus.InProgress && (iAmOwner || iAmAprover),
            Close: goal.Status === GoalEnums.GoalStatus.InProgress && !goal.CycleId && iAmOwner && (goal.ClosePromptDate < Date.now() + 24 * 3600 * 1000 || !goal.ClosePromptDate),
            Set: goal.Status === GoalEnums.GoalStatus.Editing && !goal.CycleId && iAmOwner && goal.Approver.MemberId,
            Reopen: params.OpenClosedGoal && goal.Status === GoalEnums.GoalStatus.Closed && iAmOwner && (!cycleStatus || cycleStatus === GoalEnums.CycleStatus.InProgress)
        };
    },
    getParticipantTypeText = function (type) {
        return {
            Member: 'goal.int.mbr',
            Team: 'goal.int.dpt',
            Company: 'goal.int.com'
        }[type] || 'server.hge.na';
    },
    MapApprovalByPetitioner = function (data) {
        var goalNumbersByMember = {},
            weightingNumbersByMember = {};
        data.forEach(function (petitionerSummary) {
            var memberId = petitionerSummary._id.MemberId[0];
            goalNumbersByMember[memberId] = petitionerSummary.rows.filter(function (row) {
                return [PetitionEnums.PetitionTypes.GoalSet.Name, PetitionEnums.PetitionTypes.GoalClose.Name].indexOf(row.PetitionType) > -1;
            }).length;
            weightingNumbersByMember[memberId] = petitionerSummary.rows.filter(function (row) {
                return [PetitionEnums.PetitionTypes.GoalWeighting.Name].indexOf(row.PetitionType) > -1;
            }).length;
        });
        return data.map(function (petitionerSummary) {
            var memberId = petitionerSummary._id.MemberId[0];
            return {
                MemberId: memberId,
                UserId: petitionerSummary._id.UserId[0],
                FullName: petitionerSummary.rows[0].PetitionerFullName[0],
                GoalNumber: goalNumbersByMember[memberId] || 0,
                GoalWeightingNumber: weightingNumbersByMember[memberId] || 0
            };
        });
    },
    MapAlignGoals = function (goals) {
        return goals.map(function (goal) {
            return {
                GoalId: goal.hgId,
                Name: goal.Name,
                ParticipantType: goal.Participant.ParticipantType,
                ParticipantTypeText: getParticipantTypeText(goal.Participant.ParticipantType)
            };
        });
    },
    resolvedRejectedFlag = function (goal, petitions) {
        var petitionTypeName,
            myPetitions;
        if ([GoalEnums.GoalStatus.Editing, GoalEnums.GoalStatus.InProgress].indexOf(goal.Status) === -1) {
            return false;
        }
        if (goal.Status === GoalEnums.GoalStatus.Editing) {
            petitionTypeName = PetitionEnums.PetitionTypes.GoalSet.Name;
        } else {
            petitionTypeName = PetitionEnums.PetitionTypes.GoalClose.Name;
        }
        myPetitions = petitions.filter(function (petition) {
            return petition.PetitionTypeName === petitionTypeName && petition.EntityId === goal.hgId;
        });
        if (!myPetitions.length || myPetitions[0].Status === PetitionEnums.Status.Approved) {
            return false;
        }
        return true;
    },

    MapApprovalSummary = function (data) {
        var approvalSummaries = [];
        data.Goals.forEach(function (g) {
            var summary = new ApprovalSummary({
                    CycleId: g.CycleId,
                    GoalId: g.hgId,
                    Name: g.Name,
                    Status: g.Status,
                    Owner: {
                        MemberId: g.Owner.MemberId,
                        UserId: g.Owner.UserId,
                        FullName: g.Owner.FullName
                    }
                }),
                mc = data.Cycles.filter(function (c) {
                    return c.hgId === g.CycleId;
                });
            if (mc && mc.length) {
                summary.CycleTitle = mc[0].Title;
            }
            approvalSummaries.push(summary);
        });
        return approvalSummaries;
    },
    MapGoalWeighting = function (data) {
        return {
            ParticipantId: data.Participant.ParticipantId,
            ParticipantType: data.Participant.ParticipantType,
            ParticipantHgId: data.Participant.hgId,
            type: data.Participant.GoalWeightType,
            CycleId: data.Participant.CycleId,
            goals: data.Goals.map(function (goal) {
                return {
                    GoalId: goal.hgId,
                    Weight: Math.round(goal.Weight * 100) / 100,
                    GoalName: goal.Name,
                    Status: goal.Status
                };
            })
        };
    },

    MapGoalOverview = function (data) {
        var getMatchingCycleNumber = function (type) {
                var teamCycles = data.Cycles.filter(function (cycle) {
                        return cycle.DeliveryMethods.some(function (dm) {
                            return dm.ParticipantType === type;
                        });
                    });
                return teamCycles.length;
            },
            getIndividualCycleNumber = function () {
                if ((data.MemberId === data.CurUserMemberId || data.AdhocGoalNumber || data.IsSubordinate) && data.AdhocGoal) {
                    return data.Participants.length || 1;
                }
                return data.Participants.length;
            },
            directToCreateAdhoc = function () {
                return data.AdhocGoal && data.MemberId === data.CurUserMemberId && !data.Participants.length && !data.AdhocGoalNumber && !data.ApprovalNumber;
            };
        return new GoalOverview({
            DirectToCreateAdhoc: directToCreateAdhoc(),
            IndividualCycleNumber: getIndividualCycleNumber(),
            TeamCycleNumber: getMatchingCycleNumber('Team'),
            CompanyCycleNumber: getMatchingCycleNumber('Company'),
            ApprovalNumber: data.ApprovalNumber,
            IsSubordinate: data.IsSubordinate,
            ClosedGoalNumber: data.ClosedGoalNumber
        });
    },

    MapCycleSummariesForReview = function (data) {
        var summaries = [];
        data.Goals.forEach(function (goal) {
            var summary = summaries.filter(function (s) {
                    return s.CycleId === goal.CycleId;
                });
            if (!summary.length) {
                summaries.push({
                    CycleId: goal.CycleId,
                    ParticipantId: goal.Participant.ParticipantId,
                    ParticipantType: goal.Participant.ParticipantType,
                    Title: goal.CycleTitle,
                    Goals: [{
                        hgId: goal.hgId,
                        Name: goal.Name,
                        PercentCompletion: goal.PercentCompletion,
                        Status: goal.Status,
                        StatusText: getStatusText(goal.Status),
                        IsPublic: goal.IsPublic,
                        UpToDate: goal.UpToDate,
                        CycleTitle: goal.CycleTitle,
                        Owner: {
                            MemberId: goal.Owner.MemberId,
                            UserId: goal.Owner.UserId,
                            FullName: goal.Owner.FullName
                        }
                    }]
                });
            } else {
                summary[0].Goals.push({
                    hgId: goal.hgId,
                    Name: goal.Name,
                    PercentCompletion: goal.PercentCompletion,
                    Status: goal.Status,
                    StatusText: getStatusText(goal.Status),
                    IsPublic: goal.IsPublic,
                    UpToDate: goal.UpToDate,
                    CycleTitle: goal.CycleTitle,
                    Owner: {
                        MemberId: goal.Owner.MemberId,
                        UserId: goal.Owner.UserId,
                        FullName: goal.Owner.FullName
                    }
                });
            }
        });
        return summaries;
    },

    MapAlignCycles = function (data, lang) {
        var cycleHash = {},
            cycles;
        data.Cycles.forEach(function (cycle) {
            if (!cycleHash[cycle.hgId]) {
                cycleHash[cycle.hgId] = cycle;
            }
        });
        cycles = data.Participants.map(function (p) {
            return {
                ParticipantId: p.ParticipantId,
                ParticipantType: p.ParticipantType,
                ParticipantStatus: p.Status,
                ClosePromptDate: p.ClosePromptDate,
                CycleId: p.CycleId,
                Note: cycleHash[p.CycleId].Note || '',
                CycleTitle: cycleHash[p.CycleId].Title || ''
            };
        });
        if (data.AdhocGoal && data.ParticipantType === GoalEnums.ParticipantType.Member) {
            cycles.push({
                CycleTitle: i18nHelper.translate(lang, 'goal.int.pag'),
                CycleId: 'ad-hoc-cycle-dummy-id'
            });
        }
        return cycles.filter(function (cycle) {
            return !!cycle.CycleTitle;
        });
    },

    containsItemsIOwn = function (items) {
        return items.some(function (item) {
            return item.MyRole === 'Owner' && [
                GoalEnums.ParticipantStatus.NotStarted,
                GoalEnums.ParticipantStatus.Setting,
                GoalEnums.ParticipantStatus.SubmittedForSet,
                GoalEnums.ParticipantStatus.InProgress].indexOf(item.ParticipantStatus) > -1;
        });
    },

    MapPetitionsGroupByCycle = function (data) {
        var adhocGoals = data.Goals.filter(function (goal) {
                return !goal.CycleId;
            }),
            cycleGoals = data.Goals.filter(function (goal) {
                return goal.CycleId;
            }),
            weightingPetitionsByCycle = {},
            goalPetitionsByCycle = {},
            petitionsByCycle;
        data.Participants.forEach(function (p) {
            weightingPetitionsByCycle[p.CycleId] = [{
                ParticipantHgId: p.hgId,
                Name: p.Name,
                AvatarId: p.AvatarId
            }];
        });
        cycleGoals.forEach(function (g) {
            if (!goalPetitionsByCycle[g.CycleId]) {
                goalPetitionsByCycle[g.CycleId] = [{
                    GoalId: g.hgId,
                    GoalName: g.Name,
                    Status: g.Status,
                    Name: g.Owner.FullName,
                    AvatarId: g.Owner.UserId,
                    ParticipantId: g.Owner.MemberId
                }];
            } else {
                goalPetitionsByCycle[g.CycleId].push({
                    GoalId: g.hgId,
                    GoalName: g.Name,
                    Status: g.Status,
                    Name: g.Owner.FullName,
                    AvatarId: g.Owner.UserId,
                    ParticipantId: g.Owner.MemberId
                });
            }
        });
        petitionsByCycle = data.Cycles.map(function (cycle) {
            return {
                CycleId: cycle.hgId,
                CycleTitle: cycle.Title,
                WeightingPetitions: weightingPetitionsByCycle[cycle.hgId],
                GoalPetitions: goalPetitionsByCycle[cycle.hgId]
            };
        });
        petitionsByCycle.push({
            CycleId: 'ad-hoc-cycle-dummy-id',
            CycleTitle: 'Ad-hoc goals',
            WeightingPetitions: [],
            GoalPetitions: adhocGoals.map(function (g) {
                return {
                    GoalId: g.hgId,
                    GoalName: g.Name,
                    Status: g.Status,
                    Name: g.Owner.FullName,
                    AvatarId: g.Owner.UserId
                };
            })
        });
        return petitionsByCycle;
    },
    MapCycleSummary = function (data) {
        var items = [],
            statusFilter = (data.CurUserMemberId === data.MemberId || data.IsSubordinate || data.ApproveGoal) ? allGoalStatus : postSetGoalStatus,
            adhocParticipant = {
                ParticipantId: data.MemberId,
                ParticipantType: 'Member',
                ParticipantStatus: 'InProgress',
                MyRole: data.CurUserMemberId === data.MemberId ? 'Owner' : 'Observer',
                CycleTitle: 'Ad-hoc goals',
                CycleId: 'ad-hoc-cycle-dummy-id',
                Goals: data.Goals.filter(function (g) {
                    return !g.CycleId &&
                        (statusFilter.indexOf(g.Status) > -1 || g.Approver.MemberId === data.CurUserMemberId);
                }).map(function (goal) {
                    return {
                        hgId: goal.hgId,
                        Name: goal.Name,
                        Status: goal.Status,
                        ClosePromptDate: goal.ClosePromptDate,
                        PercentCompletion: goal.PercentCompletion,
                        StatusText: getStatusText(goal.Status),
                        Rejected: resolvedRejectedFlag(goal, data.Petitions),
                        IsPublic: goal.IsPublic,
                        UpToDate: goal.UpToDate,
                        AdhocPastPrompt: goal.ClosePromptDate > Date.now() && goal.Status !== GoalEnums.GoalStatus.Closed,
                        Owner: {
                            MemberId: goal.Owner.MemberId,
                            UserId: goal.Owner.UserId,
                            FullName: goal.Owner.FullName
                        },
                        Operations: getAvailableOperations({
                            Goal: goal,
                            MemberId: data.CurUserMemberId,
                            OpenClosedGoal: data.OpenClosedGoal
                        }),
                        ProgressStatus: goal.ProgressStatus || '',
                        ProgressStatusText: getProgressStatusText(goal.ProgressStatus)
                    };
                })
            },
            cycleHashedByhgId = {},
            goalsHashedByCycleId = {};
        function resolveWeightingFlags(cycle) {
            if (cycle.MyRole !== GoalEnums.RoleInCycle.Owner) {
                return {
                    CanWeight: false,
                    CanSubmit: false
                };
            }
            if (!cycle.GoalWeighting || !cycle.Goals.length) {
                return {
                    CanWeight: false,
                    CanSubmit: false
                };
            }
            var canSubmit = !data.Closed && cycle.Goals.some(function (g) {
                return g.Status === GoalEnums.GoalStatus.Editing;
            });

            return {
                CanWeight: !data.Closed && (cycle.WeightingStatus !== GoalEnums.WeightingStatus.Pending || canSubmit),
                CanSubmit: canSubmit
            };
        }
        function getWeightingNote(particpant) {
            if (particpant.WeightingStatus !== GoalEnums.WeightingStatus.Rejected) {
                return '';
            }
            var petition = data.Petitions.filter(function (petition) {
                    return petition.PetitionTypeName === PetitionEnums.PetitionTypes.GoalWeighting.Name && petition.EntityId === particpant.hgId;
                }),
                rejections;
            if (!petition || !petition.length) {
                return '';
            }
            rejections = petition[0].History.filter(function (history) {
                return history.Activity === PetitionEnums.ActivityType.Deny;
            });
            if (!rejections) {
                return '';
            }
            return rejections[rejections.length - 1].Note;
        }
        data.Cycles.forEach(function (cycle) {
            cycleHashedByhgId[cycle.hgId] = cycle;
        });
        data.Goals.forEach(function (goal) {
            if (statusFilter.indexOf(goal.Status) > -1 && goal.CycleId) {
                if (!goalsHashedByCycleId[goal.CycleId]) {
                    goalsHashedByCycleId[goal.CycleId] = [goal];
                } else {
                    goalsHashedByCycleId[goal.CycleId].push(goal);
                }
            }
        });
        data.Participants.forEach(function (p) {
            var cycle = cycleHashedByhgId[p.CycleId],
                deliveryMethod,
                item = {
                    ParticipantId: p.ParticipantId,
                    ParticipantType: p.ParticipantType,
                    ParticipantStatus: p.Status,
                    GoalWeighting: p.GoalWeighting,
                    WeightingStatus: p.WeightingStatus,
                    WeightingNote: getWeightingNote(p),
                    GoalWeightType: p.GoalWeightType,
                    SetDueDate: p.SetDueDate,
                    ClosePromptDate: p.ClosePromptDate,
                    CloseDueDate: p.CloseDueDate,
                    PastDue: p.Status !== 'Completed' ? p.SetDueDate < Date.now() : false,
                    CycleId: p.CycleId,
                    MyRole: data.CurUserMemberId === data.MemberId ? 'Owner' : 'Observer'
                },
                defaultWeight = function (goal, arr) {
                    if (item.GoalWeightType !== 'Custom' && item.GoalWeighting) {
                        return Math.round(100 / arr.length * 100) / 100;
                    }
                    return goal.Weight;
                };
            item.Goals = (goalsHashedByCycleId[p.CycleId] || []).map(function (goal, ind, arr) {
                return {
                    hgId: goal.hgId,
                    Name: goal.Name,
                    WeightingStatus: goal.Participant.WeightingStatus,
                    PercentCompletion: goal.PercentCompletion,
                    Status: goal.Status,
                    Weight: defaultWeight(goal, arr),
                    Rejected: resolvedRejectedFlag(goal, data.Petitions),
                    StatusText: getStatusText(goal.Status),
                    ProgressStatus: goal.ProgressStatus || '',
                    ProgressStatusText: getProgressStatusText(goal.ProgressStatus),
                    IsPublic: goal.IsPublic,
                    UpToDate: goal.UpToDate,
                    SkipSetApprove: goal.SkipSetApprove,
                    Owner: {
                        MemberId: goal.Owner.MemberId,
                        UserId: goal.Owner.UserId,
                        FullName: goal.Owner.FullName
                    },
                    Operations: getAvailableOperations({
                        Goal: goal,
                        MemberId: data.CurUserMemberId,
                        CycleStatus: cycle.Status,
                        OpenClosedGoal: data.OpenClosedGoal
                    })
                };
            });
            item.WeightingFlags = resolveWeightingFlags(item);
            if (cycle) {
                item.CycleTitle = cycle.Title;
                deliveryMethod = cycle.DeliveryMethods.find(function (method) {
                    return method.ParticipantType === item.ParticipantType;
                });
                item.SetReqApproval = !deliveryMethod || !deliveryMethod.SkipSetApprove;
            }
            items.push(item);
        });
        if (data.AdhocGoal) {
            items.unshift(adhocParticipant);
        }
        return {
            Cycles: items,
            CanAddNew: !data.Closed && ((data.AdhocGoal && data.MemberId === data.CurUserMemberId) || containsItemsIOwn(items) || (data.AdhocGoal && data.IsSubordinate))
        };
    },
    MapSsd = function (members) {
        return members.map(function (m) {
            return {
                Id: m.hgId,
                Name: m.FullName,
                UserId: m.UserId,
                AvatarId: m.UserId,
                Description: m.GroupDepartmentName,
                Type: 'Member'
            };
        });
    },
    MapApproverSsd = function (approver) {
        return [{
            hgId: approver.MemberId,
            Id: approver.MemberId,
            Name: approver.FullName,
            AvatarId: approver.UserId,
            Type: GoalEnums.ParticipantType.Member,
            Description: ''
        }];
    },
    MapGoal = function (data) {
        var g = data.Goal;
        return {
            hgId: g.hgId,
            Name: g.Name,
            Status: g.Status,
            LastCheckInDate: g.LastCheckInDate,
            StatusText: getStatusText(g.Status),
            IsPublic: g.IsPublic,
            CheckInFrequency: g.CheckInFrequency,
            PercentCompletion: g.PercentCompletion,
            Rejected: false,
            Owner: {
                MemberId: g.Owner.MemberId,
                UserId: g.Owner.UserId,
                FullName: g.Owner.FullName
            },
            Operations: getAvailableOperations({
                Goal: g,
                MemberId: data.CurUserMemberId,
                OpenClosedGoal: data.OpenClosedGoal
            })
        };
    },
    MapSetGoalDto = function (data) {
        var resolveWeightingFlags = function (goals) {
                return {
                    CanWeight: data.Participant.GoalWeighting && goals.length && goals[0].SkipSetApprove,
                    CanSubmit: false
                };
            };
        return new GoalSummary({
            ParticipantId: data.Participant.ParticipantId,
            ParticipantType: data.Participant.ParticipantType,
            ParticipantStatus: data.Participant.Status,
            GoalWeighting: data.Participant.GoalWeighting,
            WeightingStatus: data.Participant.WeightingStatus,
            WeightingFlags: resolveWeightingFlags(data.Goals),
            GoalWeightType: data.Participant.GoalWeightType,
            SetDueDate: data.Participant.SetDueDate,
            PastDue: data.Participant.Status !== 'Completed' ? data.Participant.SetDueDate < Date.now() : false,
            ClosePromptDate: data.Participant.ClosePromptDate,
            CloseDueDate: data.Participant.CloseDueDate,
            CycleId: data.Participant.CycleId,
            MyRole: 'Owner',
            Message: data.Message,
            CycleTitle: data.Cycle.Title,
            Goals: data.Goals.map(function (g) {
                return {
                    hgId: g.hgId,
                    Name: g.Name,
                    Status: g.Status,
                    LastCheckInDate: g.LastCheckInDate,
                    StatusText: getStatusText(g.Status),
                    IsPublic: g.IsPublic,
                    CheckInFrequency: g.CheckInFrequency,
                    PercentCompletion: g.PercentCompletion,
                    UpToDate: g.UpToDate,
                    Rejected: false,
                    Owner: {
                        MemberId: g.Owner.MemberId,
                        UserId: g.Owner.UserId,
                        FullName: g.Owner.FullName
                    },
                    Operations: getAvailableOperations({
                        Goal: g,
                        MemberId: data.CurUserMemberId
                    })
                };
            })
        });
    },
    mapItemGoals = function (params) {
        params.Goals.forEach(function (g) {
            params.Item.Goals.push({
                hgId: g.hgId,
                Name: g.Name,
                Status: g.Status,
                IsPublic: g.IsPublic,
                StatusText: getStatusText(g.Status),
                ProgressStatus: g.ProgressStatus || '',
                ProgressStatusText: getProgressStatusText(g.ProgressStatus),
                LastCheckInDate: g.LastCheckInDate,
                CheckInFrequency: g.CheckInFrequency,
                PercentCompletion: g.PercentCompletion,
                UpToDate: g.UpToDate,
                Owner: {
                    MemberId: g.Owner.MemberId,
                    UserId: g.Owner.UserId,
                    FullName: g.Owner.FullName
                },
                Operations: getAvailableOperations({
                    Goal: g,
                    MemberId: params.CurUserMemberId,
                    CycleStatus: params.CycleStatus,
                    OpenClosedGoal: params.OpenClosedGoal
                })
            });
        });
    },
    MapCompanyGoalProfile = function (data) {
        var findAlignCompanyParticipant = function (params) {
                return data.CompanyParticipants.filter(function (cp) {
                    return cp.CycleId === params.CycleId;
                })[0];
            },
            participantHashByTypeAndCycleId = {
                Member: {},
                Team: {},
                Company: {}
            },
            items = [],
            goalHashByCycleId = {};
        data.Participants.forEach(function (participant) {
            if (participantHashByTypeAndCycleId[participant.ParticipantType]) {
                participantHashByTypeAndCycleId[participant.ParticipantType][participant.CycleId] = participant;
            }
        });
        data.Goals.forEach(function (goal) {
            if (!goalHashByCycleId[goal.CycleId]) {
                goalHashByCycleId[goal.CycleId] = [goal];
            } else {
                goalHashByCycleId[goal.CycleId].push(goal);
            }
        });
        data.Cycles.forEach(function (cycle) {
            var matchingParticipant = participantHashByTypeAndCycleId[GoalEnums.ParticipantType.Company][cycle.hgId],
                item,
                alignCompanyParticipant,
                goals;
            if (matchingParticipant) {//this member is a company goal owner in this cycle
                item = new GoalSummary({
                    ParticipantId: matchingParticipant.ParticipantId,
                    ParticipantType: matchingParticipant.ParticipantType,
                    ParticipantName: matchingParticipant.Name,
                    ParticipantStatus: matchingParticipant.Status,
                    SetDueDate: matchingParticipant.SetDueDate,
                    PastDue: matchingParticipant.Status !== GoalEnums.ParticipantStatus.Completed && matchingParticipant.SetDueDate < Date.now(),
                    ClosePromptDate: matchingParticipant.ClosePromptDate,
                    CloseDueDate: matchingParticipant.CloseDueDate,
                    CycleId: matchingParticipant.CycleId,
                    MyRole: data.CurUserMemberId === data.MemberId && matchingParticipant.ParticipantType === GoalEnums.ParticipantType.Company  ? GoalEnums.RoleInCycle.Owner : GoalEnums.RoleInCycle.Owner.Observer
                });
                goals = goalHashByCycleId[matchingParticipant.CycleId] || [];
                if (item.MyRole === GoalEnums.RoleInCycle.Owner.Observer) {
                    goals = goals.filter(function (g) {
                        return postSetGoalStatus.indexOf(g.Status) > -1;
                    });
                }
            } else {//this member is a NOT a team goal owner in this cycle
                alignCompanyParticipant = findAlignCompanyParticipant({
                    CycleId: cycle.hgId
                });
                if (alignCompanyParticipant) {//if the member's department is in the cycle
                    item = new GoalSummary({
                        ParticipantId: alignCompanyParticipant.ParticipantId,
                        ParticipantType: alignCompanyParticipant.ParticipantType,
                        ParticipantName: alignCompanyParticipant.Name,
                        ParticipantStatus: alignCompanyParticipant.Status,
                        SetDueDate: alignCompanyParticipant.SetDueDate,
                        PastDue: alignCompanyParticipant.Status !== GoalEnums.ParticipantStatus.Completed && alignCompanyParticipant.SetDueDate < Date.now(),
                        ClosePromptDate: alignCompanyParticipant.ClosePromptDate,
                        CloseDueDate: alignCompanyParticipant.CloseDueDate,
                        CycleId: alignCompanyParticipant.CycleId,
                        MyRole: GoalEnums.RoleInCycle.Observer
                    });
                    goals = goalHashByCycleId[alignCompanyParticipant.CycleId] || [];
                    goals = goals.filter(function (g) {
                        return postSetGoalStatus.indexOf(g.Status) > -1;
                    });
                }
            }
            if (item) {
                item.CycleTitle = cycle.Title;
                mapItemGoals({Item: item, Goals: goals, CurUserMemberId: data.CurUserMemberId, CycleStatus: cycle.Status, OpenClosedGoal: data.OpenClosedGoal});
                items.push(item);
            }
        });
        return {Cycles: items, CanAddNew: containsItemsIOwn(items)};
    },

    MapTeamGoalProfile = function (data) {
        var participantHashByTeamIdAndCycleId = {},
            goalHashByTeamIdAndCycleId = {},
            findAlignTeamParticipant = function (params) {
                var i,
                    teamId,
                    alignParticipant;
                for (i = 0; i < data.DepartmentsUp.length; i += 1) {
                    teamId = data.DepartmentsUp[i].TeamId;
                    alignParticipant = participantHashByTeamIdAndCycleId[teamId] ? participantHashByTeamIdAndCycleId[teamId][params.CycleId] : null;
                    if (alignParticipant) {
                        return alignParticipant;
                    }
                }
                return null;
            },
            participantHashByTypeAndCycleId = {
                Member: {},
                Team: {},
                Company: {}
            },
            items = [];
        data.Participants.forEach(function (participant) {
            if (participantHashByTypeAndCycleId[participant.ParticipantType]) {
                participantHashByTypeAndCycleId[participant.ParticipantType][participant.CycleId] = participant;
            }
        });
        data.TeamParticipants.forEach(function (participant) {
            if (!participantHashByTeamIdAndCycleId[participant.ParticipantId]) {
                participantHashByTeamIdAndCycleId[participant.ParticipantId] = {};
            }
            participantHashByTeamIdAndCycleId[participant.ParticipantId][participant.CycleId] = participant;
        });
        data.Goals.forEach(function (goal) {
            if (!goalHashByTeamIdAndCycleId[goal.Participant.ParticipantId]) {
                goalHashByTeamIdAndCycleId[goal.Participant.ParticipantId] = {};
                goalHashByTeamIdAndCycleId[goal.Participant.ParticipantId][goal.CycleId] = [goal];
            } else if (!goalHashByTeamIdAndCycleId[goal.Participant.ParticipantId][goal.CycleId]) {
                goalHashByTeamIdAndCycleId[goal.Participant.ParticipantId][goal.CycleId] = [goal];
            } else {
                goalHashByTeamIdAndCycleId[goal.Participant.ParticipantId][goal.CycleId].push(goal);
            }
        });
        data.Cycles.forEach(function (cycle) {
            var matchingParticipant = participantHashByTypeAndCycleId[GoalEnums.ParticipantType.Team][cycle.hgId],
                item,
                alignTeamParticipant,
                goals;
            if (matchingParticipant) {//this member is a team goal owner in this cycle
                item = new GoalSummary({
                    ParticipantId: matchingParticipant.ParticipantId,
                    ParticipantType: matchingParticipant.ParticipantType,
                    ParticipantName: matchingParticipant.Name,
                    ParticipantStatus: matchingParticipant.Status,
                    SetDueDate: matchingParticipant.SetDueDate,
                    PastDue: matchingParticipant.Status !== GoalEnums.ParticipantStatus.Completed && matchingParticipant.SetDueDate < Date.now(),
                    ClosePromptDate: matchingParticipant.ClosePromptDate,
                    CloseDueDate: matchingParticipant.CloseDueDate,
                    CycleId: matchingParticipant.CycleId,
                    MyRole: data.CurUserMemberId === data.MemberId && matchingParticipant.ParticipantType === GoalEnums.ParticipantType.Team ? GoalEnums.RoleInCycle.Owner : GoalEnums.RoleInCycle.Owner.Observer
                });
                if (!goalHashByTeamIdAndCycleId[matchingParticipant.ParticipantId]) {
                    goals = [];
                } else {
                    goals = goalHashByTeamIdAndCycleId[matchingParticipant.ParticipantId][matchingParticipant.CycleId] || [];
                }
                if (item.MyRole === GoalEnums.RoleInCycle.Owner.Observer) {
                    goals = goals.filter(function (g) {
                        return postSetGoalStatus.indexOf(g.Status) > -1;
                    });
                }
            } else {//this member is a NOT a team goal owner in this cycle
                alignTeamParticipant = findAlignTeamParticipant({
                    CycleId: cycle.hgId
                });
                if (alignTeamParticipant) {//if the member's department is in the cycle
                    item = new GoalSummary({
                        ParticipantId: alignTeamParticipant.ParticipantId,
                        ParticipantType: alignTeamParticipant.ParticipantType,
                        ParticipantName: alignTeamParticipant.Name,
                        ParticipantStatus: alignTeamParticipant.Status,
                        SetDueDate: alignTeamParticipant.SetDueDate,
                        PastDue: alignTeamParticipant.Status !== GoalEnums.ParticipantStatus.Completed && alignTeamParticipant.SetDueDate < Date.now(),
                        ClosePromptDate: alignTeamParticipant.ClosePromptDate,
                        CloseDueDate: alignTeamParticipant.CloseDueDate,
                        CycleId: alignTeamParticipant.CycleId,
                        MyRole: GoalEnums.RoleInCycle.Observer
                    });
                    if (!goalHashByTeamIdAndCycleId[alignTeamParticipant.ParticipantId]) {
                        goals = [];
                    } else {
                        goals = goalHashByTeamIdAndCycleId[alignTeamParticipant.ParticipantId][alignTeamParticipant.CycleId] || [];
                    }
                    goals = goals.filter(function (g) {
                        return postSetGoalStatus.indexOf(g.Status) > -1;
                    });
                }
            }
            if (item) {
                item.CycleTitle = cycle.Title;
                mapItemGoals({Item: item, Goals: goals, CurUserMemberId: data.CurUserMemberId, CycleStatus: cycle.Status, OpenClosedGoal: data.OpenClosedGoal});
                items.push(item);
            }
        });
        return {Cycles: items, CanAddNew: containsItemsIOwn(items)};
    },
    MapGoalDetails = function (goals) {
        return goals.map(function (g) {
            return new GoalDetail({
                hgId: g.hgId,
                OwnerName: g.Owner.FullName,
                OwnerMemberId: g.Owner.MemberId,
                OwnerUserId: g.Owner.UserId,
                ManagerName: g.Approver.FullName,
                ManagerMemberId: g.Approver.MemberId,
                ManagerUserId: g.Approver.UserId,
                Status: g.Status,
                GoalName: g.Name,
                Aligned: g.AlignedGoal && g.AlignedGoal.GoalId,
                LastUpdated: g.ModifiedDate,
                UpdateFrequency: g.CheckInFrequency,
                Current: g.UpToDate,
                Completion: g.PercentCompletion,
                KrNumber: g.KeyResults.length
            });
        });
    },
    getGoalType = function (type) {
        var goalType = {};
        goalType[GoalEnums.ParticipantType.Member] = 'profile.goals.igt';
        goalType[GoalEnums.ParticipantType.Team] = 'profile.goals.tgt';
        goalType[GoalEnums.ParticipantType.Company] = 'profile.goals.cgt';
        return goalType[type];
    },
    GetGoalDto = function (params, memberId) {
        var getLatestRejectionNote = function () {
                if (!params.Petitions || !params.Petitions.length) {
                    return {};
                }
                if (params.Petitions[0].Status !== PetitionEnums.Status.Denied) {
                    return {};
                }
                var rejections = params.Petitions[0].History.filter(function (history) {
                    return history.Activity === PetitionEnums.ActivityType.Deny;
                });
                if (!rejections.length) {
                    return {};
                }
                return {
                    Note: rejections[rejections.length - 1].Note,
                    Time: rejections[rejections.length - 1].Time,
                    FullName: rejections[rejections.length - 1].FullName
                };
            },
            generateKrDto = function (keyresults) {
                var jsonKeyResults = keyresults.toObject();
                jsonKeyResults.forEach(function (kr) {
                    kr.isPercentage = kr.Measure === GoalEnums.KeyResultMeasureType.Numeric && kr.NumericType === GoalEnums.KeyResultNumericType.Percentage;
                });
                return jsonKeyResults;
            },
            i,
            len;
        if (params.Goal.KeyResultWeightType !== "Custom") {
            for (i = 0, len = params.Goal.KeyResults.length; i < len; i += 1) {
                params.Goal.KeyResults[i].Weight = Math.round(100 / len * 100) / 100;
            }
        }
        return {
            ICanSetApprover: params.ICanSetApprover,
            LastCheckInDate: params.Goal.LastCheckInDate,
            ClosePromptDate: Object.keys(params.Cycle).length ? params.Cycle.ClosePromptDate : params.Goal.ClosePromptDate,
            CheckInFrequency: params.Goal.CheckInFrequency,
            ICanComment: params.ICanComment,
            ICanApprove: params.ICanApprove,
            ICanFollow: params.ICanFollow,
            ICanUnfollow: params.ICanUnfollow,
            ICanEdit: params.ICanEdit,
            ICanReopen: params.ICanReopen,
            CycleId: params.Goal.CycleId,
            Description: params.Goal.Description,
            Name: params.Goal.Name,
            CycleTitle: params.Goal.CycleTitle,
            hgId: params.Goal.hgId,
            KeyResults: generateKrDto(params.Goal.KeyResults),
            PercentCompletion: params.Goal.PercentCompletion ? Math.round(params.Goal.PercentCompletion) : 0,
            Approver: params.Goal.Approver,
            AlignedGoal: params.Goal.AlignedGoal || {},
            Owner: params.Goal.Owner,
            Participant: params.Goal.Participant,
            KeyResultWeightType: params.Goal.KeyResultWeightType,
            IsPublic: params.Goal.IsPublic,
            Status: params.Goal.Status,
            GoalType: getGoalType(params.Goal.Participant.ParticipantType),
            CanUpdate: params.MemberIdInGroup === params.Goal.Owner.MemberId && params.Goal.Status === GoalEnums.GoalStatus.InProgress,
            IMemberId: memberId,
            RejectionNote: getLatestRejectionNote(),
            ProgressStatus: params.Goal.ProgressStatus || '',
            ProgressStatusText: getProgressStatusText(params.Goal.ProgressStatus),
            Weight: Math.round(params.Goal.Weight),
            ShowWeight: params.WeightingStatus === GoalEnums.WeightingStatus.Approved
        };
    },
    GetGoalDtoForApproval = function (params) {
        var goalDto = this.GetGoalDto(params);
        goalDto.Rejections = params.Rejections;
        return goalDto;
    },
    getHistory = function (comment, actvities) {
        var commentActivities = actvities.filter(function (activity) {
                return activity.BatchId === comment.hgId;
            }),
            getKey = function (activity) {
                var measureMapping = {
                        Binary: 'profile.goals.hst.kcu',
                        Numeric: 'profile.goals.hst.ktu',
                        Percentage: 'profile.goals.hst.kpu'
                    },
                    activityTypeMapping = {
                        GoalNameChange: 'profile.goals.hst.gnc',
                        KeyResultNameChange: 'profile.goals.hst.knc',
                        KeyResultTargeChange: 'profile.goals.hst.ktc',
                        AddAlignGoal: 'profile.goals.hst.aag',
                        ChangeAlignGoal: 'profile.goals.hst.cag',
                        ChangeGoalPublicity: 'profile.goals.hst.cgp',
                        KeyResultRemoved: 'profile.goals.hst.krr',
                        KeyResultAdded: 'profile.goals.hst.kra'
                    };
                if (activity.ActivityType === EntityActivityEnums.ActivityType.KeyResultUpdate) {
                    return measureMapping[activity.Activity.Measure];
                }
                return activityTypeMapping[activity.ActivityType];
            },
            getValueByActivity = function (activity) {
                var value;
                if (activity.ActivityType === EntityActivityEnums.ActivityType.KeyResultUpdate) {
                    value = {
                        tlt: activity.Activity.KeyResultName
                    };
                    if (activity.Activity.Measure === GoalEnums.KeyResultMeasureType.Binary) {
                        value.stat = activity.Activity.NewValue ? GoalEnums.KeyResultLabel.Complete : GoalEnums.KeyResultLabel.Incomplete;
                    }
                    if (activity.Activity.Measure === GoalEnums.KeyResultMeasureType.Numeric) {
                        value.prog = Math.round(activity.Activity.NewValue * 1000) / 1000;
                        value.target = Math.round(activity.Activity.Target * 1000) / 1000;
                        if (activity.Activity.Prefix) {
                            value.prog = activity.Activity.Prefix + value.prog.toString();
                            value.target = activity.Activity.Prefix + value.target.toString();
                        }
                        if (activity.Activity.Suffix) {
                            value.prog = value.prog.toString() + activity.Activity.Suffix;
                            value.target = value.target.toString() + activity.Activity.Suffix;
                        }
                    }
                    if (activity.Activity.Measure === GoalEnums.KeyResultMeasureType.Percentage) {
                        value.prog = Math.round(activity.Activity.NewValue * 1000) / 1000;
                        value.stat = GoalEnums.KeyResultLabel.Complete;
                    }
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.GoalNameChange) {
                    value = {
                        tlt: activity.Activity.OldValue,
                        name: activity.Activity.NewValue
                    };
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.KeyResultNameChange) {
                    value = {
                        tlt: activity.Activity.OldValue,
                        name: activity.Activity.NewValue
                    };
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.KeyResultTargeChange) {
                    value = {
                        tlt: activity.Activity.KeyResultName,
                        target: activity.Activity.NewValue
                    };
                    if (activity.Activity.Prefix) {
                        value.target = activity.Activity.Prefix + value.target.toString();
                    }
                    if (activity.Activity.Suffix) {
                        value.target = value.target.toString() + activity.Activity.Suffix;
                    }
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.AddAlignGoal) {
                    value = {
                        name: activity.Activity.NewValue
                    };
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.ChangeAlignGoal) {
                    value = {
                        oldname: activity.Activity.OldValue,
                        newname: activity.Activity.NewValue
                    };
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.ChangeGoalPublicity) {
                    value = {
                        publicity: activity.Activity.NewValue ? GoalEnums.Publicity.Public : GoalEnums.Publicity.Private
                    };
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.KeyResultRemoved) {
                    value = {
                        tlt: activity.Activity.KeyResultName
                    };
                }
                if (activity.ActivityType === EntityActivityEnums.ActivityType.KeyResultAdded) {
                    value = {
                        tlt: activity.Activity.KeyResultName
                    };
                }
                return value;
            };
        return commentActivities.map(function (activity) {
            return {
                key: getKey(activity),
                value: getValueByActivity(activity)
            };
        });
    },
    GetCommentsDto = function (params) {
        var comments = params.Data.Comments || [],
            iAmOwner = (params.Data.Goal && params.Data.Goal.Owner) ? params.Data.Goal.Owner.MemberId === params.CurUserMemberId : false,
            iAmAprover = (params.Data.Goal && params.Data.Goal.Approver) ? params.Data.Goal.Approver.MemberId === params.CurUserMemberId : false;
        return comments.map(function (comment) {
            return {
                hgId: comment.hgId,
                Comment: comment.Comment,
                Type: comment.Type,
                UserhgId: comment.CommenterUserhgId,
                CreatedDate: comment.CreatedDate,
                MemberId: comment.MemberId,
                Name: comment.CommenterFirstName + ' ' + comment.CommenterLastName,
                LikedMembers: comment.LikedMembers,
                History: getHistory(comment, params.Data.Actvities),
                iLike: comment.LikedMembers.some(function (member) {
                    return member.MemberId === params.CurUserMemberId;
                }),
                ICanDelete: iAmAprover || iAmOwner || comment.MemberId === params.CurUserMemberId || ['Admin', 'HGAdmin'].indexOf(params.Role) > -1
            };
        });
    },
    MapOneComment = function (params) {
        var iAmOwner = (params.Data.Goal && params.Data.Goal.Owner) ? params.Data.Goal.Owner.MemberId === params.CurUserMemberId : false,
            iAmAprover = (params.Data.Goal && params.Data.Goal.Approver) ? params.Data.Goal.Approver.MemberId === params.CurUserMemberId : false;
        return {
            hgId: params.Data.Comment.hgId,
            Comment: params.Data.Comment.Comment,
            Type: params.Data.Comment.Type,
            UserhgId: params.Data.Comment.CommenterUserhgId,
            CreatedDate: params.Data.Comment.CreatedDate,
            MemberId: params.Data.Comment.MemberId,
            Name: params.Data.Comment.CommenterFirstName + ' ' + params.Data.Comment.CommenterLastName,
            LikedMembers: params.Data.Comment.LikedMembers,
            History: [],
            iLike: params.Data.Comment.LikedMembers.some(function (member) {
                return member.MemberId === params.CurUserMemberId;
            }),
            ICanDelete: iAmAprover || iAmOwner || params.Data.Comment.MemberId === params.CurUserMemberId ||
                    ['Admin', 'HGAdmin'].indexOf(params.Role) > -1
        };
    },
    GetDashboardStats = function (data) {
        return {
            OpenGoals: data.OpenGoals || 0,
            OnTrack: data.OnTrack || 0,
            Behind: data.Behind || 0,
            AtRisk: data.AtRisk || 0
        };
    },
    getAlignmentTypeText = function (type) {
        return {
            Member: 'goal.int.iag',
            Team: 'goal.int.dag',
            Company: 'goal.int.cag'
        }[type] || 'server.hge.na';
    },
    GetDashboardGoals = function (params, lang) {
        return params.Goals.map(function (item) {
            return {
                hgId: item.hgId,
                Name: item.Name,
                Status: item.ProgressStatus,
                StatusText: i18nHelper.translate(lang, getProgressStatusText(item.ProgressStatus)),
                Type: item.Participant.ParticipantType,
                TypeText: i18nHelper.translate(lang, !item.CycleId && item.Participant.ParticipantType === GoalEnums.ParticipantType.Member ?
                        'goal.int.pag' : getAlignmentTypeText(item.Participant.ParticipantType)),
                Department: params.DepartmentMemberMapping && params.DepartmentMemberMapping[item.Owner.MemberId] ? params.DepartmentMemberMapping[item.Owner.MemberId].DepartmentName : '',
                Owner: item.Owner.FullName,
                OwnerMemberId: item.Owner.MemberId,
                Progress: item.PercentCompletion ? Math.round(item.PercentCompletion * 100) / 100 : 0,
                Updated: item.LastCheckInDate,
                AlignedGoal: (item && item.AlignedGoal && item.AlignedGoal.GoalId) ? {
                    GoalId: item.AlignedGoal.GoalId,
                    Name: item.AlignedGoal.Name,
                    Type: item.AlignedGoal.ParticipantType,
                    TypeText:  i18nHelper.translate(lang, getAlignmentTypeText(item.AlignedGoal.ParticipantType))
                } : ''
            };
        });
    },
    GetDashboardAlignedGoals = function (data, lang) {
        var getAlignedStats = function (goalId) {
            if (!data.AlignedGoals[goalId]) {
                return {
                    Aligned: 0,
                    OnTrack: 0,
                    Behind: 0,
                    AtRisk: 0
                };
            }
            var retVal = {
                OnTrack: data.AlignedGoals[goalId].OnTrack || 0,
                Behind: data.AlignedGoals[goalId].Behind || 0,
                AtRisk: data.AlignedGoals[goalId].AtRisk || 0
            };
            retVal.Aligned = retVal.OnTrack + retVal.Behind + retVal.AtRisk;
            return retVal;
        };
        return !data.Goals || !data.Goals.length ? [] :
                data.Goals.map(function (item) {
                    return {
                        hgId: item.hgId,
                        Name: item.Name,
                        Status: i18nHelper.translate(lang, item.ProgressStatus),
                        StatusText: getProgressStatusText(item.ProgressStatus),
                        Type: i18nHelper.translate(lang, getParticipantTypeText(item.Participant.ParticipantType)),
                        Owner: item.Owner.FullName,
                        Progress: item.PercentCompletion ? Math.round(item.PercentCompletion * 100) / 100 : 0,
                        Updated: item.LastCheckInDate,
                        AlignedGoalStats: getAlignedStats(item.hgId),
                        AlignedGoal: (item && item.AlignedGoal && item.AlignedGoal.GoalId) ? {
                            GoalId: item.AlignedGoal.GoalId,
                            Name: item.AlignedGoal.Name,
                            Type: item.AlignedGoal.ParticipantType,
                            TypeText: getAlignmentTypeText(item.AlignedGoal.ParticipantType)
                        } : ''
                    };
                });
    },
    getArchivedNextStep = function (data) {
        return data.CycleType === FeedbackEnums.CycleType.SelfEvaluation ? FeedbackEnums.NextStep.SelfEvalView : FeedbackEnums.NextStep.View;
    };
module.exports = {
    MapSetGoalDto: MapSetGoalDto,
    MapCycleSummary: MapCycleSummary,
    MapTeamGoalProfile: MapTeamGoalProfile,
    MapGoalOverview: MapGoalOverview,
    MapApprovalSummary: MapApprovalSummary,
    MapCompanyGoalProfile: MapCompanyGoalProfile,
    MapAlignGoals: MapAlignGoals,
    MapGoalDetails: MapGoalDetails,
    GetGoalDto: GetGoalDto,
    GetCommentsDto: GetCommentsDto,
    MapGoal: MapGoal,
    GetGoalDtoForApproval: GetGoalDtoForApproval,
    MapSsd: MapSsd,
    MapApproverSsd: MapApproverSsd,
    MapOneComment: MapOneComment,
    MapCycleSummariesForReview: MapCycleSummariesForReview,
    MapApprovalByPetitioner: MapApprovalByPetitioner,
    MapPetitionsGroupByCycle: MapPetitionsGroupByCycle,
    MapGoalWeighting: MapGoalWeighting,
    GetDashboardStats: GetDashboardStats,
    GetDashboardGoals: GetDashboardGoals,
    MapAlignCycles: MapAlignCycles,
    GetDashboardAlignedGoals: GetDashboardAlignedGoals,
    getArchivedNextStep: getArchivedNextStep
};
