/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    ProductOrderSchema = new DataContractSchema({
        ProductItem : {
            hgId: {type : String, default: ''},
            Name: {type : String, default: ''},
            Description : {type : String, default: ''},
            PointCost : {type : Number, default: 0},
            FriendlyGroupId: {type : Number, default: -1},
            GroupId : {type : String, default: ''},
            Instruction : {type : String, default: ''}
        },
        Quantity : {type : Number, default : 0},
        Requester : {
            MemberId : {type : String},
            UserId : {type : String},
            FullName : {type : String}
        },
        Recipient : {
            MemberId : {type : String},
            UserId : {type : String},
            FullName : {type : String}
        },
        FulfilledDate: {type : Number},
        FriendlyId : {type : Number},
        Status: {type : String},
        CancelReason : {type : String, default: ''}
    }),
    ProductOrder = mongoose.model('ProductOrder', ProductOrderSchema);


exports.ProductOrder = ProductOrder;
