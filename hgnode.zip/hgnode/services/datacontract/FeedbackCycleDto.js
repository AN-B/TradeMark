/*jslint node:true es5:true*/
'use strict';
var FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    config = require('../../configurations/config'),
    i18nHelper = require('../../helpers/i18nHelper.js'),
    isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
    imgPath = isLocal ? './static' : '',
    cycleOperation = {
        Draft: {
            Archive: true,
            Close: false,
            Edit: true,
            View: true,
            Publish: true,
            Duplicate: true
        },
        Pending: {
            Archive: false,
            Close: false,
            Edit: false,
            View: true,
            Publish: false,
            Duplicate: true
        },
        InProgress: {
            Archive: true,
            Close: true,
            Edit: false,
            View: true,
            Publish: false,
            Duplicate: true,
            Report: true
        },
        Closed: {
            Archive: true,
            Close: false,
            Edit: false,
            View: true,
            Publish: false,
            Duplicate: true,
            Report: true
        },
        Archived: {
            Archive: false,
            Close: false,
            Edit: false,
            View: false,
            Publish: false,
            Duplicate: false,
            Report: true
        }
    },
    getSectionTypeText = function (type) {
        return {
            Generic: 'admin.st.gq',
            AdhocGoal: 'admin.st.pg',
            Recognitions: 'admin.st.rg',
            CycleGoal: 'admin.st.cg'
        }[type] || '';
    },
    getSignOffText = function (cycle) {
        var subjectSignOff = cycle.SubjectSignOff,
            reviewerSignOff = cycle.ReviewerSignOff,
            showManagerNotes = cycle.ShowManagerNotes,
            ret;

        if (reviewerSignOff) {
            if (subjectSignOff) {
                ret = showManagerNotes ? 'admin.pub.emsn' : 'admin.pub.empn';
            } else {
                ret = showManagerNotes ? 'admin.pub.msn' : 'admin.pub.mpn';
            }
        } else {
            ret = subjectSignOff ? 'admin.pub.emo' : '';
        }

        return ret;
    },
    MapInitiators = function (initiators) {
        return initiators.map(function (initiator) {
            return {
                hgId: initiator.hgId,
                CycleId: initiator.CycleId,
                Description: initiator.Description,
                CycleTitle: initiator.CycleTitle,
                Status: initiator.Status
            };
        });
    },
    GetCycleSummary = function (data) {
        return {
            hgId: data.Cycle.hgId,
            Name: data.Cycle.Title,
            Type: data.Cycle.Type,
            NotifyInitiator: data.Cycle.NotifyInitiator,
            ExpireRequestDays: data.Cycle.ExpireRequestDays,
            Description: data.Cycle.Description,
            Note: data.Cycle.Note,
            AdminNote: data.Cycle.AdminNote,
            SinglePageQuestion: data.Card.SinglePageQuestion,
            Criteria: data.Cluster ? data.Cluster.Criteria : [],
            ShowTips: [FeedbackEnums.CycleType.Give, FeedbackEnums.CycleType.Request].indexOf(data.Cycle.Type) > -1,
            GiverTips: data.Cycle.GiverTips || FeedbackEnums.TrainingPDFType.None,
            RequesterTips: data.Cycle.RequesterTips || FeedbackEnums.TrainingPDFType.None,
            GiverTipsFileName: data.Cycle.GiverTipsFileName,
            RequesterTipsFileName: data.Cycle.RequesterTipsFileName,
            Operation: cycleOperation[data.Cycle.Status],
            InitiatorSetting: data.Cycle.InitiatorSetting,
            CreatedBy: data.Cycle.CycleOwner.FullName,
            CreatedDate: data.Cycle.CreatedDate,
            SubjectSignOff: data.Cycle.SubjectSignOff,
            ReviewerSignOff: data.Cycle.ReviewerSignOff,
            ShowManagerNotes: data.Cycle.ShowManagerNotes,
            SignOffText: getSignOffText(data.Cycle),
            UseSections: data.Card.UseSections,
            IsPrivate: !!data.Cycle.IsPrivate,
            CanDownloadRequestReport: [FeedbackEnums.CycleType.Give, FeedbackEnums.CycleType.Request, FeedbackEnums.CycleType.EvaluateOthers].indexOf(data.Cycle.Type) > -1,
            Sections: data.Card.Sections.map(function (section) {
                section.TypeText = getSectionTypeText(section.Type);
                return section;
            }),
        };
    },
    GetCycles = function (data) {
        return data.map(function (item) {
            return {
                hgId: item.hgId,
                Title: item.Title,
                Description: item.Description,
                AdminNote: item.AdminNote,
                Status: item.Status,
                Type: item.Type,
                Operation: cycleOperation[item.Status],
                CreatedDate: item.CreatedDate,
                InitiatorSetting: item.InitiatorSetting,
                ClosedDate: item.ClosedDate,
                RequestReport: cycleOperation[item.Status].Report && [FeedbackEnums.CycleType.Give, FeedbackEnums.CycleType.Request, FeedbackEnums.CycleType.EvaluateOthers].indexOf(item.Type) > -1
            };
        });
    },
    GetCycle = function (data) {
        return {
            hgId: data.Cycle.hgId,
            Name: data.Cycle.Title,
            Type: data.Cycle.Type,
            Description: data.Cycle.Description,
            Note: data.Cycle.Note,
            AdminNote: data.Cycle.AdminNote,
            Sections: data.Card.Sections.map(function (section) {
                section.TypeText = getSectionTypeText(section.Type);
                return section;
            }),
            UseSections: data.Card.UseSections,
            GiverTips: data.Cycle.GiverTips,
            RequesterTips: data.Cycle.RequesterTips,
            GiverTipsFileName: data.Cycle.GiverTipsFileName,
            RequesterTipsFileName: data.Cycle.RequesterTipsFileName,
            ExpireRequestDays: data.Cycle.ExpireRequestDays,
            SinglePageQuestion: data.Card.SinglePageQuestion,
            Criteria: data.Cluster ? data.Cluster.Criteria : [],
            Operation: cycleOperation[data.Cycle.Status],
            IsPrivate: !!data.Cycle.IsPrivate
        };
    },
    GetDashboardDetailForInActiveUsers = function (data) {
        data.forEach(function (item) {
            item.HasRequestedFeedBack = item.Detail.some(function (item) {
                return item !== FeedbackEnums.CycleInitiatorStatus.NotStarted;
            });
        });
        return data;
    },
    GetDashboardDetailForUnFilledRequests = function (data) {
        var getData = function (d, t) {
                var x = d.filter(function (item) {
                    return item[t];
                });
                return x.length ? x[0][t] : 0;
            };
        return data.map(function (item) {
            return {
                hgId: item._id.hgId,
                Name: item._id.Name,
                DepartmentName: item.detail.length ? item.detail[0].DepartmentName : '',
                Received: getData(item.detail, 'Received'),
                Declined: getData(item.detail, 'Declined'),
                Expired: getData(item.detail, 'Expired')
            };
        });
    },
    GetDashboardDetail = function (params) {
        var type = {
            RoleModels: function (data) {
                return data;
            },
            UnfulfilledRequests: GetDashboardDetailForUnFilledRequests,
            InActiveUsers: GetDashboardDetailForInActiveUsers
        };
        if (!type[params.Type]) {
            return [];
        }
        return type[params.Type](params.Data);
    },
    MapSsd = function (member) {
        return member.map(function (m) {
            return {
                Id: m.Id,
                Name: m.Name,
                UserId: m.UserId,
                AvatarId: m.UserId,
                Description: m.DepartmentName,
                Type: 'Member'
            };
        });
    };
module.exports = {
    MapInitiators: MapInitiators,
    GetCycleSummary: GetCycleSummary,
    GetCycles: GetCycles,
    GetCycle: GetCycle,
    GetDashboardDetail: GetDashboardDetail,
    MapSsd: MapSsd
};
