/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    NewsSchema = new DataContractSchema({
        hgId: {type : String},
        Title: {type : String},
        Body: {type : String},
        Status: {type : String, enum: ['Tentative', 'Final', 'Deleted'], default: 'Tentative'},
        GroupId: {type : String},
        ModifiedDate: {type : Number, default : Date.now}
    });
exports.News = mongoose.model('News', NewsSchema);