/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    DataContractSchema = require('../../common/DataContractSchema.js'),
    BadgeEnums = require('../../enums/BadgeEnums.js'),
    FeatureFlagEnums = require('../../enums/FeatureFlagEnums.js'),
    guid = require('node-uuid'),
    GroupSummarySchema = new DataContractSchema({
        hgId: {type : String, default : ''},
        HGAccountId: {type : String, default: ''},
        GroupName: { type : String, default: '' }
    }),
    GroupSummary = mongoose.model('GroupSummary', GroupSummarySchema),
    GroupBillingFinancialSchema = new DataContractSchema({
        StartBillingDate: {type : Number},
        RatePerPerson: {type : Number},
        CreditLimit: {type : Number},
        BillMeAllowed: {type : Boolean}
    }),
    GroupBillingFinancialSummary = mongoose.model('GroupBillingFinancialSummary', GroupBillingFinancialSchema),
    MemberSummarySchema = new DataContractSchema({
        hgId: {type: String, default: ''},
        FullName: {type: String, default: ''},
        GroupDepartmentName: {type: String, default: ''},
        UserId: {type: String, default: '' }
    }),
    BadgeSchema = new DataContractSchema({
        Id: {type: String, default: ''},
        hgId: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        BackgroundBadgeId: {type: String, default: ''},
        BackgroundFilename: {type: String, default: ''},
        ForegroundBadgeId: {type: String, default: '' },
        ForegroundFilename: {type: String, default: '' },
        Message: {type: String, default: '' },
        Title: {type: String, default: '' },
        Type: {type: String, default: '' },
        TranslatedValues: {},
        titleRequired: {type: Boolean},
        messageRequired: {type: Boolean},
        text: {type: String, default: '' },
        FriendlyGroupId: {type: String, default: '' },
        ForegroundUrl: {type: String, default: '' },
        BackgroundUrl: {type: String, default: '' },
        BadgeUrl: {type: String, default: '' },
        Order: {type: Number}
    }),
    MemberSummary = mongoose.model('MemberSummary', MemberSummarySchema),
    Badge = mongoose.model('Badge', BadgeSchema),
    GroupDefaultBadge = function (params) {
        var dBadges = BadgeEnums.DefaultBadges,
            groupBadges = params.Templates,
            retVal = [];
        if (!(params.Group.Preference.FeatureFlags.some(function (featureFlag) {
                return featureFlag.FeatureName === FeatureFlagEnums.EnablePolling && featureFlag.FeatureEnabled;
            }))) {
            dBadges = dBadges.filter(function (item) {
                return item.type !== BadgeEnums.Type.Poll;
            });
            groupBadges = groupBadges.filter(function (item) {
                return item.Type !== BadgeEnums.Type.Poll;
            });
        }
        BadgeEnums.DefaultBadges.forEach(function (item) {
            var tempId = guid.v1(),
                groupBadge = groupBadges.filter(function (b) {
                    return item.type === b.Type;
                })[0];
            retVal.push(new Badge({
                Order: item.Order,
                Type: item.type,
                titleRequired: item.titleRequired,
                messageRequired: item.messageRequired,
                text: item.text,
                GroupId: params.Group.hgId,
                GroupName: params.Group.GroupName,
                FriendlyGroupId: params.Group.FriendlyGroupId,
                Id: groupBadge ? groupBadge.hgId : tempId,
                hgId: groupBadge ? groupBadge.hgId : tempId,
                BackgroundBadgeId: groupBadge ? groupBadge.BackgroundBadgeId : '',
                BackgroundFilename: groupBadge ? groupBadge.BackgroundFilename : '',
                ForegroundBadgeId: groupBadge ? groupBadge.ForegroundBadgeId : '',
                ForegroundFilename: groupBadge ? groupBadge.ForegroundFilename : item.fileName,
                Message: groupBadge ? groupBadge.Message : '',
                Title: groupBadge ? groupBadge.Title : item.type + ' Badge',
                TranslatedValues: groupBadge ? groupBadge.TranslatedValues : []
            }));
        });
        return {
            BadgeDefaults: dBadges,
            GroupBadges: retVal.sort(function (a, b) {
                return a.Order - b.Order;
            }),
            FriendlyGroupId: params.Group.FriendlyGroupId
        };
    };
exports.GroupDefaultBadge = GroupDefaultBadge;
exports.GroupSummary = GroupSummary;
exports.MemberSummary = MemberSummary;
exports.GroupBillingFinancialSummary = GroupBillingFinancialSummary;