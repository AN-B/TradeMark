/*jslint node:true es5:true*/
var HgBaseService = require('../framework/HgService.js'),
    CommentService = function () {
        'use strict';
        HgBaseService.apply(this, arguments);
        var RequestManager = this.RequestManager,
            InternalServiceCache = this.InternalServiceCache,
            i18nHelper = require('../helpers/i18nHelper.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            MemberEnums = require('../enums/MemberEnums.js'),
            commentDto = function (data, memberId) {
                return {
                    Name: data.comment.CommenterFirstName + ' ' + data.comment.CommenterLastName,
                    Comment: data.comment.Comment,
                    UserId: data.comment.CommenterUserhgId,
                    hgId: data.comment.hgId,
                    CreatedDate: data.comment.CreatedDate,
                    MemberId: data.comment.MemberId,
                    LikedMembers: data.comment.LikedMembers || [],
                    HasAttachment: data.comment.HasAttachment,
                    Attachments: data.comment.Attachments,
                    TaggedUser: {Tags: data.tags},
                    LikedCount: data.comment.LikedMembers.length,
                    MeLiked: data.comment.LikedMembers.some(function (member) {
                        return member.MemberId === memberId;
                    })
                };
            };
        this.Like = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId);
            commentInternalService.Like({
                Lang: i18nHelper.getRequestLanguageIndex(params),
                correlationId: params.correlationId,
                UserId: params.currentuser.hgId,
                FullName: params.currentuser.UserPersonal.FullName,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                CommentId: params.req.body.CommentId
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };
        this.CommentCoaching = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId);
            params.req.body.Source = 'Web';
            params.req.body.EntityType = EntityEnums.CommentEntityType.Coaching;
            commentInternalService.CommentCoaching({
                Lang: i18nHelper.getRequestLanguageIndex(params),
                correlationId: params.correlationId,
                UserId: params.currentuser.hgId,
                FirstName: params.currentuser.UserPersonal.FirstName,
                LastName: params.currentuser.UserPersonal.LastName,
                FullName: params.currentuser.UserPersonal.FullName,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                CommentRequest: params.req.body
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };

        this.CommentBatch = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId),
                tags = params.req.body.Comment.tags;
            params.req.body.Source = 'Web';
            params.req.body.Comment = params.req.body.Comment.html;
            commentInternalService.CommentBatch({
                Lang: i18nHelper.getRequestLanguageIndex(params),
                correlationId: params.correlationId,
                UserId: params.currentuser.hgId,
                FirstName: params.currentuser.UserPersonal.FirstName,
                LastName: params.currentuser.UserPersonal.LastName,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                CommentRequest: params.req.body,
                Tags: tags
            }, function (error, data) {
                if (error) {
                    return RequestManager.error(params.correlationId, error);
                }
                RequestManager.send(params.correlationId, commentDto(data, params.currentuser.UserContext.MemberIdInGroup));
            });
        };
        this.Comment = function (params) {//this method should be splitted and depcrecated
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId);
            params.req.body.Source = 'Web';
            commentInternalService.Comment_Internal({
                Lang: i18nHelper.getRequestLanguageIndex(params),
                correlationId: params.correlationId,
                UserId: params.currentuser.hgId,
                FirstName: params.currentuser.UserPersonal.FirstName,
                LastName: params.currentuser.UserPersonal.LastName,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                CommentRequest: params.req.body
            }, function (error, data) {
                if (error) {
                    return RequestManager.error(params.correlationId, error);
                }
                RequestManager.send(params.correlationId, data);
            });
        };
        this.DeleteComment = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId);
            commentInternalService.DeleteComment_Internal({
                correlationId: params.correlationId,
                CommentId: params.req.body.CommentId,
                UserId: params.currentuser.hgId,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                PermissionsInGroup: params.currentuser.UserContext.PermissionsInGroup,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                IsAdmin: params.currentuser.UserContext.RolesInGroup.indexOf(MemberEnums.MemberRole.Admin.Name) > -1 || params.currentuser.UserContext.RolesInGroup.indexOf(MemberEnums.MemberRole.HGAdmin.Name) > -1
            }, function (error, data) {
                if (error) {
                    return RequestManager.error(params.correlationId, error);
                }
                RequestManager.send(params.correlationId, data);
            });
        };
        this.DeleteCoachingNote = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId);
            commentInternalService.DeleteCoachingNote_Internal({
                correlationId: params.correlationId,
                CommentId: params.req.body.hgId,
                UserId: params.currentuser.hgId,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                PermissionsInGroup: params.currentuser.UserContext.PermissionsInGroup,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                MemberDepartment: params.currentuser.UserContext.CurrentGroupDepartmentName
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data);
                }
            });
        };
        this.GetCommentByBatchId = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId),
                types = [EntityEnums.CommentType.Comment, EntityEnums.CommentType.Gift];
            if (params.currentuser.UserContext.AggregatedSecuredTabs.recognizeTabs.indexOf('showPointsInFeed') !== -1) {
                types.push(EntityEnums.CommentType.AddPoints);
            }
            commentInternalService.GetCommentByBatchId_Internal({
                correlationId: params.correlationId,
                BatchId: params.req.query.BatchId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                Types: types
            }, function (error, comments) {
                if (error) {
                    return RequestManager.error(params.correlationId, error);
                }
                RequestManager.send(params.correlationId, comments.map(function (comment) {
                    return {
                        Name: comment.CommenterFirstName + ' ' + comment.CommenterLastName,
                        Comment: comment.Comment,
                        UserId: comment.CommenterUserhgId,
                        hgId: comment.hgId,
                        CreatedDate: comment.CreatedDate,
                        MemberId: comment.MemberId,
                        LikedMembers: comment.LikedMembers || [],
                        HasAttachment: comment.HasAttachment,
                        Attachments: comment.Attachments,
                        TaggedUser: comment.TaggedUser,
                        LikedCount: comment.LikedMembers.length,
                        MeLiked: comment.LikedMembers.some(function (member) {
                            return member.MemberId === params.currentuser.UserContext.MemberIdInGroup;
                        })
                    };
                }));
            });
        };
        this.Get = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId);
            commentInternalService.Get_Internal({
                correlationId: params.correlationId,
                EntityId: params.req.query.entityId,
                IsPublic: !params.req.query.isPublic ? true : params.req.query.isPublic,
                EntityType: params.req.query.entityType,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                Type: EntityEnums.CommentType.Comment
            }, function (error, comments) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, comments.map(function (comment) {
                        return {
                            Name: comment.CommenterFirstName + ' ' + comment.CommenterLastName,
                            Comment: comment.Comment,
                            UserId: comment.CommenterUserhgId,
                            hgId: comment.hgId,
                            CreatedDate: comment.CreatedDate,
                            MemberId: comment.MemberId,
                            LikedMembers: comment.LikedMembers || [],
                            HasAttachment: comment.HasAttachment || false,
                            Attachments: comment.Attachments,
                            TaggedUser: comment.TaggedUser
                        };
                    }));
                }
            });
        };

        this.GetCommentsByEntityIds = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId);
            commentInternalService.GetCommentsByEntityIds_Internal({
                correlationId: params.correlationId,
                EntityIds: params.req.body.EntityIds,
                IsPublic: !params.req.body.IsPublic ? true : params.req.body.IsPublic,
                GroupId: params.currentuser.UserContext.CurrentGroupId
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, data.map(function (comment) {
                        return {
                            Name: comment.CommenterFirstName + ' ' + comment.CommenterLastName,
                            Comment: comment.Comment,
                            UserId: comment.CommenterUserhgId,
                            hgId: comment.hgId,
                            CreatedDate: comment.CreatedDate,
                            MemberId: comment.MemberId,
                            LikedMembers: comment.LikedMembers || [],
                            HasAttachment: comment.HasAttachment,
                            Attachments: comment.Attachments,
                            TaggedUser: comment.TaggedUser
                        };
                    }));
                }
            });
        };

        this.EditComment = function (params) {
            var commentInternalService = new InternalServiceCache.Comment(params.correlationId),
                editCommentRequest = params.req.body;
            commentInternalService.EditComment({
                Lang: i18nHelper.getRequestLanguageIndex(params),
                correlationId: params.correlationId,
                CommentId: editCommentRequest.hgId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                Comment: editCommentRequest.newComment.comment.html,
                OldTags: editCommentRequest.TaggedUser ? editCommentRequest.TaggedUser.Tags : [],
                Tags: editCommentRequest.newComment.comment.tags,
                UserId: params.currentuser.hgId,
                CommentModifiedDate: editCommentRequest.ModifiedDate,
                IsAdmin: params.currentuser.UserContext.RolesInGroup.indexOf(MemberEnums.MemberRole.Admin.Name) > -1 || params.currentuser.UserContext.RolesInGroup.indexOf(MemberEnums.MemberRole.HGAdmin.Name) > -1
            }, function (error, data) {
                if (error) {
                    RequestManager.error(params.correlationId, error);
                } else {
                    RequestManager.send(params.correlationId, commentDto(data, params.currentuser.UserContext.MemberIdInGroup));
                }
            });
        };
    };

module.exports = CommentService;
