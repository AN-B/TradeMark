/*jslint node:true es5:true*/

var HgBaseService = require('../framework/HgService'),
    AutoCompleteService = function () {
        "use strict";
        HgBaseService.apply(this, arguments);
        var RequestManager = this.RequestManager,
            paramUtil = require('../util/params.js'),
            InternalServiceCache = this.InternalServiceCache,
            HgLog = require('../framework/HgLog.js'),
            MemberPermission = require('../enums/MemberEnums.js').MemberPermission;
        function getSearchFlag(permissionsInGroup, permission) {
            if (permissionsInGroup.indexOf(MemberPermission.GiveRecognition.Name) === -1) {
                return true;
            }
            return permissionsInGroup.indexOf(permission) !== -1;
        }
        this.GetPreSelectedItems = function (params) {
            var autoCompleteInternalService = new InternalServiceCache.AutoComplete(params.correlationId);
            autoCompleteInternalService.GetPreSelected({
                correlationId: params.correlationId,
                GroupId: params.currentuser.UserContext.CurrentGroupId,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                LocationId: params.currentuser.UserContext.CurrentLocationId,
                DepartmentId: params.currentuser.UserContext.CurrentGroupDepartmentId,
                Role: params.currentuser.UserContext.RolesInGroup,
                Managers: params.currentuser.UserContext.MyManagers,
                ManagerIds: params.currentuser.UserContext.MyManagers.map(function (item) {
                    return item.MemberId;
                }),
                UserId: params.currentuser.hgId,
                PreSelectedId: params.req.body.preSelectedId,
                ExcludeFoundingCompany: params.req.body.efc,
                Status: params.req.body.Status,
                Type: params.req.body.type,
                ExtendedFields: params.req.body.extendedFields || []
            }, function (error, data) {
                if (error) {
                    return RequestManager.error(params.correlationId, error);
                }
                RequestManager.send(params.correlationId, data);
            });
        };
        this.AutoComplete = function (params) {
            var autoCompleteInternalService = new InternalServiceCache.AutoComplete(params.correlationId);
            autoCompleteInternalService.GetAutoComplete({
                correlationId: params.correlationId,
                GroupId: params.req.body.groupId || params.currentuser.UserContext.CurrentGroupId,
                MemberId: params.currentuser.UserContext.MemberIdInGroup,
                LocationId: params.currentuser.UserContext.CurrentLocationId,
                DepartmentId: params.currentuser.UserContext.CurrentGroupDepartmentId,
                Role: params.currentuser.UserContext.RolesInGroup,
                Managers: params.currentuser.UserContext.MyManagers,
                ManagerIds: params.currentuser.UserContext.MyManagers.map(function (item) {
                    return item.MemberId;
                }),
                SearchLocation: getSearchFlag(params.currentuser.UserContext.PermissionsInGroup, MemberPermission.GiveRecognitionToLocation.Name),
                SearchDepartment: getSearchFlag(params.currentuser.UserContext.PermissionsInGroup, MemberPermission.GiveRecognitionToDepartment.Name),
                UserId: params.currentuser.hgId,
                Selected: params.req.body.selected || [],
                Roles: params.req.body.roles || [],
                Excluded: params.req.body.excluded || [],
                SearchTerm: params.req.body.searchTerm ? paramUtil.EscapeBadChars(params.req.body.searchTerm) : '',
                Type: params.req.body.type,
                Take: params.req.body.take || 25,
                Skip: params.req.body.skip || 0,
                ExcludeSelf: params.req.body.es,
                ExcludeFoundingCompany: params.req.body.efc,
                Status: params.req.body.status || ['Active'],
                SortDirection: params.req.body.sortDirection || 'ASC',
                ExtendedFields: params.req.body.extendedFields || [],
                AllowEmptySearchTerm: params.req.body.allowEmptySearchTerm,
                SortField: params.req.body.sortField,
                SelectedDepartmentIds: params.req.body.selectedDepartmentIds || []
            }, function (error, data) {
                if (error) {
                    HgLog.error('SearchTerm:', params.req.body.searchTerm);
                    return RequestManager.error(params.correlationId, error);
                }
                RequestManager.send(params.correlationId, data);
            });
        };
    };

module.exports = AutoCompleteService;