/*jslint node:true es5:true*/

var Roles = {
    EndUser : {
        Description : 'A regular user',
        Permissions : [
            'BasicPermission',
            'CareerTrackAdmin',
            'RecognitionAdmin',
            'GroupAdmin'
        ]
    },
    GlobalAdmin : {
        Description : 'HG global admin. Have permission to do anything',
        Permissions : [
            'BasicPermission',
            'AttachmentHGAdmin',
            'BadgeHGAdmin',
            'CareerTrackAdmin',
            'GroupAdmin',
            'RecognitionAdmin',
            'UserAdmin',
            'ProvisionAdmin',
            'GlobalAdmin'
        ]
    }
};

module.exports = Roles;
