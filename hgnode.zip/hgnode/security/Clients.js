/*jslint node:true es5:true*/

var Clients = [
    {
        hgId : '635be336-7ab7-4708-a18b-595fdc530a46',
        Name : 'HighGroundWorker',
        API_KEY : '99e943b2-52fb-4d55-8a46-d8998660c209',
        Description : 'HighGroundWorker'
    },
    {
        hgId : 'd9f64db1-d80f-422e-b23a-3ec368c671f4',
        Name : 'SalesForce',
        API_KEY : 'ab090607-2b7f-40a0-85a5-054aeadf23b5',
        Description : 'SalesForce'
    },
    {
        hgId : 'c9fc0024-b402-4200-8d09-b769effdaaf2',
        Name : 'LinkedIn',
        API_KEY : '8a07729c-a860-4ba9-9264-d671b9e765a8',
        Description : 'LinkedIn'
    },
];

module.exports = Clients;
