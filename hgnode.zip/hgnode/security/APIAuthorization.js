/*jslint node:true es5:true*/
var APIAuthorization = function () {
    'use strict';
    var Logger = require('../framework/HgLog.js');

    function getAuthResponse(isAuthorized) {
        return {
            isAuthorized: isAuthorized
        };
    }

    this.AuthorizeRequest = function (context, callback) {
        if (context) {
            if (context.service && context.version) {
                if (context.availableservices.indexOf(context.service) !== -1) {
                    Logger.debug('The ' + context.service + ' service requested from ' + context.host + ' on behalf of ' + context.clientname + ' is successfully authorized.');
                    callback(null, getAuthResponse(true));
                } else {
                    Logger.warn('The ' + context.service + ' service requested from ' + context.host + ' on behalf of ' + context.clientname + ' is not avalible to them.');
                    callback(null, getAuthResponse(false));
                }
            } else {
                Logger.warn('No version or service specified in request URI from ' + context.host + ' on behalf of ' + context.clientname);
                callback(null, getAuthResponse(false));
            }
        } else {
            Logger.error('Attempting to authorize an unauthenticated client from ' + context.host + '. How did we get here?');
            callback(new Error('Attempting to authorize an unauthenticated client.'), getAuthResponse(false));
        }
    };
};

module.exports = new APIAuthorization();