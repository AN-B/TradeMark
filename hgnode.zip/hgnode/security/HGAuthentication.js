/*jslint node:true es5:true*/
var HGAuthentication = function (correlationId) {
    'use strict';
    var ProcessorCache = require('../framework/ProcessorCache.js'),
        RequestManager = require('../framework/RequestManager.js'),
        HgLog = require('../framework/HgLog.js'),
        AuthorizationLevel = require('../enums/AuthorizationLevel.js'),
        HGActivityLog = require('../framework/HGActivityLog.js'),
        TokenHelper = require('../helpers/tokenHelper.js'),
        Services = require('./Services.js'),
        Clients = require('./Clients.js'),
        i18nHelper = require('../helpers/i18nHelper'),
        EventData = require('../common/EventData.js'),
        authorizeCompleteCallback = function (error, eventData) {
            var req;
            if (error || !eventData || !eventData.payload) {
                return RequestManager.respondToEvent(new EventData(correlationId, null, error || "server.hge.ath.usp"));
            }
            req = RequestManager.GetRequest(eventData.correlationId);
            RequestManager.SetUserInfo(eventData.correlationId, eventData.payload);
            eventData.servicecallback({
                correlationId: eventData.correlationId,
                req: req,
                host: req.headers['X-Forwarded-For'] || req.hostname,
                currentuser: eventData.payload
            });
        },
        clientLevelAuth = function (params, callback) {
            var clientInfo = Clients.filter(function (client) {
                return client.API_KEY === params.API_KEY;
            });
            if (process.env.SKIP_CLIENT_AUTH === 'Yes') {
                return callback(null, null);
            }
            if (!clientInfo || clientInfo.length !== 1) {
                callback('The client authentication failed.', null);
            } else {
                callback(null, clientInfo[0]);
            }
        },
        checkThrottle = function (params, callback) {
            var type, UserProcessorNoAuth;
            if (Services[params.ServiceName]
                    && Services[params.ServiceName].ThrottledMethods
                    && Services[params.ServiceName].ThrottledMethods[params.MethodName]) {
                type = Services[params.ServiceName].ThrottledMethods[params.MethodName].ThrottleType;
            }
            if (type === 'Process') {
                UserProcessorNoAuth = new ProcessorCache.UserNoAuth(correlationId);
                params.Lang = i18nHelper.getRequestLanguageIndex(params);
                UserProcessorNoAuth.CheckThrottle(params, callback);
            } else {
                callback(null, true);
            }
        };

    this.Authenticate = function (request, serviceName, methodName, servicecallback, correlationId) {
        var UserProcessorNoAuth = new ProcessorCache.UserNoAuth(correlationId),
            GroupIPAddressProcessor,
            serviceAuthLevel = Services[serviceName].AuthorizeLevel,
            fingerPrint = 'f',
            bparam = {
                correlationId: correlationId,
                UserToken: TokenHelper.GetToken(request, 'UserToken') || '',
                ActAsUserToken: TokenHelper.GetToken(request, 'ActAsUserToken') || '',
                ServiceName: serviceName,
                MethodName: methodName,
                servicecallback: servicecallback,
                IPAddress: HGActivityLog.GetIPAddress(request),
                BrowserFingerPrint : request.headers[fingerPrint] || '',
                SId: request.body.SId || '',
                Id: request.body.Id || '',
                Source: 'Web',
                UserAgent: request.headers['user-agent'] || ''
            },
            serviceParameters = {
                correlationId: correlationId,
                req: request,
                host: request.headers['X-Forwarded-For'] || request.hostname,
                IPAddress: HGActivityLog.GetIPAddress(request),
                currentuser: null,
                BrowserFingerPrint: request.headers[fingerPrint] || '',
                UserAgent: request.headers['user-agent'] || ''
            },
            clientAuthParams = {
                correlationId: correlationId,
                ServiceName: serviceName,
                MethodName: methodName,
                API_KEY: request.headers.clientkey,
                IPAddress: HGActivityLog.GetIPAddress(request),
                UserAgent: request.headers['user-agent'] || ''
            },
            clientIPParams = {
                correlationId: correlationId,
                IPAddress: HGActivityLog.GetIPAddress(request),
                BrowserFingerPrint : request.headers[fingerPrint] || '',
                SId: request.body.SId || '',
                Id: request.body.Id || '',
                UserAgent: request.headers['user-agent'] || ''
            },
            throttleParams = {
                correlationId : correlationId,
                Request: request,
                ServiceName: serviceName,
                MethodName: methodName
            };
        checkThrottle(throttleParams, function (error, passed) {
            if (error || passed !== true) {
                HGActivityLog.SaveActivity({
                    CorrelationId : correlationId,
                    ServiceName : serviceName,
                    MethodName : methodName,
                    IPAddress : HGActivityLog.GetIPAddress(request),
                    AccessGranted : false,
                    Message : 'Failed throttle!'
                });
                RequestManager.error(correlationId, error);
                return;
            }
            if (serviceAuthLevel === AuthorizationLevel.Anonymous) {
                HGActivityLog.SaveActivity({
                    CorrelationId: correlationId,
                    ServiceName: serviceName,
                    MethodName: methodName,
                    IPAddress: HGActivityLog.GetIPAddress(request),
                    AccessGranted: false,
                    Message: 'Anonymous Service Calls',
                    UserAgent: request.headers['user-agent'] || ''
                });
                servicecallback(serviceParameters);
            } else if (serviceAuthLevel === AuthorizationLevel.Client) {
                clientLevelAuth(clientAuthParams, function (error, clientInfo) {
                    if (error) {
                        HGActivityLog.SaveActivity({
                            CorrelationId: correlationId,
                            ServiceName: serviceName,
                            MethodName: methodName,
                            IPAddress: HGActivityLog.GetIPAddress(request),
                            AccessGranted: false,
                            Message: 'Client auth failed',
                            UserAgent: request.headers['user-agent'] || ''
                        });
                        RequestManager.error(correlationId, error);
                    } else {
                        HGActivityLog.SaveActivity({
                            CorrelationId: correlationId,
                            ServiceName: serviceName,
                            MethodName: methodName,
                            IPAddress: HGActivityLog.GetIPAddress(request),
                            AccessGranted: true,
                            ClientId: clientInfo ? clientInfo.hgId : null,
                            ClientName: clientInfo ? clientInfo.Name : null,
                            Message: clientInfo ? 'Client API-Key:' + clientInfo.API_KEY + ': Client Level Call Authorized Call API-Key' : 'Client authentication skipped due to environment setting',
                            UserAgent: request.headers['user-agent'] || ''
                        });
                        serviceParameters.ClientInfo = clientInfo;
                        servicecallback(serviceParameters);
                    }
                });
            } else if (serviceAuthLevel === AuthorizationLevel.ClientIP) {
                HGActivityLog.SaveActivity({
                    CorrelationId: correlationId,
                    ServiceName: serviceName,
                    MethodName: methodName,
                    IPAddress: clientIPParams.IPAddress,
                    AccessGranted: false,
                    Message: 'Client IP Service Call',
                    UserAgent: request.headers['user-agent'] || ''
                });
                if (bparam.UserToken || bparam.ActAsUserToken) {
                    UserProcessorNoAuth.Authorize(bparam, authorizeCompleteCallback);
                } else {
                    GroupIPAddressProcessor = new ProcessorCache.GroupIPAddress(correlationId);
                    GroupIPAddressProcessor.IsClientIPAllowed(clientIPParams, function (error, data) {
                        if (error) {
                            RequestManager.send(correlationId, {result : false, message : error});
                        } else {
                            serviceParameters.GroupId = data.GroupId;
                            servicecallback(serviceParameters);
                        }
                    });
                }
            } else if (serviceAuthLevel === AuthorizationLevel.User) {
                if (!bparam.UserToken && !bparam.ActAsUserToken) {
                    HGActivityLog.SaveActivity({
                        CorrelationId: correlationId,
                        ServiceName: serviceName,
                        MethodName: methodName,
                        IPAddress: HGActivityLog.GetIPAddress(request),
                        AccessGranted: false,
                        Message: 'user is not logged in',
                        UserAgent: request.headers['user-agent'] || ''
                    });
                    RequestManager.error(correlationId, 'The user is not logged in. Failed authentication.');
                } else {
                    UserProcessorNoAuth.Authorize(bparam, authorizeCompleteCallback);
                }
            } else {
                HGActivityLog.SaveActivity({
                    CorrelationId: correlationId,
                    ServiceName: serviceName,
                    MethodName: methodName,
                    IPAddress: HGActivityLog.GetIPAddress(request),
                    AccessGranted: false,
                    Message: 'Unknown service authorization level type: ' + serviceAuthLevel,
                    UserAgent: request.headers['user-agent'] || ''
                });
                HgLog.error('Unknown service authorization level type: ' + serviceAuthLevel + ' for service: ' + serviceName + '. Expected: ClientAuth or UserAuth.');
                RequestManager.error(correlationId, 'Error loading service authorization level.');
            }
        });
    };
};

module.exports = HGAuthentication;