'use strict';
var APIAuthHandlers = function () {
    var HgLog = require('../framework/HgLog.js'),
        APIAuthentication = require('./APIAuthentication.js'),
        APIAuthorization = require('./APIAuthorization.js'),
        httpResponseCodes = require('../enums/HttpResponseCodes.js'),
        HGActivityLog = require('../framework/HGActivityLog.js'),
        self = this;

    this.AuthenticationHandler = function (request, response, next) {
        APIAuthentication.AuthenticateClient(request.headers.clientkey, request.hostname, function (err, profile) {
            if (err) {
                HGActivityLog.SaveActivity({
                    ServiceName: request.params.service + ' v:' + request.params.version,
                    IPAddress: HGActivityLog.GetIPAddress(request),
                    AccessGranted: false,
                    Api: true,
                    Messsage: 'Unauthorized API Call. Client Key: ' + request.headers.clientkey + ' error: ' + err
                });

                HgLog.error('API Auth error', err);

                return response.status(httpResponseCodes.ClientError.Unauthorized).send({
                    error: 'Unauthorized client key'
                });
            }

            request.context = {
                clientId: profile.hgId,
                clientname: profile.ClientName,
                groupid: profile.GroupId,
                partnerid: profile.PartnerId,
                availableservices: profile.AvailableServices,
                service: request.params.service,
                version: request.params.version,
                action: request.params.action,
                eventtype: request.params.eventType,
                host: request.headers['X-Forwarded-For'] || request.hostname,
                query: request.query,
                body: request.body
            };

            HGActivityLog.SaveActivity({
                ServiceName: request.params.service + ' v:' + request.params.version,
                IPAddress: HGActivityLog.GetIPAddress(request),
                GroupName: profile.ClientName,
                GroupId: profile.hgId,
                AccessGranted: true,
                Api: true
            });

            next();
        });
    };

    this.AuthorizationHandler = function (request, response, next) {
        APIAuthorization.AuthorizeRequest(request.context, function (err, authorizationResponse) {
            if (err) {
                HgLog.error(err);
                return response.status(httpResponseCodes.ClientError.Forbidden).send({
                    error: 'Not authorized to call this resource'
                });
            }

            if (!authorizationResponse.isAuthorized) {
                return response.status(httpResponseCodes.ClientError.Forbidden).send({
                    error: 'Not authorized to call this resource'
                });
            }

            next();
        });
    };

    this.GetHandlers = function () {
        return [self.AuthenticationHandler, self.AuthorizationHandler];
    };
};

module.exports = new APIAuthHandlers();