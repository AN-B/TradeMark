/*jslint node:true es5:true*/
'use strict';
var Permissions = {
    BasicPermission : {
        Description : 'Basic Permission',
        AvailableServices : [
            'API',
            'AutoComplete',
            'Attachment',
            'Badge',
            'CareerTrack',
            'Comment',
            'Credit',
            'Ecommerce',
            'Finance',
            'Group',
            'Member',
            'News',
            'Payment',
            'PojoFactory',
            'Performance',
            'PublicRecognition',
            'PusherAuth',
            'Recognition',
            'Redeem',
            'Reward',
            'Team',
            'Track',
            'User',
            'UserSelf',
            'Transaction',
            'Upload',
            'SSO',
            'SocialMedia',
            'WishList',
            'Report',
            'UI',
            'Tag',
            'Coaching',
            'Metrics',
            'RulesEngine',
            'ProductItem',
            'ProductOrder',
            'Point',
            'Feed',
            'Conversation',
            'Yammer',
            'Slack',
            'FeedbackCard',
            'FeedbackCycle',
            'FeedbackSession',
            'FeedbackRequest',
            'GoalCycle',
            'Goal',
            'GRS',
            'RSS',
            'Tutorial',
            'Feedback',
            'ManagerAlert',
            'RSS',
            'Feedback',
            'Survey',
            'RSS',
            'Display',
            'Notification',
            'Template',
            'Poll',
            'CheckIn',
            'OptOut',
            "Relevancy",
            'TalentInsight'
        ]
    },
    AttachmentHGAdmin : {
        Description : 'Upload and create attachment to be used for Recognitions',
        AvailableServices : [
            'AttachmentAdmin'
        ]
    },
    BadgeHGAdmin : {
        Description : 'Upload and create badges to be used for Recognition templates',
        AvailableServices : [
            'BadgeAdmin'
        ]
    },
    CareerTrackAdmin : {
        Description : 'Upload and create badges to be used for Recognition templates',
        AvailableServices : [
            'TrackAdmin'
        ]
    },
    GroupAdmin : {
        Description : 'Group adminstration. Able to manage Groups and members',
        AvailableServices : [
            'GroupAdmin',
            'Profanity'
        ]
    },
    GlobalAdmin : {
        Description : 'GlobalAdmin',
        AvailableServices : [
            'GlobalAdmin'
        ]
    },
    ProvisionAdmin : {
        Description : 'Provision',
        AvailableServices : [
            'Provision',
            'Profanity',
            'Demo'
        ]
    },
    RecognitionAdmin : {
        Description : 'Manage recognition templates',
        AvailableServices : [
            'RecognitionAdmin'
        ]
    },
    TrackAdmin : {
        Description : 'Manage recognition templates',
        AvailableServices : [
            'RecognitionAdmin'
        ]
    },
    UserAdmin : {
        Description : 'Manage users',
        AvailableServices : [
            'UserAdmin'
        ]
    }
};

module.exports = Permissions;
