/*jslint node:true es5:true*/
var APIAuthentication = function () {
    'use strict';
    var HgLog = require('../framework/HgLog.js'),
        uuid = require('node-uuid'),
        InternalServiceCache = require('../framework/InternalServiceCache.js'),
        APIInternalService = new InternalServiceCache.API(uuid.v1()),
        GroupInternalService = new InternalServiceCache.Group(uuid.v1()),
        APIKeyStatus = require('../enums/APIKeyStatus.js'),
        ClientProfileType = require('../enums/ClientProfileTypeEnums.js'),
        EntityEnums = require('../enums/EntityEnums.js');

    function updateLastAccessed(profile, host) {
        profile.APIKeyLastAccessedAt = Date.now();
        profile.APIKeyLastAccessedFrom = host;
        profile.save(function (err) {
            if (err) {
                HgLog.error('Error saving client profile', err);
            }
        });
    }

    this.AuthenticateClient = function (clientkey, host, callback) {
        if (!clientkey) {
            return callback('No API key was provided by ' + host);
        }

        APIInternalService.GetClientProfileByAPIKey({clientkey: clientkey}, function (err, profile) {
            if (err) {
                return callback(err);
            }
            if (!profile) {
                return callback('No client profile found for api key ' + clientkey);
            }
            if (profile.APIKeyStatus !== APIKeyStatus.Active) {
                return callback('The api key ' + clientkey + ' provided by ' + host + ' on behalf of ' + profile.ClientName +  ' is not active.');
            }

            if (profile.ClientType === ClientProfileType.Group || !profile.ClientType) {
                if (!profile.GroupId) {
                    return callback('Client Profile does not have a GroupId');
                }
                GroupInternalService.GetGroupById({GroupId: profile.GroupId}, function (err, group) {
                    if (err) {
                        return callback(err);
                    }
                    if (group.Status !== EntityEnums.GroupStatus.Active) {
                        return callback(group.groupName + ' is no longer active');
                    }

                    updateLastAccessed(profile, host);
                    callback(null, profile);
                });
            }

            if (profile.ClientType === ClientProfileType.Partner) {
                if (!profile.PartnerId) {
                    return callback('Client Profile does not have a PartnerId');
                }
                updateLastAccessed(profile, host);
                callback(null, profile);
            }
        });
    };
};

module.exports = new APIAuthentication();