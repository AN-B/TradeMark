/*jslint node:true es5:true*/
var AuthorizationLevel = require('../enums/AuthorizationLevel.js'),
    MemberEnums = require('../enums/MemberEnums.js'),
    AuditLevelType = require('../enums/EntityEnums.js').AuditLevelType,
    Services = {
        Badge: {
            Description: 'Get all badges',
            AuthorizeLevel : AuthorizationLevel.User
        },
        BadgeAdmin: {
            Description: 'Upload badges',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Coaching: {
            Description: 'Credit',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Feedback: {
            Description: 'Feedback',
            AuthorizeLevel : AuthorizationLevel.User
        },
        FeedbackCard: {
            Description: 'Service to manage feedback cards',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Relevancy: {
            Description: 'Service to manage Relevancy',
            AuthorizeLevel : AuthorizationLevel.User
        },
        FeedbackCycle: {
            Description: 'Service to manage feedback cycle',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                CreateCycle: ['ManageFeedback'],
                UpdateCycle: ['ManageFeedback'],
                DuplicateCycle: ['ManageFeedback'],
                ArchiveCycle: ['ManageFeedback'],
                CloseCycle: ['ManageFeedback'],
                GetCycleSummary: ['ManageFeedback'],
                SaveCycleCluster: ['ManageFeedback'],
                PublishCycle: ['ManageFeedback'],
                SearchLibrary: ['ManageFeedback'],
                UploadCyclePDFTips: ['ManageFeedback'],
                SetCycleTips: ['ManageFeedback'],
                GetDashboardStatsDetail: ['ManageFeedback'],
                GetCycleSectionTypes: ['ManageFeedback'],
                GetSuccessionPlanningResults: ['ManageFeedback'],
                GetDashboardStats: ['ManageFeedback'],
                GetSuccessionPlanningResultById: ['ManageFeedback']
            }
        },
        FeedbackSession: {
            Description: 'Service to manage feedback session',
            AuthorizeLevel : AuthorizationLevel.User
        },
        FeedbackRequest: {
            Description: 'Service to manage feedback requests, including request about me, about others, give feedback',
            AuthorizeLevel : AuthorizationLevel.User
        },
        EventBus: {
            Description: 'HighGround Event bus service',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods: {
                RequestFeedback: ['ContinuousFeedback'],
                CommentManagerCheckInSession: ['ContinuousFeedback'],
                GetCommentsBySessionId: ['ContinuousFeedback'],
                ManagerCheckIn: ['ContinuousFeedback'],
                GetGoalsForSection: ['FeedbackCheckin'],
                GetPendingSuccessionPlanningById: ['SuccessionPlanning'],
                GetCompletedSuccessionPlanningById: ['SuccessionPlanning'],
                GetSelfEvalPdfJson: ['ContinuousFeedback'],
                GetSelfEvaluationSessionById: ['FeedbackCheckin'],
                GetMyTeamForCheckIn: ['ContinuousFeedback'],
                GetSessionByIdTip: ['ContinuousFeedback'],
                GetSessionById: ['ContinuousFeedback'],
                SuccessionPlanningAnswerAndSave: ['SuccessionPlanning'],
                SubmitSuccessionPlanningSession: ['SuccessionPlanning'],
                AnswerAndSave: ['ContinuousFeedback'],
                SelfEvalAnswerAndSave: ['FeedbackCheckin'],
                SubmitSession: ['ContinuousFeedback'],
                SaveManagerQuestionNotes: ['ContinuousFeedback'],
                SelfEvalSubmitSession: ['FeedbackCheckin'],
                AcceptRequest: ['RequestFeedback'],
                SeeSubjectRating: ['RequestFeedback'],
                DeclineRequest: ['RequestFeedback'],
                StartAnswer: ['ContinuousFeedback'],
                RateReceivedSession: ['ContinuousFeedback'],
                GetCheckInHistory: ['ContinuousFeedback'],
                GetOverview: ['ContinuousFeedback'],
                GetFeedbackCheckinOverview: ['FeedbackCheckin', 'GiveFeedback'],
                GetRequestCompleted: ['RequestFeedback'],
                GetRequestInbox: ['RequestFeedback'],
                GetCheckInInbox: ['FeedbackCheckin'],
                GetCheckInCompleted: ['FeedbackCheckin'],
                OverviewRequestInbox: ['ContinuousFeedback'],
                OverviewRequestComplete: ['ContinuousFeedback'],
                PrintCheckInPDF: ['FeedbackCheckin']
            }
        },
        RulesEngine: {
            Description: 'Rules engine',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                CreateRule : ['ManageRules'],
                UpdateRule : ['ManageRules'],
                DeleteRule : ['ManageRules'],
                GetRules : ['ManageRules']
            }
        },
        Credit: {
            Description: 'Credit',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                TransferCreditSpend : ['TransferSpendCredits']
            }
        },
        Feed: {
            Description: 'Feed',
            AuthorizeLevel : AuthorizationLevel.User
        },
        GlobalAdmin: {
            Description: 'Services available only to HG GlobalAdmin. Will consolidate other such services',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Goal: {
            Description: 'Services to create, edit, update goal',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                ReopenClosedGoal: ['OpenClosedGoal'],
                SaveTemplate : ['ManageGoalLibrary'],
                GetGoalLibrary : ['ManageGoalLibrary'],
                GetTemplateById: ['ManageGoalLibrary'],
                UnassignTemplateGoal: ['ManageGoalLibrary'],
                AssignTemplateGoal: ['ManageGoalLibrary']
            }
        },
        GoalCycle: {
            Description: 'Services to manage goal cycles',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                GetPendingPartipantsByCycleIdsAndType: ['ManageGoalCycle'],
                CreateGoalCycle: ['ManageGoalCycle'],
                AddTeam: ['ManageGoalCycle'],
                AddTeams: ['ManageGoalCycle'],
                RemoveTeam: ['ManageGoalCycle'],
                RemoveMember: ['ManageGoalCycle'],
                AddMember: ['ManageGoalCycle'],
                PublishCycle: ['ManageGoalCycle'],
                GetCycleDetailsById: ['ManageGoalCycle'],
                GetCycleSummaries: ['ManageGoalCycle'],
                DeleteCycle: ['ManageGoalCycle'],
                GetAssignedCyclesByTemplateId: ['ManageGoalLibrary'],
                GetCycleCandiatesByTemplateId: ['ManageGoalLibrary', 'Goal'],
                RemoveTemplateFromCycle: ['ManageGoalLibrary'],
                GetMemberParticipantsByCycleTemplateId: ['ManageGoalLibrary']
            }
        },
        Performance: {
            Description: 'Performance service',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SaveCard : ['PerformCardLibrary'],
                GetCards : ['PerformCardLibrary', 'PerformDeliverCycle'],
                ArchiveCard: ['PerformCardLibrary'],
                AddQuestion: ['PerformCardLibrary'],
                DuplicateCard: ['PerformCardLibrary'],
                GetQuestionLibrary : ['PerformCardLibrary'],
                DeleteQuestion: ['PerformCardLibrary'],
                GetCycles : ['PerformCycle', 'PerformDeliverCycle'],
                ArchiveReview: ['PerformCycle', 'PerformDeliverCycle'],
                ArchiveAllReviewsInCycle : ['PerformCycle', 'PerformDeliverCycle'],
                CloseReview: ['PerformCycle', 'PerformDeliverCycle'],
                CloseReviewsInCycle: ['PerformCycle', 'PerformDeliverCycle'],
                GetCycleDetailById: ['PerformCycle', 'PerformDeliverCycle'],
                NotifyUnCompletedCycleReviews : ['PerformCycle', 'PerformDeliverCycle'],
                NotifyMemberReviewDeadline : ['PerformCycle', 'PerformDeliverCycle'],
                DeliverCycle : ['PerformCycle', 'PerformDeliverCycle'],
                SaveTemplateCard : ['ManageTemplatePerformCard'],
                GetDistinctDepartmentsByCycle: ['PerformCycle', 'PerformDeliverCycle'],
                UpdateCycleTitle: ['PerformCardLibrary'],
                GetPerformCards: ['PerformCardLibrary'],
                GetCardsToExport: ['ProvisionSystem']
            }
        },
        Team: {
            Description: 'Team service',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SetGoalOwner : ['GroupSettingManagement']
            }
        },
        Journal: {
            Description: 'Journal',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SetGoalOwner : ['GroupSettingManagement']
            }
        },
        Alpha: {
            Description: 'Alpha',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SetGoalOwner : ['GroupSettingManagement']
            }
        },
        Manage: {
            Description: 'Manage',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SetGoalOwner : ['GroupSettingManagement']
            }
        },
        Search: {
            Description: 'Search',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SetGoalOwner : ['GroupSettingManagement']
            }
        },
        General: {
            Description: 'General',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SetGoalOwner : ['GroupSettingManagement']
            }
        },
        Generate: {
            Description: 'Generate',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SetGoalOwner : ['GroupSettingManagement']
            }
        },
        Track: {
            Description: 'career track',
            AuthorizeLevel : AuthorizationLevel.User
        },
        TrackAdmin: {
            Description: 'career track',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                DeleteTrackTemplate : ['TrackLibrary']
            }
        },
        Comment: {
            Description: 'comment on things',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Finance: {
            Description: 'Set user payment profile, credit, etc',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Group: {
            Description: 'Search for groups, apply for memebership, view group public info, etc',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                UpdateMember : ['GroupMemberManagement'],
                SetCreditMasterMember : ['GroupCreditManagement'],
                SetPointMasterMember : ['GroupCreditManagement'],
                OnBoardMember : ['GroupMemberManagement'],
                GetAllRoles: ['GroupMemberManagement'],
                GetAllPermissions: ['GroupMemberManagement'],
                SetRolesAndPermissionsForMembers : ['GroupMemberManagement'],
                GetAllGroups : ['Provision'],
                GetGroupMembers : ['Provision'],
                Impersonate : ['Impersonate'],
                ImpersonateGlobal : ['ImpersonateGlobal'],
                UpdateSegSetting : ['ManageSeg'],
                CreateSeg : ['ManageSeg'],
                GetGroupBillingFinanceInfo : ['ProvisionSystem'],
                GetGroupDemoType: ['GroupMemberManagement'],
                SaveGroupDemoType: ['GroupMemberManagement']
            }
        },
        GroupAdmin: {
            Description: 'Create/delete/modify groups, invite members, approve/deny members',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                SaveValueLevelSetting : ['GroupSettingManagement'],
                SaveCreditSetting : ['GroupCreditManagement'],
                SavePointSetting : ['GroupCreditManagement'],
                SaveBadgeDefaults : ['GroupCreditManagement'],
                GetGroupTerminology: ['GroupTerminologyManagement'],
                SaveGroupTerminology: ['GroupTerminologyManagement']
            }
        },
        Member: {
            Description: 'Member Service',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                GetMembersPermissionsByMemberIds: ['ProvisionSystem'],
                OffBoardMember: ['GroupMemberManagement'],
                UpdateUserAvatarVersion: ['GroupMemberManagement'],
                AddMemberToSeg: ['ManageSeg'],
                GetMemberOffboardCheckList: ['GroupMemberManagement'],
                TransferMemberDuty: ['GroupMemberManagement'],
                GetMergeMemberAccount: ['ProvisionSystem']
            }
        },
        News: {
            Description: 'Post and retrieve group or HG news',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                PostHGNews : ['ProvisionSystem'],
                UpdateHGNews : ['ProvisionSystem'],
                DeleteHGNews : ['ProvisionSystem'],
                PostGroupNews : ['GroupSettingManagement'],
                UpdateGroupNews : ['GroupSettingManagement'],
                DeleteGroupNews : ['GroupSettingManagement']
            }
        },
        Notification: {
            Description: 'Notifications',
            AuthorizeLevel : AuthorizationLevel.User
        },
        PojoFactory: {
            Description: 'Get pojo',
            AuthorizeLevel : AuthorizationLevel.Anonymous
        },
        PublicRecognition: {
            Description: '',
            AuthorizeLevel : AuthorizationLevel.Anonymous
        },
        Redeem: {
            Description: 'Redeem points to offerings, credit, etc',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Reward: {
            Description: 'Create reward items (XP store), redeem rewards with XP points',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                CreateRewardItem : ['GroupSettingManagement'],
                DeleteRewardItem : ['GroupSettingManagement'],
                GetAllRewardItemsForGroup : ['GroupSettingManagement'],
                CancelRewardOrder : ['GroupSettingManagement'],
                BookRewardOrder : ['GroupSettingManagement'],
                FulfillRewardOrder : ['GroupSettingManagement']
            }
        },
        Point: {
            Description: 'Get, update member points, admin manage and mint points',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                MintPoints : ['ManagePointEconomy'],
                GetEconomyTimeline : ['ManagePointEconomy'],
                GetMemberPoints : ['ManagePointEconomy']
            }
        },
        ProductItem: {
            Description: 'Create product items (store), redeem rewards with  points',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                CreateProductItem : ['ManageProductItem'],
                UpdateProductItem : ['ManageProductItem'],
                GetProductItemsForAdmin : ['ManageProductItem'],
                DeleteProductItem : ['ManageProductItem'],
                GiveGift : ['GivePointGift'],
                SaveProductSuggestion: ['SuggestRewardIdea'],
                RejectProductSuggestion: ['ManageProductItem'],
                ApproveProductSuggestion: ['ManageProductItem']
            }
        },
        ProductOrder: {
            Description: 'Order ProductItems with points, manage orders',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                GetOrderForGroup : ['ManageProductOrder'],
                FulfillOrder : ['ManageProductOrder'],
                ExportGroupOrders: ['ManageProductOrder']
            }
        },
        Recognition: {
            Description: 'Give recognitions, view recognitions',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                DeleteRecognition : ['DeleteRecognition'],
                HideRecognition : ['DeleteRecognition'],
                UnstickRecognition : ['DeleteRecognition'],
                GiveCustomizedRecognition : ['CustomizedRecognition'],
                GiveAchievementRecognition : ['AchievementRecognition'],
                GetAchievementTemplates : ['AchievementRecognition'],
                EditRecognitionMessage : ['GiveRecognition'],
                IsRecognitionRelevant: ['GiveRecognition']
            }
        },
        RecognitionAdmin: {
            Description: 'Create recognition templates',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                DeleteTemplate : ['GroupRecognitionsManagement']
            }
        },
        UI: {
            Description: 'Service directly targeted to serve specific UI needs. Be cautious to add methods here as it compromises SOA!',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods : {
                GetAchievementTemplates : ['AchievementRecognition']
            }
        },
        User: {
            Description: 'For users who currently not logged in, e.g., login, create new user. ',
            AuthorizeLevel : AuthorizationLevel.Anonymous
        },
        UserSelf: {
            Description: 'For users to manage their own information, e.g., preference, personal info. ',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods: {
                UpdateMyProfile: ['AllowProfileInfoEditing']
            }
        },
        UserAdmin: {
            Description: 'Manage users, change permissions, etc',
            AuthorizeLevel : AuthorizationLevel.User
        },
        PusherAuth: {
            Description: 'Pusher auth.',
            AuthorizeLevel: AuthorizationLevel.User
        },
        Provision: {
            Description: 'Provision data',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods : {
                ExportDataByGroupId : ['ExportGroupData']
            }
        },
        Upload: {
            Description: 'Upload service',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                UploadTempFile: ['AllowAvatarUpload', 'ManageProductItem', 'SuggestRewardIdea'],
                ProcessAndCropImage: ['AllowAvatarUpload', 'ManageProductItem', 'SuggestRewardIdea']
            }
        },
        Payment: {
            Description: 'Handles aspects of real-time payments and payment profiles.',
            AuthorizeLevel: AuthorizationLevel.User
        },
        WishList: {
            Description: 'User wish list for point store',
            AuthorizeLevel: AuthorizationLevel.User
        },
        Worker: {
            Description: 'Service methods to be called by the background worker.',
            AuthorizeLevel : AuthorizationLevel.Client,
            AuditLevel : AuditLevelType.OnFailure,
            ThrottledMethods : {
                MemberDailyRecapAll : {
                    ThrottleType : 'Process'//at any give moment, the system should only allow one such service call instance. If the previous call is still running, the second call will be denied.
                },
                TrackCheckIn : {
                    ThrottleType : 'Process'//at any give moment, the system should only allow one such service call instance. If the previous call is still running, the second call will be denied.
                },
                Anniversary : {
                    ThrottleType : 'Process'//at any give moment, the system should only allow one such service call instance. If the previous call is still running, the second call will be denied.
                },
                Birthday : {
                    ThrottleType : 'Process'//at any give moment, the system should only allow one such service call instance. If the previous call is still running, the second call will be denied.
                },
                PlaceHolder : {//this is the place holder
                    ThrottleType : 'Interval',//two consecutive service calls should be X (mini)seconds apart. Note this case there might be multiple instances, if the service call takes more than X to finish.
                    Interval : 1000 // in milliseconds
                }
            }
        },
        Transaction: {
            Description: 'Transactions',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                GetTransactionsForGroup: ['GroupCreditManagement'],
                ExportTransactionsForGroup: ['GroupCreditManagement'],
                GetTransactionsAll: ['ProvisionSystem'],
                ExportTransactionsAll: ['ProvisionSystem']
            }
        },
        ExpressPigeon: {
            Description: 'Express Pigeon message log',
            AuthorizeLevel: AuthorizationLevel.Anonymous
        },
        SSO: {
            Description: 'Authenticalted Single-signon providor (more of an OAuth handler.)',
            AuthorizeLevel: AuthorizationLevel.User
        },
        SSONoAuth: {
            Description: 'Non-authenticated single-signon providor',
            AuthorizeLevel: AuthorizationLevel.Anonymous
        },
        SocialMedia: {
            Description: 'Social Media service',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                PostRecognitionToLinkedIn: ['ShareLink']
            }
        },
        Metrics: {
            Description: 'Metrics Service',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods: {
                GetGroupManagerMetrics: ['HGAdminReports'],
                GetMyGroupManagerMetrics: ['AdminReports'],
                GetGroupUserMetrics: ['HGAdminReports'],
                GetMyGroupUserMetrics: ['AdminReports'],
                GetGroupDepartmentsMetrics: ['HGAdminReports'],
                GetMyGroupDepartmentsMetrics: ['AdminReports'],
                GetRecognitionMetrics: ['HGAdminReports'],
                GetMyGroupRecognitionMetrics: ['AdminReports']
            }
        },
        Report: {
            Description: 'Report Service',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods: {
                DownloadReport: ['AdminReports'],
                GetGroups : ['HGAdminReports'],
                GetReportList : ['HGAdminReports'],
                GetClientReportList : ['AdminReports'],
                GetClientReport : ['AdminReports'],
                GetReport: ['HGAdminReports'],
                ExportGroupManagerMetrics : ['AdminReports'],
                ExportGroupUserMetrics : ['AdminReports'],
                ExportGroupDepartmentMetrics : ['AdminReports'],
                ExportGroupCurrentGoals : ['AdminReports'],
                ExportMembers: ['AdminReports']
            }
        },
        Tag : {
            Description: 'Tag Service',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Conversation: {
            Description: 'Conversation service',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Yammer : {
            Description: 'Yammer Integration Service',
            AuthorizeLevel : AuthorizationLevel.User
        },
        Slack: {
            Description: 'Slack Integration Service',
            AuthorizeLevel: AuthorizationLevel.User
        },
        GRS: {
            Description: 'Global Rewards Solutions Service',
            AuthorizeLevel: AuthorizationLevel.User
        },
        ManagerAlert: {
            Description: 'Manager Alert Service',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                GetMyTeamAlerts: ['TeamAction'],
                GetRecognizeTeamStats: ['TeamAction'],
                GetCoachingTeamStats: ['TeamAction'],
                GetPerformTeamStats: ['TeamAction'],
                GetTeamDashboardStats: ['TeamAction'],
                GetTeamDashboardGoals: ['TeamAction'],
                GetFiltersByMemberId: ['TeamAction'],
                GetTeamGoalActivity: ['TeamAction']
            }
        },
        Tutorial: {
            Description: 'Tutorial service',
            AuthorizeLevel: AuthorizationLevel.User
        },
        RSS: {
            Description: 'RSS Service',
            AuthorizeLevel : AuthorizationLevel.User
        },
        AutoComplete: {
            Description: 'AutoComplete Service',
            AuthorizeLevel : AuthorizationLevel.User
        },
        API: {
            Description: 'API Integration Service',
            AuthorizeLevel : AuthorizationLevel.User,
            SecuredMethods: {
                GetAPIKeys: ['ManageAPI'],
                CreateAPIKey: ['ManageAPI'],
                RegenerateAPIKey : ['ManageAPI'],
                GetAvailableServices : ['ManageAPI'],
                GetClientAPIKeys : ['ManageClientApi'],
                CreateAPISettings : ['ManageClientApi'],
                UpdateClientAPISettings : ['ManageClientApi']
            }
        },
        Display : {
            Description: 'Display Service',
            AuthorizeLevel : AuthorizationLevel.ClientIP
        },
        Survey: {
            Description: 'Survey service, add, edit, and complete surveys, view results',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                GetGlobalSurveyDrivers: ['HGManageTemplates'],
                GetSurveyDrivers: ['ManageBenchmarkSurvey'],
                SaveSurveyDriver: ['HGManageTemplates'],
                SaveGroupSurveyDriver: ['ManageBenchmarkSurvey'],
                GetBenchmarkCohortTypeData: ['ManageBenchmarkSurvey'],
                GetGroupBenchmarkSurveyTemplate: ['ManageBenchmarkSurvey'],
                SaveGroupBenchmarkSurveyTemplate: ['ManageBenchmarkSurvey'],
                LoadSurveyPDF: ['ManageBenchmarkSurvey'],
                CancelBenchmarkSurvey: ['ManageBenchmarkSurvey'],
                DisableBenchmarkSurvey: ['ManageBenchmarkSurvey'],
                GetBenchmarkSurveyResult: ['ManageBenchmarkSurvey'],
                GetBenchmarkSurveyResultList: ['ManageBenchmarkSurvey'],
                GetBenchmarkSurveyComments: ['ManageBenchmarkSurvey'],
                GetGroupPulseSurveyTemplate: ['ManagePulseSurvey'],
                SaveGroupPulseSurveyTemplate: ['ManagePulseSurvey'],
                GetPulseSurveyMetricsByTime: ['ManagePulseSurvey'],
                GetAggregatedPulseSurveyMetrics: ['ManagePulseSurvey'],
                DeleteGroupSurveyDriver: ['ManageBenchmarkSurvey'],
                GetPulseSurveyResultList: ['ManagePulseSurvey'],
                GetSurveyResultDrivers: ['ManageBenchmarkSurvey', 'ManagePulseSurvey'],
                EnableAdminKioskMode: ['ManageBenchmarkSurvey', 'AllowSurveyKiosk'],
                ExitKioskMode: ['ManageBenchmarkSurvey', 'AllowSurveyKiosk'],
                StartKioskSurvey: ['AllowSurveyKiosk'],
                GetSurveyByCode: ['AllowSurveyKiosk']
            }
        },
        Poll: {
            Description: 'Poll service',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                CreatePoll: ['ManagePolls']
            }
        },
        Template: {
            Description: 'Template service, add, edit, System Templates',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                SaveBenchmarkSurveyTemplate: ['HGManageTemplates'],
                GetBenchmarkSurveyTemplate: ['HGManageTemplates']
            }
        },
        Profanity: {
            Description: 'Profanity service, get, add, edit, System Templates',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                GetGroupBannedWords: ['ManageProfanity'],
                ExcludeGroupBannedWord: ['ManageProfanity'],
                SaveGroupBannedWord: ['ManageProfanity'],
                GetBannedWords: ['ProvisionSystem'],
                SaveSystemBannedWord: ['ProvisionSystem'],
                RemoveSystemBannedWord: ['ProvisionSystem']
            }
        },
        CheckIn: {
            Description: 'CheckIn service',
            AuthorizeLevel: AuthorizationLevel.User
        },
        Demo: {
            Description: 'Demo Service',
            AuthorizeLevel: AuthorizationLevel.User
        },
        OptOut: {
            Description: 'OptOut Service',
            AuthorizeLevel: AuthorizationLevel.User
        },
        TalentInsight: {
            Description: 'Talent Insight',
            AuthorizeLevel: AuthorizationLevel.User,
            SecuredMethods: {
                ScheduleCycle: ['ManageTalentInsight'],
                UpdateCycle: ['ManageTalentInsight'],
                GetCycles: ['ManageTalentInsight'],
                GetCycle: ['ManageTalentInsight'],
                DeleteCycle: ['ManageTalentInsight'],
                LockCycle: ['ManageTalentInsight'],
                UnLockCycle: ['ManageTalentInsight']
            }
        }
    };
module.exports = Services;
