/*jslint node:true es5:true*/
var MobileAuthentication = function (correlationId) {
    'use strict';
    var ProcessorCache = require('../framework/ProcessorCache.js'),
        RequestManager = require('../framework/RequestManager.js'),
        HgLog = require('../framework/HgLog.js'),
        HGActivityLog = require('../framework/HGActivityLog.js'),
        AuthorizationLevel = require('../enums/AuthorizationLevel.js'),
        TokenHelper = require('../helpers/tokenHelper.js'),
        Services = require('./Services.js'),
        EventData = require('../common/EventData.js'),
        authorizeCompleteCallback = function (error, eventData) {
            var req;
            if (error || !eventData || !eventData.payload) {
                return RequestManager.respondToEvent(new EventData(correlationId, null, error || "server.hge.ath.usp"));
            }
            req = RequestManager.GetRequest(eventData.correlationId);
            RequestManager.SetUserInfo(eventData.correlationId, eventData.payload);
            eventData.servicecallback({
                correlationId: eventData.correlationId,
                req: req,
                host: req.headers['X-Forwarded-For'] || req.hostname,
                currentuser: eventData.payload
            });
        };

    this.Authenticate = function (request, serviceName, methodName, servicecallback, correlationId) {
        var UserProcessorNoAuth = new ProcessorCache.UserNoAuth(correlationId),
            serviceAuthLevel = Services[serviceName].AuthorizeLevel,
            fingerPrint = 'f',
            bparam = {
                correlationId: correlationId,
                UserToken: TokenHelper.GetMobileToken(request, 'UserToken'),
                ActAsUserToken: TokenHelper.GetMobileToken(request, 'ActAsUserToken'),
                ServiceName: serviceName,
                MethodName: methodName,
                IPAddress: HGActivityLog.GetIPAddress(request),
                servicecallback: servicecallback,
                BrowserFingerPrint : request.headers[fingerPrint] || '',
                Source: 'Mobile'
            },
            serviceParameters = {
                correlationId: correlationId,
                req: request,
                host: request.headers['X-Forwarded-For'] || request.hostname,
                IPAddress: HGActivityLog.GetIPAddress(request),
                currentuser: null
            };
        if (serviceAuthLevel === AuthorizationLevel.Anonymous) {
            HGActivityLog.SaveActivity({
                CorrelationId : correlationId,
                ServiceName : serviceName,
                MethodName : methodName,
                IPAddress : HGActivityLog.GetIPAddress(request),
                AccessGranted : false,
                Message : 'Anonymous Mobile Service Calls'
            });
            servicecallback(serviceParameters);
        } else if (serviceAuthLevel === AuthorizationLevel.User) {
            if (!bparam.UserToken && !bparam.ActAsUserToken) {
                HGActivityLog.SaveActivity({
                    CorrelationId : correlationId,
                    ServiceName : serviceName,
                    MethodName : methodName,
                    IPAddress : HGActivityLog.GetIPAddress(request),
                    AccessGranted : false,
                    Message : 'mobile user is not logged in'
                });
                RequestManager.error(correlationId, 'The user is not logged in. Failed authentication.');
            } else {
                UserProcessorNoAuth.Authorize(bparam, authorizeCompleteCallback);
            }
        } else if (serviceAuthLevel === AuthorizationLevel.ClientIP) {
            HGActivityLog.SaveActivity({
                CorrelationId : correlationId,
                ServiceName : serviceName,
                MethodName : methodName,
                IPAddress : HGActivityLog.GetIPAddress(request),
                AccessGranted : false,
                Message : 'Display Service Access from Mobile'
            });
            if (bparam.UserToken || bparam.ActAsUserToken) {
                UserProcessorNoAuth.Authorize(bparam, authorizeCompleteCallback);
            } else {
                RequestManager.error(correlationId, 'The user is not logged in. Failed authentication.');
            }
        } else {
            HGActivityLog.SaveActivity({
                CorrelationId : correlationId,
                ServiceName : serviceName,
                MethodName : methodName,
                IPAddress : HGActivityLog.GetIPAddress(request),
                AccessGranted : false,
                Message : 'Unknown mobile service authorization level type: ' + serviceAuthLevel
            });
            HgLog.error('Unknown service authorization level type: ' + serviceAuthLevel + ' for service: ' + serviceName + '. Expected: ClientAuth or UserAuth.');
            RequestManager.error(correlationId, 'Error loading service authorization level.');
        }
    };
};

module.exports = MobileAuthentication;