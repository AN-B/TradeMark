/*jslint node:true es5:true*/
'use strict';
var Enums = require('../enums/EntityEnums.js'),
    MemberEnums = require('../enums/MemberEnums.js'),
    Props = function () {
        return {
            Role: {type: String, default: ''},
            Description: {type: String, default: ''},
            MemberPermissions: [{
            }],
        };
    };

module.exports = new Props();