/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    NotificationSubscriptionSchema = new HGSchema({
        MemberId: {type : String, default: ''},
        UserId: {type : String, default: ''},
        GroupId: {type : String, default: ''},
        CategoryName : {type : String, default: ''},
        EventName : {type : String, default: ''},
        DeliveryMethod: {type : String, default: ''}
    });

exports.NotificationSubscription = ConnectionCache.hgcommon.model('NotificationSubscription', NotificationSubscriptionSchema, 'NotificationSubscription');