/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    IntegrationEnums = require('../enums/IntegrationEnums.js'),
    MemberSchema = new HGSchema({
        UserId: {type: String},
        FirstName: {type: String},
        LastName: {type: String},
        FullName: {type: String},
        SearchName: {type: String},
        SearchField: {type: Array},
        GroupId: {type: String},
        GroupName: {type: String},
        RolesInGroup: [{type: String, enum: Object.keys(Enums.MembersRoleInGroup), default: Enums.MembersRoleInGroup.Employee}],
        AddedPermissions: [{type: String}],
        RemovedPermissions: [{type: String}],
        Position: {type: String},
        Birthdate: {type: Number, default: Date.now},
        StartingDate: {type: Number, default: Date.now},
        EndingDate: {type: Number},
        LastLoginTime: {type : Number, default : 0},
        LastDailyRecapSentDate: {type: Number, default: 0},
        MembershipStatus: {type: String, enum: Object.keys(Enums.MembershipStatus), default: Enums.MembershipStatus.Active},
        MyManagers: [{
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            '_id': false
        }],
        Preference: {
            WeekendDailyRecap: {type: Boolean, default: false},
            RecapType: {type: String, enum: ['Daily', 'Weekly'], default : 'Daily'},
            OptOutPublicRec: {type: Boolean, default: false}
        },
        Location: {
            hgId: {type: String},
            Name: {type: String}
        },
        ApprovedOrDeniedBy: {type : String},
        InvitedBy: {type: String},
        GroupDepartmentName: {type: String},
        GroupDepartmentCode: {type: String},
        GroupDepartmentId: {type: String},
        EmployeeId: {type: String},
        GravatarEmail: {type: String},
        OffBoardType: {type: String, enum: Object.keys(Enums.OffBoardType)},
        LastRole: {type: String},
        Integration: [{
            Application: {type: String, enum: Object.keys(IntegrationEnums.Applications)},
            UserEmail: {type: String},
            UserId: {type: String},
            '_id': false
        }],
        JobCode: {type: String},
        JobLevel: {type: String},
        UnionCode: {type: String},
        CostCenter: {type: String},
        BenefitStatus: {type: String},
        MileagePlus: {type: String},
        MailCD: {type: String},
        HomeCountry: {type: String}
    }),
    GroupCustomMemberFieldSchema = new HGSchema({
        GroupId: {type: String},
        GroupName: {type: String},
        JobCode: {type: Boolean},
        JobLevel: {type: Boolean},
        UnionCode: {type: Boolean},
        BenefitStatus: {type: Boolean},
        MileagePlus: {type: Boolean},
        MailCD: {type: Boolean},
        HomeCountry: {type: Boolean},
        CostCenter: {type: Boolean}
    });

MemberSchema.virtual('AbbrvName').get(function () {
    var shortName = '';
    if (this.LastName && this.FirstName) {
        shortName = this.FirstName + ' ' + this.LastName.substring(0, 1) + '.';
    } else if (!this.LastName) {
        shortName = this.FirstName;
    } else if (!this.FirstName) {
        shortName = this.LastName;
    }
    return shortName;
});

MemberSchema.set('toJSON', { virtuals: true });

exports.Member = ConnectionCache.hgcommon.model('Member', MemberSchema, 'Member');
exports.GroupCustomMemberField = ConnectionCache.hgcommon.model('GroupCustomMemberField', GroupCustomMemberFieldSchema, 'GroupCustomMemberField');