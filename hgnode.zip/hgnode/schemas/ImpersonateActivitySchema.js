/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    ImpersonateActivitySchema = new HGSchema({
        ActAsUserToken : {type : String},
        ImpersonatorUserId : {type : String},
        ImpersonatorUserName : {type : String},
        ImpersonatorFullName : {type : String},
        ImpersonateeUserId : {type : String},
        ImpersonateeMemberId : {type : String},
        ImpersonateeFullName : {type : String},
        ImpersonateeGroupId : {type : String},
        ImpersonateeGroupName : {type : String},
        StartTime : {type : Number},
        EndTime : {type : Number}
    });
exports.ImpersonateActivity = ConnectionCache.hglog.model('ImpersonateActivity', ImpersonateActivitySchema, 'ImpersonateActivity');