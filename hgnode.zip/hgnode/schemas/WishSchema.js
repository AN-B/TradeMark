/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    WishSchema = new HGSchema({
        MemberId: {type: String},
        GroupId: {type: String},
        Type: {type: String, enum: Object.keys(Enums.WishListItemType), default: Enums.WishListItemType.ProductItem},
        Item: {
            Id: {type: String},
            Name: {type: String}
        },
        Status: {type: String, enum: Object.keys(Enums.WishListItemStatus), default: Enums.WishListItemStatus.Active},
        FulfillmentMemberId: {type: String}
    });


exports.Wish = ConnectionCache.hgperka.model('Wish', WishSchema, 'Wish');