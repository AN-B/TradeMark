/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    RecognitionEnums = require('../enums/RecognitionEnums'),
    OptOutEnums = require('../enums/OptOutEnums'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    OptOutSchema = new HGSchema({
        MemberIds: {
            type: Array,
            default: []
        },
        EntityId: {
            type: String,
            default: ''
        },
        EntityType: {
            type: String,
            enum: [RecognitionEnums.Type.Recognition],
            default: RecognitionEnums.Type.Recognition
        },
        PropertyName: {
            type: String,
            enum: [OptOutEnums.PropertyType.BatchId],
            default: OptOutEnums.PropertyType.BatchId
        }
    });
exports.OptOut = ConnectionCache.hgcommon.model('OptOut', OptOutSchema, 'OptOut');