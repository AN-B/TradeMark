/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EntityEnums = require('../enums/EntityEnums.js'),
    NewsSchema = new HGSchema({
        Title: {type: String},
        Body: {type: String},
        Status: {type: String, enum: Object.keys(EntityEnums.NewsStatus), default: EntityEnums.NewsStatus.Tentative},
        GroupId: {type: String}
    });

exports.News = ConnectionCache.hgcommon.model('News', NewsSchema, 'News');
