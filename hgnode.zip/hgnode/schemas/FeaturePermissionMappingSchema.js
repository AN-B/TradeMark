/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Props = require('./FeatureMappingProps.js'),
    FeaturePermissionMappingSchema = new HGSchema(Props);
FeaturePermissionMappingSchema.index({
    Feature : 1
}, {name : 'CoreFeatureIndex' });
exports.FeaturePermissionMapping = ConnectionCache.hgcommon.model('FeaturePermissionMapping', FeaturePermissionMappingSchema, 'FeaturePermissionMapping');
