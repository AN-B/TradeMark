/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Props = require('./RecognitionTemplateProps.js'),
    HGSchema = require('../common/HGSchema.js'),
    RecognitionTemplateSchema = new HGSchema(Props),
    RecognitionTemplateEmbedded = new Schema(Props, {_id : false});

exports.RecognitionTemplate = ConnectionCache.hgthanka.model('RecognitionTemplate', RecognitionTemplateSchema, 'RecognitionTemplate');
exports.RecognitionTemplateEmbedded  = mongoose.model('RecognitionTemplateEmbedded', RecognitionTemplateEmbedded);
