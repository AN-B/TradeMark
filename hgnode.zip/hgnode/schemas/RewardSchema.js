/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    RewardItem = require('./RewardItemSchema.js'),
    Member = require('./MemberSchema.js'),
    RewardSchema = new HGSchema({
        RewardItem : {type : RewardItem, default : new RewardItem.RewardItem()},
        RequestMember : {type : Member, default: new Member.Member()},
        //following 5 date/time may not may not be applicable, depending on the case
        FirstDate: {type : Number, default: Date.now},
        SecondDate: {type : Number, default: Date.now},
        FirstTime : {type : String, default: ''},
        SecondTime : {type : String, default: ''},
        FulfilledDate: {type : Number, default: Date.now},
        FriendlyId : {type : Number, default: -1},
        Status: {type : String, enum: Object.keys(Enums.RewardStatus), default: ''},
        CancelReason : {type : String, default: ''},
        ReferenceNumbers : [{
            Name: {type : String, default: ''},
            Value : {type : String, default: ''}
        }]
    });

exports.Reward = ConnectionCache.hgperka.model('Reward', RewardSchema, 'Reward');
