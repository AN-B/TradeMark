/*jslint node:true es5:true*/
'use strict';

/*!
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),

/**
 * Schema Notes
 *
 * To reduce the foot print of these collections in the database
 * The property names have been shortened. Here is the Mapping for
 * the fields used
 * p -> Period : Daily (UTC date does not include time)
 * g -> group id
 * t -> total count
 */
    MetricsCoachingSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    }),
    MetricsCoachingCategorySchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, //category : (PlainNotes, TrackLinkedNotes, PrivatePlainNotes, PrivateTrackLinkedNotes)
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    }),
    MetricsFeedBackSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, // given vs requested
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    });
exports.MetricsFeedBack = ConnectionCache.hgreports.model('MetricsFeedBack', MetricsFeedBackSchema, 'MetricsFeedBack');
exports.MetricsCoaching = ConnectionCache.hgreports.model('MetricsCoaching', MetricsCoachingSchema, 'MetricsCoaching');
exports.MetricsCoachingCategory = ConnectionCache.hgreports.model('MetricsCoachingCategory', MetricsCoachingCategorySchema, 'MetricsCoachingCategory');


