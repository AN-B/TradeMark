/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    TutorialSchema = new HGSchema({
        FullCategory : {type : String},
        PrimaryCategory : {type : String},
        SecondaryCategory : {type : String},
        Feature : {type : String},
        TutorialNumber : {type : Number},
        Step : {type : Number},
        RouteURL : {type : String},
        EventName : {type : String},
        TemplateURL : {type : String},
        ExitURL : {type : String},
        TargetSelector : {type : String},
        Permissions : {type : String},
        Template : {type : String},
        Status: {type : String, enum : ['Active', 'Inactive'], default: 'Active'},
    });

exports.Tutorial = ConnectionCache.hgcommon.model('Tutorial', TutorialSchema, 'Tutorial');