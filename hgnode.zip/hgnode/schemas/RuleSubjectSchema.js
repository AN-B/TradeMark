/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    RuleEnums = require('../enums/RuleEnums.js'),
    Rule = require('./RuleSchema.js').Rule,
    RuleSubjectSchema = new HGSchema({
        Rule : {
            type : Schema.Types.Mixed,
            default : new Rule()
        },
        //following 3 are for Member type subject
        MemberId : {type: String},
        UserId : {type: String},
        MemberFullname : {type: String},
        //following are for Team type subject
        TeamId : {type: String},
        TeamName : {type: String},
        //following are for Group type subject
        // GroupId : {type: String},//not sure if this is need because group Id is in Rule object
        //not sure what should the value be for System subject

        //following are only for "ByRanking" to keep track of participants' values. For now this isn't exposed in UI or rule.
        ParticipantType : {type: String, enum : ['Member', 'Team', 'Group']},
        Participants : [{
            MemberId : {type: String},
            UserId : {type: String},
            MemberFullname : {type: String},
            TeamId : {type: String},
            TeamName : {type: String},
            GroupId : {type: String},
            GroupName : {type: String},
            CurrentValue : {type : Number, default : 0}
        }],

        Status : {type : String, enum : ['Active', 'Archived'], default : 'Active'},
        CurrentValue : {type : Number, default : 0},
        TriggerHistory : [{
            Time : {type : Number},
            Value : {type : Number},
            ConditionId : {type : String},//the hgId field of the TriggerCondition,
            '_id' : false
        }],
        ResetHistory : [{
            Time : {type : Number},
            Value : {type : Number},
            '_id' : false
        }],
        LastResetDate : {type : Number}
    });

exports.RuleSubject = ConnectionCache.hgcommon.model('RuleSubject', RuleSubjectSchema, 'RuleSubject');