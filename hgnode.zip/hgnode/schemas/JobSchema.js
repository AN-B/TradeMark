/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    JobSchema = new HGSchema({
        JobName : {type : String},
        ServiceName : {type : String, default : 'Worker'},
        MethodName : {type : String},
        PeriodType : {type : String, enum : ['Hourly', 'Daily', 'Weekly', 'Monthly', 'Quarterly']},
        Hour : {type : Number},//if it's daily/weekly/Monthly/Quarterly, what time does it run. 24 hour
        Day : {type : Number},//if weekly, this means Monday ~ Sunday, if Monthly, it means 1 ~ 31
        Status : {type: String, enum : ['Active', 'Archived'], default : 'Active'},
        LatestTriggerDate : {type : Number, default : 0}
    });

exports.Job = ConnectionCache.hgcommon.model('Job', JobSchema, 'Job');
