/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    PointSnapshotSchema = new HGSchema({
        SpendTotal: {type : Number, default: 0},
        TransferTotal : {type : Number, default: 0},
        ItemCostTotal : {type : Number, default: 0},
        GroupId : {type : String, default: ''},
        GroupName : {type : String, default: ''}
    });

exports.PointSnapshot = ConnectionCache.hgfinance.model('PointSnapshot', PointSnapshotSchema, 'PointSnapshot');
