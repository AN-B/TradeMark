/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    GoalEnums = require('../enums/GoalEnums.js'),
    enumUtil = require('../enums/EnumsBase.js'),
    RecurrenceEnums = require('../enums/RecurrenceEnums.js'),

    KeyResultSchema = new HGSchema({
        Name: {type: String},
        Description: {type: String},
        Measure: {type: String, enum: Object.keys(GoalEnums.KeyResultMeasureType), default: GoalEnums.KeyResultMeasureType.Binary},
        Target: {type: Number},//if measure is percentage, this will be defaulted to 100
        Progress: {type: Number, default: 0},
        DueDate: {type: Number},
        Weight: {type: Number},//if goal's KeyResultWeightType is custom, this weight must be populated
        NumericType: {type: String, enum: Object.keys(GoalEnums.KeyResultNumericType)},
        Prefix: {type: String},
        Suffix: {type: String},
        '_id': false
    }),

    GoalCollaboratorSchema = new HGSchema({
        GroupId: {type: String},
        GoalId: {type: String},
        MemberId: {type: String},
        UserId: {type: String},
        FullName: {type: String}
    }),
    GoalCollaborator = ConnectionCache.hgthanka.model('GoalCollaborator', GoalCollaboratorSchema, 'GoalCollaborator'),

    GoalSchema = new HGSchema({
        CycleId: {type: String},
        CycleTitle: {type: String},
        Description: {type: String},
        GroupId: {type: String},
        Name: {type: String},
        Status: {type: String, enum: Object.keys(GoalEnums.GoalStatus), default: GoalEnums.GoalStatus.Editing},
        IsPublic: {type: Boolean, default: true},
        IsTemplate: {type: Boolean},
        TemplateId: {type: String},
        LastCheckInDate: {type: Number},//last time the user check-in or update
        ClosePromptDate: {type: Number},//ad-hoc goals only. Date when the system should start to prompt user to close the goals
        CloseDueDate: {type: Number},//ad-hoc goals only
        CheckInFrequency: {type: String, enum: enumUtil.ReturnValues(RecurrenceEnums.RecurrencePeriod)},
        UpToDate: {type: Boolean, default: true},
        KeyResultWeightType: {type: String, enum: Object.keys(GoalEnums.WeightType), default: GoalEnums.WeightType.Equal},
        Weight: {type: Number},//goals' weight for this cycle participant
        LastWeight: {type: Number},//goals' weight for this cycle participant
        AlignedGoal: {
            GoalId: {type: String},
            Name: {type: String},
            ParticipantType: {type: String}
        },
        Participant: {//if this is a member goal, it will be the same as Owner, but if it's Team, Company, then it would be different
            ParticipantType: {type: String, enum: Object.keys(GoalEnums.ParticipantType)},
            ParticipantId: {type: String},//TeamId, or group.hgId, or Member.hgId,
            AvatarId: {type: String},//UserId, or TeamId, or group.hgId
            Name: {type: String}//member fullname, or team name, or group program name,
        },
        Owner: {
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Title: {type: String}
        },
        Approver: {
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String}
        },
        Collaborators: [{
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            '_id': false
        }],
        ApprovalFlags: {
            Set: {type: Boolean, default: true},//set goal, which means the goal is finalized
            Update: {type: Boolean, default: false},
            Closure: {type: Boolean, default: true}
        },
        PercentCompletion: {type: Number, default: 0},//this value is always based on Key results
        KeyResults: [KeyResultSchema],
        ProgressStatus: {type: String, enum: Object.keys(GoalEnums.ProgressStatus)},
        SkipSetApprove: {type: Boolean},
        SkipCloseApprove: {type: Boolean},
        History: [{
            Time: {type: Number},
            Note: {type: String},//note entered by the petitioner or approver
            Activity: {type: String, enum: Object.keys(GoalEnums.ActivityType)},
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            ArchiveId: {type: String},//this references to Petition.hgId
            '_id': false
        }]
    }),
    Goal = ConnectionCache.hgthanka.model('Goal', GoalSchema, 'Goal'),

    GoalCycleParticipantSchema = new HGSchema({
        CycleId: {type: String},
        GroupId: {type: String},
        TemplateIds: [{type: String}],//templates that have been assigned to this participant
        GoalWeighting: {type: Boolean},//this is in sync with cycle's GoalWeighting field
        WeightingStatus: {type: String, enum: Object.keys(GoalEnums.WeightingStatus)},//application when above GoalWeighting is true
        GoalWeightType: {type: String, enum: Object.keys(GoalEnums.WeightType), default: GoalEnums.WeightType.Equal},
        ParticipantType: {type: String, enum: Object.keys(GoalEnums.ParticipantType)},
        ParticipantId: {type: String},//The Participant's entity id, e.g., TeamId, or group.hgId, or Member.hgId
        Status: {type: String, enum: Object.keys(GoalEnums.ParticipantStatus), default: GoalEnums.ParticipantStatus.PendingDelivery},
        AvatarId: {type: String},//UserId, or TeamId, or group.hgId
        Name: {type: String},//member fullname, or team name, or group program name,
        DeliveryDate: {type: Number},//Deliver cycle will look at this field now, instead of DeliveryMethods.DeliveryDate
        SetDueDate: {type: Number},//populated at delivery if by trigger
        SetDueInDays: {type: Number},//how many days you need to set the goal
        ClosePromptDate: {type: Number},//date when the system should start to prompt user to close the goals
        CloseDueDate: {type: Number},
        GoalNumber: {type: Number, default: 0},
        Owner: {//the actual person
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Title: {type: String},
            DeptId: {type: String},
            DeptName: {type: String},
            LocId: {type: String},
            LocName: {type: String}
        }
    }),
    GoalCycleParticipant = ConnectionCache.hgthanka.model('GoalCycleParticipant', GoalCycleParticipantSchema, 'GoalCycleParticipant'),

    GoalCycleSchema = new HGSchema({
        RoundId: {type: String},//this is for recurrence.
        Title: {type: String},
        Description: {type: String},
        Note: {type: String},
        Status: {type: String, enum: Object.keys(GoalEnums.CycleStatus), default: GoalEnums.CycleStatus.Building},
        GroupId: {type: String},
        GroupName: {type: String},
        GoalWeighting: {type: Boolean},
        Notes: {type: String},
        TemplateIds: [{type: String}],//templates that have been assigned to this cycle
        RecurrenceFrequency: {type: String, enum: enumUtil.ReturnValues(RecurrenceEnums.RecurrencePeriod)},
        ClosePromptDate: {type: Number},//date when the system should start to prompt user to close the goals
        ClosePeriod: {type: Number},//how many days participants have to close the goals after ClosePromptDate
        LockedForDelivery: {type: Boolean, default: false},
        SerialId: {type: String},//this is for recurrence. Each time a new object of cycle object will be created, but all of them will have the same SerialId
        DeliveryMethods: [{//this is equivalent to "PeopleDates" in perform cycle. For now it's one enty per ParticipantType, but i think it will be per "OrgLevel" eventually
            ParticipantType: {type: String, enum: Object.keys(GoalEnums.ParticipantType)},
            // OrgLevel: {type: String},//commented out for now, might be needed when we support multi-layers in org. ###DO NOT REMOVE THIS LINE!!!###
            CheckInFrequency: {type: String, enum: enumUtil.ReturnValues(RecurrenceEnums.RecurrencePeriod)},
            DeliveryDate: {type: Number},
            SetDueDate: {type: Number},//deadline when the goals have to be set
            SetDueInDays: {type: Number},//how many days you need to set the goal
            DeliveryTrigger: {type: String, enum: Object.keys(GoalEnums.DeliveryTriggerType), default: GoalEnums.DeliveryTriggerType.ByDate},
            TrgParticipantType: {type: String},//if this people type finalizes the goal, the cycle will be delivered to me
            ApprovalFlags: {
                Set: {type: Boolean, default: true},//set goal, which means the goal is finalized
                Update: {type: Boolean, default: false},
                Closure: {type: Boolean, default: true}
            },
            SkipSetApprove: {type: Boolean},//applicable only to Member level now, but may be needed for company/dept if later approve is applied
            SkipCloseApprove: {type: Boolean},//applicable only to Member level now, but may be needed for company/dept if later approve is applied
            '_id': false
        }],
        CompanyGoalOwner: {
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Title: {type: String}
        },
        CycleSnapshot: {
            TotalParticipantNum: {type: Number},
            TotalParticipantNumWithGoals: {type: Number},//Total count of users with >0 goals
            PreInProgressParticipantNumWithGoals: {type: Number},//Count of users with >0 goals that are in the pending creation or pending approval state
            TotalGoalNumber: {type: Number},
            EditingGoalNumber: {type: Number},
            SubmittedForSetGoalNumber: {type: Number},
            InProgressGoalNumber: {type: Number},
            PendingClosureGoalNumber: {type: Number},
            SubmittedForClosureGoalNumber: {type: Number},
            ClosedGoalNumber: {type: Number},
            OntimeGoalNumber: {type: Number},//# of goals that are updated on time
            AvgGoalCompletePercentage: {type: Number, default: 0}
        },
        CycleOwner: {//added for recurrence notifcation & transfer, but this should have more usage
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String}
        }
    }),
    GoalCycle = ConnectionCache.hgthanka.model('GoalCycle', GoalCycleSchema, 'GoalCycle');

exports.GoalCollaborator = GoalCollaborator;
exports.Goal = Goal;
exports.GoalCycle = GoalCycle;
exports.GoalCycleParticipant = GoalCycleParticipant;
