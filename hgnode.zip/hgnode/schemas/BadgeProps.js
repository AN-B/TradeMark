/*jslint node:true es5:true*/
'use strict';

var EntityEnum = require('../enums/EntityEnums.js'),
    Props = function () {
        return {
            hgId: {type : String, default : ''},
            BadgeName: { type : String, default: '' },
            Filename: { type : String, default: '' },
            Tags: { type : String, default: '' },
            Category: { type : String, default: '' },
            Archive: { type : Boolean, default: false },
            GroupId : { type : String, default: ''},
            Federated : { type : Boolean, default: false },
            SpecialUsages : [{type : String, enum : Object.keys(EntityEnum.SpecialUsages)}]
        };
    };

module.exports = new Props();