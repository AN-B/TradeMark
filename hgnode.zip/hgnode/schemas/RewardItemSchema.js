/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    RewardItemSchema = new HGSchema({
        Title: {type : String, default: ''},
        Description : {type : String, default: ''},
        XPCost : {type : Number, default: 0},
        Limit : {type : Number, default: -1}, // -1 mean there's no limit
        Period: {type : String, enum: Object.keys(Enums.RewardItemPeriod), default: ''},
        AccessLevel: {type : String, enum : ['WithinTeam', 'WithinGroup'], default: 'WithinGroup'},
        ExpireDate: {type : Number, default: Date.now},
        FriendlyGroupId: {type : Number, default: -1},
        GroupId : {type : String, default: ''},
        GroupName : {type : String, default: ''},
        TeamId : {type : String, default: ''},
        TeamName : {type : String, default: ''}
    });

exports.RewardItem = ConnectionCache.hgperka.model('RewardItem', RewardItemSchema, 'RewardItem');
