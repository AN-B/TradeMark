/*jslint node:true es5:true*/
'use strict';
var Enums = require('../enums/EntityEnums.js'),
    DemoEnums = require('../enums/DemoEnums.js'),
    MemberEnums = require('../enums/MemberEnums.js'),
    PolicyEnums = require('../enums/PolicyEnums.js'),
    TranslationEnums = require('../enums/TranslationEnums.js'),
    Address = require('./AddressSchema.js'),
    Props = function () {
        return {
            hgId: {type: String, default: ''},
            GroupName: {type: String, default: ''},
            PublicDisplayName: {type: String, default: ''},
            Slug: {type: String},
            Federated: {type: Boolean},
            SFTPFolderName: {type: String},
            ProgramName: {type: String, default: ''},
            HGAccountId: {type: String, default: ''},
            BannerColor: {type: String, default: ''},
            BannerMotif: {type: String, default: 'Dark'},
            BannerUrl: {type: String, default: ''},
            FriendlyGroupId: {type: Number, default: -1},
            IsPrivateGroup: {type: Boolean, default: false},
            CorporateEmailDomain: {type: Boolean, default: false},
            MainAddress: {type: Address, default: new Address.Address()},
            BillingAddress: {type: Address, default: new Address.Address()},
            MainPhone: {type: String, default: ''},
            MainFax: {type: String, default: ''},
            BillingRep: {type: String, default: ''},
            BillingPhone: {type: String, default: ''},
            BillingEmail: {type: String, default: ''},
            CreditSetting: {
                MinTransfer: {type: Number, default: 10},
                MaxTransfer: {type: Number, default: 1000},
                DefaultTransferAmount: {type: Number, default: 10},
                MinRecognition: {type: Number, default: 10},
                MaxRecognition: {type: Number, default: 50},
                MinSpendAmount: {type: Number, default: 120},
                MaxSpendAmount: {type: Number}
            },
            TeamTabSetting: {
                Anniversary: {type: Number, default: 10},
                Birthday: {type: Number, default: 10},
                RecognitionReceived: {type: Number, default: 10},
                RecognitionGiven: {type: Number, default: 10}
            },
            SystemRecognitionTemplates: {
                AnniversaryTemplateId: {type: String}
            },
            BadgeDefaults: [{ // this field is deprecated and moved to recognition template
                Type: {type: String, default: ''},
                ForegroundBadgeId: {type: String, default: ''},
                ForegroundFilename: {type: String, default: ''},
                BackgroundBadgeId: {type: String, default: ''},
                BackgroundFilename: {type: String, default: ''},
                Title: {type: String, default: ''},
                Message: {type: String, default: ''},
                Id: {type: String, default: ''}
            }],
            PointSetting: {
                MinPoints: {type: Number, default: 10},
                MaxPoints: {type: Number, default: 10000},
                AutoReplenishPoints: {type: Boolean, default: true},
                ReplenishPoints: {type: Number, default: 5000}
            },
            PubRepMemberId: {type: String},//PR rep. For now, this member will receive notification when low rating public recogntiion is received
            CreditMasterMemberId: {type: String, default: ''},
            PointMasterMemberId: {type: String, default: ''},
            BillMeAllowed: {type: Boolean, default: false},
            TermsOfUse: {
                Accepted: {type: Boolean, default: false},
                AcceptMemberId: {type: String},
                AcceptMemberName: {type: String},
                AcceptDate: {type: Number}
            },
            CreditLimit: {type: Number, default: 0},//in credits
            RatePerPerson: {type: Number, default: 0},
            StartBillingDate: {type: Number, default: Date.now},
            TotalFloatCredit: {type: Number, default: 0},
            Preference: {
                DefaultLanguage: {type: String, default: TranslationEnums.AvailableLanguages.English.key},
                SupportedLanguages: [{type: String, default: TranslationEnums.AvailableLanguages.English.key}],
                CommentEditInterval: {type: Number, default: 0},
                DailyRecapEnabled: {type: Boolean, default: false},
                WeeklyRecapEnabled: {type: Boolean, default: true},
                BirthdayEmailEnabled: {type: Boolean, default: false},
                AnniversaryEmailEnabled: {type: Boolean, default: false},
                EmployeeGoalRecapEnabled: {type: Boolean, default: false},
                SuppressWelcomeBadge: {type: Boolean, default: false},
                WeeklyRecapDay: {
                    type: String,
                    enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                    default: 'Monday'
                },
                WeeklyRecapTime: {type: Number},//this is a time stamp, specifying what hour/minute the recap email should go out, so only hour and minute matters
                DailyRecapTime: {type: Number},//this is a time stamp, specifying what hour/minute the recap email should go out, so only hour and minute matters
                FeatureFlags: [{
                    FeatureName: {type: String, default: ''},
                    FeatureMeta: [{
                        Name: {type: String, default: ''},
                        Value: {type: String, default: ''},
                        '_id': false
                    }],
                    FeatureEnabled: {type: Boolean, default: false},
                    '_id': false
                }],
                TimeZone: {type: String, default: 'CDT'},
                ReferenceNumberTypes: [{
                    EntityName: {type: String},//for now there's only transaction
                    Name: {type: String},
                    Resolver: {type: String}//the method name (within ReferenceNumberProcessor) to resolve this reference number's value
                }]
            },
            PubRec: {
                Short: {type: String, default: ''},
                Medium: {type: String, default: ''},
                Long: {type: String, default: ''}
            },
            TimeZone: {type: String, default: 'America/Chicago'},
            ValueLevelSetting: {
                Enabled: {type: Boolean, default: false},
                Levels: [{
                    Name: {type: String},
                    PointValue: {type: Number, default: 0},
                    CreditValue: {type: Number, default: 0},
                    LimitPeriod: {type: String, enum: ['Day', 'Week', 'Month', 'Quarter', 'Year', 'NoLimit']},
                    AvailabilityToRoles: [{
                        RoleName: {
                            type: String,
                            enum: Object.keys(MemberEnums.MemberRole)
                        },
                        Allowed: {type: Boolean, default: true},
                        LimitNumber: {type: Number, default: 0}
                    }],
                    ImageId: {type: String},
                    RemainingToMe: {type: Number, default: 0},//This is a DTO field to be populated when returned
                    LimitNumber: {type: Number, default: 0}
                }]
            },
            Status : {type: String, enum : Object.keys(Enums.GroupStatus), default : Enums.GroupStatus.Active},
            RulesEngineEventTypes : [String],
            SSO: {
                Yammer: {
                    access_token: {type: String, default: ''},
                    created_at: {type: Number, default: ''},
                    expires: {type: Number, default: 0},
                    network_name: {type: String, default: ''},
                    verified_admin: {type: Boolean, default: false},
                    user_email: {type: String, default: ''},
                    user_hgId: {type: String, default: ''},
                    user_name: {type: String, default: ''},
                    notifyGroups: [{type: String, default: ''}]
                },
                OneLogin: {
                    uploaded_at: {type: Number, default: Date.now},
                    cert: {type: String, default: ''}
                },
                SAML: {
                    uploaded_at: {type: Number, default: ''},
                    type: {type: String, default: ''},
                    cert: {type: String, default: ''},
                    issuer: {type: String, default: ''},
                    entryPoint: {type: String, default: ''}
                }
            },
            DemoType: {type: String, enum: Object.keys(DemoEnums.Type)},
            PasswordPolicy: {
                MinChar: {
                    Value: {type: Number, default: 8},
                    RegEx: {type: String, default: PolicyEnums.MinChar(8)}
                },
                MinAlpha: {
                    Value: {type: Number, default: 1},
                    RegEx: {type: String, default: PolicyEnums.MinAlpha(1)}
                },
                MinNum: {
                    Value: {type: Number, default: 1},
                    RegEx: {type: String, default: PolicyEnums.MinNum(1)}
                },
                MinUpper: {
                    Value: {type: Number, default: 1},
                    RegEx: {type: String, default: PolicyEnums.MinUpper(1)}
                },
                MinSpec: {
                    Value: {type: Number, default: 0},
                    RegEx: {type: String, default: PolicyEnums.MinSpec(0)}
                },
                Expiration: {type: Number, default: 0},
                ExpDate: {type: Number, default: 0},
                RegEx: {
                    type: String,
                    default: PolicyEnums.MinAlpha(1) + PolicyEnums.MinNum(1) + PolicyEnums.MinUpper(1) + PolicyEnums.MinSpec(0) + PolicyEnums.MinChar(8)
                }
            },
            KioskSurveyInProgress: {type: Boolean} // this is flag is used by kiosk survey feature. When it is true only admins are allowed to login
        };
    };

module.exports = new Props();