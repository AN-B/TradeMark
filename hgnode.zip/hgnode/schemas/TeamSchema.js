/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    Address = require('./AddressSchema.js'),
    TeamSchema = new HGSchema({
        Name: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        Description: {type: String, default: ''},
        IsPublic: {type: Boolean, default: false},
        OwnerId: {type: String, default: ''},//Member Id of whoever created the team
        OwnerFullName: {type: String, default: ''},
        Status: {type: String, enum: ['Deleted', 'Active', ''], default: 'Active'},
        Type: {type: String, enum: Object.keys(Enums.TeamType), default: 'Pod'},//pod is ad-hoc teams that are created by any user. Department can be created by provision and admin only
        ChildTeams: [{
            TeamId: {type: String, default : ''},
            TeamName: {type: String, default : ''},
            '_id' : false
        }],
        TeamMembers: [{
            MemberId: {type: String, default: ''},
            MemberFullName: {type : String, default: ''},
            TeamId: {type: String, default: ''},
            '_id': false
        }],
        GoalOwner: {
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Title: {type: String}
        },
        Address: {type: Address},
        Phone: {type: String},
        LocationCode: {type: String},
        DepartmentCode: {type: String},
        i18n: {type: String}, //Currently used for Location language
        tz: {type: String} // used for locaiton timezone
    });
exports.Team = ConnectionCache.hgcommon.model('Team', TeamSchema, 'Team');