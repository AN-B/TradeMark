/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    Template = require('./TemplateSchema.js').Template,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    SurveyEnums = require('../enums/SurveyEnums.js'),
    RecurrenceEnums = require('../enums/RecurrenceEnums.js'),
    enumUtil = require('../enums/EnumsBase.js'),
    QuestionAnswerSchema = new Schema({
        QuestionId: {type: String},
        QuestionText: {type: String},
        DriverId: {type: String},
        DriverName: {type: String},
        AnswerType: {type: String, enum : Object.keys(SurveyEnums.AnswerTypes), default: SurveyEnums.AnswerTypes.RatingScale},
        ScaledAnswerValue: {type: Number},
        AnswerValue: {type: Number},
        AnswerText: {type: String},
        AnswerSelectors: [{
            Text : {type : String},
            Value : {type : Number},
            Order: {type: Number},
            _id: false
        }],
        AnsweredDate: {type: Date},
        MinLabelAnswer: {type: String},
        MaxLabelAnswer: {type: String},
        Status: {type: String, enum: Object.keys(SurveyEnums.QuestionStatus), default: SurveyEnums.QuestionStatus.Pending},
        Lock: {type: Boolean, default: false}, // used by pulse to indicate questions that cannot be changed by group admins
        Comment: {type: String}, // used by benchmark and pulse for text questions
        Order: {type: Number}
    }, {_id: false}),
    SurveySchema = new HGSchema({
        GroupId: {type: String},
        Template: {type: Schema.Types.Mixed, default: new Template()},
        StartDate: {type: Number},
        PeriodType: {type: String, enum: enumUtil.ReturnValues(RecurrenceEnums.RecurrencePeriod), default: RecurrenceEnums.RecurrencePeriod.SemiAnnual},
        Frequency: {type: Number},
        DaysToLive: {type: Number, default: 7},
        Points: {type: Number, default: 0},
        Reminder: {type: Boolean},
        Status: {type: String, enum: Object.keys(SurveyEnums.Status), default: SurveyEnums.Status.Active},
        Participant: {type: Number},
        Completed: {type: Number},
        InProgress: {type: Number},
        NextScheduleDisabled: {type: Boolean},
        CurrentQuestionId: {type: String}, // used in pulse
        MultipleQuestionSupport: {type: Boolean, default: false}, // used in pulse temporarily
        KioskEnable: {type: Boolean, default: false}
    }),
    SurveyAnswerSchema = new HGSchema({
        SurveyId:  {type: String},
        Type: {type: String, enum: Object.keys(SurveyEnums.Type), default: SurveyEnums.Type.Benchmark},
        RecurrenceId: {type: String},
        CurrentRoundId: {type: String},
        GroupId: {type: String},
        MemberId: {type: String},
        UserId: {type: String},
        FullName: {type: String},
        DepartmentId: {type: String},
        DepartmentName: {type: String},
        LocationId: {type: String},
        LocationName: {type: String},
        Role: {type: String},
        Tenure: {type: String},
        Status: {type: String, enum: Object.keys(SurveyEnums.SurveyAnswerStatus), default: SurveyEnums.SurveyAnswerStatus.Pending},
        StartDate: {type: Date},
        CompletedDate: {type: Date},
        ExpireDate: {type: Number},
        LastViewedIndex: {type: Number},
        RemindSent: {type: Boolean, default: false},
        QandA: [QuestionAnswerSchema],
        AccessCode: {type: String}
    }),
    SurveyResultSchema = new HGSchema({
        SurveyId: {type: String},
        Type: {type: String, enum: Object.keys(SurveyEnums.Type), default: SurveyEnums.Type.Benchmark},
        RecurrenceId: {type: String},
        CurrentRoundId: {type: String},
        GroupId: {type: String},
        Status: {type: String, enum: Object.keys(SurveyEnums.SurveyResultStatus), default: SurveyEnums.SurveyResultStatus.InProgress},
        Completed: {type: Number},
        PreviousResultId: {type: String},
        TotalDeliveredSurvey: {type: Number},
        PDFGenerated: {type: Boolean},
        Summary: {type: Object}, //used by pulse survey
        Question: {type: String} //used by pulse
    });
SurveySchema.set('toJSON', { virtuals: true });
SurveyAnswerSchema.set('toJSON', { virtuals: true });
exports.Survey = ConnectionCache.hgperform.model('Survey', SurveySchema, 'Survey');
exports.SurveyAnswer = ConnectionCache.hgperform.model('SurveyAnswer', SurveyAnswerSchema, 'SurveyAnswer');
exports.SurveyResult = ConnectionCache.hgperform.model('SurveyResult', SurveyResultSchema, 'SurveyResult');

