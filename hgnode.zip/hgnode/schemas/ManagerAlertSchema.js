/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    ManagerAlertSchema = new HGSchema({
        GroupId: {type : String},
        ManagerMemberId : {type : String},
        ReportMemberId : {type : String},
        Category: {type: String, enum : Object.keys(Enums.ManagerAlertCategory)},
        AlertType: {type: String, enum : Object.keys(Enums.ManagerAlertType)},
        Severity: {type: String, enum : Object.keys(Enums.ManagerAlertSeverity)},
        Status: {type: String, enum : Object.keys(Enums.ManagerAlertStatus)},
        Data: {type: Object }
    });
ManagerAlertSchema.index({
    GroupId : 1,
    ManagerMemberId : 1,
    ReportMemberId : 1,
    Status : 1,
    AlertType : 1
});
exports.ManagerAlert = ConnectionCache.hgcommon.model('ManagerAlert', ManagerAlertSchema, 'ManagerAlert');