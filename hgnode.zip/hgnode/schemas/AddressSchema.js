/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    AddressSchema = new Schema({
        Address1: {type : String},
        Address2: {type : String},
        City: {type : String},
        State: {type : String},
        Zip: {type : String},
        Country: {type : String},
        _id: false
    });

exports.Address = mongoose.model('Address', AddressSchema);