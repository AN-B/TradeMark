/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Rule = require('./RuleSchema.js').Rule,
    MemberRuleSchema = new HGSchema({
        Rule : {
            type : Schema.Types.Mixed,
            default : new Rule()
        },
        MemberId : {type: String},
        UserId : {type: String},
        MemberFullname : {type: String},
        Status : {type : String, enum : ['Active', 'Archived'], default : 'Active'},
        CurrentValue : {type : Number, default : 0},
        TriggerHistory : [{
            Time : {type : Number},
            Value : {type : Number},
            ConditionId : {type : String},//the hgId field of the TriggerCondition,
            '_id' : false
        }],
        ResetHistory : [{
            Time : {type : Number},
            Value : {type : Number},
            '_id' : false
        }],
        LastResetDate : {type : Number}
    });

exports.MemberRule = ConnectionCache.hgcommon.model('MemberRule', MemberRuleSchema, 'MemberRule');
