/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    event = require('../enums/NotificationsEnums.js'),
    NotificationSchema = new HGSchema({
        Type: { type : String, enum: ['General', 'Events', 'OverdueAlerts', 'Transactions']},
        ActionUrl: {type: String, default: ''},
        Event: {type: event.Event},
        EntityId: {type: String, default: ''},
        RecipientId: {type: String, default: ''},
        RecipientUserId: {type: String},
        RecipientGroupId: {type: String, default: ''},
        IssuerId: {type: String, default: ''},
        IssuerFillName: {type: String, default: ''},
        Title: {type: String, default: ''},
        Notes: {type: String, default: ''},
        DateAdded: {type : Number, default: Date.now},
        Viewed: {type : Boolean, default: false},
        Deleted: {type : Boolean, default: false},
        Date : {type : Date, default: Date.now},
        Important: {type : Boolean},
        IsMultiManager: {type: Boolean},
        IsReviewee: {type: Boolean}
    });

module.exports.Notification = ConnectionCache.hgcommon.model('Notification', NotificationSchema, 'Notification');