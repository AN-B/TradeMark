/*jslint node:true es5:true*/
'use strict';

var TemplateEmbedded = require('./RecognitionTemplateSchema.js'),
    Enums = require('../enums/EntityEnums.js'),
    Props = function () {
        return {
            RecognitionTemplate: {type: TemplateEmbedded, default: new TemplateEmbedded.RecognitionTemplateEmbedded()},
            RecognitionId: { type : String, default: '' },
            Status: { type : String, enum: Object.keys(Enums.MilestoneStatus), default: Enums.MilestoneStatus.NotStarted },
            TargetDate: { type: Number, default: 0 },
            ClosedDate: { type: Number, default: 0 },
            LastReasonCode: { type : String, enum: Object.keys(Enums.LastReasonCode), default: Enums.LastReasonCode.None },
            DisplayName: { type : String, default: '' },
            Collaborators : [{
                MemberId : {type : String, default: '' },
                FullName: {type : String, default: '' },
                AccessLevel : {type : String, enum: Object.keys(Enums.CollaboratorsAccessLevel), default: Enums.CollaboratorsAccessLevel.Observer }
            }],
            ObjectiveChain : [{
                TrackId : {type : String, default: '' },
                MileStoneId : {type : String, default: '' },
                Title : {type : String, default: '' }
            }],
            PerformanceCards : [{ type : String, default: '' }],
            ExternalTriggers : [{
                EventTriggerGuid : {type : String, default: '' },
                StatusChange : {type : Number, default: 0 }
            }],
            PercentAchieved : {type : Number, default: 0},
            RequiresApproval: { type : Boolean, default: false },
            Weight: {type: Number},
            MilestoneTarget: {type: Number},
            NumericValue: {type: Number}
        };
    };

module.exports = new Props();