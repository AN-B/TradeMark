/*jslint node:true es5:true*/
'use strict';

var Enums = require('../enums/EntityEnums.js'),
    mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    Props = function () {
        return {
            hgId: {type: String, default: ''},
            Comment: {type: String},
            IsPublic: {type: Boolean, default: false},
            IncludePerformance: {type: Boolean, default: false},
            Status: {type: String, enum: Object.keys(Enums.CommentStatus), default: Enums.CommentStatus.Active},//Draft means "for my eyes only"
            EntityId: {type: String},
            EntityType: {type: String, enum: Object.keys(Enums.CommentEntityType), default: Enums.CommentEntityType.Recognition},
            CommenterFirstName: {type: String, default: ''},
            CommenterLastName: {type: String, default: ''},
            CommenterUserhgId: {type: String, default: ''},
            MemberId: {type: String, default: ''},//whoever made the comment
            ReadBy: {type: Array},
            Recipients: {type: Array},//this should be removed -- gw
            ReasonCode: {type: Object},
            GroupId: {type: String, default: ''},
            Type: {type: String, enum : Object.keys(Enums.CommentType), default: Enums.CommentType.Comment},
            HasAttachment: {type: Boolean, default: false},
            Attachments: {
                OrderId: {type: String, default: ''},
                Url: {type: String, default: ''},
                ImgSrc: {type: String, default: ''},
                Title: {type: String, default: ''},
                Description: {type: String, default: ''}
            },
            //following are for coaching and feedback
            Recipient: {
                MemberId: {type: String},
                UserId: {type: String},
                FullName: {type: String}
            },
            TrackId: {type: String},
            MilestoneId: {type: String},
            MilestoneTemplateId: {type: String},
            MilestoneFriendlyGroupId: {type: Number, default: -1},
            LikedMembers: [{
                MemberId: {type: String},
                UserId: { type: String},
                FullName: { type: String}
            }],
            LikedCount: {type: Number, default: 0},
            MeLiked: {type: Boolean},
            Header: {type: String},
            SubHeader: {type: String},
            Source: {type: String, default: 'Web'},// Web or Mobile Device
            TaggedUser: {type: Schema.Types.ObjectId, ref: 'TaggedUser'}
        };
    };

module.exports = new Props();
