/*jslint node:true es5:true*/
'use strict';
/*
    Implementation Notes

    Option A

    Translations Collection is the primary collection for data texts that need to be
    translated by the client. The collection has an implicity reference other collections
    via the EntityId field and Type
    Lang : en, fr, pr, ...
    GroupId: company groupd id
    EntityId: RecognitionTemplateId, BenchmarkTemplateSurveyId,
    EntityType: Template, Survey...
    Values: Array of key value pair

    Pros:
        1)
            Scalibility options here when this collection grows very large of any particular type
            new collections for the type can be created and the data can be moved

        2)  Zero change to Source Collections

    Cons:
        1) Extra call to get translated texts. (can be minimized by indexed queries)

    Option B

    This option is to use the .populate feature in mongoose to pull the translated text with find method
    from the primary collections.
    example:
        Template: {
            TranslatedValues: [{ type: Schema.Types.ObjectId, Ref: 'Translations'}],
        }
    In this approach the TranslatedValues array will have an array of the Translations._id

    This means data is added to the Translations Collection first before the data is saved in the
    source collections. This approach is the opposite approach to option A where the source Id needs to
    exist before data is written to the Translations collections.

    Pros:

        1) Translated method with the find. Simpler processor call

    Cons:
        1) Source Collections require a new field
        2) Document size growth in source collections.


    My first implementation using Option B was not working so I am going with option A for now and will cycle
    back with time permitting.
*/
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    TranslationEnums = require('../enums/TranslationEnums.js'),
    TranslationsSchema = new HGSchema({
        Lang: {type: String},
        GroupId: {type: String},
        EntityType: {type: String},
        EntityId: {type: String},
        Values: {},
        Status: {type: String, enum: Object.keys(TranslationEnums.Status), default: TranslationEnums.Status.Active},
    });
exports.Translations = ConnectionCache.hgcommon.model('Translations', TranslationsSchema, 'Translations');