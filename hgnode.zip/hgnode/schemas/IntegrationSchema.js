/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    IntegrationSchema = new HGSchema({
        GroupId : {type: String},
        GroupName : {type: String},
        SalesForceIds : [{type: String}],
        BasecampIds : [{type: String}],
        GitHubIds : [{type: String}]
    });

exports.Integration = ConnectionCache.hgsecurity.model('Integration', IntegrationSchema, 'Integration');
