/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    RecurrenceEnums = require('../enums/RecurrenceEnums.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    enumUtil = require('../enums/EnumsBase.js'),
    RecurrenceSchema = new HGSchema({
        RecurrenceType: {type: String, enum: Object.keys(RecurrenceEnums.RecurrenceTypes), required: true},
        EntityType: {type: String, enum: Object.keys(RecurrenceEnums.EntityType)},
        EntityId: {type: String, required: true},
        EntityInfo: {type: Array},
        PeriodType: {type: String, enum: enumUtil.ReturnValues(RecurrenceEnums.RecurrencePeriod), required: true},
        NumPeriod: {type: Number, default: 1},
        Status: {type: String, enum: Object.keys(RecurrenceEnums.Status), default: RecurrenceEnums.Status.Active},
        FirstTriggerDate: {type: Number},
        LatestTriggerDate: {type: Number},
        NextTriggerDate: {type : Number},
        CurrentRoundId: {type : String},
        ServiceName: {type: String},
        MethodName: {type: String},
        GroupId: {type: String},
        History: [{
            RecDate: {type: Number},//when this happened
            RoundId: {type: String},
            Status: {type: String, enum: ['Failed', 'Successful']},
            EntityId: {type: String}
        }]
    });

exports.Recurrence = ConnectionCache.hgcommon.model('Recurrence', RecurrenceSchema, 'Recurrence');