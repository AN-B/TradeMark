/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    BatchEnums = require('../enums/BatchEnums.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    BatchSchema = new HGSchema({
        EntityType: {type: String, enum: Object.keys(BatchEnums.EntityType)},
        EntityId: {type: String},
        BatchType: {type: String, enum: Object.keys(BatchEnums.BatchTypes)},
        Status: {type: String, enum: Object.keys(BatchEnums.Status), default: BatchEnums.Status.New},
        GroupId: {type: String},
        TotalNumber: {type: Number},
        ProcessedNumber: {type: Number, default: 0},
        History: [{
            Time: {type: Number},
            NumRecords: {type: Number},
            Error: {},
            '_id': false
        }]
    });
exports.Batch = ConnectionCache.hgcommon.model('Batch', BatchSchema, 'Batch');