/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    HGSchema = require('../common/HGSchema.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Props = require('./MilestoneProps.js'),
    MilestoneEmbeddedSchema = new HGSchema(Props);

exports.MileStoneEmbedded  = mongoose.model('MileStoneEmbedded', MilestoneEmbeddedSchema);
exports.MilestoneEmbeddedSchema = MilestoneEmbeddedSchema;