/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    ThrottleSchema = new HGSchema({//note this is not meant to be the service call log because it's constantly deleted
        correlationId : {type : String},
        ServiceName: {type : String},
        MethodName: {type : String},
        RequestTime : {type : Number}
    });
exports.Throttle = ConnectionCache.hgsecurity.model('Throttle', ThrottleSchema, 'Throttle');