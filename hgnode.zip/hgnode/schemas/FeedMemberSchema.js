/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Enums = require('../enums/EntityEnums.js'),
    FeedMemberSchema = new mongoose.Schema({
        hgId: {type: String}, // MemberId
        UserId: {type: String},
        FirstName: {type: String},
        LastName: {type: String},
        FullName: {type: String},
        GroupId: {type: String},
        GroupName: {type: String},
        Position: {type: String},
        EmployeeId: {type: String},
        MyManagers: [{
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String}
        }],
        LastRole: {type: String},
        MembershipStatus: {type: String, enum: Object.keys(Enums.MembershipStatus), default: Enums.MembershipStatus.Active},
        RolesInGroup: [{type: String, enum: Object.keys(Enums.MembersRoleInGroup), default: Enums.MembersRoleInGroup.Employee}],
        GroupDepartmentName: {type: String},
        GroupDepartmentId: {type: String},
        Location: {
            hgId: {type: String},
            Name: {type: String}
        }
    });

FeedMemberSchema.set('toJSON', { virtuals: true });

exports.FeedMember = mongoose.model('FeedMember', FeedMemberSchema);
