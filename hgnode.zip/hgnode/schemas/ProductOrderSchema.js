/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    ProductItem = require('./ProductItemSchema.js'),
    ProductOrderSchema = new HGSchema({
        ProductItem : {type : ProductItem, default : new ProductItem.ProductItem()},
        Quantity : {type : Number, default : 0},
        Requester : {
            MemberId : {type : String},
            UserId : {type : String},
            FullName : {type : String}
        },
        Recipient : {
            MemberId : {type : String},
            UserId : {type : String},
            FullName : {type : String}
        },
        FriendlyId : {type : Number, default: -1},
        Status: {type : String, enum: Object.keys(Enums.ProductOrderStatus)},
        AccountType : {type : String},
        FulfilledDate: {type : Number},
        FulfillNote : {type : String},
        CancelNote : {type : String}
    });

exports.ProductOrder = ConnectionCache.hgperka.model('ProductOrder', ProductOrderSchema, 'ProductOrder');
