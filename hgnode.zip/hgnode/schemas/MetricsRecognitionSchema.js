/*jslint node:true es5:true*/
'use strict';

/*!
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),

/**
 * Schema Notes
 *
 * To reduce the foot print of these collections in the database
 * The property names have been shortened. Here is the Mapping for
 * the fields used
 * p -> Period : Daily (UTC date does not include time)
 * g -> group id
 * h -> hourly stats 0 through 23
 * t -> total count
 * c -> category defers by schema see not by schema
 */
    MetricsRecognitionSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        // h : {type: Object, default: new HourProp()},
        h : {
            0 : {type : Number, default: 0},
            1 : {type : Number, default: 0},
            2 : {type : Number, default: 0},
            3 : {type : Number, default: 0},
            4 : {type : Number, default: 0},
            5 : {type : Number, default: 0},
            6 : {type : Number, default: 0},
            7 : {type : Number, default: 0},
            8 : {type : Number, default: 0},
            9 : {type : Number, default: 0},
            10 : {type : Number, default: 0},
            11 : {type : Number, default: 0},
            12 : {type : Number, default: 0},
            13 : {type : Number, default: 0},
            14 : {type : Number, default: 0},
            15 : {type : Number, default: 0},
            16 : {type : Number, default: 0},
            17 : {type : Number, default: 0},
            18 : {type : Number, default: 0},
            19 : {type : Number, default: 0},
            20 : {type : Number, default: 0},
            21 : {type : Number, default: 0},
            22 : {type : Number, default: 0},
            23 : {type : Number, default: 0}
        },
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    }),
    MetricsRecognitionCheckInNumberSchema = new Schema({
        p : {type : Number, default: Date.now},
        t : {type : Number, default: 0}
    }),
    MetricsManagerSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        m : {type : String, default: ''},
        a : {type : String, default: ''}, // r = recognition, c = coaching, p=perform, g = goals/tracks
        c : {type : String, default: ''}, // r , g
        r : {type : Boolean, default: ''}, // true , false
        t : {type : Number, default: 0}
    }),
    MetricsRecognitionCategorySchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, //category : (everyday, value, achievement, system)
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    }),
    MetricsRecognitionSourceSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, //category  : public vs internal
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    }),
    MetricsRecognitionShareSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, //category  : LinkedIn, Facebook etc
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    });
exports.MetricsRecognition = ConnectionCache.hgreports.model('MetricsRecognition', MetricsRecognitionSchema, 'MetricsRecognition');
exports.MetricsManager = ConnectionCache.hgreports.model('MetricsManager', MetricsManagerSchema, 'MetricsManager');
exports.MetricsRecognitionCheckInNumber = ConnectionCache.hgreports.model('MetricsRecognitionCheckInNumber', MetricsRecognitionCheckInNumberSchema, 'MetricsRecognitionCheckInNumber');
exports.MetricsRecognitionCategory = ConnectionCache.hgreports.model('MetricsRecognitionCategory', MetricsRecognitionCategorySchema, 'MetricsRecognitionCategory');
exports.MetricsRecognitionSource = ConnectionCache.hgreports.model('MetricsRecognitionSource', MetricsRecognitionSourceSchema, 'MetricsRecognitionSource');
exports.MetricsRecognitionShare = ConnectionCache.hgreports.model('MetricsRecognitionShare', MetricsRecognitionShareSchema, 'MetricsRecognitionShare');



