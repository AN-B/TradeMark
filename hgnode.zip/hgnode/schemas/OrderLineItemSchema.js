/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EventEmitterCache = require('../framework/EventEmitterCache.js'),
    OrderLineItemStatusEnum = {
        Filfilled : 'Filfilled',
        BackOrdered : 'BackOrdered',
        Cancelled : 'Cancelled'
    },
    OrderLineItemSchema = new HGSchema({
        IssuerId: {type : String, default: ''},
        Type : {type : String, default: ''},
        Category : {type : String, default: ''},
        Status : {type : String, enum: [OrderLineItemStatusEnum.Filfilled, OrderLineItemStatusEnum.BackOrdered, OrderLineItemStatusEnum.Cancelled], default: OrderLineItemStatusEnum.Filfilled},
        Denomination : {type : Number, default : 0},
        CardId : {type : String, default: ''},
        CardType: {type : String, default: ''},
        TangoSKU: {type : String, default: ''},
        RedeemerId: {type : String, default: ''},//userid of whoever redeemed it
        RecipientId: {type : String, default: ''},//userid of whoever purchased it. Should be defaulted to the redeemer id now
        RequestId : {type : String, default: ''} // GiftOrderRequest hgId
    });

exports.OrderLineItemStatusEnum = OrderLineItemStatusEnum;
exports.OrderLineItem = ConnectionCache.hgperka.model('OrderLineItem', OrderLineItemSchema, 'OrderLineItem');