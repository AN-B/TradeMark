/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EventData = require('../common/EventData.js'),
    EventEmitterCache = require('../framework/EventEmitterCache.js'),
    EntityEnum = require('../enums/EntityEnums.js'),
    GroupTrackActivityReportSchema = new HGSchema({
        GroupName: {type : String, default: ''},
        GroupId : {type : String, default: ''},
        Month : {type : String, default: ''},
        Date : {type : Number, default : Date.now},
        TimeRange : {type : String, default: ''},
        Status: { type : String, enum: Object.keys(EntityEnum.TrackStatus), default: ''},
        Count: {type : Number, default: 0}
    }),
    MemberActivityReportSchema = new HGSchema({
        MemberId: {type : String, default: ''},
        MemberFullName: {type : String, default: ''},
        GroupId: {type : String, default: ''},
        GroupName: {type : String, default: ''},
        TimeRange : {type : String, default: ''},
        Date : {type : Number, default : Date.now},
        Month : {type : String, default: ''},
        NumRecognitionGiven: {type : Number, default: 0},
        NumRecognitionReceived: {type : Number, default: 0},
        NumComments: {type : Number, default: 0},
        NumCongratsGiven: {type : Number, default: 0},
        NumTracksCreated: {type : Number, default: 0}
    }),
    GroupRecognitionActivityReportSchema = new HGSchema({
        GroupId: {type : String, default: ''},
        GroupName: {type : String, default: ''},
        Recognition: {type : String, default: ''},
        RecognitionCategory: {type : String, default: ''},
        Month : {type : String, default: ''},
        Date : {type : Number, default : Date.now},
        TimeRange : {type : String, default: ''},
        Count : {type : Number, default: 0},
        RecognitionStatus : {type : String, default: ''}
    }),
    CongratActivityReportSchema = new HGSchema({
        GroupId: {type : String, default: ''},
        GroupName: {type : String, default: ''},
        Month : {type : String, default: ''},
        Date : {type : Number, default : Date.now},
        TimeRange : {type : String, default: ''},
        Count : {type : Number, default: 0}
    }),
    CommentActivityReportSchema = new HGSchema({
        GroupId: {type : String, default: ''},
        Month : {type : String, default: ''},
        Date : {type : Number, default : Date.now},
        TimeRange : {type : String, default: ''},
        Count : {type : Number, default: 0},
        CommentType : {type : String, default: ''},
        IsPublic: { type: Boolean, default: false }
        //Status : {type : String, default: ''} remove add back when the field is added
    }),
    ReportRequestSchema = new HGSchema({
        Group: {type : String, default: ''},
        StartDate : {type : String, default: ''},
        EndDate : {type : String, default: ''},
        ResponseType : {type : String, default: 'json'},
        Report : {type: Number, default : 0},
        DateRange : {type : String, default: 'Custom'}
    }),
    GroupUserSystemActivityReportSchema = new HGSchema({
        GroupId: {type : String, default: ''},
        GroupName: {type : String, default: ''},
        Month : {type : String, default: ''},
        Date : {type : Number, default : Date.now},
        TimeRange : {type : String, default: ''},
        NumberofUsers : {type : Number, default: 0},
        Type : {type : String, enum : ['IntraDay', 'Daily', 'Monthly'], default : 'IntraDay' }
    });
exports.GroupTrackActivityReport = ConnectionCache.hgreports.model('GroupTrackActivityReport', GroupTrackActivityReportSchema, 'GroupTrackActivityReport');
exports.MemberActivityReport = ConnectionCache.hgreports.model('MemberActivityReport', MemberActivityReportSchema, 'MemberActivityReport');
exports.GroupRecognitionActivityReport = ConnectionCache.hgreports.model('GroupRecognitionActivityReport', GroupRecognitionActivityReportSchema, 'GroupRecognitionActivityReport');
exports.CommentActivityReport = ConnectionCache.hgreports.model('CommentActivityReport', CommentActivityReportSchema, 'CommentActivityReport');
exports.ReportRequestTemplate = ConnectionCache.hgreports.model('ReportRequestTemplate', ReportRequestSchema, 'ReportRequestTemplate');
exports.CongratActivityReport = ConnectionCache.hgreports.model('CongratActivityReport', CongratActivityReportSchema, 'CongratActivityReport');
exports.GroupUserSystemActivityReport = ConnectionCache.hgreports.model('GroupUserSystemActivityReport', GroupUserSystemActivityReportSchema, 'GroupUserSystemActivityReport');