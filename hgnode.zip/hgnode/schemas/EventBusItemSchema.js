/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EventBusEnums = require('../enums/EventBusEnums.js'),
    EventBusItemSchema = new HGSchema({
        EventType: {type: String, enum: Object.keys(EventBusEnums.EventTypes)},
        Status: {type: String, enum: Object.keys(EventBusEnums.ItemStatus), default: EventBusEnums.ItemStatus.New},
        TurkId: {type: String},//the EventTurk process that has locked this item. I don't use the BatchId here, because it's reserved for the process that generated the item
        Payload: {},
        GroupId: {type: String},
        ClientId: {type: String},
        ClientName: {type: String},
        EntityId: {type: String},
        EntityType: {type: String, enum: Object.keys(EventBusEnums.EntityType)}
    }),

    SubscriberAuditSchema = new HGSchema({
        EventId: {type: String},
        ServiceName: {type: String},
        MethodName: {type: String},
        Status: {type: String, enum: Object.keys(EventBusEnums.SubscriberStatus)},
        Message: {type: String},
        Action: {type: String, enum: Object.keys(EventBusEnums.Action)},
        ActionPending: {type: Boolean, default: true}
    }),
    EventBusItemInit = function (groupId) {
        return ConnectionCache.getSchema({
            GroupId: groupId,
            ColName: 'EventBusItem',
            DbName: 'hgcommon',
            Schema: EventBusItemSchema
        });
    };

exports.EventBusItem = EventBusItemInit;
exports.EventBusItemArchive = ConnectionCache.hglog.model('EventBusItemArchive', EventBusItemSchema, 'EventBusItemArchive');
exports.SubscriberAudit = ConnectionCache.hglog.model('SubscriberAudit', SubscriberAuditSchema, 'SubscriberAudit');

