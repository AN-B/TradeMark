'use strict';
var HGSchema = require('../common/HGSchema'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache'),
    GroupTerminologySchema = new HGSchema({
        GroupId: {type: String},
        Languages: [{
            i18n: {type: String},
            Definitions: {type: Object},
            _id: false
        }]
    });

exports.GroupTerminology = ConnectionCache.hgcommon.model('GroupTerminology', GroupTerminologySchema, 'GroupTerminology');
