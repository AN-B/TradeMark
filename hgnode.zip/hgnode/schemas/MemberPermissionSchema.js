/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Props = require('./MemberPermissionProps.js'),
    MemberPermissionSchema = new HGSchema(Props);
MemberPermissionSchema.index({
    Permission : 1
}, {name : 'CorePermissionIndex' });
exports.MemberPermission = ConnectionCache.hgcommon.model('MemberPermission', MemberPermissionSchema, 'MemberPermission');
