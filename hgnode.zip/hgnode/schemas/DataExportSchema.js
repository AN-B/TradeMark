/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    DataExportSchema = new HGSchema({
        GroupName: {type : String, default: ''},
        GroupId: {type : String, default: ''},
        Token: {type : String, default: ''},
        Status: {type : String, enum: Object.keys(Enums.DataExportStatus), default: Enums.DataExportStatus.InProgress},
        EmailDate: {type : Number, default: ''},
        DownloadDate: {type : Number, default: ''}
    });

exports.DataExport = ConnectionCache.hglog.model('DataExport', DataExportSchema, 'DataExport');
