/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    TransactionType = require('../enums/TransactionType.js'),
    TransactionStatus = require('../enums/TransactionStatus.js'),
    Enums = require('../enums/EntityEnums.js'),
    TransactionSchema = new HGSchema({
        AccountId: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        UserId: {type: String, default: ''},
        FirstName: {type: String, default: ''},
        LastName: {type: String, default: ''},
        UserName: {type: String, default: ''},
        UnitType: {type: String, enum : Object.keys(Enums.TransactionUnitType), default: Enums.TransactionUnitType.Credit},
        Type: {type: String, default: '', enum: Object.keys(TransactionType)},
        Status: {type: String, default: '', enum: [TransactionStatus.Pending, TransactionStatus.Complete, TransactionStatus.Failed, TransactionStatus.PendingAvailable] },
        Info: {type: String, default: ''},
        CreditQuantity: {type: Number, default: 0 },//this field is NOT just for "Credit", it's for "Point" as well, depending on the UnitType
        RowVersion: {type: Number, default: 1},
        ReferenceId: {type: String, default: ''},
        FriendlyId: {type: Number, default: 0},
        ReferenceNumbers : [{
            TypeName : {type : String},
            Value : {type : String}
        }]
    });

exports.Transaction = ConnectionCache.hgfinance.model('Transaction', TransactionSchema, 'Transaction');