/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EnvironmentSchema = new HGSchema({
        Name: {type : String},
        api: {type : String},
        s3: {type : String},
        Enabled : {type : Boolean, default : true},
        pkey: {type : String},
        PermissionRequired : [{type : String, enum : ['SwitchEnvironmentQA', 'SwitchEnvironmentSales', 'SwitchEnvironmentHG', 'None'], default : 'None'}]//OR
    });

exports.Environment = ConnectionCache.hgcommon.model('Environment', EnvironmentSchema, 'Environment');