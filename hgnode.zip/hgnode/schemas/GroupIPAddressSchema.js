/*jslint node:true es5:true*/
'use strict';
var DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    HGSchema = require('../common/HGSchema.js'),
    GroupIPAddressSchema = new HGSchema({
        GroupId: {type: String},
        IPRange: [{
            '_id' : false,
            Start : {type : String},
            End : {type : String}
        }]
    });

exports.GroupIPAddress = ConnectionCache.hgsecurity.model('GroupIPAddress', GroupIPAddressSchema, 'GroupIPAddress');
