/*jslint node:true es5:true*/
'use strict';

/*!
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),

/**
 * Schema Notes
 *
 * To reduce the foot print of these collections in the database
 * The property names have been shortened. Here is the Mapping for
 * the fields used
 * p -> Period : Daily (UTC date does not include time)
 * g -> group id
 * d -> departmentid
 * dn -> department name
 * l -> locationid
 * ln -> locationname
 * t -> total count
 * c -> category defers by schema see not by schema
 */
    MetricsMemberSchema = new Schema({
        p: {type: Date, default: Date.now},
        g: {type: String},
        d: {type: String},
        dn: {type: String},
        l: {type: String},
        ln: {type: String},
        m: {type: String}, // member guid
        c: {type: String}, //category : (RecognitionGiven, RecognitionReceived, TracksCreated, TracksCompleted, coaching, feedback)
        t: {type: Number, default: 0}
    });
exports.MetricsMember = ConnectionCache.hgreports.model('MetricsMember', MetricsMemberSchema, 'MetricsMember');




