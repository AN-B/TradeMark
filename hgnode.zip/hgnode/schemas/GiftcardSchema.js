/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EventData = require('../common/EventData.js'),
    EventEmitterCache = require('../framework/EventEmitterCache.js'),
    GiftcardStatusEnum = {
        Available : 'Available',
        Void : 'Void',
        Reserved : 'Reserved', // set this to be Reserved during check out and then to 'Purchased'
        Purchased : 'Purchased'
    },
    GiftcardOrderRequestSchema = new HGSchema({
        UserId: {type : String, default: ''},
        Status : {type : String, enum: ['Active', 'Expired', 'Fulfilled'], default: 'Active'},
        RequestedDenominations : [{
            IssuerId: {type : String, default: ''},
            Category: {type : String, enum: ['Code', 'Card'], default: 'Code'},
            CardType: {type : String, default: ''},
            Denomination: {type : Number, default: 0},
            CreditCost: {type : Number, default: 0},
            RequestedNumber: {type : Number, default: 0},
            TangoSKU: {type : String, default: ''}
        }]
    }),
    GiftcardSchema = new HGSchema({
        Category : {type : String, enum: ['Code', 'Card'], default: 'Code'},
        Status : {type : String, enum: ['Available', 'Void', 'Reserved', 'Purchased'], default: 'Available'},
        Issuer : {
            IssuerId: {type : String, default: ''},
            IssuerName : {type : String, default: ''}
        },
        ImageFilename : {type : String, default: ''},
        SequenceNumber: {type : Number, default: 0}, //amazon 
        ClaimCode: {type : String, default: ''}, //amazon 
        Denomination: {type : Number, default: 0},
        SerialNumber: {type : String, default: ''}, //amazon 
        Code: {type : String, default: ''}, //groupon
        Pin: {type : String, default: ''}, //groupon
        Company: {type : String, default: ''}, //groupon
        IssueDate: {type : Number, default: Date.now}, //groupon
        RedeemerId: {type : String, default: ''},//userid of whoever redeemed it
        RecipientId: {type : String, default: ''},//userid of whoever purchased it. Should be defaulted to the redeemer id now
        RequestId : {type : String, default: ''}, // GiftOrderRequest hgId
        ReserveDate : {type : Number, default : Date.now}
    });

exports.GiftcardStatusEnum = GiftcardStatusEnum;
exports.Giftcard = ConnectionCache.hgperka.model('Giftcard', GiftcardSchema, 'Giftcard');
exports.GiftcardOrderRequest = ConnectionCache.hgperka.model('GiftcardOrderRequest', GiftcardOrderRequestSchema, 'GiftcardOrderRequest');
exports.GiftcardOrderRequestArchive = ConnectionCache.hgperka.model('GiftcardOrderRequestArchive', GiftcardOrderRequestSchema, 'GiftcardOrderRequestArchive');
