/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    ProductItemSchema = new HGSchema({
        Name: {type : String, default: ''},
        Description : {type : String, default: ''},
        RedeemInstruction : {type : String, default: ''},
        ExpireDate: {type : Number},//if null, no expire date
        PointCost : {type : Number, default: 0},
        Limit : {type : Number, default: -1}, // -1 mean there's no limit
        AvailableNumber : {type : Number, default : 0},
        Accessibility : {
            RestrictByLocation : {type : Boolean, default: false},
            Locations : [{
                hgId: {type: String},
                Name: {type: String},
                '_id' : false
            }],
            RestrictByDept : {type : Boolean, default: false},
            Departments : [{
                hgId: {type: String},
                Name: {type: String},
                '_id' : false
            }]
        },
        FriendlyGroupId: {type : Number, default: -1},
        GroupId : {type : String},
        GroupName : {type : String},
        Status : {type : String, enum: Object.keys(Enums.ProductItemStatus), default: Enums.ProductItemStatus.Active},
        Instruction : {type : String, default: ''},
        ProductImageFile: {type: String, default: ''},
        ProductType :  {type: String, enum: Object.keys(Enums.ProductItemType), default: Enums.ProductItemType.Store},
        CampaignItem : {
            Backers: [
                {
                    MemberId: {type: String},
                    UserId: {type: String},
                    FullName: {type: String},
                    FirstName: {type: String},
                    LastName: {type: String},
                    PledgePoint: {type: Number},
                    '_id' : false
                }
            ],
            FundingGoal: {type: Number, default: 0},
            PledgedPrice: {type: Number, default: 0},
            FundCompletedDate: {type: Number}
        },
        Owner: {
            MemberId : {type : String, default: ''},
            UserId : {type : String, default: ''}
        },
        SuggestedBy: {
            FullName : {type : String, default: ''},
            Email : {type : String, default: ''}
        },
        Tags: [{
            TagId: {type: String},
            TagName: {type: String},
            '_id' : false
        }]
    });

exports.ProductItem = ConnectionCache.hgperka.model('ProductItem', ProductItemSchema, 'ProductItem');
