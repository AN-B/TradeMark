/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EventData = require('../common/EventData.js'),
    EventEmitterCache = require('../framework/EventEmitterCache.js'),
    GlobalSettingsSchema = new HGSchema({
        RequestInfoEmail: {type : String, default: ''}
    }),
    DBHeartBeatSchema = new HGSchema({
        Name: {type : String, default: ''}
    });
DBHeartBeatSchema.index({
    Name : 1
});
exports.DBHeartBeat = ConnectionCache.hgcommon.model('DBHeartBeat', DBHeartBeatSchema, 'DBHeartBeat');
exports.LDBHeartBeat = ConnectionCache.hglog.model('DBHeartBeat', DBHeartBeatSchema, 'DBHeartBeat');
exports.GlobalSettings = ConnectionCache.hgcommon.model('GlobalSettings', GlobalSettingsSchema, 'GlobalSettings');
