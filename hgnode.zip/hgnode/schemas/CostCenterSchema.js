/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    CostCenterSchema = new HGSchema({
        GroupId: {type : String, default: ''},
        GroupName: {type : String, default: ''},
        GLAccount: {type: String, default: ''},
        TeamId: {type: String, default: ''},
        TeamName: {type: String, default: ''}
    });

exports.CostCenter = ConnectionCache.hgfinance.model('CostCenter', CostCenterSchema, 'CostCenter');