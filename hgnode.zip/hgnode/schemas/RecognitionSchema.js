/*jslint node:true es5:true*/
'use strict';

var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    TemplateEmbedded  = require('./RecognitionTemplateSchema.js'),
    RecognitionEnums = require('../enums/RecognitionEnums.js'),
    FeedMember = require('./FeedMemberSchema.js'),
    RecognitionSchema = new HGSchema({
        BadgeFilename: {type: String},
        BatchId: {type: String},
        Template: {type: TemplateEmbedded, default: new TemplateEmbedded.RecognitionTemplateEmbedded()},
        CommentCount: {type: Number, default: 0},
        ShareCount: {type: Number, default: 0},
        Status: {type: String, enum: Object.keys(RecognitionEnums.Status), default: RecognitionEnums.Status.Active},
        NewsId: {type: String},
        PollQuestionId: {type: String},
        PollResult: {type: Object},
        GoalId: {type: String},
        KrUpdates: {type: Object},
        CreatorMember: {type: FeedMember, default: new FeedMember.FeedMember()},
        RecipientMember: {type: FeedMember, default: new FeedMember.FeedMember()},
        RandCId: {type: [String]},
        PublicCreatorInfo: {
            FullName: {type: String},
            CompanyName: {type: String},
            Email: {type: String}
        },
        TriggerInfo: {
            GroupName: {type: String},
            AvatarId: {type: String},
            RuleName: {type: String},
            RuleId: {type: String}
        },
        Message: {type: String},
        MessageEdited: {type: Boolean},
        ModifiedBy: {type: FeedMember},
        ItemId: {type: String},
        CannedMessage: {type: String },
        CompanyRating: {type: Number, default: 0},
        MemberRating: {type: Number, default: 0},
        ActualCreditValue: {type: Number, default: 0},
        ActualPointValue: {type: Number, default: 0 },
        CongratsCount: {type: Number, default: 0},
        MeCongrated: {type: Boolean, default: false},
        SuppressInFeed: {type: Boolean, default: false},
        Gifts: [{
            '_id': false,
            SenderId: {type: String},
            ProductId: {type: String},
            OrderIds: [{type: String}],
            RecipientIds: [{type: String}],
            Type: {type: String, enum: Object.keys(RecognitionEnums.GiftType)}
        }],
        VisibilityMemberIds: {}, //this actually an array of member Ids
        VisibilityLocations: {}, // this actually an array of location {hgId: {type: String},Name: {type: String}}
        CongratMemberIds: {type: Array},
        DismissMemberIds: {type: Array},//this is applicable only when Sticky is true. It is used to record which members have choosen to dismiss it
        MeDismissed: {type: Boolean},
        Shares: [{
            Dest: {type: String, enum: Object.keys(RecognitionEnums.SharesDest)},
            ShareDate: {type: Number, default: Date.now},
            Status: {type: String, enum: Object.keys(RecognitionEnums.SharesStatus)},
            Response: {type: Object}
        }],
        Relevance: {type: Number},//this will be taken out once i introduce another mapping lever, stay tuned
        LevelName: {type: String},//applicable only to value and achiemvent recognitions
        SubValue: {type: String},
        Sticky: {type: Boolean},//this is from admin's point of view
        ExpireDate: {type: Number},//if null, no expire date. only applicable when sticky is true
        Source: {type: String, default: 'Web'}// Web or Mobile Device (the actual device type), or RulesEngine, maybe later API
    }, ['Template']);

exports.Recognition = ConnectionCache.hgthanka.model('Recognition', RecognitionSchema, 'Recognition');
