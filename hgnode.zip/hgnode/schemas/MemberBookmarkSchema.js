/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    MemberBookmarkSchema = new HGSchema({
        MemberId: {type: String},
        GroupId: {type: String},
        PinnedMemberIds: [{type: String}],
        UnpinnedMemberIds: [{type: String}],
        PinnedTeamIds: [{type: String}],
        UnpinnedTeamIds: [{type: String}],
        PinnedLocationIds: [{type: String}],
        UnpinnedLocationIds: [{type: String}],
        FollowedTrackMemberIds: [{type: String}]
    });

MemberBookmarkSchema.set('toJSON', { virtuals: true });

exports.MemberBookmark = ConnectionCache.hgcommon.model('MemberBookmark', MemberBookmarkSchema, 'MemberBookmark');
