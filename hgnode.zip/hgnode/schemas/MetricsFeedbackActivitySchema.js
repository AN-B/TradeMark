/*jslint node:true es5:true*/
'use strict';

/*!
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),

/**
 * Schema Notes
 *
 * To reduce the foot print of these collections in the database
 * The property names have been shortened. Here is the Mapping for
 * the fields used
 * p -> Period : Daily (UTC date does not include time)
 * g -> group id
 * u -> user Id
 * m -> member id
 * c -> cycle id
 * d -> department
 * s -> source (web/mobile)
 * t -> total count
 * ty -> cycle type
 * r -> role
 * l -> location
 * ln -> location name
 * mn - > member name
 * dn - > department name
 * mg - member ManagerId
 * mgn - member Manager Name
 * x -> activity type (requested, completed, declined)
 * t -> total / rating score
 */
    MetricsFeedbackActivitySchema = new Schema({
        p: {type: Date, default: Date.now},
        g: {type: String},
        m: {type: String},
        c: {type: String},
        d: {type: String},
        l: {type: String},
        r: {type: String},
        mn: {type: String},
        dn: {type: String},
        x: {type: String},
        ty: {type: String},
        t: {type: Number, default: 0}
    }),
    MetricsFeedbackRoleModelSchema = new Schema({
        p: {type: Date, default: Date.now},
        g: {type: String},
        m: {type: String},
        c: {type: String},
        ty: {type: String},
        d: {type: String},
        mn: {type: String},
        dn: {type: String},
        l: {type: String},
        r: {type: String},
        t: {type: Number, default: 0}
    }),
    MetricsTalentInsightSchema = new Schema({
        p: {type: Date, default: Date.now},
        g: {type: String},
        m: {type: String},
        u: {type: String},
        c: {type: String},
        d: {type: String},
        mn: {type: String},
        mg: {type: String},
        mgn: {type: String},
        dn: {type: String},
        l: {type: String},
        ln: {type: String},
        r: {type: String},
        Replaceable: {type: Number},
        Performance: {type: Number},
        FlightRisk: {type: Number},
        Promotable: {type: Number},
        KeyToSuccess: {type: Number},
        Potential: {type: Number},
        Capacity: {type: Number},
        Speed: {type: Number},
        Scarcity: {type: Number}
    });
MetricsTalentInsightSchema.set('toJSON', { virtuals: true });
exports.MetricsFeedbackActivity = ConnectionCache.hgreports.model('MetricsFeedbackActivity', MetricsFeedbackActivitySchema, 'MetricsFeedbackActivity');
exports.MetricsFeedbackRoleModel = ConnectionCache.hgreports.model('MetricsFeedbackRoleModel', MetricsFeedbackRoleModelSchema, 'MetricsFeedbackRoleModel');
exports.MetricsTalentInsight = ConnectionCache.hgreports.model('MetricsTalentInsight', MetricsTalentInsightSchema, 'MetricsTalentInsight');



