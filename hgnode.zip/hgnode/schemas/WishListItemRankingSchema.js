/*jslint node:true es5:true*/
'use strict';
var Schema = require('mongoose').Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    WishListRankingSchema = new Schema({
        MemberId: {type: String},
        GroupId: {type: String},
        RankingList: [{
            ItemId: {type: String, default: ''},
            Rank: {type: Number, default: 0},
            _id: false
        }]
    });


exports.WishListRanking = ConnectionCache.hgperka.model('WishListRanking', WishListRankingSchema, 'WishListRanking');