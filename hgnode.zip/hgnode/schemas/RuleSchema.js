/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    RuleEnums = require('../enums/RuleEnums.js'),
    EventBusEnums = require('../enums/EventBusEnums.js'),
    RuleSchema = new HGSchema({
        RuleName : {type: String},
        Description : {type: String},
        SubjectType : {type: String, enum : Object.keys(RuleEnums.RuleSubjectType), default : RuleEnums.RuleSubjectType.Member},
        SubjectIds : [{type : String}],//this is applicable when the Subject type is AdHocMembers, or Team, or Group. Which means this rule only applies to those ids
        DeltaType : {type: String, enum : Object.keys(RuleEnums.DeltaType), default : RuleEnums.DeltaType.CountUp},
        DeltaValue : {type: String, enum : Object.keys(RuleEnums.DeltaValue), default : RuleEnums.DeltaValue.ActualValue},
        ResetInterval : {type: String, enum : Object.keys(RuleEnums.ResetInterval)},
        ResetAfterTrigger : {type: Boolean, default : true},
        AllowedInterval : {type: String, enum : Object.keys(RuleEnums.AllowedInterval)},
        StartDate : {type : Number, default : Date.now},
        Status : {type : String, enum : Object.keys(RuleEnums.Status), default : RuleEnums.Status.Active},
        EventType : {type: String, enum: Object.keys(EventBusEnums.EventTypes)},
        GroupId : {type: String},
        Scope : {
            RestrictByLocation : {type : Boolean, default: false},
            Locations : [{
                hgId: {type: String},
                Name: {type: String},
                '_id' : false
            }],
            RestrictByDept : {type : Boolean, default: false},
            Departments : [{
                hgId: {type: String},
                Name: {type: String},
                '_id' : false
            }]
        },
        FriendlyGroupId: {type : Number, default: -1},
        TriggerTiming : {type : String, enum : Object.keys(RuleEnums.TriggerTimingType), default : RuleEnums.TriggerTimingType.Immediate},
        TriggerConditionType : {type: String, enum : Object.keys(RuleEnums.TriggerConditionType), default : RuleEnums.TriggerConditionType.ByValue},
        TriggerConditions : [{
            hgId : {type : String},
            //following two fields are for "ByValue"
            Min : {type : Number},
            Max : {type : Number},
            //following is for "ByRanking"
            Ranking : {type : Number},
            ActionType : {type: String, enum : Object.keys(RuleEnums.RulesEngineAction), default : RuleEnums.RulesEngineAction.GiveRecognition},
            //following 3 fields are specific to recongition action
            RecognitionTemplateId : {type: String},
            RecognitionTemplate: {},//this should not be persisted. Instead it should be a DTO
            Level : {type: String},
            Gift: {},
            '_id' : false
        }],
        DefaultAction: {
            RecognitionTemplateId: {type: String},
            ActionType: {type: String, enum : Object.keys(RuleEnums.RulesEngineAction), default : RuleEnums.RulesEngineAction.GiveRecognition},
            Level: {type: String}
        }
    });

exports.Rule = ConnectionCache.hgcommon.model('Rule', RuleSchema, 'Rule');