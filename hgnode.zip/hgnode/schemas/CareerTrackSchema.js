/*jslint node:true es5:true*/
'use strict';

var HGSchema = require('../common/HGSchema.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    CareerTrackTemplate = require('./CareerTrackTemplateSchema.js'),
    EntityEnum = require('../enums/EntityEnums.js'),
    Member = require('./MemberSchema.js'),

    CareerTrackSchema = new HGSchema({
        BatchId: {type : String, default : ''},
        Status: { type : String, enum: Object.keys(EntityEnum.TrackStatus), default: EntityEnum.TrackStatus.Assigned },
        CareerTrackTemplate : {type: CareerTrackTemplate, default: new CareerTrackTemplate.CareerTrackTemplate()},
        AssignedMember : {type : Member, default: new Member.Member()},
        CreatorMember : {type : Member, default: new Member.Member()},
        PercentAchieved : {type : Number, default: 0},
        Collaborators : [{
            MemberId : {type : String, default: '' },
            UserId: {type : String, default: ''},
            FullName: {type : String, default: '' },
            AccessLevel : {type : String, enum: Object.keys(EntityEnum.CollaboratorsAccessLevel), default: EntityEnum.CollaboratorsAccessLevel.Writer }
        }],
        NotificationFrequency : {type : String, enum : ['Never', 'Weekly', 'Monthly', 'Quarterly'], default : 'Weekly'},
        //following is DTO field populated on the fly for coaching
        ICanCoach : {type : Boolean},
        Tags: []
    });

CareerTrackSchema.index({ 'AssignedMember.hgId': 1}, {unique: false});
CareerTrackSchema.index({ 'CreatorMember.hgId': 1}, {unique: false});
CareerTrackSchema.index({ 'Collaborators.MemberId': 1}, {unique: false});
CareerTrackSchema.index({ 'CareerTrackTemplate.GroupId' : 1, 'CreatedDate' : 1}, {name : 'CoreDocIndex' });
function calculateEquallyWeightedCompletion(mileStones) {
    var i, len = mileStones.length,
        CompletionSum = 0,
        TotalCounter = 0;
    for (i = 0; i < len; i += 1) {
        if (mileStones[i].Status !== 'Cancelled') {
            TotalCounter += 1;
            CompletionSum += (mileStones[i].PercentAchieved || 0);
        }
    }
    return TotalCounter > 0 ? Math.round(CompletionSum / TotalCounter) : 0;
}
function calculateCustomWeightedCompletion(mileStones) {
    var i, len = mileStones.length,
        CompletionSum = 0;
    for (i = 0; i < len; i += 1) {
        if (mileStones[i].Status !== 'Cancelled' && mileStones[i].Weight) {
            CompletionSum += mileStones[i].PercentAchieved * mileStones[i].Weight / 100;
        }
    }
    return Math.round(CompletionSum);
}
CareerTrackSchema.methods.SetPercentAchieved = function () {
    if (this.CareerTrackTemplate.MileStones && this.CareerTrackTemplate.MileStones.length > 0) {
        if (this.Status !== 'Void') {
            if (this.CareerTrackTemplate.MilestoneWeightType !== 'Custom') {
                this.PercentAchieved = calculateEquallyWeightedCompletion(this.CareerTrackTemplate.MileStones);
            } else {
                this.PercentAchieved = calculateCustomWeightedCompletion(this.CareerTrackTemplate.MileStones);
            }
        }
    }
};

exports.CareerTrack = ConnectionCache.hgthanka.model('CareerTrack', CareerTrackSchema, 'CareerTrack');
