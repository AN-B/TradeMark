/*jslint node:true es5:true*/
'use strict';
var DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    HGSchema = require('../common/HGSchema.js'),
    FeeSchema = new HGSchema({
        Description: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        Type: {type: String, default: 'Misc.', enum: ['Admin', 'Purchase', 'Credit', 'Support', 'Misc.']},
        Amount: {type: Number, default: 0},
        ReferenceId: {type: String, default: ''},
        InvoiceId: {type: String, default: ''},
        Date: {type: Date, default: Date.now}
    });

exports.Fee = ConnectionCache.hgfinance.model('Fee', FeeSchema, 'Fee');
