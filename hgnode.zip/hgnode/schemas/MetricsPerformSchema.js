/*jslint node:true es5:true*/
'use strict';

/*!
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),

/**
 * Schema Notes
 *
 * To reduce the foot print of these collections in the database
 * The property names have been shortened. Here is the Mapping for
 * the fields used
 * p -> Period : Daily (UTC date does not include time)
 * g -> group id
 * t -> total count
 */
    MetricsPerformSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, //category : (submitted, closed)
        s : {type : String, default: ''}, // web and mobile
        t : {type : Number, default: 0}
    }),
    MetricsPerformActivitySchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, //category : (CreatedCard, EditedCard, DuplicatedCard, DeletedCard)
        t : {type : Number, default: 0}
    });
exports.MetricsPerform = ConnectionCache.hgreports.model('MetricsPerform', MetricsPerformSchema, 'MetricsPerform');
exports.MetricsPerformActivity = ConnectionCache.hgreports.model('MetricsPerformActivity', MetricsPerformActivitySchema, 'MetricsPerformActivity');



