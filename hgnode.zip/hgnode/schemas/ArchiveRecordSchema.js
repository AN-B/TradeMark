/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    ArchiveRecordEnums = require('../enums/ArchiveRecordEnums.js'),
    ArchiveRecordSchema = new Schema({
        ArchiveId: {type: String},
        Collection: {type: String, enum: Object.keys(ArchiveRecordEnums.Collection)},
        CreatedBy: {type: String},
        Content: {type: Schema.Types.Mixed},
        Note: {type: String}
    });
exports.ArchiveRecord = ConnectionCache.hglog.model('ArchiveRecord', ArchiveRecordSchema, 'ArchiveRecord');