/*jslint node:true es5:true*/
'use strict';

/*!
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),

/**
 * Schema Notes
 *
 * To reduce the foot print of these collections in the database
 * The property names have been shortened. Here is the Mapping for
 * the fields used
 * p -> Period : Daily (UTC date does not include time)
 * g -> group id
 * h -> hourly stats 0 through 23
 * t -> total count
 * c -> category defers by schema see not by schema
 */
    MetricsCongratSchema = new Schema({
        p : {type : Date, default: Date.now},
        g : {type : String, default: ''},
        c : {type : String, default: ''}, //category : (recognition, comments, news)
        s : {type : String, default: ''}, // source web, mobile
        t : {type : Number, default: 0}
    });
exports.MetricsCongrat = ConnectionCache.hgreports.model('MetricsCongrat', MetricsCongratSchema, 'MetricsCongrat');



