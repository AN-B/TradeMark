/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    NotificationPreferenceSchema = new HGSchema({
        MemberId: {type: String},
        UserId: {type: String},
        GroupId: {type: String},
        Categories: [{
            _id: false,
            Category: {type: String},
            Name: {type: String},
            Delivery: {
                Email: {type: Boolean, default: true},
                SMS: {type: Boolean, default: false},
                InApp: {type: Boolean, default: false},
                Device: {type: Boolean, default: false}
            }
        }]
    });
exports.NotificationPreference = ConnectionCache.hgcommon.model('NotificationPreference', NotificationPreferenceSchema, 'NotificationPreference');
