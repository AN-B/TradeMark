/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    CountryEnums = require('../enums/CountryEnums.js'),
    EntityEnums = require('../enums/EntityEnums.js'),
    TangoCardSchema = new HGSchema({
        CardName: {type: String, default: ''},
        Type: {type: String, default: 'giftcard', enum: ['giftcard', 'charity']},
        Country: {type: String, default: EntityEnums.TangoTypes.US, enum: (function () {
            var ce = Object.keys(CountryEnums);
            ce.push(EntityEnums.TangoTypes.Global);
            return ce;
        }())},
        ImageUrl: {type: String, default: ''},
        GroupIds: [{type: String, default: ''}],
        ExcludedGroupIds: [{type: String, default: ''}],
        EmailTemplateId: {type: String, default: ''},
        Fulfillment: {type: String, default: EntityEnums.TangoTypes.Auto, enum: [EntityEnums.TangoTypes.Auto, EntityEnums.TangoTypes.Manual]},
        Denominations: [{
            Description: {type: String, default: ''},
            SKU: {type: String, default: ''},
            Denomination : {type: Number, default: 0},//this is the Denomination value in card's currency
            UnitPrice: {type: Number, default: 0}, // Total cost in cents for the card. If -1, then variable between min and max properties.
            MinPrice: {type: Number, default: 0},
            MaxPrice: {type: Number, default: 0},
            CurrencyType: {type: String, default: 'USD'}//from the Tango reward list, the field is USD associated with the "UnitPrice". This does NOT reflect if this is "Amazon USA" or "Amazon Canada"
        }],
        ServiceFee : {type: Number}
    }),
    TangoCardOrderSchema = new HGSchema({
        GroupId : {type: String, default: ''},
        CardName : {type: String, default: ''},
        CardType : {type: String, default: ''},
        UserId: {type: String, default: ''},
        order_id: {type: String, default: ''},
        account_identifier: {type: String, default: ''},
        customer: {type: String, default: ''},
        sku: {type: String, default: ''},
        amount: {type: Number, default: 0},
        reward_message: {type: String, default: ''},
        reward_subject: {type: String, default: ''},
        reward_from: {type: String, default: ''},
        delivered_at: {type: Date},
        recipient: {
            name: {type: String, default: ''},
            email: {type: String, default: ''}
        },
        reward: {type: Schema.Types.Mixed},
        Invoiced : {type: Boolean} // only used for cards that have service fee
    });
module.exports.TangoCard = ConnectionCache.hgperka.model('TangoCard', TangoCardSchema, 'TangoCard');
module.exports.TangoCardOrder = ConnectionCache.hgperka.model('TangoCardOrder', TangoCardOrderSchema, 'TangoCardOrder');