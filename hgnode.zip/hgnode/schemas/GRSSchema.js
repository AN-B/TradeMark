'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    GRSOrderSchema = new HGSchema({
        MemberPIN: {type: String},
        MemberHgId: {type: String},
        MemberFirstName: {type: String},
        MemberLastName: {type: String},
        ShippingCompany: {type: String},
        ShippingAddress1: {type: String},
        ShippingAddress2: {type: String},
        ShippingCity: {type: String},
        ShippingProvinceState: {type: String},
        ShippingCountry: {type: String},
        ShippingPostalCode: {type: String},
        ShippingTelephone: {type: String},
        ShippingEmail: {type: String},
        BusinessAddress: {type: String},
        OrderNumber: {type: String},
        PointsPurchased: {type: String},
        PointsPurchasedCost: {type: String},
        PointsPurchasedCurrency: {type: String},
        TotalPointCost: {type: String},
        OrderItems: [{
            LineItemId: {type: String},
            OrderId: {type: String},
            OrderedAt: {type: Date},
            ProductName: {type: String},
            ProductDescription: {type: String},
            Quantity: {type: String},
            PointCost: {type: String}
        }]
    });

module.exports.GRSOrder = ConnectionCache.hgperka.model('GRSOrder', GRSOrderSchema, 'GRSOrder');