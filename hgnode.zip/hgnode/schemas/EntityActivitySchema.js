/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    EntityActivityEnums = require('../enums/EntityActivityEnums.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EntityActivitySchema = new HGSchema({
        EntityType: {type: String, enum: Object.keys(EntityActivityEnums.EntityType)},
        ActivityType: {type: String, enum: Object.keys(EntityActivityEnums.ActivityType)},
        EntityId: {type: String},
        Entities: [],
        PageCount: {type: Number},
        BatchId: {type: String},
        MemberId: {type: String},
        UserId: {type: String},
        FullName: {type: String},
        GroupId: {type: String},
        Activity: {type: Object}
    });

exports.EntityActivity = ConnectionCache.hglog.model('EntityActivity', EntityActivitySchema, 'EntityActivity');
