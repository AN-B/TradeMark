/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EntityEnums = require('../enums/EntityEnums.js'),
    UserInfoSchema = new HGSchema({
        UserName: {type : String, default: ''},
        LowercaseUserName: {type : String, default : ''},
        UserPersonal: {
            FirstName: {type : String, default : ''},
            LastName: {type : String, default : ''},
            FullName: {type : String, default : ''},
            Address: {type : String, default : ''},
            PrimaryEmail: {type : String, default : ''},
            Startdate: {type : Number, default : Date.now}
        },
        Preference: {
            DefaultGroupId: {type : String, default : ''},
            NickName: {type : String, default : ''},
            Photo: {type : String, default : ''},
            Channels: {type : String, default : ''},
            DefaultChannelId: {type : String, default : ''},
            HomeZip: {type : String, default : ''},
            WorkZip: {type : String, default : ''},
            DefaultChannel: {type : String, default : ''},
            SuppressBirthday: {type: Boolean, default: false},
            SuppressAnniversary: {type: Boolean, default: false}
        },
        UserToken: {type : String, default : ''},
        ActAsUserToken: {type : String, default : ''},
        UserContext: {
            CurrentGroupId: {type : String, default : ''},
            CurrentLocationId: {type : String},
            CurrentLocationName: {type : String},
            CurrentGroupName: {type : String, default : ''},
            CurrentProgramName: {type : String, default : ''},
            CurrentGroupBannerColor: {type: String, default: ''},
            CurrentGroupBannerMotif: {type: String, default: ''},
            CurrentGroupBannerUrl: {type : String, default : ''},
            CurrentGroupTermStatus: {type : String, enum : ['Accepted', 'Pending', 'NoPermission', 'Bypass'], default : 'NoPermission'},
            CurrentGroupDepartmentName: {type : String},
            CurrentGroupDepartmentId: {type : String},
            StartingDateInGroup: {type : Number, default: Date.now},
            BirthdateInGroup: {type: Number, default: Date.now},
            MemberIdInGroup: {type : String, default : ''},
            MemberTitleInGroup: {type : String, default : ''},
            RolesInGroup : [{type : String, default : ''}],
            PermissionsInGroup : [{type : String, default : ''}],
            FriendlyId : {type : String, default : ''},
            MembershipStatus : {type : String, default : ''},
            AggregatedSecuredTabs : {},
            MyManagers : [{
                UserId: {type : String},
                MemberId: {type : String, default : ''},
                FullName: {type : String, default : ''}
            }],
            ExperiencePoint : {type : Number, default : 0},
            GravatarEmail: {type: String, default: ''}
        },
        MyMemberships : [{
            GroupId: {type : String, default : ''},
            GroupName: {type : String, default : ''},
            GroupDepartmentName: {type : String, default : ''},
            GroupTermStatus: {type : String, enum : ['Accepted', 'Pending', 'NoPermission', 'Bypass'], default : 'NoPermission'},
            BannerUrl: {type : String, default : ''},
            MemberIdInGroup: {type : String, default : ''},
            MemberTitleInGroup: {type : String, default : ''},
            RolesInGroup : [{type : String, default : ''}],
            FriendlyId : {type : String, default : ''},
            MembershipStatus : {type : String, default : ''},
            AggregatedSecuredTabs : {},
            MyManagers : [{
                MemberId: {type : String, default : ''},
                FullName: {type : String, default : ''}
            }],
            ExperiencePoint : {type : Number, default : 0},
            GravatarEmail: {type: String, default: ''}
        }],
        UserFinance: {
            SpendingAccountBalance: {type : Number, default : 0},
            TransferAccountBalanceInGroup: {type : Number, default : 0},
            PointSpendingBalance: {type : Number, default : 0},
            PointTransferBalance: {type : Number, default : 0},
            AuthorizeNetCustomerProfileId: {type: Number, default: 0},
            DefaultPaymentProfileId: {type : String, default : ''},
            PaymentProfiles: [{
                HgId: {type: String, default: ''},
                Type: {type: String, default: ''},
                FriendlyName: {type: String, default: ''},
                AuthorizeNetPaymentProfileId: {type: Number, default: 0}, // This probably doesn't belong here. --Demetri
                OnlyForGroupId: {type: String, default: ''}
            }]
        },
        LastLoginTime: {type : Number, default : 0},
        LastCheckInTime: {type : Number, default : 0},
        FirstLogin: [{
            Source: {type: String},
            LoginTime: {type: Number},
            DeviceUuid: {type: String},
            _id: false
        }],
        Flags: {
            WelcomeBadgePending : {type : Boolean, default : true},
            TutorialPending : {type : Boolean, default : true},
            FirstTimeLogin: {type: Boolean}
        },
        AvatarVersion: {type : Number, default : Date.now},
        AvatarUploaded: {type: Boolean},
        DevicePlatform : {type : String},
        DeviceUuid : {type : String},
        DeviceToken : {type : String},//for iOS only
        RegistrationId : {type : String, default : 'RegistrationIdPlaceholder'},//for Android only
        DeviceVersion : {type : String},
        DeviceModel : {type : String},
        i18n: {type: String, default: 'en'},
        SurveyAccessModeInProgress: {type: Boolean}, // this is flag by is used kiosk feature. It is enabled when the survey app is enabled
        Source: {type: String, default: EntityEnums.Source.Web}
    });
UserInfoSchema.set('toJSON', { virtuals: true });
exports.UserInfo = ConnectionCache.hgcommon.model('UserInfo', UserInfoSchema, 'UserInfo');
exports.UserInfoWithToken = ConnectionCache.hgcommon.model('UserInfoWithToken', UserInfoSchema, 'UserInfoWithToken');

