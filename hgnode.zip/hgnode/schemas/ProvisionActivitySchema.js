/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    ProvisionActivitySchema = new HGSchema({
        BatchId : {type : String, default: ''}, // refer to the hgId of the batch
        Type: {type : String, enum : Object.keys(Enums.ProvisionActivityType), default: ''},
        EntityName : {type : String, enum : Object.keys(Enums.ProvisionActivityEntity), default: ''},
        EntityValue : {type : Object, default: ''},
        Summary : {type : String, default: ''},
        Status: {type : String, enum : Object.keys(Enums.ProvisionActivityStatus), default: Enums.ProvisionActivityStatus.Successful},
        Notification: {type : String, enum : Object.keys(Enums.ProvisionActivityNotificationType), default: Enums.ProvisionActivityNotificationType.Pending}
    });

exports.ProvisionActivity = ConnectionCache.hgcommon.model('ProvisionActivity', ProvisionActivitySchema, 'ProvisionActivity');