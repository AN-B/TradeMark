/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EventData = require('../common/EventData.js'),
    EventEmitterCache = require('../framework/EventEmitterCache.js'),
    ScheduleEventSchema = new HGSchema({
        UserId: {type: String, default: ''},
        EmailSent: {
            Birthday: {type: Boolean, default: false},
            Anniversary: {type: Boolean, default: false}
        },
        ScheduleDate: {type: Number, default: Date.now}
    });

exports.ScheduleEvent = ConnectionCache.hgcommon.model('ScheduleEvent', ScheduleEventSchema, 'ScheduleEvent');