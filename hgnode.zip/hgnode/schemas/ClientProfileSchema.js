/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    APIKeyStatus = require('../enums/APIKeyStatus.js'),
    ClientProfileType = require('../enums/ClientProfileTypeEnums.js'),
    EnumUtil = require('../enums/EnumsBase.js'),
    ClientProfileSchema = new HGSchema({
        ClientName: {type: String},
        APIKey: {type: String},
        ClientType: {type: String, default: ClientProfileType.Group, enum: EnumUtil.ReturnValues(ClientProfileType)},
        APIKeyStatus: {type: String, default: APIKeyStatus.Active, enum: EnumUtil.ReturnValues(APIKeyStatus)},
        APIKeyLastAccessedAt: {type: Number, default: Date.now},
        APIKeyLastAccessedFrom: {type: String},
        APIKeyVersion : {type: String},
        GroupId: {type: String},
        PartnerId: {type: String},
        AvailableServices: [String]
    });

exports.ClientProfile = ConnectionCache.hgsecurity.model('ClientProfile', ClientProfileSchema, 'ClientProfile');