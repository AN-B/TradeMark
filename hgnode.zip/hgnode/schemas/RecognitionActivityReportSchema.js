/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    RecognitionActivityReportSchema = new HGSchema({
        GroupId: {type : String, default: ''},
        GroupName: {type : String, default: ''},
        GivenByFullName: {type : String, default: ''},
        GivenByMemberId: {type : String, default: ''},
        GivenByEmployeeId: {type : String, default: ''},
        GiverDepartment: {type : String, default: ''},
        GiverRole: {type : String, default: ''},
        GiverLocation: {type : String, default: ''},
        ReceiverLocation: {type : String, default: ''},
        ReceiverRole: {type : String, default: ''},
        ReceiverDepartment: {type : String, default: ''},
        ReceivedByFullName: {type : String, default: ''},
        ReceivedByEmployeeId: {type : String, default: ''},
        ReceivedByMemberId: {type : String, default: ''},
        RecognitionTitle: {type : String, default: ''},
        RecognitionCategory: {type : String, default: ''},
        Date : {type : String, default : ''},
        TimeRange : {type : String, default: ''},
        BatchId: {type : String, default: ''},
        Status: {type : String, default: ''},
        Comment : {type : String, default: ''},
        RecognitionType : {type : String, default: ''},
        CreditValue : {type : Number, default: 0},
        Company : {type : String, default: ''}, // used for external recognitions
        CompanyRating : {type : Number, default: 0},
        MemberRating : {type : Number, default: 0},
        NumComments : {type : Number, default: 0},
        NumLikes : {type : Number, default: 0},
        EmployeeId : {type : String, default: ''},
        TimeCreated : {type : String, default: ''},
        Source: {type : String, default: 'Web'},
        ActualPointValue: {type: Number}
    });

exports.RecognitionActivityReport = ConnectionCache.hgreports.model('RecognitionActivityReport', RecognitionActivityReportSchema, 'RecognitionActivityReport');
