/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    TagEntitySchema = new Schema({
        Name: {type: String, enum: Object.keys(Enums.TagEntities), default: Enums.TagEntities.Cycle},
        hgId:  {type: String, default: ''},
        CreatedDate: {type: Number, default: Date.now}
    }),
    TagSchema = new HGSchema({
        hgId: {type: String, default: ''},
        Name: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        MemberId: {type: String, default: ''},
        UserId: {type: String, default: ''},
        Entity: [TagEntitySchema],
        Global: {type: Boolean},
        Archived: {type: Boolean, default: false}
    });
exports.Tag = ConnectionCache.hgcommon.model('Tag', TagSchema, 'Tag');