/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    EventData = require('../common/EventData.js'),
    Enums = require('../enums/EntityEnums.js'),
    PerformEnums = require('../enums/PerformanceEnums.js'),
    RecurrenceEnums = require('../enums/RecurrenceEnums.js'),
    enumUtil = require('../enums/EnumsBase.js'),
    Member = require('./MemberSchema.js'),

    AnswerSchema = new HGSchema({
        MemberId: {type: String, default: ''},
        EmployeeId: {type: String, default: ''},
        MemberName: {type: String, default: ''},
        PeopleType: {type: String},
        Text: {type: String},//for 'Paragraph', 'ShortText', 'Templated'
        SelectedValues: [{type: Number}]//for answer type 'ScaleRating', 'RadioButton', 'CheckBox', 'Option'
    }),

    AnswerTemplateSchema  = new HGSchema({
        Cluster: {type: String, default: ''},
        Competency: {type: String, default: ''},
        SkillLevel: {type: String, default: ''},
        Text: {type: String, default: ''},
        Archived: {type: Boolean, default: false}
    }),
    AnswerTemplate = ConnectionCache.hgperform.model('AnswerTemplate', AnswerTemplateSchema, 'AnswerTemplate'),

    QuestionTemplateSchema  = new HGSchema({
        QuestionText: {type: String, default: ''},
        Category: {type: String, default: ''},
        AnswerType: {type: String, enum: Object.keys(Enums.AnswerTypes), default: 'ShortText'},
        Archived: {type: Boolean, default: false}
    }),
    QuestionTemplate = ConnectionCache.hgperform.model('QuestionTemplate', QuestionTemplateSchema, 'QuestionTemplate'),

    PerformanceQuestionSchema  = new HGSchema({
        QuestionText: {type: String, default: ''},
        QuestionHelp: {type: String},
        SortOrder: {type: Number, default: 0},
        Confidential: {type: Boolean, default: false},//if true, subject can NOT see the answer of the manager
        ToBeAnsweredBy: [{type: String}],
        OptionalTo: [{type: String}],//this array should be a subset of ToBeAnsweredBy
        AllowComments: {type: Boolean, default: false},
        AnswerType: {type: String, enum: Object.keys(Enums.AnswerTypes), default: 'ShortText'},
        Matrix: {type: String},
        AnswerSelectors: [{
            Value: {type: Number, default: 0},
            Text: {type: String, default: ''}
        }],
        RecognitionFilter: [{type: String}],
        TrackId:  {type: String},//only populated when it's track discussion
        TrackSetByMemberId:  {type: String},//memberId of person who selected track
        ICanSelectTrack: {type: Boolean},//current user can select track. This is populate when get review by Id
        GoalCycleId:  {type: String},//only populated when it's goal discussion
        GoalCycleSelectedByMemberId:  {type: String},//memberId of person who selected goal
        ICanSelectGoalCycle: {type: Boolean},//current user can select goal. This is populate when get review by Id
        OptionalToMe: {type: Boolean},//if this is optional to me. This is populate when get review by Id
        Answers: [AnswerSchema],//each element in this array is for one people.
        NAEnable: {type: Boolean, default: false},
        NAText:  {type: String, default: ''}
    }),
    PerformanceQuestion = mongoose.model('PerformanceQuestion', PerformanceQuestionSchema),

    PerformanceCardSectionSchema = new HGSchema({
        Title: {type: String, default: ''},
        Description: {type: String, default: ''},
        SortOrder: {type: Number, default: 0},
        Questions: [PerformanceQuestionSchema]
    }),
    PerformanceCardSection = mongoose.model('PerformanceCardSection', PerformanceCardSectionSchema),

    PerformanceCardSchema = new HGSchema({
        Title: {type: String, default: ''},
        Description: {type: String, default: ''},
        IsTemplate:  {type: Boolean, default: false},
        OriginalId: {type: String, default: ''},
        Sections: [PerformanceCardSectionSchema],
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        Status: {type: String, enum: Object.keys(PerformEnums.CardStatus), default: PerformEnums.CardStatus.Draft},
        Type: {type: String, enum: Object.keys(PerformEnums.CardType), default: PerformEnums.CardType.General},
        PeopleTypes: [{
            PeopleTypeName: {type: String, default: ''},
            ContainQuestionForMe: {type: Boolean, default: false},
            Required: {type: Boolean, default: false},
            Hierarchy: {type: Number, default: 0}
        }],
        RestrictUsers: [{
            UserId: {type: String, default: ''},
            MemberId: {type: String, default: ''}
        }],
        DetectableRolesOnly: {type: Boolean, default: false},
        ExpireDate: {type: Number, default: Date.now()}
    }),
    PerformanceCard = ConnectionCache.hgperform.model('PerformanceCard', PerformanceCardSchema, 'PerformanceCard'),

    CardBuildSchema = new HGSchema({
        Title: {type: String, default: ''},
        Description: {type: String, default: ''},
        IsTemplate:  {type: Boolean, default: false},
        OriginalId: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        Status: {type: String, enum: ['Draft', 'ReadyToAssign', 'Archived'], default: 'Draft'},
        Type: {type: String, enum: ['General', 'Project'], default: 'General'},
        PeopleTypes: [{
            PeopleTypeName: {type: String, default: ''},
            ContainQuestionForMe: {type: Boolean, default: false},
            Required: {type: Boolean, default: false},
            Hierarchy: {type: Number, default: 0}
        }],
        DetectableRolesOnly: {type: Boolean, default: false},
        ExpireDate: {type: Number, default: Date.now()},
        QnSs: [{
            hgId: {type: String, default: ''},
            Type: {type: String, enum: ['Question', 'Section'], default: 'Question'},
            QuestionText: {type: String, default: ''},
            QuestionHelp: {type: String, default: ''},
            Title: {type: String, default: ''},//section only
            Description: {type: String, default: ''},//section only
            Confidential: {type: Boolean, default: false},//if true, subject can NOT see the answer of the manager
            ToBeAnsweredBy: [{type: String}],
            AllowComments: {type: Boolean, default: false},
            AnswerType: {type: String, enum: Object.keys(Enums.AnswerTypes), default: 'ShortText'},
            Matrix: {type: String},
            AnswerSelectors: [{
                Value: {type: Number, default: 0},
                Text: {type: String, default: ''}
            }],
            SectionId: {type: String, default: ''}
        }]
    }),
    CardBuild = mongoose.model('CardBuild', CardBuildSchema),

    ReviewPeopleSchema = new HGSchema({
        MemberId: {type: String, default: ''},
        UserId: {type: String, default: ''},
        EmployeeId: {type: String, default: ''},
        MemberFullname: {type: String, default: ''},
        PeopleType: {type: String},//no longer an enum since there could be custom people type on the fly
        Position: {type: String},//Position, will be Position in Member object
        Department: {type: String},
        DeliveryDate: {type: Number, default: Date.now()},
        DueDate: {type: Number, default: Date.now()},
        DueInDays: {type: Number},//number of calendar days it's due upon delivery. This is valid only when DeliveryTrigger is Submission
        SubmitDate: {type: Number, default: Date.now()},
        StatusInCurrentReview: {type: String, enum: Object.keys(PerformEnums.ParticipantStatus), default: PerformEnums.ParticipantStatus.PendingDelivery},
        DlvTrgPplType: {type: String},//this will be populated if the my people type's delivery trigger is "Submission". In this review, if all people of DlvTrgPplType submit, the review will be delivered to me 
        PercentAchieved: {type: Number, default: 0},
        Anonymous: {type: Boolean, default: false},
        AnonymousId: {type: String},
        SignsOff: {type: Boolean},
        InitiatesSignOff: {type: Boolean},
        Signature: {
            Name: {type: String, default: ''},
            SignedAt: {type: Number, default: null},
            Comment:  {type: String, default: ''}
        },
        ContainQuestionForMe: {type: Boolean, default: false},
        CanSeeResponse: {type: Boolean, default: false},
        RequestEditPending: {type: Boolean},
        CanReject: {type: Boolean, default: false},//only applicable when the trigger is submission, and true means this people type can reject the triggering people's submission
        RejectPeopleType: {type: String}//only application when CanReject is true
    }),
    ReviewPeople = mongoose.model('ReviewPeople', ReviewPeopleSchema),

    PerformanceReviewSchema = new HGSchema({
        CycleId: {type: String, default: ''},//hgId of the cycle object
        CycleName: {type: String, default: ''},
        Card: {
            type: Schema.Types.Mixed,
            default: new PerformanceCard()
        },
        Peoples: [ReviewPeopleSchema],
        ArchivedPeoples: [ReviewPeopleSchema],
        StatusByAdminView: {type: String, enum: Object.keys(PerformEnums.ReviewStatus), default: PerformEnums.ReviewStatus.PendingDelivery},//note this does not have a 'ReadyToSubmit' because it does not make sense
        RejectHistory: [{
            Date: {type: Number},
            RejecteeMemberIds: [{type: String}],
            RejecteeUserIds: [{type: String}],
            RejectorMemberId: {type: String},
            RejectorUserId: {type: String},
            Note: {type: String},
            '_id': false
        }],
        ManagerCanSeePastReview: {type: String},// This field is set to give access to a new Manager to see past direct report reviews.
        ReviewClosedDate: {type: Number}, // this field is set when StatusByAdminView  field is CLosed
        ReviewArchiveDate: {type: Number}, // this field is set when StatusByAdminView  field is Archived
        NeedsSignOff: {type: Boolean, default: false},
        CreatorReceivesNotificationOnCompletion: {type: Boolean, default: false},
        //following fields are for DTO
        MyMemberId: {type: String, default: ''},
        MyTypeInReview:  {type: String},
        MyStatusInCurrentReview: {type: String, enum: Object.keys(PerformEnums.ParticipantStatus), default: PerformEnums.ParticipantStatus.PendingDelivery},//this field is populated only meaningful for the current user. the persisited value doesn't mean anything
        MyPercentAchieved: {type: Number, default: 0},
        MyDueDate: {type: Number, default: Date.now()},
        MySubmitDate: {type: Number, default: Date.now()},
        MyAnonymous: {type:  Boolean, default: false},
        MyAnonymousId: {type: String},
        MeetingDate: {type: Number, default: null},
        ICanSeeResponse: {type: Boolean, default: false},
        ICanReject: {type: Boolean},
        ICanReqEdit: {type: Boolean},
        MyRejectees: [{type: String}]
    }),
    PerformanceReview = ConnectionCache.hgperform.model('PerformanceReview', PerformanceReviewSchema, 'PerformanceReview'),

    PerformanceCycleSchema = new HGSchema({
        Title: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        Notes: {type: String},
        ReviewPeriodStart: {type: Number, default: Date.now()},
        ReviewPeriodEnd: {type: Number, default: Date.now()},
        NextDeliveryDate: {type: Number},
        ReleaseDate: {type: Number, default: null},
        ReleaseMethod: {type: String, enum: Object.keys(Enums.ReleaseMethod), default: Enums.ReleaseMethod.ReleaseDate},
        SignOffInitiator: {type: String, default: ''},
        CreatorReceivesNotificationOnCompletion: {type: Boolean, default: false},
        PeriodType: {type: String, enum: enumUtil.ReturnValues(RecurrenceEnums.RecurrencePeriod)},
        NumPeriod: {type: Number},//applicable only to weekly and monthly, 3 means every 3 weeks
        PeopleDates: [{
            PeopleType: {type: String, default: ''},
            DueDate: {type: Number, default: Date.now()},
            DueInDays: {type: Number},//number of calendar days it's due upon delivery. This is valid only when DeliveryTrigger is Submission
            DeliveryDate: {type: Number, default: Date.now()},
            DeliveryTrigger: {type: String, enum: ['Date', 'Submission'], default: 'Date'},
            DlvTrgPplType: {type: String},//Delivery trigger meaningful only when trigger is "Submission". Will be delivered if this type submitted
            CanSeeResponse: {type: Boolean, default: false},
            SignsOff: {type: Boolean, default: false},
            CanReject: {type: Boolean, default: false},//only applicable when the trigger is submission, and true means this people type can reject the triggering people's submission
            '_id': false
        }],
        Cards: [{
            hgId: {type: String, default: ''},
            Title: {type: String, default: ''},
            Description:  {type: String, default: ''},
            SubjectManagerOnly: {type: Boolean},
            DetectableRolesOnly: {type: Boolean, default: false},
            CustomList: [],
            ContainQuestion: [],
            AllReviewsArchived: {type: Boolean, default: false},
            PeopleTypes: [{
                PeopleTypeName: {type: String, default: ''},
                ContainQuestionForMe: {type: Boolean, default: false},
                Required: {type: Boolean, default: false},
                Hierarchy: {type: Number, default: 0},
                '_id': false
            }],
            Assignments: [{
                hgId: {type: String, default: ''},
                CustomAnonymous: {},
                uid: {type: Number},
                Participants: [{
                    PeopleType: {type: String, default: ''},
                    EntityType: {type: String, enum: ['Member', 'Team'], default: ''},
                    EntityId: {type: String, default: ''},
                    EntityName: {type: String, default: ''},
                    Anonymous: {type: Boolean, default: false},
                    AnonymousId: {type: String},
                    AvatarId: {type: String, default: ''},
                    Department: {type: String, default: ''},
                    '_id': false
                }]
            }]
        }],
        PercentCompletion: {type: Number, default: 0},
        PercentPreInProgess: {type: Number, default: 0}//percentage of reviews that a in "PendingDelivery" or "NoStarted" stage
    }),
    PerformanceCycle = ConnectionCache.hgperform.model('PerformanceCycle', PerformanceCycleSchema, 'PerformanceCycle'),

    CycleSummarySchema = new HGSchema({
        Title: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        TotalReviewNumber: {type: Number, default: 0},
        ReviewPeriodStart: {type: Number, default: Date.now()},
        ReviewPeriodEnd: {type: Number, default: Date.now()},
        PercentCompletion: {type: Number, default: 0}//how many have been submitted 
    }),
    CycleSummary = mongoose.model('CycleSummary', CycleSummarySchema),
    CycleDetailSchema = new HGSchema({
        Title: {type: String, default: ''},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        ReviewPeriodStart: {type: Number, default: Date.now()},
        ReviewPeriodEnd: {type: Number, default: Date.now()},
        ReleaseDate: {type: Number, default: null},
        ReleaseMethod: {type: String, enum: Object.keys(Enums.ReleaseMethod)},
        PeopleDates: [{
            PeopleType: {type: String, default: ''},
            DueDate: {type: Number, default: Date.now()},
            DeliveryDate: {type: Number, default: Date.now()},
            SignsOff: {type: Boolean, default: false}
        }],
        TotalReviewNumber: {type: Number, default: 0},
        NotStartedReviewNumber: {type: Number, default: 0},
        InProgressReviewNumber: {type: Number, default: 0},
        SubmittedReviewNumber: {type: Number, default: 0},
        PercentCompletion: {type: Number, default: 0},
        PeriodType: {type: String, enum: enumUtil.ReturnValues(RecurrenceEnums.RecurrencePeriod)},
        NumPeriod: {type: Number},//applicable only to weekly and monthly, 3 means every 3 weeks
        ReviewSummaries: [{
            ReviewId: {type: String, default: ''},
            DetectableRolesOnly: {type: Boolean, default: false},
            StatusByAdminView: {type: String, enum: Object.keys(PerformEnums.ReviewStatus), default: PerformEnums.ReviewStatus.PendingDelivery},
            Peoples: [ReviewPeopleSchema],
            CardTitle: {type: String, default: ''},
            CardId: {type: String, default: ''},
            MeetingDate: {type: Number, default: null}
        }]
    }),
    CycleDetail = mongoose.model('CycleDetail', CycleDetailSchema);

/*Indexes*/
PerformanceReviewSchema.index({
    'Card.GroupId': 1,
    StatusByAdminView: 1,
    'Peoples.MemberId': 1
}, {name: 'CoreDocIndex' });

exports.CardBuild = CardBuild;
exports.CycleDetail = CycleDetail;
exports.CycleSummary = CycleSummary;
exports.QuestionTemplate = QuestionTemplate;
exports.AnswerTemplate = AnswerTemplate;
exports.PerformanceQuestion = PerformanceQuestion;
exports.PerformanceCardSection = PerformanceCardSection;
exports.ReviewPeople = ReviewPeople;
exports.PerformanceCard = PerformanceCard;
exports.PerformanceReview = PerformanceReview;
exports.PerformanceCycle = PerformanceCycle;
