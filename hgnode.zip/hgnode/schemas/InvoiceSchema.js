/*jslint node:true es5:true*/
'use strict';
var DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    HGSchema = require('../common/HGSchema.js'),
    InvoiceSchema = new HGSchema({
        BatchId: {type: String},
        StartBillingDate : {type : Date},
        GroupId: {type: String, default: ''},
        GroupName: {type: String, default: ''},
        StartDate: {type: Date, default: Date.now},
        Rate: {type: Number, default: 0},
        NumEmps: {type: Number, default: 0},
        ServiceTotal: {type: Number, default: 0},
        FeeTotal: {type: Number, default: 0},
        BillMeTotal: {type: Number, default: 0},
        CreditsPurchasedQuantity: {type: Number, default: 0}, // Credits Purchased Quantity
        CreditsPurchasedAmount: {type: Number, default: 0}, // Credits Purchased Amount
        Total: {type: Number, default: 0},
        InvoiceDate: {type: Date, default: Date.now},
        CardFees : [{
            CardName : {type: String},
            CardServiceFee : {type: Number},
            TotalCardsPurchased : {type: Number},
            TotalCardFees : {type: Number}
        }],
        Status: {type: String, default: 'Pending', enum: ['Pending', 'Sent', 'Paid', 'Overdue']}
    });

exports.Invoice = ConnectionCache.hgfinance.model('Invoice', InvoiceSchema, 'Invoice');
