/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    RelevancyEnums = require('../enums/RelevancyEnums.js'),
    BucketEnums = require('../enums/BucketEnums.js'),
    MemberRelevancySchema = new HGSchema({
        GroupId: {type: String},
        MemberId: {type: String},
        Relevants: [{type: String}],//array of member ids who are relevancy to subject
        Size: {type: Number, default: 0},
        Status: {type: String,  enum: Object.keys(BucketEnums.Status), default: BucketEnums.Status.Active}
    }),
    MemberRelevancy = ConnectionCache.hgthanka.model('MemberRelevancy', MemberRelevancySchema, 'MemberRelevancy'),

    MemberInteractionSchema = new HGSchema({
        GroupId: {type: String},
        SubjectMemberId: {type: String},
        ObjectMemberId: {type: String},
        //below are metric to reflect relevancy between two members
        GiveReco: {type: Number},
        ReceiveReco: {type: Number},
        InSameReco: {type: Number},
        GiveComm: {type: Number},
        ReceiveComm: {type: Number},
        GiveLike: {type: Number},
        ReceiveLike: {type: Number},
        GiveGift: {type: Number},
        ReceiveGift: {type: Number},
        GiveTag: {type: Number},
        ReceiveTag: {type: Number},
        InSameTag: {type: Number},
        FollowGoal: {type: Number},
        GoalFollowed: {type: Number},
        ReqFeedback: {type: Number},
        GiveFeedback: {type: Number},
        Bookmark: {type: Number}
    }),
    MemberInteraction = ConnectionCache.hgthanka.model('MemberInteraction', MemberInteractionSchema, 'MemberInteraction');

exports.MemberRelevancy = MemberRelevancy;
exports.MemberInteraction = MemberInteraction;