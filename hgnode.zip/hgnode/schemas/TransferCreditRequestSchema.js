/*jslint node:true es5:true*/
'use strict';

var HGSchema = require('../common/HGSchema.js'),
    mongoose = require('mongoose'),

    TransferCreditRequestSchema = new HGSchema({
        mId: {type : String, default : ''},
        recipients : [{
            hgId: {type : String, default : ''},
            userId: {type : String, default : ''},
            credits : {type : Number, default : 0},
            FromAccountId: {type : String, default : ''},
            ToAccountId: {type : String, default : ''},
            Notes: {type : String, default : ''},
            RecipientMember : {}
        }]
    });

exports.TransferCreditRequest = mongoose.model('TransferCreditRequest', TransferCreditRequestSchema, 'TransferCreditRequest');
