/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    TemplateEnums = require('../enums/TemplateEnums.js'),
    TemplateSchema = new HGSchema({
        Type: {type: String, enum: Object.keys(TemplateEnums.Type), default: TemplateEnums.Type.Benchmark},
        Status: {type: String, enum: Object.keys(TemplateEnums.Status), default: TemplateEnums.Status.Active},
        Title: {type: String},
        Description: {type: String},
        // Used for BenchmarkSurvey
        UberQuestion: {type: Schema.Types.Mixed}, //QuestionProp Type
        DriverQuestions: [{type: Schema.Types.Mixed}], //QuestionProp Type
        //Used for Pulse Survey
        PulseQuestions: [{type: Schema.Types.Mixed}] //QuestionProp Type
    });
TemplateSchema.set('toJSON', { virtuals: true });
exports.Template = ConnectionCache.hgperform.model('Template', TemplateSchema, 'Template');