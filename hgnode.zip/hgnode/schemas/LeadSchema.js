/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    LeadSchema = new HGSchema({
        Name: {type : String},
        Company: {type : String},
        Email: {type : String},
        Phone: {type : String},
        DevicePlatform : {type : String},
        DeviceVersion : {type : String}
    });

exports.Lead = ConnectionCache.hgcommon.model('Lead', LeadSchema, 'Lead');
