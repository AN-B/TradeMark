/*jslint node:true es5:true*/
'use strict';
var ConnectionCache = require('../framework/ConnectionCache.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    HGSchema = require('../common/HGSchema.js'),
    GroupRolePermissionsSchema = new HGSchema({
        GroupId: {type: String, default: ''},
        RoleName: {type : String, default: ''},
        AddedPermissions: [String]
    });

exports.GroupRolePermissions = ConnectionCache.hgcommon.model('GroupRolePermissions', GroupRolePermissionsSchema, 'GroupRolePermissions');
