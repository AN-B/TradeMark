/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    UserSecurityStatus = require('../enums/UserSecurityStatus.js'),
    EntityEnums = require('../enums/EntityEnums.js'),
    UserSecuritySchema = new HGSchema({
        UserName: {type: String},
        FirstName: {type: String},
        Status: {type: String, enum: [UserSecurityStatus.Active, UserSecurityStatus.PasswordChangeRequired, UserSecurityStatus.Suspended, UserSecurityStatus.LockedOut], default: UserSecurityStatus.Active},
        LowercaseUserName: {type: String},
        Password: {type: String},
        Password_PBKDF2: {type: String},
        PasswordSalt: {type: String},
        PasswordIterations: {type: Number},
        PasswordExpiration: {type: Number},
        Roles: [],
        Permissions: [],
        AvailableServiceArray: [],
        UserToken: {type: String},
        ActAsUserToken: {type: String},
        ActionToken: {type: String}, //used only when need to reset password
        FailLoginAttempts: {type: Number, default: 0},
        LockedOutTime: {type: Number, default: Date.now},
        LastRefreshTime: {type: Number, default: Date.now},
        SSO: {
            Salesforce: {
                Username: {type: String}
            },
            LinkedIn: {
                state: {type: String},
                state_ref: {type: String},
                access_token: {type: String},
                expires: {type: Number, default: 0}
            },
            Facebook: {
                state_ref: {type: String},
                access_token: {type: String},
                expires: {type: Number, default: 0}
            }
        },
        Source: {type: String, default: EntityEnums.Source.Web}
    });

exports.UserSecurity = ConnectionCache.hgsecurity.model('UserSecurity', UserSecuritySchema, 'UserSecurity');
exports.UserSecurityWithToken = ConnectionCache.hgsecurity.model('UserSecurityWithToken', UserSecuritySchema, 'UserSecurityWithToken');