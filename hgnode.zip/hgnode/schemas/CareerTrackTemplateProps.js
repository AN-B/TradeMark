/*jslint node:true es5:true*/
'use strict';

var MileStoneEmbedded = require('./MilestoneSchema.js'),
    MilestoneEmbeddedSchema = MileStoneEmbedded.MilestoneEmbeddedSchema,
    Props = function () {
        return {
            Title: { type : String, default: '' },
            Description: { type : String, default: '' },
            TrackType: { type : String, enum: ['Goal', 'Skill', 'Education', 'Training', 'Project', 'Performance', 'Achievement'] },
            IsLinear: { type : Boolean, default: false },
            MileStones: [MilestoneEmbeddedSchema],
            Goal: { type : MileStoneEmbedded, default: new MileStoneEmbedded.MileStoneEmbedded()},
            FriendlyGroupId : {type : String, default : ''},
            GroupId: {type : String, default : ''},  //Group.hgId
            Archive: { type : Boolean, default: false }, //bool. if true, don't show in search
            GroupName: {type : String, default : ''},
            PodId: {type : String, default : ''},  //Pod.hgId
            PodName: {type : String, default : ''},
            AccessLevel: { type : String, enum : ['Individual', 'WithinTeam', 'WithinGroup'], default: 'Individual'},
            TeamId : { type : String, default: '' },//meaningful only when AccessLevel is "WithinTeam"
            ObjectiveLabel: {type : String, default : ''},
            ObjectiveWeight: {type : Number, default : 0},
            MilestoneLabel: {type : String, default : ''},
            Frequency: { type : String, enum: ['Quarterly', 'Annually', 'Custom'] },
            NotificationFrequency : {type : String, enum : ['Never', 'Weekly', 'Monthly', 'Quarterly'], default : 'Weekly'},
            MilestoneWeightType: {type: String, enum: ['Equally', 'Custom'], default: 'Equally'}
        };
    };

module.exports = Props;