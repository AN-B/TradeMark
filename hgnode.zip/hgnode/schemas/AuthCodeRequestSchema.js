/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    ConnectionCache = require('../framework/ConnectionCache.js'),
    AuthCodeRequestSchema = new Schema({
        CreatedDate: {type: Date},
        UserName: {type: String},
        IPAddress: {type: String},
        GroupId: {type: String},
        DevicePlatform: {type: String},
        DeviceUuid: {type: String},
        DeviceToken: {type: String}
    });
exports.AuthCodeRequest = ConnectionCache.hgcommon.model('AuthCodeRequest', AuthCodeRequestSchema, 'AuthCodeRequest');
