/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    Enums = require('../enums/EntityEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    PermissionSchema = new HGSchema(
        {
            PermissionName: {type: String},
            Status: {type: String},
            Description: {type: String},
        });
exports.Permission = ConnectionCache.hgcommon.model('Permission', PermissionSchema, 'Permission');
