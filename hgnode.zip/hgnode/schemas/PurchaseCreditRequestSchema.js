/*jslint node:true es5:true*/
'use strict';

var HGSchema = require('../common/HGSchema.js'),
    mongoose = require('mongoose'),

    PurchaseCreditRequestSchema = new HGSchema({
        PackTemplateId: {type : String, default : ''},
        PaymentProfileId : {type : String, default : ''},
        WhomToBuy : {type : String, default : ''}
    });

exports.PurchaseCreditRequest = mongoose.model('PurchaseCreditRequest', PurchaseCreditRequestSchema, 'PurchaseCreditRequest');
