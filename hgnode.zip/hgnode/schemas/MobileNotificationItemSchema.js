/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    MobileNotificationItemSchema = new HGSchema({
        UserId : {type : String, default : ''},
        Content : {},
        Viewed: {type : Boolean, default: false}
    });

exports.MobileNotificationItem = ConnectionCache.hgcommon.model('MobileNotificationItem', MobileNotificationItemSchema, 'MobileNotificationItem');
