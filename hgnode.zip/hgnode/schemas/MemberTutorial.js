/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    MemberTutorialSchema = new HGSchema({
        MemberId : {type : String},
        TutorialIds : [{type : String}]
    });

exports.MemberTutorial = ConnectionCache.hgcommon.model('MemberTutorial', MemberTutorialSchema, 'MemberTutorial');