/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    DemoEnums = require('../enums/DemoEnums.js'),
    DemoEnvironmentSchema = new HGSchema({
        Type: {type: String, enum: Object.keys(DemoEnums.Type)},
        FeatureFlags: [{
            FeatureName: {type: String},
            FeatureMeta: [{
                Name: {type: String},
                Value: {type: String},
                _id: false
            }],
            FeatureEnabled: {type: Boolean, default: false},
            _id: false
        }]
    });
exports.DemoEnvironment = ConnectionCache.hgcommon.model('DemoEnvironment', DemoEnvironmentSchema, 'DemoEnvironment');
