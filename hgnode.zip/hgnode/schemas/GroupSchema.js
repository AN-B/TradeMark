/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Props = require('./GroupProps.js'),
    GroupSchema = new HGSchema(Props),
    GroupEmbedded = new Schema(Props, {_id : false}),
    GroupFinance = new HGSchema({
        hgId: {type : String, default : ''},
        GroupName: {type : String, default: ''},
        HGAccountId: {type : String, default: ''},
        BillMeAllowed : {type : Boolean, default: false},
        CreditLimit : {type : Number, default: 0},//in credits
        RatePerPerson : {type : Number, default: 0},
        StartBillingDate : {type : Number, default: Date.now},
        TotalFloatCredit : {type : Number, default: 0}
    });
GroupSchema.index({
    GroupName : 1,
    Status : 1
}, {name : 'CoreDocIndex' });
exports.GroupFinance = mongoose.model('GroupFinance', GroupFinance);
exports.Group = ConnectionCache.hgcommon.model('Group', GroupSchema, 'Group');
exports.GroupEmbedded = mongoose.model('GroupEmbedded', GroupEmbedded);