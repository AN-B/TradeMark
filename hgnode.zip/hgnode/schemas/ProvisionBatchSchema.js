/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    ProvisionEnums = require('../enums/ProvisionEnums.js'),
    ProvisionBatchSchema = new HGSchema({
        FileName: {type: String, default: ''},
        Type: {type: String, enum: Object.keys(Enums.ProvisionBatchType), default: ''},
        Status: {
            type: String,
            enum: Object.keys(Enums.ProvisionBatchStatus),
            default: Enums.ProvisionBatchStatus.InProgress
        },
        Activities: []
    }),
    ProvisionQueueSchema = new HGSchema({
        Type: {type: String, enum: Object.keys(ProvisionEnums.QueueType)},
        Status: {type: String, enum: Object.keys(ProvisionEnums.QueueStatus)},
        Source: {type: String, enum: Object.keys(ProvisionEnums.QueueSource)},
        AuditId: {type: String},
        GroupId: {type: String},
        HideWelcomeBadge: {type: String},
        DisableTutorial: {type: String},
        StartTime: {type: Date},
        EndTime: {type: Date},
        Members: [{}]
    }),
    ProvisionAuditSchema = new HGSchema({
        GroupId: {type: String},
        BatchId: {type: String},
        MemberId: {type: String},
        FullName: {type: String},
        FileName: {type: String},
        Status: {type: String, enum: Object.keys(ProvisionEnums.Status), default: ProvisionEnums.Status.FileUploaded},
        Type: {type: String, enum: Object.keys(ProvisionEnums.Type)},
        GroupStatus: {type: String, enum: Object.keys(ProvisionEnums.ProcessStepStatus), default: ProvisionEnums.ProcessStepStatus.NotStarted},
        LocationStatus: {type: String, enum: Object.keys(ProvisionEnums.ProcessStepStatus), default: ProvisionEnums.ProcessStepStatus.NotStarted},
        DepartmentStatus: {type: String, enum: Object.keys(ProvisionEnums.ProcessStepStatus), default: ProvisionEnums.ProcessStepStatus.NotStarted},
        MemberStatus: {type: String, enum: Object.keys(ProvisionEnums.ProcessStepStatus), default: ProvisionEnums.ProcessStepStatus.NotStarted},
        MemberProcessStep: {type: String, enum: Object.keys(ProvisionEnums.ProcessMemberStep), default: ProvisionEnums.ProcessMemberStep.NotStarted},
        CurrentStep: {type: Number, default: 0},
        Content: {
            Company: {},
            EmployeeHeader: {},
            LocationHeader: {}
        },
        Notes: [{
            _id: false,
            Time: {type: Date},
            Text: {type: String}
        }],
        SFTPFilePath: {type: String}
    }),
    ProvisionStagedDepartmentSchema = new HGSchema({
        GroupId: {type: String},
        GroupName: {type: String},
        BatchId: {type: String},
        AuditId: {type: String},
        Name: {type: String},
        Code: {type: String},
        ProcessType: {type: String, enum: Object.keys(ProvisionEnums.ProcessType)},
        Status: {type: String, enum: Object.keys(ProvisionEnums.ProcessStepStatus), default: ProvisionEnums.ProcessStepStatus.NotStarted}
    }),
    ProvisionFileMapSchema =  new HGSchema({
        GroupId: {type: String},
        GroupName: {type: String},
        MapFunctionName: {type: String},
        PreserveRoleForExistingUsers: {type: Boolean},
        PreserveSuppressBirthdayForExistingUsers: {type: Boolean},
        PreserveSuppressAnniversaryForExistingUsers: {type: Boolean},
        Keys: {
            FirstName: {type: String},
            LastName: {type: String},
            FullName: {type: String},
            UserName: {type: String},
            Email: {type: String},
            StartDate: {type: String},
            BirthDate: {type: String},
            EmpID: {type: String},
            Department: {type: String},
            DepartmentCode: {type: String},
            Role: {type: String},
            Position: {type: String},
            JobLevel: {type: String},
            JobCode: {type: String},
            BenefitStatus: {type: String},
            HomeZip: {type: String},
            HomeCountry: {type: String},
            WorkZip: {type: String},
            Manager: {type: String},
            ManagerEmpID: {type: String},
            ManagerUserName: {type: String},
            SuppressBirthday: {type: String},
            SuppressAnniversary: {type: String},
            Location: {type: String},
            OffBoardType: {type: String},
            OffBoardDate: {type: String},
            MailCD: {type: String},
            UnionCode: {type: String},
            MileagePlus: {type: String},
            CostCenter: {type: String}
        },
        ManagerUserNameProvided: {type: Boolean},
        ManagerEmployeeIdProvided: {type: Boolean}, //used in validation
        DoNotCopyDefaultAvatar: {type: Boolean},
        FileExt: {type: String},
        FileDelimiter: {type: String},
        FileEndLineChar: {type: String},
        UserNameGenerated: {type: Boolean},
        AllowAutoUserNameChange: {type: Boolean},
        UserNameDomain: {type: String},
        AllowOffboardedManagerTransfer: {type: Boolean}
    }),
    ProvisionStagedMemberSchema = new HGSchema({
        Action: {type: String},
        GroupId: {type: String},
        GroupName: {type: String},
        FileType: {type: String},
        BatchId: {type: String},
        AuditId: {type: String},
        UserId: {type: String},
        UserNameChangeType: {type: String},
        MemberId: {type: String},
        LocationId: {type: String},
        DepartmentId: {type: String},
        FirstName: {type: String},
        LastName: {type: String},
        FullName: {type: String},
        UserName: {type: String},
        Email: {type: String},
        StartDate: {type: String},
        BirthDate: {type: String},
        EmpID: {type: String},
        Department: {type: String},
        DepartmentCode: {type: String},
        Role: {type: String},
        Position: {type: String},
        JobLevel: {type: String},
        JobCode: {type: String},
        HomeZip: {type: String},
        HomeCountry: {type: String},
        WorkZip: {type: String},
        Manager: {type: String},
        ManagerEmpID: {type: String},
        ManagerUserName: {type: String},
        SuppressBirthday: {type: String},
        SuppressAnniversary: {type: String},
        NewUserName: {type: String}, //used in update and hris file
        Location: {type: String},
        OffBoardType: {type: String},
        OffBoardDate: {type: String},
        BenefitStatus: {type: String},
        NotificationEmail: {type: String},
        MailCD: {type: String},
        UnionCode: {type: String},
        MileagePlus: {type: String},
        CostCenter: {type: String},
        Row: {type: Number},
        USM: {type: Boolean}, //Manager and UserName equal
        ManagerEmpIdSameAsReportEmpId: {type: Boolean}, // Manager employeeId is the same as the direct report employeeId
        InvalidEmail: {type: Boolean},
        InvalidStartDate: {type: Boolean},
        InvalidBirthDate: {type: Boolean},
        InvalidOffBoardDate: {type: Boolean},
        InvalidRole: {type: Boolean},
        InvalidSuppressAnniversary: {type: Boolean},
        InvalidSuppressBirthday: {type: Boolean},
        InvalidNewUserName: {type: Boolean},
        InvalidOffBoardType: {type: Boolean},
        InvalidUserName: {type: Boolean}, // fails regex
        InvalidNewUserNameValue: {type: Boolean}, // fails regex
        InvalidManagerUserName: {type: Boolean}, // fails regex
        InvalidNotificationEmail: {type: Boolean}, // fails notification email
        InvalidMultipleFlagNotEnabled: {type: Boolean}, // fails when their are multiple managers in the file and the flag is not enabled
        ProcessStep: {type: String},
        ProcessType: {type: String}, //New, Update, Offboard
        UCStatus: {type: String}, //User creation and update status
        MUStatus: {type: String}, // manager update status
        NUStatus: {type: String}, // new user name update status
        OBStatus: {type: String},
        CStatus: {type: String}, // used for post provision event
        SpecialNote: {type: String}
    }),
    ProvisionStagedLocationSchema = new HGSchema({
        GroupId: {type: String},
        GroupName: {type: String},
        BatchId: {type: String},
        AuditId: {type: String},
        Name: {type: String},
        Description: {type: String},
        Address1: {type: String},
        Address2: {type: String},
        City: {type: String},
        State: {type: String},
        ZipCode: {type: String},
        Country: {type: String},
        Phone: {type: String},
        LocationCode: {type: String},
        Language: {type: String},
        TimeZone: {type: String},
        Row: {type: Number},
        InvalidCountry: {type: Boolean},
        InvalidState: {type: Boolean},
        InvalidZipCode: {type: Boolean},
        InvalidLanguage: {type: Boolean},
        InvalidTimeZone: {type: Boolean},
        ProcessType: {type: String, enum: Object.keys(ProvisionEnums.ProcessType)},
        Status: {type: String, enum: Object.keys(ProvisionEnums.ProcessStepStatus), default: ProvisionEnums.ProcessStepStatus.NotStarted}
    });

ProvisionStagedMemberSchema.set('toJSON', { virtuals: true });
ProvisionStagedLocationSchema.set('toJSON', { virtuals: true });
ProvisionFileMapSchema.set('toJSON', { virtuals: true });
exports.ProvisionBatch = ConnectionCache.hgcommon.model('ProvisionBatch', ProvisionBatchSchema, 'ProvisionBatch');
exports.ProvisionFileMap = ConnectionCache.hglog.model('ProvisionFileMap', ProvisionFileMapSchema, 'ProvisionFileMap');
exports.ProvisionAudit = ConnectionCache.hglog.model('ProvisionAudit', ProvisionAuditSchema, 'ProvisionAudit');
exports.ProvisionQueue = ConnectionCache.hglog.model('ProvisionQueue', ProvisionQueueSchema, 'ProvisionQueue');
exports.ProvisionStagedMember = ConnectionCache.hglog.model('ProvisionStagedMember', ProvisionStagedMemberSchema, 'ProvisionStagedMember');
exports.ProvisionStagedLocation = ConnectionCache.hglog.model('ProvisionStagedLocation', ProvisionStagedLocationSchema, 'ProvisionStagedLocation');
exports.ProvisionStagedDepartment = ConnectionCache.hglog.model('ProvisionStagedDepartment', ProvisionStagedDepartmentSchema, 'ProvisionStagedDepartment');