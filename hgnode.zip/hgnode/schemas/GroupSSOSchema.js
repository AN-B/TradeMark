'use strict';
var HGSchema = require('../common/HGSchema'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache'),
    SAMLEnums = require('../enums/SAMLEnums'),
    GroupSSOSchema = new HGSchema({
        GroupId: {type: String},
        SAML: {
            uploaded_at: {type: Number},
            type: {type: String}, //array of SAMLEnums
            cert: {type: String},
            issuer: {type: String},
            entryPoint: {type: String},
            slo: {type: String}
        },
        Yammer: {
            access_token: {type: String},
            created_at: {type: Number},
            expires: {type: Number},
            network_name: {type: String},
            verified_admin: {type: Boolean, default: false},
            user_email: {type: String},
            user_hgId: {type: String},
            user_name: {type: String},
            notifyGroups: [{type: String}]
        },
        Slack: {
            access_token: {type: String},
            channels: [String]
        },
        slug: {type: String}
    });

exports.GroupSSO = ConnectionCache.hgcommon.model('GroupSSO', GroupSSOSchema, 'GroupSSO');