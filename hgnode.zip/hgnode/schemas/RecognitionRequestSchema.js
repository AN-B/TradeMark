/*jslint node:true es5:true*/
'use strict';

var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    RecognitionEnums = require('../enums/RecognitionEnums.js'),
    RecognitionRequestSchema = new HGSchema({
        BadgeId: {type : String},//used only for customized recogniont
        TemplateTitle : {type : String},//used only for customized recogniont
        TemplateId: {type : String},
        TemplateIds: [{type : String}],
        IssuerMemberId: {type : String},
        IssuerGroupId: {type : String},
        AttachmentIds: [{type : String}],
        RecipientMemberIds: [{type : String}],
        RecipientTeamIds: [{type : String}],
        RecipientLocationIds: [{type : String}],
        RecipientUserIds: [{type : String}],
        Title: {type : String, default: ''},
        Message: {type : String, default: ''},
        MessageEdited: {type : Boolean},
        Publicity : {type : String, enum: Object.keys(RecognitionEnums.Publicity)},
        CompanyName: {type : String, default: ''},
        FullName: {type : String, default: ''},
        Email: {type : String, default: ''},
        CompanyRating: {type : Number, default: 0},
        MemberRating: {type : Number, default: 0},
        CreditPerRecipient : {type : Number, default: 0},
        PointPerRecipient : {type : Number, default: 0},
        TotalCreditRequired : {type : Number, default: 0},
        TotalPointRequired : {type : Number, default: 0},
        MoreOptions : {
            suppressFeed: {type : Boolean, default: false},
            creditValue: {type : Number, default: 0},
            pointValue : {type : Number, default: 0},
            giftId : {type : String, default: ''}
        },
        Mode : {type : String, enum: Object.keys(RecognitionEnums.Mode)},
        ImageId: {type : String},
        Level: {type : String},
        Levels: [{
            Name: {type: String},
            PointValue: {type: Number, default: 0},
            CreditValue: {type: Number, default: 0}
        }],
        ValidationError : {type : String},
        Source : {type : String},
        SubValue: {type : String},
        RequesterRole: {type: String}
    });
RecognitionRequestSchema.set('toJSON', { virtuals: true });
exports.RecognitionRequest = ConnectionCache.hgthanka.model('RecognitionRequest', RecognitionRequestSchema, 'RecognitionRequest');
