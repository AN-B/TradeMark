/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    FeedbackEnums = require('../enums/FeedbackEnums.js'),
    RecurrenceEnums = require('../enums/RecurrenceEnums.js'),

    QuestionAnswerSchema = new HGSchema({
        Tag: {type: String},//used for Succession Planning
        OriginalId: {type: String},
        Question: {type: String},
        QuestionHelp: {type: String},
        Type: {type: String, enum : Object.keys(FeedbackEnums.QuestionType), default: FeedbackEnums.QuestionType.ShortAnswer},
        ScaledAnswerValue: {type: Number}, // used for ratingscale
        Required: {type: Boolean, default: true},
        OptionalComment: {type: Boolean, default: false}, //only allowed for ratingscale
        Comment: {type: String}, //used with Rating Scale when OptionalComments is true
        Answers: [{
            MemberId: {type: String},
            UserId: {type: String},
            MemberName: {type: String},
            PeopleType: {type: String},
            Text: {type: String},//for 'Paragraph', 'ShortText', 'Templated'
            SelectedValues: [{type: Number}],//for answer type 'ScaleRating', 'RadioButton', 'CheckBox', 'Option'
            '_id': false
        }],
        MinRange: {type: Number}, //used with Slider question
        MaxRange: {type: Number}, //used with Slider question
        AnswerSelector: [{ // used for ratingscale, multiple choice, check box, slider
            Text: {type: String},
            Value: {type: Number},
            Order: {type: Number},
            '_id': false
        }],
        ManagerNotes: [{
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Notes: {type: String}
        }],
        NotApplicableOptionText: {type: String},
        NotApplicableOption: {type: Boolean}, // used for ratingscale
        AnsweredDate: {type: Date},
        SortOrder: {type: Number, default: 0},
        ToBeAnsweredBy: [{type: String}]//for request feedback it's always Subject, while in self-assessment it's always subject, for perform review it could be anything
    }, {'_id': false}),
    FeedbackQuestionAnswer = mongoose.model('FeedbackQuestionAnswer', QuestionAnswerSchema),

    FeedbackCardSchema = new HGSchema({
        Title: {type: String},
        Description: {type: String},
        GroupId: {type: String},
        GroupName: {type: String},
        Category: {type: String},//used to differentiate system and group cards
        Status: {type: String, enum: Object.keys(FeedbackEnums.CardStatus), default: FeedbackEnums.CardStatus.Draft},
        UseSections: {type: Boolean}, //used to indicate to UI to display with sections
        Sections: [{
            hgId: {type: String},
            OriginalId: {type: String},
            Title: {type: String},
            Description: {type: String},
            Type: {type: String, enum: Object.keys(FeedbackEnums.SectionType)},
            GoalCycleName: {type: String},
            GoalCycleId: {type: String},//if type is "CycleGoal" or "CycleGoals"
            QuestionForEachGoal: {type: Boolean},
            GoalId: {type: String},//if type is "CycleGoal" or "CycleGoals"
            AllowSkipGoals: {type: Boolean},//adhoc goals
            StartDate: {type: Number},//adhoc goals or reconigiotns
            EndDate: {type: Number},//adhoc goals or reconigiotns,
            Questions: [QuestionAnswerSchema],
            '_id': false,
            AllowSectionToBeSkipped: {type: Boolean},//this is true when user does not have goals while feeling the review
        }],
        Type: {type: String, enum: Object.keys(FeedbackEnums.CardType)},
        SinglePageQuestion: {type: Boolean},
        IsPrivate: {type: Boolean}
    }),
    FeedbackCard = ConnectionCache.hgperform.model('FeedbackCard', FeedbackCardSchema, 'FeedbackCard'),

    FeedbackRequestSchema = new HGSchema({
        CycleId: {type: String},
        CycleTitle: {type: String},
        RequestNote: {type: String},
        ExpirationDate: {type: Number},
        CompletedDate: {type: Number},
        IsPrivate: {type: Boolean},//Refer to Cycle's IsPrivate field
        GroupId: {type: String},
        Status: {type: String, enum: Object.keys(FeedbackEnums.RequestStatus), default: FeedbackEnums.SessionStatus.Requesting},
        CycleType: {type: String, enum: Object.keys(FeedbackEnums.CycleType)},
        RequesterMemberId: {type: String},//Request/AboutOthers/Give: person who requested or gave feedback
        RequesterUserId: {type: String},
        RequesterFullName: {type: String},
        SubjectMemberId: {type: String},//Request: person who requested, Give: person who is given, Others: about whom
        SubjectUserId: {type: String},
        SubjectFullName: {type: String},
        UnreadInfo: {type: Boolean},//true is there is unread information for the requester
        Sessions: [{
            SessionId: {type: String},//FeedbackSessionSchema.hgId,
            ReviewerMemberId: {type: String},
            ReviewerUserId: {type: String},
            ReviewerFullName: {type: String},
            SubmittedDate: {type: Number},
            DeclinedDate: {type: Number},
            UnreadInfo: {type: Boolean},//true is there is unread information for the reviewer
            SessionStatus: {type: String, enum: Object.keys(FeedbackEnums.SessionStatus), default: FeedbackEnums.SessionStatus.Requesting},
            '_id': false
        }]
    }),
    FeedbackRequest = ConnectionCache.hgperform.model('FeedbackRequest', FeedbackRequestSchema, 'FeedbackRequest'),
    FeedbackSessionSchema = new HGSchema({
        CycleId: {type: String},
        InitiatorId: {type: String},//refer to FeedbackCycleInitiator.hgId
        RequestId: {type: String}, //refer to FeedbackRequest.hgId
        ClusterId: {type: String},
        CycleTitle: {type: String},
        CycleType: {type: String, enum: Object.keys(FeedbackEnums.CycleType)},
        CycleDescription: {type: String},
        Note: {type: String}, //admin instruction
        ExpirationDate: {type: Number},//request expires if not accept/decline by this date
        Card: {
            type: mongoose.Schema.Types.Mixed,
            default: new FeedbackCard()
        },
        DeclinedDate: {type: Number},
        ArchiveDate: {type: Number},
        CompletedDate: {type: Number},
        Participants: [{//one session has limited number of participants, so it's an embedded array
            ParticipantType: {type: String},//doesn't use enum because there might be custom type
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Status: {type: String, enum: Object.keys(FeedbackEnums.SessionParticipantStatus), default: FeedbackEnums.SessionParticipantStatus.Requesting},
            DeliveryDate: {type: Number},//request is delivered at this date
            AcceptByDate: {type: Number},//by this date, the participant has to accept or decline. Usually for reviewers
            DueDate: {type: Number},
            Role: {type: String},
            DepartmentName: {type: String},
            DepartmentId: {type: String},
            LocationName: {type: String},
            LocationId: {type: String},
            SubmittedDate: {type: Number},
            EmployeeId: {type: String},
            NeedsSignOff: {type: Boolean},
            ViewedDate: {type: Number}, //Only set the first time that manager view the session
            _id: false
        }],
        ShowManagerNotes: {type: Boolean},
        RequestNote: {type: String},
        SubjectRating: {type: String, enum: Object.keys(FeedbackEnums.SubjectRating)},
        RatingNote: {type: String},
        DeclineNote: {type: String},
        GroupId: {type: String},
        PrevStatus: {type: String, enum: Object.keys(FeedbackEnums.SessionStatus)},
        Status: {type: String, enum: Object.keys(FeedbackEnums.SessionStatus), default: FeedbackEnums.SessionStatus.Requesting}
    }),
    FeedbackSession = ConnectionCache.hgperform.model('FeedbackSession', FeedbackSessionSchema, 'FeedbackSession'),

    StagedInitiatorSchema = new HGSchema({
        ClusterId: {type: String},
        GroupId: {type: String},
        MemberId: {type: String}
    }),
    StagedInitiator = ConnectionCache.hgperform.model('StagedInitiator', StagedInitiatorSchema, 'StagedInitiator'),

    FeedbackCycleInitiatorSchema = new HGSchema({//person who should initiate a feedback session. Usually it's the subject
        CycleId: {type: String},
        CycleTitle: {type: String},
        CycleType: {type: String, enum: Object.keys(FeedbackEnums.CycleType)},
        Description: {type: String},
        GroupId: {type: String},
        ClusterId: {type: String},
        Type: {type: String, enum: Object.keys(FeedbackEnums.InitiatorType), default: FeedbackEnums.InitiatorType.Subject},
        MemberId: {type: String},
        Status: {type: String, enum: Object.keys(FeedbackEnums.CycleInitiatorStatus), default: FeedbackEnums.CycleInitiatorStatus.PendingDelivery},
        AvatarId: {type: String},//UserId, or TeamId, or group.hgId
        Name: {type: String},//member fullname, or team name, or group program name,
        DeliveryDate: {type: Number},
        DueDate: {type: Number},
        ClosedDate: {type: Number},
        Role: {type: String},
        DepartmentName: {type: String},
        DepartmentId: {type: String},
        LocationName: {type: String},
        LocationId: {type: String},
        EmployeeId: {type: String},
        LastInitiateDate: {type: Number, default: Date.now()},
        HasInstruction: {type: Boolean},
        SkipGiveInstruction: {type: Boolean},
        TipGivePending: {type: Boolean},
        LastAnsweredSessionId: {type: String},
        LastViewedSessionId: {type: String}

        // DesignatedReviewers: []//Place holder. People who are designated by admin to be reviewers in this cycle/card
    }),
    FeedbackCycleInitiator = ConnectionCache.hgperform.model('FeedbackCycleInitiator', FeedbackCycleInitiatorSchema, 'FeedbackCycleInitiator'),

    FeedbackCycleClusterSchema = new HGSchema({//this is for the "group" in spec
        CycleId: {type: String},
        Title: {type: String},
        Description: {type: String},
        CycleType: {type: String, enum: Object.keys(FeedbackEnums.CycleType)},
        GroupId: {type: String},
        Criteria: [{ // filter clause  example -> level (Manager) in Department in Location
            // MemberIds: {}, //Array of MemberIds to include specific members // not currently used future
            Level: {type: String},
            DepartmentName: {type: String},
            DepartmentId: {type: String},
            LocationName: {type: String},
            LocationId: {type: String},
            _id: false
        }],
        Status: {type: String, enum: Object.keys(FeedbackEnums.ClusterStatus), default: FeedbackEnums.ClusterStatus.Pending}
    }),
    FeedbackCycleCluster = ConnectionCache.hgperform.model('FeedbackCycleCluster', FeedbackCycleClusterSchema, 'FeedbackCycleCluster'),

    FeedbackCycleSchema = new HGSchema({
        GroupId: {type: String},
        GroupName: {type: String},
        Title: {type: String},
        Description: {type: String},
        IsPrivate: {type: Boolean},//if true, Request: Subject & Reviewer; AboutOther: Requester & Reviewer; Give: Giver & Subject
        AdminNote: {type: String}, //internal note just for the admin
        Workflow: {type: String, enum: Object.keys(FeedbackEnums.Workflow), default: FeedbackEnums.Workflow.Direct},
        Status: {type: String, enum: Object.keys(FeedbackEnums.CycleStatus), default: FeedbackEnums.CycleStatus.Draft},
        Note: {type: String}, // Admin user Instruction
        TriggerType: {type: String, enum: Object.keys(FeedbackEnums.TriggerType), default: FeedbackEnums.TriggerType.RequestAnytime},
        Type: {type: String, enum: Object.keys(FeedbackEnums.CycleType)},
        CardId: {type: String},
        CardTitle: {type: String},
        NotifyInitiator: {type: Boolean}, //currently used to notify initiators new request card is available
        InitiatorSetting: {
            DeliveryDate: {type: Number},//when will this be delivered to the initiator
            DueDate: {type: Number}//days for the initiator to send request
        },
        ClosedDate: {type: Number},
        ArchivedDate: {type: Number},
        SubjectSignOff: {type: Boolean},//this needs to be changed when we support custom type
        ReviewerSignOff: {type: Boolean},//this needs to be changed when we support custom type
        ShowManagerNotes: {type: Boolean},
        ExpireRequestDays: {type: Number, default: FeedbackEnums.Default.ExpireRequestDays}, //the feedback request would expire after this number of days
        CycleOwner: {
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String}
        },
        GiverTips: {type: String, enum: Object.keys(FeedbackEnums.TrainingPDFType), default: FeedbackEnums.TrainingPDFType.None},
        GiverTipsFileName: {type: String},
        RequesterTips: {type: String, enum: Object.keys(FeedbackEnums.TrainingPDFType), default: FeedbackEnums.TrainingPDFType.None},
        RequesterTipsFileName: {type: String},
        Locked: {type: Boolean} // used with talent insight
    }),
    FeedbackCycle = ConnectionCache.hgperform.model('FeedbackCycle', FeedbackCycleSchema, 'FeedbackCycle'),

    FeedbackGuideSchema = new HGSchema({
        GroupId: {type: String},
        Type: {type: String, enum: Object.keys(FeedbackEnums.CycleType)},
        FileName: {type: String}
    }),
    FeedbackGuide = ConnectionCache.hgperform.model('FeedbackGuide', FeedbackGuideSchema, 'FeedbackGuide');

exports.FeedbackQuestionAnswer = FeedbackQuestionAnswer;
exports.FeedbackCycleCluster = FeedbackCycleCluster;
exports.FeedbackSession = FeedbackSession;
exports.FeedbackCard = FeedbackCard;
exports.FeedbackCycleInitiator = FeedbackCycleInitiator;
exports.FeedbackCycle = FeedbackCycle;
exports.StagedInitiator = StagedInitiator;
exports.FeedbackGuide = FeedbackGuide;
exports.FeedbackRequest = FeedbackRequest;
