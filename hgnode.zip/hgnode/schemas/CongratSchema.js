/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    CongratSchema = new HGSchema({
        MemberId: {type : String, default : ''},
        RecognitionIds: [],
        GroupId: {type : String, default : ''},
        GroupName: {type : String, default: ''},
        Status : {type : String, enum : Object.keys(Enums.CongratStatus), default: Enums.CongratStatus.Active},
        Source : { type : String, default: 'Web'}// Web or Mobile Device
    });

exports.Congrat = ConnectionCache.hgthanka.model('Congrat', CongratSchema, 'Congrat');
