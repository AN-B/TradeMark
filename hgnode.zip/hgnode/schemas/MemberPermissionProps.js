/*jslint node:true es5:true*/
'use strict';
var Enums = require('../enums/EntityEnums.js'),
    MemberEnums = require('../enums/MemberEnums.js'),
    Props = function () {
        return {
            Permission: {type: String, default: ''},
            Description: {type: String, default: ''},
            SecuredTabs: [{
            }],
        };
    };

module.exports = new Props();