/*jslint node:true es5:true*/
'use strict';

var Enums = require('../enums/EntityEnums.js'),
    Member = require('./MemberSchema.js'),
    RecognitionEnums = require('../enums/RecognitionEnums.js'),
    Props = function () {
        return {
            Title:  { type: String, default: ''},
            Description: { type: String, default: ''},
            DepartmentName: { type: String, default: '' },
            Message: {type: String},
            CreditValue: {type: Number, default: 0},
            PointValue: {type: Number, default: 0},
            FriendlyGroupId: {type: Number, default: -1},
            GroupId: {type: String, default: ''},
            GroupName: {type: String, default: ''},
            Tags: {type: String},
            Category: {type: String, enum: Object.keys(RecognitionEnums.RecognitionCategory), default: RecognitionEnums.RecognitionCategory.Everyday},
            SubCategory: {type : String, enum : Object.keys(RecognitionEnums.RecognitionSubCategory), default: RecognitionEnums.RecognitionSubCategory.Default},
            Type: {type: String, enum: Object.keys(RecognitionEnums.TemplateType), default: RecognitionEnums.TemplateType.Recognition},
            AccessLevel: {type: String, enum: Object.keys(RecognitionEnums.AccessLevel), default: RecognitionEnums.AccessLevel.WithinGroup},
            TeamId: {type: String},//meaningful only when AccessLevel is "WithinTeam"
            ApprovalLevel: {type: String},
            ApproverMemberId: {type: Number, default: -1},
            DefaultGivenToNewMembers: { type: Boolean, default: false },
            Publicity: {type: String, enum: Object.keys(RecognitionEnums.Publicity)},
            SubValues: [{
                Name: {type: String, default: '' },
                ImageId: {type: String, default: '' },
                IconPickerColor: {},
                Description: {type: String},
                BadgeId: {type: String, default: '' }
            }],
            AchievementLevelEnabled: {type: Boolean, default: false},
            Levels: [{
                Name: {type: String},
                PointValue: {type: Number, default: 0},
                CreditValue: {type: Number, default: 0}
            }],
            ForegroundFilename: {type: String},
            BackgroundFilename: {type: String},
            BadgeId: {type: String},//for foreground
            DefaultBadge: {type: Boolean}, //used for default badges moved from group
            BackgroundBadgeId: {type: String},
            RestrictUsers: {
                TeamIds: {type: Array, default: []},
                MemberIds: {type: Array, default: []},
                Roles: [{type: String}]
            },
            RestrictDepartmentIds: {type: Array, default: []},
            RestrictDepartments: [{
                Id: {type: String},
                Name: {type: String}
            }],
            IconPickerColor: {}, // this object is now an array
            BkgdPickerColor: {}
        };
    };

module.exports = new Props();
