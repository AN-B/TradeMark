/*jslint node:true es5:true*/
'use strict';

var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    SurveyEnums = require('../enums/SurveyEnums.js'),
    SurveyDriverSchema = new HGSchema({
        Name: {type: String},
        Description: {type: String},
        Status: {type: String, enum: Object.keys(SurveyEnums.SurveyDriverStatus), default: SurveyEnums.SurveyDriverStatus.Active},
        GroupId: {type: String}
    });
exports.SurveyDriver = ConnectionCache.hgperform.model('SurveyDriver', SurveyDriverSchema, 'SurveyDriver');