/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    PollEnums = require('../enums/PollEnums.js'),
    PollQuestionSchema = new HGSchema({
        GroupId: {type: String},
        Question: {type: String},
        Description: {type: String},
        AnswerOptions: [{
            Value: {type: Number},
            Text: {type: String},
            _id: false
        }],
        Status: {type: String, enum: Object.keys(PollEnums.Status), default: PollEnums.Status.Active},
        StartDate: {type: Number},
        EndDate: {type: Number},
        ParticipantsCount: {type: Number},
        Participants: [{
            Type: String, //Member, Department, Location, All (future)
            Id: String,
            _id: false
        }]
    }),
    PollSchema = new HGSchema({
        GroupId: {type: String},
        UserId: {type: String},
        FullName: {type: String},
        MemberId: {type: String},
        PollQuestionId: {type: String},
        DepartmentId: {type: String},
        DepartmentName: {type: String},
        LocationId: {type: String},
        LocationName: {type: String},
        Role: {type: String},
        Status: {type: String, enum: Object.keys(PollEnums.QuestionStatus), default: PollEnums.QuestionStatus.Pending},
        Tenure: {type: String},
        StartDate: {type: Date},
        CompletedDate: {type: Date},
        ExpireDate: {type: Number},
        AnswerValue: {type: Number}
    });
exports.PollQuestion = ConnectionCache.hgperform.model('PollQuestion', PollQuestionSchema, 'PollQuestion');
exports.Poll = ConnectionCache.hgperform.model('Poll', PollSchema, 'Poll');
