/*jslint node:true es5:true*/
'use strict';
var DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    HGSchema = require('../common/HGSchema.js'),
    OnBoardMemberSchema = new HGSchema({
        UserId: {type : String, default: ''},
        FirstName: {type : String, default: ''},
        LastName: {type : String, default: ''},
        FullName: {type : String, default: ''},
        UserName: {type : String, default: ''},
        Email: {type : String, default: ''},
        Password: {type : String, default: ''},
        GroupId: {type : String, default: ''},
        Role: {type : String, enum : ['Employee', 'Manager', 'Director', 'Executive', 'Admin'], default: 'Employee'},
        Position: {type : String, default: ''},
        Team: {type : String, default: ''},
        StartDate: {type : Number, default: Date.now},
        BirthDate: {type : Number, default: Date.now},
        HomeZip: {type : String, default: ''},
        WorkZip: {type : String, default: ''},
        EmployeeId : {type : String, default: ''},
        LastEmployeeId : {type : String, default: ''},
        SendWelcomeEmail : {type : Boolean, default : false},
        SendWelcomeEmailDate : {type : Number, default : Date.now},
        Managers : [{
            MemberId: {type : String, default : ''},
            FullName: {type : String, default : ''}
        }]
    });

exports.OnBoardMemberTemplate = ConnectionCache.hgcommon.model('OnBoardMemberTemplate', OnBoardMemberSchema, 'OnBoardMemberTemplate');