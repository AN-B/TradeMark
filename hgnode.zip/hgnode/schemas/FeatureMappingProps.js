/*jslint node:true es5:true*/
'use strict';
var Enums = require('../enums/EntityEnums.js'),
    MemberEnums = require('../enums/MemberEnums.js'),
    Props = function () {
        return {
            Feature: {type: String},
            CustomLogic: {type: String},
            GroupId : {type: String},
            TrueCondition: [{
            }],
            FalseCondition: [{
            }]
        };
    };

module.exports = new Props();