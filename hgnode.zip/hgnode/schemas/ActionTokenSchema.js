/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    Enums = require('../enums/EntityEnums.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    ActionTokenSchema = new HGSchema({
        Status: {type: String, enum: Object.keys(Enums.ActionTokenStatus), default: Enums.ActionTokenStatus.Pending},
        Type: {type: String, enum: Object.keys(Enums.ActionTokenType), default: Enums.ActionTokenType.PasswordReset},
        EntityName: {type: String},
        EntityId: {type: String},
        ExpireDate: {type: Number, default: Date.now()},
        AuthCode: {type: Number}
    });

exports.ActionToken = ConnectionCache.hgsecurity.model('ActionToken', ActionTokenSchema, 'ActionToken');