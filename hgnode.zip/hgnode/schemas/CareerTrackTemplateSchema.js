/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    PropsDefinition = require('./CareerTrackTemplateProps.js'),
    Props = new PropsDefinition(),
    HGSchema = require('../common/HGSchema.js'),
    uuid = require('node-uuid'),
    CareerTrackTemplateSchema = new HGSchema(Props);

CareerTrackTemplateSchema.index({ TeamId: 1}, {unique: false});

CareerTrackTemplateSchema.methods.GenerateMileStoneIds = function () {
    var i, len = this.MileStones.length;
    for (i = 0; i < len; i += 1) {
        this.MileStones[i].hgId = uuid.v1();
    }
};

exports.CareerTrackTemplate = ConnectionCache.hgthanka.model('CareerTrackTemplate', CareerTrackTemplateSchema, 'CareerTrackTemplate');