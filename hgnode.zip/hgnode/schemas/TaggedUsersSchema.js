/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    obj = new HGSchema({
        Tags: [{
            UserId: {type: String},
            Id: {type: String}
        }]
    });
exports.TaggedUser = ConnectionCache.hgthanka.model('TaggedUser', obj, 'TaggedUser');