/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    LogSchema = new Schema({
        meta: {type: Object, default: null},
        timestamp: {type: Date, default: Date.now},
        level: {type: String, default: ''},
        message: {type: String, default: ''}
    });
exports.Log = ConnectionCache.hglog.model('Log', LogSchema, 'log');