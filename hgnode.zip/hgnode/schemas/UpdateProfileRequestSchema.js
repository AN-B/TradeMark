/*jslint node:true es5:true*/
'use strict';

var HGSchema = require('../common/HGSchema.js'),
    mongoose = require('mongoose'),
    UpdateProfileRequestSchema = new HGSchema({
        FirstName: {type : String, default : ''},
        LastName: {type : String, default : ''},
        FullName: {type : String, default : ''},
        HomeZip: {type : String, default : ''},
        WorkZip: {type : String, default : ''},
        SuppressBirthday: {type : Boolean, default : false},
        SuppressAnniversary: {type : Boolean, default : false},
        PrimaryEmail: {type : String, default : ''},
        DefaultGroupId: {type : String, default : ''},
        DefaultChannel: {type : String, default : ''},
        CurrentPassword: {type : String, default : ''},
        NewPassword1: {type : String, default : ''},
        NewPassword2: {type : String, default : ''}
    });

UpdateProfileRequestSchema.methods.ContainValidPasswordChangeRequest = function () {
    return (this.CurrentPassword.length > 0 && this.NewPassword1.length > 0 && this.NewPassword1 === this.NewPassword2);
};

exports.UpdateProfileRequest = mongoose.model('UpdateProfileRequest', UpdateProfileRequestSchema, 'UpdateProfileRequest');
