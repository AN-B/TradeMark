/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    Enums = require('../enums/EntityEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    RoleSchema = new HGSchema(
        {
            Role: {type: String},
            GroupId: {type: String},
            GroupName: {type: String},
            Type: {type: String},
            Description: {type: String},
            Permissions: [{
            }],
            RoleStatus: {type: String , enum: Object.keys(Enums.RoleStatus)}
        });
exports.Role = ConnectionCache.hgcommon.model('Role', RoleSchema, 'Role');
