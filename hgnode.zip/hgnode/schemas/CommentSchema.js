/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Props = require('./CommentProps.js'),
    HGSchema = require('../common/HGSchema.js'),
    CommentSchema = new HGSchema(Props),
    CommentEmbedded = new Schema(Props, {_id : false});

exports.Comment = ConnectionCache.hgthanka.model('Comment', CommentSchema, 'Comment');
exports.CommentEmbedded  = mongoose.model('CommentEmbedded', CommentEmbedded);