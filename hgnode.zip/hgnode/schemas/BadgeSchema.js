/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Props = require('./BadgeProps.js'),
    HGSchema = require('../common/HGSchema.js'),
    BadgeSchema = new HGSchema(Props),
    BadgeEmbedded = new Schema(Props, {_id : false});

exports.Badge = ConnectionCache.hgthanka.model('Badge', BadgeSchema, 'Badge');
exports.e  = mongoose.model('BadgeEmbedded', BadgeEmbedded);