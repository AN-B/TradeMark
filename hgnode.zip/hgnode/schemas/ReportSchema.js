/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    ReportEnums = require('../enums/ReportEnums.js'),
    ReportSchema = new HGSchema({
        ReportTypeId: {type: Number},
        EntityId: {type: String},
        Ext: {type: String, enum: Object.keys(ReportEnums.Extension), default: ReportEnums.Extension.xlsx},
        ReportTypeName: {type: String},
        OperationType: {type: String},
        ReportGroupId: {type: String},
        RequesterGroupId: {type: String},
        RequesterUserId: {type: String},
        RequesterMemberId: {type: String},
        RequesterFullname: {type: String},
        Department: {type: String},
        ManagerMemberId: {type: String},
        StartDate: {type: Number},
        EndDate: {type: Number},
        Status: {type: String, enum: Object.keys(ReportEnums.Status), default: ReportEnums.Status.Pending},
        ReadyDate: {type: Number},
        ExpireDate: {type: Number},
        DownloadDate: {type: Number},
        FileName: {type: String},
        Payload: {}
    });
exports.Report = ConnectionCache.hgreports.model('Report', ReportSchema, 'Report');
