/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    CreditAccountSchema = new HGSchema({
        OwnerId: {type: String},
        AccountType: {type: String},
        Category: {type: String},
        Balance: {type: Number, default: 0},
        IsActive: {type: Boolean, default: true},
        GroupId: {type: Array},
    });

exports.CreditAccount = ConnectionCache.hgfinance.model('CreditAccount', CreditAccountSchema, 'CreditAccount');