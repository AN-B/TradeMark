/*jslint node:true es5:true*/
'use strict';
var ConnectionCache = require('../framework/ConnectionCache.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    HGSchema = require('../common/HGSchema.js'),
    DisplaySchema = new HGSchema({
        GroupId: {type: String},
        RecognitionInterval: { type : Number, default : 5 },
        GroupRecognitionAvatarInterval: { type : Number, default : 5 }
    });

exports.Display = ConnectionCache.hgcommon.model('Display', DisplaySchema, 'Display');
