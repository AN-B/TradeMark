/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    Enums = require('../enums/EntityEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    FeaturePermissionSchema = new HGSchema(
        {
			FeatureMain : {type: String},
            Permission: {type: Array},
            Status: {type: String},
            Description: {type: String},
        });
exports.FeaturePermission = ConnectionCache.hgcommon.model('FeaturePermission', FeaturePermissionSchema, 'FeaturePermission');
