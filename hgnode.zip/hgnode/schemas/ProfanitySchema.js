/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    toLower = function (v) {
        return v ? v.toLowerCase() : '';
    },
    ProfanitySchema = new HGSchema({
        Lang: {type: String, default: 'en'},
        Word: {type: String, set: toLower},
        Level: {type: Number},
        Status: {type: String, enum: Object.keys(Enums.ProfanityWordStatus), default: Enums.ProfanityWordStatus.Active},
        GroupId: {type: String}, // Words added by groups
        ExcludedGroupIds: [{type: String}]
    });

exports.Profanity = ConnectionCache.hgcommon.model('Profanity', ProfanitySchema, 'Profanity');