/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    NotificationQueueItemSchema = new HGSchema({
        Category: {type: String},
        Name: {type: String},
        DeliveryMethods: [{type: String, default: ''}],
        RecipientList: [{
            Name: {type: String, default: ''},
            Address: {type: String, default: ''},
            WelcomeBadgePending: {type: Boolean, default: true},
            GroupId: {type: String},
            MemberId: {type: String}
        }],
        Subject: {type: String, default: ''},
        TemplateId: {type: Number, default: 0},
        TemplateName: {type: String, default: ''},
        LockedForDispatching: {type: Boolean, default: false},
        MergeFields: {},
        ClickTracking: {type: Boolean, default: true},
        AttemptNumber: {type: Number, default: 0},
        Action: {type: String, enum: ['SuccessfulAndRemove', 'FailedAndRemove', 'Retry', 'ModifyPayload', 'RequestEntityTooLarge']},//for NotificationAudit only
        Environment: {type: String},//for NotificationAudit only
        ActualAddress: {type: String},//for NotificationAudit only
        ServerResponse: {type: String}, //for NotificationAudit only
        OriginalHgId: {type: String}, //for NotificationAudit only to ref to source
        ReplyTo: {type: String}
    });

exports.NotificationQueueItem = ConnectionCache.hgcommon.model('NotificationQueueItem', NotificationQueueItemSchema, 'NotificationQueueItem');
exports.NotificationAudit = ConnectionCache.hglog.model('NotificationAudit', NotificationQueueItemSchema, 'NotificationAudit');
