/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    UserActivityAuditSchema = new Schema({
        CreatedDate: {type: Date}, // used to archive records
        GroupName: {type: String},
        GroupId: {type: String},
        UserId: {type: String},
        ClientId: {type: String},
        ClientName: {type: String},
        MemberId: {type: String},
        FullName: {type: String},
        ServiceName: {type: String},
        MethodName: {type: String},
        AccessGranted: {type: Boolean, default: false},
        IPAddress:  {type: String},
        BrowserFingerPrint:  {type: Number},
        Source: {type: String},
        UserAgent: {type: String}
    }),
    UnAuthorizedActivitySchema = new Schema({
        CreatedDate: {type: Date}, // used to archive records
        GroupName: {type: String},
        GroupId: {type: String},
        UserId: {type: String},
        MemberId: {type: String},
        FullName: {type: String},
        ServiceName: {type: String},
        MethodName: {type: String},
        IPAddress:  {type: String},
        BrowserFingerPrint: {type: Number},
        Message: {type: String},
        UserToken: {type: String}
    });
exports.UserActivityAudit = ConnectionCache.hglog.model('UserActivityAudit', UserActivityAuditSchema, 'UserActivityAudit');
exports.UnAuthorizedActivity = ConnectionCache.hglog.model('UnAuthorizedActivity', UnAuthorizedActivitySchema, 'UnAuthorizedActivity');