/*jslint node:true es5:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    DTOInstructionSchema = new Schema({
        DataFormat : {type : String, enum : ['Object', 'Array'], default : 'Object'},
        Projections : [{
            Input : {type : String},
            Output : {type : String},
            Mapping : {
                Operation : {type : String, enum : ['Copy', 'FixedValue', 'Conversion-unimplemented', 'Aggregate-unimplemented'], default : 'Copy'},
                Value : {type : String}
            }
        }]
    });
exports.DTOInstruction = mongoose.model('DTOInstruction', DTOInstructionSchema);