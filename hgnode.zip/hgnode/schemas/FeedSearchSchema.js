/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    FeedSearchSchema = new HGSchema({
        Name : {type : String}, // search names are unique and required
        GroupId: {type : String},
        MemberId: {type : String},
        SearchTerm: {type : String, default: ''},
        UserIds : [String],
        TeamIds : [String],
        DepartmentIds : [String],
        LocationIds : [String],
        ManagerIds : [String],
        DefaultSearch : {type : Boolean}, // only one active record can be true
        Status : {type : String, enum : Object.keys(Enums.FeedSearchStatus), default: Enums.FeedSearchStatus.Active},
        RecognitionSource : {type : String, enum : Object.keys(Enums.RecognitionSource), default: Enums.RecognitionSource.Both},
        RelevancyFilter: {type: Boolean}
    });

exports.FeedSearch = ConnectionCache.hgcommon.model('FeedSearch', FeedSearchSchema, 'FeedSearch');
