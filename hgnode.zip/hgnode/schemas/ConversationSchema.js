/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    Enums = require('../enums/EntityEnums.js'),
    Conversation = new HGSchema({
        EntityId: {type: String},
        BatchId: {type: String},
        GroupId: {type: String},
        Type: {type: String, enum: Object.keys(Enums.ConversationType), default: Enums.ConversationType.FeedForward},
        Subject: {type: String, default: ''},
        Creator: {
            MemberId: {type: String, default: ''},
            UserId: {type: String, default: ''},
            FullName: {type: String, default: ''}
        },
        Recipient: {
            MemberId: {type: String, default: ''},
            UserId: {type: String, default: ''},
            FullName: {type: String, default: ''}
        },
        FeedBackType: {type: String, enum: Object.keys(Enums.FeedBackType)},
        Status: {type: String, enum: Object.keys(Enums.ConversationStatus), default: Enums.ConversationStatus.Active},
        Source: {type: String, default: 'Web'}
    });

exports.Conversation = ConnectionCache.hgthanka.model('Conversation', Conversation, 'Conversation');