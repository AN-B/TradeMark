/*jslint node:true es5:true*/
'use strict';
var HGSchema = require('../common/HGSchema.js'),
    Enums = require('../enums/PetitionEnums.js'),
    DatabaseEnums = require('../enums/DatabaseEnums.js'),
    ConnectionCache = require('../framework/ConnectionCache.js'),
    PetitionSchema = new HGSchema({//this is for the "Approval engine". Can't use "Approval" because it's actually for both Approval and rejection. And "Request", "Application" would cause confusion here
        PetitionTypeName: {type: String, enum: Object.keys(Enums.PetitionTypes)},
        EntityId: {type: String},
        Status: {type: String, enum: Object.keys(Enums.Status), default: Enums.Status.Pending},
        Petitioners: [{
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            '_id': false
        }],
        Approvers: [{
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            Decision: {type: String, enum: Object.keys(Enums.DecisionType)},
            '_id': false
        }],
        History: [{
            Time: {type: Number},
            Note: {type: String},//note entered by the petitioner or approver
            Activity: {type: String, enum: Object.keys(Enums.ActivityType)},
            MemberId: {type: String},
            UserId: {type: String},
            FullName: {type: String},
            '_id': false
        }]
    });

exports.Petition = ConnectionCache.hgcommon.model('Petition', PetitionSchema, 'Petition');
