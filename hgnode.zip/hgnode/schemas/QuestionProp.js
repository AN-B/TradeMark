/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    HGSchema = require('../common/HGSchema.js'),
    SurveyEnums = require('../enums/SurveyEnums.js'),
    QuestionPropSchema = new HGSchema({
        Status: {type: String, enum: Object.keys(SurveyEnums.QuestionStatus), default: SurveyEnums.QuestionStatus.Active},
        Type: {type: String, enum: Object.keys(SurveyEnums.QuestionType), default: SurveyEnums.QuestionType.System},
        Driver: { type: Schema.Types.Mixed}, // Type here is SurveyDriver
        AnswerType: {type: String, enum: Object.keys(SurveyEnums.AnswerTypes), default: SurveyEnums.AnswerTypes.RatingScale},
        AnswerSelectors: [{
            Text: {type: String},
            Value: {type: Number},
            Order: {type: Number},
            _id: false
        }],
        Lock: {type: Boolean}, // used by pulse to indicate questions that cannot be changed by group admins
        Order: {type: Number},
        Question: {type: String},
        MinLabelAnswer: {type: String},
        MaxLabelAnswer: {type: String}
    });
exports.QuestionProp = mongoose.model('QuestionProp', QuestionPropSchema);
