/*jslint node:true es5:true*/
'use strict';
// store all api keys here
var keystore = require('../configurations/ks/' + (process.env.BUILD_ENV || 'local') + '-keystore.js'),
    envInvariants = {
        pusher: {
            key: process.env.PUSHER_KEY,
            secret: process.env.PUSHER_SECRET,
            id: process.env.PUSHER_ID
        },
        authorizenet_api: {
            loginid: process.env.AUTHORIZENET_LOGINID,
            key: process.env.AUTHORIZENET_KEY
        },
        amazon_aws: {
            key: process.env.AWS_KEY,
            secret: process.env.AWS_SECRET
        },
        expresspigeon_api: process.env.EXPRESS_PIGEON,
        canvas_api: {
            key: process.env.CANVAS_API_KEY
        },
        linkedin: {
            api_key: process.env.LINKEDIN_API_KEY,
            secret_key: process.env.LINKEDIN_SECRET_KEY,
            oauth_token: process.env.LINKEDIN_OAUTH_TOKEN,
            oauth_secret: process.env.LINKEDIN_OAUTH_SECRET
        },
        yammer: {
            clientId: process.env.YAMMER_CLIENT_ID,
            clientSecret: process.env.YAMMER_CLIENT_SECRET
        },
        slack: {
            clientId: process.env.SLACK_CLIENT_ID,
            clientSecret: process.env.SLACK_CLIENT_SECRET,
            state: process.env.SLACK_STATE
        },
        tango: {
            platform: process.env.TANGO_PLATFORM,
            key: process.env.TANGO_KEY
        },
        loggly: {
            token: process.env.LOGGLY_TOKEN
        },
        statusio: {
            key: process.env.STATUSIO_KEY,
            pageId: process.env.STATUSIO_PAGE_ID,
            metric: process.env.STATUSIO_METRIC,
            componentId: process.env.STATUSIO_COMPONENT_ID
        },
        GRS: {
            storefront: {
                adminUser: process.env.GRS_STOREFRONT_USER,
                token: process.env.GRS_STOREFRONT_TOKEN
            },
            giftcards: {
                username: process.env.GRS_USER,
                password: process.env.GRS_PASSWORD,
                token: process.env.GRS_GIFTCARD_TOKEN
            }
        },
        deskcom: {
            apiKey: process.env.DESKTOP_API_KEY
        },
        WorkerClientKey: process.env.WORKER_CLIENT_KEY,
        CryptoPassword : process.env.CRYPTO_PASSWORD,
        hg_sftp: {
            username: process.env.SFTP_USER,
            password: process.env.SFTP_PASSWORD
        },
        exchangerate: {
            access_key: "a557180971e7a3e2e7facc9192075ff4"
        },
        zopim: {
            chat_id: "1ESyiKnpekzx45ZhEVbEbz1rPWMOJv9Q"
        },
        Redis: {
            REDISCLOUD_URL: process.env.REDISCLOUD_URL
        }
    };
Object.keys(envInvariants).forEach(function (prop) {
    keystore[prop] = keystore[prop] || envInvariants[prop];
});

module.exports = keystore;