/*jslint node:true es5:true*/
'use strict';
// store all api keys here
module.exports = {
    authorizenet_api: {
        loginid: '8ea3N4SB',
        key: '86tM7U4sX3de4KL9'
    },
    yammer: {
        clientId: 'qWbhQcmLh3NJlB8EbeBkvw',
        clientSecret: 'izS6WLuAa0YKXOSIeJjBGkYxwSqh3tcYyJxz2LRmA'
    },
    slack: {
        clientId: '4472746338.8175704566',
        clientSecret: 'f289f7b147b9ec37fdc0d9f2f5b7b9cb',
        state: 'dangergoat'//this is a secret key
    },
    statusio: {
        key: '9077c80d57b6eb40e2923182d2fb24bbb1b42a6b717a90124bc298800cfe2c87',
        pageId: 'b9nx5rrg3vvw',
        metric: 'tnqh3cc8rq6t',
        componentId: 'fyq438qjlc6s'
    },
    deskcom: {
        apiKey: 'cafcf0ac4dd89b3ca85b6309151591f5b8c9907a'
    },
    WorkerClientKey: '99e943b2-52fb-4d55-8a46-d8998660c209',
    CryptoPassword: 'qatest1'
};
