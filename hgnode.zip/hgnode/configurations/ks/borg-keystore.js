/*jslint node:true es5:true*/
'use strict';
// store all api keys here
module.exports = {
    authorizenet_api: {
        loginid: '8ea3N4SB',
        key: '86tM7U4sX3de4KL9'
    },
    yammer: {
        clientId: 'SehGkS3SyPUaVtnKhZXaTw',
        clientSecret: 'HAdW3JEVEh0zvNWaf26nTVumPg41RwamXkTj7Ga6co'
    },
    slack: {
        clientId: '4472746338.8578601396',
        clientSecret: 'a413c5c80f8c794d6d1ac00b90e273b5',
        state: 'dangergoat'     //this is a secret key
    },
    statusio: {
        key: '9077c80d57b6eb40e2923182d2fb24bbb1b42a6b717a90124bc298800cfe2c87',
        pageId: 'b9nx5rrg3vvw',
        metric: 'tnqh3cc8rq6t',
        componentId: 'fyq438qjlc6s'
    },
    deskcom: {
        apiKey: 'cafcf0ac4dd89b3ca85b6309151591f5b8c9907a'
    },
    WorkerClientKey: '99e943b2-52fb-4d55-8a46-d8998660c209',
    CryptoPassword: 'qatest1',
    Redis: {
        REDISCLOUD_URL: 'redis://rediscloud:h29sHqol8TRnUVe1@redis-17229.c8.us-east-1-3.ec2.cloud.redislabs.com:17229'
    },
    newrelic: {
        NEW_RELIC_NO_CONFIG_FILE: 'True',
        NEW_RELIC_APP_NAME: 'HighGround Borg',
        NEW_RELIC_LICENSE_KEY: 'af17a77dbb4d854bc2faa47d3fe893bb9b8a352b',
        NEW_RELIC_LOG_LEVEL: 'info'
    }
};
