/*jslint node:true es5:true*/
'use strict';
// store all api keys here
module.exports = {
    Redis: {
        REDISCLOUD_URL: 'redis://admin@highground.com:pocredis@redis-17621.c8.us-east-1-3.ec2.cloud.redislabs.com:17621'
    }
};
