/*jslint node:true es5:true*/
'use strict';
// store all api keys here
module.exports = {
    authorizenet_api: {
        loginid: '8ea3N4SB',
        key: '86tM7U4sX3de4KL9'
    },
    yammer: {
        clientId: 'zx6ssvRG2OrLm5qSTkrlw',
        clientSecret: 'MGG0SqeSykjZxhsFKPKmnrQ9BjHKgLFuRVLJhWfY8'
    },
    statusio: {
        key: '9077c80d57b6eb40e2923182d2fb24bbb1b42a6b717a90124bc298800cfe2c87',
        pageId: 'b9nx5rrg3vvw',
        metric: 'tnqh3cc8rq6t',
        componentId: 'fyq438qjlc6s'
    },
    deskcom: {
        apiKey: 'cafcf0ac4dd89b3ca85b6309151591f5b8c9907a'
    },
    WorkerClientKey: '99e943b2-52fb-4d55-8a46-d8998660c209',
    CryptoPassword: 'qatest1',
    Redis: {
        REDISCLOUD_URL: 'redis://rediscloud:bxNJNXdzgO3tvXnb@redis-19031.c8.us-east-1-3.ec2.cloud.redislabs.com:19031'
    },
    newrelic: {
        NEW_RELIC_NO_CONFIG_FILE: 'True',
        NEW_RELIC_APP_NAME: 'HighGround Web POC',
        NEW_RELIC_LICENSE_KEY: 'af17a77dbb4d854bc2faa47d3fe893bb9b8a352b',
        NEW_RELIC_LOG_LEVEL: 'info'
    }
};
