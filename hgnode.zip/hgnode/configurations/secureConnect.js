/*jslint node:true es5:true nomen:true stupid:true*/
'use strict';

module.exports = function () {
    var fs = require('fs'),
        isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
        testServers = ['qa', 'uat', 'poc', 'borg', 'cylon', 'tron', 'ripley', 'scully', 'trinity'];

    if (isLocal || testServers.indexOf(process.env.BUILD_ENV) > -1) {
        return {};
    }
    return {
        ssl: true,
        sslValidate: true,
        sslCert: fs.readFileSync(__dirname + '/cert/database-cert.pem')
    };
};