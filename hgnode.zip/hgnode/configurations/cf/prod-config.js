/*jslint node:true es5:true nomen:true*/
'use strict';
// store all environment configurations, including connection strings
module.exports = function (params) {
    return {
        deploy: {
            useNodeEnv: true
        },
        mongodb: {
            hgcommon:   process.env.MONGO_HGCOMMON,
            hgsecurity: process.env.MONGO_HGSECURITY,
            hgthanka:   process.env.MONGO_HGTHANKA,
            hgperka:    process.env.MONGO_HGPERKA,
            hgfinance:  process.env.MONGO_HGFINANCE,
            hgperform:  process.env.MONGO_HGPERFORM,
            hgreports:  process.env.MONGO_HGREPORTS,
            hglog:      process.env.MONGODB_HGLOG,
            winstonlog:  {
                host: process.env.MONGO_HGLOG,
                port: process.env.MONGO_HGLOG_PORT,
                db: 'hglog',
                collection: 'log',
                username: process.env.MONGO_HGLOG_USERNAME,
                password: process.env.MONGO_HGLOG_PASSWORD
            },
            replica: process.env.MONGO_REPLICA,
            replicaLR: process.env.MONGO_REPLICA_LR || process.env.MONGO_REPLICA
        },
        baseUrl: '//app.highground.com/',
        esbUrl: '//esb.highground.com/',
        wwwSite: 'http://www.highground.com',
        ioUrl: 'wss://ws.highground.com',
        protocol: 'https:',
        s3store: {
            provisionDirectory: '//hgprod.s3.amazonaws.com/provision/',
            imageStore: '//hgprod.s3.amazonaws.com',
            cssImageStore: '//hgprod.s3.amazonaws.com/css/',
            javascriptDirectory: '//hgprod.s3.amazonaws.com',
            cssDirectory: '//hgprod.s3.amazonaws.com',
            htmlTemplateDirectory: '//hgprod.s3.amazonaws.com',
            uploadDirectory: '//hgprod.s3.amazonaws.com',
            defaultAvatars: '/files/avatars/default/',
            s3bucketJS: 'hgprod',
            s3bucketCSS: 'hgprod',
            s3bucketImg: 'hgprod',
            s3bucket: 'hgprod',
            cdn: [
                '//prdcdn1.highground.com',
                '//prdcdn2.highground.com',
                '//prdcdn3.highground.com',
                '//prdcdn4.highground.com',
                '//prdcdn5.highground.com'
            ]
        },
        hg_api_host : 'api.highground.com',
        giftcards_api_host: 'api.wrl.com/1.0',
        email : {
            Alert : 'alerts@highground.com',
            FromAddress: "support@highground.com",
            FromName: "Notification",
            BlackHole : 'blackhole@expresspigeon.com',
            BuildErrors: 'build@highground.com',
            Releases: "releases@highground.com",
            Billing: "billing@highground.com",
            Tango: 'tango@highground.com',
            Refund: 'refund@highground.com',
            Operations: 'operations@highground.com'
        },
        HighgroundGlobalUserId : '5e42c56e-5b17-4070-817f-d924a5cd7462',
        APIGlobalUserId : 'db742790-41ca-11e5-b754-c9dc5f0e768c',
        authorizenet: {
            aim_host: 'api2.authorize.net',
            aim_path: '/xml/v1/request.api',
            cim_host: 'api.authorize.net',
            cim_path: '/xml/v1/request.api'
        },
        RecapInterval : 60,
        RecapBatchSize : 1000,
        WeeklyRecapBatchSize : process.env.WEEKLYRECAPBATCHSIZE || 200,
        DispatchEmailInterval : process.env.DISPEMAILINT || 30,
        EmailPerDispatch : process.env.EMAILPERDISP || 600,
        memcached: {
            username: process.env.MEMCACHIER_USERNAME,
            password: process.env.MEMCACHIER_PASSWORD,
            servers: process.env.MEMCACHIER_SERVERS,
            defaultLifetime: 86400 //24hrs
        },
        tango: {
            host: 'api.tangocard.com',
            customer: 'HighGround',
            account: 'Corporate'
        },
        device: {
            ios: {
                gateway: 'gateway.push.apple.com',
                feedback: 'feedback.push.apple.com',
                cert: params.path + '/certs/prd_cert.pem',
                key: params.path + '/certs/prd_key.pem',
                passphrase: 'h164gr0und!'
            },
            android: {
                AppId: '817058402545',
                APIKey : 'AIzaSyAmrgGaNH81GFt8_19QYx5eBWwreHWEMy8'
            }
        },
        onelogin: {
            certPath: params.path + '/certs/local_onelogin.pem',
            issuer: 'highground-saml',
            entryPoint: 'https://app.onelogin.com/trust/saml2/http-post/sso/389869'
        },
        GRS: {
            storefront: {
                host: 'highground2.p2motivate.com',
                path: '/client/soap.php',
                wsdl: '/client/soap.php?wsdl',
                namespace: 'https://highground2.p2motivate.com/client/'
            },
            giftcards: {
                host: 'admin-uat.grsportal.com',
                port: 1022,
                WSDL: 'https://api-uat.grsportal.com/partner/v3/wsdl/token/'
            }
        }
    };
};
