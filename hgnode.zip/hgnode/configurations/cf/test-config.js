/*jslint node:true es5:true nomen:true*/
'use strict';
var RedisRetry = require('../RedisRetry');

// store all environment configurations, including connection strings
module.exports = function (params) {
    var testDBPort = process.env.BUILD_CODESHIP ? 27018 : 27017;
    return {
        deploy: {
            useNodeEnv: false
        },
        mongodb: {
            hgcommon: 'mongodb://localhost:' + testDBPort + '/hgcommon_test',
            hgsecurity: 'mongodb://localhost:' + testDBPort + '/hgsecurity_test',
            hgthanka: 'mongodb://localhost:' + testDBPort + '/hgthanka_test',
            hgperka: 'mongodb://localhost:' + testDBPort + '/hgperka_test',
            hgfinance: 'mongodb://localhost:' + testDBPort + '/hgfinance_test',
            hgperform: 'mongodb://localhost:' + testDBPort + '/hgperform_test',
            hgreports: 'mongodb://localhost:' + testDBPort + '/hgreports_test',
            hglog: 'mongodb://localhost:' + testDBPort + '/hglog_test',
            winstonlog: {
                host: 'localhost',
                port: testDBPort,
                db: 'hglog',
                collection: 'log'
            },
            replica: ''
        },
        baseUrl: '//localhost:8895/',
        esbUrl: '//localhost:8897/',
        ioUrl: 'http://localhost:3000/',
        protocol: 'http:',
        wwwSite: '/www/index.html',
        s3store: {
            provisionDirectory: '//hgdev1.s3.amazonaws.com/provision/',
            imageStore: '/img',
            cssImageStore: '',
            javascriptDirectory: '',
            cssDirectory: '',
            htmlTemplateDirectory: '//hgdev1.s3.amazonaws.com',
            uploadDirectory: params.path + '/static/img/',
            defaultAvatars: '',
            s3bucketJS: '',
            s3bucketCSS: '',
            s3bucketImg: '',
            s3bucket: ''
        },
        hg_api_host : 'localhost',
        giftcards_api_host: 'api.wrl.com',
        email: {
            Alert: 'qaerrors@highground.com',
            FromAddress: "devtest@highground.com",
            FromName: "Notification -- Local",
            BlackHole: 'blackhole@expresspigeon.com',
            BuildErrors: 'build@highground.com',
            Releases: "releases@highground.com",
            Billing: "billing@highground.com",
            Tango: 'tango@highground.com',
            Refund: 'devtest@highground.com',
            Operations: 'operations@highground.com'
        },
        HighgroundGlobalUserId: '5e42c56e-5b17-4070-817f-d924a5cd7462',
        APIGlobalUserId: 'db742790-41ca-11e5-b754-c9dc5f0e768c',
        authorizenet: {
            aim_host: 'apitest.authorize.net',
            aim_path: '/xml/v1/request.api',
            cim_host: 'apitest.authorize.net',
            cim_path: '/xml/v1/request.api'
        },
        RecapInterval: 60,
        RecapBatchSize: 1000,
        WeeklyRecapBatchSize : process.env.WEEKLYRECAPBATCHSIZE || 200,
        DispatchEmailInterval: process.env.DISPEMAILINT || 30,
        EmailPerDispatch: process.env.EMAILPERDISP || 600,
        memcached: {
            username: process.env.MEMCACHIER_USERNAME,
            password: process.env.MEMCACHIER_PASSWORD,
            servers: process.env.MEMCACHIER_SERVERS || 'localhost:11211',
            defaultLifetime: 86400 //24hrs
        },
        tango: {
            host: 'sandbox.tangocard.com',
            customer: 'HighGroundQA',
            account: 'Corporate'
        },
        device: {
            ios: {
                gateway: 'gateway.push.apple.com',
                feedback: 'feedback.push.apple.com',
                cert: params.path + '/deploy/certs/prd_cert.pem',
                key: params.path + '/deploy/certs/prd_key.pem',
                passphrase: 'h164gr0und!'
            },
            android: {
                AppId: '817058402545',
                APIKey: 'AIzaSyAmrgGaNH81GFt8_19QYx5eBWwreHWEMy8'
            }
        },
        onelogin: {
            certPath: 'deploy/certs/local_onelogin.pem',
            issuer: 'highground-saml',
            entryPoint: 'https://app.onelogin.com/trust/saml2/http-post/sso/389869'
        },
        GRS: {
            storefront: {
                host: 'highground.sandbox.grsstorefront.com',
                path: '/client/soap.php',
                wsdl: '/client/soap.php?wsdl',
                namespace: 'https://highground.sandbox.grsstorefront.com/client/'
            },
            giftcards: {
                host: 'admin-uat.grsportal.com',
                port: 1022,
                WSDL: 'https://api-uat.grsportal.com/partner/v3/wsdl/token/'
            }
        },
        Redis: {
            Connection: {
                host: '127.0.0.1',
                port: '6379',
                retry_strategy: RedisRetry
            }
        }
    };
};
