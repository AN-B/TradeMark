/*jslint node:true es5:true nomen:true*/
'use strict';
// store all environment configurations, including connection strings
// send in a params object to support future configs
var Config = require('../configurations/cf/' + (process.env.BUILD_ENV || 'local') + '-config.js')({
        path: __dirname.replace('/hgnode/configurations', '')
    }),
    primary = process.env.REPLICA_PRIMARY || 'a0',
    secondary = process.env.REPLICA_SECONDARY || 'a1',
    primaryB = process.env.REPLICA_PRIMARY_B || 'a0',
    secondaryB = process.env.REPLICA_SECONDARY_B || 'a1',
    databases = ['hgcommon', 'hgsecurity', 'hgthanka', 'hgperka', 'hgfinance', 'hgperform', 'hgreports', 'hglog'],
    RedisRetry = require('./RedisRetry'),

    envInvariants = {
        UnlockNotificationInterval: 1800,//second
        RecapInterval: 60,
        RecapBatchSize: 1000,
        WeeklyRecapBatchSize : process.env.WEEKLYRECAPBATCHSIZE || 200,
        DispatchEmailInterval: process.env.DISPEMAILINT || 30,
        EventBusInterval: process.env.EVENT_BUS_INTERVAL || 10,
        EmailPerDispatch: process.env.EMAILPERDISP || 600,
        HighgroundGlobalUserId: '5e42c56e-5b17-4070-817f-d924a5cd7462',
        APIGlobalUserId : 'db742790-41ca-11e5-b754-c9dc5f0e768c',
        yammer: {
            oauthhost: 'www.yammer.com',
            oauthpath: {
                authorization: '/dialog/oauth',
                accessToken: '/oauth2/access_token.json'
            }
        },
        linkedin: {
            oauthhost: 'www.linkedin.com',
            oauthpath: {
                authorization: '/uas/oauth2/authorization',
                accessToken: '/uas/oauth2/accessToken'
            },
            api: {
                host: 'api.linkedin.com',
                share: '/v1/people/~/shares'
            }
        },
        filepath: {
            ImageRoot: 'static/img/',
            UserProfile: 'user/',
            TeamProfile: 'team/',
            BadgeRoot: 'badges/original/',
            RecognitionTemplateRoot: 'badges/group/',
            FileUploadTmp: '/tmp/',
            AttachmentRoot: 'attachment/',
            GroupRoot: 'company/',
            Provision: 'provision/',
            Reports: 'reports/',
            Files: 'files/'
        },
        statusio: {
            host : 'api.statuspage.io',
            submitMetric : '/v1/pages/[page_id]/metrics/[metric_id]/data.json',
            componentUpdate :  '/v1/pages/[page_id]/components/[component_id].json'
        },
        hg_sftp: {
            host: 'us2.hostedftp.com',
            port: 22
        },
        exchangerate: {
            url: 'http://apilayer.net/api/live'
        },
        Redis: {
            Connection: {
                url: process.env.REDISCLOUD_URL,
                no_ready_check: true,
                retry_strategy: RedisRetry
            }
        }
    };
Object.keys(envInvariants).forEach(function (prop) {
    Config[prop] = Config[prop] || envInvariants[prop];
});

// set primary and secondary
databases.forEach(function (db) {
    if (Config.mongodb[db]) {
        Config.mongodb[db] = Config.mongodb[db].replace(/__primary__/g, primary).replace(/__secondary__/g, secondary);
        Config.mongodb[db] = Config.mongodb[db].replace(/__primaryB__/g, primaryB).replace(/__secondaryB__/g, secondaryB);
    }
});
if (Config.mongodb.winstonlog && Config.mongodb.winstonlog.host) {
    Config.mongodb.winstonlog.host = Config.mongodb.winstonlog.host.replace(/__primary__/g, primary).replace(/__secondary__/g, secondary);
    Config.mongodb.winstonlog.host = Config.mongodb.winstonlog.host.replace(/__primaryB__/g, primaryB).replace(/__secondaryB__/g, secondaryB);
}

// replace imagestore with array for CDN
if (Config.s3store.cdn) {
    Config.s3store.imageStore = Config.s3store.cdn;
    Config.s3store.javascriptDirectory = Config.s3store.cdn;
    Config.s3store.cssDirectory = Config.s3store.cdn;
    Config.s3store.cssImageStore = Config.s3store.cdn;
    Config.cdnCount = Config.s3store.cdn.length;
} else {
    Config.s3store.imageStore = [Config.s3store.imageStore];
    Config.s3store.javascriptDirectory = [Config.s3store.javascriptDirectory];
    Config.s3store.cssDirectory = [Config.s3store.cssDirectory];
    Config.cdnCount = 1;
}

// add function to get next index for round robin
Config.nextIndex = function () {
    return Date.now() % Config.cdnCount;
};

module.exports = Config;
