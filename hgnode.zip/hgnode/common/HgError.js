/*jslint node:true es5:true*/
"use strict";
var ErrorEnums = {
    Generic: {
        CacheError: 'Error saving item to cache.',
        NotImplemented: 'Not Implemented.',
        Error: 'Internal Error.',
        WatchYourLanguage: 'services.int.user.wyl'
    },
    Petition: {
        DuplicatePetition: 'There is already a petition for this entity of the same type'
    },
    Attachment: {
        ErrorLoadingAttachments: 'Error loading attachments.',
        ErrorSavingAttachment: 'Error saving attachment.',
        ErrorUpdatingAttachment: 'Error updating attachment.'
    },
    Badge: {
        ErrorLoadingBadge: 'Error loading badges.',
        ErrorSavingBadge: 'Error saving badge.',
        ErrorUpdatingBadge: 'Error updating badge.'
    },
    CareerTrack: {
        ErrorLoadingCareerTrack: 'Error loading track.',
        ErrorLoadingCareerTracks: 'Error loading tracks',
        ErrorUpdatingTrackMilestone: 'Error updating track milestone.',
        TracksMilestoneIdInvalid: 'Invalid tracks milestone id.',
        NoTracksFoundWithRecognitionId: 'No tracks match the recognition id.',
        ErrorSavingCareerTrack: 'Error saving track template.',
        ErrorDeleteTrack: 'Error deleting track.',
        ErrorSelfAssignWithCredits: "Tracks with credit value can't be saved when self-assigned.",
        ErrorTitleNeeded: "Objective and milestones titles are required.",
        InsufficientFundsToApprove: 'Insufficient funds to approve track.',
        NoRecipientMembers : 'There is no recipient members selected for this track. Possibly because there is no active member in the team that you selected'
    },
    CareerTrackTemplate: {
        ErrorSavingCareerTrackTemplate: 'Error saving track template.',
        ErrorUpdatingCareerTrackTemplate: 'Error updating track template.',
        ErrorLoadingCareerTrackTemplates: 'Error loading track templates.'
    },
    Credit: {
        ErrorLoading: 'Error loading credit account.',
        InsufficientFundsToRedeem: 'services.int.reg.err.ifg',
        InsufficientFundsToTransferCredits: 'Insufficient funds to transfer credits.',
        InsufficientFundsForRecognition: 'services.int.reg.err.ifr',
        InsufficientFundsAddPoints: 'Insufficient funds to add points.',
        TransferAmountOutOfLimit: 'The amount you try to transfer out of the limit of the group.',
        NegativeCreditTransfer: 'Negative credit value is not allowed in transfer account.'
    },
    CreditAccount: {
        ErrorLoadingPackTemplate: 'Error loading pack template.',
        ErrorEarmarking: 'Error while earmarking.',
        ErrorDistributingCredit: 'Error while distributing credits.',
        ErrorLoadingCreditAccount: 'Error loading credit account.',
        ErrorLoadingSPNDCreditAccount: 'Error loading Spend credit account.',
        ErrorLoadingTRFRCreditAccount: 'Error loading Give credit account.',
        ErrorUpdatingCreditAccount: 'Error updating credit account.',
        ErrorTransferringFundsBetweenAccounts: 'Error transferring funds between accounts.',
        SourceAccountNotFound: 'Source account was not found.',
        DestinationAccountNotFound: 'Destination account was not found.',
        InsufficientFunds: 'Insufficient funds.'
    },
    Comment: {
        ErrorLoadingComment: 'Error loading comment.',
        ErrorSavingComment: 'Error saving comment.',
        EmptyEntityId: 'Empty EntityId.'
    },
    Giftcard: {
        ErrorLoadingGiftcard: 'Error loading gift card.',
        ErrorSavingingGiftcard: 'Error saving` gift card.',
        ErrorSavingingGiftcardOrderRequest: 'Error saving gift card order request.',
        ErrorUpdatingGiftcard: 'Error updating gift card.'
    },
    User: {
        PasswordInvalid : 'The password is invalid.',
        MemberIsNotActive : 'Sorry, but the user may have been offboarded from the company',
        NotInGroup: 'You are not a member of this group.',
        VerifyLogin: 'Login failed. Please verify your username and password.',
        PasswordNoMatch: 'Current password is incorrect.',
        PasswordShouldBeDifferent: 'services.int.user.npdc',
        ErrorLoadingMemberByUserId: 'Error loading member by user id.',
        ErrorLoadingUserSecurityWithToken: 'Error loading UserSecurityWithToken.',
        ErrorLoadingUserById: 'Error loading user by id.',
        ErrorUpdatingUserInfo: 'Updating UserInfo failed.',
        //Below Enum is used by mobile and can't be removed
        InvalidUserToken: 'InvalidUserToken',
        UserLockedOut: 'services.int.user.eml',
        MissingParamterForUserNameVerification: 'Missing parameter for UserName check.',
        ErrorSavingGravatar: 'Error while saving Gravatar image.',
        ErrorGettingGravatar: 'Error while downloading Gravatar image.'
    },
    Goal: {
        ErrorLoading: 'Error loading the goal.',
        ErrorUpdating: 'Error updating the goal.',
        ErrorDeleting: 'Error deleting the goal.',
        ErrorInserting: 'Error adding the goal.'
    },
    Group: {
        ErrorSavingGroup: 'Error creating the group.',
        ErrorSavingMember: 'Error creating the member.',
        ErrorUpdatingGroup: 'Error updating the group.',
        MemberDoesNotExist: 'The member does not exist.',
        ErrorSettingUpMemberRoles: 'Error setting up member roles.',
        ErrorChangeMemberStatus: 'Error changing member status.',
        MemberNotInGroup: 'The member is not in the group.',
        MemberDoesNotQualify: 'The member can not be selected as the credit master of the group.',
        SetCreditMasterMember: 'Please select a member for the credits administrator.',
        ErrorSavingPointMaster: 'Error saving Point master member.',
        ErrorSavingCreditMaster: 'Error saving credit master member.',
        ErrorSavingMemberInfo: 'Error while saving member information.'
    },
    Provision: {
        ErrorLoading: 'Error loading batches.',
        ErrorGeneratingGuids: 'Error while generating GUIDs. Number of request should be in the range of 1 to 100.'
    },
    Recognition: {
        ErrorLoading: 'Error loading recognitions.',
        ErrorLoadingCount: 'Error loading the recognition count.',
        ErrorCreatingRecognitions: 'Error creating the recognitions.',
        RecognitionDoesNotExist: 'Recognition does not exist.',
        ErrorDeletingRecognition: 'Error deleting recognition.',
        ErrorGeneratingCertificate: 'Error while generating recognition certificate.',
        ErrorCreatingAutoRecognition: 'Error while creating auto-recognition.',
        ErrorUpdatingRecognition: 'Error while updating recognition.',
        NotAuthorizedToView: 'You are not authorized to view this recognition.',
        ErrorHidingRecognitions: 'Error while hiding the selected recognition(s).'
    },
    RecognitionTemplate: {
        ErrorLoadingMember: 'Error loading the member.',
        MemberDoesNotExist: 'The requested member does not exist.',
        ErrorLoadingTemplates: 'Error loading templates.',
        ErrorUpdating: 'Error updating template.'
    },
    Report: {
        ErrorComputingDataAggregation: 'Error computing data aggregation.'
    },
    Member : {
        MemberDoesNotExist: 'The member does not exist.',
        ErrorUpdatingMember : 'Error Updating Member'
    },
    News : {
        ErrorSaving : 'Error saving news.',
        ErrorLoading : 'Error loading news.',
        InactiveMembership : 'Member needs to be active to view group news.',
        StatusError : 'News should be tentative status for this operation.',
        TypeError : 'New type error!'
    },
    NotificationPreference: {
        ErrorLoading: 'Error loading notification preference.'
    },
    Notification: {
        ErrorLoading: 'Error loading notifications.',
        ErrorUpdating: 'Error updating notifications.',
        ErrorCreating: 'Error creating notifications.'
    },
    Payment: {
        PaymentMethodNotAllowed: 'The customer or current user is not allowed to use this payment method.',
        ExceededCreditLimit: 'The customer has exceeded the credit limit.',
        ParameterMissingHgId: 'hgId parameter is missing.',
        PaymentProfileIdParameterMissing: 'PaymentProfileId parameter is missing.',
        AmountGreaterThanZero: 'Amount parameter must be greater than $0.00.',
        ErrorParsingXMLResponse: 'Error parsing XML response from Authorize.NET.',
        HttpRequestError: 'Error sending HTTP request to Authorize.NET.',
        ErrorUpdatingUserInfoWithNewCustomerProfile: 'Error updating user information with new customer profile.',
        OnlyAccessYourOwnProfiles: 'You may only access your own payment profiles.',
        TransactParametersMissing: 'Missing one or more parameters for Transact: PaymentProfileId, Amount, or ClientIPAddress.',
        TransactionFailedGenericMessage: 'Transaction failed, please verify your payment profile information. If this is a duplicate purchase using the same payment profile for the same amount, please wait at least 5 minutes before resubmitting.'
    },
    Points: {
        InsufficientPointsToGive: 'You do not have enough Points to Give to complete that action.',
        InsufficientPointsForRecognition: 'services.int.reg.err.ipr'
    },
    Worker: {
        SendMemberDailyRecapFailed : 'Failed to send member daily recap.',
        ClearScheduleEventFailed: 'Failed to clear schedule events.'
    },
    Transaction: {
        MissingParameterForTransaction: 'Missing parameter for transaction.',
        NotAuthorized: 'Insufficient authorization to access this method.',
        InvalidStatusToUpdate: 'Only transactions in a \'PendingAvailable\' state can be completed or failed.',
        ErrorSaving: 'Error saving transaction.'
    },
    Tag : {
        ErrorSavingTag : 'Error Saving Tag'
    },
    Invoice: {
        ErrorCreatingFee: 'Error creating fee.',
        ErrorDeletingFee: 'Error deleting fee.',
        ErrorFindingFees: 'Error finding fees.',
        ErrorCreatingInvoices: 'Error creating invoices.',
        ErrorFindingInvoices: 'Error finding invoices',
        ErrorUpdatingInvoice: 'Error updating invoice.'
    },
    WRL: {
        NoPackages: 'No card packages were found, please define a card package before ordering gift cards.',
        OrderError: 'Error creating new card order.',
        API2001: 'Invalid login. Invalid username/password combination sent to the api_users/auth API.',
        API2002: 'Invalid token. Supplied token is invalid. The token may either be non-existent or expired.',
        API3001: 'Invalid version. The API version the request was directed to does not exist.',
        API3002: 'Invalid action. The requested API action is unrecognized.',
        API3003: 'Invalid request. This response is received if no input parameters are specified.',
        API5001: 'Internal error. An error occurred within the WRL system or a third party system that was contacted to retrieve additional information to fulfill your request.'
    },
    Team: {
        ErrorLoadingTeams: 'Error while loading teams.',
        EmptyTeam: 'There are no members in this department.'
    },
    Perform: {
        SetMeetingDate: 'Error setting meeting date.',
        SetReleaseDate: 'Error setting release date.',
        OutstandingReviewsClosed: 'The outstanding reviews are closed.',
        ErrorLoadingReviews: 'Error while loading reviews',
        ErrorLoadingCycle: 'Error while loading cycle.',
        ErrorLoadingReview: 'Error while loading this review. This review could have been deleted. Please contact your HR Administrator.',
        NoPermissionForReview: 'You do not have permission to see this review.',
        CardNonExistent: 'The card you tried to update does not exist.',
        CantEditTemplate: 'This is a template card and cannot be edited.',
        ErrorLoadingCard: 'Error while loading card.',
        ErrorLoadingSubject: 'Error while loading subject matter.',
        ErrorLoadingManager: 'Error while loading manager member.',
        ErrorPDFGeneration: 'Error while generating PDF.',
        InvalidRecurrenceEntityType : 'Invalid Recurrence Entity Type',
        DuplicateMembersInCard: 'You cannot have duplicate members on the review.',
        NoMemberId: 'Please make sure all the reviewer fields have a member selected.'

    },
    SSO: {
        OAuthFailed: 'There was a problem authenticating your request.'
    }
};

module.exports.Enums = ErrorEnums;
