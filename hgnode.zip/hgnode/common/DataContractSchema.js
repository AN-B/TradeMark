//this is the base class that all other services will inherit from
/*jslint node:true es5:true nomen:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    mongodb = require('mongodb'),
    DataContractSchema = function (props) {
        var baseSchema;
        if (!props.hgId) {
            props.hgId = {type: String};
        }
        baseSchema = new Schema(props, {_id: false, versionKey: false });
        baseSchema.index({ hgId: 1}, {unique: false});
        return baseSchema;
    };
module.exports = DataContractSchema;