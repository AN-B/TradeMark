//this is the base class that all other services will inherit from
/*jslint node:true es5:true nomen:true*/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    env = process.env.BUILD_ENV || 'local',
    QUERY_THRESHOLD = 500,
    WATCH_DB_INTERNALS = ['local', 'test'].indexOf(env) > -1 && process.env.LOCAL_DEBUG,
    HgLog = require('../framework/HgLog.js'),
    MAXLENGTH = process.env.SCHEMA_TEXT_MAXLENGTH || 16000,
    addMaxLength = function (props, key) {
        if (props[key] && props[key].type === String && !props[key].maxlength) {
            props[key].maxlength = [MAXLENGTH, 'The value of path `{PATH}` (exceeds the maximum allowed length ({MAXLENGTH}).'];
        }
    },
    injectMaxLengthType = function (props) {
        var x,
            i,
            j,
            ilen,
            jlen,
            xPropKey,
            xprop,
            xlen = Object.keys(props).length;
        for (x = 0; x < xlen; x += 1) {
            xPropKey = Object.keys(props)[x];
            xprop = props[xPropKey];
            if (Array.isArray(xprop)) {
                ilen = xprop.length;
                for (i = 0; i < ilen; i += 1) {
                    jlen = Object.keys(xprop[i]).length;
                    for (j = 0; j < jlen;  j += 1) {
                        addMaxLength(xprop[i], Object.keys(xprop[i])[j]);
                    }
                }
            } else if (xprop && !xprop.type) {
                injectMaxLengthType(xprop);
            } else {
                addMaxLength(props, Object.keys(props)[x]);
            }
        }
    },
    HGSchema = function (props) {
        props.hgId = {type: String, default: ''};
        props.CreatedBy = {type: String, default: ''};
        props.CreatedDate = {type: Number, default: Date.now};
        props.ModifiedBy = {type: String, default: ''};
        props.ModifiedDate = {type: Number, default: Date.now};
        injectMaxLengthType(props);
        var baseSchema = new Schema(props, {_id: true, autoIndex: false });
        function logUpdate(type, object) {
            if (WATCH_DB_INTERNALS) {
                HgLog.debug(type + ' collection: ' + object.mongooseCollection.name, {
                    query: JSON.stringify(object._conditions),
                    update: JSON.stringify(object._update)
                });
            }
        }
        function logQuery(type, object) {
            var millis = Date.now() - object.start;
            if (millis > QUERY_THRESHOLD) {
                HgLog.debug(type + ' collection: ' + object.mongooseCollection.name, {
                    query: JSON.stringify(object._conditions),
                    time: 'Query took ' + millis + ' millis'
                });
            }
        }
        baseSchema.index({hgId: 1}, {unique: false});
        baseSchema.set('toJSON', { virtuals: true });
        baseSchema.pre('save', function (next) {
            var self = this;
            self.validate(function (error) {
                if (error) {
                    return next(error);
                }
                var now = Date.now();
                if (self.isNew) {
                    self._doc._id = new mongoose.Types.ObjectId();
                    self._doc.CreatedDate = self._doc.CreatedDate || now;
                    self._doc.ModifiedDate = self._doc.ModifiedDate || now;
                    self._doc.ModifiedBy = self._doc.ModifiedBy || self._doc.CreatedBy;
                } else {
                    if (self.ModifiedDate) {
                        self.ModifiedDate = now;
                    }
                }
                next();
            });
        });
        baseSchema.pre('findOneAndUpdate', function (next) {
            this.options.runValidators = true;
            if (this.mongooseCollection.name !== 'Recognition') {
                this.update({}, {$set: {ModifiedDate: Date.now()}});
            }
            logUpdate('findOneAndUpdate', this);
            next();
        });
        baseSchema.pre('update', function (next) {
            this.options.runValidators = true;
            if (this.mongooseCollection.name !== 'Recognition') {
                this.update({}, { $set: {ModifiedDate: Date.now()}});
            }
            logUpdate('update', this);
            next();
        });
        baseSchema.post('update', function (data) {
            //With upgrade to MongoDB Driver 2.0, update methods now return
            //raw mongodb server result instead of the number of records affected
            //For backward compability I am changing the result format
            data.result = data.result.n;
        });
        if (WATCH_DB_INTERNALS) {
            baseSchema.pre('count', function () {
                this.start = Date.now();
            });
            baseSchema.post('count', function () {
                logQuery('count', this);
            });
            baseSchema.pre('findOne', function () {
                this.start = Date.now();
            });
            baseSchema.post('findOne', function () {
                logQuery('findOne', this);
            });
            baseSchema.pre('find', function () {
                this.start = Date.now();
            });
            baseSchema.post('find', function () {
                logQuery('find', this);
            });
        }
        return baseSchema;
    };
module.exports = HGSchema;
