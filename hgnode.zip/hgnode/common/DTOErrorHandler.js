/*jslint node:true es5:true*/
'use strict';
var i18nHelper = require('../helpers/i18nHelper.js');

function error(params, callback) {
    var errors = [];
    if (!params.validationErrors || !params.validationErrors.errors) {
        return callback();
    }
    if (params.validationErrors.name !== 'ValidationError') {
        return callback(params.validationErrors);
    }
    Object.keys(params.validationErrors.errors).forEach(function (field) {
        var prop = params.validationErrors.errors[field].properties;
        errors.push(i18nHelper.translate(params.Lang, 'validation.msg.' + prop.type, prop));
    });
    return callback(errors.join(','));
}
module.exports = {
    error: error
};
