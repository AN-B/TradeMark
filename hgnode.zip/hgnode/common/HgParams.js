/*jslint node:true es5:true*/
'use strict';
var HgParams = function (correlationId, payload, EventName) {
    this.correlationId = '';
    this.payload = null;
    this.EventName = '';

    if (correlationId !== undefined && EventName !== undefined) {
        this.correlationId = correlationId;
        this.payload = payload;
        this.EventName = EventName;
    } else {
        throw 'No correlationId passed in for HgParams';
    }
};

module.exports = HgParams;