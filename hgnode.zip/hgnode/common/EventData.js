/*jslint node:true es5:true*/
'use strict';
var EventData = function (correlationId, payload, errorMessage) {
    this.correlationId = '';
    this.payload = null;
    this.errorMessage = errorMessage;

    if (correlationId !== undefined && payload !== undefined) {
        this.correlationId = correlationId;
        this.payload = payload;
    } else {
        throw new Error('The correlationId or payload was not passed in to the EventData constructor. If there is no payload (like in the case of an error) use null.');
    }
};

module.exports = EventData;