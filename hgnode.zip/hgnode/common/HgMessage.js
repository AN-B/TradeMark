/*jslint node:true es5:true*/
"use strict";
var MessageEnums = {
    User: {
        ProfileSaved: 'Profile information saved.',
        ProfilePasswordSaved: 'Profile information saved and password has been changed.'
    },
    Congrat : {
        SuccessDeleted: 'Congrats was deleted.'
    },
    Comment : {
        SuccessDeleted: 'Comment was deleted.'
    },
    Recognition: {
        SuccessDeleted: 'rec.del',
        SuccessHidden: 'Recognition is now hidden from the feed.',
        SuccessUnstick: 'Recognition is now dismissed from the top.',
        RecognitionNotFound: 'The recognition you are trying to access has been deleted or your permission to view it has been revoked.'
    },
    Performance: {
        UpdatedCycleCompleted: 'Updated cycle percentage completed.',
        ReviewArchived: 'This review has been archived.',
        OverdueReviewsUpdated: 'OverDue reviews have been updated.',
        CardArchived: 'The card has been archived.',
        CycleReviewsArchived: "All review(s) deleted.",
        CycleReviewsClosed: "All review(s) closed."
    },
    Tutorial: {
        SuccessAllTutorialsReset: 'All tutorials have been successfully reset for all members.',
        SuccessMemberTutorialsReset: 'Selected tutorials have been successfully reset for the selected member.',
        SuccessCurrentMemberTutorialsReset: 'All tutorials have been successfully reset.'
    }
};

module.exports.Enums = MessageEnums;