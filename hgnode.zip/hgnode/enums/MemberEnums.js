/*jslint node:true es5:true*/
'use strict';
var paramUtil = require('../util/params.js'),
    MemberEnums = {

        Status: {
            Active: 0,
            InActive: 0,
            PendingAdminApprove: 0,
            PendUserAccept: 0,
            Denied: 0,
            Suspended: 0,
            OffBoarded: 0,
            UserReject: 0
        },

        MemberPermission: {
            OffBoarded: {
                Description: 'Permissions specific to off-boarded users.',
                SecuredTabs: {
                    companyTabs:    [],
                    recognizeTabs:  [],
                    teamTabs:       [],
                    profileTabs:    [],
                    trackTabs:      [],
                    motivateTabs:   ['giftCards', 'charities'],
                    userTabs:       ['account', 'notificationEmail'],
                    adminTabs:      [],
                    provisionTabs:  []
                }
            },
            Consultant: {
                Description: 'Consultant',
                SecuredTabs: {
                    companyTabs:    ['company'],
                    recognizeTabs:  [],
                    teamTabs:       [],
                    profileTabs:    ['profile'],
                    trackTabs:      ['summary'],
                    motivateTabs:   [],
                    userTabs:       ['account', 'recognizeMeLinks', 'notifications', 'preferences', 'notificationEmail'],
                    adminTabs:      [],
                    provisionTabs:  []
                }
            },
            Basic: {
                Description: 'Basic permission available to all members - is not typically suppressed.',
                SecuredTabs: {
                    companyTabs:    ['company'],
                    recognizeTabs:  [],
                    teamTabs:       [],
                    profileTabs:    ['profile'],
                    trackTabs:      ['summary'],
                    motivateTabs:   ['giftCards', 'charities'],
                    userTabs:       ['account', 'recognizeMeLinks', 'notifications', 'preferences', 'notificationEmail'],
                    adminTabs:      [],
                    provisionTabs:  [],
                    surveyTabs:     []
                }
            },
            AllImportantNotifications: {
                Description: 'Access to see all important notification screen',
                SecuredTabs: {
                    userTabs:  ['allImportantNotifications']
                }
            },
            GiveRecognition: {
                Description: 'Refers to the Recognize > Give Recognition functionality.',
                SecuredTabs: {
                    recognizeTabs:  ['giveRecognition']
                }
            },
            SendCreditsInRecognition: {
                Description: "Refers to the 'Add Credits' option when giving a recognition.",
                SecuredTabs: {
                    recognizeTabs: ['sendCredits']
                }
            },
            SendPointsInRecognition: {
                Description: 'Refers to the \'Add Points\' option when giving a recognition.',
                SecuredTabs: {
                    recognizeTabs: ['sendPoints']
                }
            },
            AddPointsInRecognition: {
                Description: 'Refers to the \'Add Points\' option for given recognition in the feed.',
                SecuredTabs: {
                    recognizeTabs: ['addPoints']
                }
            },
            ShowPointsInPublicFeed: {
                Description: 'Refers to the public display of points a user received in a recognition on the feed.',
                SecuredTabs: {
                    recognizeTabs: ['showPointsInFeed']
                }
            },
            ShareLink: {
                Description: "Refers to the 'Share' button on recognitions in the feed.",
                SecuredTabs: {
                    recognizeTabs: ['shareLink']
                }
            },
            HideRecognition: {
                Description: 'Refers to the Hide Recognition option within the More dropdown in the feed.',
                SecuredTabs: {
                    recognizeTabs: ['hideRecognition']
                }
            },
            EnableLanguages: {
                Description: 'Refers to the Language tab.',
                SecuredTabs: {
                    adminTabs: ['enableLanguages']
                }
            },
            DeleteRecognition: {
                Description: 'Refers to the Delete Recognition option within the More dropdown in the feed.',
                SecuredTabs: {
                    recognizeTabs: ['deleteFeedEntry']
                }
            },
            CreateTrack: {
                Description: 'Refers to the Tracks > Create Track tab.',
                SecuredTabs: {
                    trackTabs: ['goalTracks']
                }
            },
            AssignTrack: {
                Description: "Refers to the 'Assign Track' subtab under Track Library.",
                SecuredTabs: {
                    trackTabs: ['assignTracks']
                }
            },
            CreateTrackMoreOptions: {
                Description: "Refers to the 'More Options' button in Create Track.",
                SecuredTabs: {
                    trackTabs: ['moreOptions']
                }
            },
            CreateTrackAddCredits: {
                Description: "Ability to Add Credits in Create Track.",
                SecuredTabs: {
                    trackTabs:  ['addCredits']
                }
            },
            CreateTrackAddPoints: {
                Description: "Ability to Add Points in Create Track.",
                SecuredTabs: {
                    trackTabs: ['addPoints']
                }
            },
            TrackLibrary: {
                Description: "Access to Track Library tab and all its subtabs.",
                SecuredTabs: {
                    trackTabs: ['manageTracks']
                }
            },
            DeleteTrack: {
                Description: 'Refers to the Delete Track option within the Actions dropdown.',
                SecuredTabs: {
                    trackTabs: ['deleteTracks']
                }
            },
            PointStore: {
                Description: 'Access to Points Store in Motivate > Store.',
                SecuredTabs: {
                    motivateTabs:  ['pointStore']
                }
            },
            PerformDeliverCycle: {
                Description: 'Ability to deliver cycle, but not to edit or create cards.',
                SecuredTabs: {
                    adminTabs: ['cardLibrary', 'cycleSubTab']
                }
            },
            PerformCardLibrary: {
                Description: 'Access to Perform Card Library and manage them.',
                SecuredTabs: {
                    adminTabs: ['cardLibrary']
                }
            },
            PerformCycle: {
                Description: 'Access perform cycles created by the member.',
                SecuredTabs: {
                    adminTabs: ['cycleSubTab', 'recurringCycle']
                }
            },
            ProfilePerform: {
                Description: 'Access Perform Profile.',
                SecuredTabs: {
                    profileTabs: ['perform']
                }
            },
            ProfileCoaching: {
                Description: 'Refers to the Coaching tab in the feed.',
                SecuredTabs: {
                    profileTabs: ['coaching']
                }
            },
            ProfileFeedback: {
                Description: 'Refers to the Feedback tab in the feed.',
                SecuredTabs: {
                    profileTabs: ['feedback']
                }
            },
            SeeAllCycles: {
                Description: 'Refers to ability to see all cycles including those created by others.',
                SecuredTabs: {
                    profileTabs: ['seeAllCycles']
                }
            },
            ApproveGoal: {
                Description: 'Be able to goals even if you are not the approver',
                SecuredTabs: {}
            },
            ExportGroupData: {
                Description: 'Export data of any groups.',
                SecuredTabs: {}
            },
            AnswerLibrary: {
                Description: 'Refers to the Answer Library.',
                SecuredTabs: {
                    profileTabs: ['answerLibrary']
                }
            },
            ManageTemplatePerformCard: {
                Description: 'Refers to the Card Library.',
                SecuredTabs: {
                }
            },
            MemberCredit: {
                Description: "Refers to User > Account > Credits.",
                SecuredTabs: {
                    userTabs: ['credits']
                }
            },
            MemberPoint: {
                Description: "Refers to User > Account > Points.",
                SecuredTabs: {
                    userTabs: ['points']
                }
            },
            TransferCredits: {
                Description: "Refers to the 'Transfer Credits' subtab under User > Account > Credits.",
                SecuredTabs: {
                    userTabs: ['transferCredits']
                }
            },
            TransferPoints: {
                Description: 'Be able to transfer points.',
                SecuredTabs: {
                    adminTabs: ['transferPoints']
                }
            },
            PurchaseCredits: {
                Description: "Refers to the 'Purchase Credits' subtab under User > Account > Credits.",
                SecuredTabs: {
                    userTabs: ['purchaseCredits']
                }
            },
            CreditTransactions: {
                Description: "Refers to the 'Transactions' subtab under User > Account > Credits.",
                SecuredTabs: {
                    userTabs: ['creditTransactions']
                }
            },
            AdhocTeam: {
                Description: "Access to AdhocTeam feature",
                SecuredTabs: {}
            },
            TeamManagement: {
                Description: "Refers to the User > Account > Teams tab and all its subtabs.",
                SecuredTabs: {
                    userTabs: ['teams']
                }
            },
            TeamAdmin: {
                Description: "Refers to the ability to manage all teams.",
                SecuredTabs: {
                    adminTabs: ['teams']
                }
            },
            PaymentProfile: {
                Description: "Refers to the 'Payment Info subtab under User > Account.",
                SecuredTabs: {
                    userTabs: ['paymentInfo']
                }
            },
            GroupRecognitionsManagement : {
                Description: 'Refers to the Admin > Recognitions tab and all its subtabs.',
                SecuredTabs: {
                    adminTabs: ['recognitions']
                }
            },
            GroupSettingManagement : {
                Description: 'Refers to the Admin > Settings tab and all its subtabs.',
                SecuredTabs: {
                    adminTabs: ['settings']
                }
            },
            GroupCreditManagement : {
                Description: 'Refers to the Admin > Credits tab and all its subtabs.',
                SecuredTabs: {
                    adminTabs: ['credits']
                }
            },
            GroupMemberManagement : {
                Description: 'Refers to the Admin > Members tab and all its subtabs.',
                SecuredTabs: {
                    adminTabs: ['members']
                }
            },
            GroupMemberEdit : {
                Description: 'Refers to the Admin > Members > Edit Member subtab.',
                SecuredTabs: {
                    adminTabs: ['editProfile']
                }
            },
            GroupMemberTransferManager : {
                Description: 'Refers to the Admin > Members > Transfer Manager subtab.',
                SecuredTabs: {
                    adminTabs: ['transferManager']
                }
            },
            GroupMemberExport : {
                Description: 'Refers to the Adimin > Members > Export Members subtab.',
                SecuredTabs: {
                    adminTabs: ['exportMembers']
                }
            },
            ProvisionSystem : {
                Description: 'For the HGAdmin role - refers to the Provision > System tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionSystem']
                }
            },
            ProvisionUpload: {
                Description: 'For the HGAdmin role - refers to the Provision > Upload tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionUpload']
                }
            },
            ProvisionCompany: {
                Description: 'For the HGAdmin role - refers to the Provision > Company tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionCompany']
                }
            },
            ProvisionTemplates: {
                Description: 'For the HGAdmin role - refers to the Provision > Templates tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionTemplates']
                }
            },
            ProvisionDemo: {
                Description: 'For the HGAdmin role - refers to the Provision > Demo tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionDemo']
                }
            },
            ProvisionBilling: {
                Description: 'For the HGAdmin role - refers to the Provision > Billing tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionBilling']
                }
            },
            ProvisionMetrics: {
                Description: 'For the HGAdmin role - refers to the Provision > Metrics tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionMetrics']
                }
            },
            ProvisionTutorials: {
                Description: 'For the HGAdmin role - refers to the Provision > Tutorials tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionTutorials']
                }
            },
            GroupTerminologyManagement: {
                Description: 'To manage the custom group terminology.',
                SecuredTabs: {
                    provisionTabs: ['provisionTerminology']
                }
            },
            AdminReports: {
                Description: 'Refers to the Admin > Reports tab.',
                SecuredTabs: {
                    adminTabs: ['reports']
                }
            },
            HGAdminReports : {
                Description : 'Cross-group reports.',
                SecuredTabs : {}
            },
            CustomizedRecognition: {
                Description: "Refers to the 'Create a Custom Badge' option within Recognize > Everyday Recognition for Recognition 2.0.",
                SecuredTabs: {
                    recognizeTabs: ['customizedRecognition']
                }
            },
            EverydayRecognition: {
                Description: 'Refers to the Everyday tab when giving a recognition in Recognition 2.0.',
                SecuredTabs: {
                    recognizeTabs: ['everydayRecognition']
                }
            },
            ValuesRecognition: {
                Description: 'Refers to the Values tab when giving a recognition in Recognition 2.0.',
                SecuredTabs: {
                    recognizeTabs: ['valuesRecognition']
                }
            },
            AchievementRecognition: {
                Description: 'Refers to the Achievements tab when giving a recognition in Recognition 2.0.',
                SecuredTabs: {
                    recognizeTabs: ['achievementRecognition']
                }
            },
            ImpersonateGlobal: {
                Description: 'Impersonate another member in any group. This should be available only to HGAdmins.',
                SecuredTabs: {}
            },
            DeleteComment: {
                Description: "Refers to ability to delete other people's comments.",
                SecuredTabs: {}
            },
            AllowAvatarUpload: {
                Description: 'Refers to ability of member to upload an avatar of himself/herself',
                SecuredTabs: {}
            },
            AllowProfileInfoEditing: {
                Description: 'Allows a user to edit their account profile info',
                SecuredTabs: {}
            },
            ProvisionAssets: {
                Description: 'For the HGAdmin role - refers to the Provision > Assets tab and all its subtabs.',
                SecuredTabs: {
                    provisionTabs: ['provisionAssets']
                }
            },
            GivePointGift: {
                Description: 'Refers to ability to order Point Product Items as a gift for others.',
                SecuredTabs: {
                    motivateTabs:   ['givePointGift']
                }
            },
            ManagePointEconomy: {
                Description: 'Refers to ability to view the economy of the group.',
                SecuredTabs: {}
            },
            ManageProductItem: {
                Description: 'Be able to manage product items.',
                SecuredTabs: {
                    adminTabs: ['points']
                }
            },
            ManageProductOrder: {
                Description: 'Be able to manage product orders.',
                SecuredTabs: {}
            },
            YammerIntegration: {
                Description: '',
                SecuredTabs: {
                    adminTabs: ['yammerIntegration']
                }
            },
            TeamTabManagement: {
                Description: 'Allows Admin to set Manager Alert Days Interval.',
                SecuredTabs: {
                    adminTabs: ['teamTabManagement']
                }
            },
            SwitchEnvironment: {
                Description: 'Be able to switch environments in mobile app.',
                SecuredTabs: {}
            },
            SwitchEnvironmentQA: {
                Description: 'Be able to switch environments in mobile app as a QA.',
                SecuredTabs: {}
            },
            SwitchEnvironmentSales: {
                Description: 'Be able to switch environments in mobile app as a sales.',
                SecuredTabs: {}
            },
            SwitchEnvironmentHG: {
                Description: 'Be able to switch environments in mobile app as an HGAdmin.',
                SecuredTabs: {}
            },
            Goal: {
                Description: 'Access to goal feature.',
                SecuredTabs: {
                    profileTabs: ['goalCycle']
                }
            },
            ManageGoalCycle: {
                Description: 'Be able to manage goal cycles.',
                SecuredTabs: {
                    adminTabs: ['goalCycle']
                }
            },
            RecurringGoalCycle: {
                Description: 'Be able to set up recurring goal cycles.',
                SecuredTabs: {}
            },
            ManageGoalLibrary: {
                Description: 'Manage goal Library and assign goals to cycles and users.',
                SecuredTabs: {}
            },
            OpenClosedGoal: {
                Description: 'Allow user to reopen closed goal.',
                SecuredTabs: {}
            },
            UploadGoalCycleParticipants: {
                Description: 'Be able to add/remove goal participants by uploading CSV files.',
                SecuredTabs: {}
            },
            GoalWeighting: {
                Description: 'Admin can set up goal cycles that allow goal weighting.',
                SecuredTabs: {}
            },
            SkipGoalApproval: {
                Description: 'Admin can set up goal cycles that approval for setting/closing is skipped',
                SecuredTabs: {}
            },
            PerformGoal: {
                Description: 'Create goal type questions in perform card.',
                SecuredTabs: {}
            },
            NumericPercentageTarget: {
                Description: 'Create percentage type target for numeric goal key result.',
                SecuredTabs: {}
            },
            SelectRecapTime: {
                Description: 'Select the time when weekly/daily recap emails are sent',
                SecuredTabs: {}
            },
            AdhocGoal: {
                Description: 'Be able to access Adhoc goals.',
                SecuredTabs: {}
            },
            BenchmarkSurvey: {
                Description: 'Be able to see and participate benchmark surveys.',
                SecuredTabs: {
                    userTabs: ['userBenchmarkSurvey']
                }
            },
            ManageBenchmarkSurvey: {
                Description: 'Be able to manage benchmark surveys, such as templates & results.',
                SecuredTabs: {
                    adminTabs: ['benchmarkSurveys']
                }
            },
            PulseSurvey: {
                Description: 'Be able to see and participate pulse surveys.',
                SecuredTabs: {
                    userTabs: ['userPulseSurvey'],
                    surveyTabs: ['survey']
                }
            },
            ManagePulseSurvey: {
                Description: 'Be able to manage pulse surveys, such as templates & results.',
                SecuredTabs: {
                    adminTabs: ['pulseSurveys']
                }
            },
            ManageAllSurveys: {
                Description: 'Be able to manage all surveys, such as templates & results.',
                SecuredTabs: {
                    adminTabs: ['adminSurveys']
                }
            },
            ContinuousFeedback: {
                Description: 'Access to continuous feedback features, e.g., Request, Scheduled checkin, manager checkin.',
                SecuredTabs: {
                    profileTabs: ['feedbackSession']
                }
            },
            FeedbackCheckin: {
                Description: 'Access  check-in feature.',
                SecuredTabs: {
                    profileTabs: ['feedbackCheckin']
                }
            },
            RequestFeedback: {
                Description: 'Request Feedback.',
                SecuredTabs: {
                    profileTabs: ['requestFeedback']
                }
            },
            GiveFeedback: {
                Description: 'Give Feedback.',
                SecuredTabs: {
                    profileTabs: ['giveFeedback']
                }
            },
            UserNotificationPreference: {
                Description: 'Access to User Notification Preference.',
                SecuredTabs: {
                    userTabs: ['userNotificationPreference']
                }
            },
            AllowChatWidget: {
                Description: 'Allow chat widget to render.',
                SecuredTabs: {
                    userTabs: ['allowChatWidget']
                }
            },
            EnableConversationGuide: {
                Description: 'Enable the conversation guide link.',
                SecuredTabs: {
                    userTabs: ['enableConversationGuide']
                }
            },
            ManagerCheckin: {
                Description: 'Access to manager checkin feature.',
                SecuredTabs: {}
            },
            ManageFeedback: {
                Description: 'Be able to manage continuous, such as dashboard, templates & settings.',
                SecuredTabs: {
                    adminTabs: ['adminFeedback']
                }
            },
            TalentInsight: {
                Description: 'Manager access to talent questions and answers.',
                SecuredTabs: {}
            },
            ManageTalentInsight: {
                Description: 'Be able to manage talent assessments, such as dashboard, templates & settings.',
                SecuredTabs: {
                    adminTabs: ['manageTalentInsight']
                }
            },
            SeeLocation: {
                Description: 'See his or other member\'s location.',
                SecuredTabs: {}
            },
            ManageLocation: {
                Description: 'Be able to manage segregating group into smaller divisions or locations.',
                SecuredTabs: {
                    adminTabs: ['location']
                }
            },
            ManageAuthentication: {
                Description: 'Be able to manage authentication methods.',
                SecuredTabs: {
                    adminTabs: ['authentication']
                }
            },
            ManageRules: {
                Description: 'Manage rules engine of the group.',
                SecuredTabs: {
                    adminTabs: ['rules']
                }
            },
            Polls: {
                Description: 'Receive Polls.',
                SecuredTabs: {
                    profileTabs: ['rpoll']
                }
            },
            ManagePolls: {
                Description: 'Create Polls.',
                SecuredTabs: {
                    profileTabs: ['poll']
                }
            },
            ManageProfanity: {
                Description: 'Manage Profanity Filter',
                SecuredTabs: {
                    profileTabs: ['profanity']
                }
            },
            ManageDepartment: {
                Description: 'Manage Department',
                SecuredTabs: {
                    adminTabs: ['manageDepartment']
                }
            },
            GiveRecognitionToDepartment: {
                Description: 'Permission to allow giving recognition to department',
                SecuredTabs: {}
            },
            GiveRecognitionToLocation: {
                Description: 'Permission to allow giving recognition to location',
                SecuredTabs: {}
            },
            AllowSelectAllWhenGivingRecognition: {
                Description: 'Allow selecting all users when giving recognition',
                SecuredTabs: {}
            },
            TeamAction: {
                Description: 'View the team action tab.',
                SecuredTabs: {
                    teamTabs: ['action']
                }
            },
            TeamActionDemo: {
                Description: 'View the team action tab.',
                SecuredTabs: {
                    teamTabs: ['actiondemo']
                }
            },
            FeedbackDemo: {
                Description: 'Access to demo features for feedback.',
                SecuredTabs: {}
            },
            TeamRecognize: {
                Description: 'View the team recognize tab.',
                SecuredTabs: {
                    teamTabs: ['recognize']
                }
            },
            TeamGoals: {
                Description: 'View the team goals tab.',
                SecuredTabs: {
                    teamTabs: ['goals']
                }
            },
            TeamTalent: {
                Description: 'View the team Talent Insights tab.',
                SecuredTabs: {
                    teamTabs: ['talent']
                }
            },
            TeamCoaching: {
                Description: 'View the team coaching tab.',
                SecuredTabs: {
                    teamTabs: ['coaching']
                }
            },
            TeamPerform: {
                Description: 'View the team peform tab',
                SecuredTabs: {
                    teamTabs: ['perform']
                }
            },
            TeamCheckin: {
                Description: 'View the team checkin tab.',
                SecuredTabs: {
                    teamTabs: ['checkin']
                }
            },
            ManagerTeamLearning: {
                Description: 'View the manager team learning tab',
                SecuredTabs: {
                    teamTabs: ['managerTeamTabLearning']
                }
            },
            AddGiftToNewRecognition: {
                Description: 'Add a gift while giving a new recognition.',
                SecuredTabs: {
                    motivateTabs: ['addGiftNew']
                }
            },
            AddGiftToOldRecognition: {
                Description: 'Add a gift to an old recognition in the feed.',
                SecuredTabs: {
                    motivateTabs: ['addGiftOld']
                }
            },
            ViewAnalytics: {
                Description: 'View the new analytics area.',
                SecuredTabs: {
                    adminTabs: ['viewAnalytics']
                }
            },
            ApproveProductSuggestion: {
                Description: 'Approve product suggestion.',
                SecuredTabs: {
                    adminTabs: ['approveProductSuggestion']
                }
            },
            SellMyOwnItemForPoints: {
                Description: 'sell my own item for points.',
                SecuredTabs: {
                    motivateTabs: ['sellMyOwnItemForPoints']
                }
            },
            SuggestRewardIdea: {
                Description: 'Suggest reward idea.',
                SecuredTabs: {
                    motivateTabs: ['suggestRewardIdea']
                }
            },
            PurchaseGiftCards: {
                Description: 'Allow user to purchase gift cards.',
                SecuredTabs: {
                    motivateTabs: ['giftCards']
                }
            },
            DonateToCharities: {
                Description: 'Allow user to donate credits to charities.',
                SecuredTabs: {
                    motivateTabs: ['charities']
                }
            },
            ManageAPI: {
                Description: 'Manage Public API Keys.',
                SecuredTabs: {
                    adminTabs: ['manageAPI']
                }
            },
            ManageDisplay: {
                Description: 'Manage Display.',
                SecuredTabs: {
                    adminTabs: ['manageDisplay']
                }
            },
            TrackObjectiveWeight: {
                Description: 'Display objective weight of track.',
                SecuredTabs: {
                    trackTabs: ['trackObjectiveWeight']
                }
            },
            TransferSpendCredits: {
                Description: 'Be able to transfer spend credits.',
                SecuredTabs: {
                    userTabs: ['transferSpendCredits']
                }
            },
            HGManageTemplates: {
                Description: 'Be able to manage a System Templates as an HGAdmin.',
                SecuredTabs: {
                    provisionTabs: ['provisionTemplates']
                }
            },
            WishList: {
                Description: "Refers to the Wish List subtab under User > Account.",
                SecuredTabs: {
                    userTabs: ['wishList']
                }
            },
            Tutorials: {
                Description: "Allow onboarding walkthrough.",
                SecuredTabs: {}
            },
            GRSStorefront: {
                Description: "Allow access to GRS Storefront.",
                SecuredTabs: {
                    motivateTabs: ['grsStorefront']
                }
            },
            ReportAnalytics: {
                Description: "Allow access to the Report Analytics page.",
                SecuredTabs: {
                    teamTabs: ['analytics']
                }
            },
            MobileAllowCompanyGoalMod: {
                Description: "Allow create, edit and delete of company goals on mobile.",
                SecuredTabs: {}
            },
            MobileAllowTeamGoalMod: {
                Description: "Allow create, edit and delete of department goals on mobile.",
                SecuredTabs: {}
            },
            ReqFeedbackAboutOthers: {
                Description: "Allow request feedback about others",
                SecuredTabs: {}
            },
            EnableOptOutPublicRec: {
                Description: "Allow opt-out public recognitions",
                SecuredTabs: {}
            },
            HideHelpLink: {
                Description: "Hide help link",
                SecuredTabs: {}
            },
            AllowSurveyKiosk: {
                Description: "Allow Survey Kiosk",
                SecuredTabs: {}
            },
            RestrictSurveyResultByLocation: {
                Description: "Restrict survey result by location",
                SecuredTabs: {}
            }
        },
        MemberRole: {
            OffBoarded: {
                Description: 'An off-boarded employee.',
                MemberPermissions: [
                    'OffBoarded'
                ]
            },
            Consultant: {
                Description: 'Consultant',
                MemberPermissions: [
                    'Consultant',
                    'AdhocTeam',
                    'GiveRecognition',
                    'EverydayRecognition'
                ]
            },
            Employee: {
                Description: 'A regular employee.',
                MemberPermissions: [
                    'Basic',
                    'AdhocTeam',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'CustomizedRecognition',
                    'AllowSelectAllWhenGivingRecognition',
                    'CreateTrack',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PurchaseCredits',
                    'PaymentProfile',
                    'WishList',
                    'CreditTransactions',
                    'EverydayRecognition',
                    'ValuesRecognition',
                    'PointStore',
                    'ShowPointsInPublicFeed',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'SeeLocation',
                    'BenchmarkSurvey',
                    'PulseSurvey',
                    'Goal',
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    "OpenClosedGoal",
                    'AdhocGoal',
                    'NumericPercentageTarget',
                    'Polls',
                    'Tutorials',
                    'GRSStorefront',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'TalentInsight',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'AllImportantNotifications'
                ]
            },
            Manager: {
                Description: 'Manager.',
                MemberPermissions: [
                    'Basic',
                    'AdhocTeam',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'AllowSelectAllWhenGivingRecognition',
                    'CustomizedRecognition',
                    'EverydayRecognition',
                    'ValuesRecognition',
                    'SendCreditsInRecognition',
                    'SendPointsInRecognition',
                    'AddPointsInRecognition',
                    'CreateTrack',
                    'AssignTrack',
                    'CreateTrackMoreOptions',
                    'CreateTrackAddCredits',
                    'CreateTrackAddPoints',
                    'PerformDeliverCycle',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PerformCardLibrary',
                    'PaymentProfile',
                    'WishList',
                    'PurchaseCredits',
                    'PointStore',
                    'GivePointGift',
                    'CreditTransactions',
                    'ShowPointsInPublicFeed',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'BenchmarkSurvey',
                    'PulseSurvey',
                    'SeeLocation',
                    "OpenClosedGoal",
                    'Goal',
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    'AdhocGoal',
                    'NumericPercentageTarget',
                    'Polls',
                    'ManagePolls',
                    'Tutorials',
                    'GRSStorefront',
                    'ManagerCheckin',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'TalentInsight',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'AllImportantNotifications'
                ]
            },
            Director: {
                Description: 'Director.',
                MemberPermissions: [
                    'Basic',
                    'AdhocTeam',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'AllowSelectAllWhenGivingRecognition',
                    'SendCreditsInRecognition',
                    'SendPointsInRecognition',
                    'AddPointsInRecognition',
                    'CreateTrack',
                    'CreateTrackMoreOptions',
                    'CreateTrackAddCredits',
                    'CreateTrackAddPoints',
                    'TrackLibrary',
                    'PerformCardLibrary',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PaymentProfile',
                    'WishList',
                    'PurchaseCredits',
                    'CreditTransactions',
                    'CustomizedRecognition',
                    'EverydayRecognition',
                    'ValuesRecognition',
                    "OpenClosedGoal",
                    'PointStore',
                    'GivePointGift',
                    'ShowPointsInPublicFeed',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'BenchmarkSurvey',
                    'PulseSurvey',
                    'ManageSeg',
                    'SeeLocation',
                    'Goal',
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    'AdhocGoal',
                    'NumericPercentageTarget',
                    'Polls',
                    'ManagePolls',
                    'Tutorials',
                    'GRSStorefront',
                    'ManagerCheckin',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'TalentInsight',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'AllImportantNotifications'
                ]
            },
            Executive: {
                Description: 'Executive.',
                MemberPermissions: [
                    'Basic',
                    'AdhocTeam',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'AllowSelectAllWhenGivingRecognition',
                    'SendCreditsInRecognition',
                    'SendPointsInRecognition',
                    'AddPointsInRecognition',
                    'CreateTrack',
                    'CreateTrackMoreOptions',
                    'CreateTrackAddCredits',
                    'CreateTrackAddPoints',
                    'TrackLibrary',
                    'PerformCardLibrary',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PaymentProfile',
                    'WishList',
                    'PurchaseCredits',
                    'CreditTransactions',
                    'CustomizedRecognition',
                    'EverydayRecognition',
                    'ValuesRecognition',
                    'PointStore',
                    'GivePointGift',
                    'ShowPointsInPublicFeed',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'ManageSeg',
                    'AdminReports',
                    'SeeLocation',
                    'NumericPercentageTarget',
                    'Goal',
                    "OpenClosedGoal",
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    'AdhocGoal',
                    'BenchmarkSurvey',
                    'PulseSurvey',
                    'Polls',
                    'ManagePolls',
                    'Tutorials',
                    'GRSStorefront',
                    'ManagerCheckin',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'TalentInsight',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'AllImportantNotifications'
                ]
            },
            Admin: {
                Description: 'Admin of the group; generally HR staff.',
                MemberPermissions: [
                    'Basic',
                    'GroupSettingManagement',
                    'AdhocTeam',
                    'ManageBenchmarkSurvey',
                    'ManagePulseSurvey',
                    'ManageAllSurveys',
                    'ManageFeedback',
                    'TalentInsight',
                    'ManageTalentInsight',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'AllowSelectAllWhenGivingRecognition',
                    'SendCreditsInRecognition',
                    'SendPointsInRecognition',
                    'AddPointsInRecognition',
                    'DeleteRecognition',
                    'CreateTrack',
                    'CreateTrackMoreOptions',
                    'CreateTrackAddCredits',
                    'CreateTrackAddPoints',
                    'DeleteTrack',
                    'TrackLibrary',
                    'PerformCardLibrary',
                    'PerformCycle',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PaymentProfile',
                    'WishList',
                    'PurchaseCredits',
                    'CreditTransactions',
                    'TeamManagement',
                    'TeamAdmin',
                    'AdminDashboard',
                    'AdminReports',
                    'GroupCreditManagement',
                    'GroupMemberManagement',
                    'GroupMemberEdit',
                    'GroupMemberTransferManager',
                    'GroupMemberExport',
                    'CustomizedRecognition',
                    'DeleteComment',
                    'AchievementRecognition',
                    'EverydayRecognition',
                    'ValuesRecognition',
                    'ManageRules',
                    'ManageProductItem',
                    'ManageProductOrder',
                    'ManagePointEconomy',
                    'PointStore',
                    'GivePointGift',
                    'ShowPointsInPublicFeed',
                    'GroupRecognitionsManagement',
                    'YammerIntegration',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'TeamTabManagement',
                    'ManageAPI',
                    'ManageLocation',
                    'ManageAuthentication',
                    'ManageSeg',
                    'ManageDisplay',
                    'SeeLocation',
                    'TransferSpendCredits',
                    'Goal',
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    'AdhocGoal',
                    'ManageGoalLibrary',
                    'ManageGoalCycle',
                    "OpenClosedGoal",
                    'RecurringGoalCycle',
                    'UploadGoalCycleParticipants',
                    'GoalWeighting',
                    'SkipGoalApproval',
                    'NumericPercentageTarget',
                    'SelectRecapTime',
                    'PerformGoal',
                    'BenchmarkSurvey',
                    'PulseSurvey',
                    'Polls',
                    'ManagePolls',
                    'Tutorials',
                    'ManageProfanity',
                    'GRSStorefront',
                    'HideRecognition',
                    'ManagerCheckin',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'ManageDepartment',
                    'AllImportantNotifications'
                ]
            },
            Owner: {
                Description: 'Owner of the group -- user who created the group, applicable for ad-hoc group.',
                MemberPermissions: [
                    'Basic',
                    'AdhocTeam',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'AllowSelectAllWhenGivingRecognition',
                    'SendCreditsInRecognition',
                    'SendPointsInRecognition',
                    'AddPointsInRecognition',
                    'DeleteRecognition',
                    'CreateTrack',
                    'CreateTrackMoreOptions',
                    'CreateTrackAddCredits',
                    'CreateTrackAddPoints',
                    'DeleteTrack',
                    'TrackLibrary',
                    'PerformCardLibrary',
                    'PerformCycle',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PaymentProfile',
                    'WishList',
                    'PurchaseCredits',
                    'CreditTransactions',
                    'TeamManagement',
                    'TeamAdmin',
                    'AdminDashboard',
                    'AdminReports',
                    'GroupSettingManagement',
                    'GroupCreditManagement',
                    'GroupMemberManagement',
                    'GroupMemberEdit',
                    'GroupMemberTransferManager',
                    'GroupMemberExport',
                    'CustomizedRecognition',
                    'DeleteComment',
                    'EverydayRecognition',
                    'ValuesRecognition',
                    'AchievementRecognition',
                    'ManageRules',
                    'ManageProductItem',
                    'ManageProductOrder',
                    'ManagePointEconomy',
                    'PointStore',
                    'GivePointGift',
                    'ShowPointsInPublicFeed',
                    'YammerIntegration',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'BenchmarkSurvey',
                    'PulseSurvey',
                    'ManageDisplay',
                    'SeeLocation',
                    'Goal',
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    'AdhocGoal',
                    'ManageGoalCycle',
                    "OpenClosedGoal",
                    'RecurringGoalCycle',
                    'GoalWeighting',
                    'SkipGoalApproval',
                    'PerformGoal',
                    'Polls',
                    'ManagePolls',
                    'Tutorials',
                    'GRSStorefront',
                    'ManagerCheckin',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'ManageDepartment',
                    'AllImportantNotifications'
                ]
            },
            ResellerAdmin: {
                Description: 'Admin from the above reseller.',
                MemberPermissions: [
                    'Basic',
                    'GroupSettingManagement',
                    'AdhocTeam',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'AllowSelectAllWhenGivingRecognition',
                    'SendCreditsInRecognition',
                    'SendPointsInRecognition',
                    'AddPointsInRecognition',
                    'DeleteRecognition',
                    'CreateTrack',
                    'CreateTrackMoreOptions',
                    'CreateTrackAddCredits',
                    'CreateTrackAddPoints',
                    'DeleteTrack',
                    'TrackLibrary',
                    'PerformCardLibrary',
                    'PerformCycle',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PaymentProfile',
                    'WishList',
                    'PurchaseCredits',
                    'CreditTransactions',
                    'TeamManagement',
                    'TeamAdmin',
                    'AdminDashboard',
                    'AdminReports',
                    'GroupCreditManagement',
                    'GroupMemberManagement',
                    'GroupMemberEdit',
                    'GroupMemberTransferManager',
                    'GroupMemberExport',
                    'Provision',
                    'Metrics',
                    'DeleteComment',
                    'ManageTemplatePerformCard',
                    'ManageRules',
                    'ManageProductItem',
                    'ManageProductOrder',
                    'ManagePointEconomy',
                    'PointStore',
                    'GivePointGift',
                    'ShowPointsInPublicFeed',
                    'YammerIntegration',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'TeamTabManagement',
                    'ManagerAlerts',
                    'ManagePulseSurvey',
                    'ManageSeg',
                    'ManageAPI',
                    'ManageLocation',
                    'SeeLocation',
                    'Goal',
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    'AdhocGoal',
                    'NumericPercentageTarget',
                    'SelectRecapTime',
                    'ManageGoalCycle',
                    "OpenClosedGoal",
                    'RecurringGoalCycle',
                    'GoalWeighting',
                    'SkipGoalApproval',
                    'PerformGoal',
                    'BenchmarkSurvey',
                    'PulseSurvey',
                    'Tutorials',
                    'GRSStorefront',
                    'ManagerCheckin',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'ManageDepartment',
                    'AllImportantNotifications'
                ]
            },
            HGAdmin: {
                Description: 'Admin of the system.',
                MemberPermissions: [
                    'Basic',
                    'GroupSettingManagement',
                    'AdhocTeam',
                    'HGManageTemplates',
                    'GiveRecognition',
                    'GiveRecognitionToDepartment',
                    'GiveRecognitionToLocation',
                    'AllowSelectAllWhenGivingRecognition',
                    'SendCreditsInRecognition',
                    'SendPointsInRecognition',
                    'AddPointsInRecognition',
                    'DeleteRecognition',
                    'CreateTrack',
                    'CreateTrackMoreOptions',
                    'CreateTrackAddCredits',
                    'CreateTrackAddPoints',
                    'DeleteTrack',
                    'TrackLibrary',
                    'PerformCardLibrary',
                    'PerformCycle',
                    'MemberCredit',
                    'MemberPoint',
                    'TransferCredits',
                    'PaymentProfile',
                    'WishList',
                    'PurchaseCredits',
                    'CreditTransactions',
                    'TeamManagement',
                    'TeamAdmin',
                    'AdminDashboard',
                    'AdminReports',
                    'HGAdminReports',
                    'GroupCreditManagement',
                    'GroupMemberManagement',
                    'GroupMemberEdit',
                    'GroupMemberExport',
                    'GroupMemberTransferManager',
                    'Provision',
                    'ProvisionSystem',
                    'ProvisionUpload',
                    'ProvisionCompany',
                    'ProvisionTemplates',
                    'ProvisionDemo',
                    'ProvisionBilling',
                    'ProvisionMetrics',
                    'ProvisionTutorials',
                    'GroupTerminologyManagement',
                    'DeleteComment',
                    'ManageTemplatePerformCard',
                    'CustomizedRecognition',
                    'EverydayRecognition',
                    'ValuesRecognition',
                    'AchievementRecognition',
                    'ImpersonateGlobal',
                    'ProvisionAssets',
                    'ManageRules',
                    'ManageProductItem',
                    'ManageProductOrder',
                    'ManagePointEconomy',
                    'PointStore',
                    'GivePointGift',
                    'ShowPointsInPublicFeed',
                    'GroupRecognitionsManagement',
                    'YammerIntegration',
                    'AddGiftToNewRecognition',
                    'AddGiftToOldRecognition',
                    'TeamTabManagement',
                    'ManageSeg',
                    'ManageAPI',
                    'ManageLocation',
                    'ManageAuthentication',
                    'ManageClientApi',
                    'ManageDisplay',
                    'SeeLocation',
                    'TransferSpendCredits',
                    'Goal',
                    'TeamGoals',
                    'TeamCheckin',
                    'ContinuousFeedback',
                    'AdhocGoal',
                    'ManageGoalCycle',
                    "OpenClosedGoal",
                    'RecurringGoalCycle',
                    'ManageGoalLibrary',
                    'UploadGoalCycleParticipants',
                    'GoalWeighting',
                    'SkipGoalApproval',
                    'PerformGoal',
                    'ManageAllSurveys',
                    'ManageFeedback',
                    'TalentInsight',
                    'ManageTalentInsight',
                    'ManageBenchmarkSurvey',
                    'BenchmarkSurvey',
                    'ManagePulseSurvey',
                    'NumericPercentageTarget',
                    'SelectRecapTime',
                    'PulseSurvey',
                    'Polls',
                    'ManagePolls',
                    'Tutorials',
                    'ManageProfanity',
                    'GRSStorefront',
                    'HideRecognition',
                    'ManagerCheckin',
                    'FeedbackCheckin',
                    'RequestFeedback',
                    'MobileAllowCompanyGoalMod',
                    'MobileAllowTeamGoalMod',
                    'UserNotificationPreference',
                    'AllowChatWidget',
                    'ReqFeedbackAboutOthers',
                    'AllowAvatarUpload',
                    'EnableOptOutPublicRec',
                    'AllowProfileInfoEditing',
                    'ManageDepartment',
                    'AllImportantNotifications'
                ]
            }
        }
    },
    util = require('./EnumsBase.js');

util.SetNames(MemberEnums.Status);
util.SetNames(MemberEnums.MemberRole, 'Name');
util.SetNames(MemberEnums.MemberPermission, 'Name');

MemberEnums.GetAllPermissions = function () {
    var keys = Object.keys(MemberEnums.MemberPermission),
        i,
        len = keys.length,
        permissions = [],
        attr;
    for (i = 0; i < len; i += 1) {
        attr = keys[i];
        MemberEnums.MemberPermission[attr].MemberPermission = attr;
        permissions.push(MemberEnums.MemberPermission[attr]);
    }
    return permissions;
};

MemberEnums.GetExcludePermission = function (tab, subtab) {
    var keys = Object.keys(MemberEnums.MemberPermission),
        i,
        ilen,
        sec,
        secj,
        attr,
        j,
        jlen,
        k,
        klen,
        inn;
    for (i = 0, ilen = keys.length; i < ilen; i += 1) {
        attr = keys[i];
        if (MemberEnums.MemberPermission[attr].SecuredTabs) {
            sec = Object.keys(MemberEnums.MemberPermission[attr].SecuredTabs);
            for (j = 0, jlen = sec.length; j < jlen; j += 1) {
                secj = sec[j];
                inn = MemberEnums.MemberPermission[attr].SecuredTabs[secj];
                if (tab === secj && inn) {
                    for (k = 0, klen = inn.length; k < klen; k += 1) {
                        if (subtab === inn[k]) {
                            return attr;
                        }
                    }
                }
            }
        }
    }
};
MemberEnums.GetAllRoles = function () {
    return Object.keys(MemberEnums.MemberRole);
};
MemberEnums.GetRolesPermissionsTabs = function () {
    var results = {
            Roles: [],
            Permissions: {}
        },
        getAllRoles = function (results) {
            var roleKeys = Object.keys(MemberEnums.MemberRole),
                i,
                ilen = roleKeys.length,
                attr;
            for (i = 0; i < ilen; i += 1) {
                attr = roleKeys[i];
                results.Roles.push({
                    Role: attr,
                    Description: MemberEnums.MemberRole[attr].Description,
                    isSelected: false
                });
            }
        },
        checkExists = function (params) {
            return results.Permissions[params.index].Tabs.some(function (t) {
                return t.Permission === params.value;
            });
        },
        getAllMemberPermissions = function (results) {
            var permKeys = Object.keys(MemberEnums.MemberPermission),
                i,
                ilen = permKeys.length,
                attr,
                secAttr,
                j,
                jlen,
                k,
                klen,
                kArray,
                secKeys,
                tabs = [];
            for (i = 0; i < ilen; i += 1) {
                attr = permKeys[i];
                if (MemberEnums.MemberPermission[attr].SecuredTabs) {
                    secKeys = Object.keys(MemberEnums.MemberPermission[attr].SecuredTabs);
                    for (j = 0, jlen = secKeys.length; j < jlen; j += 1) {
                        secAttr = secKeys[j];
                        if (tabs.indexOf(secAttr) === -1) {
                            tabs.push(secAttr);
                            results.Permissions[secAttr] = {
                                Title: paramUtil.CapitalizeFirstLetter(secAttr.replace('Tabs', '')),
                                isSelected: false,
                                isExpanded: false,
                                Tabs: []
                            };
                        }
                        kArray = MemberEnums.MemberPermission[attr].SecuredTabs[secAttr];
                        for (k = 0, klen = kArray.length; k < klen; k += 1) {
                            if (!checkExists({index: secAttr, value: kArray[k]})) {
                                results.Permissions[secAttr].Tabs.push({
                                    Permission: kArray[k],
                                    Description: MemberEnums.MemberPermission[attr].Description,
                                    isSelected: false
                                });
                            }
                        }
                    }
                }
            }
        };
    getAllRoles(results);
    getAllMemberPermissions(results);
    return results;
};

MemberEnums.GetPermissionsInRole = function (roleName) {
    var permissions = [];
    if (MemberEnums.MemberRole[roleName]) {
        permissions = MemberEnums.MemberRole[roleName].MemberPermissions;
    }
    return permissions;
};

module.exports = MemberEnums;
