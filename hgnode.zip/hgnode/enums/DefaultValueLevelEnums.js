/*jslint node:true es5:true*/
'use strict';
var LimitPeriodEnums = {
        Week: 0,
        Month: 0,
        Quarter: 0,
        Year: 0,
        NoLimit: 0
    },
    Enums,
    util = require('./EnumsBase.js');
util.SetNames(LimitPeriodEnums);
Enums = {
    Levels : {
        Default : {
            PointValue : 0,
            CreditValue : 0,
            LimitPeriod : LimitPeriodEnums.NoLimit,
            AvailabilityToRoles : []
        },
        Silver : {
            PointValue : 0,
            CreditValue : 0,
            LimitPeriod : LimitPeriodEnums.NoLimit,
            AvailabilityToRoles : [
                {
                    RoleName : 'Employee',
                    Allowed : true,
                    LimitNumber : 10
                },
                {
                    RoleName: 'Consultant',
                    Allowed: true,
                    LimitNumber: 10
                },
                {
                    RoleName : 'Manager',
                    Allowed : true,
                    LimitNumber : 10
                },
                {
                    RoleName : 'Director',
                    Allowed : true,
                    LimitNumber : 10
                },
                {
                    RoleName : 'Executive',
                    Allowed : true,
                    LimitNumber : 10
                },
                {
                    RoleName : 'Admin',
                    Allowed : true,
                    LimitNumber : 10
                },
                {
                    RoleName : 'Owner',
                    Allowed : true,
                    LimitNumber : 10
                },
                {
                    RoleName : 'HGAdmin',
                    Allowed : true,
                    LimitNumber : 10
                }
            ]
        },
        Gold : {
            PointValue : 0,
            CreditValue : 0,
            LimitPeriod : LimitPeriodEnums.NoLimit,
            AvailabilityToRoles : [
                {
                    RoleName : 'Employee',
                    Allowed : true,
                    LimitNumber : 3
                },
                {
                    RoleName: 'Consultant',
                    Allowed: true,
                    LimitNumber: 3
                },
                {
                    RoleName : 'Director',
                    Allowed : true,
                    LimitNumber : 3
                },
                {
                    RoleName : 'Manager',
                    Allowed : true,
                    LimitNumber : 3
                },
                {
                    RoleName : 'Executive',
                    Allowed : true,
                    LimitNumber : 3
                },
                {
                    RoleName : 'Admin',
                    Allowed : true,
                    LimitNumber : 3
                },
                {
                    RoleName : 'Owner',
                    Allowed : true,
                    LimitNumber : 3
                },
                {
                    RoleName : 'HGAdmin',
                    Allowed : true,
                    LimitNumber : 3
                }
            ]
        },
        Platinum : {
            PointValue : 0,
            CreditValue : 0,
            LimitPeriod : LimitPeriodEnums.NoLimit,
            AvailabilityToRoles : [
                {
                    RoleName : 'Employee',
                    Allowed : true,
                    LimitNumber : 1
                },
                {
                    RoleName: 'Consultant',
                    Allowed: true,
                    LimitNumber: 1
                },
                {
                    RoleName : 'Manager',
                    Allowed : true,
                    LimitNumber : 1
                },
                {
                    RoleName : 'Director',
                    Allowed : true,
                    LimitNumber : 1
                },
                {
                    RoleName : 'Executive',
                    Allowed : true,
                    LimitNumber : 1
                },
                {
                    RoleName : 'Admin',
                    Allowed : true,
                    LimitNumber : 1
                },
                {
                    RoleName : 'Owner',
                    Allowed : true,
                    LimitNumber : 1
                },
                {
                    RoleName : 'HGAdmin',
                    Allowed : true,
                    LimitNumber : 1
                }
            ]
        }
    }
};
util.SetNames(Enums.Levels, 'Name');

Enums.GetAllLevels = function () {
    return Object.keys(Enums.Levels).map(function (level) {
        return Enums.Levels[level];
    });
};

module.exports = Enums;
