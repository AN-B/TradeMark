/*jslint node:true es5:true*/
'use strict';
var Enums = {
    CreditCard: 0,
    eCheck: 0,
    BillMeLater: 0,
    Transfer: 0,
    Recognition: 0,
    BenchmarkSurvey: 0,
    PulseSurvey: 0,
    Redemption: 0,
    CreditReversal: 0,
    Refund: 0,
    MintPoints: 0,
    ReplenishPoints: 0,
    PlaceOrder: 0,//use point to place order of an item
    OwnerCredit: 0,
    BackToCampaignPoints: 0,
    RefundOfCampaign: 0,
    GRSOrder: 0,
    Adjustment: 0
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;