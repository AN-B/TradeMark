/*jslint node:true es5:true*/
'use strict';
var Enums = {
    Service: {
        Credit: 0,
        GoalCycle: 0,
        Goal: 0,
        ManagerAlert: 0,
        Recognition: 0,
        Tag: 0,
        Performance: 0,
        Survey: 0,
        Onboard: 0,
        ProvisionBuilder: 0,
        ProvisionGroup: 0,
        ProvisionLocation: 0,
        ProvisionDepartment: 0,
        ProvisionMember: 0,
        FeedbackCycle: 0,
        Provision: 0,
        Group: 0,
        Member: 0,
        FeedbackSession: 0,
        FeedbackRequest: 0,
        Notification: 0,
        Relevancy: 0
    },
    ProvisionMember: {
        ProvisionMemberProcessType: 0,
        ProvisionUpdateMemberManagers: 0,
        ProvisionUpdateMemberUserNames: 0,
        ProvisionOffBoardMembers: 0,
        ProvisionSetMemberManagersFromEmployeeId: 0
    },
    ProvisionDepartment: {
        ProcessNewDepartments: 0
    },
    ProvisionGroup: {
        ProvisionCreateGroup: 0,
        ProvisionUpdateGroup: 0
    },
    ProvisionLocation: {
        ProvisionUpdateLocationType: 0
    },
    Notification: {
        ServiceAwardPointMissing: 0
    },
    Relevancy: {
        MemberFirstLogin: 0,
        RecognitionReceived: 0,
        MemberBookmarked: 0,
        CongratsReceived: 0,
        MemberOnboarded: 0,
        MemberReinstated: 0,
        MemberOffboarded: 0,
        ManagerChanged: 0
    },
    FeedbackSession: {
        FeedbackCheckin: 0,
        SuccessionPlanning: 0,
        GoalCreated: 0,
        MemberOffboarded: 0
    },
    Credit: {
        MemberOffboarded: 0,
        MemberReinstated: 0
    },
    GoalCycle: {
        GoalCycleClosed: 0,
        GoalCycleDeleted: 0,
        GoalCycleUpdated: 0,
        ParticipantRemovedFromCycle: 0,
        GoalCyclePublished: 0,
        UploadedGoalCycleParticipants: 0,
        GoalCycleParticipantUploadProcessed: 0,
        TemplateGoalDeleted: 0
    },
    Goal: {
        GoalCycleClosed: 0,
        GoalDeleted: 0,
        ParticipantRemovedFromCycle: 0,
        GoalCreated: 0,
        MemberOffboarded: 0,
        TemplateGoalAssigned: 0,
        TemplateGoalDeleted: 0
    },
    ManagerAlert: {
        MemberUpdatedGoal: 0,
        GoalCycleDeleted: 0,
        FeedbackCycleArchivedOrClosed: 0
    },
    Member: {
        MemberReinstated: 0
    },
    Recognition: {
        GoalKeyResultUpdated: 0,
        MemberOffboarded: 0,
        MemberReinstated: 0,
        MemberRoleChanged: 0,
        RecognitionRequested: 0
    },
    Tag: {
        GlobalTagAdded: 0
    },
    Performance: {
        PerformanceCycleCreated: 0,
        AllReviewsClosedInCycle: 0,
        AllReviewsArchivedInCycle: 0
    },
    Provision: {
        MergeAccount: 0
    },
    Survey: {
        DeliverSurveyToMembers: 0
    },
    Onboard: {
        FileUploaded: 0,
        FilePreValidation: 0,
        FileConfirmed: 0,
        HRISUpload: 0
    },
    ProvisionBuilder: {
        CreateMemberOffBoardQueue: 0
    },
    FeedbackCycle: {
        FeedbackCyclePublished: 0,
        FeedbackCycleArchived: 0,
        FeedbackCycleClosed: 0,
        MemberFirstLogin: 0,
        MemberDeptChange: 0,
        MemberLocationChange: 0
    },
    Group: {
        SelectRecapTimeFeatureFlagSwitched: 0,
        WeeklyRecapDayChanged: 0
    },
    Yammer: {
        PostMessage: 0,
        BuildBadgeForYammer: 0
    }
},
    util = require('./EnumsBase.js');
util.SetNames(Enums);

module.exports = Enums;
