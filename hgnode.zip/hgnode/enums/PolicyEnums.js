/*jslint node:true es5:true*/
'use strict';
var Enums = {
    MinChar: function (value) {
        return '(?=^.{' + value + ',}$)';
    },
    MinAlpha: function (value) {
        return '(?=(.*[a-z]){' + value + ',})';
    },
    MinNum: function (value) {
        return '(?=(.*\\d){' + value + ',})';
    },
    MinUpper: function (value) {
        return '(?=(.*[A-Z]){' + value + ',})';
    },
    MinSpec: function (value) {
        return '(?=(.*[!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~]){' + value + ',})';
    }
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;