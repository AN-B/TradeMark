/*jslint node:true es5:true*/
'use strict';
var Enums = {
    EntityType : {
        BenchmarkSurvey: 0,
        PulseSurvey: 0,
        PerformanceCycle: 0,
        GoalCycle: 0,
        GoalCycleParticipant: 0,
        Poll: 0,
        Goal: 0,
        Group: 0,
        FeedbackCycle: 0,
        EventBusItemArchive: 0,
        Member: 0,
        TalentInsight: 0
    },
    Status: {
        Active: 0,
        InProgress: 0,
        Archived: 0
    },
    WindowType: {
        Sliding: 0,
        Calendar: 0
    },
    RecurrencePeriod: {
        Once: 0,
        Daily: 0,
        Weekly: 0,
        Monthly: 0,
        Quarterly: 0,
        SemiAnnual: 'Semi-Annual',
        Yearly: 0,
        Anniversary: 0
    },
    RecurrenceTypes: {
        SaveYammerNetworkUserInfo: {
            EntityType: 'Member',
            ServiceName: 'Member',
            MethodName: 'SaveYammerNetworkUserInfo'
        },
        ResendBadgeToYammer: {
            EntityType: 'EventBusItemArchive',
            ServiceName: 'Yammer',
            MethodName: 'ResendBadgeToYammer'
        },
        GoalCycleSliding: {
            EntityType: 'GoalCycle',
            ServiceName: 'GoalCycle',
            MethodName: 'GoalCycleSliding'
        },
        DeliverSelfEvaluation: {
            EntityType: 'FeedbackCycle',
            ServiceName: 'FeedbackCycle',
            MethodName: 'DeliverSelfEvaluation'
        },
        GoalCheckIn: {
            EntityType: 'GoalCycleParticipant',
            ServiceName: 'Goal',
            MethodName: 'GoalCheckIn'
        },
        AdhocGoalCheckIn: {
            EntityType: 'Goal',
            ServiceName: 'Goal',
            MethodName: 'AdhocGoalCheckIn'
        },
        PerformanceCyclePercentUpdate: {
            EntityType: 'PerformanceCycle',
            ServiceName: 'Performance',
            MethodName: 'UpdateCyclePercentBySchedule'
        },
        PulseSurveyReminder: {
            EntityType: 'PulseSurvey',
            ServiceName: 'Survey',
            MethodName: 'SendPulseSurveyReminder'
        },
        BenchmarkSurveyReminder: {
            EntityType: 'BenchmarkSurvey',
            ServiceName: 'Survey',
            MethodName: 'SendSurveyReminder'
        },
        CollateSurveyResult: {
            EntityType: 'BenchmarkSurvey',
            ServiceName: 'Survey',
            MethodName: 'CollateSurveyResult'
        },
        ExpireNotification: {
            EntityType: 'BenchmarkSurvey',
            ServiceName: 'Survey',
            MethodName: 'ExpireNotification'
        },
        DeliverPulseSurvey: {
            EntityType: 'PulseSurvey',
            ServiceName: 'Survey',
            MethodName: 'DeliverSurveyToMembers'
        },
        DeliverBenchmarkSurvey: {
            EntityType: 'BenchmarkSurvey',
            ServiceName: 'Survey',
            MethodName: 'DeliverSurveyToMembers'
        },
        DeliverPoll: {
            EntityType: 'Poll',
            ServiceName: 'Poll',
            MethodName: 'DeliverPoll'
        },
        ClosePoll: {
            EntityType: 'Poll',
            ServiceName: 'Poll',
            MethodName: 'ClosePoll'
        },
        DailyRecap: {
            EntityType: 'Group',
            ServiceName: 'Recap',
            MethodName: 'DailyRecapRecurrence'
        },
        WeeklyRecap: {
            EntityType: 'Group',
            ServiceName: 'Recap',
            MethodName: 'WeeklyRecapRecurrence'
        },
        CloseSuccessionCycle: {
            EntityType: 'Feedback',
            ServiceName: 'FeedbackCycle',
            MethodName: 'CloseSuccessionCycle'
        },
        DeliverAssessmentToManagers: {
            EntityType: 'TalentInsight',
            ServiceName: 'TalentInsight',
            MethodName: 'DeliverAssessmentToManagers'
        }
    }
},
    util = require('./EnumsBase.js');
util.SetNames(Enums);
util.SetNames(Enums.RecurrenceTypes, 'Name');

module.exports = Enums;
