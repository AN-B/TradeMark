/*jslint node:true es5:true*/
'use strict';
var Enums = {
        GoalStatus: {
            Editing: 0,//for goal template, it can't be assigned yet
            SubmittedForSet: 0,//
            InProgress: 0,//for goal template, this is ready to be assigned
            PendingClosure: 0,
            SubmittedForClosure: 0,
            Closed: 0,
            Archived: 0//for goal template, it has been deleted
        },
        ParticipantOperation: {
            Add: 0,
            Remove: 0
        },
        ParticipantOperationAudit: {
            SkipAdd: 0,
            SkipRemove: 0,
            ErrorAdd: 0,
            ErrorRemove: 0,
            Add: 0,
            Remove: 0
        },
        UploadStep: {
            LoadFileData: 0,
            ValidateRawData: 0,
            ValidateCycleAndMemers: 0
        },
        UploadErrorType: {
            LoadFileData: 0,
            EmptyUserList: 0,
            InvalidOperation: 0,
            MixedOperation: 0,
            ErrorLoadUsers: 0,
            InvalidUserName: 0,
            ErrorLoadMembers: 0,
            InvalidMember: 0
        },
        CycleStatus: {
            Building: 0,//the cycle object itself has been created, but the system is still in process of adding default participants into the cycle. Cycles in this status shouldn't show up in the cycle list screen
            Draft: 0,//admin is still editing, nothing should be delivered (even if all other criteria meet)
            Pending: 0,//cycle is ready to be delivered if all other criteria meet
            InProgress: 0,//at least one party has been delivered
            Closed: 0,
            Archived: 0
        },
        ParticipantType: {
            Member: 0,
            Team: 0,
            Company: 0
        },
        ParticipantStatus: {
            PendingDelivery: 0,
            NotStarted: 0,//has been delivered to this member, but still haven't created any goals
            Setting: 0,//has created some goals, but still haven't set the goal
            SubmittedForSet: 0,// aka 0, once in this status, participant can no longer add new goals for this cycle
            InProgress: 0,//all his goals in the cycle have been "set", and he's working on its progress
            SubmittedForClosure: 0,
            Completed: 0,
            Removed: 0
        },
        WeightingStatus: {
            NA: 0,//not applicable. For non-weighting cycle or adhoc
            Pending: 0,
            Approved: 0,
            Rejected: 0
        },
        WeightType: {
            Equal: 0,
            Custom: 0
        },
        ProgressStatus: {
            Behind: 0,
            OnTrack: 0,
            AtRisk: 0
        },
        KeyResultWeightType: {
            Equal: 0,
            Custom: 0
        },
        KeyResultMeasureType: {
            Numeric: 0,
            Percentage: 0,
            Binary: 0
        },
        KeyResultNumericType: {
            Percentage: 0,
            Currency: 0,
            Custom: 0
        },
        KeyResultLabel: {
            Complete: 0,
            Incomplete: 0
        },
        ActivityType: {
            Delivered: 0,
            CreateGoal: 0,
            EditedGoal: 0,
            SetGoal: 0,
            SubmittedForSet: 0,
            SetApproved: 0,
            SetRejected: 0,
            KeyResultUpdated: 0,
            SubmittedForClosure: 0,
            ClosureApproved: 0,
            ClosureRejected: 0,
            CloseGoal: 0,
            GoalArchived: 0,
            GoalClosed: 0,
            ReopenGoal: 0,
            CloseAdhocGoal: 0,
            SetAdhocGoal: 0,
            GoalNameChange: 0,
            KeyResultNameChange: 0,
            KeyResultTargeChange: 0,
            AddAlignGoal: 0,
            ChangeAlignGoal: 0,
            ChangeGoalPublicity: 0,
            KeyResultRemoved: 0,
            KeyResultAdded: 0
        },
        CycleUpdateType: {
            Title: 0,
            ClosePromptDate: 0,
            Note: 0,
            Level: 0,
            DeliveryDate: 0,
            SetDueDate: 0,
            CheckInFrequency: 0,
            RecurrenceFrequency: 0,
            GoalWeighting: 0
        },
        DeliveryTriggerType: {
            ByDate: 0,
            OtherSet: 0
        },
        Publicity: {
            Public: 0,
            Private: 0
        },
        RoleInCycle: {
            Observer: 0,
            Owner: 0
        },
        Personal: 0
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
