/*jslint node:true es5:true*/
'use strict';
var Enums = {
    ItemStatus: {
        New: 0,
        Locked: 0,
        Processing: 0,
        Processed: 0
    },
    SubscriberStatus: {
        Success: 0,
        Failed: 0
    },
    Action: {
        Completed: 0,
        Ignore: 0,
        Report: 0,
        Retry: 0,
        ReportFailedRetries: 0
    },
    EntityType: {
        SalesforceOpportunity: 0,
        SalesforceAccount: 0
    },
    EventTypes: {
        ReplenishPoints: {
            DisplayText: 'Replenish Points',
            Subscribers: [
                {
                    ServiceName: 'Point',
                    MethodName: 'ReplenishPointsByTrigger',
                    FailureAction: 'Report'
                }
            ]
        },
        ServiceAward: {
            DisplayText: 'Service Award',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'
                }
            ]
        },
        ServiceAwardPointMissing: {
            DisplayText: 'Service Award Point Missing',
            Subscribers: [
                {
                    ServiceName: 'Notification',
                    MethodName: 'ServiceAwardPointMissing',
                    FailureAction: 'Report'
                }
            ]
        },
        GlobalTagAdded: {
            DisplayText: 'Global Tag Added',
            Subscribers: [
                {
                    ServiceName: 'Tag',
                    MethodName: 'GlobalTagAdded',
                    FailureAction: 'Report'
                }
            ]
        },
        CompanyOnboarded: {
            DisplayText: 'Company Onboarded',
            Subscribers: [
                {
                    ServiceName: 'RecognitionAdmin',
                    MethodName: 'CreateDefaultServiceAward',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Tag',
                    MethodName: 'ImportGlobalTags',
                    FailureAction: 'Report'
                }
            ]
        },
        AppointmentMade: {
            DisplayText: 'Appointment Made',
            AppSource: 'SalesForce',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'//options are Ignore, Retry, Report
                }
            ]
        },
        DialMade: {
            DisplayText: 'Activity Trigger',
            AppSource: 'SalesForce',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'//options are Ignore, Retry, Report
                }
            ]
        },
        Acq_WebinarSet: {//Opty Created trigger for Acquirent
            AppSource: 'SalesForce',
            DisplayText: 'Opportunity Trigger',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'//options are Ignore, Retry, Report
                }
            ]
        },
        Acq_WebinarRun: {//Demo/meeting held trigger for acquirent
            AppSource: 'SalesForce',
            DisplayText: 'Demo/Meeting Trigger',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'//options are Ignore, Retry, Report
                }
            ]
        },
        Acq_CloseWon: {//Win trigger for Acquirent
            AppSource: 'SalesForce',
            DisplayText: 'Win Trigger',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'//options are Ignore, Retry, Report
                }
            ]
        },
        ContractSold: {
            DisplayText: 'Contract Sold',
            AppSource: 'SalesForce',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                }
            ]
        },
        BDContractSold: {
            AppSource: 'SalesForce',
            DisplayText: 'BD Contract Sold',
            CheckUniqueness: true,
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                }
            ]
        },
        CsNewClientLaunched: {
            DisplayText: 'New Client Launched',
            AppSource: 'SalesForce',
            CheckUniqueness: true,
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                }
            ]
        },
        CsClientRenewed: {
            DisplayText: 'Client Renewed',
            AppSource: 'SalesForce',
            CheckUniqueness: true,
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                }
            ]
        },
        CsAdditionalClientModule: {
            DisplayText: 'Client Launched Additional Module',
            AppSource: 'SalesForce',
            CheckUniqueness: true,
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                }
            ]
        },
        MemberNameUpdated: {
            Subscribers: [
                {
                    ServiceName: 'Member',
                    MethodName: 'UpdateMemberManagerName',
                    FailureAction: 'Retry'
                },
                {
                    ServiceName: 'Performance',
                    MethodName: 'UpdateReviewMemberName',
                    FailureAction: 'Retry'
                },
                {
                    ServiceName: 'Performance',
                    MethodName: 'UpdateCycleMemberName',
                    FailureAction: 'Retry'
                }
            ]
        },
        MemberRoleChanged: {
            Subscribers: [{
                ServiceName: 'EntityActivity',
                MethodName: 'CreateActivity',
                FailureAction: 'Report'
            }]
        },
        MemberReinstated: {
            Subscribers: [
                {
                    ServiceName: 'Member',
                    MethodName: 'MemberReinstated',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Recognition',
                    MethodName: 'MemberReinstated',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Credit',
                    MethodName: 'MemberReinstated',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'MemberReinstated',
                    FailureAction: 'Report'
                }
            ]
        },
        MemberDeptChange: {
            Subscribers: [
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'MemberDeptChange',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'FeedbackCycle',
                    MethodName: 'MemberDeptChange',
                    FailureAction: 'Report'
                }
            ]
        },
        MemberLocationChange: {
            Subscribers: [
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'MemberLocationChange',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'FeedbackCycle',
                    MethodName: 'MemberDeptChange',
                    FailureAction: 'Report'
                }
            ]
        },
        ManagerChanged: {
            Subscribers: [
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'ManagerChanged',
                    FailureAction: 'Report'
                }
            ]
        },
        HRISUpload: {
            Subscribers: [
                {
                    ServiceName: 'Onboard',
                    MethodName: 'HRISUpload',
                    FailureAction: 'Report'
                }
            ]
        },
        MergeAccounts: {
            Subscribers: [
                {
                    ServiceName: 'Provision',
                    MethodName: 'MergeAccount',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionFileUploaded: {
            Subscribers: [
                {
                    ServiceName: 'Onboard',
                    MethodName: 'FileUploaded',
                    FailureAction: 'Report'
                }
            ]
        },
        ProcessAPIBatch: {
            Name: 'ProcessAPIBatch',
            Subscribers: [ {
                ServiceName: 'Onboard',
                MethodName: 'ProcessAPIBatch',
                FailureAction: 'Report'
            }]
        },
        ProvisionFileValidation: {
            Subscribers: [
                {
                    ServiceName: 'Onboard',
                    MethodName: 'FilePreValidation',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionFileConfirmed: {
            Subscribers: [
                {
                    ServiceName: 'Onboard',
                    MethodName: 'FileConfirmed',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionCreateGroup: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionGroup',
                    MethodName: 'ProvisionCreateGroup',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionUpdateGroup: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionGroup',
                    MethodName: 'ProvisionUpdateGroup',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionMemberProcessType: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionMember',
                    MethodName: 'ProvisionMemberProcessType',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionUpdateMember: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionMember',
                    MethodName: 'ProvisionUpdateMember',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionUpdateMemberManagers: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionMember',
                    MethodName: 'ProvisionUpdateMemberManagers',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionSetMemberManagersFromEmployeeId: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionMember',
                    MethodName: 'ProvisionSetMemberManagersFromEmployeeId',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionOffBoardMembers: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionMember',
                    MethodName: 'ProvisionOffBoardMembers',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionUpdateMemberUserNames: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionMember',
                    MethodName: 'ProvisionUpdateMemberUserNames',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionUpdateLocationType: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionLocation',
                    MethodName: 'ProvisionUpdateLocationType',
                    FailureAction: 'Report'
                }
            ]
        },
        ProcessNewDepartments: {
            Subscribers: [
                {
                    ServiceName: 'ProvisionDepartment',
                    MethodName: 'ProcessNewDepartments',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionProcessFile: {
            Subscribers: [
                {
                    ServiceName: 'Onboard',
                    MethodName: 'ProcessFile',
                    FailureAction: 'Report'
                }
            ]
        },
        ProvisionItemAddedToQueue: {
            Name: 'ProvisionItemAddedToQueue',
            Subscribers: [
                {
                    ServiceName: 'ProvisionBuilder',
                    MethodName: 'ProcessQueue',
                    FailureAction: 'Report'
                }
            ]
        },
        CreateManagerUpdateQueue: {
            Name: 'CreateManagerUpdateQueue',
            Subscribers: [
                {
                    ServiceName: 'ProvisionBuilder',
                    MethodName: 'CreateManagerUpdateQueue',
                    FailureAction: 'Report'
                }
            ]
        },
        CreateUserNameUpdateQueue: {
            Name: 'CreateUserNameUpdateQueue',
            Subscribers: [
                {
                    ServiceName: 'ProvisionBuilder',
                    MethodName: 'CreateUserNameUpdateQueue',
                    FailureAction: 'Report'
                }
            ]
        },
        CreateMemberOffBoardQueue: {
            Name: 'CreateMemberOffBoardQueue',
            Subscribers: [
                {
                    ServiceName: 'ProvisionBuilder',
                    MethodName: 'CreateMemberOffBoardQueue',
                    FailureAction: 'Report'
                }
            ]
        },
        CreateNewMemberQueue: {
            Name: 'CreateNewMemberQueue',
            Subscribers: [
                {
                    ServiceName: 'ProvisionBuilder',
                    MethodName: 'CreateNewMemberQueue',
                    FailureAction: 'Report'
                }
            ]
        },
        MemberProfileUpdated: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'MemberProfileUpdated',
                    FailureAction: 'Report'
                }
            ]
        },
        MemberOnboarded: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'MemberProfileUpdated',
                    FailureAction: 'Retry'
                }
            ]
        },
        MemberFirstLogin: {
            Subscribers: [
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'MemberFirstLogin',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'FeedbackCycle',
                    MethodName: 'MemberFirstLogin',
                    FailureAction: 'Report'
                }
            ]
        },
        TemplateGoalDeleted: {
            Subscribers: [
                {
                    ServiceName: 'Goal',
                    MethodName: 'TemplateGoalDeleted',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'TemplateGoalDeleted',
                    FailureAction: 'Report'
                }
            ]
        },
        TemplateGoalAssigned: {
            Subscribers: [
                {
                    ServiceName: 'Goal',
                    MethodName: 'TemplateGoalAssigned',
                    FailureAction: 'Report'
                }
            ]
        },
        MemberOffboarded: {
            Subscribers: [
                {
                    ServiceName: 'Track',
                    MethodName: 'MemberOffboarded',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                },
                {
                    ServiceName: 'Performance',
                    MethodName: 'MemberOffboarded',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                },
                {
                    ServiceName: 'Goal',
                    MethodName: 'MemberOffboarded',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                },
                {
                    ServiceName: 'Team',
                    MethodName: 'MemberOffboarded',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                },
                {
                    ServiceName: 'FeedbackSession',
                    MethodName: 'MemberOffboarded',
                    FailureAction: 'Report'//options are Ignore, Retry, Report
                },
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'UpdateMemberOffboarded',
                    FailureAction: 'Retry'
                },
                {
                    ServiceName: 'Recognition',
                    MethodName: 'MemberOffboarded',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Credit',
                    MethodName: 'MemberOffboarded',
                    FailureAction: 'Report'
                }
                // { // this commented out cause the mongo connection times out when it runs
                    // this method needs to be optimized
                //     ServiceName: 'Relevancy',
                //     MethodName: 'MemberOffboarded',
                //     FailureAction: 'Report'
                // }
            ]
        },
        PointsEconomyChanged: {
            Subscribers: [
                {
                    ServiceName: 'Point',
                    MethodName: 'TakeSnapshotEvent',
                    FailureAction: 'Retry'
                }
            ]
        },
        ProductItemAvailable: {
            Subscribers: [
                {
                    ServiceName: 'Recognition',
                    MethodName: 'ProductItemAvailable',
                    FailureAction: 'Ignore'
                }
            ]
        },
        UpdateProductItemAvailable: {
            Subscribers: [
                {
                    ServiceName: 'Recognition',
                    MethodName: 'UpdateProductItemAvailable',
                    FailureAction: 'Ignore'
                }
            ]
        },
        RemarkableRecognitionNumber: {
            DisplayText: 'Remarkable Recognition Number',
            Subscribers: [
                {
                    ServiceName: 'RulesEngine',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'
                }
            ]
        },
        RecognitionRequested: {
            Subscribers: [
                {
                    ServiceName: 'Recognition',
                    MethodName: 'RecognitionRequested',
                    FailureAction: 'Report'
                }
            ]
        },
        RecognitionReceived: {
            Subscribers: [
                {
                    ServiceName: 'Yammer',
                    MethodName: 'BuildBadgeForYammer',
                    FailureAction: 'Retry'
                },
                {
                    ServiceName: 'Slack',
                    MethodName: 'PostBadgeToSlack',
                    FailureAction: 'Retry'
                },
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'RecognitionReceived',
                    FailureAction: 'Report'
                }
            ]
        },
        MemberBookmarked: {
            Subscribers: [
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'MemberBookmarked',
                    FailureAction: 'Report'
                }
            ]
        },
        CongratsReceived: {
            Subscribers: [
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'CongratsReceived',
                    FailureAction: 'Report'
                }
            ]
        },
        CommentReceived: {
            Subscribers: [
                {
                    ServiceName: 'Relevancy',
                    MethodName: 'CommentReceived',
                    FailureAction: 'Report'
                }
            ]
        },
        ReviewsOverdue: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'ReviewsOverdue',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewsClosed: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'ReviewsDeleted',
                    FailureAction: 'Ignore'
                },
                {
                    ServiceName: 'Performance',
                    MethodName: 'ReviewsClosed',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewsDeleted: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'ReviewsDeleted',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewerRemoved: {
            Subscribers: [
                {
                    ServiceName: 'Performance',
                    MethodName: 'ReviewerRemoved',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewDelivered: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'ReviewDelivered',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewUnSubmitted: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'ReviewUnSubmitted',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewSubmitted: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'UpdateOverDueReview',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewRejected: {
            Subscribers: [
                {
                    ServiceName: 'Notification',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'
                },
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'ReviewRejectedOrUnsubmitted',
                    FailureAction: 'Ignore'
                }
            ]
        },
        ReviewRequestEdit: {
            Subscribers: [
                {
                    ServiceName: 'Notification',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'
                }
            ]
        },
        CommentCoaching: {
            Subscribers: [
                {
                    ServiceName: 'Notification',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'
                }
            ]
        },
        IssuePointsToGroup: {
            Subscribers: [
                {
                    ServiceName: 'Point',
                    MethodName: 'IssuePointsToGroupEvent',
                    FailureAction: 'Report'
                }
            ]
        },
        GiftcardOrderSubmitted: {
            Subscribers: [
                {
                    ServiceName: 'Redeem',
                    MethodName: 'GiftcardOrderSubmitted',
                    FailureAction: 'Report'
                }
            ]
        },
        ManualGiftcardOrderSubmitted: {
            Subscribers: [
                {
                    ServiceName: 'Redeem',
                    MethodName: 'ManualGiftcardOrderSubmitted',
                    FailureAction: 'Report'
                }
            ]
        },
        BatchCreated: {
            Subscribers: [
                {
                    ServiceName: 'Batch',
                    MethodName: 'ProcessBatch',
                    FailureAction: 'Report'
                }
            ]
        },
        PerformanceCycleCreated: {
            Subscribers: [
                {
                    ServiceName: 'Performance',
                    MethodName: 'PerformanceCycleCreated',
                    FailureAction: 'Report'
                }
            ]
        },
        AllReviewsClosedInCycle: {
            Subscribers: [
                {
                    ServiceName: 'Performance',
                    MethodName: 'AllReviewsClosedInCycle',
                    FailureAction: 'Report'
                }
            ]
        },
        AllReviewsArchivedInCycle: {
            Subscribers: [
                {
                    ServiceName: 'Performance',
                    MethodName: 'AllReviewsArchivedInCycle',
                    FailureAction: 'Report'
                }
            ]
        },
        PerformanceCycleRevieweeAdded: {
            Subscribers: [
                {
                    ServiceName: 'Performance',
                    MethodName: 'PerformanceCycleRevieweeAdded',
                    FailureAction: 'Report'
                }
            ]
        },
        UploadedGoalCycleParticipants: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'UploadedGoalCycleParticipants',
                    FailureAction: 'Report'
                }
            ]
        },
        AddedAllMembersToGoalCycle: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'GoalCycleParticipantUploadProcessed',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCycleParticipantUploadProcessed: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'GoalCycleParticipantUploadProcessed',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCycleCreated: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'AddDefaultParticipants',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCycleDeleted: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'GoalCycleDeleted',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Goal',
                    MethodName: 'GoalCycleDeleted',//this should archive goals created in that
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'GoalCycleDeleted',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCycleClosed: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'GoalCycleClosed',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Goal',
                    MethodName: 'GoalCycleClosed',//this should close goals created in that
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCyclePublished: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'GoalCyclePublished',
                    FailureAction: 'Report'
                }
            ]
        },
        FeedbackCyclePublished: {
            Subscribers: [
                {
                    ServiceName: 'FeedbackCycle',
                    MethodName: 'FeedbackCyclePublished',
                    FailureAction: 'Report'
                }
            ]
        },
        FeedbackCycleArchived: {
            Subscribers: [
                {
                    ServiceName: 'FeedbackCycle',
                    MethodName: 'FeedbackCycleArchived',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'FeedbackCycleArchivedOrClosed',
                    FailureAction: 'Report'
                }
            ]
        },
        FeedbackCycleClosed: {
            Subscribers: [
                {
                    ServiceName: 'FeedbackCycle',
                    MethodName: 'FeedbackCycleClosed',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'FeedbackCycleArchivedOrClosed',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalSetForCycle: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalSetApproved: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'GoalSetApproved',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCloseRejected: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'GoalCloseRejected',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCloseApproved: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'GoalCloseApproved',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalSetRejected: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'GoalSetRejected',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalSubmittedForSet: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'GoalSubmittedForApproval',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalCreated: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'
                },
                {
                    ServiceName: 'Goal',
                    MethodName: 'GoalCreated',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'FeedbackSession',
                    MethodName: 'GoalCreated',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalKeyResultUpdated: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Recognition',
                    MethodName: 'GoalKeyResultUpdated',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalClosed: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'
                }
            ]
        },
        GoalDeleted: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Goal',
                    MethodName: 'GoalDeleted',
                    FailureAction: 'Report'
                }
            ]
        },
        ManagerSubmittedReview: {
            Subscribers: [
                {
                    ServiceName: 'ManagerAlert',
                    MethodName: 'ManagerSubmittedReview',
                    FailureAction: 'Report'
                }
            ]
        },
        ReportRequestSubmitted: {
            Subscribers: [
                {
                    ServiceName: 'Report',
                    MethodName: 'ProcessReportRequest',
                    FailureAction: 'Ignore'
                }
            ]
        },
        GoalCycleUpdated: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'GoalCycleUpdated',
                    FailureAction: 'Report'
                }
            ]
        },
        ParticipantAddedToCycle: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'ParticipantAddedToCycle',
                    FailureAction: 'Report'
                }
            ]
        },
        ParticipantRemovedFromCycle: {
            Subscribers: [
                {
                    ServiceName: 'GoalCycle',
                    MethodName: 'ParticipantRemovedFromCycle',
                    FailureAction: 'Report'
                },
                {
                    ServiceName: 'Goal',
                    MethodName: 'ParticipantRemovedFromCycle',//this should close goals created in that
                    FailureAction: 'Report'
                }
            ]
        },
        SelectRecapTimeFeatureFlagSwitched: {
            Subscribers: [
                {
                    ServiceName: 'Group',
                    MethodName: 'SelectRecapTimeFeatureFlagSwitched',
                    FailureAction: 'Report'
                }
            ]
        },
        WeeklyRecapDayChanged: {
            Subscribers: [
                {
                    ServiceName: 'Group',
                    MethodName: 'WeeklyRecapDayChanged',
                    FailureAction: 'Report'
                }
            ]
        },
        UserTagged: {
            Subscribers: [
                {
                    ServiceName: 'Notification',
                    MethodName: 'ProcessEvent',
                    FailureAction: 'Ignore'
                }
            ]
        },
        PostYammerMessage: {
            Subscribers: [{
                ServiceName: 'Yammer',
                MethodName: 'PostMessage',
                FailureAction: 'Ignore'
            }]
        }
    },
    Status: {
        New: 0,
        Processing: 0,
        Processed: 0
    },
    SubscriberAuditStatus: {
        Failed: 0,
        Success: 0
    },
    SubscriberAuditAction: {
        Completed: 0,
        Ignore: 0,
        Report: 0,
        Retry: 0,
        ReportFailedRetires: 0
    }
},
    util = require('./EnumsBase.js');
util.SetNames(Enums);
util.SetNames(Enums.EventTypes, 'Name');

Enums.GetEventTypesByServiceName = function (serviceName) {
    return Object.keys(Enums.EventTypes).map(function (key) {
        return Enums.EventTypes[key];
    }).filter(function (eventType) {
        return eventType.Subscribers.filter(function (subscriber) {
            return subscriber.ServiceName === serviceName;// 'RulesEngine';
        }).length;
    });
};

module.exports = Enums;
