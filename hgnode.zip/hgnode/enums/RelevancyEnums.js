/*jslint node:true es5:true*/
'use strict';
var Enums = {
        EntityType: {
            Member: 0,
            Team: 0,
            Department: 0,
            Location: 0
        },
        ActivityType: {
            UserAdd: 0,
            UserRemove: 0,
            SystemAdd: 0,
            SystemRemove: 0
        },
        Features: {//later we can add heuristic weight field for each feature
            GiveReco: 0,
            ReceiveReco: 0,
            InSameReco: 0,
            GiveComm: 0,
            ReceiveComm: 0,
            GiveLike: 0,
            ReceiveLike: 0,
            Bookmark: 0
        },
        MaxRecognitionRecipientNumber: 30,//if recognition's recipient number is greater than this, skip it
        HrisApproximatyThreshold: 2
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
