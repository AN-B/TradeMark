/*jslint node:true es5:true*/
'use strict';
var Enums = {
        hgcommon: 0,
        hgsecurity: 0,
        hgthanka: 0,
        hgperka: 0,
        hgfinance: 0,
        hgperform: 0,
        hgreports: 0,
        hglog: 0
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
