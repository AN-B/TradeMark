/*jslint node:true es5:true*/
'use strict';
var Enums = {
    TriggerTimingType: {
        Immediate: 0,
        BeforeReset: 0
    },
    TriggerConditionType: {
        ByValue: 0,
        ByRanking: 0
    },
    RuleSubjectType: {
        Member: 0,//single member
        AdHocMembers: 0,//not implemented
        Team: 0,
        Group: 0,
        System: 0//the entire system
    },
    RulesEngineAction: {
        GiveRecognition: 0,
        SendNotification: 0
    },
    ThresholdOperator: {
        Equals: 0,
        LessThan: 0,
        LessThanOrEquals: 0,
        GreaterThan: 0,
        GreaterThanOrEquals: 0,
        EachTime: 0,
        Zero: 0
    },
    DeltaType: {
        CountUp: 0,
        CountDown: 0,
        Overwrite: 0
    },
    DeltaValue: {
        ActualValue: 0,
        SingleTick: 0
    },
    ResetInterval: {
        None: 0,
        DateRange: 0,
        Daily: 0,
        Weekly: 0,
        BiWeekly: 0,
        Monthly: 0,
        BiMonthly: 0,
        Quarterly: 0,
        SemiAnnual: 0,
        Yearly: 0
    },
    AllowedInterval: {
        Lifetime: 0,//for a member, one condition in this rule can only trigger once
        None: 0,//no limit in interval, this rule can trigger as frequent as the condition matches
        Every5Minutes: 0,
        Every10Minutes: 0,
        Every30Minutes: 0,
        TwiceADay: 0,
        Daily: 0,
        Weekly: 0,
        BiWeekly: 0,
        Monthly: 0,
        BiMonthly: 0,
        Quarterly: 0,
        SemiAnnual: 0,
        Yearly: 0
    },
    Status: {
        Active: 0,
        Archived: 0
    }
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
