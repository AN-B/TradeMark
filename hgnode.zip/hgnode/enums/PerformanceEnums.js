/*jslint node:true es5:true*/
'use strict';
var Enums = {
        ReviewStatus: {
            PendingDelivery: 0,
            NotStarted: 0,
            InProgress: 0,
            Submitted: 0,
            WaitingForSignOff: 0,
            Overdue: 0,
            Archived: 0,
            Closed: 0,
            Completed: 0
        },
        ParticipantStatus: {
            PendingDelivery: 0,
            NA: 0,
            NotStarted: 0,
            InProgress: 0,
            ReadyToSubmit: 0,
            Submitted: 0,
            SignedOff: 0,
            Overdue: 0,
            Closed: 0
        },
        DeliveryTriggerType: {
            Submission: 0,
            Date: 0
        },
        DefaultPeopleTypes: {
            Subject: 0,
            Manager: 0,
            Peer: 0,
            Admin: 0,
            NA: 0
        },
        CardStatus: {
            Draft: 0,
            ReadyToAssign: 0,
            Archived: 0
        },
        CardType: {
            General: 0,
            Project: 0
        },
        Drafts: 0
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
