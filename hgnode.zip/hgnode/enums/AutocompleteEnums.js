/*jslint node:true es5:true*/
'use strict';
var Enums = {
        Entity: {
            Member: 0,
            Group: 0,
            Team: 0,
            SurveyDriver: 0,
            GoalCycle: 0,
            FeedbackCycle: 0,
            Department: 0,
            Location: 0,
            RecognitionDepartment: 0,
            RecogntionLocation: 0,
            MembersWithDirectReports: 0,
            MobileMember: 0,
            MobileDepartment: 0,
            MobileLocation: 0
        },
        SearchWeight: {
            Manager: 0.75,
            Department: 0.50,
            Location: 0.25
        }
    };
Enums.SearchProximityProjection = function (params) {
    var p = {};
    Object.keys(params).forEach(function (item) {
        p[item] = 1;
    });
    if (!p.hgId) {
        p.hgId = 1;
    }
    if (!p.FullName) {
        p.FullName = 1;
    }
    if (!p.EmployeeId) {
        p.EmployeeId = 1;
    }
    p.ProximityScore = {$add: ["$LocationScore", "$DepartmentScore", "$ManagerScore"]};
    return p;
};

Enums.SearchProjection = function (params, projection) {
    projection = projection || {};
    projection.DepartmentScore = {
        $cond: {
            if: { $eq: ["$GroupDepartmentId", params.DepartmentId]},
            then: Enums.SearchWeight.Department,
            else: 0
        }
    };
    projection.ManagerScore = {
        $cond: [
            {
                $anyElementTrue: {
                    $map: {
                        input: params.ManagerIds || [],
                        as: "el",
                        in: { $eq: [ "$$el", "$MyManagers.MemberId" ] }
                    }
                }
            },
            Enums.SearchWeight.Manager,
            0
        ]
    };
    projection.LocationScore = {
        $cond: {
            if: { $eq: ["$Location.hgId", params.LocationId]},
            then: Enums.SearchWeight.Location,
            else: 0
        }
    };
    return projection;
};
Enums.RepackGroup = function (projection) {
    var g = {};
    projection = projection || {};
    Object.keys(projection).forEach(function (item) {
        g[item] = '$' + item;
    });
    g.ProximityScore = "$ProximityScore";
    return {
        _id: g
    };
};

Enums.RepackProjection = function (projection) {
    var p = {};
    Object.keys(projection).forEach(function (item) {
        p[item] = '$_id.' + item;
    });
    p.ProximityScore = "$_id.ProximityScore";
    return p;
};

require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
