/*jslint node:true es5:true*/
'use strict';
var Enums = {
    Type: {
        Recognition: 0,
        KeyResult: 0,
        Objective: 0,
        Milestone: 0,
        Skill: 0,
        Award: 0,
        Context: 0,
        Thanks: 0,
        Quick: 0,
        Congrats: 0,
        Newsfeed: 0,
        ProductItem: 0,
        PollResult: 0,
        GoalKeyResultUpdate: 0
    },
    Mode: {
        RegularEveryday: 0,
        CustomizedEveryday: 0,
        Values: 0,
        Achievement: 0
    },
    TemplateType: {
        Recognition: 0,
        KeyResult: 0,
        Objective: 0,
        Milestone: 0,
        Skill: 0,
        Award: 0,
        Context: 0,
        Thanks: 0,
        Quick: 0,
        Congrats: 0,
        Newsfeed: 0,
        ProductItem: 0,
        PollResult: 0,
        News: 0, //default templates types
        Poll: 0, //default templates types
        Welcome: 0, //default templates types
        Birthday: 0, //default templates types
        Anniversary: 0 //default templates types
    },
    AccessLevel: {
        Individual: 0,
        WithinTeam: 0,
        WithinGroup: 0
    },
    Publicity: {
        Private: 0,
        Public: 0,
        Both: 0
    },
    RecognitionCategory: {
        Everyday: 0,
        Achievement: 0,
        Values: 0,
        System: 0
    },
    RecognitionSubCategory: {
        Default: 0,
        Custom: 0,
        TrackCompletion: 0,
        Welcome: 0,
        Birthday: 0,
        Anniversary: 0,
        ServiceAward: 0
    },
    Status: {
        Active: 0,
        Archive: 0,
        Deleted: 0,
        PendingApproval: 0
    },
    GiftType: {
        Group: 0,
        Individual: 0
    },
    SharesDest: {
        LinkedIn: 0,
        Facebook: 0
    },
    SharesStatus: {
        Failed: 0,
        Successful: 0
    },
    Source: {
        Web: 0,
        RulesEngine: 0,
        Mobile: 0
    },
    OperationType: {
        RedeemGiftcard: 0,
        GiveRecognition: 0,
        AddPoints: 0,
        TransferCredit: 0,
        Recognition: 0
    },
    GetType: {
        MineOnly: 0,
        Team: 0,
        CurrentGroup: 0,
        AdvancedSearch: 0,
        Location: 0
    }
},
    util = require('./EnumsBase.js');
util.SetNames(Enums);

Enums.DEFAULT_API_TAKE = 50;
Enums.GetTypesExceptExcluded = function (types) {
    return Object.keys(Enums.Type).filter(function (item) {
        return types.indexOf(item) === -1;
    });
};

module.exports = Enums;
