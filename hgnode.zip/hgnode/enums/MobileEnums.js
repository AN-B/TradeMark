/*jslint node:true es5:true*/
'use strict';
var Enums = {
        Version: {
            V1_15: 101500
        }
    };

module.exports = Enums;
