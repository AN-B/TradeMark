/*jslint node:true es5:true*/
'use strict';
var Enums = {
    Get: 'get',
    GetId: 'getid',
    Put: 'put',
    PutId: 'putid',
    Delete: 'delete',
    DeleteId: 'deleteid',
    Post: 'post'
};

module.exports = Enums;