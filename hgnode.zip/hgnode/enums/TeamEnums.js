/*jslint node:true es5:true*/
'use strict';
var TeamEnums = {
    APITeamErrorCode: {
        DepartmentIdNotFound: 'Department Id does not exist.',
        LocationIdNotFound: 'Location Id does not exist.'
    }
};

module.exports = TeamEnums;