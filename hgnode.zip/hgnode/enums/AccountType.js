/*jslint node:true es5:true*/
'use strict';
var Enums = {
        Spend: 'SPND',
        EarmarkSpend: 'ESPN',
        Transfer: 'TRFR',
        EarmarkTransfer: 'ETFR',
        PointSpend: 0,
        PointTransfer: 0,
        ClientStrings: {
            SpendType: 'spend',
            TransferType: 'transfer',
            GiveTransfer: 'Give',
            SpendTransfer: 'Spend'
        }
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
