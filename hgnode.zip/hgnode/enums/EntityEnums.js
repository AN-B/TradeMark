/*jslint node:true es5:true*/
'use strict';
var util = require('./EnumsBase.js'),
    Enums = {
        LogglyFilterType: {
            ProfanityBannedWords: 0,
            HRISFileMissingEmail: 0
        },
        ProfanityWordStatus: {
            Active: 0,
            Deleted: 0
        },
        OffBoardMemberCheckList: {
            DepartmentOwner: 0,
            CompanyGoalOwner: 0,
            DepartmentGoalOwner: 0,
            MemberGoalApprover: 0,
            GoalCycleAdmin: 0,
            PointAdmin: 0,
            CreditAdmin: 0
        },
        NewsStatus: {
            Tentative: 0,
            Final: 0,
            Deleted: 0
        },
        ApprovalEntityType: {
            PerformanceReview: 0
        },
        ConversationStatus: {
            Active: 0,
            Deleted: 0,
            Draft: 0,
            Pending: 0,
            Archived: 0
        },
        ConversationType: {
            FeedForward: 0,
            Feedback: 0
        },
        ReleaseMethod: {
            ReleaseDate: 0,
            SignOff: 0
        },
        MilestoneStatus: {
            NotStarted: 0,
            InProgress: 0,
            OverDue: 0,
            Cancelled: 0,
            RequestComplete: 0,
            Completed: 0,
            Closed: 0
        },
        LastReasonCode: {
            Blank: util.EMPTY_VALUE,
            None: 0,
            Question: 0,
            RequestExtension: 0,
            Close: 0,
            Cancel: 0
        },
        AuditLevelType: {
            All: 0,
            OnSuccess: 0,
            OnFailure: 0,
            None: 0
        },
        CollaboratorsAccessLevel: {
            Observer: 0,
            Writer: 0,
            Manager: 0
        },
        SpecialUsages: {
            Everyday: 0,
            Tracks: 0,
            CustomizedEveryday: 0,
            CustomizedRecognition: 0,
            ValuesIcon: 0,
            LevelBorder: 0,
            Achievement: 0,
            Background: 0,
            AchievementBackground: 0
        },
        BadgeDefaults: {
            Goal: 0,
            Objective: 0,
            Milestone: 0,
            Welcome: 0,
            Birthday: 0,
            Anniversary: 0,
            News: 0
        },
        CommentStatus: {
            Active: 0,
            Archived: 0,
            Deleted: 0,
            Draft: 0
        },
        CommentEntityType: {
            Batch: 0,
            Recognition: 0,
            Milestone: 0,
            Coaching: 0,
            Comment: 0,
            Conversation: 0,
            NA: 0,
            Goal: 0,
            ManagerCheckIn: 0
        },
        CommentType: {
            KeyResultUpdate: 0,
            Comment: 0,
            AddPoints: 0,
            Coaching: 0,
            Gift: 0
        },
        GiftType: {
            Individual: 0,
            Group: 0
        },
        NotificationType: {
            General: 0,
            Events: 0,
            OverdueAlerts: 0,
            Transactions: 0
        },
        NotificationSubType: {
            CommentReceived: 0,
            GiftReceived: 0,
            CongratsReceived: 0,
            CollaboratorAdded: 0,
            SkillAssigned: 0,
            MilestoneStatusChanged: 0,
            CreditsRedeemed: 0,
            GoalOverdue: 0,
            MilestoneOverdue: 0,
            Welcome: 0,
            Birthday: 0,
            Anniversary: 0
        },
        RewardItemPeriod: {
            Daily: 0,
            Weekly: 0,
            Monthly: 0,
            Quarterly: 0,
            Annual: 0
        },
        ProductOrderStatus: {
            Ordered: 0,
            Cancelled: 0,
            Fulfilled: 0,
            PendingAdminApprove: 0
        },
        RewardStatus: {
            Ordered: 0,
            Denied: 0,
            Booked: 0,
            UserCancelled: 0,
            AdminCancelled: 0,
            Fulfilled: 0,
            Expired: 0
        },
        TrackStatus: {
            Created: 0,
            Modified: 0,
            Assigned: 0,
            Partial: 0,
            RequestComplete: 0,
            Completed: 0,
            Void: 0,
            Closed: 0
        },
        AnswerTypes: {
            Paragraph: 0,
            ShortText: 0,
            Templated: 0,
            RecognitionDiscussion: 0,
            Goal: 0,
            ScaleRating: 0,
            RadioButton: 0,
            CheckBox: 0,
            Option: 0
        },
        TagEntities: {
            Recognition: 0,
            Cycle: 0,
            Track: 0,
            MyEmployee: 0,
            ProductItem: 0
        },
        ProvisionBatchType: {
            ImportCustomer: 0,
            ImportBadge: 0,
            ImportGiftcard: 0,
            ImportQuestion: 0
        },
        ProvisionBatchStatus: {
            InProgress: 0,
            Successful: 0,
            Failed: 0,
            Aborted: 0,
            Suspended: 0
        },
        ProvisionCompanyMessageType: {
            Info: 0,
            Warning: 0,
            Error: 0
        },
        ProvisionMessageType: {
            Info: 0,
            Warning: 0,
            Error: 0
        },
        ProvisionCompanySheet: {
            Name: 0,
            Address1: 0,
            Address2: 0,
            City: 0,
            State: 0,
            Zip: 0,
            MainPhone: 0,
            MainFax: 0,
            BillingRep: 0,
            BillingAddress1: 0,
            BillingAddress2: 0,
            BillingCity: 0,
            BillingState: 0,
            BillingZip: 0,
            BillingPhone: 0,
            BillingEmail: 0,
            BillMeAllowed: 0,
            CreditLimit: 0,
            HGAdmin: 0,
            TeamOwner: 0,
            FileType: 0
        },
        ProvisionEmployeeSheet: {
            FirstName: 0,
            LastName: 0,
            FullName: 0,
            UserName: 0,
            Email: 0,
            Password: 0,
            StartDate: 0,
            BirthDate: 0,
            EmpID: 0,
            Department: 0,
            Role: 0,
            Position: 0,
            HomeZip: 0,
            WorkZip: 0,
            Manager: 0,
            ManagerEmail: 0,
            NewUserName: 0,
            Location: 0
        },
        ProvisionOffBoardEmployeeSheet: {
            FirstName: 0,
            LastName: 0,
            Email: 0,
            OffBoardType: 0
        },
        ProvisionBadgeSheet: {
            BadgeName: 0,
            Filename: 0,
            Tags: 0,
            Category: 0,
            Federated: 0,
            SpecialUsages: 0
        },
        ProvisionTangoCardSheet: {
            Card: 0,
            EmailTemplateId: 'Email Template Id',
            ImageUrl: 0,
            Type: 0,
            Country: 0
        },
        ProvisionTangoDenomSheet: {
            Card: 0,
            Description: 0,
            SKU: 0,
            Denomination: 0,
            Min: 0,
            Max: 0,
            Currency: 0
        },
        TangoTypes: {
            Auto: 0,
            Manual: 0,
            US: 0,
            Global: 0
        },
        MembershipStatus: {
            Active: 0,
            InActive: 0,
            PendingAdminApprove: 0,
            PendUserAccept: 0,
            UserReject: 0,
            Denied: 0,
            Suspended: 0,
            OffBoarded: 0
        },
        MembersRoleInGroup: {
            OffBoarded: 0,
            Employee: 0,
            Consultant: 0,
            Manager: 0,
            Director: 0,
            Executive: 0,
            Admin: 0,
            Owner: 0,
            HGAdmin: 0
        },
        AutoCompleteEntityType: {
            Member: 0,
            Department: 0,
            Group: 0,
            Location: 0
        },
        GroupStatus: {
            Active: 0,
            Disabled: 0
        },
        TeamType: {
            Pod: 0,
            Location: 0,
            Department: 0
        },
        TeamStatus: {
            Deleted: 0,
            Active: 0
        },
        ActionTokenStatus: {
            Pending: 0,
            Fullfilled: 0,
            Expired: 0
        },
        ActionTokenType: {
            UserActivation: 0,
            MemberInvitation: 0,
            PasswordReset: 0,
            ExportGroupData: 0,
            MobileAuth: 0
        },
        ActionTokenEntity: {
            Member: 0
        },
        ProvisionActivityEntity: {
            Group: 0,
            UserInfo: 0,
            Member: 0,
            Badge: 0,
            RecognitionTemplate: 0,
            CareerTrackTemplate: 0,
            Giftcard: 0
        },
        ProvisionActivityType: {
            GroupCreated: 0,
            GroupUpdated: 0,
            UserAdded: 0,
            UserUpdated: 0,
            MemberAdded: 0,
            MemberUpdated: 0,
            MemberOffboarded: 0,
            MemberAddedNotificationPending: 0,
            MemberOffboardScheduled: 0,
            BadgeAdded: 0,
            RecognitionTemplateAdded: 0,
            TrackTemplateAdded: 0,
            GiftcardAdded: 0
        },
        ProvisionActivityNotificationType: {
            Pending: 0,
            Sent: 0
        },
        ProvisionActivityStatus: {
            Pending: 0,
            Successful: 0,
            Failed: 0
        },
        ProvisionGroupFileType: {
            New: 0,
            Update: 0,
            OffBoard: 0
        },
        OffBoardType: {
            Voluntary: 0,
            InVoluntary: 0,
            Unknown: 0,
            NotApplicable: 0
        },
        RecognitionRequestMode: {
            RegularEveryday: 0,
            CustomizedEveryday: 0,
            Achievement: 0,
            Values: 0
        },
        RecognitionCategory: {
            Everyday: 0,
            Achievement: 0,
            Values: 0,
            System: 0
        },
        RecognitionSubCategory: {
            Default: 0,
            Custom: 0,
            TrackCompletion: 0,
            Welcome: 0,
            Birthday: 0,
            Anniversary: 0,
            ServiceAward: 0
        },
        MetricsDepartmentCategory: {
            RecognitionGiven: 0,
            TracksCreated: 0,
            TracksCompleted: 0,
            TracksClosed: 0,
            TracksCancelled: 0,
            TrackDeletedMilestone: 0,
            TrackRestoredMilestone: 0,
            TrackClosedMilestone: 0,
            TrackCompletedMilestone: 0,
            CoachingGiven: 0,
            Reviewed: 0
        },
        MetricsMemberCategory: {
            RecognitionGiven: 0,
            RecognitionReceived: 0,
            RecognitionDeleted: 0,
            CommentsMade: 0,
            CommentsDeleted: 0,
            CongratsGiven: 0,
            CommentsCongratsGiven: 0,
            NewsCongratsGiven: 0,
            ProductCongratsGiven: 0,
            GiftCongratsGiven: 0,
            CongratsDeleted: 0,
            TracksCreated: 0,
            TracksAssigned: 0,
            TracksCompleted: 0,
            TracksClosed: 0,
            TracksCancelled: 0,
            LinkedInShares: 0,
            TrackContributorUpdate: 0,
            TrackEdited: 0,
            TrackProgressUpdate: 0,
            TrackDeletedMilestone: 0,
            TrackRestoredMilestone: 0,
            TrackClosedMilestone: 0,
            TrackCompletedMilestone: 0,
            CoachingPlainNotes: 0,
            CoachingTrackLinkedNotes: 0,
            CoachingPrivatePlainNotes: 0,
            CoachingPrivateTrackLinkedNotes: 0,
            CoachingReceived: 0,
            Reviewed: 0,
            UnsubmitReview: 0,
            SubmittedReview: 0,
            SubmittedReviewAsManager: 0,
            SubmittedReviewAsPeer: 0,
            CreatedCard: 0,
            EditedCard: 0,
            DuplicatedCard: 0,
            DeletedCard: 0,
            GenerateReviewPdf: 0,
            DeletedReview: 0,
            DeliverCard: 0,
            UserSubmittedReview: 0,
            UserClosedReview: 0,
            UserArchivedReview: 0,
            UserExportedCycleContent: 0,
            UserPerformCycleReminder: 0,
            FavoriteMember: 0,
            UnfavoriteMember: 0,
            FavoriteTeam: 0,
            UnfavoriteTeam: 0,
            FavoriteLocation: 0,
            UnfavoriteLocation: 0,
            UnPinNews: 0,
            DeleteNews: 0,
            AddedNews: 0,
            DismissNews: 0,
            ReviewsSubmittedAboutMe: 0,
            ClickedFavoriteMember: 0,
            MintPoints: 0,
            IssuePointsToGroup: 0,
            AdminTransferPoints: 0,
            CreateProductItem: 0,
            UpdateProductItem: 0,
            DeleteProductItem: 0,
            UpdateProductItemImage: 0,
            FulfillOrder: 0,
            CancelOrder: 0,
            PlaceItemOrder: 0,
            PlaceGiftOrder: 0,
            GaveFeedBack: 0,
            ReceivedFeedBack: 0,
            IRequestedFeedBack: 0,
            WasRequestedForFeedBack: 0,
            RejectedFeedBack: 0,
            ViewedMemberExcerpt: 0,
            AdminViewedMemberProfile: 0,
            UpdatedGoalProgressStatus: 0,
            RecognitionGivenReminder: 0
        },
        MetricsCoachingCategory: {
            PlainNotes: 0,
            TrackLinkedNotes: 0,
            PrivatePlainNotes: 0,
            PrivateTrackLinkedNotes: 0
        },
        MetricsPerformCategory: {
            Submitted: 0,
            Archived: 0,
            Closed: 0,
            UnsubmitReview: 0,
            DeliverCard: 0
        },
        MetricsTrackCategory: {
            Created: 0,
            Closed: 0,
            Completed: 0,
            Cancelled: 0,
            Delegated: 0,
            ContributorUpdate: 0,
            Edited: 0,
            ProgressUpdate: 0,
            DeletedMilestone: 0,
            RestoredMilestone: 0,
            ClosedMilestone: 0,
            CompletedMilestone: 0
        },
        MetricsCongratCategory: {
            Recognition: 0,
            News: 0,
            Comment: 0,
            ProductItem: 0,
            Gift: 0
        },
        MetricsUpdateType: {
            User: 0,
            Recognition: 0,
            Comment: 0,
            Likes: 0,
            Shares: 0,
            Track: 0,
            Coaching: 0,
            Perform: 0
        },
        CongratStatus: {
            Active: 0,
            Deleted: 0
        },
        DataExportStatus: {
            InProgress: 0,
            MailSent: 0,
            Downloaded: 0,
            Expired: 0
        },
        ProductItemStatus: {
            Active: 0,
            Draft: 0,
            Archived: 0,
            ApprovalPending: 0,
            Fulfilled: 0
        },
        ProductItemType: {
            Store: 0,
            Campaign: 0
        },
        TransactionUnitType: {
            Credit: 0,
            Point: 0
        },
        RecognitionSource: {
            Internal: 0,
            External: 0,
            Both: 0
        },
        FeedSearchStatus: {
            Active: 0,
            Deleted: 0
        },
        ManagerAlertCategory: {
            Perform: 0,
            Recognition: 0,
            Coaching: 0,
            Profile: 0,
            Goals: 0,
            Feedback: 0
        },
        FriendlyEntityType: {
            Group: 0
        },
        ManagerAlertType: {
            ProfileUpcomingBirthday: 0,
            ProfileUpcomingAnniversary: 0,
            PerformPendingReview: 0,
            PerformOverDueReview: 0,
            PerformLastReview: 0,
            RecognitionLastReceived: 0,
            RecognitionLastGiven: 0,
            CoachingLastGiven: 0,
            CoachingLastReceived: 0,
            GoalCreationOverdue: 0,
            GoalPendingCreationApproval: 0,
            RecognitionsIGave: 0,
            RecognitionsIReceived: 0,
            CoachingIGave: 0,
            CoachingIReceived: 0,
            FeedbackIReceived: 0,
            GoalCloseOverdue: 0,
            GoalPendingCloseApproval: 0,
            FeedbackCheckInDue: 0
        },
        ManagerAlertSeverity: {
            Urgent: 0,
            Warning: 0,
            Upcoming: 0
        },
        ManagerAlertStatus: {
            Active: 0,
            Deleted: 0,
            Completed: 0,
            Dismissed: 0,
            Processing: 0
        },
        FeedBackType: {
            Requested: 0,
            Given: 0
        },
        RecapType: {
            Daily: 0,
            Weekly: 0
        },
        ValueRecognitionLevelPrime: {
            PlatinumPrime: 5,
            GoldPrime: 3,
            SilverPrime: 2
        },
        WishListItemStatus: {
            Deleted: 0,
            Active: 0,
            Fulfilled: 0,
            Expired: 0
        },
        WishListItemType: {
            ProductItem: 0
        },
        WeekDays: {
            Monday: 0,
            Tuesday: 0,
            Wednesday: 0,
            Thursday: 0,
            Friday: 0,
            Saturday: 0,
            Sunday: 0
        },
        Source: {
            Web: 0,
            Mobile: 0
        },
        ProfileAccess: {
            Admin: 0,
            Manager: 0,
            User: 0,
            None: 0
        },
        RoleStatus: {
            Active: 0,
            InActive: 0
        },
        All: 0,
        MemberIdConstantHashSalt: 'Gus', //DO NOT CHANGE THIS
        PusherOperations: {
            Comment: {
                Delete: 'delete'
            }
        },
        YammerGroupCount: 25,
        YammerEmailType: 'primary'
    };
util.SetNames(Enums);

module.exports = Enums;
