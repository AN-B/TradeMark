/*jslint node:true es5:true*/
'use strict';
var Enums = {
    Status: {
        FileUploaded: 0,
        StagingFile: 0,
        FileStaged: 0,
        FilePreValidation: 0,
        ValidatingFile: 0,
        FileValidated: 0,
        FileConfirmed: 0,
        ProcessingFile: 0,
        FileProcessed: 0,
        FileAbandoned: 0
    },
    ProcessStepStatus: {
        NotStarted: 0,
        BeginProcessing: 0,
        Processing: 0,
        Processed: 0
    },
    ProcessMemberStep: {
        NotStarted: 0,
        UserCreationAndUpdate: 0,
        ManagerUpdate: 0,
        ManagerUserNameUpdate: 0,
        NewUserName: 0,
        OffBoard: 0
    },
    QueueSteps: {
        Onboard: {
            Steps: [
                {Value: 1, Step: 'CreateManagerUpdateQueue'}
            ]
        },
        Update: {
            Steps: [
                {Value: 1, Step: 'CreateNewMemberQueue'},
                {Value: 2, Step: 'CreateManagerUpdateQueue'},
                {Value: 3, Step: 'CreateUserNameUpdateQueue'}
            ]
        },
        APIOnboard: {
            Steps: [
                {Value: 1, Step: 'CreateNewMemberQueue'},
                {Value: 2, Step: 'CreateManagerUpdateQueue'}
            ]
        },
        APIUpdate: {
            Steps: [
                {Value: 1, Step: 'CreateNewMemberQueue'},
                {Value: 2, Step: 'CreateManagerUpdateQueue'}
            ]
        },
        APISendWelcomeEmail: {
            Steps: []
        },
        HRIS: {
            Steps: [
                {Value: 1, Step: 'CreateNewMemberQueue'},
                {Value: 2, Step: 'CreateManagerUpdateQueue'},
                {Value: 3, Step: 'CreateUserNameUpdateQueue'},
                {Value: 4, Step: 'CreateMemberOffBoardQueue'}
            ]
        }
    },
    ProcessType: {
        New: 0,
        Update: 0
    },
    Type: {
        Onboard: 0,
        Update: 0,
        OffBoard: 0,
        APIOnboard: 0,
        APIUpdate: 0,
        APIOffboard: 0,
        APISendWelcomeEmail: 0,
        HRIS: 0
    },
    QueueStatus: {
        New: 'New',
        Processing: 'Processing',
        Processed: 'Processed'
    },
    QueueType: {
        MemberAdded: 0,
        MemberUpdate: 0,
        MemberOffBoard: 0,
        MemberManagerUpdate: 0,
        MemberUserNameUpdate: 0,
        SendMemberWelcomeEmail: 0
    },
    QueueSource: {
        HRIS: 0,
        API: 0,
        WEB: 0
    },
    ProvisionCompanySheet : {
        Name: 0,
        Address1: 0,
        Address2: 0,
        City: 0,
        State: 0,
        Zip: 0,
        MainPhone: 0,
        MainFax: 0,
        BillingRep: 0,
        BillingAddress1: 0,
        BillingAddress2: 0,
        BillingCity: 0,
        BillingState: 0,
        BillingZip: 0,
        BillingPhone: 0,
        BillingEmail: 0,
        BillMeAllowed: 0,
        CreditLimit: 0,
        FileType: 0,
        HideWelcomeBadge: 0,
        DisableTutorial: 0
    },
    ProvisionEmployeeSheet: {
        Row: 0,
        FirstName: 0,
        LastName: 0,
        FullName: 0,
        UserName: 0,
        Email: 0,
        StartDate: 0,
        BirthDate: 0,
        SuppressBirthday: 0,
        SuppressAnniversary: 0,
        EmpID: 0,
        Department: 0,
        Role: 0,
        Position: 0,
        HomeZip: 0,
        WorkZip: 0,
        Manager: 0,
        ManagerUserName: 0,
        Location: 0,
        NewUserName: 0
    },
    ProvisionLocationSheet: {
        Row: 0,
        Name: 0,
        Description: 0,
        Address1: 0,
        Address2: 0,
        City: 0,
        State: 0,
        ZipCode: 0,
        Country: 0,
        Phone: 0,
        LocationCode: 0,
        Language: 0,
        TimeZone: 0
    },
    ProvisionHRISFields: {
        Row: {required: false},
        FirstName: {required: true},
        LastName: {required: true},
        FullName: {required: true},
        UserName: {required: true},
        NewUserName: {required: true},
        Email: {required: true},
        Password: {required: false},
        StartDate: {required: true},
        BirthDate: {required: true},
        EmpID: {required: true},
        Department: {required: true},
        DepartmentCode: {required: false},
        Role: {required: true},
        Position: {required: true},
        JobLevel: {required: false},
        JobCode: {required: false},
        HomeCountry: {required: false},
        HomeZip: {required: true},
        WorkZip: {required: true},
        ManagerUserName: {required: true},
        ManagerEmpID: {required: false},
        Location: {required: true},
        SuppressBirthday: {required: true},
        SuppressAnniversary: {required: true},
        OffBoardType: {required: true},
        OffBoardDate: {required: true},
        BenefitStatus: {required: false},
        MailCD: {required: false},
        UnionCode: {required: false},
        MileagePlus: {required: false}
    },
    ProvisionOffBoardEmployeeSheet: {
        Row: 0,
        FirstName: 0,
        LastName: 0,
        UserName: 0,
        OffBoardType: 0,
        NotificationEmail: 0,
        OffBoardDate: 0
    },
    ProvisionActivityType: {
        GroupCreated: 0,
        GroupUpdated: 0,
        UserAdded: 0,
        UserUpdated: 0,
        MemberAdded: 0,
        MemberUpdated: 0,
        MemberOffboarded: 0,
        MemberAddedNotificationPending: 0,
        MemberOffboardScheduled: 0,
        BadgeAdded: 0,
        RecognitionTemplateAdded: 0,
        TrackTemplateAdded: 0,
        GiftcardAdded: 0
    },
    ProvisionActivityEntity: {
        Group: 0,
        UserInfo: 0,
        Member: 0,
        Badge: 0,
        RecognitionTemplate: 0,
        CareerTrackTemplate: 0,
        Giftcard: 0
    },
    ProvisionActivityNotificationType: {
        Pending: 0,
        Sent: 0
    },
    DefaultTransferItems: {
        Profile: 'No',
        Points: 'No',
        Credits: 'No',
        Goals: 'Yes',
        Tracks: 'Yes',
        Perform: 'Yes'
    },
    ProvisionActivityStatus: {
        Pending: 0,
        Successful: 0,
        Failed: 0,
        Archived: 0
    },
    DefaultBadgeTexts: {
        Objective: {
            Title: '10 Year Service',
            Filename: '10yearservicebadge.svg',
            Message: '10 Year Service',
            Description: ''
        },
        Milestone: {
            Title: '15 Year Service',
            Filename: '15yearservicebadge.svg',
            Message: '15 Year Service',
            Description: ''
        },
        Welcome: {
            Title: 'Welcome On-Board',
            Filename: 'welcomebadge.svg',
            Message: 'Welcome On-Board from ',
            Description: ''
        },
        Birthday: {
            Title: 'Happy Birthday',
            Filename: 'packagebadge.svg',
            Message: 'Happy Birthday from ',
            Description: ''
        },
        Anniversary: {
            Title: 'Happy Anniversary',
            Filename: 'perfectattendancebadge.svg',
            Message: 'Happy Anniversary from ',
            Description: ''
        },
        News: {
            Title: 'News Badge',
            Filename: 'perfectattendancebadge.svg',
            Message: '',
            Description: ''
        },
        Poll: {
            Title: 'Poll Badge',
            Filename: 'IconBeanCounter.svg',
            Message: '',
            Description: ''
        }
    },
    HrisDefaultFieldValues: {
        SuppressBirthday: 'FALSE',
        SuppressAnniversary: 'FALSE'
    },
    HRISPickupNote: 'This file was automatically picked up from the sftp server location'
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
