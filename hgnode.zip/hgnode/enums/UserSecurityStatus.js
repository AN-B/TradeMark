/*jslint node:true es5:true*/
'use strict';
var Enums = {
    Active: 0,
    InActive: 0,
    PasswordChangeRequired: 0,
    Suspended: 0,
    LockedOut: 0
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;