/*jslint node:true es5:true*/
'use strict';
var Enums = {
    Status: {
        Active: 0,
        Archived: 0,
        Deleted: 0
    },
    Type: {
        Email: 0,
        Pulse: 0,
        Benchmark: 0,
        Poll: 0
    }
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
