/*jslint node:true es5:true*/
'use strict';
var Enums = {
        Event: {
            GoalCycleBatchDelivered: 0,
            GoalCycleBuilt: 0,
            GoalCycleParticipantUploadProcessed: 0,
            GoalCycleParticipantUploadError: 0
        }
    };
require('./EnumsBase.js').SetNames(Enums.Event);
module.exports = Enums;
