/*jslint node:true es5:true*/
'use strict';
var Enums = {
        Daily: 'DAILY',
        Weekly: 'WEEKLY',
        Aggregate: 'AGGR'
    };
module.exports = Enums;
