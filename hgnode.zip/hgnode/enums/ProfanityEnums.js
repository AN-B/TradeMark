/*jslint node:true es5:true*/
'use strict';
var Enums = {
    EntityTypes: {
        News: {
            Lang: ['en'],
            Fields: [
                'Title',
                'Body'
            ]
        },
        Comment: {
            Lang: ['en'],
            Fields: [
                'Comment'
            ]
        },
        Recognition: {
            Lang: ['en'],
            Fields: [
                'Message'
            ]
        },
        RecognitionTemplate: {
            Lang: ['en'],
            Fields: [
                'Title',
                'Description',
                'Message'
            ]
        }
    }
},
    util = require('./EnumsBase.js');

util.SetNames(Enums.EntityTypes, 'Name');
module.exports = Enums;