/*jslint node:true es5:true*/
'use strict';

module.exports = function (params) {
    var directReports = [
        {
            RolesInGroup: ['Employee'],
            Birthdate: 1200614400000,
            StartingDate: 1421539200000,
            MembershipStatus: 'Active',
            MyManagers: [{
                UserId: params.UserId,
                MemberId: params.MemberId,
                FullName: params.FullName
            }],
            hgId: '4b64a812-63bf-11e6-94bd-4bb0f03b86bf',
            UserId: '4b64a810-63bf-11e6-94bd-4bb0f03b86bf',
            Position: 'Sales Representative',
            LastName: 'Patterson',
            FullName: 'Greg Patterson',
            FirstName: 'Greg'
        },
        {
            RolesInGroup: ['Employee'],
            Birthdate: 1200614400000,
            StartingDate: 1421539200000,
            MembershipStatus: 'Active',
            MyManagers: [{
                UserId: params.UserId,
                MemberId: params.MemberId,
                FullName: params.FullName
            }],
            hgId: 'a24a6761-63be-11e6-94bd-4bb0f03b86bf',
            UserId: 'a24a4050-63be-11e6-94bd-4bb0f03b86bf',
            Position: 'Business Analyst',
            LastName: 'Smith',
            FullName: 'Rich Smith',
            FirstName: 'Rich'
        },
        {
            RolesInGroup: ['Employee'],
            Birthdate: 1200614400000,
            StartingDate: 1421539200000,
            MembershipStatus: 'Active',
            MyManagers: [{
                UserId: params.UserId,
                MemberId: params.MemberId,
                FullName: params.FullName
            }],
            hgId: 'd2c6f4a3-5e44-11e6-9132-e5d69574f762',
            UserId: 'd2c6f4a1-5e44-11e6-9132-e5d69574f762',
            Position: 'Sales Representative',
            LastName: 'MacCallister',
            FullName: 'Pete MacCallister',
            FirstName: 'Pete'
        }
    ];
    return {
        DemoData: true,
        DirectReports: directReports,
        Alerts: [
            {
                ReportMemberId: 'a24a6761-63be-11e6-94bd-4bb0f03b86bf',
                ManagerMemberId: params.MemberId,
                "hgId": "5b783da0-6d8a-11e6-9e7e-8d825142b0bc",
                "AlertType": "FeedbackCheckInDue",
                "Severity": "Urgent",
                "Category": "Feedback",
                "Data": {
                    "CycleId": "99fc0260-6f2d-11e6-8716-8992a1e589f6",
                    "CycleTitle": "Q3 Check In",
                    "SessionId": "ea577e00-6f2e-11e6-9665-0b970150a8a0"
                }
            },
            {
                ReportMemberId: '4b64a812-63bf-11e6-94bd-4bb0f03b86bf',
                ManagerMemberId: params.MemberId,
                AlertType: "GoalPendingCreationApproval",
                Severity: "Urgent",
                hgId: "d61b9dd0-6b3d-11e6-9fb8-77db707ac757",
                Data: {
                    CycleName: "Development Goals"
                }
            },
            {
                ReportMemberId: '4b64a812-63bf-11e6-94bd-4bb0f03b86bf',
                ManagerMemberId: params.MemberId,
                AlertType: "ProfileUpcomingAnniversary",
                Severity: "UpComing",
                hgId: "e5529160-57f0-11e6-abab-a1580d509ce2",
                Data: {
                    Startdate: Date.now(),
                    DisplayText: '2 year work anniversary is coming up next week.'
                }
            }
        ],
        DirectReportCount: [{
            _id: directReports.map(function (item) {
                return item.hgId;
            }),
            count: directReports.length
        }]
    };
};
