/*jslint node:true es5:true*/
'use strict';

// use these enums as a reference for which feature flags are available
var Enums = {
    Type: {
        Goal: 0,
        Objective: 0,
        Milestone: 0,
        Welcome: 0,
        Birthday: 0,
        Anniversary: 0,
        News: 0,
        Poll: 0
    },
    DefaultBadges: [
        {
            order: 1,
            type: 'Objective',
            text: 'enums.badges.obj',
            fileName: 'obadgescript.svg',
            validation: {
                title: false,
                message: false
            }
        },
        {
            order: 2,
            type: 'Milestone',
            text: 'enums.badges.mil',
            fileName: 'mbadgescript.svg',
            validation: {
                title: false,
                message: false
            }
        },
        {
            order: 3,
            type: 'Welcome',
            text: 'enums.badges.wel',
            fileName: 'welcomebadge.svg',
            validation: {
                title: true,
                message: false
            }
        },
        {
            order: 4,
            type: 'Birthday',
            text: 'enums.badges.bir',
            fileName: 'packagebadge.svg',
            validation: {
                title: true,
                message: false
            }
        },
        {
            order: 5,
            type: 'Anniversary',
            text: 'enums.badges.ann',
            fileName: 'perfectattendancebadge.svg',
            validation: {
                title: true,
                message: false
            }
        },
        {
            order: 6,
            type: 'News',
            text: 'enums.badges.new',
            fileName: 'perfectattendancebadge.svg',
            validation: {
                title: false,
                message: false
            }
        },
        {
            order: 7,
            type: 'Poll',
            text: 'enums.badges.pol',
            fileName: 'IconBeanCounter.svg',
            validation: {
                title: false,
                message: false
            }
        }
    ]
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;


