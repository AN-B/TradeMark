/*jslint node:true es5:true*/
'use strict';

var msgs = [
    {
        cat: 'public.cat.g',
        msg: [
            'public.msg.g1',
            'public.msg.g2',
            'public.msg.g3',
            'public.msg.g4',
            'public.msg.g5',
            'public.msg.g6']
    },
    {
        cat: 'public.cat.c',
        msg: [
            'public.msg.c1',
            'public.msg.c2',
            'public.msg.c3',
            'public.msg.c4',
            'public.msg.c5',
            'public.msg.c6',
            'public.msg.c7',
            'public.msg.c8',
            'public.msg.c9']
    },
    {
        cat: 'public.cat.r',
        msg: [
            'public.msg.r1',
            'public.msg.r2',
            'public.msg.r3',
            'public.msg.r4']
    },
    {
        cat: 'public.cat.e',
        msg: [
            'public.msg.e1',
            'public.msg.e2',
            'public.msg.e3']
    },
    {
        cat: 'public.cat.p',
        msg: [
            'public.msg.p1',
            'public.msg.p2',
            'public.msg.p3',
            'public.msg.p4',
            'public.msg.p5',
            'public.msg.p6',
            'public.msg.p7',
            'public.msg.p8']
    }
];

module.exports = msgs;