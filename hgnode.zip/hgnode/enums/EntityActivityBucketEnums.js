/*jslint node:true es5:true*/
'use strict';
var Enums = {
    MemberPermissionsBucketType: {
        EntityArrayBucketType: '[object String]',
        EntityArrayBucketSize: 1000
    }
};
require('./EnumsBase.js').SetNames(Enums, 'Name');
module.exports = Enums;