/*jslint node:true es5:true*/
'use strict';
var Enums = {
        AvailableLanguages: {
            English: {key: 'en'},
            PortugueseBrazil: {key: 'pt-br'}
        },
        EntityType: {
            RecognitionTemplate: 0,
            BenchmarkSurveyTemplate: 0
        },
        Status: {
            Active: 0,
            InActive: 0,
            Deleted: 0
        }
    },
    i18nHelper = require('../helpers/i18nHelper.js');
Enums.getAvailableLanguages = function (lang) {
    return Object.keys(Enums.AvailableLanguages).map(function (k) {
        return {
            key: Enums.AvailableLanguages[k].key,
            value: i18nHelper.translate(lang, "server.language." + k)
        };
    });
};

require('./EnumsBase.js').SetNames(Enums);
module.exports = Enums;