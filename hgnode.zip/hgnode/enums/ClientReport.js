/*jslint node:true es5:true*/
'use strict';
var ClientReport = [
    { name: 'Recognition Activity', value : 100, template : 'Recognition.Activity.xlsx', Ext : ['csv', 'xlsx']},
    { name: 'Credit Activity', value : 101, template : 'Credit.Activity.xlsx', Ext : ['csv', 'xlsx']},
    { name: 'Track Activity', value : 102, template : 'Track.Activity.xlsx', Ext : ['csv', 'xlsx']},
    { name: 'Launch Stats', value : 103, template : 'Launch.Stats.xlsx', Ext : ['xlsx']},
    { name: 'Member Redemption Activity', value : 104, template : 'Member.Redemption.xlsx', Ext : ['xlsx']},
    { name: 'Members Last Activity', value : 105, template : 'Members.LastActivity.xlsx', Ext : ['xlsx']},
    { name: 'Member Activity', value : 106, template : 'Member.Activity.xlsx', Ext : ['csv', 'xlsx']},
    { name: 'Perform Review', value : 107, template : 'Perform.Review.xlsx', Ext : ['xlsx', 'csv']},
    { name: 'Coaching Report', value : 108, template : 'Coaching.xlsx', Ext : ['xlsx', 'csv']},
    { name: 'Recognition Engagement', value : 111, template : 'Recognition.Engagement.xlsx', Ext : ['xlsx']},
    { name: 'Goal Activity', value : 122, template : 'Goal.Activity.xlsx', Ext : ['xlsx']},
    { name: 'Current Point Balance', value : 123, template : 'Current.Point.Balance.xlsx', Ext : ['xlsx']},
    { name: 'Feedback Check-In Activity', value : 125, template: 'Check.In.Activity.xlsx', Ext : ['xlsx']},
    { name: 'Feedback Request Activity', value: 126, template: 'Feedback.Request.Activity.xlsx', Ext : ['xlsx']}
],
    ProvisionReport = [
        {Name: "Recognition Activity", Value: 100, AllowAllView: false, Ext: ['csv', 'xlsx']},
        {Name: 'Credit Activity', Value: 103, AllowAllView: false, Ext: ['csv', 'xlsx']},
        {Name: 'Launch Stats', Value: 105, AllowAllView: false, Ext: ['xlsx']},
        {Name: 'Member Activity', Value: 106, AllowAllView: false, Ext: ['csv', 'xlsx']},
        {Name: 'Members Last Activity', Value: 109, AllowAllView: false, Ext: ['xlsx']},
        {Name: 'Track Activity', Value: 110, AllowAllView: false, Ext: ['csv', 'xlsx']},
        {Name: 'Perform Engagement', Value: 114, AllowAllView: true, Ext: ['xlsx']},
        {Name: 'Recognition Engagement', Value: 111, AllowAllView: true, Ext: ['xlsx']},
        {Name: 'Track Engagement', Value: 112, AllowAllView: true, Ext: ['xlsx']},
        {Name: 'Engagement Trend', Value: 113, AllowAllView: true, Ext: ['xlsx']},
        {Name: 'Redemption Activity', Value: 115, AllowAllView: true, Ext: ['xlsx']},
        {Name: 'Member Redemption Activity', Value: 116, AllowAllView: false, Ext: ['xlsx']},
        {Name: 'Perform Review Activity', Value: 117, AllowAllView: false, Ext: ['xlsx', 'csv']},
        {Name: 'Employee Review Feedback Summary', Value: 118, AllowAllView: false, Ext: ['xlsx']},
        {Name: 'User Preference Report', Value: 119, AllowAllView: true, Ext: ['xlsx']},
        {Name: 'Credit Card Transactions', Value: 120, AllowAllView: true, Ext: ['xlsx']},
        {Name: 'HRIS Member Export', Value: 121, AllowAllView: false, Ext: ['xlsx']},
        {Name: 'Coaching Report', Value: 108, AllowAllView: false, Ext: ['xlsx', 'csv']},
        {Name: 'Goal Activity', Value: 122, AllowAllView: false, Ext: ['xlsx', 'csv']},
        {Name: 'HRIS Activity', Value: 124, AllowAllView: true, Ext: ['xlsx', 'csv']},
        {Name: 'Feedback Check-In Activity', Value: 125, AllowAllView: false, Ext: ['xlsx', 'csv']},
        {Name: 'Feedback Request Activity', Value: 126, AllowAllView: false, Ext: ['xlsx', 'csv']}
    ];

function getClientReportTemplate(reportId) {
    var report = ClientReport.filter(function (item) {
        return item.value === reportId;
    });
    return (report && report.length === 1) ? report[0].template : '';
}
function getReportName(reportType, reportId) {
    var report,
        name;
    if (reportType) {
        report = ClientReport.filter(function (item) {
            return item.value === reportId;
        });
        name = (report && report.length === 1) ? report[0].name : '';
    } else {
        report = ProvisionReport.filter(function (item) {
            return item.Value === reportId;
        });
        name = (report && report.length === 1) ? report[0].Name : '';
    }
    return name;
}

module.exports.ClientReport = ClientReport;
module.exports.ProvisionReport = ProvisionReport;
module.exports.GetClientReportTemplate = getClientReportTemplate;
module.exports.getReportName = getReportName;