/*jslint node:true es5:true*/
'use strict';
var Enums = {
        PropertyType: {
            BatchId: 0
        }
    },
    util = require('./EnumsBase.js');
util.SetNames(Enums);
module.exports = Enums;