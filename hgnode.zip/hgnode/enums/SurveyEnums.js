/*jslint node:true es5:true*/
'use strict';
var Enums = {
    QuestionStatus: {
        Active: 0,
        Deleted: 0,
        Pending: 0,
        Completed: 0,
        Suppressed: 0,
        Archived: 0
    },
    QuestionType: {
        System: 0,
        Group: 0,
        Department: 0,
        User: 0
    },
    Tenure: {
        LessThanSix: '0006',
        LessThanYear: '0010',
        LessThanTwo: '0020',
        LessThanThree: '0030',
        LessThanFour: '0040',
        LessThanFive: '0050',
        LessThanTen: '0100',
        GreaterThanTen: '0101'
    },
    SurveyDriverStatus: {
        Active: 0,
        Deleted: 0
    },
    CohortType: {
        Role: 0,
        Tenure: 0,
        Department: 0,
        Location: 0
    },
    Status: {
        Active: 0,
        Deleted: 0,
        Scheduled: 0,
        InProgress: 0,
        Archived: 0
    },
    Type: {
        Benchmark: 0,
        Pulse: 0,
        Poll: 0
    },
    SurveyAnswerStatus: {
        Pending: 0,
        Dismissed: 0,
        Completed: 0,
        InProgress: 0
    },
    SurveyResultStatus: {
        Completed: 0,
        InProgress: 0
    },
    AnswerTypes : {
        Mood: 0,
        RatingScale: 0,
        MultipleChoice: 0,
        Text: 0
    },
    PulseCohortTextFilter: {
        Department: 'DepartmentId',
        Tenure: 'Tenure',
        Role: 'Role',
        Location: 'LocationId'
    },
    PulseMapType: {
        Mood: 0,
        MultipleChoice: 0
    },
    PDFSurveyResultSections: {
        DriverResultSummary: 0,
        DriverResultSummaryByResponderType: 0,
        EngagementScoreByDepartment: 0,
        EngagementScoreByLocation: 0,
        EngagementScoreByLevel: 0,
        EngagementScoreByTenure: 0,
        DriverDetailDepartment: 0,
        DriverDetailLocation: 0,
        DriverDetailLevel: 0,
        DriverDetailTenure: 0,
        DepartmentQuestionDetail: 0,
        LocationQuestionDetail: 0,
        LevelQuestionDetail: 0,
        TenureQuestionDetail: 0
    },
    KioskPDFSurveyResultSections: {
        DriverResultSummary: 0,
        DriverResultSummaryByResponderType: 0,
        EngagementScoreByDepartment: 0,
        EngagementScoreByLocation: 0,
        DriverDetailDepartment: 0,
        DriverDetailLocation: 0,
        DepartmentQuestionDetail: 0,
        LocationQuestionDetail: 0
    },
    SVGFilenames: {
        BubbleBargraph1: 'bubble-bargraph-1.svg',
        BubbleBargraph2: 'bubble-bargraph-2.svg',
        BubbleBargraphSmall: 'bubble-bargraph-small.svg',
        BubbleHeaderBargraph: 'bubble-header-bargraph.svg',
        BubbleHeaderLinegraph: 'bubble-header-linegraph.svg',
        BubbleHeaderRight: 'bubble-header-right.svg',
        SurveyCover: 'SurveyCover.svg'
    }
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
