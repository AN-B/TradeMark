'use strict';
var Enums = {
    OneLogin: {
        issuer: 'highground-saml',
        entryPoint: 'https://app.onelogin.com/trust/saml2/http-post/sso/389869'
    },
    Authen2cate: {
        issuer: 'https://my.authen2cate.com/',
        entryPoint: 'https://my.authen2cate.com/a2c/lrw/saml/sp/131'
    },
    Custom: {
        issuer: '',
        entryPoint: '',
        slo: ''
    }
};
require('./EnumsBase.js').SetNames(Enums, 'name');

module.exports = Enums;