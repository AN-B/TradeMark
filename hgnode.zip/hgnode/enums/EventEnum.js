var Enums = {
    Authorization: {
        LoadClientProfileComplete: 0,
        AuthorizeComplete: 0
    },
    AttachmentService: {
        GetAllComplete: 0
    },
    AttachmentAdminService: {
        CreateComplete: 0,
        UpdateComplete: 0
    },
    BadgeService: {
        GetAllComplete: 0
    },
    BadgeAdminService: {
        CreateComplete: 0,
        UpdateComplete: 0,
        InternalServiceCallComplete: 0
    },
    CreditService: {
        LoadPackTemplateComplete: 0,
        PurchaseComplete: 0,
        PaymentMade: 0,
        TransferCreditComplete: 0,
        VerifyCreditBalanceComplete: 0,
        VerifyGroupTransferSettingComplete: 0,
        GeneralServiceCallComplate: 0,
        GeneralInternalServiceCallComplate: 0,
        EarmarkCreditsByAccountIdComplete: 0,
        EarmarkCreditsByOwnerIdAndTypeComplete: 0,
        ReverseEarmarkCreditsByOwnerIdAndTypeComplete: 0,
        DeductCreditsByOwnerIdAndAccountTypeComplete: 0,
        DeductCreditsByAccountIdComplete: 0,
        GetCreditAccountByOwnerIdAndAccontTypeComplete: 0
    },
    ExpressPigeonService: {
        GeneralServiceCallComplete: 0
    },
    GoalService: {
        LoadComplete: 0,
        InsertComplete: 0,
        UpdateComplete: 0,
        DeleteComplete: 0
    },
    GlobalAdminService: {
        GeneralServiceCallComplete: 0,
        LoadCreditMasterMemberComplete: 0,
        GeneralWrappedServiceCallComplete: 0
    },
    GoalProcessor: {
        GetComplete: 0
    },
    GroupService: {
        GetCurrentGroupMembersDTOComplete: 0,
        GetUserInfoByIdComplete: 0,
        CreateNewUserActivityComplete: 0,
        GetNewUserActivityComplete: 0,
        ReInstateOffBoardMemberComplete: 0,
        ApproveMemberComplete: 0
    },
    GroupAdminService: {
        GenerateFriendlyIdComplete: 0,
        CreateComplete: 0
    },
    NewsService: {
        UpdateHGNewsComplete: 0,
        PostUpdateGroupNewsComplete: 0,
        GeneralServiceCallComplete: 0
    },
    NotificationService: {
        GenericSendData: 0,
        ResolveRecipientsComplete: 0,
        BuildContentComplete: 0,
        DispatchCompleted: 0,
        NotificationCompleted: 0
    },
    PerformanceService: {
        GeneralProcessorCallComplete: 0,
        GeneralWrappedProcessorCallComplete: 0
    },
    RedeemService: {
        ReserveAndReturnGiftcardsComplete: 0,
        VerifyCreditBalanceComplete: 0,
        SaveGiftcardOrderComplete: 0,
        OrderGiftcardsComplete: 0,
        GetAvailableCodeGiftcardsGroupByIssuerComplete: 0,
        GetAvailableTangoCardsComplete: 0
    },
    RewardService: {
        GeneralServiceCallComplete: 0
    },
    TeamService: {
        GeneralProcessorCallComplete: 0
    },
    TrackService: {
        GetComplete: 0,
        CreateComplete: 0,
        GetIssuerMemberComplete: 0,
        GetRecipientMembersComplete: 0,
        GetTemplatesComplete: 0,
        GetUpdateTrackComplete: 0,
        UpdateMileStoneComplete: 0,
        GetAddContributorComplete: 0,
        AddContributorComplete: 0,
        GetSetObjectiveChainComplete: 0,
        SetObjectiveChainComplete: 0,
        GetDeleteMileStoneComplete: 0,
        DeleteMileStoneComplete: 0,
        UpdateOverDueMilestonesComplete: 0,
        GeneralProcessorCallComplete: 0,
        WrappedEventComplete: 0
    },
    TrackAdminService: {
        CreateComplete: 0,
        LoadGoalTemplateComplete: 0,
        LoadMileStoneTemplatesComplete: 0,
        GetForDeleteMileStoneComplete: 0,
        GetMemberComplete: 0,
        GetMembersComplete: 0,
        GetGroupComplete: 0,
        GetBadgeComplete: 0,
        GeneralServiceCallComplete: 0,
        UpdateCareerTrackComplete: 0
    },
    UserProcessor: {
        LoadUserSecurityWithTokenComplete: 0,
        LoadUserSecurityWithUsernamePasswordComplete: 0,
        LoadUserInfoComplete: 0,
        LoadDefaultGroupComplete: 0,
        LoadUserMembershipComplete: 0
    },
    UserService: {
        LoginComplete: 0,
        Login2Complete: 0,
        GeneralProcessorCallComplete: 0,
        CompleteCallbackRequest: 0
    },
    UserAdminService: {
        GetUserSecurityComplete: 0,
        CreateUserComplete: 0
    },
    UserSelfService: {
        SwitchCurrentGroupComplete: 0,
        UpdateMyProfileComplete: 0,
        GetNotificationPreferenceComplete: 0,
        GeneralServiceCallComplete: 0,
        UpdateNotificationPreferenceComplete: 0,
        GeneralProcessorCallComplate: 0
    },
    PaymentService: {
        SaveAuthorizeNetProfileComplete: 0,
        CreateAuthorizeNetCustomerProfileComplete: 0,
        LoadUserInfoForSavingingNewCustomerProfileId: 0,
        CustomerProfileIdSaved: 0,
        AuthorizeNetCustomerProfileIdSaved: 0,
        SaveBillMeLaterProfileComplete: 0,
        DeleteProfileComplete: 0,
        GetPaymentProfilesComplete: 0,
        UpdateUserFinanceComplete: 0,
        TransactComplete: 0,
        LoadUserInfoWithParamsForSaveNewPaymentProfileComplete: 0,
        LoadUserInfoWithParamsForUpdatePaymentProfileComplete: 0,
        LoadUserInfoWithParamsForDeletePaymentProfileComplete: 0,
        GetPaymentProfileToDeleteComplete: 0,
        LookUpBillMeLaterPaymentProfileIdComplete: 0
    },
    PublicRecognition: {
        GetPublicTemplatesForMemberComplete: 0,
        LoadMembersComplete: 0,
        LoadTemplatesComplete: 0,
        GetMemberComplete: 0,
        GetRecipientMemberComplete: 0,
        CreateRecognitionsComplete: 0,
        CreateWelcomeRecognitionsComplete: 0,
        GetUserByTokenComplete: 0,
        LoadBadgeComplete: 0,
        GetGroupComplete: 0,
        GetRecognitionMessageTemplatesComplete: 0,
        GeneralProcessorCallComplete: 0
    },
    RequestManager: {
        GenericSendData: 0
    },
    RecognitionService: {
        TemplateLoadComplete: 0,
        GeneralServiceCallComplete: 0,
        GenericSendData: 0
    },
    RecognitionAdminService: {
        GenericSendData: 0,
        CreateComplete: 0,
        UpdateComplete: 0
    },
    ReportService: {
        GeneralServiceCallComplete: 0,
        GetLaunchStatActivityComplete: 0,
        GetReportDashboardComplete: 0,
        GetTrackActivityReportComplete: 0
    },
    ProvisionService: {
        ExcelReadComplete: 0,
        OnboardCustomerReadComplete: 0,
        GenerateFriendlyIdComplete: 0,
        VerifyCustomerExistComplete: 0,
        CreateUpdateGroupComplete: 0,
        VerifyUserExistComplete: 0,
        CreateOrGetUserComplete: 0,
        VerifyMemberExistComplete: 0,
        UpdateGroupBannerInfoComplete: 0,
        OnboardEmployeesComplete: 0,
        SaveAndGetUsersComplete: 0,
        GetGroupByHGAccountIdComplete: 0,
        OffboardMembersReadComplete: 0,
        LoadByUserNamesComplete: 0,
        LoadMembersForOffboarding: 0,
        BatchCreated: 0,
        SendPendingNotificationForBatchComplete: 0,
        BatchLoadForNotificationComplete: 0,
        ActivityLoadForNotificationComplete: 0,
        BatchLoadComplete: 0,
        GeneralProcessorCallComplete: 0,
        GenerateGuids: 0,
        ImportTangoCardsReadComplete: 0
    },
    TagService: {
        GeneralProcessorCallComplate: 0
    },
    TransactionService: {
        SaveTransactionComplete: 0,
        GetTransactionComplete: 0,
        UpdateTransactionComplete: 0,
        GetTransactionsForAccountComplete: 0,
        SaveTransferTransactionsComplete: 0,
        FundsChanged: 0,
        GenericCallbackFunctionComplete: 0
    },
    WorkerService: {
        GeneralProcessorCallComplate: 0,
        GeneralServiceCallComplete: 0,
        GetTracksWithOverdueMileStonesComplete: 0,
        GetUsersForAnniversaryComplete: 0,
        GetGroupsForInvoicesComplete: 0,
        GetMembershipsForGroupsComplete: 0,
        MemberDailyRecapAllComplete: 0,
        UpdateOverdueMileStonesComplete: 0,
        GetScheduledOnBoardMembersComplete: 0,
        UpdateScheduledNewOnBoardMemberComplete: 0,
        GetMembersForGroupsComplete: 0
    },
    SSOService: {
        CompleteCallbackRequest: 0
    },
    SSONoAuthService: {
        CompleteCallbackRequest: 0
    },
    SocialMediaService: {
        CompleteCallbackRequest: 0
    },
    UIService: {
        GeneralProcessorCallComplete: 0
    }
};
require('./EnumsBase.js').SetNames(Enums, '.');

module.exports = Enums;