/*jslint node:true es5:true*/
'use strict';
var Enums = {
    EntityType: {
        PerformanceReview: 0,
        Recognition: 0,//not implemented
        Goal: 0
    },
    Status: {
        Pending: 0,
        Archived: 0,//set to this status usually means the entity has been deleted or archived
        Cancelled: 0,
        Approved: 0,
        Denied: 0,
        ApprovalPending: 0
    },
    PersonType: {
        Approver: 0,//people who decides to approve or deny
        Petitioner: 0
    },
    DecisionType: {
        Deny: 0,
        Approve: 0,
        Abstention: 0
    },
    ActivityType: {
        Archived: 0,
        Deny: 0,
        Approve: 0,
        Abstention: 0,
        Submit: 0//the petitioner submitted this petition for approval
    },
    DefaultDecisionType: {
        Deny: 0,
        Approve: 0,
        None: 0
    },
    ResolutionType: {
        Majority: 0,//need over 50%
        Veto: 0,//If one person denies, the petition is denied
        OnePass: 0,//if one person approves, the petition is approved,
        FirstActionWin: 0
    },
    PetitionTypes: {
        ReviewRequestEdit: {
            EntityType: 'PerformanceReview',
            DefaultDecision: 'Approve',
            DaysToAct: 2,
            ResolutionType: 'FirstActionWin',
            EventType: 'ReviewRequestEditPetitionResolution'//the event type on ESB when resolution is available
        },
        GoalWeighting: {
            EntityType: 'GoalCycleParticipant',
            DefaultDecision: 'Approve',
            DaysToAct: 2,
            ResolutionType: 'FirstActionWin',
            EventType: 'GoalWeightingResolution'//the event type on ESB when resolution is available
        },
        GoalSet: {
            EntityType: 'Goal',
            DefaultDecision: 'Approve',
            DaysToAct: 2,
            ResolutionType: 'FirstActionWin',
            EventType: 'GoalSetPetitionResolution'//the event type on ESB when resolution is available
        },
        GoalClose: {
            EntityType: 'Goal',
            DefaultDecision: 'Approve',
            DaysToAct: 2,
            ResolutionType: 'FirstActionWin',
            EventType: 'GoalClosePetitionResolution'//the event type on ESB when resolution is available
        },
        ProductItemSuggestion: {
            EntityType: 'RewardsItemSuggestion',
            DefaultDecision: 'Approve',
            DaysToAct: 2,
            ResolutionType: 'FirstActionWin',
            EventType: 'ProductItemSuggestionPetitionResolution'
        }
    }
},
    util = require('./EnumsBase.js');
util.SetNames(Enums);
util.SetNames(Enums.PetitionTypes, 'Name');

module.exports = Enums;
