/*jslint node:true es5:true*/
'use strict';
var Enums = {
        CycleStatus: {
            Draft: 0,//admin is still editing, nothing should be delivered (even if all other criteria meet)
            Pending: 0,//cycle is ready to be delivered if all other criteria meet
            Scheduled: 0, // used in talent insight
            InProgress: 0,//at least one party has been delivered
            Closed: 0,
            Archived: 0
        },
        CycleInitiatorStatus: {
            PendingDelivery: 0,// The participant has questions to answer, but hasn't been delivered
            NotStarted: 0,//Delivered but haven't started
            InProgress: 0,// working on feedback sessions in this cycle. This starts from the cycle is delivered to subject, until either closed or archived
            Closed: 0,// either finished or closed out by admin
            Archived: 0
        },
        RequestStatus: {
            Requesting: 0,//  -- subject sent a request
            InProgress: 0,//  -- at least one reviewer has responded, either accept or decline
            ReadyToComplete: 0,//  -- all reviewers are final (declined, expired, submitted) and at least one reviewer submitted. Subject can mark it as completed
            Declined: 0,//  -- all reviewers declined
            Expired: 0,//  -- nobody responded and the request expired
            Completed: 0,//  - Subject marked a ReadyToComplete request to Completed. The request now moves to Completed tab.
            Closed: 0,//closed by admin
            Archived: 0
        },
        SessionStatus: {
            Requesting: 0,//"Subject" requested for feedback. This step can be skipped in backend, even though spec said it's always initiated by Subject request
            Declined: 0,//Reviewer declined 
            Expired: 0,
            NotStarted: 0,//has been delivered by has not been started
            InProgress: 0,//all requested participants have accepted invitation, but at least one participant haven't submitted
            Overdue: 0,//for now this only applies to self evaluation
            Submitted: 0,// all questions have been answered, and sent to subject to view
            PendingSignOff: 0,
            Completed: 0,//reviewer has seen subject's rating and thank you note
            Closed: 0,//closed by admin
            Archived: 0
        },
        Tabs: {
            RequestInbox: 0,
            RequestCompleted: 0,
            CheckInInbox: 0,
            CheckInCompleted: 0
        },
        RequestFilter: {
            All: 0,
            ByMeInbox: 0,
            ByOthersInbox: 0,
            ByMeCompleted: 0,
            ByOthersCompleted: 0,
            ByMeExpired: 0,
            ByOthersExpired: 0,
            ByMeDeclined: 0,
            ByOthersDeclined: 0
        },
        NextStep: {//this is in DTO, telling UI which route to populate on the button
            Start: 0,//take to "Start" screen to accept/decline
            Tip: 0,//go to tip & instruction screen
            Answer: 0,//go to answer question screen
            Rate: 0,//go to rating screen
            View: 0,//read only screen
            SelfEvalStart: 0, //to to start page to read instruction
            SelfEvalAnswer: 0,//answer screen for self evaluation
            SelfEvalView: 0,//read only screen for self evaluation. In front end, it can share the same controller and template in the beginning, but may also split if needed
            NoAccess: 0//no access,
        },
        SessionParticipantStatus: {
            NotApplicable: 0,
            NotStarted: 0,
            Accepted: 0,
            PendingDelivery: 0,
            Requesting: 0,// Participant has sent request to provide feedback. One session can include multiple requestees, and the subject stays in this status until all have accepted or rejected, or closed/archived by admin
            RequestPending: 0,//You are invited to be a reviewer in a feedback session, and you haven't accepted or declined 
            Declined: 0,// You declined the request to be a reviewer
            InProgress: 0,//participant working on feedback
            Submitted: 0,
            Viewed: 0,
            Expired: 0,
            Closed: 0,
            SignedOff: 0,
            Archived: 0
        },
        SessionParticipantType: {//keep in mind there MIGHT be custom session participant types
            Subject: 0,
            Reviewer: 0,
            Requester: 0
        },
        SubjectRating: {
            NA: 0,
            Helpful: 0,
            ExtremelyHelpful: 0
        },
        CriteriaType: {
            Level: 0,
            Department: 0,
            Location: 0,
            Company: 0//add the entire company
        },
        ClusterStatus: {
            Pending: 0,//added to cycle, but corresponding "FeedbackCycleInitiator" has not been instantiated
            Active: 0,//"FeedbackCycleInitiator" have been instantiated
            Archived: 0
        },
        InitiatorType: {
            Subject: 0,
            Reviewer: 0
        },
        TriggerType: {
            RequestAnytime: 0,
            GiveAnytime: 0,
            EventTrigger: 0,
            FrequencyTrigger: 0
        },
        CardStatus: {
            Draft: 0,
            Active: 0,
            Archived: 0
        },
        CycleType: {
            Give: 0,
            Request: 0,
            SelfEvaluation: 0,//aka Guided check-in
            ManagerCheckIn: 0,
            SuccessionPlanning: 0,
            EvaluateOthers: 0,
            TalentInsight: 0
        },
        CardType: {//note, CycleType and card type seems now identical, basically a cycle type decides the card type, but i'm keeping them separate because logically they are different
            Give: 0,
            Request: 0,
            SelfEvaluation: 0,//aka Guided check-in
            Perform: 0,
            SuccessionPlanning: 0,
            EvaluateOthers: 0,
            TalentInsight: 0
        },
        Workflow: {
            SelfAssessment: 0,
            Direct: 0,
            HiddenFromEmployee: 0
        },
        SectionType: {
            CycleGoal: 0,//ask question for each goal in the cycle
            AdhocGoal: 0,//ask question for each adhoc goal within date range
            Recognitions: 0,//ask question for all recognitions within date range
            Generic: 0
        },
        QuestionType: {
            ShortAnswer: 0,
            Paragraph: 0,
            RadioButton: 0,
            RatingScale: 0,
            CheckBox: 0,
            Slider: 0
        },
        Default: {
            ExpireRequestDays: 14,
            CheckinGuide: 'NLI_standard_checkin_CVG.pdf'
        },
        TrainingPDFType: {
            None: 0,
            HGTips: 0,
            Custom: 0
        },
        FeedbackActivityType: {
            Received: 0,
            Accepted: 0,
            Requested: 0,
            Completed: 0,
            Declined: 0,
            Expired: 0
        },
        ActionMode: {
            Receive: 0,
            Give: 0
        },
        ProfileAccessMode: {
            Self: 0,
            Manager: 0,
            Admin: 0,//accessing the session as admin.
            NoAccess: 0
        },
        SessionAccessMode: {
            NoAccess: 0,//no access
            Subject: 0,//accessing the session as the subject
            Reviewer: 0,//accessing the session as the reviewer
            Requester: 0
        },
        TalentInsightTags: {
            Replaceable: 0,
            Performance: 0,
            FlightRisk: 0,
            Promotable: 0,
            KeyToSuccess: 0,
            Potential: 0,
            Capacity: 0,
            Speed: 0,
            Scarcity: 0
        },
        TalentInsightCategory: {
            Promotable: 0,
            NotPromotable: 0,
            PromotableFlightRisk: 0,
            NotPromotableFlightRisk: 0
        },
        CardQuestionCategory: {
            System: 0, // system standard questions
            Group: 0 // group questions
        },
        UserAction: {
            Archive: 0,
            Decline: 0,
            Delete: 0
        },
        ParticipantDateType: {
            DueDate: 0,
            SubmittedDate: 0
        }
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
