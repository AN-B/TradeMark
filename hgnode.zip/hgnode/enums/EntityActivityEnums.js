/*jslint node:true es5:true*/
'use strict';
var Enums = {
        EntityType: {
            GoalCycle: 0,
            Goal: 0,
            KeyResult: 0,
            MemberRole: 0,
            MemberPermission: 0
        },
        ActivityType: {
            KeyResultUpdate: 0,
            KeyResultNameChange: 0,
            GoalNameChange: 0,
            KeyResultTargeChange: 0,
            AddAlignGoal: 0,
            ChangeAlignGoal: 0,
            ChangeGoalPublicity: 0,
            KeyResultRemoved: 0,
            KeyResultAdded: 0,
            MemberRoleChanged: 0,
            MemberPermissionChanged: 0
        }
    };
require('./EnumsBase.js').SetNames(Enums);
module.exports = Enums;
