/*jslint node:true es5:true*/
/*
    Pending - Credits are not get avalible, but will be when the transaction completes.
    Complete - Transaction has fully settled, credits are avalib.e
    Failed - Transaction for credits failed (ex: check bounced.)
    PendingAvalible - Credits are avalible to the user but transaction still needs to clear. Ex: check is in transit/being deposted.
*/
'use strict';
var Enums = {
    Pending: 0,
    Complete: 0,
    Failed: 0,
    PendingAvailable: 0
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
