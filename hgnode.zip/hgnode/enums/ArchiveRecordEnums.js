/*jslint node:true es5:true*/
'use strict';
var Enums = {
        Reason: {
            ReviewsDueToOffBoard: 'Reviews archived because the member was off-boarded.',
            ChangeDueToManagerTransfer: 'Cycle archived because a manager was transferred.',
            GoalSetRejected: 0,
            GoalClosureRejected: 0
        },
        Collection: {
            PerformanceReview: 0,
            PerformanceCycle: 0,
            Goal: 0,
            UserInfo: 0,
            Member: 0,
            UserSecurity: 0
        }
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
