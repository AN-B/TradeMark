/*jslint node:true es5:true*/
'use strict';
var Enums = {
        EntityType : {
            GoalCycle: 0,
            Goal: 0,
            Member: 0,
            Track: 0,
            ProvisionActivity: 0,
            PerformanceReview: 0,
            FeedbackCycle: 0,
            FeedbackSession: 0,
            FeedbackCheckin: 0,
            ProvisionStagedLocation: 0
        },
        Status: {
            New: 0,
            Processing: 0,
            Failed: 0,
            Completed: 0
        },
        BatchTypes: {
            AddAllMembersToCycle: {
                EntityType: 'GoalCycle',
                SkipNeeded: true,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalElegibleMembers',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'LoadElegibleMembersBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'AddMembersToCycleBatch',
                PostProcServiceName: 'GoalCycle',
                PostProcMethodName: 'DoneAddAllMembersToCycle',
                Report: true
            },
            RemoveAllMembersFromCycle: {
                EntityType: 'GoalCycle',
                SkipNeeded: true,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalElegibleMembers',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'LoadElegibleMembersBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'RemoveMembersFromCycleBatch',
                PostProcServiceName: 'GoalCycle',
                PostProcMethodName: 'DoneRemoveAllMembersFromCycle',
                Report: true
            },
            FeedbackRequestExpiringReminder: {
                EntityType: 'FeedbackSession',
                SkipNeeded: true,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 200,
                DataServiceName: 'FeedbackSession',
                DataMethodName: 'LoadExpiringRequestsGroupByReviewer',
                ProcessingServiceName: 'FeedbackSession',
                ProcessingMethodName: 'RemindExpiringRequests',
                Report: true
            },
            ExpireFeedbackRequest: {
                EntityType: 'FeedbackSession',
                SkipNeeded: false,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 200,
                DataServiceName: 'FeedbackSession',
                DataMethodName: 'LoadRequestsToExpire',
                ProcessingServiceName: 'FeedbackSession',
                ProcessingMethodName: 'ExpireRequests',
                Report: true
            },
            ArchiveSessionsInFeedbackCycle: {
                EntityType: 'FeedbackCycle',
                SkipNeeded: false,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                DataServiceName: 'FeedbackSession',
                DataMethodName: 'GetSessionsByCycleIdToArchiveBatch',
                ProcessingServiceName: 'FeedbackSession',
                ProcessingMethodName: 'ArchiveSessionsByCycleIdBatch',
                Report: true
            },
            CloseSessionsInFeedbackCycle: {
                EntityType: 'FeedbackCycle',
                SkipNeeded: false,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                DataServiceName: 'FeedbackSession',
                DataMethodName: 'GetSessionsByCycleIdToCloseBatch',
                ProcessingServiceName: 'FeedbackSession',
                ProcessingMethodName: 'CloseSessionsByCycleIdBatch',
                Report: true
            },
            FeedbackCycleAddCompany: {
                EntityType: 'FeedbackCycle',
                SkipNeeded: true,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                DataServiceName: 'FeedbackCycle',
                DataMethodName: 'LoadMemberToCycleBatch',
                ProcessingServiceName: 'FeedbackCycle',
                ProcessingMethodName: 'AddMembersToCycleBatch',
                Report: true
            },
            FeedbackCycleAddStagedInitiators: {
                EntityType: 'FeedbackCycle',
                SkipNeeded: false,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                DataServiceName: 'FeedbackCycle',
                DataMethodName: 'LoadStagedInitiatorsBatch',
                ProcessingServiceName: 'FeedbackCycle',
                ProcessingMethodName: 'AddMembersToCycleBatch',
                Report: true
            },
            DeliverSelfEvaluation: {
                EntityType: 'FeedbackCycle',
                SkipNeeded: false,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                GetTotalServiceName: 'FeedbackCycle',
                GetTotalMethodName: 'GetTotalDeliveryDueInitiatoryCycleId',
                DataServiceName: 'FeedbackCycle',
                DataMethodName: 'LoadDeliveryDueInitiatorsByCycleIdBatch',
                ProcessingServiceName: 'FeedbackCycle',
                ProcessingMethodName: 'DeliverCycleBatch',
                Report: true
            },
            DeliverGoalCycle: {
                EntityType: 'GoalCycle',
                SkipNeeded: false,//if the DataMethod won't pick up the same chunk of data after they are processed, this is set to false 
                ChunkSize: 100,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalDeliveryDueParticipantByCycleId',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'LoadDeliveryDueParticipantByCycleIdBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'DeliverCycleBatch',
                PostProcServiceName: 'GoalCycle',
                PostProcMethodName: 'DoneDeliverCycleBatch',
                Report: true
            },
            GoalCreationReminder: {
                EntityType: 'GoalCycle',
                SkipNeeded: true,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 100,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalPartipantsForGoalCreation',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'GetPartipantsForGoalCreationReminderBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'SendAlertsToParticipantsGoalCreationReminder'
            },
            GoalOverdueReminder: {
                EntityType: 'GoalCycle',
                SkipNeeded: true,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 100,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalParticipantsNumberGoalOverdue',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'GetPartipantsForGoalOverdueReminderBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'SendAlertsToParticipantsGoalOverdueReminder',
                Report: true
            },
            CloseGoalPrompt: {
                EntityType: 'GoalCycle',
                SkipNeeded: true,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 100,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalPartipantsForCloseGoalPrompt',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'GetPartipantsForCloseGoalPromptBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'SendAlertsToParticipantsCloseGoalPrompt'
            },
            CloseGoalOverdue: {
                EntityType: 'GoalCycle',
                SkipNeeded: true,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 100,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalPartipantsForCloseGoalOverdue',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'GetPartipantsForCloseGoalOverdueBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'SendAlertsToParticipantsCloseGoalOverdue'
            },
            CloseAdhocGoalPrompt: {
                EntityType: 'Goal',
                SkipNeeded: true,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 100,
                GetTotalServiceName: 'Goal',
                GetTotalMethodName: 'GetTotalAdhocGoalsForClosePrompt',
                DataServiceName: 'Goal',
                DataMethodName: 'GetAdhocGoalsForClosePromptBatch',
                ProcessingServiceName: 'Goal',
                ProcessingMethodName: 'SendAlertsToAdhocGoalOwnerCloseGoalPrompt'
            },
            TrackCheckIn: {
                EntityType: 'Track',
                SkipNeeded: true,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 50,
                GetTotalServiceName: 'Track',
                GetTotalMethodName: 'GetTotalTracksForCheckin',
                DataServiceName: 'Track',
                DataMethodName: 'GetTracksForCheckinBatch',
                ProcessingServiceName: 'Track',
                ProcessingMethodName: 'SendCheckinForTracks'
            },
            RemoveGoalCycleParticipants: {
                EntityType: 'GoalCycleParticipant',
                SkipNeeded: false,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 50,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalPartipantsForForRemove',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'GetPartipantsForRemoveBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'RemoveGoalCycleParticipantsBatch',
                Report: true
            },
            CloseGoalCycleParticipants: {
                EntityType: 'GoalCycleParticipant',
                SkipNeeded: false,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 50,
                GetTotalServiceName: 'GoalCycle',
                GetTotalMethodName: 'GetTotalPartipantsForClose',
                DataServiceName: 'GoalCycle',
                DataMethodName: 'GetPartipantsForCloseBatch',
                ProcessingServiceName: 'GoalCycle',
                ProcessingMethodName: 'CloseGoalCycleParticipantsBatch',
                Report: true
            },
            BatchDailyRecap: {
                EntityType: 'Member',
                SkipNeeded: false,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 200,
                GetTotalServiceName: 'Recap',
                GetTotalMethodName: 'GetTotalMembersForDailyRecap',
                DataServiceName: 'Recap',
                DataMethodName: 'GetNextBatchMembersForDailyRecap',
                ProcessingServiceName: 'Recap',
                ProcessingMethodName: 'GenerateDailyRecapForMembers',
                Report: true
            },
            BatchWeeklyRecap: {
                EntityType: 'Member',
                SkipNeeded: false,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 100,
                GetTotalServiceName: 'Recap',
                GetTotalMethodName: 'GetTotalMembersForWeeklyRecap',
                DataServiceName: 'Recap',
                DataMethodName: 'GetNextBatchMembersForWeeklyRecap',
                ProcessingServiceName: 'Recap',
                ProcessingMethodName: 'GenerateWeeklyRecapForMembers',
                Report: true
            },
            SendBatchWelcomeEmail: {
                EntityType: 'ProvisionActivity',
                SkipNeeded: true,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 100,
                GetTotalServiceName: 'Provision',
                GetTotalMethodName: 'GetTotalMemberAddedActivities',
                DataServiceName: 'Provision',
                DataMethodName: 'GetMemberAddedActivitiesBatch',
                ProcessingServiceName: 'Provision',
                ProcessingMethodName: 'ProcessBatchWelcomeEmail',
                Report: true
            },
            UpdateOverDueReviewStatus: {
                EntityType: 'Member',
                SkipNeeded: false,//if the DataMethod could pick up the same chunk of data after they are processed, this is set to true
                ChunkSize: 50,
                GetTotalServiceName: 'Performance',
                GetTotalMethodName: 'GetTotalOverdueReviews',
                DataServiceName: 'Performance',
                DataMethodName: 'GetNextBatchOverDueReviews',
                ProcessingServiceName: 'Performance',
                ProcessingMethodName: 'UpdateOverDueReviewStatusBatch',
                Report: true
            },
            SendWelcomeEmails: {
                EntityType: 'Member',
                SkipNeeded: true,      //if the DataMethod could pick up the same chunk of data after they are processed, this is set to false
                ChunkSize: 100,
                GetTotalServiceName: 'Provision',
                GetTotalMethodName: 'GetTotalUnloggedMembers',
                DataServiceName: 'Provision',
                DataMethodName: 'GetUnloggedMembers',
                ProcessingServiceName: 'Provision',
                ProcessingMethodName: 'BatchSendMemberWelcomeEmail',
                Report: true
            },
            ProvisionNewLocations: {
                EntityType: 'ProvisionStagedLocation',
                SkipNeeded: false,
                ChunkSize: 200,
                GetTotalServiceName: 'ProvisionLocation',
                GetTotalMethodName: 'GetTotalNewLocations',
                DataServiceName: 'ProvisionLocation',
                DataMethodName: 'GetNextNewLocations',
                ProcessingServiceName: 'ProvisionLocation',
                ProcessingMethodName: 'CreateNewLocations',
                Report: true
            },
            ProvisionUpdateLocations: {
                EntityType: 'ProvisionStagedLocation',
                SkipNeeded: false,
                ChunkSize: 200,
                GetTotalServiceName: 'ProvisionLocation',
                GetTotalMethodName: 'GetTotalExistingLocations',
                DataServiceName: 'ProvisionLocation',
                DataMethodName: 'GetNextExistingLocations',
                ProcessingServiceName: 'ProvisionLocation',
                ProcessingMethodName: 'UpdateLocations',
                Report: true
            },
            ProvisionNewMembers: {
                EntityType: 'ProvisionStagedMember',
                SkipNeeded: false,
                ChunkSize: 250,
                GetTotalServiceName: 'ProvisionMember',
                GetTotalMethodName: 'GetTotalNewMembers',
                DataServiceName: 'ProvisionMember',
                DataMethodName: 'GetNextNewMembers',
                ProcessingServiceName: 'ProvisionMember',
                ProcessingMethodName: 'CreateNewMembers',
                Report: true
            },
            ProvisionUpdateMembers: {
                EntityType: 'ProvisionStagedMember',
                SkipNeeded: false,
                ChunkSize: 250,
                GetTotalServiceName: 'ProvisionMember',
                GetTotalMethodName: 'GetTotalExistingMembers',
                DataServiceName: 'ProvisionMember',
                DataMethodName: 'GetNextExistingMembers',
                ProcessingServiceName: 'ProvisionMember',
                ProcessingMethodName: 'UpdateMembers',
                Report: true
            },
            ProvisionMemberProcessType: {
                EntityType: 'ProvisionStagedMember',
                SkipNeeded: false,
                ChunkSize: 250,
                GetTotalServiceName: 'ProvisionMember',
                GetTotalMethodName: 'GetTotalUserCreationAndUpdate',
                DataServiceName: 'ProvisionMember',
                DataMethodName: 'GetNextUserCreationAndUpdate',
                ProcessingServiceName: 'ProvisionMember',
                ProcessingMethodName: 'SetUserCreationAndUpdateType',
                Report: true
            },
            ProvisionCompletedEvent: {
                EntityType: 'ProvisionStagedMember',
                SkipNeeded: false,
                ChunkSize: 250,
                GetTotalServiceName: 'ProvisionMember',
                GetTotalMethodName: 'GetTotalNewUsersCreated',
                DataServiceName: 'ProvisionMember',
                DataMethodName: 'GetNextNewUsersCreated',
                ProcessingServiceName: 'ProvisionMember',
                ProcessingMethodName: 'CreateAddedMembersEvent',
                Report: true
            }
        }
    },
    util = require('./EnumsBase.js');

util.SetNames(Enums);
util.SetNames(Enums.BatchTypes, 'Name');

module.exports = Enums;
