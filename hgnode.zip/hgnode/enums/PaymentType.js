/*jslint node:true es5:true*/
'use strict';
var Enums = {
        CreditCard: 0,
        eCheck: 0,
        BillMeLater: 0
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
