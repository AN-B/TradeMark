'use strict';
var Enums = {
    getGalleries: 0,
    getCatalogs: 0,
    getCatalog: 0,
    getCategories: 0,
    getRewardsByCategory: 0,
    getRewardDetails: 0,
    getMemberAccount: 0,
    searchCatalogRewardsByKeyword: 0,
    searchCatalogRewardsByCostRange: 0,
    searchCategoryRewardsByKeyword: 0,
    searchCategoryRewardsByCostRange: 0,
    searchByCatalog: 0,
    searchByCategory: 0,
    getBrandsByCategory: 0,
    placeOrder: 0,
    getOrderStatus: 0,
    createSubordinateAccount: 0,
    updateSubordinateAccount: 0,
    getSsoSession: 0
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;