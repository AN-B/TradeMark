/*jslint node:true es5:true*/
'use strict';
var Enums = {
    Extension: {
        xlsx: 0,
        zip: 0,
        json: 0,
        csv: 0,
        txt: 0,
        pdf: 0
    },
    Status: {
        Pending: 0,
        Processing: 0,
        Ready: 0,
        Downloaded: 0,
        Expired: 0
    },
    ResponseType: {
        EXCEL: 0
    },
    GoalActivityReport: {
        Team: 'Department',
        Member: 'Individual',
        Company: 'Company',
        PersonalGoal: 'Personal Goal',
        Cycle: 0,
        Goal: 0,
        GoalCycleParticipant: 0,
        Public: 0,
        Private: 0
    },
    ExportProductOrderReport: 0,
    ExportGoalCycleReport: 0,
    ExportCheckInReport: 0,
    ExportCheckInDetailsReport: 0,
    ExportFeedbackRequestReport: 0,
    ExportGroupLocations: 0,
    ExportSurveyKioskAccessCode: 0,
    ExportSurveyActivityReport: 0,
    ExportGroupSurveyResult: 0,
    ExportGroupSurveyDriverResult: 0,
    ExportGroupSurveyComments: 0,
    ProgressStatus: {
        AtRisk: 'At Risk',
        OnTrack: 'On Track',
        Behind: 'Behind'
    },
    ProfileSummaryReport: 0
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
