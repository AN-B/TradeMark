'use strict';
var Enums = {
    AuthType: {
        Password: 0,
        AuthCode: 0
    }
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
