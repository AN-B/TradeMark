/*jslint node:true es5:true*/
'use strict';
var DailyHourRangeType = {
        ThreeHour: 3,
        Custom: 'Custom'
    },
    month = ["January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"];
DailyHourRangeType.GetHourlyRange = function (vDate, hourlyRange) {
    function getDate(d, t) {
        return new Date(d + " " + t).getTime();
    }
    vDate =  new Date(vDate);
    vDate = new Date(vDate.getFullYear() + "/" + (vDate.getMonth() + 1) + "/" + vDate.getDate());
    var dailyHourRanges = [],
        monthName = month[vDate.getMonth()],
        temp = new Date(parseInt(vDate.getTime(), 10)),
        c = [temp.getFullYear(), "/", parseInt(temp.getMonth() + 1, 10), "/", temp.getDate()].join('');
    switch (hourlyRange) {
    case 'Custom':
        dailyHourRanges.push({TimeDuration: '0to10', Month: monthName, Date: DailyHourRangeType.ConvertToPlainDay(vDate.getTime()), Range: c + " 0:00:00 to 9:59:59", Start: getDate(c, "0:00:00"), End: getDate(c, "09:59:59")});
        dailyHourRanges.push({TimeDuration: '10to3', Month: monthName, Date: DailyHourRangeType.ConvertToPlainDay(vDate.getTime()), Range: c + " 10:00:00 to 14:59:59", Start: getDate(c, "10:00:00"), End: getDate(c, "14:59:59")});
        dailyHourRanges.push({TimeDuration: '3to12', Month: monthName, Date: DailyHourRangeType.ConvertToPlainDay(vDate.getTime()), Range: c + " 15:00:00 to 23:59:59", Start: getDate(c, "15:00:00"), End: getDate(c, "23:59:59")});
        break;
    case 'Daily':
        dailyHourRanges.push({TimeDuration: '0to23', Month: monthName, Date: DailyHourRangeType.ConvertToPlainDay(vDate.getTime()), Range: c + " 0:00:00 to 23:59:59", Start: getDate(c, "0:00:00"), End: getDate(c, "23:59:59")});
        break;
    default:
    }
    return dailyHourRanges;
};
DailyHourRangeType.ConvertToPlainDay = function (timestamp) {
    var d = new Date(timestamp),
        plainDay,
        temp = [d.getFullYear(), "/", d.getMonth() + 1, "/", d.getDate()].join('');
    plainDay = new Date(temp + " " + "0:00:00");
    return plainDay.getTime();
};
DailyHourRangeType.GetMonth = function (index) {
    return month[index];
};
DailyHourRangeType.GetTimeRange = function (vdate) {
    var temp = new Date(vdate),
        justDate = [temp.getFullYear(), "/", parseInt(temp.getMonth() + 1, 10), "/", temp.getDate()].join(''),
        timeRange,
        firstPeriod = new Date(justDate + " " + "09:59:59").getTime(),
        secondPeriod = new Date(justDate + " " + "14:59:59").getTime();
    if (vdate <= firstPeriod) {
        timeRange = '0to10';
    } else if (vdate <=  secondPeriod) {
        timeRange = '10to3';
    } else {
        timeRange = '3to12';
    }
    return timeRange;
};

module.exports = DailyHourRangeType;