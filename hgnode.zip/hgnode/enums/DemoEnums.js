/*jslint node:true es5:true*/
'use strict';

// use these enums as a reference for cluster messages
var Enums = {
    Type: {
        FullPlatform: 0,
        RecognitionReward: 0,
        RecognitionSurvey: 0,
        Performance: 0,
        Survey: 0
    }
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
