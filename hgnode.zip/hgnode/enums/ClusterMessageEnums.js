/*jslint node:true es5:true*/
'use strict';

// use these enums as a reference for cluster messages
var Enums = {
    UpdateClusterCache: 0,
    UpdateCacheTimestamp: 0,
    GroupPreferencesTimestamp: 0,
    UpdateCustomTerminology: 0,
    RemoveCustomTerminology: 0,
    CustomTerminologyTimestamp: 0
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
