/*jslint node:true es5:true*/
'use strict';
var Enums = {
    CSS: require('../../static/templates/server/track/track-in-progress-css.html'),
    BodyTable: require('../../static/templates/server/track/track-in-progress-body.html'),
    Greeting: require('../../static/templates/server/track/track-in-progress-greeting.html'),
    TracksInProgress: require('../../static/templates/server/track/track-in-progress-header.html'),
    TrackInProgressRow: require('../../static/templates/server/track/track-in-progress-row.html')
};

module.exports = Enums;
