/*jslint node:true es5:true*/
'use strict';
var Enums = {
        Applications: {
            SalesForce: 0,
            GitHub: 0,
            EchoOptimizer: 0,
            GRS: 0,
            Yammer: 0
        }
    };
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
