/*jslint node:true es5:true*/
'use strict';
var EntityEnums = require('../enums/EntityEnums.js'),
    Enums = {
        Action: {
            SuccessfulAndRemove: 0,
            FailedAndRemove: 0,
            Retry: 0,
            ModifyPayload: 0,
            RequestEntityTooLarge: 0
        },

        RecapMode: {
            Regular: 0,
            Friday: 0,
            Monday: 0,
            NoMail: 0
        },

        DeliveryMethod: {
            Email: 0,
            HGInternal: 0,
            SMS: 0,
            Facebook: 0
        },

        FrequencyInterval: {
            Weekly: 7,
            Monthly: 28,
            Quarterly: 89
        },

        Category: {
            Conversation: 0,
            General: 0,
            Goal: 0,
            Group: 0,
            Recognize: 0,
            Perform: 0,
            Motivate: 0,
            Track: 0,
            User: 0,
            VirtualCurrency: 0,
            Recap: 0,
            Survey: 0,
            Product: 0,
            Provision: 0,
            Feedback: 0
        },

        DispatchOption: {
            Now: 0,
            Queue: 0
        },

        Event: {
            Anniversary: {
                DisplayText: 'Anniversary',
                Category: 'User',
                TemplateId: 39451,//6418,
                Subject: 'Happy Anniversary, from ${company}!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                FeatureDepends: 'Recognize'
            },
            Birthday: {
                DisplayText: 'Birthday',
                Category: 'User',
                TemplateId: 39451,//6419,
                Subject: 'Happy Birthday, from ${company}!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                FeatureDepends: 'Recognize'
            },
            UserRequestedInfo: {
                DisplayText: 'User Requested Info',
                Category: 'User',
                TemplateId: 19806,
                Subject: 'Someone requested to be contacted by HighGround!',
                UserCannotDisable: true
            },
            CommentReceived: {
                DisplayText: 'Comment Received',
                Category: 'Recognize',
                TemplateId: 6373,
                Subject: 'You have 1 new comment',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            PerformanceReviewsCreated: {
                DisplayText: 'Performance Reviews Created',
                Category: 'Perform',
                UserCannotDisable: true
            },
            PerformanceCycleRevieweeAdded: {
                DisplayText: 'Performance Cycle Reviewee Added',
                Category: 'Perform',
                UserCannotDisable: true
            },
            AddedAllMembersToGoalCycle: {
                DisplayText: 'All members in group have been added to goal cycle',
                Category: 'Goal',
                UserCannotDisable: true
            },
            RemovedAllMembersFromGoalCycle: {
                DisplayText: 'All members in group have been removed from goal cycle',
                Category: 'Goal',
                UserCannotDisable: true
            },
            GoalCycleParticipantUploadError: {
                DisplayText: 'Goal CycleParticipant Upload Failed',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'Error happened when processing your uploaded file.',
                UserCannotDisable: true,
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroup.HGAdmin]
            },
            GoalCycleParticipantUploadProcessed: {
                DisplayText: 'Goal CycleParticipant Upload Processed',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'Your uploaded goal participant file has been processed.',
                UserCannotDisable: true,
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroup.HGAdmin]
            },
            GoalCycleBuilt: {
                DisplayText: 'Goal Cycle Built',
                Category: 'Goal',
                TemplateId: 39451,
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroup.HGAdmin]
            },
            AllReviewsClosedInCycle: {
                DisplayText: 'All Reviews are closed in a cycle',
                Category: 'Perform',
                UserCannotDisable: true
            },
            AllReviewsArchivedInCycle: {
                DisplayText: 'All Reviews are deleted in a cycle',
                Category: 'Perform',
                UserCannotDisable: true
            },
            GoalCyclePublished: {
                DisplayText: 'Goal Cycle Published',
                Category: 'Goal',
                UserCannotDisable: true
            },
            GoalSet: {
                DisplayText: 'Goal Set',
                Category: 'Goal',
                UserCannotDisable: true
            },
            GoalClosed: {
                DisplayText: 'Goal Closed',
                Category: 'Goal',
                UserCannotDisable: true
            },
            GoalUpToDate: {
                DisplayText: 'Goal up to date',
                Category: 'Goal',
                UserCannotDisable: true
            },
            TemplateGoalAssigned: {
                DisplayText: 'Goals have been assigned to you!',
                Category: 'Goal',
                TemplateId: 39451,//24099
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCycleDelivered: {
                DisplayText: 'Goal Cycle Delivered',
                Category: 'Goal',
                TemplateId: 39451,//24099
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCycleBatchDelivered: {
                DisplayText: 'Goal Cycle Batch Delivered',
                Category: 'Goal',
                UserCannotDisable: true
            },
            GoalDeleted: {
                DisplayText: 'Goal deleted',
                Category: 'Goal',
                UserCannotDisable: true
            },
            GoalCycleDeleted: {
                DisplayText: 'Goal cycle deleted',
                Category: 'Goal',
                UserCannotDisable: true
            },
            ParticipantRemovedFromCycle: {
                DisplayText: 'Participant Removed From Cycle',
                Category: 'Goal',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCreationReminder: {
                DisplayText: 'Goal Creation Reminder',
                Category: 'Goal',
                // TemplateId: 31155,
                TemplateId: 39451,
                Subject: 'Your goals are due soon!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalOverdueReminder: {
                DisplayText: 'Goal Overdue Reminder',
                Category: 'Goal',
                // TemplateId: 35016,
                TemplateId: 39451,
                Subject: 'Your goals are overdue!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CloseAdhocGoalPrompt: {
                DisplayText: 'Close Goal Prompt (Adhoc)',
                Category: 'Goal',
                TemplateId: 39451,// 35692,
                Subject: 'Your goal(s) are due soon!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CloseSingleAdhocGoalReminder: {
                DisplayText: 'Close Goal Prompt (Single Adhoc Reminder)',
                Category: 'Goal',
                TemplateId: 39451,// 35799,
                Subject: "Reminder, it's time to close your goal!",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CloseGoalPrompt: {
                DisplayText: 'Close Goal Prompt',
                Category: 'Goal',
                TemplateId: 39451,//31172,
                Subject: 'Time to close your goal(s)',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CloseGoalOverdue: {
                DisplayText: 'Close Goal Overdue',
                Category: 'Goal',
                TemplateId: 39451,//31175,
                Subject: "You're overdue closing your goals!",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCycleOwnershipTransferred: {
                DisplayText: 'Goal Cycle Ownership Transferred',
                Category: 'Goal',
                TemplateId: 39451,// 35928,
                Subject: 'Goal Cycle ownership has been transferred to you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalOwnershipTransferred: {
                DisplayText: 'Goal Approver Transferred',
                Category: 'Goal',
                TemplateId: 42753,// 35434,
                Subject: 'Goal approver has been transferred to you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalApproverTransferred: {
                DisplayText: 'Goal Ownership Transferred',
                Category: 'Goal',
                TemplateId: 42753,// 35434,
                Subject: 'Goal ownership has been transferred to you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalSetRequested: {
                DisplayText: 'Goal Set Requested',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'Someone has submitted goal for your approval',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCreatedForYou: {
                DisplayText: 'Goal created for you',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'A goal was created for you.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCloseRequested: {
                DisplayText: 'Goal Close Requested',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'Someone has submitted goal for your approval to close',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalSetRejected: {//used "Goal" because this email is sent for every returned goal
                DisplayText: 'Goal Set returned',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'One of your goals has been returned',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCloseRejected: {//used "Goal" because this email is sent for every returned goal
                DisplayText: 'Goal Close rejected',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'One of your goals need updates before it can be closed',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalsSetApproved: {//used "Goals" because this email is sent when all goals of the user with the cycle get approved
                DisplayText: 'Goals Set Approved',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'Your goal has been approved',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalsClosureApproved: {//used "Goals" because this email is sent when all goals of the user with the cycle get approved
                DisplayText: 'Goals Closure Approved',
                Category: 'Goal',
                TemplateId: 39451,
                Subject: 'Your request to close a goal has been approved',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GoalCheckIn: {//used "Goals" because this email is sent when all goals of the user with the cycle get approved
                DisplayText: 'Goal Check in',
                Category: 'Goal',
                TemplateId: 42753,//30664,
                Subject: 'Check Your Goal Progress',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            FeedbackSessionAccepted: {
                DisplayText: 'Feedback Session Accepted',
                Category: 'Feedback',
                UserCannotDisable: true
            },
            FeedbackReviewerReadNote: {
                DisplayText: 'Feedback Reviewer read thank you note from subject',
                Category: 'Feedback',
                UserCannotDisable: true
            },
            FeedbackRequestExpired: {
                DisplayText: 'Feedback Session Expired',
                Category: 'Feedback',
                Subject: 'Your request for feedback has been declined.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            FeedbackSessionDeclined: {
                DisplayText: 'Feedback Session Declined',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'Your request for feedback has been declined.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            FeedbackSessionRequested: {
                DisplayText: 'Feedback Session Requested',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'You are invited to provide feedback.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            FeedbackSessionSubmitted: {
                DisplayText: 'Feedback Session submitted.',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'A feedback has been submitted for you.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            EvaluateOthersSubmitted: {
                DisplayText: 'Evaluate others Session submitted.',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'A feedback has been submitted.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            FeedbackCheckInManagerNotesAvailable: {
                DisplayText: 'Your Check-In is complete!',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'Your Check-In is complete!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            FeedbackCheckInSignedOff: {
                DisplayText: 'Check-In Session was signed off',
                Category: 'Feedback',
                UserCannotDisable: true
            },
            FeedbackCheckInNeedsSignOff: {
                DisplayText: 'Check-In Session needs sign off',
                Category: 'Feedback',
                UserCannotDisable: true
            },
            SelfEvaluationSubmitted: {
                DisplayText: 'Self Evaluation Session Submitted.',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'A self evaluation has been submitted by your team member.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                RequiresDirectReport: true
            },
            GiveFeedbackSubmitted: {
                DisplayText: 'Give feedback submitted.',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'Give feedback session submitted by your team member.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                RequiresDirectReport: true
            },
            FeedbackSessionRated: {
                DisplayText: 'Feedback Session rated.',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'Your feedback has been rated.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            FeedbackRequestExpiring: {
                DisplayText: 'Feedback request expiring.',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'A feedback request is about expire.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            EmptyFeedbackCycle: {
                DisplayText: 'Feedback cycle does not have any participants',
                Category: 'Feedback',
                UserCannotDisable: true
            },
            FeedbackCardAvailable: {
                DisplayText: 'Feedback card available.',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'A feedback form has been published.',
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroup.HGAdmin]
            },
            SelfEvaluationDelivered: {
                DisplayText: 'Self evaluation card has been assigned to you!',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: 'Self evaluation card has been assigned to you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            TalentInsightAssessmentDelivered: {
                DisplayText: 'Talent insight assessment has been assigned to you!',
                Category: 'Feedback',
                TemplateId: 39451,
                Subject: "It's time to complete your Talent Insights assessment",
                UserCannotDisable: true
            },
            FeedbackCycleClosedOrArchived: {
                DisplayText: 'Feedback Form closed.',
                Category: 'Feedback',
                TemplateId: 42753,
                Subject: 'Feedback form has been closed.',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            PetitionArchived: {
                DisplayText: 'Petition Archived',
                Category: 'Goal',
                UserCannotDisable: true
            },
            PetitionApproverReplaced: {
                DisplayText: 'Petition Approver Replaced',
                Category: 'Goal',
                UserCannotDisable: true
            },
            ReviewReadyToView: {
                DisplayText: 'Review Ready To View',
                Category: 'Perform',
                TemplateId: 18183,
                Subject: 'Take a look! Review is now available for you to view!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReviewDelivered: {
                DisplayText: 'Review Delivered',
                Category: 'Perform',
                TemplateId: 16119,
                Subject: 'A review has been assigned to you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ClosedReview: {
                DisplayText: 'Review Closed',
                Category: 'Perform',
                TemplateId: 13288,
                Subject: 'Review has been closed!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            YouSubmittedReview: {
                DisplayText: 'Your review has been submitted',
                Category: 'Perform',
                TemplateId: 11003,
                Subject: 'Thanks for submitting the review!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReviewReadyToSignOff: {
                DisplayText: 'Review Ready To Sign Off',
                Category: 'Perform',
                TemplateId: 26714,
                Subject: 'Your review is now waiting for you to sign off',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            OtherSubmittedReview: {
                DisplayText: 'A review has been submitted for you',
                Category: 'Perform',
                TemplateId: 11005,
                Subject: 'A review has been submitted for you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CreatedbySubmittedReview: {
                DisplayText: 'A review has been submitted for you',
                Category: 'Perform',
                TemplateId: 11005,
                Subject: 'A review has been submitted for you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ProductIdeaSuggested: {
                DisplayText: 'A Product Suggestion has been submitted',
                Category: 'Product',
                TemplateId: 24452,
                Subject: 'A Product Suggetion has been submitted!',
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroup.HGAdmin]
            },
            CampaignFunded: {
                DisplayText: 'A campaign has been funded 100%',
                Category: 'Product',
                TemplateId: 25475,
                Subject: 'A campaign has been funded 100%!',
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroup.HGAdmin]
            },
            ProductIdeaApproved: {
                DisplayText: 'A Product Suggestion has been approved',
                Category: 'Product',
                TemplateId: 24453,
                Subject: 'A Product Suggestion has been approved!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            UnsubmittedReview: {
                DisplayText: 'A review has been unsubmitted.',
                Category: 'Perform',
                TemplateId: 16891,
                Subject: 'A review has been unsubmitted!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReviewRejected: {
                DisplayText: 'A review has been rejected.',
                Category: 'Perform',
                TemplateId: 22183,
                Subject: 'Your review is rejected!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReviewRequestReject: {
                DisplayText: 'Review Request Reject',
                Category: 'Perform',
                TemplateId: 22423,
                Subject: 'Review Request Reject',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReviewRequestUnsubmit: {
                DisplayText: 'Review Request Unsubmit',
                Category: 'Perform',
                TemplateId: 22424,
                Subject: 'Review Request Unsubmit',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            PastOverdueDelivered: {
                DisplayText: 'Review',
                Category: 'Perform',
                TemplateId: 14444,
                Subject: 'Your review is late!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CycleReviewsClosedOrArchived: {
                DisplayText: 'Review',
                Category: 'Perform',
                TemplateId: 16094,
                Subject: 'Your review has been closed, no action required',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            RemovedFromCycle: {
                DisplayText: 'Review',
                Category: 'Perform',
                TemplateId: 23126,
                Subject: 'You have been removed from the review cycle',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReviewDeadlineDelivered: {
                DisplayText: 'Review',
                Category: 'Perform',
                TemplateId: 16093,
                Subject: 'Deadline approaching',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            RecognitionCommentReceived: {
                DisplayText: 'Recognition Comment Received',
                Category: 'Recognize',
                TemplateId: 184267,
                Subject: 'You have 1 new comment',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            RecognitionPointsAdded: {
                DisplayText: 'Recognition Points Added',
                Category: 'Recognize',
                TemplateId: 36174,
                Subject: 'Points added to recognition',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            RecognitionGive: {
                DisplayText: 'Time to recognize someone',
                Category: 'Recognize',
                TemplateId: 39451,
                Subject: 'Time to recognize someone',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            TrackCommentReceived: {
                DisplayText: 'TrackComment Received',
                Category: 'Track',
                TemplateId: 6379,
                Subject: '1 new comment on a track',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CoachingNoteReceived: {
                DisplayText: 'Coaching Note Received',
                Category: 'Recognize',
                TemplateId: 18710,
                Subject: '{Manager_Name} just gave you a coaching note',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CommentCoaching: {
                DisplayText: 'CommentCoaching',
                Category: 'Recognize',
                TemplateId: 22576,
                Subject: '{name} just commented on your coaching note',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CommentGoal: {
                DisplayText: 'CommentGoal',
                Category: 'Recognize',
                TemplateId: 39451,
                Subject: '{name} just commented on your goal',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            UserTagged: {
                DisplayText: 'Mentioned',
                Category: 'Recognize',
                TemplateId: 39451,
                Subject: '${commentor_name} just mentioned you in the comment',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CongratsReceived: {
                DisplayText: 'Congrats  Received',
                Category: 'Recognize',
                TemplateId: 6373,
                Subject: "You have 1 new 'Like'",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CommentLiked: {
                DisplayText: 'Comment Liked',
                Category: 'Recognize',
                TemplateId: 6373,
                Subject: 'Your comment was liked',
                UserCannotDisable: true
            },
            ContributorAdded: {
                DisplayText: 'Contributor Added',
                Category: 'Track',
                TemplateId: 6417,
                Subject: "You have been added as a collaborator",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CollaboratorAdded: {
                DisplayText: 'Contributor Added',
                Category: 'Track',
                TemplateId: 6417,
                Subject: "You have been added as a collaborator",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            CreditBillMeLater: {
                DisplayText: ' Credit Purchased',
                Category: 'Motivate',
                TemplateId: 6421,
                Subject: 'Your HighGround Purchase Invoice',
                UserCannotDisable: true
            },
            CreditPurchased: {
                DisplayText: 'Credit Purchased',
                Category: 'Motivate',
                TemplateId: 6382,
                Subject: 'Your Credits Purchase Receipt',
                UserCannotDisable: true
            },
            MemberDailyRecap: {
                DisplayText: 'Member Daily Recap',
                Category: 'Recap',
                TemplateId: 39877,
                Subject: 'Check your company activity, stay in the loop',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                DailyRecap: true
            },
            MemberWeeklyRecap: {
                DisplayText: 'Member Weekly Recap',
                Category: 'Recap',
                TemplateId: 39878,
                Subject: 'Check your company activity, stay in the loop',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                WeeklyRecap: true
            },
            MemberGoalStatus: {
                DisplayText: 'Employee Goal Status',
                Category: 'Recap',
                TemplateId: 20664,
                Subject: 'Employee Goal Status',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                RequiresDirectReport: true,
                FeatureDepends: 'Track'
            },
            ApproverOKRStatus: {
                DisplayText: 'Employee Goal Status',
                Category: 'Recap',
                TemplateId: 42753,//20664,
                Subject: 'Employee Goal Status',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                RequiresDirectReport: true,
                FeatureDepends: 'Goal'
            },
            TrackCheckIn: {
                DisplayText: 'Track Check-in',
                Category: 'Track',
                TemplateId: 17655,
                Subject: 'Check Your HighGround Goal Progress',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                RequiresDirectReport: true
            },
            EmployeeOnboarded: {
                DisplayText: 'New Employee onboarded in group',
                Category: 'Group',
                TemplateId: 39451,
                Subject: "You're invited to ${company}!",
                WelcomeBadgePendingOverride: true,
                UserCannotDisable: true
            },
            ResendWelcomeEmailCompleted: {
                DisplayText: 'New Employees onboarded emails have been queued',
                Category: 'Provision',
                TemplateId: 41650,
                Subject: 'Welcome emails have been queued for ${group_name}!',
                WelcomeBadgePendingOverride: true,
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroupHGAdmin]
            },
            ConversationStarted: {
                DisplayText: 'New Message',
                Category: 'Conversation',
                TemplateId: 18710,
                Subject: 'New Message received!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
            },
            ConversationComment: {
                DisplayText: 'New Message',
                Category: 'Conversation',
                TemplateId: 18710,
                Subject: 'New Message received!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
            },
            FeedbackReceived: {
                DisplayText: 'Feedback Received',
                Category: 'Conversation',
                TemplateId: 25101,
                Subject: 'You just got feedback!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
            },
            FeedbackRequested: {
                DisplayText: 'Feedback Requested',
                Category: 'Conversation',
                TemplateId: 25123,
                Subject: 'Feedback requested from you!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
            },
            FeedbackComment: {
                DisplayText: 'Comment Coaching',
                Category: 'Conversation',
                TemplateId: 25106,
                Subject: 'You just got feedback comment',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
            },
            GroupNewsPublished: {
                DisplayText: 'Group News Published',
                Category: 'Group',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                Templates: [
                    {
                        TemplateId: 6114,
                        Subject: "Check out what's new in your company!",
                        Name: 'GroupNewsPublished'
                    }
                ]
            },
            XpOrderCancelledRequester: {//you ordered something for yourself and it's cancelled
                DisplayText: 'XP Order cancelled',
                TemplateId: 36376,
                Category: 'VirtualCurrency',
                Subject: 'Order for ${product_name} cancelled',
                UserCannotDisable: true
            },
            XpOrderCancelledRecipient: {//you ordered something for yourself and it's cancelled
                DisplayText: 'XP Order cancelled',
                TemplateId: 36377,
                Category: 'VirtualCurrency',
                Subject: 'Order for ${product_name} cancelled',
                UserCannotDisable: true
            },
            XpOrderCancelledGifter: {//you ordered something for yourself and it's cancelled
                DisplayText: 'XP Order cancelled',
                TemplateId: 36375,
                Category: 'VirtualCurrency',
                Subject: 'Order for ${product_name} cancelled',
                UserCannotDisable: true
            },
            XpOrderPlacedRequester: {//you ordered something for yourself
                DisplayText: 'XP Order placed',
                TemplateId: 21195,
                Category: 'VirtualCurrency',
                Subject: 'Thanks for ordering from XP store!',
                UserCannotDisable: true
            },
            XpOrderPlacedGifter: {//you ordered something as a gift for someone
                DisplayText: 'XP Order placed',
                TemplateId: 19963,
                Category: 'VirtualCurrency',
                Subject: 'You gave ${gift_recipient_full_name} a ${product_name} reward',
                UserCannotDisable: true
            },
            XpOrderPlacedRecipient: {
                DisplayText: 'XP Order placed as a gift for you',
                TemplateId: 21203,
                Category: 'VirtualCurrency',
                Subject: 'Redeem your ${item_name}!',
                UserCannotDisable: true
            },
            XpProductItemExpired: {
                DisplayText: 'Xp Product Item Expired in your group',
                TemplateId: 21413,
                Category: 'VirtualCurrency',
                Subject: 'A product in your store has expired.'
            },
            XpCampaignItemExpired: {
                DisplayText: 'Xp Campaign Item Expired in your group',
                TemplateId: 25476,
                Category: 'VirtualCurrency',
                Subject: 'A campaign has expired.',
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroupHGAdmin]
            },
            XpOrderPlacedAdmin: {
                DisplayText: 'XP Order placed in your group',
                TemplateId: 19564,
                Category: 'VirtualCurrency',
                Subject: 'New order placed by ${Recipient_full_name}',
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroupHGAdmin]
            },
            AdminPointsReplenished: {
                DisplayText: 'Your Points have been replenished!',
                TemplateId: 30652,
                Category: 'VirtualCurrency',
                Subject: 'Your Points have been replenished!',
                Roles: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroupHGAdmin]
            },
            AdminIssuedPoints: {
                DisplayText: 'You just received points to give!',
                TemplateId: 36008,
                Category: 'VirtualCurrency',
                Subject: "You've received points!",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            MilestoneApproved: {
                DisplayText: 'Milestone Approved',
                TemplateId: 6420,
                Category: 'Track',
                Subject: "You've completed a milestone!",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            MilestoneCompleted: {
                DisplayText: 'Milestone Completed',
                TemplateId: 16039,
                Category: 'Track',
                Subject: 'A milestone has been completed!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            OffBoardMember: {
                DisplayText: 'Member is off boarded',
                Category: 'Group',
                TemplateId: 42753,//6412,
                Subject: 'HighGround ${group} account disabled',
                UserCannotDisable: true
            },
            TransferCreditsComplete: {
                DisplayText: 'Transfer Credits Complete',
                Category: 'Motivate',
                TemplateId: 39451,
                Subject: "You've just been given credits!",
                UserCannotDisable: true
            },
            RefundCreditsComplete: {
                DisplayText: 'Refund Credits Complete',
                Category: 'General',
                TemplateId: 35175,
                Subject: "${admin_user_name} refunded ${employee_name} ${count_credits_refunded} credits!",
                UserCannotDisable: true
            },
            AuthCodeCreated: {
                DisplayText: 'Auth Code Created',
                Category: 'User',
                TemplateId: 32167,
                Subject: 'Mobile Authorization Code',
                UserCannotDisable: true
            },
            PasswordResetRequestCreated: {
                DisplayText: 'Password reset request created',
                Category: 'User',
                TemplateId: 39451,
                Subject: 'Reset your HighGround password',
                WelcomeBadgePendingOverride: true,
                UserCannotDisable: true
            },
            PasswordChanged: {
                DisplayText: 'Password changed',
                Category: 'User',
                TemplateId: 39451,//16400,
                Subject: 'Password reset confirmation',
                WelcomeBadgePendingOverride: true,
                UserCannotDisable: true
            },
            RecognitionReceived: {
                DisplayText: 'Recognition Received',
                Category: 'Recognize',
                TemplateId: 38320,
                Subject: 'You have been recognized!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            GiveRecognitionError: {
                DisplayText: 'Deliver Recognition Error',
                Category: 'Recognize',
                TemplateId: 42753,
                Subject: 'There is an issue delivering your recognition',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            PulseSurveyOverdue: {
                DisplayText: 'Pulse Survey Overdue',
                Category: 'Survey',
                TemplateId: 42753,
                Subject: 'Your response is overdue!',
                UserCannotDisable: true
            },
            SurveyDelivered: {
                DisplayText: 'Engagement Survey',
                Category: 'Survey',
                TemplateId: 29347,
                Subject: 'Engagement Survey!',
                UserCannotDisable: true
            },
            SurveyDueSoon: {
                DisplayText: 'Engagement Survey due',
                Category: 'Survey',
                TemplateId: 29487,
                Subject: 'Your Survey responses are due soon!',
                UserCannotDisable: true
            },
            SurveyCompleted: {
                DisplayText: 'Engagement Survey results',
                Category: 'Survey',
                TemplateId: 29488,
                Subject: 'Engagement Survey results are ready for viewing!',
                UserCannotDisable: true
            },
            ProcessingFailed: {
                DisplayText: 'Uploaded File Failed Validation',
                Category: 'Provision',
                TemplateId: 32092,
                Subject: 'The File you provisioned has errors',
                UserCannotDisable: true
            },
            FileRequiresApproval: {
                DisplayText: 'Uploaded File requires approval',
                Category: 'Provision',
                TemplateId: 32110,
                Subject: 'The File you provisioned requires your confirmation',
                UserCannotDisable: true
            },
            FileProcessed: {
                DisplayText: 'Uploaded File processed',
                Category: 'Provision',
                TemplateId: 32245,
                Subject: 'The File you provisioned has been processed',
                UserCannotDisable: true
            },
            WelcomeReceived: {
                DisplayText: 'Welcome Recognition Received',
                Category: 'Recognize',
                TemplateId: 38320,
                Subject: 'Welcome to HighGround!',
                UserCannotDisable: true
            },
            PublicRecognitionReceived: {
                DisplayText: 'Public Recognition Received/Rated',
                Category: 'Recognize',
                TemplateId: 39451,
                Subject: 'Public Recognition/Rating received',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            PublicFeedbackReceived: {
                DisplayText: 'Public Feedback Received/Rated',
                Category: 'Recognize',
                TemplateId: "39458",
                // TemplateId: 16897,
                Subject: 'Public Feedback Received/Rated',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            TrackAssigned: {
                DisplayText: 'Track Assigned',
                Category: 'Track',
                TemplateId: 6374,
                Subject: "You've been assigned a track",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            TrackCompleted: {
                DisplayText: 'Track Completed',
                Category: 'Track',
                TemplateId: 6415,
                Subject: '${track_assignee} has completed a track!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            TrackCompletionRequested: {
                DisplayText: 'Track Completion Requested',
                Category: 'Track',
                TemplateId: 6423,
                Subject: 'Track completion approval requested',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            TrackCompletionRequestApproved: {
                DisplayText: 'Track Completion Request Approved',
                Category: 'Track',
                TemplateId: 6422,
                Subject: "You've completed a track!",
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
                RequiresDirectReport: true
            },
            UserLockedOut: {
                DisplayText: 'User Locked Out',
                Category: 'User',
                TemplateId: 6414,
                Subject: "Can't get into HighGround?",
                UserCannotDisable: true
            },
            UserNotificationEmailChanged: {
                DisplayText: 'User Notification Email Changed',
                Category: 'User',
                TemplateId: 42753,
                Subject: 'Email address update confirmation',
                UserCannotDisable: true
            },
            OverdueMilestones: {
                DisplayText: 'Overdue Milestones',
                Category: 'Track',
                TemplateId: 6381,
                Subject: 'Overdue milestones',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup),
            },
            EventBusError: {
                Category: 'General',
                DisplayText: 'EventBusError',
                TemplateId: 20219,
                Subject: 'Event Bus Error!',
                UserCannotDisable: true
            },
            ScheduledOffboardError: {
                Category: 'General',
                DisplayText: 'ScheduledOffboardError',
                TemplateId: 38354,
                Subject: 'Error happened for scheduled offboard Member!',
                UserCannotDisable: true
            },
            BatchEngineError: {
                Category: 'General',
                DisplayText: 'BatchEngineError',
                TemplateId: 36319,
                Subject: 'Batch Engine Error!',
                UserCannotDisable: true
            },
            MonthlyInvoice: {
                Category: 'General',
                DisplayText: 'MonthlyInvoice',
                TemplateId: 23364,
                Subject: 'Monthly Invoice!',
                Roles: [EntityEnums.MembersRoleInGroupHGAdmin],
                UserCannotDisable: true
            },
            SuppressedEmail: {
                Category: 'General',
                DisplayText: 'Suppressed Email',
                TemplateId: 58662,
                Subject: 'Active Members on Suppressed Email List',
                Roles: [EntityEnums.MembersRoleInGroupHGAdmin],
                UserCannotDisable: true
            },
            TangoOrderLoadUserError: {
                Category: 'Motivate',
                DisplayText: 'Tango error loading user',
                TemplateId: 90902,
                Subject: 'Action required: TangoCard error when user purchased giftcard!',
                UserCannotDisable: true
            },
            TangoGiftcardOrderRequestError: {
                Category: 'Motivate',
                DisplayText: 'Tango error loading order request',
                TemplateId: 90907,
                Subject: 'Action required: TangoCard error when user purchased giftcard!',
                UserCannotDisable: true
            },
            TangoErrorInGiftcardPurchase: {
                Category: 'Motivate',
                DisplayText: 'Tango error during gift card purchase',
                TemplateId: 17056,
                Subject: 'Action required: TangoCard error when user purchased giftcard!',
                UserCannotDisable: true
            },
            ManualGiftcardOrderSubmittedAdmin: {
                Category: 'Motivate',
                DisplayText: 'Manual fulfillment gift card ordered',
                TemplateId: 166941,
                Subject: 'Action required: Manual fulfillment gift card ordered, please fulfill!',
                UserCannotDisable: true
            },
            TangoGiftCard: {
                Category: 'Motivate',
                DisplayText: 'Gift card order fulfilled.',
                Subject: 'Your gift card order has been processed successfully.',
                UserCannotDisable: true
            },
            ExportGroupDataRequest: {
                DisplayText: 'HighGround Data export is ready',
                Category: 'Group',
                TemplateId: 19664,
                Subject: 'HighGround Data export is ready',
                UserCannotDisable: true
            },
            AccountsMerged: {
                DisplayText: 'Accounts Merged',
                Category: 'Provision',
                TemplateId: 64583,
                Subject: 'Accounts Merged',
                UserCannotDisable: true
            },
            ReportReadyToDownload: {
                DisplayText: 'Report is ready to download',
                Category: 'Group',
                TemplateId: 26073,
                Subject: 'Your report is ready to download!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReportNotProcessed: {
                DisplayText: 'Report was not processed',
                Category: 'Group',
                TemplateId: 36572,
                Subject: 'Your report was not processed!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            YearSummaryReportReady: {
                DisplayText: 'Profile Summary Report is ready to download',
                Category: 'Group',
                TemplateId: 39451,
                Subject: 'Profile Summary Report is ready to download',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ProductIdeaRejected: {
                DisplayText: 'A Product Suggestion has been rejected',
                Category: 'Product',
                TemplateId: 24454,
                Subject: 'Your product has been rejected!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ProductIdeaPurchased: {
                Category: 'Product',
                TemplateId: 25605,
                Subject: 'Your product has been Purchased!',
                Roles: Object.keys(EntityEnums.MembersRoleInGroup)
            },
            ReviewEditRequest: {
                Category: 'Perform',
                Subject: 'requested you un-submit their review so they can edit it.',
                UserCannotDisable: true
            },
            ReviewRejectRequest: {
                Category: 'Perform',
                Subject: 'requested you reject their review so they can edit it.',
                UserCannotDisable: true
            },
            ServiceAwardPointMissing: {
                DisplayText: 'ServiceAwardPointMissing',
                Category: 'Recognize',
                TemplateId: 39451,
                Subject: 'You have been recognized!',
                UserCannotDisable: true
            }
        }
    },
    util = require('./EnumsBase.js');
util.SetNames(Enums);
util.SetNames(Enums.Event, 'Name');

Enums.GetEventsInCategory = function (CategoryName) {
    var keys = Object.keys(Enums.Event),
        i,
        len = keys.length,
        events = [];
    for (i = 0; i < len; i += 1) {
        if (Enums.Event[keys[i]].Category === CategoryName) {
            events.push(Enums.Event[keys[i]]);
        }
    }
    return events;
};

Enums.GetTemplateList = function () {
    var keys = Object.keys(Enums.Event),
        i,
        len = keys.length,
        list = [],
        item;
    for (i = 0; i < len; i += 1) {
        item = Enums.Event[keys[i]];
        list.push({
            Name: item.Name,
            TemplateId: item.TemplateId
        });
    }
    return list;
};

module.exports = Enums;
