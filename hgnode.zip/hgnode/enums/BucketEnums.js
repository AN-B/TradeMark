/*jslint node:true es5:true*/
'use strict';
var Enums = {
        EntityType : {
            MemberRelevancy: 0
        },
        Status: {
            Active: 0,
            Archived: 0
        },
        BucketTypes: {
            MemberRelevancy: {
                EntityType: 'MemberRelevancy',
                BucketCap: 500,
                KeyName: "MemberId",
                ContentFieldName: 'Relevants',
                SizeFieldName: "Size"
            }
        }
    },
    util = require('./EnumsBase.js');

util.SetNames(Enums);
util.SetNames(Enums.BucketTypes, 'Name');

module.exports = Enums;
