/*jslint node:true es5:true*/
'use strict';
var Enums = {
    QuestionStatus: {
        Pending: 0,
        Dismissed: 0,
        Completed: 0
    },
    Status: {
        Active: 0,
        Scheduled: 0,
        InProgress: 0,
        Archived: 0
    },
    ParticipantType: {
        Member: 0,
        Location: 0,
        Department: 0,
        All: 0
    }
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;
