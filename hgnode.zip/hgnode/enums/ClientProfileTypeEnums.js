'use strict';
var Enums = {
    Group: 0,
    Partner: 0
};
require('./EnumsBase.js').SetNames(Enums);

module.exports = Enums;