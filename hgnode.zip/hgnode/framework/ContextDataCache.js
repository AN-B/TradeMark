/*jslint node:true es5:true*/
'use strict';

//this is to store context data that has the same lifecycle as the service request. Doing experiment for now. the pattern isn't mature enough to follow
//the purpose is to store the data that will be used by several functions chained by events.
//Talk to gary if you want to use it


var ContextDataCache = {};

module.exports = ContextDataCache;
