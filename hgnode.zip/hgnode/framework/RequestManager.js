/*jslint node:true es5:true*/
var RequestManager = function () {
    'use strict';
    var uuid = require('node-uuid'),
        ContextDataCache = require('../framework/ContextDataCache.js'),
        EventEmitter = require('../framework/EventEmitterCache.js'),
        Logger = require('../framework/HgLog.js'),
        Services = require('../security/Services.js'),
        HgError = require('../common/HgError.js'),
        cryptoHelper = require('../helpers/cryptoHelper.js'),
        fs = require('fs'),
        ResponseCache = {},
        RequestCache = {},
        EventEmitterCache = {},
        UserInfoCache = {},
        environment = process.env.BUILD_ENV || 'local',
        EntityCache = require('../framework/EntityCache.js'),
        contentTypeData = function (correlationId, contentTypeHeader, contentTypeValue) {
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].set(contentTypeHeader, contentTypeValue);
            }
        },
        statusCode = function (correlationId, httpStatusCode) {
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].status(httpStatusCode);
            }
        },
        endData = function (correlationId, data) {
            contentTypeData(correlationId, 'Cache-Control', 'no-cache, must-revalidate');
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].end(data);
            }
        },
        sendData = function (correlationId, data) {
            contentTypeData(correlationId, 'Cache-Control', 'no-cache, must-revalidate');
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].send(data);
            }
        },
        sendBinaryData = function (correlationId, data) {
            contentTypeData(correlationId, 'Cache-Control', 'no-store, no-cache, max-age=0, must-revalidate');
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].end(data, 'binary');
            }
        },
        sendError = function (correlationId, error) {
            var resp = ResponseCache[correlationId];
            contentTypeData(correlationId, 'Error',
                (error === 'InvalidUserToken') ?
                        error : "Error occurred, please see response body for more details.");
            contentTypeData(correlationId, 'Content-Type', 'text/html;charset=utf-8');

            if (error && typeof error !== 'string') {
                error = error.toString();
            }
            if (error.indexOf('MongoError') > -1) {
                if (resp && resp.req) {
                    Logger.error({
                        error: error,
                        url: resp.originalUrl,
                        payload: resp.req.query || resp.req.body
                    });
                } else {
                    Logger.error(error);
                }
                error = "Server error occurred, please try your operation again.";
            }
            if (resp) {
                resp.end(error);
            }
        },
        sendRedirect = function (correlationId, url) {
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].redirect(url);
            }
        },
        cookieData = function (correlationId, name, value, options) {
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].cookie(name, value, options);
            }
        },
        clearCookie = function (correlationId, name, path) {
            if (ResponseCache[correlationId]) {
                ResponseCache[correlationId].clearCookie(name, path);
            }
        },
        clearThrottle = function (correlationId, callback) {
            if (RequestCache[correlationId] && RequestCache[correlationId].params) {
                var serviceName = RequestCache[correlationId] && RequestCache[correlationId].params.ServiceName,
                    methodName = RequestCache[correlationId] && RequestCache[correlationId].params.MethodName,
                    type;

                if (Services[serviceName]
                        && Services[serviceName].ThrottledMethods
                        && Services[serviceName].ThrottledMethods[methodName]) {
                    type = Services[serviceName].ThrottledMethods[methodName].ThrottleType;
                    if (type === 'Process') {
                        EntityCache.Throttle.remove({correlationId : correlationId}, function (error) {
                            if (error) {
                                Logger.error(error);
                            }
                            callback();
                        });
                    }
                } else {
                    callback();
                }
            } else {
                callback();
            }
        },
        cleanup = function (correlationId) {
            clearThrottle(correlationId, function () {
                delete EventEmitterCache[correlationId];
                delete RequestCache[correlationId];
                delete ResponseCache[correlationId];
                delete UserInfoCache[correlationId];
                delete ContextDataCache[correlationId];
            });
        },
        genericSendData = function (eventData, wrappedPayload) {
            if (!eventData.correlationId) {
                Logger.error('genericSendData: No correlationId was found in event data! Cannot send a response.');
            } else {
                if (!eventData.errorMessage) {
                    if (wrappedPayload !== undefined && wrappedPayload === true) {
                        sendData(eventData.correlationId, eventData.payload.data);
                    } else {
                        sendData(eventData.correlationId, eventData.payload);
                    }
                } else {
                    Logger.info('genericSendData userland error: ' + eventData.errorMessage);
                    //HgError.Enums.User.InvalidUserToken is an enum that mobile expects
                    if (eventData.errorMessage === HgError.Enums.User.InvalidUserToken) {
                        clearCookie(eventData.correlationId, 'UserToken', { path: '/' });
                        sendError(eventData.correlationId, HgError.Enums.User.InvalidUserToken);
                    } else {
                        sendError(eventData.correlationId, eventData.errorMessage);
                    }
                }
                cleanup(eventData.correlationId);
            }
        };
    this.newRequest = function (request, response, userInfo) {
        var correlationId = uuid.v1(),
            eventEmitter = new EventEmitter();
        RequestCache[correlationId] = request;
        ResponseCache[correlationId] = response;
        UserInfoCache[correlationId] = userInfo;
        ContextDataCache[correlationId] = {};
        EventEmitterCache[correlationId] = eventEmitter;

        // This should be removed in the future. --Demetri.
        eventEmitter.on(eventEmitter.EventEnum.RequestManager.GenericSendData, genericSendData);

        return correlationId;
    };

    this.sendZip = function (correlationId, data, fileName) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/x-zip-compressed');
        this.contentType(correlationId, 'Content-Disposition', 'attachment; filename=' + fileName);
        sendBinaryData(correlationId, data);
        cleanup(correlationId);
    };

    this.sendRSS = function (correlationId, data) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/rss+xml');
        sendData(correlationId, data);
        cleanup(correlationId);
    };

    this.pipeZip = function (correlationId, filePath, fileName, callback) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/x-zip-compressed');
        this.contentType(correlationId, 'Content-Disposition', 'attachment; filename=' + fileName);
        var readStream = fs.createReadStream(filePath);
        readStream.on('open', function () {
            readStream.pipe(ResponseCache[correlationId]);
        });
        readStream.on('end', function () {
            cleanup(correlationId);
        });
        readStream.on('close', function () {
            if (callback && callback instanceof Function) {
                callback();
            }
        });
        readStream.on('error', function (err) {
            ResponseCache[correlationId].end(err);
            cleanup(correlationId);
        });
    };

    this.sendExcel = function (correlationId, data, fileName) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/vnd.openxmlformats');
        this.contentType(correlationId, 'Content-Disposition', 'attachment; filename=' + fileName);
        sendBinaryData(correlationId, data);
        cleanup(correlationId);
    };

    this.sendJson = function (correlationId, data, fileName) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/force-download');
        this.contentType(correlationId, 'Content-Disposition', 'attachment; filename=' + fileName);
        if (!data) {
            data = {};
        }
        if (typeof data === 'object') {
            data = JSON.stringify(data, null, 4);
        }
        sendData(correlationId, data);
        cleanup(correlationId);
    };
    this.sendPdfAttachment = function (correlationId, data, fileName) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/force-download');
        this.contentType(correlationId, 'Content-Disposition', 'attachment; filename=' + fileName);
        sendData(correlationId, data);
        cleanup(correlationId);
    };
    this.sendPdf = function (correlationId, data) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/pdf');
        sendBinaryData(correlationId, data);
        cleanup(correlationId);
    };
    this.sendEncryptedFileStream = function (correlationId, params) {
        var readStream = fs.createReadStream(params.SourceFileName);
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', params.ContentType);
        this.contentType(correlationId, 'Content-Disposition', 'attachment; filename=' + params.OutPutFile);
        readStream
            .pipe(cryptoHelper.createDecipher())
            .pipe(ResponseCache[correlationId])
            .on('end', function () {
                cleanup(correlationId);
            })
            .on('error', function (error) {
                ResponseCache[correlationId].end(error);
            });
    };

    this.sendHttpCodeAndJson = function (correlationId, httpStatusCode, data) {
        this.checkParams(correlationId);
        this.contentType(correlationId, 'Content-Type', 'application/json');
        this.statusCode(correlationId, httpStatusCode);
        if (!data) {
            data = {};
        }
        if (typeof data === 'object') {
            data = JSON.stringify(data);
        }
        endData(correlationId, data);
        cleanup(correlationId);
    };

    this.send = function (correlationId, data) {
        this.checkParams(correlationId);
        sendData(correlationId, data);
        cleanup(correlationId);
    };

    this.sendGeneric = function (correlationId, error, data) {
        this.checkParams(correlationId);
        if (error) {
            sendError(correlationId, error);
        } else {
            sendData(correlationId, data);
        }
        cleanup(correlationId);
    };

    this.error = function (correlationId, error) {
        this.checkParams(correlationId);
        sendError(correlationId, error);
        cleanup(correlationId);
    };

    this.redirect = function (correlationId, url) {
        this.checkParams(correlationId);
        sendRedirect(correlationId, url);
        cleanup(correlationId);
    };

    this.cookie = function (correlationId, name, value, options) {
        this.checkParams(correlationId);
        cookieData(correlationId, name, value, options);
    };
    this.setSessionCookie = function (correlationId, name, value, callback) {
        var self = this;
        self.checkParams(correlationId);
        cookieData(correlationId, name, value);
        if (callback && typeof callback === 'function') {
            return callback();
        }
    };
    this.removeTokenCookie = function (correlationId, name, callback) {
        var options = {
            path: '/',
            expires: new Date("Thu, 01-Jan-70 00:00:01 GMT")
        };
        if (['test', 'local'].indexOf(environment) === -1) {
            options.domain = '.highground.com';
            name = environment + '.' + name;
        }
        this.checkParams(correlationId);
        cookieData(correlationId, name, '', options);
        if (callback && typeof callback === 'function') {
            return callback();
        }
    };
    this.setTokenCookie = function (correlationId, name, value, persistCookie, callback) {
        // FYI: DO NOT REMOVE THE CONDITIONAL LOGIC FOR THE EXPIRATION TIME - NORMAL VS. IMPERSONATION (WHICH IS FORCED TO EXPIRE IN 1 HOUR)
        var options = {
            path: '/'
        };
        if (persistCookie) {
            options.expires = (name === 'UserToken') ? new Date(Date.now() + 24 * 3600 * 1000 * 365) : new Date(Date.now() + 3600 * 1000);
        }
        if (['test', 'local'].indexOf(environment) === -1) {
            options.domain = '.highground.com';
            name = environment + '.' + name;
            options.secure = true;
        }
        this.checkParams(correlationId);
        cookieData(correlationId, name, value, options);
        if (callback && typeof callback === 'function') {
            return callback();
        }
    };

    this.clearCookie = function (correlationId, name, path) {
        this.checkParams(correlationId);
        clearCookie(correlationId, name, path);
    };

    this.contentType = function (correlationId, contentTypeHeader, contentTypeValue) {
        this.checkParams(correlationId);
        contentTypeData(correlationId, contentTypeHeader, contentTypeValue);
    };

    this.statusCode = function (correlationId, httpStatusCode) {
        this.checkParams(correlationId);
        if (httpStatusCode) {
            statusCode(correlationId, httpStatusCode);
        } else {
            Logger.error('Trying to call RequestManager.statusCode() with no status code parameter.');
        }
    };

    this.respondToEvent = function (eventData) {
        genericSendData(eventData, false);
    };

    this.respondToWrappedEvent = function (eventData) {
        genericSendData(eventData, true);
    };

    this.GetRequest = function (correlationId) {
        this.checkParams(correlationId);
        return RequestCache[correlationId];
    };

    this.GetResponse = function (correlationId) {
        this.checkParams(correlationId);
        return ResponseCache[correlationId];
    };

    this.GetEventEmitter = function (correlationId) {
        this.checkParams(correlationId);
        return EventEmitterCache[correlationId];
    };

    this.GetUserInfo = function (correlationId) {
        this.checkParams(correlationId);
        return UserInfoCache[correlationId];
    };

    this.SetUserInfo = function (correlationId, UserInfo) {
        this.checkParams(correlationId);
        UserInfoCache[correlationId] = UserInfo;
    };

    this.checkParams = function (correlationId) {
        if (correlationId === undefined || correlationId === '') {
            throw new Error('Must pass correlationId into this RequestManager method.');
        }
    };

    this.cleanup = function (correlationId) {
        cleanup(correlationId);
    };
};

module.exports = new RequestManager();
