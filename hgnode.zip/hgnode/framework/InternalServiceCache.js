/*jslint node:true es5:true*/
'use strict';

var HgBaseService = require('./HgService.js'),
    InternalServiceCache = {};

function SurrogateCtor() {
    return;
}

function extend(base, sub) {
    SurrogateCtor.prototype = base.prototype;
    sub.prototype = new SurrogateCtor();
    sub.prototype.constructor = sub;
    return sub;
}
InternalServiceCache.API = extend(HgBaseService, require('../services/internal/APIInternalService.js'));
InternalServiceCache.Badge = extend(HgBaseService, require('../services/internal/BadgeInternalService.js'));
InternalServiceCache.EntityActivity = extend(HgBaseService, require('../services/internal/EntityActivityInternalService.js'));
InternalServiceCache.Recap = extend(HgBaseService, require('../services/internal/RecapInternalService.js'));
InternalServiceCache.Relevancy = extend(HgBaseService, require('../services/internal/RelevancyInternalService.js'));
InternalServiceCache.FeedbackCard = extend(HgBaseService, require('../services/internal/FeedbackCardInternalService.js'));
InternalServiceCache.FeedbackCycle = extend(HgBaseService, require('../services/internal/FeedbackCycleInternalService.js'));
InternalServiceCache.FeedbackSession = extend(HgBaseService, require('../services/internal/FeedbackSessionInternalService.js'));
InternalServiceCache.FeedbackRequest = extend(HgBaseService, require('../services/internal/FeedbackRequestInternalService.js'));
InternalServiceCache.Batch = extend(HgBaseService, require('../services/internal/BatchInternalService.js'));
InternalServiceCache.Comment = extend(HgBaseService, require('../services/internal/CommentInternalService.js'));
InternalServiceCache.Coaching = extend(HgBaseService, require('../services/internal/CoachingInternalService.js'));
InternalServiceCache.EventBus = extend(HgBaseService, require('../services/internal/EventBusInternalService.js'));
InternalServiceCache.Recurrence = extend(HgBaseService, require('../services/internal/RecurrenceInternalService.js'));
InternalServiceCache.Petition = extend(HgBaseService, require('../services/internal/PetitionInternalService.js'));
InternalServiceCache.RulesEngine = extend(HgBaseService, require('../services/internal/RulesEngineInternalService.js'));
InternalServiceCache.Credit = extend(HgBaseService, require('../services/internal/CreditInternalService.js'));
InternalServiceCache.Feed = extend(HgBaseService, require('../services/internal/FeedInternalService.js'));
InternalServiceCache.CreditAccount = extend(HgBaseService, require('../services/internal/CreditAccountInternalService.js'));
InternalServiceCache.Group = extend(HgBaseService, require('../services/internal/GroupInternalService.js'));
InternalServiceCache.GroupSSO = extend(HgBaseService, require('../services/internal/GroupSSOInternalService.js'));
InternalServiceCache.ManagerAlert = extend(HgBaseService, require('../services/internal/ManagerAlertInternalService.js'));
InternalServiceCache.Member = extend(HgBaseService, require('../services/internal/MemberInternalService.js'));
InternalServiceCache.Notification = extend(HgBaseService, require('../services/internal/NotificationInternalService.js'));
InternalServiceCache.Performance = extend(HgBaseService, require('../services/internal/PerformanceInternalService.js'));
InternalServiceCache.Point = extend(HgBaseService, require('../services/internal/PointInternalService.js'));
InternalServiceCache.ProductItem = extend(HgBaseService, require('../services/internal/ProductItemInternalService.js'));
InternalServiceCache.ProductOrder = extend(HgBaseService, require('../services/internal/ProductOrderInternalService.js'));
InternalServiceCache.Provision = extend(HgBaseService, require('../services/internal/ProvisionInternalService.js'));
InternalServiceCache.Metrics = extend(HgBaseService, require('../services/internal/MetricsInternalService.js'));
InternalServiceCache.Recognition = extend(HgBaseService, require('../services/internal/RecognitionInternalService.js'));
InternalServiceCache.PublicRecognition = extend(HgBaseService, require('../services/internal/PublicRecognitionInternalService.js'));
InternalServiceCache.RecognitionAdmin = extend(HgBaseService, require('../services/internal/RecognitionAdminInternalService.js'));
InternalServiceCache.Tag = extend(HgBaseService, require('../services/internal/TagInternalService.js'));
InternalServiceCache.Team = extend(HgBaseService, require('../services/internal/TeamInternalService.js'));
InternalServiceCache.Track = extend(HgBaseService, require('../services/internal/TrackInternalService.js'));
InternalServiceCache.Tango = extend(HgBaseService, require('../services/internal/TangoInternalService.js'));
InternalServiceCache.Transaction = extend(HgBaseService, require('../services/internal/TransactionInternalService.js'));
InternalServiceCache.User = extend(HgBaseService, require('../services/internal/UserInternalService.js'));
InternalServiceCache.UserV2 = extend(HgBaseService, require('../services/internal/UserV2InternalService.js'));
InternalServiceCache.UserSelf = extend(HgBaseService, require('../services/internal/UserSelfInternalService.js'));
InternalServiceCache.WishList = extend(HgBaseService, require('../services/internal/WishListInternalService.js'));
InternalServiceCache.Worker = extend(HgBaseService, require('../services/internal/WorkerInternalService.js'));
InternalServiceCache.News = extend(HgBaseService, require('../services/internal/NewsInternalService.js'));
InternalServiceCache.Yammer = extend(HgBaseService, require('../services/internal/YammerInternalService.js'));
InternalServiceCache.Conversation = extend(HgBaseService, require('../services/internal/ConversationInternalService.js'));
InternalServiceCache.GoalCycle = extend(HgBaseService, require('../services/internal/GoalCycleInternalService.js'));
InternalServiceCache.Goal = extend(HgBaseService, require('../services/internal/GoalInternalService.js'));
InternalServiceCache.Invoice = extend(HgBaseService, require('../services/internal/InvoiceInternalService.js'));
InternalServiceCache.Redeem = extend(HgBaseService, require('../services/internal/RedeemInternalService.js'));
InternalServiceCache.Tutorial = extend(HgBaseService, require('../services/internal/TutorialInternalService.js'));
InternalServiceCache.Survey = extend(HgBaseService, require('../services/internal/SurveyInternalService.js'));
InternalServiceCache.Report = extend(HgBaseService, require('../services/internal/ReportInternalService.js'));
InternalServiceCache.RSS = extend(HgBaseService, require('../services/internal/RSSInternalService.js'));
InternalServiceCache.Job = extend(HgBaseService, require('../services/internal/JobInternalService.js'));
InternalServiceCache.StatusIO = extend(HgBaseService, require('../services/internal/StatusIOInternalService.js'));
InternalServiceCache.AutoComplete = extend(HgBaseService, require('../services/internal/AutoCompleteInternalService.js'));
InternalServiceCache.Display = extend(HgBaseService, require('../services/internal/DisplayInternalService.js'));
InternalServiceCache.ActionToken = extend(HgBaseService, require('../services/internal/ActionTokenInternalService.js'));
InternalServiceCache.Payment = extend(HgBaseService, require('../services/internal/PaymentInternalService.js'));
InternalServiceCache.Activity = extend(HgBaseService, require('../services/internal/ActivityInternalService.js'));
InternalServiceCache.Template = extend(HgBaseService, require('../services/internal/TemplateInternalService.js'));
InternalServiceCache.SSONoAuth = extend(HgBaseService, require('../services/internal/SSONoAuthInternalService.js'));
InternalServiceCache.PDFBuilder = extend(HgBaseService, require('../services/internal/SurveyPDF/PDFBuilder.js'));
InternalServiceCache.FeedbackPDFBuilder = extend(HgBaseService, require('../services/internal/FeedbackPDF/PDFBuilder.js'));
InternalServiceCache.Onboard = extend(HgBaseService, require('../services/internal/provision/OnboardInternalService.js'));
InternalServiceCache.ProvisionValidator = extend(HgBaseService, require('../services/internal/provision/ProvisionValidatorService.js'));
InternalServiceCache.ProvisionBuilder = extend(HgBaseService, require('../services/internal/provision/ProvisionBuilderInternalService.js'));
InternalServiceCache.ProvisionGroup = extend(HgBaseService, require('../services/internal/provision/ProvisionGroupInternalService.js'));
InternalServiceCache.ProvisionLocation = extend(HgBaseService, require('../services/internal/provision/ProvisionLocationInternalService.js'));
InternalServiceCache.ProvisionDepartment = extend(HgBaseService, require('../services/internal/provision/ProvisionDepartmentInternalService.js'));
InternalServiceCache.ProvisionMember = extend(HgBaseService, require('../services/internal/provision/ProvisionMemberInternalService.js'));
InternalServiceCache.ProvisionPreValidation = extend(HgBaseService, require('../services/internal/provision/ProvisionPreValidationInternalService.js'));
InternalServiceCache.Translation = extend(HgBaseService, require('../services/internal/TranslationInternalService.js'));
InternalServiceCache.Poll = extend(HgBaseService, require('../services/internal/PollInternalService.js'));
InternalServiceCache.SSO = extend(HgBaseService, require('../services/internal/SSOInternalService.js'));
InternalServiceCache.Slack = extend(HgBaseService, require('../services/internal/SlackInternalService.js'));
InternalServiceCache.Profanity = extend(HgBaseService, require('../services/internal/ProfanityInternalService.js'));
InternalServiceCache.TaggedUsers = extend(HgBaseService, require('../services/internal/TaggedUsersInternalService.js'));
InternalServiceCache.GRS = extend(HgBaseService, require('../services/internal/GRSInternalService.js'));
InternalServiceCache.ExpressPigeon = extend(HgBaseService, require('../services/internal/ExpressPigeonInternalService.js'));
InternalServiceCache.Demo = extend(HgBaseService, require('../services/internal/DemoInternalService.js'));
InternalServiceCache.UserNoAuth = extend(HgBaseService, require('../services/internal/UserInternalServiceNoAuth'));
InternalServiceCache.OptOut = extend(HgBaseService, require('../services/internal/OptOutInternalService'));
InternalServiceCache.TalentInsight = extend(HgBaseService, require('../services/internal/TalentInsightInternalService.js'));

module.exports = InternalServiceCache;
