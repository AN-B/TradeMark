/*jslint node:true es5:true*/
'use strict';
var FeatureFlags = require('../enums/FeatureFlagEnums.js'),
    EntityEnums = require('../enums/EntityEnums.js'),
    HgLog = require('../framework/HgLog.js'),
    Async = require('async'),
    transformWords = function (data) {
        if (!data || !data.length) {
            return {};
        }
        var words = {};
        data.forEach(function (item) {
            if (!words[item.Lang]) {
                words[item.Lang] = {};
            }
            words[item.Lang][item.Word] = item.Level;
        });
        return words;
    },
    getBannedWords = function (EntityCache, callback) {
        if (!EntityCache || !EntityCache.Profanity) {
            return callback();
        }
        EntityCache.Profanity.find({
            GroupId: null,
            Status: EntityEnums.ProfanityWordStatus.Active
        }, function (error, words) {
            if (error) {
                return callback(error);
            }
            callback(null, transformWords(words));
        });
    },
    getGroupBannedWords = function (GroupId, EntityCache, callback) {
        if (!EntityCache || !EntityCache.Profanity) {
            return callback();
        }
        EntityCache.Profanity.find({
            Status: EntityEnums.ProfanityWordStatus.Active,
            GroupId: {$in: [null, GroupId]},
            ExcludedGroupIds: {$nin: [GroupId]}
        }, function (error, words) {
            if (error) {
                return callback(words);
            }
            callback(null, transformWords(words));
        });
    },
    ClusterCache = {
        cache: {},
        init: function (EntityCache, groupId, callback) {
            // build the cache from database
            if (EntityCache && EntityCache.Group) {
                Async.parallel({
                    systemBannedWords: function (fcallback) {
                        getBannedWords(EntityCache, function (error, systemBannedWords) {
                            if (error) {
                                return fcallback(error);
                            }
                            fcallback(null, systemBannedWords);
                        });
                    },
                    groups: function (fcallback) {
                        var query = {
                            Status: EntityEnums.GroupStatus.Active
                        };
                        if (groupId) {
                            query.hgId = groupId;
                        }
                        EntityCache.Group.find(query, {
                            _id: 0,
                            hgId: 1,
                            "Preference.FeatureFlags": 1,
                            GroupName: 1,
                            Federated: 1
                        }, function (error, groups) {
                            if (error) {
                                return fcallback(error);
                            }
                            fcallback(null, groups);
                        });
                    }
                }, function (error, result) {
                    if (error) {
                        HgLog.error(error);
                        if (callback) {
                            return callback(error);
                        }
                        return;
                    }
                    Async.each(result.groups, function (group, gCallback) {
                        var profanityFilter = group.Preference.FeatureFlags.some(function (ff) {
                            return ff.FeatureName === FeatureFlags.ProfanityFilter && ff.FeatureEnabled;
                        }), customProfanityFilter = group.Preference.FeatureFlags.some(function (ff) {
                            return ff.FeatureName === FeatureFlags.CustomProfanityFilter && ff.FeatureEnabled;
                        });
                        if (!customProfanityFilter) {
                            ClusterCache.cache[group.hgId] = {
                                ProfanityFilter: profanityFilter,
                                WordList: result.systemBannedWords,
                                Federated: group.Federated
                            };
                            return gCallback();
                        }
                        getGroupBannedWords(group.hgId, EntityCache, function (error, groupBannedWords) {
                            if (error) {
                                HgLog.error('Error Loading Group Banned Words', error);
                                //we continue loading other groups
                                ClusterCache.cache[group.hgId] = {
                                    ProfanityFilter: profanityFilter,
                                    WordList: result.systemBannedWords,
                                    Federated: group.Federated
                                };
                                return gCallback();
                            }
                            ClusterCache.cache[group.hgId] = {
                                ProfanityFilter: profanityFilter,
                                WordList: groupBannedWords,
                                Federated: group.Federated
                            };
                            return gCallback();
                        });
                    }, function (error) {
                        if (callback) {
                            return callback(ClusterCache.cache);
                        }
                        return;
                    });
                });
            }
        },
        get: function () {
            return ClusterCache.cache;
        },
        set: function (c) {
            ClusterCache.cache = c;
        }
    };

module.exports = ClusterCache;
