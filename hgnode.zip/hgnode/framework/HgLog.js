/*jslint node:true es5:true*/
// this is the common logging module
'use strict';

var winston = require('winston'),
    loggly = require('winston-loggly'),
    config = require('../configurations/config'),
    keystore = require('../configurations/keystore'),
    env = process.env.BUILD_ENV || 'local',
    serverType = process.env.SERVER_TYPE || 'web',
    consoleTransport = new winston.transports.Console({
        level: 'debug',
        colorize: true,
        prettyPrint: true,
        timestamp: function () {
            return new Date().toLocaleTimeString();
        }
    }),
    logglyTransport = new winston.transports.Loggly({
        level: 'info',
        subdomain: 'highground',
        inputToken: keystore.loggly.token || '0',
        tags: [env, serverType],
        silent: !(keystore.loggly.token),       //silent if we don't have a loggly token
        json: true
    }),
    HgLog;

winston.loggers.add('HgLog', {
    transports: env === 'prod' ? [logglyTransport] : [
        consoleTransport,
        logglyTransport
    ]
});

winston.loggers.add('ActivityLog', {
    transports: [
        logglyTransport
    ]
});

HgLog = winston.loggers.get('HgLog');

/**
 * examines the call stack and returns a string indicating
 * the file and line number of the n'th previous ancestor call.
 * this works in chrome, and should work in nodejs as well.
 *
 * @param n : int (default: n=1) - the number of calls to trace up the
 *   stack from the current call.  `n=0` gives you your current file/line.
 *  `n=1` gives the file/line that called you.
 */
function getDatStack(n) {
    if (isNaN(n) || n < 0) {
        n = 1;
    }
    n += 1;

    var datStackTho = (new Error()).stack,
        a = datStackTho.indexOf('\n', 5),
        b;

    while (n > 0) {
        n -= 1;
        a = datStackTho.indexOf('\n', a + 1);
        if (a < 0) {
            a = datStackTho.lastIndexOf('\n', datStackTho.length);
            break;
        }
    }

    b = datStackTho.indexOf('\n', a + 1);
    if (b < 0) {
        b = datStackTho.length;
    }
    a = Math.max(datStackTho.lastIndexOf(' ', b), datStackTho.lastIndexOf('/', b));
    b = datStackTho.lastIndexOf(':', b);
    datStackTho = datStackTho.substring(a + 1, b);
    return datStackTho;
}

//amend the file name and line number from the stack trace if enabled
//only for debug, error, and warn levels due to performance concerns
//checks for the env variable LOG_LINE_NUMS
if (process.env.LOG_LINE_NUMS && env !== 'prod') {
    ['debug', 'error', 'warn', 'info'].forEach(function (level) {
        (function (oldFunc) {
            HgLog[level] = function (msg, meta) {
                var fileAndLine = getDatStack(1);

                if (typeof msg === 'object') {
                    meta = msg;
                    msg = '';
                }
                if (meta === undefined) {
                    meta = null;
                }
                if (meta && typeof meta.toObject === 'function') {
                    //convert mongoose object to plain object
                    meta = meta.toObject();
                }

                return oldFunc.call(this, '[' + fileAndLine + '] ' + msg, meta);
            };
        }(HgLog[level]));
    });
}

module.exports = HgLog;
