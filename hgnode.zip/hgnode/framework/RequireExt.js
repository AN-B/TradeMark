/*jslint node:true es5:true nomen:true stupid:true*/
'use strict';
var fs = require('fs'),
    htmlHelper = require('../helpers/htmlHelper.js'),
    htmlSnips = {
        FontFamily: "font-family:'Helvetica Neue',Helvetica,Arial,'Lucida Grande',sans-serif"
    };
require.extensions['.html'] = function (module, filename) {
    module.exports = htmlHelper.replaceTokens(
        fs.readFileSync(filename, 'utf8').
            replace(/\r?\n|\r|\t/g, '').
            replace(/\s{2,}/g, ' ').
            replace(/> </g, '><'),
        htmlSnips
    );
};