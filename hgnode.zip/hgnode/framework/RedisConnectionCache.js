/*jslint node:true es5:true*/
'use strict';

var redis = require('redis'),
    config = require('../configurations/config'),
    HgLog = require('../framework/HgLog'),
    client,
    noop = function () { return; },
    RedisConnection = {};

function respondWithError(message, callback) {
    HgLog.error(message);
    if (typeof callback === 'function') {
        callback(message);
    }
}

function checkForParameter(parameterName, parameterValue, callback) {
    if (!parameterValue) {
        return respondWithError('the \'' + parameterName + '\' parameter must be supplied to this method', callback);
    }
    return true;
}

function init() {
    if (!client) {
        client = redis.createClient(config.Redis.Connection);

        client.on('ready', function (err) {
            if (err) {
                HgLog.error(err);
            }
            HgLog.info('*** Redis completed connection to ' + (config.Redis.Connection.url || config.Redis.Connection.host + ':' + config.Redis.Connection.port) + ' ***');
        });

        client.on('error', function (err) {
            HgLog.error(err);
        });
    }
}

function quit() {
    if (client) {
        client.quit();
    }
}

function globalSet(key, value, callback, lifetime) {
    var stringified,
        cb = callback || noop;

    if (checkForParameter('key', key, cb) && checkForParameter('value', value, cb)) {
        try {
            if (Object.prototype.toString.call(value) === '[object Object]') {
                stringified = JSON.stringify(value || '');
            }
            if (lifetime) {
                return client.setex(key, lifetime, stringified || value, cb || noop);
            }
            client.set(key, stringified || value, cb || noop);
        } catch (error) {
            HgLog.error('*** Redis Error: ' + error.toString() + ' ****');
            cb(error);
        }
    }
}

function globalGet(key, callback) {
    var cb = callback || noop;
    try {
        if (checkForParameter('key', key, cb)) {
            client.get(key, cb);
        }
    } catch (error) {
        HgLog.error('*** Redis Error: ' + error.toString() + ' ****');
        cb(error);
    }
}

function globalDelete(key, callback) {
    var cb = callback || noop;
    try {
        if (checkForParameter('key', key, cb)) {
            client.del(key, cb);
        }
    } catch (error) {
        HgLog.error('*** Redis Error: ' + error.toString() + ' ****');
        cb(error);
    }
}

RedisConnection.init = init;
RedisConnection.quit = quit;
RedisConnection.GlobalSet = globalSet;
RedisConnection.GlobalGet = globalGet;
RedisConnection.GlobalDelete = globalDelete;

RedisConnection.init();

module.exports = RedisConnection;
