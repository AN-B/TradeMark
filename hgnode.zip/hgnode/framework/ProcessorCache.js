/*jslint node:true es5:true*/
'use strict';

var HgBaseProcessor = require('./HgProcessor.js'),
    HgProcessorV2 = require('./HgProcessorV2.js'),
    ProcessorCache = {};

function SurrogateCtor() {
    return;
}

function extend(base, sub) {
    SurrogateCtor.prototype = base.prototype;
    sub.prototype = new SurrogateCtor();
    sub.prototype.constructor = sub;
    return sub;
}

ProcessorCache.FeedbackCard = extend(HgBaseProcessor, require('../processors/FeedbackCardProcessor.js'));
ProcessorCache.FeedbackCycle = extend(HgBaseProcessor, require('../processors/FeedbackCycleProcessor.js'));
ProcessorCache.FeedbackSession = extend(HgBaseProcessor, require('../processors/FeedbackSessionProcessor.js'));
ProcessorCache.FeedbackRequest = extend(HgBaseProcessor, require('../processors/FeedbackRequestProcessor.js'));
ProcessorCache.Relevancy = extend(HgBaseProcessor, require('../processors/RelevancyProcessor.js'));
ProcessorCache.Goal = extend(HgBaseProcessor, require('../processors/GoalProcessor.js'));
ProcessorCache.GoalCycle = extend(HgProcessorV2, require('../processors/GoalCycleProcessor.js'));
ProcessorCache.Badge = extend(HgBaseProcessor, require('../processors/BadgeProcessor.js'));
ProcessorCache.Batch = extend(HgProcessorV2, require('../processors/BatchProcessor.js'));
ProcessorCache.EntityActivity = extend(HgProcessorV2, require('../processors/EntityActivityProcessor.js'));
ProcessorCache.Comment = extend(HgBaseProcessor, require('../processors/CommentProcessor.js'));
ProcessorCache.CareerTrack = extend(HgBaseProcessor, require('../processors/CareerTrackProcessor.js'));
ProcessorCache.CareerTrackTemplate = extend(HgBaseProcessor, require('../processors/CareerTrackTemplateProcessor.js'));
ProcessorCache.CreditAccount = extend(HgBaseProcessor, require('../processors/CreditAccountProcessor.js'));
ProcessorCache.ClientProfile = extend(HgBaseProcessor, require('../processors/ClientProfileProcessor.js'));
ProcessorCache.Crud = extend(HgBaseProcessor, require('../processors/CrudProcessor.js'));
ProcessorCache.EventBusItem = extend(HgBaseProcessor, require('../processors/EventBusItemProcessor.js'));
ProcessorCache.Feed = extend(HgBaseProcessor, require('../processors/FeedProcessor.js'));
ProcessorCache.RulesEngine = extend(HgBaseProcessor, require('../processors/RulesEngineProcessor.js'));
ProcessorCache.Giftcard = extend(HgBaseProcessor, require('../processors/GiftcardProcessor.js'));
ProcessorCache.Group = extend(HgBaseProcessor, require('../processors/GroupProcessor.js'));
ProcessorCache.GroupSSO = extend(HgBaseProcessor, require('../processors/GroupSSOProcessor.js'));
ProcessorCache.GroupTerminology = extend(HgBaseProcessor, require('../processors/GroupTerminologyProcessor.js'));
ProcessorCache.Member = extend(HgBaseProcessor, require('../processors/MemberProcessor.js'));
ProcessorCache.MemberBookmark = extend(HgBaseProcessor, require('../processors/MemberBookmarkProcessor.js'));
ProcessorCache.Invoice = extend(HgBaseProcessor, require('../processors/InvoiceProcessor.js'));
ProcessorCache.News = extend(HgBaseProcessor, require('../processors/NewsProcessor.js'));
ProcessorCache.Performance = extend(HgBaseProcessor, require('../processors/PerformanceProcessor.js'));
ProcessorCache.ProductItem = extend(HgBaseProcessor, require('../processors/ProductItemProcessor.js'));
ProcessorCache.ProductOrder = extend(HgBaseProcessor, require('../processors/ProductOrderProcessor.js'));
ProcessorCache.Provision = extend(HgBaseProcessor, require('../processors/ProvisionProcessor.js'));
ProcessorCache.ReferenceNumber = extend(HgBaseProcessor, require('../processors/ReferenceNumberProcessor.js'));
ProcessorCache.Recurrence = extend(HgBaseProcessor, require('../processors/RecurrenceProcessor.js'));
ProcessorCache.Petition = extend(HgBaseProcessor, require('../processors/PetitionProcessor.js'));
ProcessorCache.Recognition = extend(HgBaseProcessor, require('../processors/RecognitionProcessor.js'));
ProcessorCache.RecognitionTemplate = extend(HgBaseProcessor, require('../processors/RecognitionTemplateProcessor.js'));
ProcessorCache.Reward = extend(HgBaseProcessor, require('../processors/RewardProcessor.js'));
ProcessorCache.Team = extend(HgBaseProcessor, require('../processors/TeamProcessor.js'));
ProcessorCache.User = extend(HgBaseProcessor, require('../processors/UserProcessor.js'));
ProcessorCache.WishList = extend(HgBaseProcessor, require('../processors/WishListProcessor.js'));
ProcessorCache.UserNoAuth = extend(HgBaseProcessor, require('../processors/UserProcessorNoAuth.js'));
ProcessorCache.BillMeLater = extend(HgBaseProcessor, require('../processors/BillMeLaterProcessor.js'));
ProcessorCache.Transaction = extend(HgBaseProcessor, require('../processors/TransactionProcessor.js'));
ProcessorCache.ScheduleEvent = extend(HgBaseProcessor, require('../processors/ScheduleEventProcessor.js'));
ProcessorCache.Certificate = extend(HgBaseProcessor, require('../processors/CertificateProcessor.js'));
ProcessorCache.ReviewPDF = extend(HgBaseProcessor, require('../processors/review/ReviewPDFProcessor.js'));
ProcessorCache.ActionToken = extend(HgBaseProcessor, require('../processors/ActionTokenProcessor.js'));
ProcessorCache.Log = extend(HgBaseProcessor, require('../processors/LogProcessor.js'));
ProcessorCache.Report = extend(HgBaseProcessor, require('../processors/ReportProcessor.js'));
ProcessorCache.Tag = extend(HgBaseProcessor, require('../processors/TagProcessor.js'));
ProcessorCache.Metrics = extend(HgBaseProcessor, require('../processors/MetricsProcessor.js'));
ProcessorCache.DataExport = extend(HgBaseProcessor, require('../processors/DataExportProcessor.js'));
ProcessorCache.Conversation = extend(HgBaseProcessor, require('../processors/ConversationProcessor.js'));
ProcessorCache.Tutorial = extend(HgBaseProcessor, require('../processors/TutorialProcessor.js'));
ProcessorCache.ManagerAlert = extend(HgBaseProcessor, require('../processors/ManagerAlertProcessor.js'));
ProcessorCache.Job = extend(HgBaseProcessor, require('../processors/JobProcessor.js'));
ProcessorCache.Display = extend(HgBaseProcessor, require('../processors/DisplayProcessor.js'));
ProcessorCache.GroupIPAddress = extend(HgBaseProcessor, require('../processors/GroupIPAddressProcessor.js'));
ProcessorCache.AutoComplete = extend(HgBaseProcessor, require('../processors/autocomplete/AutoCompleteProcessor.js'));
ProcessorCache.Activity = extend(HgBaseProcessor, require('../processors/ActivityProcessor.js'));
ProcessorCache.Survey = extend(HgBaseProcessor, require('../processors/survey/SurveyProcessor.js'));
ProcessorCache.SurveyResult = extend(HgBaseProcessor, require('../processors/survey/SurveyResultProcessor.js'));
ProcessorCache.Template = extend(HgBaseProcessor, require('../processors/TemplateProcessor.js'));
ProcessorCache.Poll = extend(HgBaseProcessor, require('../processors/PollProcessor.js'));
ProcessorCache.TaggedUser = extend(HgBaseProcessor, require('../processors/TaggedUsersProcessor.js'));
ProcessorCache.GRS = extend(HgBaseProcessor, require('../processors/GRSProcessor.js'));
ProcessorCache.Translation = extend(HgBaseProcessor, require('../processors/TranslationProcessor.js'));
ProcessorCache.Profanity = extend(HgBaseProcessor, require('../processors/ProfanityProcessor.js'));
ProcessorCache.MergeAccount = extend(HgBaseProcessor, require('../processors/MergeAccountProcessor.js'));
ProcessorCache.FeedbackPDF = extend(HgBaseProcessor, require('../processors/feedback/FeedbackPDFProcessor.js'));
ProcessorCache.FeedbackRequestPDF = extend(HgBaseProcessor, require('../processors/feedback/FeedbackRequestPDFProcessor.js'));
ProcessorCache.Demo = extend(HgBaseProcessor, require('../processors/DemoProcessor.js'));
ProcessorCache.OptOut = extend(HgBaseProcessor, require('../processors/OptOutProcessor'));
ProcessorCache.ProfilePDF = extend(HgBaseProcessor, require('../processors/pdfGenerators/ProfilePDFProcessor.js'));

// Notifications
ProcessorCache.Notification = extend(HgBaseProcessor, require('../processors/notifications/NotificationProcessor.js'));
ProcessorCache.MobileAddressAuthority = extend(HgBaseProcessor, require('../processors/notifications/MobileAddressAuthority.js'));
ProcessorCache.ContentBuilder = extend(HgBaseProcessor, require('../processors/notifications/ContentBuilder.js'));
ProcessorCache.MobileContentBuilder = extend(HgBaseProcessor, require('../processors/notifications/MobileContentBuilder.js'));
ProcessorCache.Dispatcher = extend(HgBaseProcessor, require('../processors/notifications/Dispatcher.js'));
ProcessorCache.NotificationPreference = extend(HgBaseProcessor, require('../processors/notifications/NotificationPreferenceProcessor.js'));

// External APIs
ProcessorCache.AuthorizeNet = extend(HgBaseProcessor, require('../processors/integration/AuthorizeNetProcessor.js'));
ProcessorCache.ExpressPigeon = extend(HgBaseProcessor, require('../processors/integration/ExpressPigeonProcessor.js'));
ProcessorCache.LinkedIn = extend(HgBaseProcessor, require('../processors/integration/LinkedInProcessor.js'));
ProcessorCache.Facebook = extend(HgBaseProcessor, require('../processors/integration/FacebookProcessor.js'));
ProcessorCache.Tango = extend(HgBaseProcessor, require('../processors/integration/TangoProcessor.js'));

module.exports = ProcessorCache;
