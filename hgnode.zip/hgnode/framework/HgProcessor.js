/*jslint node:true es5:true nomen:true*/
var HgProcessor = function (correlationId) {
    'use strict';
    if (correlationId === undefined || correlationId === '') {
        throw new Error('Must pass correlationId into processor');
    }
    var RequestManager = require('../framework/RequestManager.js'),
        EntityCache = require('../framework/EntityCache.js');
    this.EventEmitterCache = RequestManager.GetEventEmitter(correlationId);
    this.IsFunction = require('../util/params.js').IsFunction;
    this.DefaultEntityName = '';
    this.DefaultKeyName = 'hgId';

    this.GetOne = function (params, callback) {
        var entityName = this.DefaultEntityName,
            EntityModel = EntityCache[entityName],
            condition = params.Condition || {'hgId': params.hgId},//example : {'hgId' : 'dlklfjsakf'}
            fields = params.Fields || {},//example : {'hgId' : true, 'FirstName' : true}
            mquery;
        if (!EntityModel || !condition) {
            callback('Invalid EntityName or condition', null);
            return;
        }
        if (fields) {
            mquery = EntityModel.findOne(condition, fields);
        } else {
            mquery = EntityModel.findOne(condition);
        }
        mquery.exec(function (error, entity) {
            if (error || !entity) {
                callback('Cannot retrieve ' + entityName, null);
            } else {
                callback(null, entity);
            }
        });
    };
    this.Get = function (params, callback) {
        var entityName = params.EntityName || this.DefaultEntityName,
            EntityModel = EntityCache[entityName],
            condition = params.Condition || {},
            options = params.Options || {},
            fields = params.Fields || {},//example : {'hgId' : true, 'FirstName' : true}
            mquery,
            skip = parseInt(params.Skip, 10) || 0,
            take = parseInt(params.Take, 10) || 0;
        if (!EntityModel || !condition) {
            callback('Invalid EntityName or condition', null);
            return;
        }

        mquery = EntityModel.find(condition, fields, options);
        mquery.skip(skip).limit(take).exec(function (error, entities) {
            if (error) {
                callback('Cannot retrieve ' + params.EntityName, null);
            } else {
                callback(null, entities);
            }
        });
    };
    this.Count = function (params, callback) {
        var entityName = params.EntityName || this.DefaultEntityName,
            EntityModel = EntityCache[entityName],
            condition = params.Condition || {},
            mquery;
        if (!EntityModel || !condition) {
            callback('Invalid EntityName or condition', null);
            return;
        }

        mquery = EntityModel.count(condition);
        mquery.exec(function (error, count) {
            if (error) {
                callback('Cannot retrieve ' + params.EntityName, null);
            } else {
                callback(null, count);
            }
        });
    };
    this.Update = function (params, callback) {
        var entityName = params.EntityName || this.DefaultEntityName,
            EntityModel = EntityCache[entityName],
            condition = params.Condition,//example : {'hgId' : 'dlklfjsakf'}
            mapping = params.Mapping,//example : {$set : {'FirstName' : 'Gary'}}
            multi = params.Multi || true;
        if (!EntityModel || !condition || !mapping) {
            callback('Invalid EntityName or condition or mapping', null);
            return;
        }
        EntityModel.update(condition, mapping, {multi: multi}, function (error) {
            callback(error, 'Update done');
        });
    };
};

module.exports = HgProcessor;