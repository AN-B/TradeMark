/*jslint node:true es5:true*/
'use strict';

var mongoose = require('mongoose'),
    config = require('../configurations/config.js'),
    ClusterMessageEnums = require('../enums/ClusterMessageEnums.js'),
    ClusterCache = require('./ClusterCache.js'),
    secureConnect = require('../configurations/secureConnect.js')(),
    HgLog = require('./HgLog'),
    ConnectionCache = {},
    dbsToBeCached = ['hgcommon', 'hgsecurity', 'hgthanka', 'hgperka', 'hgfinance', 'hgperform', 'hgreports', 'hglog'],
    replicaSets = {
        hgcommon: config.mongodb.replica,
        hgsecurity: config.mongodb.replica,
        hgthanka: config.mongodb.replica,
        hgperka: config.mongodb.replica,
        hgfinance: config.mongodb.replica,
        hgperform: config.mongodb.replica,
        hgreports: config.mongodb.replicaLR || config.mongodb.replica,
        hglog: config.mongodb.replicaLR || config.mongodb.replica
    },
    options = {};
mongoose.Promise = global.Promise;

// add options for replica sets, override connection timeout to 30 seconds
dbsToBeCached.forEach(function (dbName) {
    options[dbName] = {
        db: {
            native_parser: true
        },
        server: {
            poolSize: process.env.POOL_SIZE || 2,
            readPreference: 'secondaryPreferred',
            socketOptions: {
                keepAlive: 1,
                connectTimeoutMS: 30000,
                auto_reconnect: true
            }
        }
    };
    if (config.mongodb.replica !== '') {
        options[dbName].replSet = {
            poolSize: process.env.POOL_SIZE || 2,
            rs_name: replicaSets[dbName],
            readPreference: 'secondaryPreferred',
            socketOptions: {
                keepAlive: 1,
                connectTimeoutMS: 30000,
                auto_reconnect: true
            }
        };
    }
    if (secureConnect.ssl && (!process.env.DB_EXCLUDE_SECURE || process.env.DB_EXCLUDE_SECURE.indexOf(dbName) === -1)) {
        Object.keys(secureConnect).forEach(function (key) {
            options[dbName].server[key] = secureConnect[key];
            if (options[dbName].replSet[key]) {
                options[dbName].replSet[key] = secureConnect[key];
            }
        });
    }
});

function init(callback) {
    var fullSet = 0,
        connectionMap = {},
        startTheServer = function (theDbName) {
            if (!connectionMap[theDbName]) {
                fullSet += 1;
                connectionMap[theDbName] = true;
                if (fullSet === dbsToBeCached.length) {
                    if (callback && typeof callback === 'function') {
                        callback();
                    }
                }
            }
        };
    dbsToBeCached.forEach(function (dbName) {
        if (config.mongodb[dbName] && config.mongodb[dbName].length > 0) {
            ConnectionCache[dbName] = mongoose.createConnection(config.mongodb[dbName], options[dbName]);
            ConnectionCache[dbName].on('connecting', function () {
                HgLog.debug('Connecting to: ' + dbName);
            });
            ConnectionCache[dbName].on('connected', function () {
                HgLog.debug(process.pid + ' >> Connected to: ' + dbName);
                startTheServer(dbName);
            });
            ConnectionCache[dbName].on('error', function (err) {
                HgLog.error('Error, trying to reconnect to: ' + dbName + ' >> ' + err);
            });
            ConnectionCache[dbName].on('disconnected', function () {
                HgLog.debug('Disconnected connection: ' + dbName);
            });
            ConnectionCache[dbName].on('fullsetup', function () {
                HgLog.debug('Full replica set connected: ' + dbName);
            });
            ConnectionCache[dbName].on('reconnected', function () {
                HgLog.debug('Reconnected to: ' + dbName);
            });
            ConnectionCache[dbName].on('close', function () {
                HgLog.debug('Closed connection: ' + dbName + '...');
            });
        }
    });
}

function shutdown() {
    dbsToBeCached.forEach(function (dbName) {
        if (config.mongodb[dbName] && config.mongodb[dbName].length > 0) {
            try {
                ConnectionCache[dbName].close();
            } catch (dbEx) {
                HgLog.error(dbEx);
            }
        }
    });
    ConnectionCache = {};
}

function getSchema(params) {
    var groupClusterCache = ClusterCache.get()[params.GroupId];
    if (!params.GroupId || !groupClusterCache || !groupClusterCache.Federated) {
        return ConnectionCache[params.DbName].model(params.ColName, params.Schema, params.ColName);
    }
    return ConnectionCache[params.DbName].model(params.ColName, params.Schema, params.ColName + "_" + params.GroupId);
}

ConnectionCache.getSchema = getSchema;
ConnectionCache.shutdown = shutdown;
ConnectionCache.init = init;

module.exports = ConnectionCache;