/*jslint node:true es5:true*/
'use strict';

var HGActivityLog,
    HgLog = require('../framework/HgLog.js'),
    exceptionNotifyer = require('../framework/ExceptionNotifier.js'),
    cryptoHelper = require('../helpers/cryptoHelper.js'),
    RequestManager,
    TokenHelper,
    serverMap,
    exceptionThrottle,
    timeoutUrlMap = {},
    timeoutThreshold = parseInt(process.env.RESPONSE_TIMEOUT_THRESHOLD, 10) || 25000,
    timeoutEmailInterval = parseInt(process.env.TIMEOUT_EMAIL_INTERVAL, 10) || 30000;

function processRequest(req, res, type) {
    var serviceName = req.params.ServiceName,
        methodName = req.params.MethodName,
        correlationId,
        authService;

    // set the timeout for the request here for 28 seconds
    // only send out a timeout email notification every minute
    res.setTimeout(timeoutThreshold, function () {
        var token = serverMap[type].TokenHelper(req, 'UserToken'),
            pl = {
                Exception: {
                    message: 'Timeout potential caught, please take a look.',
                    source: 'timeout'
                },
                UserToken: token ? cryptoHelper.encrypt(token).toString('base64') : 'N/A',
                Payload: {
                    name: 'Slow service methods',
                    payload: req.query || req.body,
                    params: req.params,
                    url: req.url,
                    headers: req.rawHeaders
                },
                ServerType: process.env.SERVER_TYPE || 'Unknown'
            };
        HgLog.info(pl);
        if (!exceptionThrottle && !timeoutUrlMap[req.url]) {
            timeoutUrlMap[req.url] = true;
            exceptionNotifyer(pl);
            exceptionThrottle = setTimeout(function () {
                clearTimeout(exceptionThrottle);
                exceptionThrottle = null;
            }, timeoutEmailInterval);
        }
        res.statusCode = 503;
        if (!res.finished) {
            res.end();
        }
        RequestManager.cleanup(correlationId);
    });

    if (!RequestManager) {
        HGActivityLog = require('../framework/HGActivityLog.js');
        RequestManager = require('../framework/RequestManager.js');
        TokenHelper = require('../helpers/tokenHelper.js');
        serverMap = {
            web: {
                TokenHelper: TokenHelper.GetToken,
                ServiceCache: require('../framework/ServiceCache.js'),
                HGAuthentication: require('../security/HGAuthentication.js')
            },
            mobile: {
                TokenHelper: TokenHelper.GetMobileToken,
                ServiceCache: require('../framework/MobileServiceCache.js'),
                HGAuthentication: require('../security/MobileAuthentication.js')
            }
        };
    }

    correlationId = RequestManager.newRequest(req, res);

    function executeServiceMethod(params) {
        var serviceInstance = new serverMap[type].ServiceCache[serviceName](correlationId),
            currentUser,
            userContext;
        if (serviceInstance[methodName] === undefined || typeof serviceInstance[methodName] !== 'function') {
            currentUser = params.currentuser || {};
            userContext = currentUser.UserContext || {};
            HGActivityLog.SaveActivity({
                CorrelationId: params.correlationId,
                UserId: currentUser.hgId || '',
                GroupId: userContext.CurrentGroupId || '',
                GroupName: userContext.CurrentGroupName || '',
                MemberId: userContext.MemberIdInGroup || '',
                FullName: currentUser.UserPersonal ? currentUser.UserPersonal.FullName : '',
                ServiceName: serviceName,
                MethodName: methodName,
                IPAddress: HGActivityLog.GetIPAddress(params.req),
                AccessGranted: false,
                Message: 'Service method does not exist',
                UserAgent: params.req.headers['user-agent'] || ''
            });
            RequestManager.error(correlationId, 'Service method does not exist: ' + serviceName + '/' + methodName);
        } else {
            serviceInstance[methodName](params);
        }
    }

    if (process.env.LOCAL_DEBUG) {
        if (req.method === 'POST') {
            HgLog.debug(req.method + ' svc/' + serviceName + '/' + methodName, req.headers['content-length'] < 700 ? req.body : null);
        }
        if (req.method === 'GET') {
            HgLog.debug(req.method + ' svc/' + serviceName + '/' + methodName, req.query);
        }
    }

    if (serviceName && methodName && serverMap[type].ServiceCache[serviceName]) {
        authService = new serverMap[type].HGAuthentication(correlationId);
        authService.Authenticate(req, serviceName, methodName, executeServiceMethod, correlationId);
    } else {
        HGActivityLog.SaveActivity({
            CorrelationId: correlationId,
            UserToken: serverMap[type].TokenHelper(req, 'UserToken'),
            ServiceName: serviceName || 'Unknown',
            MethodName: methodName || 'Unknown',
            IPAddress: HGActivityLog.GetIPAddress(req),
            AccessGranted: false,
            Message: 'Call to unknown service.',
            UserAgent: req.headers['user-agent'] || ''
        });
        RequestManager.error(correlationId,  'The service does not exist: ' + serviceName);
    }
}

function ProcessMobileRequest(req, res) {
    processRequest(req, res, 'mobile');
}

function ProcessWebRequest(req, res) {
    processRequest(req, res, 'web');
}

exports.ProcessMobileRequest = ProcessMobileRequest;
exports.ProcessRequest = ProcessWebRequest;
