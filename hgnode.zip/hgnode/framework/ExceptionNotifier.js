/*jslint node:true es5:true nomen:true*/
var ExceptionNotifier = function () {
    'use strict';
    var https = require('https'),
        httpResponseCodes = require('../enums/HttpResponseCodes.js'),
        keyStore = require('../configurations/keystore.js'),
        config = require('../configurations/config.js'),
        emailEnvirons = ['qa', 'uat', 'st', 'prod'],
        exceptionCache = [];

    function sendRequest(requestData, callback) {
        if (!requestData) {
            callback('Missing email body options.');
        } else {
            requestData = JSON.stringify(requestData);
        }
        var requestOptions = {
                hostname: 'api.expresspigeon.com',
                path: '/messages',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': requestData.length,
                    'X-auth-key': keyStore.expresspigeon_api
                }
            },
            httpsRequest,
            responseData = '';

        httpsRequest = https.request(requestOptions, function (httpsResponse) {
            httpsResponse.on('data', function (dataChunk) {
                responseData += dataChunk;
            }).on('end', function () {
                if (httpsResponse.statusCode === httpResponseCodes.Success.OK || httpsResponse.statusCode === httpResponseCodes.Success.Created) {
                    callback(null, responseData);
                } else {
                    callback('Error sending exception notification (HTTP ' + httpsResponse.statusCode + ') ', responseData);
                }
            });
        }).on('error', function (error) {
            callback(error);
        });
        httpsRequest.write(requestData);
        httpsRequest.end();
    }

    return function (error, callback) {
        var exception = error.Exception,
            text = exception ? (exception.stack || exception.message) : 'There was no exception provided!',
            source = exception ? exception.source : null,
            errorMessage = '<pre>' + text + '</pre>',
            emailOptions = {
                template_id: '34477',
                reply_to: config.email.Alert,
                from: config.email.Alert,
                to: config.email.Alert,
                subject: (source === 'timeout' ? 'Timeout caught in ' : 'Unhandled Exception in ') +
                    (process.env.SERVER_NAME || process.env.BUILD_ENV) + ', Server type: ' + error.ServerType + '!',
                merge_fields: {
                    error: errorMessage,
                    usertoken: error.UserToken ? 'UserToken: ' + error.UserToken : '',
                    payload: error.Payload ? JSON.stringify(error.Payload) : ''
                }
            },
            i,
            len,
            exists = -1,
            sendIt = true,
            currentTimestamp;
        if (emailEnvirons.indexOf(process.env.BUILD_ENV) > -1) {
            currentTimestamp = Date.now();
            // do not send the same exception message unless 5 seconds has elapsed when sending the same error message
            for (i = 0, len = exceptionCache.length; i < len; i += 1) {
                if (exceptionCache[i].message === emailOptions.merge_fields.error) {
                    exists = i;
                    if (currentTimestamp - exceptionCache[i].timestamp < 5000) {
                        sendIt = false;
                        break;
                    }
                }
            }
            if (sendIt) {
                if (exists > -1) {
                    exceptionCache[exists].timestamp = Date.now();
                } else {
                    exceptionCache.push({
                        message: emailOptions.merge_fields.error,
                        timestamp: Date.now()
                    });
                }
                sendRequest(emailOptions, function (error, responseData) {
                    if (callback) {
                        if (!error) {
                            callback(null, responseData);
                        } else {
                            callback('Sorry, there was a problem sending an email about this exception:\n' + error.stack || error + '\n' + responseData);
                        }
                    }
                });
            }
        } else {
            if (callback) {
                callback(null, 'Not in production, therefore not sending exception email.');
            }
        }
    };
};

module.exports = new ExceptionNotifier();