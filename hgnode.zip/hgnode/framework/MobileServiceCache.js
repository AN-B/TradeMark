/*jslint node:true es5:true*/
'use strict';

var HgBaseService = require('./HgService.js'),
    MobileServiceCache;

function SurrogateCtor() {
    return;
}

function extend(base, sub) {
    SurrogateCtor.prototype = base.prototype;
    sub.prototype = new SurrogateCtor();
    sub.prototype.constructor = sub;
    return sub;
}
MobileServiceCache = {
    AutoComplete: extend(HgBaseService, require('../services/mobile/AutoCompleteService.js')),
    Badge: extend(HgBaseService, require('../services/mobile/BadgeService.js')),
    Comment: extend(HgBaseService, require('../services/mobile/CommentService.js')),
    Goal: extend(HgBaseService, require('../services/mobile/GoalService.js')),
    Recognition: extend(HgBaseService, require('../services/mobile/RecognitionService.js')),
    User: extend(HgBaseService, require('../services/mobile/UserService.js')),
    UserSelf: extend(HgBaseService, require('../services/mobile/UserSelfService.js')),
    News: extend(HgBaseService, require('../services/mobile/NewsService.js')),
    PusherAuth: extend(HgBaseService, require('../services/mobile/PusherAuthService.js')),
    Coaching: extend(HgBaseService, require('../services/mobile/CoachingService.js')),
    Feedback: extend(HgBaseService, require('../services/mobile/FeedbackService.js')),
    Redeem: extend(HgBaseService, require('../services/mobile/RedeemService.js')),
    ProductOrder: extend(HgBaseService, require('../services/mobile/ProductOrderService.js')),
    ProductItem: extend(HgBaseService, require('../services/mobile/ProductItemService.js')),
    Member: extend(HgBaseService, require('../services/mobile/MemberService.js')),
    Team: extend(HgBaseService, require('../services/mobile/TeamService.js')),
    Survey: extend(HgBaseService, require('../services/mobile/SurveyService.js')),
    ManagerAlert: extend(HgBaseService, require('../services/mobile/ManagerAlertService.js')),
    Feed: extend(HgBaseService, require('../services/mobile/FeedService.js')),
    Poll: extend(HgBaseService, require('../services/mobile/PollService.js')),
    CheckIn: extend(HgBaseService, require('../services/mobile/CheckInService.js')),
    Notification: extend(HgBaseService, require('../services/mobile/NotificationService.js')),
    OptOut: extend(HgBaseService, require('../services/mobile/OptOutService.js')),
    Performance: extend(HgBaseService, require('../services/mobile/PerformanceService.js')),
    FeedbackRequest: extend(HgBaseService, require('../services/mobile/FeedbackRequestService.js')),
    FeedbackSession: extend(HgBaseService, require('../services/mobile/FeedbackSessionService.js')),
    FeedbackCycle: extend(HgBaseService, require('../services/mobile/FeedbackCycleService.js'))
};
module.exports = MobileServiceCache;