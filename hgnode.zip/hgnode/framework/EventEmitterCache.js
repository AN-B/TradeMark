/*jslint node:true es5:true*/
'use strict';
var events = require('events'),
    util = require('util'),
    logger = require('./HgLog.js'),
    eventEnums = require('../enums/EventEnum.js');

function EventEmitterCache() {
    events.EventEmitter.call(this);
    this.EventEnum = eventEnums;
    this.localOn = this.on;
    this.localEmit = this.emit;
    var self = this;

    this.emit = function (eventName, eventData) {
        this.localEmit(eventName, eventData);
    };

    this.on = function (eventName, callback) {
        var error;
        // This is an experimental change to only allow a single listener per event.
        // This should solve the problem of multiple service layer instantiations.
        if (eventName) {
            if (self.listeners(eventName).length === 0) {
                this.localOn(eventName, callback);
            }
        } else {
            error = new Error(process.pid + ' \'undefined\' event subscription attempt detected. Ignoring subscription.');
            logger.error(error.stack);
        }
    };
}

util.inherits(EventEmitterCache, events.EventEmitter);
module.exports = EventEmitterCache;