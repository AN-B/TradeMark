/*jslint node:true es5:true nomen:true*/
var HGActivityLog = function () {
    'use strict';
    var EntityCache = require('../framework/EntityCache.js'),
        AuditLevelType = require('../enums/EntityEnums.js').AuditLevelType,
        ServiceSecurity = require('../security/Services.js'),
        DateHelper = require('../util/DateHelper.js'),
        winston = require('winston'),
        ActivityLog = winston.loggers.get('ActivityLog');

    function logUserMetric(params) {
        var today = DateHelper.getJustDate(),
            query = {p: today, g: params.GroupId, m: params.MemberId},
            options = {upsert: true},
            update = {$set: {p: today, g: params.GroupId, m: params.MemberId}};
        EntityCache.MetricsUserActivity.update(query, update, options).exec();
    }

    this.GetIPAddress = function (request) {
        var retval = "", headers = 'headers', socket = 'socket', remoteAddress = 'remoteAddress';
        if (request[headers] && request[headers]["x-forwarded-for"]) {
            retval = request[headers]["x-forwarded-for"];
        } else if (request[socket] && request[socket][remoteAddress]) {
            retval = request[socket][remoteAddress];
        } else if (request[socket] && request[socket][socket] && request[socket][socket][remoteAddress]) {
            retval = request[socket][socket][remoteAddress];
        }
        return retval;
    };
    this.SaveActivity = function (params) {
        var meta,
            activity,
            auditLevelType = AuditLevelType.All;

        if (ServiceSecurity[params.ServiceName] && ServiceSecurity[params.ServiceName].AuditLevel) {
            auditLevelType = ServiceSecurity[params.ServiceName].AuditLevel;
        }
        if (params.AccessGranted && (auditLevelType === AuditLevelType.All || auditLevelType === AuditLevelType.OnSuccess)) {
            meta = {
                CreatedDate: new Date(),
                GroupName: params.GroupName,
                GroupId: params.GroupId,
                UserId: params.UserId,
                ClientId: params.ClientId,
                ClientName: params.ClientName,
                MemberId: params.MemberId,
                FullName: params.FullName,
                ServiceName: params.ServiceName,
                MethodName: params.MethodName,
                AccessGranted: params.AccessGranted,
                IPAddress: params.IPAddress,
                BrowserFingerPrint: params.BrowserFingerPrint,
                Source: params.Source,
                UserAgent: params.UserAgent
            };
            ActivityLog.info('UserActivityAudit', meta);
            activity = EntityCache.UserActivityAudit(meta);
            if (!params.Api && !params.ClientId && params.MemberId && params.GroupId && !process.env.PRUNE_HGLOG) {
                logUserMetric({GroupId: params.GroupId, MemberId: params.MemberId});
            }
        } else if (!params.AccessGranted && (auditLevelType === AuditLevelType.All || auditLevelType === AuditLevelType.OnFailure)) {
            meta = {
                CreatedDate: new Date(),
                GroupName: params.GroupName,
                GroupId: params.GroupId,
                UserId: params.UserId,
                MemberId: params.MemberId,
                FullName: params.FullName,
                ServiceName: params.ServiceName,
                MethodName: params.MethodName,
                IPAddress: params.IPAddress,
                BrowserFingerPrint: params.BrowserFingerPrint,
                Message: params.Message,
                UserToken: params.UserToken
            };
            ActivityLog.info('UnAuthorizedActivity', meta);
            activity = EntityCache.UnAuthorizedActivity(meta);
        }
        if (activity && !process.env.PRUNE_HGLOG) {
            activity.save();
        }
    };
    this.Archive = function (params, callback) {
        EntityCache.ArchiveRecord(params).save(callback);
    };
    this.GetArchiveById = function (params, callback) {
        EntityCache.ArchiveRecord.findOne({ArchiveId: params.ArchiveId}, callback);
    };
};

module.exports = new HGActivityLog();