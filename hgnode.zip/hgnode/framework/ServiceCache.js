/*jslint node:true es5:true*/
'use strict';

var HgBaseService = require('./HgService.js'),
    ServiceCache = {};

function SurrogateCtor() {
    return;
}

function extend(base, sub) {
    SurrogateCtor.prototype = base.prototype;
    sub.prototype = new SurrogateCtor();
    sub.prototype.constructor = sub;
    return sub;
}

ServiceCache.API = extend(HgBaseService, require('../services/APIService.js'));
ServiceCache.Badge = extend(HgBaseService, require('../services/BadgeService.js'));
ServiceCache.BadgeAdmin = extend(HgBaseService, require('../services/BadgeAdminService.js'));
ServiceCache.Comment = extend(HgBaseService, require('../services/CommentService.js'));
ServiceCache.Coaching = extend(HgBaseService, require('../services/CoachingService.js'));
ServiceCache.RulesEngine = extend(HgBaseService, require('../services/RulesEngineService.js'));
ServiceCache.Credit = extend(HgBaseService, require('../services/CreditService.js'));
ServiceCache.Feed = extend(HgBaseService, require('../services/FeedService.js'));
ServiceCache.Group = extend(HgBaseService, require('../services/GroupService.js'));
ServiceCache.GroupAdmin = extend(HgBaseService, require('../services/GroupAdminService.js'));
ServiceCache.GlobalAdmin = extend(HgBaseService, require('../services/GlobalAdminService.js'));
ServiceCache.News = extend(HgBaseService, require('../services/NewsService.js'));
ServiceCache.Notification = extend(HgBaseService, require('../services/NotificationService.js'));
ServiceCache.Payment = extend(HgBaseService, require('../services/PaymentService.js'));
ServiceCache.FeedbackCard = extend(HgBaseService, require('../services/FeedbackCardService.js'));
ServiceCache.FeedbackCycle = extend(HgBaseService, require('../services/FeedbackCycleService.js'));
ServiceCache.FeedbackSession = extend(HgBaseService, require('../services/FeedbackSessionService.js'));
ServiceCache.FeedbackRequest = extend(HgBaseService, require('../services/FeedbackRequestService.js'));
ServiceCache.GoalCycle = extend(HgBaseService, require('../services/GoalCycleService.js'));
ServiceCache.Goal = extend(HgBaseService, require('../services/GoalService.js'));
ServiceCache.GRS = extend(HgBaseService, require('../services/GRSService.js'));
ServiceCache.Performance = extend(HgBaseService, require('../services/PerformanceService.js'));
ServiceCache.PojoFactory = extend(HgBaseService, require('../services/PojoFactory.js'));
ServiceCache.Point = extend(HgBaseService, require('../services/PointService.js'));
ServiceCache.ProductItem = extend(HgBaseService, require('../services/ProductItemService.js'));
ServiceCache.ProductOrder = extend(HgBaseService, require('../services/ProductOrderService.js'));
ServiceCache.Provision = extend(HgBaseService, require('../services/ProvisionService.js'));
ServiceCache.ManagerAlert = extend(HgBaseService, require('../services/ManagerAlertService.js'));
ServiceCache.Member = extend(HgBaseService, require('../services/MemberService.js'));
ServiceCache.Metrics = extend(HgBaseService, require('../services/MetricsService.js'));
ServiceCache.PublicRecognition = extend(HgBaseService, require('../services/PublicRecognitionService.js'));
ServiceCache.PusherAuth = extend(HgBaseService, require('../services/PusherAuthService.js'));
ServiceCache.Recognition = extend(HgBaseService, require('../services/RecognitionService.js'));
ServiceCache.RecognitionAdmin = extend(HgBaseService, require('../services/RecognitionAdminService.js'));
ServiceCache.Redeem = extend(HgBaseService, require('../services/RedeemService.js'));
ServiceCache.Reward = extend(HgBaseService, require('../services/RewardService.js'));
ServiceCache.Report = extend(HgBaseService, require('../services/ReportService.js'));
ServiceCache.RSS = extend(HgBaseService, require('../services/RSSService.js'));
ServiceCache.Tag = extend(HgBaseService, require('../services/TagService.js'));
ServiceCache.Team = extend(HgBaseService, require('../services/TeamService.js'));
ServiceCache.Track = extend(HgBaseService, require('../services/TrackService.js'));
ServiceCache.TrackAdmin = extend(HgBaseService, require('../services/TrackAdminService.js'));
ServiceCache.User = extend(HgBaseService, require('../services/UserService.js'));
ServiceCache.UserAdmin = extend(HgBaseService, require('../services/UserAdminService.js'));
ServiceCache.UserSelf = extend(HgBaseService, require('../services/UserSelfService.js'));
ServiceCache.Worker = extend(HgBaseService, require('../services/WorkerService.js'));
ServiceCache.Payment = extend(HgBaseService, require('../services/PaymentService.js'));
ServiceCache.Transaction = extend(HgBaseService, require('../services/TransactionService.js'));
ServiceCache.Upload = extend(HgBaseService, require('../services/UploadService.js'));
ServiceCache.ExpressPigeon = extend(HgBaseService, require('../services/ExpressPigeonService.js'));
ServiceCache.SSO = extend(HgBaseService, require('../services/SSOService.js'));
ServiceCache.SSONoAuth = extend(HgBaseService, require('../services/SSONoAuthService.js'));
ServiceCache.SocialMedia = extend(HgBaseService, require('../services/SocialMediaService.js'));
ServiceCache.UI = extend(HgBaseService, require('../services/UIService.js'));
ServiceCache.WishList = extend(HgBaseService, require('../services/WishListService.js'));
ServiceCache.Yammer = extend(HgBaseService, require('../services/YammerService.js'));
ServiceCache.Slack = extend(HgBaseService, require('../services/SlackService.js'));
ServiceCache.Tutorial = extend(HgBaseService, require('../services/TutorialService.js'));
ServiceCache.Feedback = extend(HgBaseService, require('../services/FeedbackService.js'));
ServiceCache.AutoComplete = extend(HgBaseService, require('../services/AutoCompleteService.js'));
ServiceCache.Display = extend(HgBaseService, require('../services/DisplayService.js'));
ServiceCache.Survey = extend(HgBaseService, require('../services/SurveyService.js'));
ServiceCache.Template = extend(HgBaseService, require('../services/TemplateService.js'));
ServiceCache.Poll = extend(HgBaseService, require('../services/PollService.js'));
ServiceCache.Profanity = extend(HgBaseService, require('../services/ProfanityService.js'));
ServiceCache.Demo = extend(HgBaseService, require('../services/DemoService.js'));
ServiceCache.OptOut = extend(HgBaseService, require('../services/OptOutService'));
ServiceCache.TalentInsight = extend(HgBaseService, require('../services/TalentInsightService.js'));
module.exports = ServiceCache;
