/*jslint node:true es5:true nomen:true*/
var HgService = function (correlationId) {
    'use strict';
    if (!correlationId) {
        throw new Error('Must pass correlationId into service');
    }
    this.correlationId = correlationId;
    this.RequestManager = require('../framework/RequestManager.js');
    this.EventEmitterCache = this.RequestManager.GetEventEmitter(correlationId);
    this._UserInfo = this.RequestManager.GetUserInfo(correlationId);
    this.ProcessorCache = require('../framework/ProcessorCache.js');
    this.InternalServiceCache = require('../framework/InternalServiceCache.js');
    this.ServiceCache = require('../framework/ServiceCache.js');
    this.IsFunction = require('../util/params.js').IsFunction;
    Object.defineProperty(this, "UserInfo", {
        get : function () {
            return this._UserInfo;
        },
        set : function (val) {
            this._UserInfo = val;
        },
        enumerable: true
    });
};

module.exports = HgService;