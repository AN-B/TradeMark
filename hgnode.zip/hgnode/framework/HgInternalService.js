/*jslint node:true es5:true nomen:true*/
var HgInternalService = function (correlationId) {
    'use strict';

    this.correlationId = correlationId;
    this.ProcessorCache = require('../framework/ProcessorCache.js');
    this.InternalServiceCache = require('../framework/InternalServiceCache.js');
};

module.exports = HgInternalService;