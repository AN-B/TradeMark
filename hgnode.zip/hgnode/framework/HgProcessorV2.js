/*jslint node:true es5:true nomen:true*/
var HgProcessorV2 = function () {
    'use strict';
    this.EntityCache = require('./EntityCache.js');
    var BucketEnums = require('../enums/BucketEnums.js'),
        EntityCache = this.EntityCache,
        Async = require('async'),
        guid = require('node-uuid'),
        arrayUtil = require('../util/arrayUtil'),
        fillBuckets = function (params, callback) {
            var i = 0,
                len = params.UnfilledBuckets.length,
                bucketType = params.BucketType;
            if (!len) {
                return callback();
            }
            if (!params.Content.length) {
                return callback();
            }
            Async.whilst(
                function () {
                    return params.Content.length && i < len;
                },
                function (scallback) {
                    var curBucket = params.UnfilledBuckets[i],
                        contentToBucket = params.Content.splice(0, bucketType.BucketCap - curBucket[bucketType.SizeFieldName]);
                    i += 1;
                    curBucket[bucketType.ContentFieldName] = curBucket[bucketType.ContentFieldName].concat(contentToBucket);
                    curBucket[bucketType.SizeFieldName] += contentToBucket.length;
                    curBucket.ModifiedBy = params.UserId;
                    curBucket.save(scallback);
                },
                function (error) {
                    callback(error, "Done fillBuckets");
                }
            );
        },
        pushToNewBuckets = function (params, callback) {
            var bucketType = params.BucketType;
            if (!params.Content.length) {
                return callback();
            }
            Async.whilst(
                function () {
                    return params.Content.length;
                },
                function (scallback) {
                    var contentToBucket = params.Content.splice(0, bucketType.BucketCap),
                        newBucket = new EntityCache[bucketType.EntityType](params.Bucket);
                    if (!contentToBucket.length) {
                        return scallback();
                    }
                    newBucket[bucketType.ContentFieldName] = contentToBucket;
                    newBucket[bucketType.SizeFieldName] = contentToBucket.length;
                    newBucket.hgId = guid.v1();
                    newBucket.save(scallback);
                },
                function (error) {
                    callback(error, "Done pushToNewBuckets");
                }
            );
        };

    this.AddItemsToBucket = function (params, callback) {
        var bucketType = BucketEnums.BucketTypes[params.BucketTypeName],
            condition;
        if (!bucketType) {
            return callback("Invalid bucketType, ", params.BucketTypeName);
        }
        //1. get buckets of this entity that has unfilled spots
        condition = {
            Status: BucketEnums.Status.Active,
            GroupId: params.Bucket.GroupId
        };
        condition[bucketType.KeyName] = params.Bucket[bucketType.KeyName];
        condition[bucketType.SizeFieldName] = {$lt: bucketType.BucketCap};
        params.BucketType = bucketType;
        EntityCache[bucketType.EntityType].find(condition, function (error, unfilledBuckets) {
            if (error) {
                return callback(error);
            }
            params.UnfilledBuckets = unfilledBuckets;
            //2. if any, fill the content array into those buckets
            fillBuckets(params, function (error) {
                if (error) {
                    return callback(error);
                }
                //3. if still have item left, create new bucket(s)
                pushToNewBuckets(params, callback);
            });
        });
    };

    this.GetItemsFromBuckets = function (params, callback) {
        var bucketType = BucketEnums.BucketTypes[params.BucketTypeName],
            condition;
        if (!bucketType) {
            return callback("Invalid bucketType, ", params.BucketTypeName);
        }
        condition = {
            Status: BucketEnums.Status.Active,
            GroupId: params.Bucket.GroupId
        };
        condition[bucketType.KeyName] = params.Bucket[bucketType.KeyName];
        EntityCache[bucketType.EntityType].find(condition, function (error, buckets) {
            if (error) {
                return callback(error);
            }
            buckets.forEach(function (bucket) {
                params.Bucket[bucketType.ContentFieldName] = params.Bucket[bucketType.ContentFieldName] || [];
                params.Bucket[bucketType.ContentFieldName] = params.Bucket[bucketType.ContentFieldName].concat(bucket[bucketType.ContentFieldName]);
            });
            callback(null, params.Bucket);
        });
    };

    this.GetBulkItemsFromBuckets = function (params, callback) {
        var bucketType = BucketEnums.BucketTypes[params.BucketTypeName],
            condition = {
                Status: BucketEnums.Status.Active,
                GroupId: {$in: arrayUtil.getUnique(params.Buckets.map(function (item) {
                    return item.GroupId;
                }))}
            },
            contentFieldName = bucketType.ContentFieldName,
            ret = {};
        if (!bucketType) {
            return callback("Invalid bucketType, ", params.BucketTypeName);
        }
        condition[bucketType.KeyName] = {$in: params.Buckets.map(function (item) {
            return item[bucketType.KeyName];
        })};
        EntityCache[bucketType.EntityType].find(condition, function (error, buckets) {
            if (error) {
                return callback(error);
            }
            buckets.forEach(function (bucket) {
                if (!ret[bucket[bucketType.KeyName]]) {
                    ret[bucket[bucketType.KeyName]] = {};
                    ret[bucket[bucketType.KeyName]][contentFieldName] = bucket[bucketType.ContentFieldName];
                } else {
                    ret[bucket[bucketType.KeyName]][contentFieldName] = ret[bucket[bucketType.KeyName]][contentFieldName].concat(bucket[bucketType.ContentFieldName]);
                }
            });
            callback(null, ret);
        });
    };

    this.RemoveItemsFromBucket = function (params, callback) {
        var bucketType = BucketEnums.BucketTypes[params.BucketTypeName],
            condition;
        if (!bucketType) {
            return callback("Invalid bucketType, ", params.BucketTypeName);
        }
        condition = {
            Status: BucketEnums.Status.Active,
            GroupId: params.Bucket.GroupId
        };
        condition[bucketType.KeyName] = params.Bucket[bucketType.KeyName];
        condition[bucketType.ContentFieldName] = {$in: params.Content};
        EntityCache[bucketType.EntityType].find(condition, function (error, buckets) {
            if (error) {
                return callback(error);
            }
            Async.each(buckets, function (bucket, scallback) {
                bucket[bucketType.ContentFieldName] = bucket[bucketType.ContentFieldName].filter(function (item) {
                    return params.Content.indexOf(item) === -1;
                });
                bucket.ModifiedBy = params.ModifiedBy;
                bucket[bucketType.SizeFieldName] = bucket[bucketType.ContentFieldName].length;
                bucket.save(scallback);
            }, callback);
        });
    };
};

module.exports = HgProcessorV2;
