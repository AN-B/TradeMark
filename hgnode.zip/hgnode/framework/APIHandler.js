/*jslint node:true es5:true*/
'use strict';
var RequestManager = require('../framework/RequestManager.js'),
    RESTtypes = require('../enums/RestTypes.js'),
    DefaultErrors = require('../api/DefaultErrors'),
    HgLog = require('../framework/HgLog.js'),
    RESTServices = require('../api/restservices');

function process(request, response) {
    var correlationId = RequestManager.newRequest(request, response),
        version = request.context.version,
        service = request.context.service,
        action = request.context.action,
        responseHandler,
        RESTservice,
        sendError = function (error) {
            RequestManager.sendHttpCodeAndJson(correlationId, error.StatusCode, {
                error: error.Description
            });
        };
    request.context.correlationId = correlationId;

    //first check if version doesn't exist
    if (RESTServices.Versions.indexOf(request.context.version) === -1) {
        HgLog.error('Unknown API Version -', version);
        sendError(DefaultErrors.UnknownAPIVersion);
        return;
    }
    //next check if resource doesn't exist
    if (!RESTServices[version][service]) {
        //we probably will never hit this error, since APIAuthorization.js will check if they have access to the service
        HgLog.error('Unknown API service -', service);
        sendError(DefaultErrors.UnknownResource);
        return;
    }

    RESTservice = new RESTServices[version][service]();
    responseHandler = new RESTServices.ResponseHandlers[version](correlationId);

    //finally check if action exists
    if (!action || !RESTservice[action]) {
        HgLog.error('Unknown API action -', action);
        sendError(DefaultErrors.NotImplemented);
        return;
    }

    RESTservice[action](request.context, responseHandler.handleResponse);
}

exports.ProcessRESTGet = function (request, response) {
    request.context.action = RESTtypes.Get;
    process(request, response);
};
exports.ProcessRESTGetId = function (request, response) {
    request.context.action = RESTtypes.GetId;
    request.context.id = request.params.id;
    process(request, response);
};
exports.ProcessRESTPut = function (request, response) {
    request.context.action = RESTtypes.Put;
    request.context.body = request.body;
    process(request, response);
};
exports.ProcessRESTPutId = function (request, response) {
    request.context.action = RESTtypes.PutId;
    request.context.id = request.params.id;
    request.context.body = request.body;
    process(request, response);
};
exports.ProcessRESTDelete = function (request, response) {
    request.context.action = RESTtypes.Delete;
    request.context.body = request.body;
    process(request, response);
};
exports.ProcessRESTDeleteId = function (request, response) {
    request.context.action = RESTtypes.DeleteId;
    request.context.id = request.params.id;
    request.context.body = request.body;
    process(request, response);
};
exports.ProcessRESTPost = function (request, response) {
    request.context.action = RESTtypes.Post;
    request.context.body = request.body;
    process(request, response);
};
exports.ProcessOperationalRequestPost = function (request, response) {
    //request.context.action should already be set
    request.context.body = request.body;
    process(request, response);
};
exports.ProcessOperationalRequestPostId = function (request, response) {
    //request.context.action should already be set
    request.context.id = request.params.id;
    request.context.body = request.body;
    process(request, response);
};