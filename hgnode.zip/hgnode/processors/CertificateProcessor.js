/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    CertificateProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            HgLog = require('../framework/HgLog'),
            HgCache = require('../framework/RedisConnectionCache'),
            https = require('https'),
            config = require('../configurations/config.js'),
            isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
            fs = require('fs'),
            parseXml = require('xml2js').parseString,
            PDF = require('pdfkit'),
            defaultColor = '#282E31',
            underlineColor = '#bbbbbb',
            i18nHelper = require('../helpers/i18nHelper.js'),
            buffers,
            doc = new PDF({
                info: {
                    Author: 'HighGround Enterprise Solutions, Inc.',
                    Producer: 'HighGround Enterprise Solutions, Inc.'
                },
                size: 'letter',
                layout: 'landscape',
                margins: {
                    top: 24,
                    bottom: 24,
                    left: 24,
                    right: 24
                }
            }),
            processElement = require('../util/SvgHelper.js'),
            lang,
            processShapes = function (ele) {
                var e, i, len, shape, k, klen,
                    keys = ele ? Object.keys(ele) : [];
                for (k = 0, klen = keys.length; k < klen; k += 1) {
                    e = keys[k];
                    shape = e.toString();
                    if (shape === 'g') {
                        for (i = 0, len = ele[e].length; i < len; i += 1) {
                            if (!ele[e][i].$ || ele[e][i].$.display !== 'none') {
                                processShapes(ele[e][i]);
                            }
                        }
                    } else if (processElement[shape]) {
                        processElement[shape]({ele: ele[e], doc: doc});
                    } else {
                        HgLog.error('Element ' + shape + ' is not supported!');
                    }
                }
            },
            processTemplate = function (data, callback) {
                parseXml(data, {explicitArray: true}, function (err, result) {
                    doc.scale(1);
                    processShapes(result.svg);
                    callback();
                });
            },
            getTemplateFromCache = function (cacheKey, cb) {
                HgCache.GlobalGet(cacheKey, function (error, svg) {
                    if (error || !svg) {
                        // don't handle the error, just return null
                        return cb();
                    }
                    cb(svg);
                });
            },
            readTemplate = function (templateName, callback) {
                var cacheKey;
                if (isLocal) {
                    cacheKey = './static/files/certificates/svg/' + templateName;
                    getTemplateFromCache(cacheKey, function (svg) {
                        if (svg) {
                            return processTemplate(svg, callback);
                        }
                        fs.readFile(cacheKey, 'utf8', function (error, svg) {
                            if (error) {
                                HgLog.error({methodName: 'readTemplate', error: error});
                                return callback(error);
                            }
                            svg = svg.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                            // this is fire-and-forget setting of the cache
                            HgCache.GlobalSet(cacheKey, svg, function (err) {
                                if (err) {
                                    HgLog.error(err);
                                }
                            });
                            processTemplate(svg, callback);
                        });
                    });
                } else {
                    cacheKey = '/files/certificates/svg/' + templateName;
                    getTemplateFromCache(cacheKey, function (svg) {
                        if (svg) {
                            return processTemplate(svg, callback);
                        }
                        svg = '';
                        https.get({
                            host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
                            path: cacheKey
                        }, function (ret) {
                            ret.on("data", function (chunk) {
                                svg += chunk;
                            }).on("end", function () {
                                svg = svg.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                                // this is fire-and-forget setting of the cache
                                HgCache.GlobalSet(cacheKey, svg, function (err) {
                                    if (err) {
                                        HgLog.error(err);
                                    }
                                });
                                processTemplate(svg, callback);
                            });
                        }).on('error', function (e) {
                            HgLog.error('ERROR: ' + e.message);
                        });
                    });
                }
            },
            processBadge = function (params, callback) {
                parseXml(params.xml, {explicitArray: true}, function (err, result) {
                    if (err) {
                        HgLog.error(err);
                        return callback();
                    }
                    if (result) {
                        doc.save();
                        if (params.msg === 'true') {
                            doc.translate(234, 206 - (params.rec.Template.Description ? 0 : 44)).scale(1.37);
                        } else {
                            doc.translate(301.5, 186).scale(1.75);
                        }
                        processShapes(result.svg);
                        doc.restore();
                    }
                    callback();
                });
            },
            getBadgeFromCache = function (cacheKey, cb) {
                HgCache.GlobalGet(cacheKey, function (error, svg) {
                    if (error || !svg) {
                        return cb();
                    }
                    cb(svg);
                });
            },
            addBadgeImage = function (params, callback) {
                var recognition = params.rec,
                    fileName = recognition.BadgeFilename && recognition.BadgeFilename.length ? recognition.BadgeFilename : recognition.Template.hgId,
                    cacheKey;
                if (isLocal) {
                    cacheKey = './static/img/badges/group/' + recognition.Template.FriendlyGroupId + '/' + fileName + '.svg';
                    getBadgeFromCache(cacheKey, function (svg) {
                        if (svg) {
                            params.xml = svg;
                            processBadge(params, callback);
                        } else {
                            fs.readFile(cacheKey, 'utf8', function (error, svg) {
                                if (error) {
                                    return HgLog.error({methodName: 'addBadgeImage', error: error});
                                }
                                svg = svg.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                                HgCache.GlobalSet(cacheKey, svg, function (err) {
                                    if (err) {
                                        HgLog.error(err);
                                    }
                                });
                                params.xml = svg;
                                processBadge(params, callback);
                            });
                        }
                    });
                } else {
                    cacheKey = '/badges/group/' + recognition.Template.FriendlyGroupId + '/' + fileName + '.svg';
                    getBadgeFromCache(cacheKey, function (svg) {
                        if (svg) {
                            params.xml = svg;
                            processBadge(params, callback);
                        } else {
                            svg = '';
                            https.get({
                                host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
                                path: cacheKey
                            }, function (ret) {
                                ret.on("data", function (chunk) {
                                    svg += chunk;
                                }).on("end", function () {
                                    svg = svg.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                                    HgCache.GlobalSet(cacheKey, svg, function (err) {
                                        if (err) {
                                            HgLog.error(err);
                                        }
                                    });
                                    params.xml = svg;
                                    processBadge(params, callback);
                                });
                            }).on('error', function (e) {
                                HgLog.error('addBadgeImage.ERROR: ' + e.message);
                                callback();
                            });
                        }
                    });
                }
            },
            addRecognition = function (params, callback) {
                var namePos = '',
                    position = i18nHelper.translate(lang, 'pdf.cert.emp'),
                    presentedTo = i18nHelper.translate(lang, 'pdf.cert.pres'),
                    rec = params.rec,
                    fromLineWidth = 250,
                    fSize,
                    noDescOffset = 0,
                    subValueOffset = 0;
                if (rec) {
                    // title
                    // decrease font size until it fits withing a width of 500pts
                    fSize = 36;
                    doc.fontSize(fSize).font('OpenSans-Semibold');
                    while (doc.widthOfString(rec.Template.Title) > 500 && fSize > 20) {
                        fSize -= 1;
                        doc.fontSize(fSize);
                    }
                    doc.fill(defaultColor)
                        .text(rec.Template.Title, 146, 50 + (rec.Template.Description ? 0 : 14), {
                            width: 500,
                            height: 40,
                            align: 'center'
                        });
                    // check for subvalue first
                    if (rec.SubValue) {
                        doc.fontSize(15).font('OpenSans-Regular')
                            .text(rec.SubValue, 146, 104, {
                                width: 500,
                                height: 5 * 15 * 1.2,
                                align: 'center'
                            });
                        subValueOffset = 18;
                    }
                    // description
                    if (rec.Template.Description) {
                        doc.fontSize(14).font('OpenSans-Regular')
                            .text(rec.Template.Description, 146, 100 + subValueOffset * 2, {
                                width: 500,
                                height: (5 - (subValueOffset ? 2 : 0)) * 15 * 1.2,
                                align: 'center'
                            });
                    } else {
                        noDescOffset = 44;
                    }
                    if (rec.RecipientMember.Position) {
                        position = rec.RecipientMember.Position;
                    }
                    if (params.msg === 'true') {
                        // presented to
                        doc.fontSize(14).font('OpenSans-Regular')
                            .text(presentedTo, 396, 232 - noDescOffset, {
                                width: 300,
                                height: 20,
                                align: 'left'
                            });
                        // member name
                        // decrease font size until it fits within a width of 300pts
                        fSize = 32;
                        doc.fontSize(fSize).font('OpenSans-Semibold');
                        while (doc.widthOfString(rec.RecipientMember.FullName) > 300 && fSize > 20) {
                            fSize -= 1;
                            doc.fontSize(fSize);
                        }
                        doc.text(rec.RecipientMember.FullName, 396, 274 - noDescOffset, {
                            width: 300,
                            height: fSize * 1.2,
                            align: 'left'
                        });
                        // recipient position
                        doc.fontSize(14).text(position, 396, 315 - noDescOffset, {
                            width: 300,
                            align: 'left'
                        });
                    } else {
                        // presented to
                        doc.fontSize(16).font('OpenSans-Regular')
                            .text(presentedTo, 50, 391, {
                                width: 692,
                                height: 100,
                                align: 'center'
                            });
                        // divider line
                        doc.moveTo(224, 456).lineTo(568, 456).stroke(underlineColor);
                        // member name
                        doc.fontSize(32).font('OpenSans-Semibold')
                            .text(rec.RecipientMember.FullName, 50, 418, {
                                width: 692,
                                height: 120,
                                align: 'center'
                            });
                        // recipient position
                        doc.fontSize(14).text(position, 50, 460, {
                            width: 692,
                            align: 'center'
                        });
                    }
                    // date
                    doc.fontSize(12).font('OpenSans-Regular').text(i18nHelper.translate(lang, 'pdf.cert.date'), 165, 523, {
                        width: 166,
                        align: 'center'
                    });
                    doc.fontSize(12).font('OpenSans-Regular')
                        .text((new Date(rec.CreatedDate)).toLocaleDateString(), 165, 502, {
                            width: 166,
                            align: 'center'
                        });
                    // from: giver name & position
                    doc.fontSize(12).font('OpenSans-Regular').text(i18nHelper.translate(lang, 'pdf.cert.from'), 418, 523, {
                        width: fromLineWidth,
                        align: 'center'
                    });
                    doc.fontSize(12).font('OpenSans-Regular');
                    if (rec.CreatorMember && rec.CreatorMember.FullName) {
                        namePos = rec.CreatorMember.FullName;
                    }
                    if (rec.CreatorMember.Position) {
                        namePos += ', ' + rec.CreatorMember.Position;
                    }
                    if (namePos && doc.widthOfString(namePos) > fromLineWidth) {
                        doc.text(rec.CreatorMember.FullName, 418, 488, {
                            width: fromLineWidth,
                            align: 'center'
                        });
                        namePos = rec.CreatorMember.Position;
                    }
                    // pull public creator info
                    if (!namePos && rec.PublicCreatorInfo && rec.PublicCreatorInfo.FullName && rec.PublicCreatorInfo.CompanyName) {
                        namePos = rec.PublicCreatorInfo.FullName + ', ' + rec.PublicCreatorInfo.CompanyName;
                    }
                    // pull program name or group name
                    if (!namePos) {
                        namePos = params.ProgramName || params.GroupName;
                    }
                    doc.text(namePos, 418, 502, {
                        width: fromLineWidth,
                        align: 'center'
                    });
                }
                callback();
            },
            addMessageOnCertificate = function (params, callback) {
                // message - keep this as the last text render step as
                // it needs to create a clipping path that can't be reset
                if (params.msg === 'true') {
                    doc.fontSize(12).font('OpenSans-Regular')
                        .text(params.rec.Message, 140, 370, {
                            width: 512,
                            align: 'center',
                            height: 7 * 12 * 1.2
                        });
                }
                if (params.spg === 'true') {
                    doc.addPage();
                    doc.fontSize(12).font('OpenSans-Regular')
                        .text(params.rec.Message, 140, 72, {
                            width: 512,
                            align: 'left'
                        });
                }
                callback();
            };

        // fonts are stored in the slug under /static/fonts directory
        doc.registerFont('OpenSans-Regular', './static/fonts/Open_Sans/OpenSans-Regular.ttf');
        doc.registerFont('OpenSans-Semibold', './static/fonts/Open_Sans/OpenSans-Semibold.ttf');

        this.GetCustomCertificateTemplates = function (params, callback) {
            var certTemplates = [];
            EntityCache.Group.findOne({hgId: params.GroupId}, {
                Preference: 1,
                PublicDisplayName: 1,
                ProgramName: 1,
                GroupName: 1
            }, {lean: true}, function (err, group) {
                var feature;
                // ignore errors, because it'll just send back a blank array
                if (!err && group) {
                    if (group.Preference.FeatureFlags) {
                        feature = group.Preference.FeatureFlags.filter(function (flags) {
                            return flags.FeatureName === 'CertificateTemplates';
                        });
                        if (feature.length === 1 && feature[0].FeatureMeta.length === 1) {
                            certTemplates = feature[0].FeatureMeta[0].Value.split(',');
                        }
                    }
                } else {
                    group = {
                        PublicDisplayName: "N/A",
                        ProgramName: "N/A",
                        GroupName: "N/A"
                    };
                }
                // always return something back, do not error out
                callback({
                    certs: certTemplates,
                    PublicDisplayName: group.PublicDisplayName,
                    ProgramName: group.ProgramName,
                    GroupName: group.GroupName
                });
            });
        };

        this.GenerateCertificate = function (params, callback) {
            lang = params.lang;
            doc.info.Title = i18nHelper.translate(lang, 'pdf.cert.ttl');
            buffers = [];
            doc.on('data', function (data) {
                buffers.push(data);
            });
            doc.on('end', function () {
                if (buffers.length) {
                    callback(null, Buffer.concat(buffers));
                } else {
                    callback(i18nHelper.translate(lang, 'pdf.cert.errg'));
                }
            });
            EntityCache.Recognition.findOne({hgId: params.rId, "RecipientMember.GroupId": params.groupId}, {}, {lean: true}, function (err, recognition) {
                if (!err && recognition && recognition.RecipientMember) {
                    params.rec = recognition;
                    readTemplate(params.cId, function () {
                        // get group info
                        if (params.groupInfo.GroupName) {
                            params.PublicDisplayName = params.groupInfo.PublicDisplayName;
                            params.ProgramName = params.groupInfo.ProgramName;
                            params.GroupName = params.groupInfo.GroupName;
                            addRecognition(params, function () {
                                addBadgeImage(params, function () {
                                    addMessageOnCertificate(params, function () {
                                        doc.end();
                                    });
                                });
                            });
                        } else {
                            callback(i18nHelper.translate(lang, 'pdf.cert.errg'), err);
                        }
                    });
                } else {
                    callback(i18nHelper.translate(lang, 'pdf.cert.errg'));
                }
            });
        };

    };

module.exports = CertificateProcessor;
