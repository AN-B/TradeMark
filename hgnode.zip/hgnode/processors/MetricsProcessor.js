/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    MetricsProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            Enums = require('../enums/EntityEnums.js'),
            MemberEnums = require('../enums/MemberEnums.js'),
            FeedbackEnums = require('../enums/FeedbackEnums.js'),
            ConstantEnums = require('../enums/ConstantEnums.js'),
            DateHelper = require('../util/DateHelper.js'),
            MetricsHelper = require('../services/Helper/MetricsHelper.js'),
            HgLog = require('../framework/HgLog.js'),
            Async = require('async'),
            PerformEnums = require('../enums/PerformanceEnums.js'),
            metricFields = {
                Period : 'p',
                GroupId : 'g',
                Category : 'c',
                Match : '$match',
                Group : '$group',
                AssignedTrackGroupId : 'AssignedMember.GroupId',
                AssignedTrackMemberIds : 'AssignedMember.hgId',
                ModifiedDate : 'ModifiedDate',
                Project : '$project',
                NotInCategory : 'c',
                InCategory : 'c',
                Source : 's',
                MetricMemberIds : 'm',
                DirectReport : 'r',
                Activity : 'a'
            },
            self = this;

/*!
 * Pre Aggregation
 *
 *strategy 1
 *preallocate records at midnight for the next day for all groups
 *
 *strategy 2
 *use upsert for new allocation (expect slightly slower writes because of recreation and reallocation of memory)
 *upserts do not apply defaults
 *
 */

/*!
 * Helper Functions
 * To-do move into helper file
 */

        function getExcludedMemberActivity() {
            return [
                Enums.MetricsMemberCategory.RecognitionReceived,
                Enums.MetricsMemberCategory.Reviewed,
                Enums.MetricsMemberCategory.CoachingReceived,
                Enums.MetricsMemberCategory.SubmittedReview,
                Enums.MetricsMemberCategory.SubmittedReviewAsPeer,
                Enums.MetricsMemberCategory.SubmittedReviewAsManager
            ];
        }
        function getReviewSubmittionDate(review) {
            var returnDate, reviewPeoples;
            if (review.StatusByAdminView === PerformEnums.ReviewStatus.Submitted) {
                //returns last submitted review which would qualify as the date the review became Submitted.
                reviewPeoples = review.Peoples.sort(function (a, b) {
                    return a.SubmitDate > b.SubmitDate ? -1 : 1;
                });
                returnDate = DateHelper.getJustDate(reviewPeoples[0].SubmitDate);
            } else if (review.StatusByAdminView === PerformEnums.ReviewStatus.Closed) {
                returnDate = DateHelper.getJustDate(review.ReviewClosedDate);
            }
            return returnDate;
        }
        function getIncludedUniqueMemberActivity() {
            var activitiesToExclude = getExcludedMemberActivity(),
                trackedActivities = [];
            Object.keys(Enums.MetricsMemberCategory).forEach(function (item) {
                if (activitiesToExclude.indexOf(item) < 0) {
                    trackedActivities.push(item);
                }
            });
            return trackedActivities;
        }

        function saveRecognition(params) {
            var query = {p : params.Date, g : params.GroupId},
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {},
                subItem = {},
                total = 't',
                inc = '$inc',
                hourIndex = 'h.' + params.Hour;
            subItem[total] = params.UpdateValue;
            subItem[hourIndex] = 1;
            update[inc] = subItem;
            EntityCache.MetricsRecognition.update(query, update, options).exec();
        }
        function saveFeedback(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.Category, s : params.Source},
                options = {upsert: true},
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsFeedBack.update(query, update, options).exec();
        }
        function saveCoaching(params) {
            var query = {p : params.Date, g : params.GroupId, s : params.Source},
                options = {upsert: true},
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsCoaching.update(query, update, options).exec();
        }
        function saveCoachingCategory(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.Category, s : params.Source},
                options = {upsert: true},
                update = {$inc : { t : 1}};
            EntityCache.MetricsCoachingCategory.update(query, update, options).exec();
        }
        function saveManagerActivity(params) {
            var query = { p : params.Date, g : params.GroupId, c : params.Category, m : params.MemberId, a : params.Activity, r : params.ReportType},
                options = {upsert: true},
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsManager.update(query, update, options).exec();
        }
        function saveRecognitionCategory(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.Category, s : params.Source},
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsRecognitionCategory.update(query, update, options).exec();
        }
        function saveNewsActivity(params) {
            var query = {p : params.Date, g : params.GroupId},
                options = {upsert: true},
                update = {$inc : { t : 1}};
            EntityCache.MetricsNews.update(query, update, options).exec();
        }
        function savePerformActivity(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.PerformActivity},
                options = {upsert: true},
                update = {$inc : { t : 1}};
            EntityCache.MetricsPerformActivity.update(query, update, options).exec();
        }
        function savePerform(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.ReviewStatus, s : params.Source},
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsPerform.update(query, update, options).exec();
        }
        function saveCongratMetric(params) {
            var query = {p : params.Date, g : params.GroupId, s: params.CongratSource, c : params.Category },
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsCongrat.update(query, update, options).exec();
        }
        function saveCommentMetric(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.EntityType, s: params.CommentSource},
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsComment.update(query, update, options).exec();
        }
        function saveMemberMetric(params) {
            var query = {
                p: params.Date,
                g: params.GroupId,
                m: params.MemberId,
                c: params.Category
            },
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {$inc: { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsMember.update(query, update, options).exec();
        }
        function saveDepartmentMetric(params) {
            var query = {p : params.Date, g : params.GroupId, d : params.Department, c : params.Category, s : params.Source},
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsDepartment.update(query, update, options).exec();
        }
        function saveTrackMetric(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.Category},
                options = {upsert: true},
                update = {$inc : { t : 1}};
            EntityCache.MetricsTrack.update(query, update, options).exec();
        }
        function decreaseMemberAssignedTrackMetric(params) {
            var query = {p : params.Date, g : params.GroupId, m : params.MemberId, c : params.Category, t : { $gte : 1}},
                options = {upsert: false},
                update = {$inc : { t : -1}};
            EntityCache.MetricsMember.update(query, update, options).exec();
        }
        function saveRecognitionSource(params) {
            var query = {p : params.Date, g : params.GroupId, c : params.PublicityType, s : params.Source},
                options = {upsert: (params.UpdateValue < 1) ? false : true },
                update = {$inc : { t : params.UpdateValue}};
            if (params.UpdateValue < 1) {
                query.t = { $gte : 1};
            }
            EntityCache.MetricsRecognitionSource.update(query, update, options).exec();
        }
        function getRecognitionPublicityType(recognition) {
            return (!recognition.PublicCreatorInfo || !recognition.PublicCreatorInfo.FullName || recognition.Template.Category === 'System') ? 'Internal' : 'Public';
        }
        function getMyManager(recognition) {
            return (recognition.RecipientMember.MyManagers &&
                    recognition.RecipientMember.MyManagers.length > 0 &&
                    recognition.RecipientMember.MyManagers[0].MemberId) ? recognition.RecipientMember.MyManagers[0].MemberId : '';
        }
        function saveOneRecognitionMetric(recognition, updateValue, callback) {
            var today = DateHelper.getJustDate(recognition.CreatedDate),
                publicityType = getRecognitionPublicityType(recognition),
                category = [recognition.Template.Category, '.', recognition.Template.SubCategory].join(''),
                groupId = recognition.RecipientMember.GroupId,
                departmentName = recognition.CreatorMember ? recognition.CreatorMember.GroupDepartmentName : '';
            if (recognition.Template.Type !== 'Newsfeed' && recognition.Template.Type !== 'ProductItem') {
                saveRecognition({
                    Date : today,
                    Hour : new Date(recognition.CreatedDate).getHours(),
                    GroupId : groupId,
                    Source : recognition.Source,
                    UpdateValue : updateValue
                });
                saveRecognitionCategory({
                    Category : category,
                    Date : today,
                    GroupId : groupId,
                    Source : recognition.Source,
                    UpdateValue : updateValue
                });
                saveRecognitionSource({
                    PublicityType : publicityType,
                    Date : today,
                    GroupId : groupId,
                    Source : recognition.Source,
                    UpdateValue : updateValue
                });
                saveMemberMetric({
                    Date : today,
                    GroupId : groupId,
                    MemberId : recognition.RecipientMember.hgId,
                    Category : Enums.MetricsMemberCategory.RecognitionReceived,
                    UpdateValue : updateValue
                });
                if (recognition.CreatorMember && recognition.CreatorMember.hgId && recognition.CreatorMember.hgId !== '') {
                    saveMemberMetric({
                        Date : today,
                        GroupId : groupId,
                        MemberId : recognition.CreatorMember.hgId,
                        Category : Enums.MetricsMemberCategory.RecognitionGiven,
                        UpdateValue : updateValue
                    });
                    saveManagerActivity({
                        Date : today,
                        GroupId : groupId,
                        Category : 'g',
                        ReportType : (getMyManager(recognition) === recognition.CreatorMember.hgId),
                        MemberId : recognition.CreatorMember.hgId,
                        Activity : 'r',
                        UpdateValue : updateValue
                    });
                }
                saveManagerActivity({
                    Date : today,
                    GroupId : groupId,
                    Category : 'r',
                    Activity : 'r',
                    ReportType : (((recognition.CreatorMember && recognition.CreatorMember.hgId) ? recognition.CreatorMember.hgId : '') === getMyManager(recognition)),
                    MemberId : recognition.RecipientMember.hgId,
                    UpdateValue : updateValue
                });
                if (publicityType === 'Internal') {
                    saveDepartmentMetric({
                        Department : (departmentName === '' || departmentName === null || departmentName === undefined) ? 'Other' : departmentName,
                        Date : today,
                        GroupId : groupId,
                        Category : Enums.MetricsDepartmentCategory.RecognitionGiven,
                        UpdateValue : updateValue,
                        Source : recognition.Source
                    });
                }
            }
        }
        function getMemberDepartment(params, callback) {
            EntityCache.Member.findOne({hgId : params.MemberId}, {hgId : 1, GroupDepartmentName : 1}, function (error, member) {
                if (error) { return callback(error); }
                callback(null, member);
            });
        }
        function saveOneArchivedReviewMetric(review) {
            var groupId = review.Card.GroupId;
            if (review.StatusByAdminView !== PerformEnums.ReviewStatus.Archived) {
                review.Peoples.forEach(function (item) {
                    if (item.PeopleType === PerformEnums.DefaultPeopleTypes.Subject) {
                        getMemberDepartment({MemberId: item.MemberId}, function (error, memberDepartment) {
                            savePerform({
                                Date : DateHelper.getJustDate(),
                                ReviewStatus : PerformEnums.ReviewStatus.Archived,
                                GroupId : groupId,
                                Source : 'Web',
                                UpdateValue : 1
                            });
                            if (item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted || item.StatusInCurrentReview === PerformEnums.ReviewStatus.Closed) {
                                saveMemberMetric({
                                    Date: getReviewSubmittionDate(review),
                                    GroupId: groupId,
                                    MemberId: item.MemberId,
                                    Category: 'Reviewed',
                                    UpdateValue: -1
                                });
                                saveDepartmentMetric({
                                    Department: (memberDepartment.GroupDepartmentName !== undefined && memberDepartment.GroupDepartmentName !== '') ? memberDepartment.GroupDepartmentName : 'Other',
                                    Date: getReviewSubmittionDate(review),
                                    Category: 'Reviewed',
                                    GroupId: groupId,
                                    UpdateValue: -1,
                                    Source : 'Web',
                                });
                                savePerform({
                                    Date : DateHelper.getJustDate(review.ModifiedDate),
                                    ReviewStatus : item.StatusInCurrentReview,
                                    GroupId : groupId,
                                    Source : 'Web',
                                    UpdateValue : -1
                                });
                                if (item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted) {
                                    saveMemberMetric({
                                        Date: DateHelper.getJustDate(item.SubmitDate),
                                        GroupId: groupId,
                                        MemberId: item.MemberId,
                                        Category: 'SubmittedReview',
                                        UpdateValue: -1
                                    });
                                }
                            }
                        });
                    } else if (item.PeopleType === PerformEnums.DefaultPeopleTypes.Manager) {
                        if (item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted) {
                            saveMemberMetric({
                                Date: DateHelper.getJustDate(item.SubmitDate),
                                GroupId: groupId,
                                MemberId: item.MemberId,
                                Category: 'SubmittedReviewAsManager',
                                UpdateValue: -1
                            });
                        }
                    } else if (item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted) {
                        saveMemberMetric({
                            Date: DateHelper.getJustDate(item.SubmitDate),
                            GroupId: groupId,
                            MemberId: item.MemberId,
                            Category: 'SubmittedReviewAs' + item.PeopleType,
                            UpdateValue: -1
                        });
                    }
                });
            }
        }
        function saveOneReviewMetric(review) {
            var groupId = review.Card.GroupId;
            if (review.StatusByAdminView === PerformEnums.ReviewStatus.Submitted || review.StatusByAdminView === PerformEnums.ReviewStatus.Closed) {
                review.Peoples.forEach(function (item) {
                    if (item.PeopleType === PerformEnums.DefaultPeopleTypes.Subject) {
                        getMemberDepartment({MemberId: item.MemberId}, function (error, memberDepartment) {
                            savePerform({
                                Date : getReviewSubmittionDate(review),
                                ReviewStatus : review.StatusByAdminView,
                                GroupId : groupId,
                                Source : 'Web',
                                UpdateValue : 1
                            });
                            saveMemberMetric({
                                Date: getReviewSubmittionDate(review),
                                GroupId: groupId,
                                MemberId: item.MemberId,
                                Category: 'Reviewed',
                                UpdateValue: 1
                            });
                            saveDepartmentMetric({
                                Department: (memberDepartment.GroupDepartmentName !== undefined && memberDepartment.GroupDepartmentName !== '') ? memberDepartment.GroupDepartmentName : 'Other',
                                Date: getReviewSubmittionDate(review),
                                Category: 'Reviewed',
                                GroupId: groupId,
                                UpdateValue: 1,
                                Source : 'Web',
                            });
                            if (item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted) {
                                saveMemberMetric({
                                    Date: DateHelper.getJustDate(item.SubmitDate),
                                    GroupId: groupId,
                                    MemberId: item.MemberId,
                                    Category: 'SubmittedReview',
                                    UpdateValue: 1
                                });
                            }
                        });
                    } else if (item.PeopleType === PerformEnums.DefaultPeopleTypes.Manager) {
                        if (item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted) {
                            saveMemberMetric({
                                Date: DateHelper.getJustDate(item.SubmitDate),
                                GroupId: groupId,
                                MemberId: item.MemberId,
                                Category: 'SubmittedReviewAsManager',
                                UpdateValue: 1
                            });
                        }
                    } else if (item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted) {
                        saveMemberMetric({
                            Date: DateHelper.getJustDate(item.SubmitDate),
                            GroupId: groupId,
                            MemberId: item.MemberId,
                            Category: 'SubmittedReviewAs' + item.PeopleType,
                            UpdateValue: 1
                        });
                    }
                });
            }
        }

        function addOneRecognitionMetric(recognition, callback) {
            saveOneRecognitionMetric(recognition, 1, callback);
        }
        function subOneRecognitionMetric(recognition, callback) {
            saveOneRecognitionMetric(recognition, -1, callback);
        }
        function getDefualtAggregation(params, includeCategory) {
            var take = (params.Take !== undefined) ? params.Take : 7,
                filter = (params.Filter && params.Filter !== '') ? params.Filter : {$match : {}},
                group = { $group: { _id: { year : { '$year' : '$p'}, month : { '$month' : '$p'}}, Total: {$sum: "$t"}}},
                project = { $project : { Total : 1, '_id.year' : 1, '_id.month' : 1, _id : 0}},
                preProject = null,
                sort = { $sort: { '_id.year' : -1, '_id.month' : -1 } },
                limit =  { $limit : take },
                aggregateParams;
            if (params.DateRange === 'Daily') {
                preProject = { '$project' :
                    {
                        _id : 0,
                        Total : '$t',
                        date : {
                            year: { '$year' : '$p'},
                            month: { '$month' : '$p'},
                            day: { '$dayOfMonth' : '$p'}
                        }
                    }
                    };
                group = { '$group' : {  _id : {  date: "$date"},  Total : { $sum : '$Total'} }};
                project = {
                    $project : {
                        Total : 1,
                        '_id.date.year' : 1,
                        '_id.date.month' : 1,
                        '_id.date.day' : 1,
                        _id : 0
                    }
                };
                sort = { $sort: { '_id.year' : -1, '_id.month' : -1, '_id.day' : -1 } };
            }
            if (includeCategory && includeCategory === true) {
                group[metricFields.Group]._id[metricFields.Category] = '$c';
                if (preProject !== null) {
                    preProject[metricFields.Project].date.c = '$c';
                    project[metricFields.Project]['_id.date.c'] =  1;
                } else {
                    project[metricFields.Project]['_id.c'] =  1;
                }
            }
            if (params.DateRange === 'Daily') {
                aggregateParams = [filter, preProject, group, project, sort];
            } else {
                aggregateParams = [filter, group, project, sort];
            }
            if (params.Take > 0) {
                aggregateParams.push(limit);
            }
            return aggregateParams;
        }
        // can still be refactored to support all entity types
        function getGroupType(params) {
            var groupType = {
                    All : { c : '$c'},
                    ByMonthYear : { c : '$c', year : {"$year" : "$p"}, month : {"$month" : "$p"} }
                };
            return groupType[params.Type];
        }
        function getQueryFilter(params) {
            var filter = {}, match = {};
            if (params.EntityId && params.EntityId !== '') {
                filter[metricFields.GroupId] = params.EntityId;
            }
            if (params.StartDate && params.EndDate) {
                filter[metricFields.Period] = { $gte : DateHelper.getJustDate(params.StartDate), $lte : DateHelper.getJustDate(params.EndDate)};
            }
            if (params.CommentType && params.CommentType !== '') {
                filter[metricFields.Category] = params.CommentType;
            }
            if (params.DepartmentCategory && params.DepartmentCategory !== '') {
                filter[metricFields.Category] = params.DepartmentCategory;
            }
            if (params.AssignedTrackGroupId && params.AssignedTrackGroupId !== '') {
                filter[metricFields.AssignedTrackGroupId] = params.AssignedTrackGroupId;
            }
            if (params.TrackCategory && params.TrackCategory !== '') {
                filter[metricFields.Category] = params.TrackCategory;
            }
            if (params.MemberCategory && params.MemberCategory !== '') {
                filter[metricFields.Category] = { $in : params.MemberCategory };
            }
            if (params.NotInCategory && params.NotInCategory !== '') {
                filter[metricFields.NotInCategory] = { $nin : params.NotInCategory };
            }
            if (params.InCategory && params.InCategory !== '') {
                filter[metricFields.InCategory] = { $in : params.InCategory };
            }
            if (params.MetricMemberIds && params.MetricMemberIds.length > 0) {
                filter[metricFields.MetricMemberIds] = { $in : params.MetricMemberIds };
            }
            if (params.AssignedTrackMemberIds && params.AssignedTrackMemberIds.length > 0) {
                filter[metricFields.AssignedTrackMemberIds] = { $in : params.AssignedTrackMemberIds };
            }
            if (params.DirectReport) {
                filter[metricFields.DirectReport] = params.DirectReport;
            }
            if (params.Category) {
                filter[metricFields.Category] = params.Category;
            }
            if (params.Activity) {
                filter[metricFields.Activity] = params.Activity;
            }
            match[metricFields.Match] = filter;
            return match;
        }
        function mapDataResult(dataRange, data, includeCategory) {
            var dataRecords = {};
            data.map(function (item) {
                if (dataRange === 'Daily') {
                    if (includeCategory && includeCategory === true) {
                        dataRecords[item._id.date.year + '.' + item._id.date.month + '.' + item._id.date.day + '.' + item._id.date.c] = item.Total;
                    } else {
                        dataRecords[item._id.date.year + '.' + item._id.date.month + '.' + item._id.date.day] = item.Total;
                    }
                } else {
                    if (includeCategory && includeCategory === true) {
                        dataRecords[item._id.year + '.' + item._id.month + '.' + item._id.c] = item.Total;
                    } else {
                        dataRecords[item._id.year + '.' + item._id.month] = item.Total;
                    }
                }
            });
            return dataRecords;
        }

        function getOnlyActiveMembers(data, fCallback) {
            Async.each(data, function (monthRecord, callback) {
                EntityCache.Member.find({hgId : { $in : monthRecord.m}, MembershipStatus : 'Active'}, {hgId : 1}, function (error, members) {
                    if (error) {
                        callback(error);
                    } else {
                        monthRecord.m = members.map(function (item) { return item.hgId; });
                        callback();
                    }
                });
            }, function (error) {
                if (error) {
                    fCallback(error);
                } else {
                    fCallback(null, data);
                }
            });
        }
        function getNoteCategory(note) {
            var cat;
            if (note.Status === 'Active') {
                cat = (note.TrackId === undefined || note.TrackId === null) ? Enums.MetricsCoachingCategory.PlainNotes : Enums.MetricsCoachingCategory.TrackLinkedNotes;
            } else {
                cat = (note.TrackId === undefined || note.TrackId === null) ? Enums.MetricsCoachingCategory.PrivatePlainNotes : Enums.MetricsCoachingCategory.PrivateTrackLinkedNotes;
            }
            return cat;
        }
        //This method is only temporarily used to get group departments until
        //the departments is restructured
/*!
 *
 * Public Read Methods
 *
 */
        this.GetMyMetrics = function (params, callback) {
            var dataRecords = {};
            EntityCache.MetricsMember.aggregate([
                {
                    $match : {
                        m : params.MemberId,
                        c : {
                            $in : [
                                Enums.MetricsMemberCategory.CoachingReceived,
                                Enums.MetricsMemberCategory.ReceivedFeedBack
                            ]
                        }
                    }
                }, {
                    $group : {
                        _id : {c : '$c'},
                        Total : { $sum : '$t'}
                    }
                }], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.map(function (item) {
                    dataRecords[item._id.c] = item.Total;
                });
                callback(null, dataRecords);
            });
        };

        this.GetFoundingCompany = function (params, callback) {
            EntityCache.Group.findOne({'Preference.FeatureFlags.FeatureName' : 'IsFoundingCompany'}, {hgId : 1}, function (error, data) {
                if (error) { return callback(error); }
                callback(null, data);
            });
        };
        this.GetCommentMetrics = function (params, callback) {
            var aggregateParams,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    CommentType : params.CommentType
                },
                newParams = {
                    Filter : getQueryFilter(iParam),
                    Take  : (!params.Take) ?  0 : 7,
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams);
            EntityCache.MetricsComment.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data), length : data.length});
            });
        };

        this.GetShareMetrics = function (params, callback) {
            var aggregateParams,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Filter : getQueryFilter(iParam),
                    Take  : (!params.Take) ?  0 : 7,
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams);
            EntityCache.MetricsRecognitionShare.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data), length : data.length});
            });
        };

        this.GetRecognitionDepartmentMetrics = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    DepartmentCategory : Enums.MetricsDepartmentCategory.RecognitionGiven
                },
                group = { $group : { _id : {'d' : '$d'}, Total : {$sum : '$t'}}},
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam);
            EntityCache.MetricsDepartment.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    dataRecords[(item._id.d !== '') ? item._id.d : 'UnKnown'] = item.Total;
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetGroupDepartmentsMetrics = function (params, callback) {
            var dataRecords = [],
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                group = { $group : { _id : { d : '$d', c : '$c' }, Total : {$sum : '$t'}}},
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam),
                CategoryData = {};
            EntityCache.MetricsDepartment.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    CategoryData = {
                        Name : item._id.d,
                        Category : item._id.c
                    };
                    CategoryData[item._id.c + 'Total'] = item.Total;
                    dataRecords.push(CategoryData);
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetCoachingCategoryMetric = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                group = {
                    $group : {
                        _id : getGroupType({ Type : (params.CategoryGroupType === undefined) ? 'All' : params.CategoryGroupType}),
                        Total : {$sum : '$t'}
                    }
                },
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam);
            EntityCache.MetricsCoachingCategory.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    if (params.CategoryGroupType === undefined || params.CategoryGroupType === 'All') {
                        dataRecords[(item._id.c !== '') ? item._id.c : 'No Category Name'] = item.Total;
                    } else if (params.CategoryGroupType === 'ByMonthYear') {
                        data.map(function (item) { dataRecords[item._id.c + '.' + item._id.year + '.' + item._id.month] = item.Total; });
                    }
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetUniqueActiveMembers = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    InCategory : getIncludedUniqueMemberActivity()
                },
                newParams = {
                    Filter : getQueryFilter(iParam)
                },
                filter = (newParams.Filter && newParams.Filter !== '') ? newParams.Filter : {$match : { c : { $in : getIncludedUniqueMemberActivity()}}},
                group = { $group: { _id: { year : {'$year' : '$p'}, month : { '$month' : '$p'}}, m : { '$addToSet' : "$m" }}},
                project = { $project : {'_id.year' : 1, '_id.month' : 1, 'm' : 1, _id : 0}},
                sort = { $sort: { '_id.year' : -1, '_id.month' : -1} };
            EntityCache.MetricsMember.aggregate([filter, group, project, sort], function (error, data) {
                if (error) { return callback(error); }
                getOnlyActiveMembers(data, function (error, data) {
                    data.map(function (item) { dataRecords[item._id.year + '.' + item._id.month] = item.m.length; });
                    callback(null, {data : dataRecords, length : data.length});
                });
            });
        };

        this.GetRecognitionSourceMetrics = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                group = {
                    $group : {
                        _id : getGroupType({ Type : (params.CategoryGroupType === undefined) ? 'All' : params.CategoryGroupType}),
                        Total : {$sum : '$t'}
                    }
                },
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam);
            EntityCache.MetricsRecognitionSource.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    if (params.CategoryGroupType === undefined || params.CategoryGroupType === 'All') {
                        dataRecords[(item._id.c !== '') ? item._id.c : 'No Category Name'] = item.Total;
                    } else if (params.CategoryGroupType === 'ByMonthYear') {
                        data.map(function (item) { dataRecords[item._id.c + '.' + item._id.year + '.' + item._id.month] = item.Total; });
                    }
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetCongratCategoryMetrics = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                group = {
                    $group : {
                        _id : getGroupType({ Type : (params.CategoryGroupType === undefined) ? 'All' : params.CategoryGroupType}),
                        Total : {$sum : '$t'}
                    }
                },
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam);
            EntityCache.MetricsCongrat.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    if (params.CategoryGroupType === undefined || params.CategoryGroupType === 'All') {
                        dataRecords[(item._id.c !== '') ? item._id.c : 'No Category Name'] = item.Total;
                    } else if (params.CategoryGroupType === 'ByMonthYear') {
                        data.map(function (item) { dataRecords[item._id.c + '.' + item._id.year + '.' + item._id.month] = item.Total; });
                    }
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetRecognitionCategoryMetrics = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                group = {
                    $group : {
                        _id : getGroupType({ Type : (params.CategoryGroupType === undefined) ? 'All' : params.CategoryGroupType}),
                        Total : {$sum : '$t'}
                    }
                },
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam);
            EntityCache.MetricsRecognitionCategory.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    if (params.CategoryGroupType === undefined || params.CategoryGroupType === 'All') {
                        dataRecords[(item._id.c !== '') ? item._id.c : 'No Category Name'] = item.Total;
                    } else if (params.CategoryGroupType === 'ByMonthYear') {
                        data.map(function (item) { dataRecords[item._id.c + '.' + item._id.year + '.' + item._id.month] = item.Total; });
                    }
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetGroupTrackedActivityMetrics = function (params, callback) {
            var dataRecords = [],
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                group = { $group : { _id : { c : '$c', year : { '$year' : '$p'}, month : { '$month' : '$p'} }, Total : {$sum : '$t'}}},
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam),
                key;
            if (params.EntityId && params.EntityId !== '') {
                group[metricFields.Group]._id.g = '$g';
            }
            EntityCache.MetricsMember.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    key = ((params.EntityId !== undefined && params.EntityId !== '') ? item._id.g + '.'  : '') + item._id.c + '.' + item._id.month + '.' + item._id.year;
                    dataRecords[key] = item.Total;
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetGroupManagerMetricsActivity = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    Category : 'g', //given
                    Activity : 'r', // recognition
                    DirectReport : true, // direct report
                    MetricMemberIds : params.MemberIds
                },
                group = { $group : { _id : { m : '$m'}, Total : {$sum : '$t'}}},
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam);

            EntityCache.MetricsManager.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    dataRecords[item._id.m] = item.Total;
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetGroupUserMetrics = function (params, callback) {
            var dataRecords = [],
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    MetricMemberIds : params.MemberIds
                },
                group = { $group : { _id : { m : '$m', c : '$c' }, Total : {$sum : '$t'}}},
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam),
                CategoryData = {};
            EntityCache.MetricsMember.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    CategoryData = {
                        hgId : item._id.m,
                        Category : item._id.c
                    };
                    CategoryData[item._id.c + 'Total'] = item.Total;
                    dataRecords.push(CategoryData);
                });
                callback(null, {data : dataRecords, length : data.length});
            });
        };
        // this method is going directly to CareerTrack entity
        // Might move this to track internal service
        this.GetGroupMembersInProgressTracks = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    AssignedTrackGroupId : params.EntityId,
                    AssignedTrackMemberIds : params.MemberIds
                },
                group = { $group : { _id : { m : '$AssignedMember.hgId'}, Total : {$sum : 1}}},
                sort = { $sort: { Total : -1} },
                filter = getQueryFilter(iParam);
            filter[metricFields.Match].Status = { $nin : ['Created', 'Completed',  'Closed', 'Void'] };
            EntityCache.CareerTrack.aggregate([filter, group, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) { dataRecords[item._id.m] = item.Total; });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetGroupDepartmentInProgressTracks = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    AssignedTrackGroupId: params.EntityId,
                    AssignedTrackMemberIds: params.MemberIds
                },
                group = {
                    $group: {
                        _id: {
                            d: '$AssignedMember.GroupDepartmentId'
                        },
                        Total: {$sum: 1}
                    }
                },
                sort = { $sort: { Total: -1} },
                filter = getQueryFilter(iParam);
            filter[metricFields.Match].Status = { $nin: ['Created', 'Completed',  'Closed', 'Void'] };
            EntityCache.CareerTrack.aggregate([filter, group, sort], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.map(function (item) {
                    dataRecords[item._id.d] = item.Total;
                });
                callback(null, {data: dataRecords, length: data.length});
            });
        };


        this.GetDaysSinceLastActivityByMemberIds = function (params, callback) {
            var dataRecords = {},
                filter = getQueryFilter({
                    EntityId : params.EntityId,
                    MetricMemberIds : params.MemberIds,
                    MemberCategory : params.MemberActivityCategory
                }),
                group = { $group: { _id: { m: '$m'}, Date : { $max: "$p"}}};
            EntityCache.MetricsMember.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                if (!data || data.length === 0) { return callback(null, {data : {}, length : 0 }); }
                data.map(function (item) { dataRecords[item._id.m] = item.Date; });
                callback(null, {data : dataRecords, length : data.length});
            });
        };
        this.GetLastMemberActivityByCategory = function (params, callback) {
            var dataRecords = {};
            EntityCache.MetricsMember.aggregate([
                {$match: {
                    g: params.GroupId,
                    m: {$in: params.MemberIds},
                    c: {$in: params.MemberActivityCategory}
                }},
                {$group: {
                    _id: {
                        m: '$m',
                        c: '$c'
                    },
                    Date: {$max: "$p"}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!data || !data.length) {
                    return callback();
                }
                data.map(function (item) {
                    if (!dataRecords[item._id.m]) {
                        dataRecords[item._id.m] = {};
                    }
                    dataRecords[item._id.m][item._id.c] = item.Date;
                });
                callback(null, dataRecords);
            });
        };
        this.GetLastActivityByMemberIds = function (params, callback) {
            var filter = getQueryFilter({
                    EntityId : params.EntityId,
                    MetricMemberIds : params.MemberIds,
                    MemberCategory : params.MemberActivityCategory
                }),
                group = { $group: { _id: {m: '$m', c: '$c'}, Date : { $max: "$p"}}};
            filter[metricFields.Match].t = {$gt: 0};
            EntityCache.MetricsMember.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                if (!data || !data.length) { return callback(null, []); }
                callback(null, data);
            });
        };
        this.GetCountActivityByMemberIds = function (params, callback) {
            var filter = getQueryFilter({
                    EntityId : params.EntityId,
                    MetricMemberIds : params.MemberIds,
                    MemberCategory : params.MemberActivityCategory,
                    StartDate : new Date(Date.now() - 30 * 86400000)
                }),
                group = {$group: {_id: {m: '$m', c: '$c'}, count: { $sum: '$t'}}};
            EntityCache.MetricsMember.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                if (!data || !data.length) { return callback(null, []); }
                callback(null, data);
            });
        };

        //this method to be updated later to aggregate by department
        this.GetMemberDepartmentActivity = function (params, callback) {
            EntityCache.MetricsMember.aggregate([
                getQueryFilter({
                    EntityId: params.EntityId,
                    StartDate: params.StartDate,
                    EndDate: params.EndDate,
                    MemberCategory: params.ActivityCategory
                }),
                {$group: {
                    _id: { m: '$m'},
                    Date: { $max: "$p"}
                }},
                {$project: {
                    _id: 0,
                    m: '$_id.m',
                    Date: "$Date"
                }}
            ], callback);
        };

        //this method should be deprecated
        // MetricsMember schema needs to include departmentId and name,
        // locationid and name
        this.GetMembersByActivity = function (params, callback) {
            var memberIds = [],
                filter = getQueryFilter({
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    MemberCategory : params.ActivityCategory
                }),
                group = { $group: { _id: { m: '$m'}, Date : { $max: "$p"}}};
            EntityCache.MetricsMember.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                if (!data || data.length === 0) { return callback(null, []); }
                data.map(function (item) { memberIds.push(item._id.m); });
                EntityCache.Member.find({hgId : { $in: memberIds}}, {hgId : 1, GroupDepartmentName : 1}, function (error, members) {
                    if (error) { return callback(error); }
                    callback(null, {data : members});
                });
            });
        };

        this.GetGroupMemberLastLoginMetrics = function (params, callback) {
            var dataRecords = {},
                group = { $group: { _id: { m: '$m'}, Date : { $max: "$p"}}},
                iParam = {
                    EntityId : params.EntityId,
                    MetricMemberIds : params.MemberIds
                },
                filter = getQueryFilter(iParam);
            EntityCache.MetricsUserActivity.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) { dataRecords[item._id.m] = item.Date; });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetUserActivityMetrics = function (params, callback) {
            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Filter : getQueryFilter(iParam)
                },
                filter = (newParams.Filter && newParams.Filter !== '') ? newParams.Filter : {$match : {}},
                group = { $group: { _id: { year : {'$year' : '$p'}, month : { '$month' : '$p'}, day : { '$dayOfMonth' : '$p'}}, m : { '$addToSet' : "$m" }}},
                project = { $project : {'_id.year' : 1, '_id.month' : 1, '_id.day' : 1, 'm' : 1, _id : 0}},
                sort = { $sort: { '_id.year' : -1, '_id.month' : -1, '_id.day' : -1 } };
            EntityCache.MetricsUserActivity.aggregate([filter, group, project, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) { dataRecords[item._id.year + '.' + item._id.month + '.' + item._id.day] = item.m.length; });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.GetUserActivityPctMetrics = function (params, callback) {
            var dataRecords = {},
                filter = getQueryFilter({EntityId: params.EntityId, StartDate: params.StartDate, EndDate: params.EndDate}) || {$match : {}},
                group = { $group: { _id: { year: {'$year': '$p'}, month: { '$month': '$p'}}, m : {'$addToSet': "$m" }, c: {'$push': "$m"}}},
                project = { $project: {'_id.year': 1, '_id.month': 1, 'm': 1, 'c': 1, _id: 0}},
                sort = { $sort: {'_id.year': -1, '_id.month': -1} };
            EntityCache.MetricsUserActivity.aggregate([filter, group, project, sort], function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {dataRecords[item._id.year + '.' + item._id.month] = [item.m.length, item.c.length]; });
                callback(null, {data : dataRecords, length : data.length});
            });
        };

        this.AggregateLastMonthUserActivity = function (params, callback) {
            EntityCache.MetricsUserActivity.aggregate([
                {$match: {p: {$gte: params.StartDate, $lte: params.EndDate}}},
                {$group: {
                    _id: {
                        g: "$g",
                        year: {'$year': '$p'},
                        month: {'$month': '$p'}
                    },
                    m: { '$addToSet': "$m"}
                }}
            ], function (error, result) {
                if (error || !result || !result.length) {
                    return callback(error);
                }
                Async.each(result, function (activity, aCallback) {
                    EntityCache.MetricsMonthlyActivity.update({
                        g: activity._id.g,
                        year: activity._id.year,
                        month: activity._id.month,
                    }, {
                        $set: {
                            t: activity.m.length,
                            p: params.EndDate
                        }
                    }, {
                        upsert: true
                    }, aCallback);
                }, callback);
            });
        };

        this.GetMonthlyUserActivityMetrics = function (params, callback) {
            var query = {
                p: { $gte: params.StartDate, $lte: params.EndDate}
            },
                group = {
                    _id: {
                        year: '$year',
                        month: '$month',
                    },
                    total: { $sum: "$t"}
                },
                dataRecords = {};
            if (params.EntityId) {
                query.g = params.EntityId;
                group._id.g = "$g";
            }
            EntityCache.MetricsMonthlyActivity.aggregate([
                {$match: query},
                {$group: group},
                {$sort: {
                    '_id.year': 1,
                    '_id.month': 1
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.map(function (item) {
                    dataRecords[item._id.year + '.' + item._id.month] = item.total;
                });
                callback(null, {
                    data: dataRecords,
                    length: data.length
                });
            });
        };
        this.GetGroupUserActivityMetrics = function (params, finalCallback) {

            var dataRecords = {},
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                filter = getQueryFilter(iParam),
                group = { $group: { _id: { year : {'$year' : '$p'}, month : { '$month' : '$p'}}, m : { '$addToSet' : "$m" }}},
                project = { $project : {'_id.year' : 1, '_id.month' : 1, 'm' : 1, _id : 0}},
                sort = { $sort: { '_id.year' : -1, '_id.month' : -1 } };
            EntityCache.MetricsUserActivity.aggregate([filter, group, project, sort], function (error, data) {
                if (error) { return finalCallback(error); }
                getOnlyActiveMembers(data, function (error, data) {
                    if (error) { return finalCallback(error); }
                    data.map(function (item) { dataRecords[item._id.year + '.' + item._id.month] = item.m.length; });
                    finalCallback(null, {data : dataRecords, length : data.length});
                });
            });
        };

        this.GetTrackMetricsDetails = function (params, callback) {
            var aggregateParams,
                includeCategory = true,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Take  : (!params.Take) ?  0 : 7,
                    Filter : getQueryFilter(iParam),
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams, includeCategory);
            EntityCache.MetricsTrack.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data, includeCategory), length : data.length});
            });
        };
        this.GetPerformActivityMetrics = function (params, callback) {
            var aggregateParams,
                includeCategory = true,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Filter : getQueryFilter(iParam),
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams, includeCategory);
            EntityCache.MetricsPerformActivity.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data, includeCategory), length : data.length});
            });
        };

        this.GetPerformMetrics = function (params, callback) {
            var aggregateParams,
                includeCategory = true,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Filter : getQueryFilter(iParam),
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams, includeCategory);
            EntityCache.MetricsPerform.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data, includeCategory), length : data.length});
            });
        };

        this.GetRecognitionMetrics = function (params, callback) {
            var aggregateParams,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Take  : (!params.Take) ?  0 : 7,
                    Filter : getQueryFilter(iParam),
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams);
            EntityCache.MetricsRecognition.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data), length : data.length});
            });
        };

        this.GetTotalPerformMetrics = function (params, callback) {
            var aggregateParams = [
                    { $match : { c : {$in : [ Enums.MetricsPerformCategory.Submitted,  Enums.MetricsPerformCategory.Closed] }}},
                    { $group : { _id : 0, total : { $sum : '$t'}}}
                ];
            EntityCache.MetricsPerform.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {
                    TotalSubmittedReviews : (data[0] && data[0].total) ? data[0].total : 0
                });
            });
        };

        this.GetNewsMetrics = function (params, callback) {
            var aggregateParams,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Take  : (!params.Take) ?  0 : 7,
                    Filter : getQueryFilter(iParam),
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams);
            EntityCache.MetricsNews.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data), length : data.length});
            });
        };

        this.GetCoachingMetrics = function (params, callback) {
            var aggregateParams,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Take  : (!params.Take) ?  0 : 7,
                    Filter : getQueryFilter(iParam),
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams);
            EntityCache.MetricsCoaching.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data), length : data.length});
            });
        };

        this.GetTrackMetrics = function (params, callback) {
            var aggregateParams,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    TrackCategory: params.TrackCategory
                },
                newParams = {
                    Take  : (!params.Take) ?  0 : 7,
                    Filter : getQueryFilter(iParam),
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams);
            EntityCache.MetricsTrack.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data), length : data.length});
            });
        };

        this.GetCongratsMetrics = function (params, callback) {
            var aggregateParams,
                iParam = {
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate
                },
                newParams = {
                    Filter : getQueryFilter(iParam),
                    Take  : (!params.Take) ?  0 : 7,
                    DateRange : params.DateRange
                };
            aggregateParams = getDefualtAggregation(newParams);
            EntityCache.MetricsCongrat.aggregate(aggregateParams, function (error, data) {
                if (error) { return callback(error); }
                callback(null, {data : mapDataResult(params.DateRange, data), length : data.length});
            });
        };
        this.GetSummary = function (params, callback) {
            params.TrackCategory = Enums.MetricsTrackCategory.Created;
            Async.parallel({
                recognitions: function (fCallback) {
                    self.GetRecognitionMetrics(params, fCallback);
                },
                comments: function (fCallback) {
                    self.GetCommentMetrics(params, fCallback);
                },
                congrats: function (fCallback) {
                    self.GetCongratsMetrics(params, fCallback);
                },
                tracks: function (fCallback) {
                    self.GetTrackMetrics(params, fCallback);
                },
                coaching: function (fCallback) {
                    self.GetCoachingMetrics(params, fCallback);
                }
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    Recognitions: result.recognitions,
                    Comments: result.comments,
                    Congrats: result.congrats,
                    Tracks: result.tracks,
                    Coaching: result.coaching
                });
            });
        };
/*!
 *
 * Public Read Methods (Totals)
 *
 */
        this.GetGroupMemberNumber = function (params, callback) {
            var condition = {
                    GroupId: params.EntityId
                };
            condition.MembershipStatus = params.Status ? {$in: params.Status} : MemberEnums.Status.Active;
            EntityCache.Member.count(condition, callback);
        };
        //Adding this in metric processor for here to take advantage of possible query optimization without
        //affecting existing method call
        this.GetGroupMembers = function (params, callback) {
            var query = {
                    GroupId: params.EntityId
                },
                project = {
                    _id : 0,
                    hgId : 1,
                    UserId : 1,
                    FullName : 1,
                    MyManagers : 1,
                    RolesInGroup : 1,
                    EmployeeId : 1,
                    GroupDepartmentName : 1,
                    Location: 1
                };
            query.MembershipStatus = params.Status ? {$in: params.Status} : MemberEnums.Status.Active;
            if (params.DepartmentMembers && params.DepartmentMembers.length > 0) {
                query.hgId = { $in : params.DepartmentMembers};
            }
            if (params.ManagerMemberId && params.ManagerMemberId !== '') {
                query['MyManagers.MemberId'] = params.ManagerMemberId;
            }
            EntityCache.Member.find(query, project)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(function (error, members) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null,  members);
                });
        };

        this.GetTotalMembers = function (params, callback) {
            var filter = {'MembershipStatus' : 'Active'}, match = {},
                group =  { $group : { _id : {MembershipStatus : "$MembershipStatus"}, total : { $sum : 1}}};
            if (params.EntityId && params.EntityId !== '') {
                filter.GroupId = params.EntityId;
            }
            match[metricFields.Match] = filter;
            EntityCache.Member.aggregate([match, group], function (error, data) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {
                        TotalMembers : (data[0] && data[0].total) ? data[0].total : 0
                    });
                }
            });
        };

        this.UpdateLastRecognitionCheckInNumber = function (params) {
            var CheckInNumber = new EntityCache.MetricsRecognitionCheckInNumber({
                p : new Date().getTime(),
                t : params.LastRecognitionCheckInNumber
            });
            CheckInNumber.save();
        };

        this.GetLastRecognitionCheckInNumber = function (params, callback) {
            var mquery = EntityCache.MetricsRecognitionCheckInNumber.findOne({});
            mquery.sort({p : -1}).exec(function (error, record) {
                if (error || !record) {
                    callback(null, 0);
                } else {
                    callback(null, record.t);
                }
            });
        };

        this.GetTotalRecognitions = function (params, callback) {
            var group = { $group: { _id: null, total: { $sum: "$t" } } },
                filter = (params.Filter !== undefined && params.Filter !== '') ? {$match : { g : params.Filter}} : {$match : {}};
            EntityCache.MetricsRecognition.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                callback(null, {TotalRecognitions : (data[0] && data[0].total) ? data[0].total : 0});
            });
        };

        this.GetTotalTracks = function (params, callback) {
            var group = { $group: { _id: null, total: { $sum: "$t" } } },
                filter = {$match : { c : Enums.MetricsTrackCategory.Created}};
            EntityCache.MetricsTrack.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                callback(null, {TotalTracks : (data[0] && data[0].total) ? data[0].total : 0});
            });
        };

        this.GetTotalCongrats = function (params, callback) {
            var group = { $group: { _id: null, total: { $sum: "$t" } } },
                filter = (params.Filter !== undefined) ? {$match : { g : params.Filter}} : {$match : {}};
            EntityCache.MetricsCongrat.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                callback(null, {TotalCongrats : (data[0] && data[0].total) ? data[0].total : 0});
            });
        };

        this.GetTotalShares = function (params, callback) {
            var group = { $group: { _id: null, total: { $sum: "$t" } } },
                filter = (params.Filter !== undefined) ? {$match : { g : params.Filter}} : {$match : {}};
            EntityCache.MetricsRecognitionShare.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                callback(null, {TotalShares : (data[0] && data[0].total) ? data[0].total : 0});
            });
        };

        this.GetTotalComments = function (params, callback) {
            var group = { $group: { _id: null,  total: { $sum: "$t" } } },
                filter = (params.Filter !== undefined) ? {$match : { g : params.Filter}} : {$match : {}};
            EntityCache.MetricsComment.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                callback(null, {TotalComments :  (data[0] && data[0].total) ? data[0].total : 0});
            });
        };

        this.GetTotalCoachingGiven = function (params, callback) {
            var group = { $group: { _id: null,  total: { $sum: "$t" } } },
                filter = (params.Filter) ? {$match : { g : params.Filter}} : {$match : {}};
            EntityCache.MetricsCoaching.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                callback(null, {TotalCoachingGiven :  (data[0] && data[0].total) ? data[0].total : 0});
            });
        };

        this.GetUniqueUserCountByModule = function (moduleType, params, callback) {
            var dataRecords = {},
                filter = getQueryFilter({
                    EntityId : params.EntityId,
                    StartDate : params.StartDate,
                    EndDate : params.EndDate,
                    MemberCategory : params.ActivityCategories
                }),
                group = { $group: { _id: { year: { '$year' : '$p'}, month: { '$month' : '$p'}}, m : { '$addToSet' : "$m" }}};
            EntityCache.MetricsMember.aggregate([filter, group], function (error, data) {
                if (error) { return callback(error); }
                if (!data || data.length === 0) { return callback(null, dataRecords); }
                getOnlyActiveMembers(data, function (error, data) {
                    if (error) { return callback(error); }
                    data.forEach(function (item) {
                        if (!dataRecords[moduleType + '.' + item._id.year  + '.' + item._id.month]) {
                            dataRecords[moduleType + '.' + item._id.year  + '.' + item._id.month] = item.m.length;
                        }
                    });
                    callback(null, dataRecords);
                });
            });
        };
        this.GetFeedbackActivity = function (params, callback) {
            var aggregateParams = MetricsHelper.buildActivityAggregatedParam(params);
            if (params.ActivityType) {
                aggregateParams.Query.x = params.ActivityType;
            }
            if (params.CycleType) {
                aggregateParams.Query.ty = params.CycleType;
            }
            EntityCache.MetricsFeedbackActivity.aggregate([
                {$match: aggregateParams.Query},
                {$project: aggregateParams.FirstProject},
                {$group: aggregateParams.Group},
                {$project: aggregateParams.SecondProject},
                {$sort: aggregateParams.Sort}
            ], function (error, data) {
                if (error) {
                    return callback('metrics.prc.elf');
                }
                params.Result = data;
                return MetricsHelper.formatActivityResult(params, callback);
            });
        };
        this.GetFeedbackActivityByType = function (params, callback) {
            var query = {
                g: params.GroupId,
                x: FeedbackEnums.FeedbackActivityType.Completed,
                c: {$in: params.CycleIds},
                p: {
                    $gte: new Date(params.StartDate),
                    $lt: new Date(params.EndDate)
                }
            },
                dataRecords = {},
                group = {
                    _id: "$c",
                    count: {$sum: "$t"}
                };
            if (params.DepartmentId) {
                group._id = {
                    c: "$c",
                    d: "$d"
                };
            }
            EntityCache.MetricsFeedbackActivity.aggregate([
                {$match: query},
                {$group: group}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    if (params.DepartmentId) {
                        dataRecords[item._id.c + '.' + item._id.d] = item.count;
                    } else {
                        dataRecords[item._id] = item.count;
                    }
                });
                callback(null, dataRecords);
            });
        };
        this.GetGoalActivity = function (params, callback) {
            var aggregateParams = MetricsHelper.buildActivityAggregatedParam(params);
            EntityCache.MetricsGoalActivity.aggregate([
                {$match: aggregateParams.Query},
                {$project: aggregateParams.FirstProject},
                {$group: aggregateParams.Group},
                {$project: aggregateParams.SecondProject},
                {$sort: aggregateParams.Sort}
            ], function (error, data) {
                if (error) {
                    return callback('metrics.prc.elg');
                }
                params.Result = data;
                return MetricsHelper.formatActivityResult(params, callback);
            });
        };
        this.GeUnfilledRequestUserCount = function (params, callback) {
            var  query = {
                g: params.GroupId,
                x: {
                    $in: [
                        FeedbackEnums.SessionStatus.Declined,
                        FeedbackEnums.SessionStatus.Expired
                    ]
                },
                p: {$gte: new Date(Date.now() - ConstantEnums.NINETY_DAYS)}
            };
            if (params.CycleId) {
                query.c = params.CycleId;
            }
            if (params.DepartmentId) {
                query.d = params.DepartmentId;
            }
            if (params.LocationId) {
                query.l = params.LocationId;
            }
            if (params.LevelId) {
                query.r = params.LevelId;
            }
            EntityCache.MetricsFeedbackActivity.aggregate([
                {$match: query},
                {$group: {
                    _id: "$m"
                }}
            ], function (error, data) {
                callback(error, data.length);
            });
        };
        this.GeUnfilledRequestUserDetails = function (params, callback) {
            var query = {
                g: params.GroupId,
                x: {
                    $in: [
                        FeedbackEnums.FeedbackActivityType.Received,
                        FeedbackEnums.FeedbackActivityType.Declined,
                        FeedbackEnums.FeedbackActivityType.Expired
                    ]
                },
                p: {$gte: new Date(Date.now() - ConstantEnums.NINETY_DAYS)}
            };
            if (params.CycleId) {
                query.c = params.CycleId;
            }
            if (params.DepartmentId) {
                query.d = params.DepartmentId;
            }
            if (params.LocationId) {
                query.l = params.LocationId;
            }
            if (params.LevelId) {
                query.r = params.LevelId;
            }
            EntityCache.MetricsFeedbackActivity.aggregate([
                {$match: query},
                {$group: {
                    _id: {
                        m: "$m",
                        mn: "$mn",
                        dn: "$dn",
                        x: "$x"
                    },
                    count: {$sum: "$t"}
                }},
                {$project: {
                    _id: 0,
                    data: "$data",
                    hgId: "$_id.m",
                    Name: "$_id.mn",
                    DepartmentName: "$_id.dn",
                    Received: {$cond: { if: { $eq: [ "$_id.x", 'Received' ] }, then: "$count", else: 0 }},
                    Declined: {$cond: { if: { $eq: [ "$_id.x", 'Declined' ] }, then: "$count", else: 0 }},
                    Expired: {$cond: { if: { $eq: [ "$_id.x", 'Expired' ] }, then: "$count", else: 0 }}
                }},
                {$group: {
                    _id: {
                        hgId: "$hgId",
                        Name: "$Name"
                    },
                    detail: {$push: {
                        Name: "$Name",
                        DepartmentName: "$DepartmentName",
                        Received: "$Received",
                        Expired: "$Expired",
                        Declined: "$Declined"
                    }}
                }},
                {$match: {
                    $or: [{'detail.Declined': {$gt: 0}}, {'detail.Expired': {$gt: 0}}]
                }},
                {$sort: {'detail.Declined': -1, 'detail.Expired': -1, 'detail.Received': -1}},
                {$skip: parseInt(params.Skip, 10) || 0},
                {$limit: parseInt(params.Take, 10) || 10}
            ], callback);
        };
        this.GetFeedbackRoleModels = function (params, callback) {
            var query = {
                g: params.GroupId,
                p: {$gte: new Date(Date.now() - ConstantEnums.NINETY_DAYS)}
            }, aggregateParams = [];
            if (params.CycleId) {
                query.c = params.CycleId;
            }
            if (params.DepartmentId) {
                query.d = params.DepartmentId;
            }
            if (params.LevelId) {
                query.r = params.LevelId;
            }
            if (params.LocationId) {
                query.l = params.LocationId;
            }
            aggregateParams = [
                {$match: query},
                {$match: {t: {$exists: true}}},
                {$group: {
                    _id: {
                        hgId: "$m",
                        Name: "$mn",
                        DepartmentName: "$dn"
                    },
                    avg: {$avg: "$t"},
                    count: {$sum: 1}
                }},
                {$project: {
                    _id: 0,
                    hgId: "$_id.hgId",
                    Name: "$_id.Name",
                    DepartmentName: "$_id.DepartmentName",
                    Avg: "$avg",
                    GivenCount: "$count",
                    RoleScore: {$multiply: ["$avg", "$count"]},
                    Helpfullness: {$divide: [
                        {$multiply: ["$avg", "$count"]},
                        {$multiply: ["$count", 100]}
                    ]}
                }},
                {$sort: {RoleScore: -1}}
            ];
            if (params.Take) {
                aggregateParams.push({$skip: parseInt(params.Skip, 10) || 0});
                aggregateParams.push({$limit: parseInt(params.Take, 10) || 10});
            }
            EntityCache.MetricsFeedbackRoleModel.aggregate(aggregateParams, callback);
        };

/*!
 *
 * Public Write Methods
 *
 */
        this.SaveFeedbackActivityMetric = function (params) {
            var query = {
                p: DateHelper.getJustDate(),
                g: params.GroupId,
                m: params.MemberId,
                d: params.DepartmentId,
                r: params.Role,
                l: params.LocationId,
                x: params.FeedbackActivityType,
                mn: params.FullName,
                dn: params.DepartmentName,
                ty: params.CycleType
            };
            if (params.CycleId) {
                query.c = params.CycleId;
            }
            EntityCache.MetricsFeedbackActivity.update(query, {$inc: {t: 1}}, {upsert: true}).exec();
        };
        this.SaveFeedbackRoleModel = function (params) {
            var subjectRatingMap = {
                    NotHelful: 0,
                    Helpful: 50,
                    ExtremelyHelpful: 100
                },
                data = {
                    p: DateHelper.getJustDate(),
                    g: params.GroupId,
                    ty: params.CycleType,
                    m: params.MemberId,
                    mn: params.FullName,
                    dn: params.DepartmentName,
                    d: params.DepartmentId,
                    r: params.Role,
                    l: params.LocationId,
                    t: subjectRatingMap[params.RatingScale]
                };
            if (params.CycleId) {
                data.c = params.CycleId;
            }
            EntityCache.MetricsFeedbackRoleModel.create(data);
        };
        this.SaveTalentInsigtsStats = function (params) {
            EntityCache.MetricsTalentInsight.findOne({
                g: params.g,
                m: params.m,
                c: params.c,
                mg: params.mg
            }, function (error, data) {
                if (error) {
                    HgLog.error(error);
                    return;
                }
                if (!data) {
                    data = new EntityCache.MetricsTalentInsight(params);
                } else {
                    data.Replaceable = params.Replaceable;
                    data.Performance = params.Performance;
                    data.FlightRisk = params.FlightRisk;
                    data.Promotable = params.Promotable;
                    data.KeyToSuccess = params.KeyToSuccess;
                    data.Potential = params.Potential;
                    data.Capacity = params.Capacity;
                    data.Scarcity = params.Scarcity;
                    data.Speed = params.Speed;
                }
                data.save();
            });
        };
        this.GetManagerInsightStatsByCycleId = function (params, callback) {
            EntityCache.MetricsTalentInsight.find({
                c: params.CycleId,
                g: params.GroupId,
                mg: params.MemberId
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data.length ? data.map(function (item) {
                    return item.toObject();
                }) : []);
            });
        };
        this.SaveGoalUpdateMetric = function (params) {
            var query = {
                p: DateHelper.getJustDate(),
                g: params.GroupId,
                m: params.MemberId,
                d: params.DepartmentId,
                s: params.Source
            };
            if (params.CycleId) {
                query.c = params.CycleId;
            }
            EntityCache.MetricsGoalActivity.update(query, {$inc: {t: 1}}, {upsert: true}).exec();
        };

        this.PreAllocate = function (params, callback) {
            var r = new EntityCache.MetricsRecognitionDaily({
                p : params.p,
                gId : params.GroupId
            });
            r.save(callback);
        };

        this.SaveNewsActivityMetric = function (params) {
            saveNewsActivity({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId
            });
            saveMemberMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                Category : params.Category,
                UpdateValue : 1
            });
        };

        this.SaveMemberActivityMetric = function (params) {
            saveMemberMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                Category : params.MemberCategoryActivity,
                UpdateValue : 1
            });
        };

        this.SavePerformActivityMetric = function (params) {
            savePerformActivity({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                PerformActivity : params.PerformActivity
            });
            saveMemberMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                Category : params.PerformActivity,
                UpdateValue : 1
            });
        };

        this.SaveCommentMetric = function (params) {
            saveCommentMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                EntityType : params.EntityType,
                UpdateValue : 1,
                CommentSource : params.CommentSource
            });
            saveMemberMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                Category : Enums.MetricsMemberCategory.CommentsMade,
                UpdateValue : 1
            });
        };

        this.SaveArchivedPerformMetric = function (params) {
            var reviews;
            function logDeletedByMember(review) {
                saveMemberMetric({
                    Date : DateHelper.getJustDate(),
                    GroupId : params.GroupId,
                    MemberId : params.MemberId,
                    Category : Enums.MetricsMemberCategory.DeletedReview,
                    UpdateValue : 1
                });
            }
            Async.each(params.Reviews, saveOneArchivedReviewMetric, function (error) {
                if (error) {
                    HgLog.error({methodName: 'saveOneArchivedReviewMetric', error: error});
                }
            });
            if (params.Reviews.length === 1) {
                logDeletedByMember(params.Reviews[0]);
            } else {
                reviews = params.Reviews.filter(function (item) {
                    return item.StatusByAdminView !== PerformEnums.ReviewStatus.Archived;
                });
                Async.each(reviews, logDeletedByMember, function (error) {
                    if (error) {
                        HgLog.error({methodName: 'logDeletedByMember', error: error});
                    }
                });
            }
        };

        this.SaveUnSubmitReviewMetric = function (params) {
            var firstOccurance,
                groupId = params.GroupId,
                review = params.Review;
            if (!review) {
                return;
            }
            saveMemberMetric({
                Date: DateHelper.getJustDate(),
                GroupId: groupId,
                MemberId: params.MemberId,
                Category: Enums.MetricsMemberCategory.UnsubmitReview,
                UpdateValue: 1
            });
            savePerformActivity({
                Date : DateHelper.getJustDate(),
                GroupId : groupId,
                PerformActivity : Enums.MetricsPerformCategory.UnsubmitReview
            });
            firstOccurance = review.Peoples.filter(function (item) {
                return item.StatusInCurrentReview === PerformEnums.ReviewStatus.Submitted;
            });
            if (firstOccurance && firstOccurance[0]) {
                review.Peoples.forEach(function (item) {
                    if (item.PeopleType === PerformEnums.DefaultPeopleTypes.Subject) {
                        getMemberDepartment({MemberId: item.MemberId}, function (error, memberDepartment) {
                            savePerform({
                                Date : DateHelper.getJustDate(review.ModifiedDate),
                                ReviewStatus : PerformEnums.ReviewStatus.Submitted,
                                GroupId : groupId,
                                Source : 'Web',
                                UpdateValue : -1
                            });
                            saveMemberMetric({
                                Date: DateHelper.getJustDate(review.ModifiedDate),
                                GroupId: groupId,
                                MemberId: item.MemberId,
                                Category: 'Reviewed',
                                UpdateValue: -1
                            });
                            saveDepartmentMetric({
                                Department: (memberDepartment.GroupDepartmentName !== undefined && memberDepartment.GroupDepartmentName !== '') ? memberDepartment.GroupDepartmentName : 'Other',
                                Date: DateHelper.getJustDate(review.ModifiedDate),
                                Category: 'Reviewed',
                                GroupId: groupId,
                                UpdateValue: -1,
                                Source : 'Web',
                            });
                            saveMemberMetric({
                                Date: DateHelper.getJustDate(review.ModifiedDate),
                                GroupId: groupId,
                                MemberId: item.MemberId,
                                Category: 'SubmittedReview',
                                UpdateValue: -1
                            });
                        });
                    } else if (item.PeopleType === PerformEnums.DefaultPeopleTypes.Manager) {
                        saveMemberMetric({
                            Date: DateHelper.getJustDate(review.ModifiedDate),
                            GroupId: groupId,
                            MemberId: item.MemberId,
                            Category: 'SubmittedReviewAsManager',
                            UpdateValue: -1
                        });
                    } else {
                        saveMemberMetric({
                            Date: DateHelper.getJustDate(review.ModifiedDate),
                            GroupId: groupId,
                            MemberId: item.MemberId,
                            Category: 'SubmittedReviewAs' + item.PeopleType,
                            UpdateValue: -1
                        });
                    }
                });
            }
        };

        this.SavePerformMetric = function (params) {
            Async.each(params.Reviews, saveOneReviewMetric, function (error) {
                HgLog.error('Error occored saving performance review', error);
            });
        };

        this.SaveMemberActivity = function (params) {
            var today = DateHelper.getJustDate();
            saveMemberMetric({
                Date : today,
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                Category : params.Category,
                UpdateValue : 1
            });
        };

        this.SaveCoachingMetric = function (params) {
            if (params.CoachingNote.Status === 'Active') {
                saveCoaching({
                    Date : DateHelper.getJustDate(params.CoachingNote.CreatedDate),
                    GroupId : params.GroupId,
                    Source : params.CoachingNote.Source,
                    UpdateValue : 1
                });
                //Coaching Recieved
                saveMemberMetric({
                    Date : DateHelper.getJustDate(params.CoachingNote.CreatedDate),
                    GroupId : params.GroupId,
                    MemberId : params.CoachingNote.Recipient.MemberId,
                    Category : Enums.MetricsMemberCategory.CoachingReceived,
                    UpdateValue : 1
                });
                //Coaching Department
                saveDepartmentMetric({
                    Department : (params.Member.GroupDepartmentName !== '' && params.Member.GroupDepartmentName !== undefined) ? params.Member.GroupDepartmentName : 'Other',
                    Date : DateHelper.getJustDate(params.CoachingNote.CreatedDate),
                    Category : Enums.MetricsDepartmentCategory.CoachingGiven,
                    GroupId : params.GroupId,
                    UpdateValue : 1,
                    Source : params.CoachingNote.Source
                });
            }
            // Save member coaching note type
            saveMemberMetric({
                Date : DateHelper.getJustDate(params.CoachingNote.CreatedDate),
                GroupId : params.GroupId,
                MemberId : params.CoachingNote.MemberId,
                Category : 'Coaching' + getNoteCategory(params.CoachingNote),
                UpdateValue : 1
            });
            //note category
            saveCoachingCategory({
                Date : DateHelper.getJustDate(params.CoachingNote.CreatedDate),
                GroupId : params.GroupId,
                Category : getNoteCategory(params.CoachingNote),
                Source : params.CoachingNote.Source,
                UpdateValue : 1
            });
        };

        this.SaveCongratMetric = function (params) {
            var getMemberCategory = function (cat) {
                var value;
                if (cat === 'Recognition') {
                    value = 'CongratsGiven';
                } else if (cat === 'Comment') {
                    value = 'CommentsCongratsGiven';
                } else {
                    value = 'NewsCongratsGiven';
                }
                return value;
            };
            saveCongratMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                UpdateValue : 1,
                CongratSource : params.Source || 'Web',
                Category : params.Category
            });
            saveMemberMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                Category : getMemberCategory(params.Category),
                UpdateValue : 1
            });
        };
        this.SaveShareMetric = function (params) {
            var query = {p : DateHelper.getJustDate(), g : params.GroupId, c : params.ShareType, s : params.Source},
                options = {upsert: true},
                update = {$inc : { t : 1}};
            EntityCache.MetricsRecognitionShare.update(query, update, options).exec();
            saveMemberMetric({
                Date : DateHelper.getJustDate(),
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                Category : Enums.MetricsMemberCategory.LinkedInShares,
                UpdateValue : 1
            });
        };
        this.SaveRecognitionMetric = function (params) {
            Async.each(params.Recognitions, addOneRecognitionMetric, function (error) {
                HgLog.error('Error occured saving recognition metric', error);
            });
        };
        this.SaveTrackActivityMetric = function (params) {
            var today = DateHelper.getJustDate();
            saveTrackMetric({ Date : today, GroupId : params.GroupId, Category : params.TrackCategoryType});
            saveMemberMetric({Date : today, GroupId : params.GroupId, MemberId : params.MemberId, Category : params.TrackMemberCategoryType, UpdateValue : 1});
        };
        this.SaveDelegatedTrackMetric = function (params) {
            var today = DateHelper.getJustDate();

            saveTrackMetric({ Date : today, GroupId : params.GroupId, Category : params.TrackCategoryType});
            saveMemberMetric({Date : today, GroupId : params.GroupId, MemberId : params.AssignedMember.hgId, Category : params.TrackMemberCategoryType, UpdateValue : 1});
            decreaseMemberAssignedTrackMetric({
                Date : DateHelper.getJustDate(params.TrackCreatedDate),
                GroupId : params.GroupId,
                MemberId : params.OriginalAssignedMember.hgId,
                Category : params.TrackMemberCategoryType
            });
        };
        this.SaveGenericTrackMetric = function (params) {
            var today = DateHelper.getJustDate(),
                departmentName = params.Track.CreatorMember.GroupDepartmentName,
                assignedMemberId = params.Track.AssignedMember.hgId;
            saveTrackMetric({ Date : today, GroupId : params.GroupId, Category : params.TrackCategoryType});
            saveMemberMetric({Date : today, GroupId : params.GroupId, MemberId : assignedMemberId, Category : params.TrackMemberCategoryType, UpdateValue : 1});
            saveDepartmentMetric({
                Department : (departmentName === '' || departmentName === null || departmentName === undefined) ? 'Other' : departmentName,
                Date : today,
                GroupId : params.GroupId,
                Category : params.TrackDepartmentCategoryType,
                Source : 'Web',
                UpdateValue : 1
            });
        };

        this.SaveFeedBackMetric = function (params) {
            function saveOneFeedBackMetric(feedBack) {
                saveFeedback({
                    Date : DateHelper.getJustDate(),
                    GroupId : feedBack.GroupId,
                    Category : feedBack.FeedBackType,
                    Source : feedBack.Source,
                    UpdateValue : 1
                });
                if (feedBack.FeedBackType === Enums.FeedBackType.Given) {
                    saveMemberMetric({
                        Date : DateHelper.getJustDate(),
                        GroupId : feedBack.GroupId,
                        MemberId : feedBack.Creator.MemberId,
                        Category : 'GaveFeedBack',
                        UpdateValue : 1
                    });
                    saveMemberMetric({
                        Date : DateHelper.getJustDate(),
                        GroupId : feedBack.GroupId,
                        MemberId : feedBack.Recipient.MemberId,
                        Category : 'ReceivedFeedBack',
                        UpdateValue : 1
                    });
                } else if (feedBack.FeedBackType === Enums.FeedBackType.Requested) {
                    saveMemberMetric({
                        Date : DateHelper.getJustDate(),
                        GroupId : feedBack.GroupId,
                        MemberId : feedBack.Creator.MemberId,
                        Category : 'IRequestedFeedBack',
                        UpdateValue : 1
                    });
                    saveMemberMetric({
                        Date : DateHelper.getJustDate(),
                        GroupId : feedBack.GroupId,
                        MemberId : feedBack.Recipient.MemberId,
                        Category : 'WasRequestedForFeedBack',
                        UpdateValue : 1
                    });
                }
            }
            Async.each(params.FeedBack, saveOneFeedBackMetric, function (error) {
                if (error) {
                    HgLog.error({methodName: 'saveOneFeedBackMetric', error: error});
                }
            });
        };

        this.SaveCreatedTrackMetric = function (params) {
            var today = DateHelper.getJustDate();
            function saveOneTrackMetric(track, callback) {
                var departmentName = track.CreatorMember.GroupDepartmentName,
                    creatorMemberId = track.CreatorMember.hgId,
                    assignedMemberId = track.AssignedMember.hgId;
                saveTrackMetric({Date : today, GroupId : params.GroupId, Category : 'Created'});
                saveMemberMetric({Date : today, GroupId : params.GroupId, MemberId : creatorMemberId, Category : 'TracksCreated', UpdateValue : 1});
                saveMemberMetric({Date : today, GroupId : params.GroupId, MemberId : assignedMemberId, Category : 'TracksAssigned', UpdateValue : 1});
                saveDepartmentMetric({
                    Department : (departmentName === '' || departmentName === null || departmentName === undefined) ? 'Other' : departmentName,
                    Date : today,
                    GroupId : params.GroupId,
                    Category : Enums.MetricsDepartmentCategory.TracksCreated,
                    Source : 'Web',
                    UpdateValue : 1
                });
            }
            Async.each(params.Tracks, saveOneTrackMetric, function (error) {
                if (error) {
                    HgLog.error('Error saving track metric', error);
                }
            });
        };

        this.DeleteCongratMetric = function (params) {
            function deleteOneCongratMetric(congrat, callback) {
                saveCongratMetric({
                    Date : DateHelper.getJustDate(congrat.CreatedDate),
                    GroupId : congrat.GroupId,
                    UpdateValue : -1,
                    CongratSource : congrat.Source
                });
                saveMemberMetric({
                    Date : DateHelper.getJustDate(congrat.CreatedDate),
                    GroupId : params.GroupId,
                    MemberId : congrat.MemberId,
                    Category : Enums.MetricsMemberCategory.CongratsGiven,
                    UpdateValue : -1
                });
                saveMemberMetric({
                    Date : DateHelper.getJustDate(congrat.CreatedDate),
                    GroupId : params.GroupId,
                    MemberId : params.MemberId,
                    Category : Enums.MetricsMemberCategory.CongratsDeleted,
                    UpdateValue : 1
                });
            }
            Async.each(params.Congrats, deleteOneCongratMetric, function (error) {
                if (error) {
                    HgLog.error('Error deleting congrat metric', error);
                }
            });
        };

        this.DeleteCoachingMetric = function (params) {
            function deleteOneCoachingMetric(coachingNote, callback) {
                if (coachingNote.Status === 'Active') {
                    saveCoaching({
                        Date : DateHelper.getJustDate(coachingNote.CreatedDate),
                        GroupId : params.GroupId,
                        Source : coachingNote.Source,
                        UpdateValue : -1
                    });
                    //Coaching Recieved
                    saveMemberMetric({
                        Date : DateHelper.getJustDate(coachingNote.CreatedDate),
                        GroupId : params.GroupId,
                        MemberId : coachingNote.Recipient.MemberId,
                        Category : Enums.MetricsMemberCategory.CoachingReceived,
                        UpdateValue : -1
                    });
                    //Coaching Department
                    saveDepartmentMetric({
                        Department :  params.Department || 'Other',
                        Date : DateHelper.getJustDate(coachingNote.CreatedDate),
                        Category : Enums.MetricsDepartmentCategory.CoachingGiven,
                        GroupId : params.GroupId,
                        UpdateValue : -1,
                        Source : coachingNote.Source
                    });
                }
                // Save member coaching note type
                saveMemberMetric({
                    Date : DateHelper.getJustDate(coachingNote.CreatedDate),
                    GroupId : params.GroupId,
                    MemberId : coachingNote.MemberId,
                    Category : 'Coaching' + getNoteCategory(coachingNote),
                    UpdateValue : -1
                });
                //note category
                saveCoachingCategory({
                    Date : DateHelper.getJustDate(coachingNote.CreatedDate),
                    GroupId : params.GroupId,
                    Category : getNoteCategory(coachingNote),
                    Source : coachingNote.Source,
                    UpdateValue : -1
                });
            }
            Async.each(params.CoachingNotes, deleteOneCoachingMetric, function (error) {
                if (error) {
                    HgLog.error({methodName: 'deleteOneCoachingMetric', error: error});
                }
            });
        };

        this.DeleteCommentMetric = function (params) {
            function deleteOneCommentMetric(comment, callback) {
                saveCommentMetric({
                    Date : DateHelper.getJustDate(comment.CreatedDate),
                    GroupId : comment.GroupId,
                    EntityType : comment.EntityType,
                    UpdateValue : -1,
                    CommentSource : comment.Source
                });
                saveMemberMetric({
                    Date : DateHelper.getJustDate(comment.CreatedDate),
                    GroupId : params.GroupId,
                    MemberId : comment.MemberId,
                    Category : Enums.MetricsMemberCategory.CommentsMade,
                    UpdateValue : -1
                });
                saveMemberMetric({
                    Date : DateHelper.getJustDate(comment.CreatedDate),
                    GroupId : params.GroupId,
                    MemberId : params.MemberId,
                    Category : Enums.MetricsMemberCategory.CommentsDeleted,
                    UpdateValue : 1
                });
            }
            Async.each(params.Comments, deleteOneCommentMetric, function (error) {
                if (error) {
                    HgLog.error('Error deleting comment metric', error);
                }
            });
        };

        this.DeleteRecognitionMetric = function (params) {
            function logDeletedByMember(recognition) {
                saveMemberMetric({
                    Date : DateHelper.getJustDate(),
                    GroupId : params.GroupId,
                    MemberId : params.MemberId,
                    Category : Enums.MetricsMemberCategory.RecognitionDeleted,
                    UpdateValue : 1
                });
            }
            Async.each(params.Recognitions, subOneRecognitionMetric, function (error) {
                if (error) {
                    HgLog.error({methodName: 'DeleteRecognitionMetric.subOneRecognitionMetric', error: error});
                }
            });
            Async.each(params.Recognitions, logDeletedByMember, function (error) {
                if (error) {
                    HgLog.error({methodName: 'DeleteRecognitionMetric.logDeletedByMember', error: error});
                }
            });
        };

        //One time migration Script for FeedBack
        this.MigrateFeedBack = function (params, callback) {
            EntityCache.Conversation.find({}, function (error, data) {
                if (error) {
                    callback(error);
                } else {
                    self.SaveFeedBackMetric({FeedBack : data});
                    callback(null, 'done');
                }
            });
        };

        this.GetRecognitionReceivedByMemberIds = function (params, callback) {
            var memberRecognitionIndex = {};
            EntityCache.MetricsMember.aggregate([
                {$match: {
                    c: Enums.MetricsMemberCategory.RecognitionReceived,
                    g: params.GroupId,
                    m: {$in: params.MemberIds},
                    p: {$gte: params.StartDate}
                }},
                {$group: {
                    _id: "$m",
                    recognitionReceived: {$sum: "$t"}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    memberRecognitionIndex[item._id] = item.recognitionReceived;
                });
                callback(null, memberRecognitionIndex);
            });
        };

        this.GetRecognitionGivenByMemberIds = function (params, callback) {
            var memberRecognitionIndex = {};
            EntityCache.MetricsMember.aggregate([
                {$match: {
                    c: Enums.MetricsMemberCategory.RecognitionGiven,
                    g: params.GroupId,
                    m: {$in: params.MemberIds},
                    p: {$gte: params.StartDate}
                }},
                {$group: {
                    _id: "$m",
                    recognitionGiven: {$sum: "$t"}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    memberRecognitionIndex[item._id] = item.recognitionGiven;
                });
                callback(null, memberRecognitionIndex);
            });
        };
    };

module.exports = MetricsProcessor;
