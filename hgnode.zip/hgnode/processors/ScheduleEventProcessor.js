/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ScheduleEventProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            HgError = require('../common/HgError.js'),
            HgLog = require('../framework/HgLog'),
            queryByDateAndMonth = function (key, date, month) {
                return {
                    "$where": "var d = new Date(this." + key + "); return d.getUTCDate() === " + date + " && d.getUTCMonth() === " + month
                };
            };

        this.RemoveScheduleEvents = function (params) {
            var today = new Date(),
                yesterday = new Date(+today - 24 * 60 * 60 * 1000),
                queryYesterday = queryByDateAndMonth('ScheduleDate', yesterday.getDate(), yesterday.getMonth());
            EntityCache.ScheduleEvent.remove(queryYesterday, function (err) {
                if (err) {
                    HgLog.error({methodName: 'RemoveScheduleEvents', error: err});
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Worker.ClearScheduleEventFailed));
                }
            });
        };
    };

module.exports = ScheduleEventProcessor;
