/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js');
module.exports = function () {
    'use strict';
    HgBaseProcessor.apply(this, arguments);

    var EntityCache = require('../framework/EntityCache.js'),
        guid = require('node-uuid');

    function createTag(params, callback) {
        var tag = new EntityCache.TaggedUser({
            hgId: guid.v1(),
            UserId: params.UserId,
            CreatedBy: params.UserId,
            Tags: params.Tags
        });
        tag.save(callback);
    }
    this.GetTags = function (params, callback) {
        EntityCache.TaggedUser.find({_id: {$in: params.ids}}, callback);
    };
    this.CreateTag = createTag;

    this.GetTag = function (params, callback) {
        EntityCache.TaggedUser.findOne({_id: params.id}, callback);
    };
    this.UpdateTag = function (params, callback) {
        if (!params.Tags.length) {
            EntityCache.TaggedUser.remove({_id: params.id}, function (error) {
                callback(error);
            });
        } else {
            EntityCache.TaggedUser.findOne({_id: params.id}, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!data) {
                    createTag({UserId: params.ModifiedBy, Tags: params.Tags}, callback);
                } else {
                    data.Tags = params.Tags;
                    data.ModifiedBy = params.ModifiedBy;
                    data.save(callback);
                }
            });
        }
    };
};
