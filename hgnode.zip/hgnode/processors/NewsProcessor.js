/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    NewsProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid'),
            config = require('../configurations/config.js'),
            changeProtocol = function (msg) {
                if (config.protocol === 'http:') {
                    msg = msg.replace(/https:/g, config.protocol);
                } else {
                    msg = msg.replace(/http:/g, config.protocol);
                }
                return msg;
            };

        this.PostNews = function (params, callback) {
            var news = EntityCache.News(params);
            news.hgId = guid.v1();
            news.CreatedBy = params.UserId;
            news.ModifiedBy = params.UserId;
            news.Body = changeProtocol(news.Body);
            news.save(callback);
        };

        this.UpdateNews = function (params, callback) {
            EntityCache.News.findOne({hgId: params.NewsId}, function (error, news) {
                if (error) {
                    callback(error);
                } else if (!news) {
                    callback('news.err.nfd');
                } else {
                    news.Title = params.Title;
                    news.Body = changeProtocol(params.Body);
                    news.ModifiedBy = params.UserId;
                    news.Status = params.Status;
                    news.save(callback);
                }
            });
        };

        this.GetNewsById = function (params, callback) {
            EntityCache.News.findOne({hgId: params.NewsId}, callback);
        };

        this.DeleteNewsById = function (params, callback) {
            EntityCache.News.findOne({hgId: params.NewsId, GroupId: params.GroupId}, function (error, news) {
                if (error) {
                    callback(error);
                } else if (!news) {
                    callback('news.err.nfd');
                } else {
                    news.ModifiedBy = params.UserId;
                    news.Status = 'Deleted';
                    news.save(callback);
                }
            });
        };

        this.GetNewsByGroupId = function (params, callback) {
            var query = {GroupId: params.GroupId};
            if (params.Status) {
                query.Status = {$in : params.Status};
            }
            EntityCache.News.find(query, null, {
                skip: parseInt(params.skip, 10) || 0,
                limit: parseInt(params.take, 10) || 0,
                sort: {
                    ModifiedDate : -1
                }
            }, callback);
        };
    };

module.exports = NewsProcessor;
