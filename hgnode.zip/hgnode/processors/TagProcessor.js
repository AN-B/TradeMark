/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    TagProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid'),
            Async = require('async'),
            self = this;

        this.GetTagsByEntityType = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    'Entity.Name': params.TagEntityType,
                    Archived: false
                };
            if (params.SearchTerm) {
                condition.Name = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.Tag.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetTagById = function (params, callback) {
            EntityCache.Tag.findOne({hgId: params.TagId}, callback);
        };

        this.GetGlobalTagsByEntityType = function (params, callback) {
            EntityCache.Tag.find({
                'Entity.Name': params.TagEntityType,
                Global: true,
                Archived: false
            }, callback);
        };

        this.GetAllGlobalTags = function (params, callback) {
            EntityCache.Tag.find({
                Global: true,
                Archived: false
            }, callback);
        };

        this.SaveGlobalTags = function (params, callback) {
            var updateOneTag = function (update, asyncCallback) {
                EntityCache.Tag.update({
                    hgId: update.TagId
                }, {
                    $set: {
                        Name: update.NewName,
                        ModifiedBy: params.UserId
                    }
                }, asyncCallback);
            };
            EntityCache.Tag.find({
                'Entity.Name': params.TagEntityType,
                Global: true,
                Archived: false
            }, function (error, existingTags) {
                if (error) {
                    return callback(error);
                }
                var tagIdsToBeRemoved = existingTags.filter(function (existingTag) {
                        return !params.Tags.some(function (payloadTag) {
                            return payloadTag.hgId === existingTag.hgId;
                        });
                    }).map(function (tag) {
                        return tag.hgId;
                    }),
                    newTags = params.Tags.filter(function (tag) {
                        return !tag.hgId;
                    }).map(function (tag) {
                        return {
                            hgId: guid.v1(),
                            Name: tag.Name,
                            CreatedBy: params.UserId,
                            ModifiedBy: params.UserId,
                            Entity: [{
                                Name: params.TagEntityType
                            }],
                            Global: true
                        };
                    }),
                    updates = existingTags.filter(function (existingTag) {
                        return params.Tags.some(function (payloadTag) {
                            return payloadTag.hgId === existingTag.hgId && existingTag.Name !== payloadTag.Name;
                        });
                    }).map(function (existingTag) {
                        var matching = params.Tags.filter(function (payloadTag) {
                            return payloadTag.hgId === existingTag.hgId && existingTag.Name !== payloadTag.Name;
                        });
                        return {
                            TagId: existingTag.hgId,
                            NewName: matching[0].Name
                        };
                    });
                EntityCache.Tag.update({
                    hgId: {$in: tagIdsToBeRemoved}
                }, {
                    $set: {
                        Archived: true,
                        ModifiedBy: params.UserId
                    }
                }, {
                    multi: true
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    EntityCache.Tag.create(newTags, function (error) {
                        if (error) {
                            return callback(error);
                        }
                        Async.each(updates, updateOneTag, function (error) {
                            callback(error, {NewTags: newTags});
                        });
                    });
                });
            });
        };

        this.GetOrCreateTag = function (params, callback) {
            var newTag = new EntityCache.Tag({
                    hgId: guid.v1(),
                    Name: params.TagName,
                    GroupId: params.GroupId,
                    MemberId: params.MemberId,
                    UserId: params.UserId,
                    CreatedBy: params.UserId,
                    ModifiedBy: params.UserId,
                    Entity: [{
                        Name: params.TagEntityType,
                        hgId: params.EntityId
                    }]
                });
            if (!params.TagId) {
                return newTag.save(function (error) {
                    callback(error, newTag);
                });
            }
            EntityCache.Tag.findOne({hgId: params.TagId}, function (error, tag) {
                if (error || !tag) {
                    return newTag.save(function (error) {
                        callback(error, newTag);
                    });
                }
                callback(null, tag);
            });
        };

        this.GetTagByNameEntityTypeGroupId = function (params, callback) {
            EntityCache.Tag.findOne({
                Name: params.TagName,
                GroupId: params.GroupId,
                'Entity.Name': params.TagEntityType
            }, callback);
        };

        this.CreateTag = function (params, callback) {
            var tag = new EntityCache.Tag({
                hgId : guid.v1(),
                Name : params.Tag.Name.trim(),
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                UserId : params.UserId,
                CreatedBy : params.UserId,
                ModifiedBy : params.UserId,
                CreatedDate : Date.now(),
                ModifiedDate : Date.now(),
                Entity : [{
                    Name : params.Tag.EntityName,
                    hgId : params.Tag.EntityId,
                    CreatedDate : Date.now()
                }]
            });
            tag.save(function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {data : 'Tag Saved'});
                }
            });
        };
        this.AddTagEntity = function (params, callback) {
            var i, len, added;
            EntityCache.Tag.findOne({GroupId : params.GroupId, MemberId : params.MemberId, Name : new RegExp(["^", params.Tag.Name.trim(), "$"].join(""), "i")}, function (error, tag) {
                if (error) {
                    callback(error);
                } else {
                    if (tag) {
                        for (i = 0, len = tag.Entity.length; i < len; i += 1) {
                            if (tag.Entity[i].Name === params.Tag.EntityName &&  tag.Entity[i].hgId === params.Tag.EntityId) {
                                added = true;
                                break;
                            }
                        }
                        if (!added) {
                            tag.Entity.push({
                                Name : params.Tag.EntityName,
                                hgId : params.Tag.EntityId,
                                CreatedDate : Date.now()
                            });
                        }
                        tag.save(function (error) {
                            if (error) {
                                callback(error);
                            } else {
                                callback(null, {data : 'Tag Saved'});
                            }
                        });
                    } else {
                        self.CreateTag(params, callback);
                    }
                }
            });
        };
        this.RemoveTag = function (params, callback) {
            EntityCache.Tag.remove({GroupId : params.GroupId, MemberId : params.MemberId, Name : new RegExp(["^", params.Tag.Name.trim(), "$"].join(""), "i")}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {data : 'Tag Removed'});
                }
            });
        };
        this.RemoveTagEntities = function (params, callback) {
            var filter = {
                GroupId : params.GroupId,
                MemberId : params.MemberId,
                'Entity.Name' : params.EntityName,
                'Entity.hgId' : params.EntityId
            };
            function removeTagEntity(tag, callback) {
                var pull = {
                        Entity : {Name : params.EntityName, hgId : params.EntityId }
                    },
                    newParams = {
                        GroupId : params.GroupId,
                        MemberId : params.MemberId,
                        Tag : {
                            Name: tag.Name
                        }
                    };
                filter.Name = tag.Name;
                EntityCache.Tag.findOneAndUpdate(filter, {$pull : pull}, {new: true}, function (error, data) {
                    //delete tag document if there are no more Entity
                    if (data.Entity.length === 0) {
                        self.RemoveTag(newParams, function (error, data) {
                            if (error) {
                                callback(error);
                            }
                        });
                    }
                    callback(null, 'tag.rem');
                });
            }
            EntityCache.Tag.find(filter, function (error, tags) {
                Async.each(tags, removeTagEntity, function (error) {
                    callback(null, 'tag.ter');
                });
            });
        };
        this.RemoveTagEntity = function (params, callback) {
            var i, len;
            EntityCache.Tag.findOne({GroupId : params.GroupId, MemberId : params.MemberId, Name : new RegExp(["^", params.Tag.Name.trim(), "$"].join(""), "i")}, function (error, tag) {
                if (error) {
                    callback(error);
                } else {
                    if (tag) {
                        for (i = 0, len = tag.Entity.length; i < len; i += 1) {
                            if (tag.Entity[i].Name === params.Tag.EntityName && tag.Entity[i].hgId === params.Tag.EntityId) {
                                tag.Entity[i].remove();
                                break;
                            }
                        }
                        if (tag.Entity.length === len) {
                            callback(null, {data : 'Tag was not found'});
                        } else if (tag.Entity.length === 0) {
                            self.RemoveTag(params, function (error, data) {
                                if (error) {
                                    callback(error);
                                } else {
                                    callback(null, data);
                                }
                            });
                        } else {
                            tag.save(function (error) {
                                if (error) {
                                    callback(error);
                                } else {
                                    callback(null, {data : 'Tag Removed'});
                                }
                            });
                        }
                    } else {
                        callback(null, {data : 'Tag Removed'});
                    }
                }
            });
        };
        this.GetTag = function (params, callback) {
            EntityCache.Tag.findOne({GroupId : params.GroupId, MemberId : params.MemberId, Name : new RegExp(["^", params.Tag.Name.trim(), "$"].join(""), "i")}, function (error, tag) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {data : tag});
                }
            });
        };
        //get multiple tag records based on 1 or more tag names
        this.GetTags = function (params, callback) {
            EntityCache.Tag.find({GroupId : params.GroupId, MemberId : params.MemberId, Name : {$in: params.Tags}}, function (error, tags) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {data : tags});
                }
            });
        };
        //get all the tags for a member within a group, regardless of Entity Name
        this.GetMemberTags = function (params, callback) {
            EntityCache.Tag.find({GroupId : params.GroupId, MemberId : params.MemberId}, function (error, tags) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {data : tags});
                }
            });
        };
        //get all the tags for a member within a group, and filter tags based on either an entityId or entity Name
        //results will be all tags for a record or all tags for one entity type (e.g. Track)
        this.GetEntityTags = function (params, callback) {
            var mquery = EntityCache.Tag.find({GroupId : params.GroupId, MemberId : params.MemberId});
            if (params.Tag.EntityId) {
                mquery.where('Entity.hgId', params.Tag.EntityId);
            }
            if (params.Tag.EntityName) {
                mquery.where('Entity.Name', params.Tag.EntityName);
            }
            mquery.exec(function (error, tags) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {data : tags});
                }
            });
        };
        this.GetEntityTagsByEntityIds = function (params, callback) {
            var mquery = EntityCache.Tag.find({GroupId : params.GroupId, MemberId : params.MemberId});
            mquery.where('Entity.hgId', { $in : params.EntityIds});
            mquery.exec(function (error, tags) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {data : tags});
                }
            });
        };
    };

module.exports = TagProcessor;
