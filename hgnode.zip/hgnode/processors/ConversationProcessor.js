/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ConversationProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            Enums = require('../enums/EntityEnums.js'),
            guid = require('node-uuid');

        function getSearchQuery(params) {
            var ret;
            if (params.MemberId === params.currentMemberId) {
                ret = {
                    $or: [
                        {
                            'Creator.MemberId': params.currentMemberId,
                            Status: Enums.ConversationStatus.Active
                        },
                        {
                            'Recipient.MemberId': params.currentMemberId,
                            Status: {
                                $in: [Enums.ConversationStatus.Active, Enums.ConversationStatus.Pending]
                            }
                        }
                    ]
                };
            } else {
                ret = {
                    $or: [
                        {
                            'Creator.MemberId': params.currentMemberId,
                            'Recipient.MemberId': params.MemberId,
                            Status: 'Active'
                        },
                        {
                            'Recipient.MemberId': params.currentMemberId,
                            'Creator.MemberId': params.MemberId,
                            Status: {
                                $in: [Enums.ConversationStatus.Active, Enums.ConversationStatus.Pending]
                            }

                        }
                    ]
                };
            }
            return ret;
        }
        this.Create = function (collection, callback) {
            EntityCache.Conversation.create(collection, function (error, conversations) {
                callback(error, conversations);
            });
        };

        this.Delete = function (params, callback) {
            EntityCache.Conversation.update(
                {BatchId: params.id},
                {$set: {
                    Status: Enums.ConversationStatus.Deleted,
                    ModifiedBy: params.UserId
                }},
                {
                    upsert: false,
                    multi: true
                },
                function (err) {
                    return callback(err);
                }
            );
        };
        this.Get = function (params, callback) {
            var query = getSearchQuery(params);
            query.BatchId =  params.BatchId;
            EntityCache.Conversation.findOne(query, function (err, conversation) {
                if (err) {
                    callback(err);
                } else {
                    if (!conversation) {
                        callback('business.conv.get');
                    } else {
                        callback(null, conversation);
                    }

                }
            });
        };
        this.GetById = function (id, callback) {
            EntityCache.Conversation.findOne({
                hgId : id
            }, function (err, conversation) {
                if (err) {
                    callback(err);
                } else {
                    callback(null, conversation);
                }
            });
        };
        this.FulfillFeedbackRequest = function (params, callback) {
            EntityCache.Conversation.findOneAndUpdate({
                hgId: params.CommentRequest.EntityId
            },  {
                $set: {
                    Status: Enums.ConversationStatus.Archived
                }
            }, {
                new: true
            }, function (err, result) {
                if (err) {
                    return callback(err);
                }
                if (!result) {
                    return callback('business.conv.get');
                }
                //add feedback
                var conversation = new EntityCache.Conversation({
                    BatchId: guid.v1(),
                    hgId: guid.v1(),
                    EntityId: params.CommentRequest.EntityId,
                    GroupId: params.GroupId,
                    FeedBackType: Enums.FeedBackType.Given,
                    ModifiedBy: params.UserId,
                    CreatedBy: params.UserId,
                    CreatedDate: Date.now(),
                    Source: params.CommentRequest.Source,
                    Status: Enums.ConversationStatus.Active,
                    Subject: params.CommentRequest.Comment,
                    Type: Enums.ConversationType.Feedback
                });
                conversation.Recipient = params.Request.Creator;
                conversation.Creator = params.Request.Recipient;
                conversation.save(callback);
            });
        };
        this.GetByUserId = function (params, callback) {
            var regex = new RegExp(params.searchTerm.replace(/([.*?=+&#!:${}()|\[\]\/\\\^\+])/g, "\\$1"), "i"),
                search = getSearchQuery(params),
                query,
                or = '$or';
            search.Type = params.Type;

            if (params.searchTerm) {
                search[or].forEach(function (q) {
                    q[or] = ([
                        {Subject: regex },
                        {'Creator.FullName': regex },
                        {'Recipient.FullName': regex }]);
                });
            }
            query = EntityCache.Conversation.aggregate([
                {$match : search },
                {$group : { _id : "$BatchId", count: { $sum: 1 }, max: {$max: '$ModifiedDate'}}},
                {$sort: { max: -1}}]);

            query.skip(parseInt(params.skip, 10) || 0).limit(parseInt(params.take, 10) || 0).exec(function (err, batch) {
                var batchIds = [],
                    i,
                    len;
                if (err) {
                    callback(err);
                } else {
                    for (i = 0, len = batch.length; i < len; i += 1) {
                        batchIds.push(batch[i]._id);
                    }
                    EntityCache.Conversation.find({BatchId : {$in : batchIds}}, null, { sort: { ModifiedDate: -1} },
                        function (err, conversations) {
                            if (err) {
                                callback(err);
                            } else {
                                callback(err, conversations, batchIds);
                            }
                        });
                }

            });
        };
        this.GetConversationByGroupId = function (params, callback) {
            EntityCache.Conversation.find({GroupId: params.GroupId}, callback);
        };
    };

module.exports = ConversationProcessor;
