/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    InvoiceProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            HgError = require('../common/HgError.js'),
            guid = require('node-uuid'),
            self = this;

        this.ResetInvoices = function (params, callback) {
            EntityCache.Invoice.remove({}, function (error, data) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'INVOICES RESET');
                }
            });
        };

        this.AddInvoices = function (params, callback) {
            EntityCache.Invoice.create(params.InvoiceData, function (error, data) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'Invoices Added');
                }
            });
        };

        this.GetGroupAndSetOverdueInvoices = function (params, callback) {
            var dataRecords = {},
                query = {
                    Status : {
                        $nin: ['Overdue', 'Paid']
                    },
                    InvoiceDate: {
                        $lt: params.StartDate
                    }
                },
                matchQuery = {
                    $match : query
                },
                groupQuery = {
                    $group : {
                        _id : {
                            GroupId : '$GroupId'
                        },
                        TotalFees : { $sum : '$FeeTotal'},
                        TotalServiceFees : { $sum : '$ServiceTotal'},
                    }
                };
            EntityCache.Invoice.aggregate([matchQuery, groupQuery], function (error, data) {
                if (error) { return callback(HgError.Enums.Invoice.ErrorFindingInvoices); }
                data.map(function (item) {
                    if (!dataRecords[item._id.GroupId]) {
                        dataRecords[item._id.GroupId] = {
                            TotalFees : item.TotalFees,
                            TotalServiceFees : item.TotalServiceFees
                        };
                    }
                });
                EntityCache.Invoice.update(query, {$set : {Status : 'Overdue', ModifiedDate : new Date().getTime()}}, {multi : true}, function (error, result) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, dataRecords);
                    }
                });
            });
        };

        this.GetGroupInvoices = function (params, callback) {
            var query = {
                GroupId : params.GroupId,
                Status : {
                    $not: {$in: ['Overdue', 'Paid']}
                },
                InvoiceDate: {
                    $lt: +params.StartDate
                }
            };
            EntityCache.Invoice.find(query, function (error, invoices) {
                if (error) { return callback(HgError.Enums.Invoice.ErrorFindingInvoices); }
                callback(null, invoices);
            });
        };

        this.GetInvoicesForGroup = function (params, callback) {
            var query = params.Query || {};
            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            EntityCache.Invoice.find(query, function (error, invoices) {
                if (error) { return callback(HgError.Enums.Invoice.ErrorFindingInvoices + ' : ' + error); }
                callback(error, invoices);
            });
        };

        this.GetFeesForInvoice = function (params) {
            EntityCache.Fee.find({InvoiceId: params.invoiceId}, function (err, fees) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, HgError.Enums.Invoice.ErrorFindingFees));
                    return;
                }
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, fees));
            });
        };

        this.CreateInvoiceForFee = function (params, cb) {
            EntityCache.Group.findOne({hgId: params.payload.GroupId}, function (err, group) {
                var invoice = EntityCache.Invoice(),
                    invoiceDate = new Date();
                invoiceDate.setUTCMonth(invoiceDate.getUTCMonth() + 1);
                invoiceDate.setUTCDate(1);
                invoice.hgId = guid.v1();
                invoice.GroupId = params.payload.GroupId;
                invoice.GroupName = group.GroupName;
                invoice.StartDate = +new Date();
                invoice.FeeTotal = params.Amount;
                invoice.Total = invoice.FeeTotal;
                invoice.InvoiceDate = +invoiceDate;
                invoice.ModifiedBy = params.UserId;
                invoice.save(cb);
            });
        };

        this.CreateFeeForInvoice = function (params) {
            var fee = EntityCache.Fee(params.payload);
            fee.hgId = guid.v1();
            fee.ModifiedBy = params.UserId;
            fee.save(function (err, newFee) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, HgError.Enums.Invoice.ErrorCreatingFee));
                    return;
                }
                self.UpdateTotalsForInvoice({invoiceId: params.payload.InvoiceId, UserId : params.UserId});
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, newFee));
            });
        };

        this.CreateFee = function (params) {
            var feeRequest = params.payload;
            if (feeRequest.InvoiceId) {
                self.CreateFeeForInvoice(params);
            } else {
                self.CreateInvoiceForFee(params, function (err, invoice) {
                    feeRequest.InvoiceId = invoice.hgId;
                    self.CreateFeeForInvoice(params);
                });
            }
        };

        this.DeleteFeeForInvoice = function (params) {
            params.payload.UserId = params.UserId;
            EntityCache.Fee.remove({hgId: params.payload.feeId}, function (err, removed) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, HgError.Enums.Invoice.ErrorDeletingFee));
                    return;
                }
                self.UpdateTotalsForInvoice(params.payload);
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {removed: removed}));
            });
        };

        this.UpdateTotalsForInvoice = function (params) {
            EntityCache.Invoice.findOne({hgId: params.invoiceId}, function (err, invoice) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, HgError.Enums.Invoice.ErrorFindingFees));
                    return;
                }
                EntityCache.Fee.find({InvoiceId: params.invoiceId}, function (err, fees) {
                    invoice.FeeTotal = fees.reduce(function (memo, fee) {
                        return memo + fee.Amount;
                    }, 0);
                    invoice.ModifiedBy = params.UserId;
                    invoice.Total = invoice.FeeTotal + invoice.BillMeTotal + invoice.ServiceTotal;
                    invoice.save();
                });
            });
        };

        this.UpdateInvoiceStatus = function (params) {
            EntityCache.Invoice.findOne({hgId: params.payload.invoiceId, Status: {$ne: "Paid"}}, function (err, invoice) {
                if (err || !invoice) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, HgError.Enums.Invoice.ErrorUpdatingInvoice));
                    return;
                }
                invoice.Status = params.payload.status;
                invoice.ModifiedBy = params.UserId;
                invoice.save(function (err, invoice) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, HgError.Enums.Invoice.ErrorUpdatingInvoice));
                        return;
                    }
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, invoice));
                });
            });
        };

        this.GetInvoiceByGroupId = function (params, callback) {
            EntityCache.Invoice.find({'GroupId' : params.GroupId}, function (err, news) {
                if (!err) {
                    callback(null, news);
                } else {
                    callback(err);
                }
            });
        };

        this.GetInvoicesById = function (params, callback) {
            EntityCache.Invoice.findOne({'hgId' : params.InvoiceId}, function (error, invoice) {
                callback(error, invoice);
            });
        };
        this.GetInvoicesByBatchId = function (params, callback) {
            EntityCache.Invoice.find({'BatchId' : params.BatchId}, null, { sort: { GroupName: 1} }, function (error, invoices) {
                callback(error, invoices);
            });
        };
    };

module.exports = InvoiceProcessor;
