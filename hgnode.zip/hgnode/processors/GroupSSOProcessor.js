var HgBaseProcessor = require('../framework/HgProcessorV2'),
    GroupSSOProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache'),
            uuid = require('node-uuid'),
            ProcessorHelper = require('../util/ProcessorHelper'),
            HgLog = require('../framework/HgLog'),
            self = this;

        this.DefaultEntityName = 'GroupSSO';

        this.GetGroupSSOById = function (params, callback) {
            EntityCache.GroupSSO.findOne({GroupId: params.GroupId}, params.Fields || {}, function (err, SSO) {
                if (err) {
                    return callback(err);
                }
                if (!SSO) {
                    self.CreateGroupSSO(params, function (err, SSO) {
                        if (err) {
                            return callback(err);
                        }
                        return callback(null, SSO);
                    });
                } else {
                    callback(null, SSO);
                }
            });
        };

        this.GetGroupSSOBySlug = function (params, callback) {
            EntityCache.GroupSSO.findOne({slug: params.slug}, callback);
        };

        this.CreateGroupSSO = function (params, callback) {
            var groupSSO = new EntityCache.GroupSSO(params);
            groupSSO.hgId = uuid.v1();
            groupSSO.save(function (err) {
                callback(err, groupSSO);
            });
        };

        this.UpdateGroupSSO = function (params, callback) {
            var fieldsToUpdate = ProcessorHelper.GetUpdateJson(params.Fields, params.GroupSSO, params.UserId);
            HgLog.debug('fieldsToUpdate', fieldsToUpdate);
            EntityCache.GroupSSO.update({GroupId: params.GroupSSO.GroupId}, {$set: fieldsToUpdate}, function (err) {
                if (err) {
                    return callback(err);
                }
                callback(null, 'services.int.sso.gsu');
            });
        };

        this.UpdateSlug = function (params, callback) {
            EntityCache.GroupSSO.update({GroupId: params.GroupId}, {$set: {slug: params.slug}}, function (err) {
                if (err) {
                    return callback(err);
                }
                callback(null, 'services.int.sso.gsu');
            });
        };

        this.GetSlugUnique = function (params, callback) {
            if (params.slug === '') {
                return callback(null, '');
            }
            EntityCache.GroupSSO.findOne({
                slug: params.slug,
                GroupId: {$ne: params.GroupId}
            }, callback);
        };

        this.IsSSOEnabled = function (params, callback) {
            EntityCache.GroupSSO.findOne({
                GroupId: params.GroupId,
                "SAML.cert": { $exists: true, $ne: null }
            }, {
                hgId: 1
            }, function (err, SSO) {
                if (err) {
                    return callback(err);
                }
                callback(null, !!SSO);
            });
        };
    };

module.exports = GroupSSOProcessor;