/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ProfanityProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            guid = require('node-uuid'),
            Async = require('async'),
            self = this;

        function createNewGroupWord(params, callback) {
            Async.waterfall([
                function (wCallback) {
                    self.ExcludeGroupBannedWord(params, function (error) {
                        wCallback(error);
                    });
                },
                function (wCallback) {
                    EntityCache.Profanity.findOne({
                        GroupId: params.GroupId,
                        Word: params.Word,
                        Lang: params.Lang
                    }, function (error, data) {
                        if (error) {
                            return wCallback(error);
                        }
                        params.groupWordExist = data;
                        wCallback();
                    });
                },
                function (wCallback) {
                    if (params.groupWordExist) {
                        return wCallback();
                    }
                    delete params.hgId;
                    self.SaveBannedWord(params, wCallback);
                }
            ], callback);
        }
        this.IsWordNew = function (params, callback) {
            var query = {
                Lang: params.Lang,
                Status: EntityEnums.ProfanityWordStatus.Active,
                Word: params.Word
            };
            query.GroupId = params.GroupWord ? {$in: [null, params.GroupId]} : null;
            if (params.hgId) {
                query.hgId = {$ne: params.hgId};
            }
            EntityCache.Profanity.findOne(query, callback);
        };
        this.GetBannedWords = function (params, callback) {
            var query = {
                Lang: params.Lang,
                Status: EntityEnums.ProfanityWordStatus.Active,
                GroupId: null
            };
            if (params.SearchTerm) {
                query.Word = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.Profanity.find(query)
                .sort({Word: 1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetGroupBannedWords = function (params, callback) {
            var query = {
                Lang: params.Lang,
                Status: EntityEnums.ProfanityWordStatus.Active,
                GroupId: {$in: [null, params.GroupId]},
                ExcludedGroupIds: {$nin: [params.GroupId]}
            };
            if (params.SearchTerm) {
                query.Word = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.Profanity.aggregate([
                {$match: query},
                {$group: {
                    _id: "$Word",
                    data: {$push: "$$ROOT"}
                }},
                {$sort: {_id: 1}},
                {$skip: parseInt(params.Skip || 0, 10)},
                {$limit: parseInt(params.Take || 10, 20)}
            ], function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, result.map(function (item) {
                    return item.data.length === 1 ? item.data[0] : item.data.find(function (dItem) {
                        return dItem.GroupId === params.GroupId;
                    });
                }));
            });
        };
        this.ExcludeGroupBannedWord = function (params, callback) {
            EntityCache.Profanity.findOne({hgId: params.hgId, GroupId: params.GroupId}, function (error, word) {
                if (error) {
                    return callback(error);
                }
                if (word) {
                    word.Status = EntityEnums.ProfanityWordStatus.Deleted;
                    word.save(callback);
                } else {
                    EntityCache.Profanity.update({
                        hgId: params.hgId
                    }, {
                        $set: {
                            ModifiedBy: params.UserId
                        },
                        $addToSet: {
                            ExcludedGroupIds: params.GroupId
                        }
                    }, callback);
                }
            });
        };
        this.RemoveSystemBannedWord = function (params, callback) {
            EntityCache.Profanity.update({
                hgId: params.hgId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Status: EntityEnums.ProfanityWordStatus.Deleted
                }
            }, callback);
        };
        this.SaveGroupBannedWord = function (params, callback) {
            EntityCache.Profanity.findOne({hgId: params.hgId}, function (error, data) {
                if (error || !data) {
                    return callback(error || 'services.int.prof.elw');
                }
                if (!data.GroupId) {
                    createNewGroupWord(params, callback);
                } else {
                    self.SaveBannedWord(params, callback);
                }
            });
        };
        this.SaveBannedWord = function (params, callback) {
            if (params.hgId) {
                EntityCache.Profanity.update({
                    hgId: params.hgId
                }, {
                    $set: {
                        ModifiedBy: params.UserId,
                        Level: params.Level,
                        Word: params.Word,
                        Lang: params.Lang
                    }
                }, callback);
            } else {
                var word = new EntityCache.Profanity(params);
                word.hgId = guid.v1();
                word.CreatedBy = params.UserId;
                word.save(callback);
            }
        };
    };

module.exports = ProfanityProcessor;