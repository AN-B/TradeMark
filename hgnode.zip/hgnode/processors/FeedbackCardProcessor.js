/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    FeedbackCardProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            FeedbackEnums = require('../enums/FeedbackEnums.js'),
            guid = require('node-uuid'),
            self = this;

        this.SaveCard = function (params, callback) {
            EntityCache.FeedbackCard.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.CardRequest.hgId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Title: params.CardRequest.Title,
                    Description: params.CardRequest.Description || '',
                    Sections: params.CardRequest.Sections,
                    UseSections: params.CardRequest.UseSections,
                    SinglePageQuestion: params.CardRequest.SinglePageQuestion,
                    IsPrivate: params.CardRequest.IsPrivate
                },
                $setOnInsert: {
                    hgId: guid.v1(),
                    GroupId: params.GroupId,
                    GroupName: params.GroupName,
                    CreatedBy: params.UserId,
                    CreatedDate: Date.now(),
                    Status: FeedbackEnums.CardStatus.Active,
                    Type: params.CardRequest.CardType || FeedbackEnums.CardType.Request
                }
            }, {
                upsert: true,
                new: true
            }, callback);
        };

        this.BuilCardForCycleInitiator = function (params, callback) {
            var originalCard = params.OriginalCard,
                newCard = new EntityCache.FeedbackCard({
                    hgId: originalCard.hgId,
                    CreatedBy: originalCard.CreatedBy,
                    CreatedDate: originalCard.CreatedDate,
                    ModifiedBy: originalCard.ModifiedBy,
                    Title: originalCard.Title,
                    GroupId: originalCard.GroupId,
                    GroupName: originalCard.GroupName,
                    Status: originalCard.Status,
                    CycleType: originalCard.CycleType,
                    SinglePageQuestion: originalCard.SinglePageQuestion,
                    Sections: []
                }),
                buildNewSection = function (originalSection, goalId) {
                    return {
                        OriginalId: originalSection.hgId,
                        QuestionForEachGoal: originalSection.QuestionForEachGoal,
                        hgId: guid.v1(),
                        Description: originalSection.Description,
                        Type: originalSection.Type,
                        Title: originalSection.Title,
                        GoalCycleId: originalSection.GoalCycleId,
                        GoalId: goalId,
                        AllowSkipGoals: originalSection.AllowSkipGoals,
                        StartDate: originalSection.StartDate,
                        EndDate: originalSection.EndDate,
                        Questions: originalSection.Questions.map(function (q) {
                            var newQuestion = new EntityCache.FeedbackQuestionAnswer(q);
                            newQuestion.OriginalId = q.hgId;
                            newQuestion.hgId = guid.v1();
                            return newQuestion;
                        })
                    };
                },
                pushSectionsByGoalsToNewCard = function (originalSection) {
                    if (params.SectionGoalMapping[originalSection.hgId] && params.SectionGoalMapping[originalSection.hgId].length) {
                        params.SectionGoalMapping[originalSection.hgId].forEach(function (goal) {
                            newCard.Sections.push(buildNewSection(originalSection, goal.hgId));
                        });
                    } else {
                        newCard.Sections.push(buildNewSection(originalSection));
                    }
                };
            originalCard.Sections.forEach(function (originalSection) {
                if ([FeedbackEnums.SectionType.CycleGoal, FeedbackEnums.SectionType.AdhocGoal].indexOf(originalSection.Type) > -1 && originalSection.QuestionForEachGoal) {
                    pushSectionsByGoalsToNewCard(originalSection);
                } else {
                    newCard.Sections.push(originalSection);
                }
            });

            callback(null, newCard);
        };

        this.GetCardById = function (params, callback) {
            EntityCache.FeedbackCard.findOne({
                hgId: params.CardId,
                GroupId: params.GroupId
            }, function (error, card) {
                if (error || !card) {
                    return callback(error || 'fbc.int.elc');
                }
                callback(null, card.toObject());
            });
        };

        this.GetTalentInsightSystemCard = function (params, callback) {
            EntityCache.FeedbackCard.findOne({
                Category: FeedbackEnums.CardQuestionCategory.System,
                Type: FeedbackEnums.CardType.TalentInsight
            }, params.Fields || {}, callback);
        };

        this.DuplicateTalentInsightCard = function (params, callback) {
            self.GetTalentInsightSystemCard(params, function (error, data) {
                if (error || !data) {
                    return callback('tal.err.rlt');
                }
                delete data._id;
                data.isNew = true;
                data.hgId = guid.v1();
                data.GroupId = params.GroupId;
                data.GroupName = params.GroupName;
                data.CreatedBy = params.UserId;
                data.ModifiedBy = params.UserId;
                data.CreatedDate = Date.now();
                data.Category = FeedbackEnums.CardQuestionCategory.Group;
                var newCard = EntityCache.FeedbackCard(data);
                newCard.save(callback);
            });
        };
    };

module.exports = FeedbackCardProcessor;
