/*jslint node:true es5:true regexp: true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    FeedbackRequestPDFProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var PDF = require('pdfkit'),
            fs = require('fs'),
            parseXml = require('xml2js').parseString,
            Async = require('async'),
            https = require('https'),
            doc,
            docY = 0,
            docBuffers = [],
            userAvatarBuffers = [],
            badgeImages = {},
            isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
            config = require('../../configurations/config.js'),
            HgLog = require('../../framework/HgLog'),
            processElement = require('../../util/SvgHelper.js'),
            DateHelper = require('../../util/DateHelper.js'),
            PDFConstants = require('./FeedbackRequestPDFConstants.js'),
            i18nHelper = require('../../helpers/i18nHelper.js'),
            FeedbackEnums = require('../../enums/FeedbackEnums.js'),
            htmlToText = require('html-to-text'),
            GoalEnums = require('../../enums/GoalEnums.js'),
            lang,
            cycle,
            translateMap = require('../../helpers/translateHelper.js').Goal;

        // create an arc function
        PDF.prototype.arc = function (x, y, radius, startAngle, endAngle, anticlockwise) {
            var startX = x + radius * Math.cos(startAngle),
                startY = y + radius * Math.sin(startAngle),
                endX = x + radius * Math.cos(endAngle),
                endY = y + radius * Math.sin(endAngle),
                arcAngle = endAngle - startAngle,
                largeArc = (arcAngle > Math.PI) ^ (startAngle > endAngle) ^ anticlockwise;
            return this.path("M " + startX + "," + startY +
                " A " + radius + "," + radius +
                " 0 " + (largeArc ? "1" : "0") + "," + (anticlockwise ? "0" : "1") +
                " " + endX + "," + endY);
        };

        function bufferUserAvatar(callback) {
            var userIds;
            if (isLocal) {
                return callback();
            }
            userIds = cycle.Participants.map(function (user) {
                return user.UserId;
            });
            cycle.Card.Sections.forEach(function (section) {
                section.Questions.forEach(function (question) {
                    question.Answers.forEach(function (answer) {
                        if (userIds.indexOf(answer.UserId) === -1) {
                            userIds.push(answer.UserId);
                        }
                    });
                });
                if (Array.isArray(section.AuxiliaryData)) {
                    section.AuxiliaryData.forEach(function (data) {
                        if (data.OwnerUserId && userIds.indexOf(data.OwnerUserId) === -1) {
                            userIds.push(data.OwnerUserId);
                        }
                        if (data.ManagerUserId && userIds.indexOf(data.ManagerUserId) === -1) {
                            userIds.push(data.ManagerUserId);
                        }
                        if (data.comments && data.comments.length) {
                            data.comments.forEach(function (comment) {
                                if (userIds.indexOf(comment.UserId) === -1) {
                                    userIds.push(comment.UserId);
                                }
                            });
                        }
                    });
                } else if (section.AuxiliaryData && section.AuxiliaryData.hgId) {
                    if (section.AuxiliaryData.Approver && userIds.indexOf(section.AuxiliaryData.Approver.UserId) === -1) {
                        userIds.push(section.AuxiliaryData.Approver.UserId);
                    }
                    if (section.AuxiliaryData.Owner && userIds.indexOf(section.AuxiliaryData.Owner.UserId) === -1) {
                        userIds.push(section.AuxiliaryData.Owner.UserId);
                    }
                    if (section.AuxiliaryData.Comments && section.AuxiliaryData.Comments.length) {
                        section.AuxiliaryData.Comments.forEach(function (comment) {
                            if (userIds.indexOf(comment.UserhgId) === -1) {
                                userIds.push(comment.UserhgId);
                            }
                        });
                    }
                }
            });
            Async.forEach(userIds, function (userId, fcallback) {
                var userAvatarBuffer = [];
                https.get({
                    host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
                    path: '/user/' + userId + '.jpg'
                }, function (ret) {
                    ret.on("data", function (chunk) {
                        userAvatarBuffer.push(chunk);
                    }).on("end", function () {
                        userAvatarBuffer = Buffer.concat(userAvatarBuffer);
                        userAvatarBuffers[userId] = userAvatarBuffer;
                        fcallback();
                    });
                }).on('error', function (e) {
                    fcallback('ERROR: ' + e.message);
                });
            }, callback);
        }
        function nextLine(margin) {
            if (doc.y > docY) {
                docY = doc.y;
            }
            docY += margin;
            if (docY > PDFConstants.Size.PageBreak) {
                docY = PDFConstants.Size.MarginTop;
                doc.addPage();
            }
        }
        function generateAvatar(userId, width) {
            var avatarPath = isLocal ?
                    './static' + config.s3store.imageStore[config.nextIndex()] + '/user/' + userId + '.jpg' :
                    userAvatarBuffers[userId],
                leftMargin = PDFConstants.Size.MarginLeft,
                cornerRadius = 4;

            if (width === PDFConstants.Size.AvatarImage) {
                cornerRadius += 4;
            } else {
                leftMargin += 10;
            }
            doc.save();
            try {
                doc.roundedRect(leftMargin, docY, width, width, cornerRadius).clip();
                doc.image(avatarPath, leftMargin, docY, {width: width});
                doc.roundedRect(leftMargin, docY, width, width, cornerRadius).stroke(PDFConstants.Color.RegularText);
            } catch (ex) {
                HgLog.debug(ex);
                doc.roundedRect(leftMargin, docY, width, width, cornerRadius).clip();
                doc.image('./static/css/images/boy.jpg', leftMargin, docY, {width: width});
                doc.roundedRect(leftMargin, docY, width, width, cornerRadius).stroke(PDFConstants.Color.RegularText);
            }
            doc.restore();
        }
        function generateGoalDonut(percent) {
            var leftMargin = PDFConstants.Size.PageWidth / 2;
            doc
                .circle(leftMargin, docY + PDFConstants.Size.GoalRadius, PDFConstants.Size.GoalRadius)
                .lineWidth(10)
                .stroke(PDFConstants.Color.LightShade);
            doc
                .circle(leftMargin, docY + PDFConstants.Size.GoalRadius, PDFConstants.Size.GoalRadius)
                .lineWidth(5)
                .stroke(PDFConstants.Color.ProgressLight);
            doc
                .lineWidth(5)
                .arc(leftMargin, docY + PDFConstants.Size.GoalRadius, PDFConstants.Size.GoalRadius, 0, percent / 100 * 360 * Math.PI / 180, false)
                .rotate(-100, {origin: [leftMargin, docY + PDFConstants.Size.GoalRadius]})
                .stroke(PDFConstants.Color.HeaderText);
            doc.rotate(100, {origin: [leftMargin, docY + PDFConstants.Size.GoalRadius]});
            doc.lineWidth(1);
            nextLine(12);
            doc
                .fontSize(14)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(percent, leftMargin - PDFConstants.Size.GoalRadius, docY, {width: PDFConstants.Size.GoalRadius * 2, align: 'center'});
            nextLine(1);
            doc
                .fontSize(10)
                .text(i18nHelper.translate(lang, 'common.pct'), leftMargin - PDFConstants.Size.GoalRadius, docY, {width: PDFConstants.Size.GoalRadius * 2, align: 'center'});
            nextLine(25);
        }
        function convertBadgeToJSON(params, callback) {
            parseXml(params.xml, {explicitArray: true}, function (err, result) {
                if (!badgeImages[params.hgId]) {
                    badgeImages[params.hgId] = result.svg;
                }
                callback();
            });
        }
        function parseHTML(value) {
            return htmlToText.fromString(value.replace(/•/g, '\u2022 ')
                .replace(/\t/g, '')
                .replace(/\r\n/g, '\n'));
        }
        function extractTaggedUserName(comment) {
            return comment.replace(/<input.*?value="/g, '').replace(/">/g, '');
        }
        function readBadgeImages(callback) {
            var badgeSvgs = {},
                len,
                badgeKey,
                recogntionSections = cycle.Card.Sections.filter(function (section) { return section.Type === FeedbackEnums.SectionType.Recognitions; });

            if (!recogntionSections.length) {
                return callback();
            }

            recogntionSections.forEach(function (recogntionSection) {
                if (Array.isArray(recogntionSection.AuxiliaryData) && recogntionSection.AuxiliaryData.length) {
                    recogntionSection.AuxiliaryData.forEach(function (data) {
                        if (!badgeSvgs[data.TemplateId]) {
                            badgeSvgs[data.TemplateId] = (isLocal ? './static/img' : '') + data.badgeUrl + '.svg';
                        }
                    });
                }
            });

            if (!Object.keys(badgeSvgs).length) {
                return callback();
            }
            len = Object.keys(badgeSvgs).length;
            Async.whilst(
                function () {
                    len -= 1;
                    badgeKey = len > -1 ? Object.keys(badgeSvgs)[len] : '';
                    return len > -1;
                },
                function (badgeCallback) {
                    var xml = '';
                    if (isLocal) {
                        fs.readFile(badgeSvgs[badgeKey], 'utf8', function (error, svg) {
                            if (error) {
                                HgLog.error({methodName: 'readBadgeImages', error: error});
                                return callback('pdf.rev.errg');
                            }
                            svg = svg.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                            convertBadgeToJSON({
                                hgId: badgeKey,
                                xml: svg
                            }, badgeCallback);
                        });
                    } else {
                        https.get({
                            host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
                            path: badgeSvgs[badgeKey]
                        }, function (ret) {
                            ret.on("data", function (chunk) {
                                xml += chunk;
                            }).on("end", function () {
                                xml = xml.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                                convertBadgeToJSON({
                                    hgId: badgeKey,
                                    xml: xml
                                }, badgeCallback);
                            });
                        }).on('error', function (e) {
                            HgLog.error('ERROR: ' + e.message);
                            return callback('pdf.rev.errg');
                        });
                    }
                },
                function (err) {
                    if (err) {
                        return callback('pdf.rev.errg');
                    }
                    callback();
                }
            );
        }
        function processShapes(ele) {
            var i, len, shape;
            Object.keys(ele).forEach(function (e) {
                if (ele.hasOwnProperty(e)) {
                    shape = e.toString();
                    if (shape === 'g') {
                        for (i = 0, len = ele[e].length; i < len; i += 1) {
                            if (!ele[e][i].$ || ele[e][i].$.display !== 'none') {
                                processShapes(ele[e][i]);
                            }
                        }
                    } else if (processElement[shape]) {
                        processElement[shape]({ele: ele[e], doc: doc});
                    } else {
                        HgLog.error('Element ' + shape + ' is not supported!');
                    }
                }
            });
        }
        function RenderAuxiliaryData(data) {
            this.Recognitions = function () {
                var badge  = badgeImages[data.TemplateId];
                if (docY > PDFConstants.Size.PageBreak - (data.message.length > 500 ? 80 : 50)) {
                    nextLine(data.message.length > 500 ? 80 : 50);
                }
                nextLine(10);
                if (badge) {
                    doc.save();
                    doc.translate(PDFConstants.Size.MarginLeft, docY).scale(0.35);
                    processShapes(badge);
                    doc.restore();
                }
                doc
                    .fontSize(12)
                    .fill(PDFConstants.Color.RegularText)
                    .font(PDFConstants.Font.OpenSansBold)
                    .text(data.title, PDFConstants.Size.MarginLeft + 50, docY, {width: 450});
                nextLine(5);
                doc
                    .fontSize(10)
                    .font(PDFConstants.Font.OpenSansItalic)
                    .text(data.issuer.fullName, PDFConstants.Size.MarginLeft + 50, docY, {width: 450});
                nextLine(5);
                doc
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(data.message, PDFConstants.Size.MarginLeft + 50, docY, {width: 450});
                nextLine(15);

                if (data.comments.length) {
                    doc
                        .moveTo(PDFConstants.Size.MarginLeft, docY)
                        .dash(2)
                        .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, docY)
                        .stroke(PDFConstants.Color.Underline).undash();
                    data.comments.forEach(function (comment) {
                        if (comment.Comment) {
                            nextLine(10);
                            if (docY > PDFConstants.Size.PageBreak - 15) {
                                nextLine(15);
                            }
                            generateAvatar(comment.UserId, PDFConstants.Size.CommentImage);
                            doc
                                .fontSize(10)
                                .font(PDFConstants.Font.OpenSansBold)
                                .text(comment.Name, PDFConstants.Size.MarginLeft + 50, docY, {width: 450});
                            nextLine(5);
                            doc
                                .fontSize(10)
                                .font(PDFConstants.Font.OpenSansRegular)
                                .text(htmlToText.fromString(extractTaggedUserName(comment.Comment)), PDFConstants.Size.MarginLeft + 50, docY, {width: 450});
                            nextLine(10);
                        }
                    });
                    nextLine(5);
                }
                doc
                    .moveTo(PDFConstants.Size.MarginLeft, docY)
                    .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, docY)
                    .stroke(PDFConstants.Color.Underline);
                nextLine(5);
            };
            this.Goals = function (params) {
                var progressUnit,
                    i,
                    goalDeailsInfo = {};
                if (docY > PDFConstants.Size.PageBreak - 65) {
                    nextLine(65);
                }
                nextLine(10);
                if (!params.singleGoal) {
                    doc
                        .fontSize(10)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .fill(PDFConstants.Color.RegularText)
                        .text(i18nHelper.translate(lang, 'pdf.of', {current: params.index, total: params.total}), 0, docY, {width: PDFConstants.Size.PageWidth, align: 'center'});
                    nextLine(10);
                }
                generateGoalDonut(Math.round(params.singleGoal ? data.PercentCompletion : data.Completion));
                doc
                    .font(PDFConstants.Font.OpenSansBold)
                    .fontSize(12)
                    .fill(PDFConstants.Color.HeaderText)
                    .text(params.singleGoal ? data.Name : data.GoalName, 0, docY, {width: PDFConstants.Size.PageWidth, align: 'center'});
                nextLine(10);
                if (data.ProgressStatus) {
                    doc
                        .fontSize(10)
                        .font(PDFConstants.Font.OpenSansBold)
                        .fill(PDFConstants.Color.ProgressStatus[data.ProgressStatus])
                        .text(i18nHelper.translate(lang, translateMap.Status[data.ProgressStatus]), 0, docY, {width: PDFConstants.Size.PageWidth, align: 'center'});
                    nextLine(10);
                }
                if (!params.singleGoal) {
                    doc
                        .fontSize(10)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .fill(PDFConstants.Color.RegularText)
                        .text(i18nHelper.translate(lang, data.KrNumber > 1 ? 'pdf.mrs' : 'pdf.mrs1', {results_number: data.KrNumber}), 0, docY, {width: PDFConstants.Size.PageWidth, align: 'center'});
                    nextLine(15);
                    doc
                        .moveTo(PDFConstants.Size.MarginLeft, docY)
                        .dash(2)
                        .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, docY)
                        .stroke(PDFConstants.Color.Underline).undash();
                } else {
                    if (data.Description) {
                        doc
                            .font(PDFConstants.Font.OpenSansRegular)
                            .fill(PDFConstants.Color.RegularText)
                            .text(data.Description, PDFConstants.Size.MarginLeft, docY, {width: PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2, align: 'center'});
                        nextLine(20);
                    }

                    //goal details
                    if (data.ClosePromptDate) {
                        goalDeailsInfo['pdf.cmb'] = DateHelper.formatDateStringFromTimestamp(data.ClosePromptDate);
                    }
                    if (data.CycleTitle) {
                        goalDeailsInfo['pdf.cyn'] = data.CycleTitle;
                    }
                    if (data.CheckInFrequency) {
                        goalDeailsInfo['pdf.cif'] = data.CheckInFrequency;
                    }
                    if (data.Status) {
                        goalDeailsInfo['common.sta'] = i18nHelper.translate(lang, translateMap.GoalStatus[data.Status]);
                    }
                    if (data.Approver.FullName) {
                        goalDeailsInfo['pdf.app'] = data.Approver.FullName;
                    }
                    if (docY > PDFConstants.Size.PageBreak - 50) {
                        nextLine(50);
                    }
                    Object.keys(goalDeailsInfo).forEach(function (key, ind) {
                        if (ind % 2 === 1) {
                            doc
                                .rect(PDFConstants.Size.MarginLeft, docY, PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2, 25)
                                .fill(PDFConstants.Color.LightShade);
                        }
                        nextLine(2);
                        doc
                            .fontSize(9)
                            .font(PDFConstants.Font.OpenSansBold)
                            .fill(PDFConstants.Color.RegularText)
                            .text(i18nHelper.translate(lang, key), PDFConstants.Size.MarginLeft + 20, docY, {
                                width: 80,
                                align: 'right'
                            });
                        doc
                            .fontSize(10)
                            .font(PDFConstants.Font.OpenSansRegular)
                            .text(goalDeailsInfo[key], PDFConstants.Size.MarginLeft + 120, docY, {width: 250, align: 'left'});
                        nextLine(10);
                    });

                    // keyresults
                    nextLine(5);
                    data.KeyResults.forEach(function (keyResult) {
                        if (docY > PDFConstants.Size.PageBreak - 25) {
                            nextLine(25);
                        }
                        doc
                            .rect(PDFConstants.Size.MarginLeft, docY, PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2, 50)
                            .fill(PDFConstants.Color.LightShade);
                        nextLine(5);
                        doc
                            .font(PDFConstants.Font.OpenSansSemibold)
                            .fill(PDFConstants.Color.RegularText)
                            .text(keyResult.Name, PDFConstants.Size.MarginLeft + 20, docY, {width: 400});

                        if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Numeric) {
                            if (keyResult.NumericType === GoalEnums.KeyResultNumericType.Percentage && keyResult.Target === 100) {
                                doc
                                    .font(PDFConstants.Font.OpenSansBold)
                                    .text(keyResult.Progress + keyResult.Suffix || '', 400, docY, {
                                        width: 150,
                                        align: 'right'
                                    });
                            } else {
                                doc
                                    .font(PDFConstants.Font.OpenSansBold)
                                    .text(i18nHelper.translate(lang, 'pdf.out', {
                                        progress: keyResult.Progress + (keyResult.Suffix || ''),
                                        target: keyResult.Target + (keyResult.Suffix || '')
                                    }), 400, docY, {width: 150, align: 'right'});
                            }
                            nextLine(15);
                            if (keyResult.Progress > keyResult.Target) {
                                doc
                                    .moveTo(PDFConstants.Size.MarginProgress, docY)
                                    .lineWidth(4)
                                    .lineTo(PDFConstants.Size.ProgressWidth, docY)
                                    .stroke(PDFConstants.Color.HeaderText);
                            } else {
                                if (keyResult.Target === 100) {
                                    progressUnit = keyResult.Progress * 5;
                                } else {
                                    progressUnit = keyResult.Progress / keyResult.Target * 500;
                                }
                                doc
                                    .moveTo(PDFConstants.Size.MarginProgress, docY)
                                    .lineWidth(4)
                                    .lineTo(PDFConstants.Size.MarginProgress + progressUnit, docY)
                                    .stroke(PDFConstants.Color.HeaderText);
                                doc
                                    .moveTo(PDFConstants.Size.MarginProgress + progressUnit, docY)
                                    .lineTo(PDFConstants.Size.ProgressWidth, docY)
                                    .stroke(PDFConstants.Color.RegularText);
                            }
                        } else if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Percentage) {
                            doc
                                .font(PDFConstants.Font.OpenSansBold)
                                .fill(PDFConstants.Color.RegularText)
                                .text(i18nHelper.translate(lang, 'profile.goals.pp', { progress: keyResult.Progress}), 400, docY, {
                                    width: 150,
                                    align: 'right'
                                });
                            nextLine(15);
                            doc
                                .moveTo(PDFConstants.Size.MarginProgress, docY)
                                .lineWidth(4)
                                .lineTo(PDFConstants.Size.MarginProgress + keyResult.Progress * 5, docY)
                                .stroke(PDFConstants.Color.HeaderText);
                            doc
                                .moveTo(PDFConstants.Size.MarginProgress + keyResult.Progress * 5, docY)
                                .lineTo(PDFConstants.Size.ProgressWidth, docY)
                                .stroke(PDFConstants.Color.RegularText);
                        } else if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Binary) {
                            doc
                                .font(PDFConstants.Font.OpenSansBold)
                                .fill(PDFConstants.Color.RegularText)
                                .text(i18nHelper.translate(lang, keyResult.Progress === 100 ? 'common.com' : 'common.inco'), 400, docY, {width: 150, align: 'right'});
                            nextLine(15);
                            doc
                                .moveTo(PDFConstants.Size.MarginProgress, docY)
                                .lineWidth(4)
                                .lineTo(PDFConstants.Size.ProgressWidth, docY)
                                .stroke(keyResult.Progress === 100 ? PDFConstants.Color.HeaderText : PDFConstants.Color.RegularText);
                        }
                        doc.lineWidth(1);
                        nextLine(25);
                    });
                    nextLine(20);

                    //goal comments
                    if (data.CommentTotalCount) {
                        doc
                            .font(PDFConstants.Font.OpenSansBold)
                            .fill(PDFConstants.Color.RegularText)
                            .text(i18nHelper.translate(lang, 'common.cmt'), PDFConstants.Size.MarginLeft, docY, {width: 110});
                        nextLine(20);
                        for (i = data.Comments.length - 1; i >= 0; i -= 1) {
                            if (docY > PDFConstants.Size.PageBreak - 15) {
                                nextLine(15);
                            }
                            generateAvatar(data.Comments[i].UserhgId, PDFConstants.Size.CommentImage);
                            doc
                                .fontSize(10)
                                .font(PDFConstants.Font.OpenSansBold)
                                .text(data.Comments[i].Name, PDFConstants.Size.MarginLeft + 50, docY, {width: 450});
                            nextLine(5);
                            doc
                                .fontSize(10)
                                .font(PDFConstants.Font.OpenSansRegular)
                                .text(i18nHelper.translate(lang, parseHTML(data.Comments[i].Comment)), PDFConstants.Size.MarginLeft + 50, docY, {width: 450});
                            nextLine(15);
                        }
                    }
                }
            };
        }
        function RenderAnswer(question) {
            doc
                .font(PDFConstants.Font.OpenSansBold)
                .fontSize(10)
                .fill(PDFConstants.Color.Black)
                .text(question.Question, PDFConstants.Size.MarginLeft, docY, {width: 450});
            nextLine(10);
            this.ShortAnswer = function (answer) {
                if (!answer.Text) {
                    doc
                        .fontSize(10)
                        .fill(PDFConstants.Color.RegularText)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(i18nHelper.translate(lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, docY, {width: 450});
                    nextLine(10);
                    return;
                }
                generateAvatar(answer.UserId, PDFConstants.Size.CommentImage);
                doc
                    .fontSize(10)
                    .fill(PDFConstants.Color.RegularText)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(answer.Text, PDFConstants.Size.MarginAnswer, docY, {width: 450});
                nextLine(20);
            };
            this.RadioButton = function (answer) {
                var selection = answer.SelectedValues && answer.SelectedValues.length && question.AnswerSelector.find(function (selected) {
                    return selected.Value === answer.SelectedValues[0];
                });
                if (!selection) {
                    doc
                        .fontSize(10)
                        .fill(PDFConstants.Color.RegularText)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(i18nHelper.translate(lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, docY, {width: 450});
                    nextLine(10);
                    return;
                }
                generateAvatar(answer.UserId, PDFConstants.Size.CommentImage);
                nextLine(3);
                doc.circle(PDFConstants.Size.MarginAnswer + 10, docY + 8, 8).fill(PDFConstants.Color.HeaderText);
                doc
                    .fontSize(10)
                    .fill(PDFConstants.Color.RegularText)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(selection.Text, PDFConstants.Size.MarginAnswer + 25, docY, {width: selection.Text.length * 15, align: 'left'});
                nextLine(20);
            };
            this.RatingScale = function (answer) {
                var selection;
                if (!answer.SelectedValues || !answer.SelectedValues.length) {
                    doc
                        .fontSize(10)
                        .fill(PDFConstants.Color.RegularText)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(i18nHelper.translate(lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, docY, {width: 450});
                    nextLine(10);
                    return;
                }
                if (docY > PDFConstants.Size.PageBreak - 10) {
                    nextLine(10);
                }
                generateAvatar(answer.UserId, PDFConstants.Size.CommentImage);
                question.AnswerSelector.forEach(function (selector, index) {
                    selection = answer.SelectedValues.find(function (selectedAnswer) {
                        return selector.Value === selectedAnswer;
                    });
                    doc
                        .circle(PDFConstants.Size.MarginAnswer + 10, docY + 8, 8)
                        .fillAndStroke(
                            selection === undefined ? PDFConstants.Color.White : PDFConstants.Color.HeaderText,
                            selection === undefined ? PDFConstants.Color.RegularText : PDFConstants.Color.HeaderText
                        );
                    doc
                        .fontSize(8)
                        .fill(selection !== undefined ? PDFConstants.Color.White : PDFConstants.Color.RegularText)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(i18nHelper.translate(lang, 'feedback.asw.' + 'a' + index), PDFConstants.Size.MarginAnswer, docY + 2, {width: 20, align: 'center'});
                    doc
                        .fontSize(10)
                        .fill(selection !== undefined ? PDFConstants.Color.HeaderText : PDFConstants.Color.RegularText)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(selector.Text, PDFConstants.Size.MarginAnswer + 25, docY, {width: selector.Text.length * 15, align: 'left'});
                    nextLine(10);
                });
                nextLine(5);
            };
            this.CheckBox = function (answer) {
                var selection;
                if (!answer.SelectedValues || !answer.SelectedValues.length) {
                    doc
                        .fontSize(10)
                        .fill(PDFConstants.Color.RegularText)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(i18nHelper.translate(lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, docY, {width: 450});
                    nextLine(10);
                    return;
                }
                if (docY > PDFConstants.Size.PageBreak - 10) {
                    nextLine(10);
                }
                generateAvatar(answer.UserId, PDFConstants.Size.CommentImage);
                answer.SelectedValues.forEach(function (selectedAnswer) {
                    selection = question.AnswerSelector.find(function (selected) {
                        return selected.Value === selectedAnswer;
                    });
                    doc.circle(PDFConstants.Size.MarginAnswer + 10, docY + 8, 8).fill(PDFConstants.Color.HeaderText);
                    doc
                        .fontSize(10)
                        .fill(PDFConstants.Color.RegularText)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(selection.Text, PDFConstants.Size.MarginAnswer + 25, docY, {width: selection.Text.length * 15, align: 'left'});
                    nextLine(10);
                });
                nextLine(5);
            };
        }
        function renderManagerNotes(notes) {
            doc
                .fontSize(12)
                .fill(PDFConstants.Color.HeaderText)
                .font(PDFConstants.Font.OpenSansItalic)
                .text(i18nHelper.translate(lang, "pdf.mnt"), PDFConstants.Size.MarginAnswer, docY, {width: 100});
            nextLine(25);
            notes.forEach(function (note) {
                generateAvatar(note.UserId, PDFConstants.Size.CommentImage);
                doc
                    .fontSize(10)
                    .fill(PDFConstants.Color.RegularText)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(note.Notes, PDFConstants.Size.MarginAnswer + 50, docY, {width: 450});
            });
            nextLine(20);
        }
        function additionalComments() {
            nextLine(30);
            doc
                .fontSize(12)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansBold)
                .text(i18nHelper.translate(lang, "pdf.adc"), PDFConstants.Size.MarginLeft, docY, {width: 350});
        }
        function cycleHeader() {
            doc
                .rect(0, docY, 612, 60)
                .fill(PDFConstants.Color.White);
            nextLine(20);
            doc
                .font(PDFConstants.Font.OpenSansBold)
                .fontSize(16)
                .fill(PDFConstants.Color.HeaderText)
                .text(cycle.CycleTitle, PDFConstants.Size.MarginLeft, docY, {width: 540});
            if (cycle.CycleDescription) {
                nextLine(20);
                doc
                    .font(PDFConstants.Font.OpenSansItalic)
                    .text(cycle.CycleDescription, PDFConstants.Size.MarginLeft, docY, {width: 540});
            }
            var subject = cycle.Participants.find(function (p) {
                return [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(p.ParticipantType) !== -1;
            });
            nextLine(25);
            generateAvatar(subject.UserId, PDFConstants.Size.AvatarImage);
            doc
                .fontSize(12)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansSemibold)
                .text(subject.FullName, PDFConstants.Size.MarginAnswer + 10, docY, {width: 450});
            if (cycle.Status === FeedbackEnums.SessionStatus.Archived && cycle.ArchiveDate) {
                doc
                    .fontSize(10)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(i18nHelper.translate(lang, "pdf.arc", {date: DateHelper.formatDateStringFromTimestamp(cycle.ArchiveDate)}), PDFConstants.Size.MarginLeft, docY,
                        {
                            width: PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2,
                            align: 'right'
                        });
            } else {
                doc
                    .fontSize(10)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(i18nHelper.translate(lang, "pdf.con", {due_date: DateHelper.formatDateStringFromTimestamp(subject.SubmittedDate)}), PDFConstants.Size.MarginLeft, docY,
                        {
                            width: PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2,
                            align: 'right'
                        });
            }
            nextLine(4);
            doc
                .fontSize(10)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(subject.DepartmentName, PDFConstants.Size.MarginAnswer + 10, docY, {width: 450});
            nextLine(4);
            doc
                .fontSize(10)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(subject.Position, PDFConstants.Size.MarginAnswer + 10, docY, {width: 450});
            nextLine(4);
            if (subject.Manager) {
                doc
                    .fontSize(10)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(i18nHelper.translate(lang, "pdf.rpt", {manager_name: subject.Manager.Name}), PDFConstants.Size.MarginAnswer + 10, docY, {width: 450});
            }
            nextLine(35);
        }
        function sectionHeader(tabName) {
            nextLine(10);
            if (docY > PDFConstants.Size.PageBreak - 110) {
                nextLine(110);
            }
            if (tabName) {
                doc
                    .font(PDFConstants.Font.OpenSansSemibold)
                    .fontSize(14)
                    .fill(PDFConstants.Color.HeaderText)
                    .text(tabName, PDFConstants.Size.MarginLeft, docY, {width: 540});
                nextLine(5);
            }
            doc
                .lineWidth(5)
                .moveTo(PDFConstants.Size.MarginLeft, docY)
                .lineTo(576, docY)
                .stroke(PDFConstants.Color.Underline);
            doc.lineWidth(1);
            nextLine(5);
        }
        function sectionBody(section) {
            var auxiliaryDataFactory,
                answerFactory,
                len = section.AuxiliaryData.length,
                auxiliaryType = section.Type;

            if ([FeedbackEnums.SectionType.CycleGoal, FeedbackEnums.SectionType.AdhocGoal].indexOf(auxiliaryType) > -1) {
                auxiliaryType = 'Goals';
            }

            if (Array.isArray(section.AuxiliaryData) && section.AuxiliaryData.length) {
                section.AuxiliaryData.forEach(function (auxi, ind) {
                    auxiliaryDataFactory = new RenderAuxiliaryData(auxi);
                    if (typeof auxiliaryDataFactory[auxiliaryType] === 'function') {
                        auxiliaryDataFactory[auxiliaryType]({index: ind + 1, total: len});
                    }
                });
            } else if (typeof section.AuxiliaryData === 'object' && section.AuxiliaryData.hgId) {
                auxiliaryDataFactory = new RenderAuxiliaryData(section.AuxiliaryData);
                if (typeof auxiliaryDataFactory[auxiliaryType] === 'function') {
                    auxiliaryDataFactory[auxiliaryType]({singleGoal: true});
                }
            } else if (auxiliaryType === 'Goals') {
                doc
                    .font(PDFConstants.Font.OpenSansRegular)
                    .fontSize(12)
                    .fill(PDFConstants.Color.RegularText)
                    .text(i18nHelper.translate(lang, 'pdf.ngs'), PDFConstants.Size.MarginLeft, docY, {width: 540});
                nextLine(15);
            }
            doc
                .font(PDFConstants.Font.OpenSansBold)
                .fontSize(12)
                .fill(PDFConstants.Color.HeaderText)
                .text(i18nHelper.translate(lang, 'pdf.qaa'), PDFConstants.Size.MarginLeft, docY, {width: 540});
            nextLine(15);
            section.Questions.forEach(function (question) {
                answerFactory = new RenderAnswer(question);
                question.Answers.forEach(function (answer) {
                    answerFactory[question.Type](answer);
                });
                if (question.PdfManagerNotes && question.PdfManagerNotes.length) {
                    renderManagerNotes(question.PdfManagerNotes);
                }
            });
            if (section.QuestionForEachGoal) {
                nextLine(10);
                doc
                    .moveTo(PDFConstants.Size.MarginLeft, docY)
                    .dash(2)
                    .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, docY)
                    .stroke(PDFConstants.Color.Underline).undash();
            }
        }
        function buildPDF() {
            var currentSection;
            doc.y = 0;
            nextLine(0);
            cycleHeader();
            cycle.Card.Tabs.forEach(function (tab) {
                sectionHeader(tab.name);
                tab.sectionIds.forEach(function (section) {
                    currentSection = cycle.Card.Sections.find(function (sec) { return sec.hgId === section.hgId; });
                    if (currentSection) {
                        sectionBody(currentSection);
                    }
                });
            });
            additionalComments();
            doc.end();
        }
        this.GenerateFeedbackPdf = function (params, callback) {
            cycle = params.Cycle;
            lang = params.Lang;
            doc = new PDF({
                info: {
                    Title: cycle.CycleTitle,
                    Author: PDFConstants.Author,
                    Producer: PDFConstants.Author
                },
                size: 'letter',
                margins: {
                    top: PDFConstants.Size.MarginTop,
                    bottom: PDFConstants.Size.MarginBottom,
                    left: 24,
                    right: 24
                },
                bufferPages: true
            });
            Object.keys(PDFConstants.Font).forEach(function (key) {
                doc.registerFont(key, PDFConstants.Font[key]);
            });
            doc.lineWidth(1);
            doc
                .on('data', function (data) {
                    docBuffers.push(data);
                })
                .on('error', function (error) {
                    return callback(error);
                })
                .on('end', function () {
                    if (docBuffers.length) {
                        callback(null, Buffer.concat(docBuffers));
                    } else {
                        callback('pdf.rev.errg');
                    }
                });
            Async.parallel({
                badgeImages: function (fcallback) {
                    readBadgeImages(fcallback);
                },
                userAvatars: function (fcallback) {
                    bufferUserAvatar(fcallback);
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                buildPDF();
            });
        };
    };

module.exports = FeedbackRequestPDFProcessor;
