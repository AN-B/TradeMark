/*jslint node:true es5:true*/
'use strict';
var FeedbackRequestPDFConstants = {
    Author: 'HighGround Enterprise Solutions, Inc.',
    Color: {
        HeaderColor: '#2F3D44',
        White: "white",
        Black: "black",
        HeaderText: "#379def",
        ProgressLight: "#9bcef7",
        Underline: '#bbbbbb',
        RegularText: "#666666",
        LightShade: '#eeeeee',
        DarkShade: '#2b3538',
        ProgressStatus: {
            OnTrack: "#42d981",
            Behind: "#ddb100",
            AtRisk: "#e15c5c"
        }
    },
    Size: {
        PageWidth: 612,
        PageHeight: 792,
        MarginLeft: 36,
        MarginTop: 36,
        MarginBottom: 48,
        MarginAnswer: 86,
        MarginProgress: 56,
        PageBreak: 684,
        AvatarImage: 50,
        CommentImage: 32,
        GoalRadius: 30,
        ProgressWidth: 550
    },
    Font: {
        LaBelleAurore: './static/fonts/LaBelleAurore.ttf',
        OpenSansRegular: './static/fonts/Open_Sans/OpenSans-Regular.ttf',
        OpenSansSemibold: './static/fonts/Open_Sans/OpenSans-Semibold.ttf',
        OpenSansItalic: './static/fonts/Open_Sans/OpenSans-Italic.ttf',
        OpenSansBold: './static/fonts/Open_Sans/OpenSans-Bold.ttf',
        OpenSansLight: './static/fonts/Open_Sans/OpenSans-Light.ttf'
    }
};
module.exports = FeedbackRequestPDFConstants;
