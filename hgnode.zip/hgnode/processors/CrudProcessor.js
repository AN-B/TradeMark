/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    CrudProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js');

        this.Create = function (params, callback) {
            var EntityModel = EntityCache[params.EntityName],
                entity = params.entity,
                dbEntity;
            if (!EntityModel || !entity) {
                callback('Invalid EntityName or entity', null);
                return;
            }
            dbEntity = new EntityModel(entity);

            dbEntity.save(function (error) {
                callback(error, dbEntity);
            });
        };
        this.GetOne = function (params, callback) {
            var EntityModel = EntityCache[params.EntityName],
                condition = params.Condition,//example : {'hgId' : 'dlklfjsakf'}
                fields = params.Fields,//example : {'hgId' : true, 'FirstName' : true}
                mquery;
            if (!EntityModel || !condition) {
                callback('Invalid EntityName or condition', null);
                return;
            }
            if (fields) {
                mquery = EntityModel.findOne(condition, fields);
            } else {
                mquery = EntityModel.findOne(condition);
            }
            mquery.exec(function (error, entity) {
                if (error || !entity) {
                    callback('Cannot retrieve ' + params.EntityName, null);
                } else {
                    callback(null, entity);
                }
            });
        };
        this.Get = function (params, callback) {
            var EntityModel = EntityCache[params.EntityName],
                condition = params.Condition,//example : {'hgId' : 'dlklfjsakf'}
                fields = params.Fields,//example : {'hgId' : true, 'FirstName' : true}
                mquery;
            if (!EntityModel || !condition) {
                callback('Invalid EntityName or condition', null);
                return;
            }
            if (fields) {
                mquery = EntityModel.find(condition, fields);
            } else {
                mquery = EntityModel.find(condition);
            }
            mquery.exec(function (error, entities) {
                if (error) {
                    callback('Cannot retrieve ' + params.EntityName, null);
                } else {
                    callback(null, entities);
                }
            });
        };
        this.Update = function (params, callback) {
            var EntityModel = EntityCache[params.EntityName],
                condition = params.Condition,//example : {'hgId' : 'dlklfjsakf'}
                mapping = params.Mapping,//example : {$set : {'FirstName' : 'Gary'}}
                multi = params.Multi || true;
            if (!EntityModel || !condition || !mapping) {
                callback('Invalid EntityName or condition or mapping', null);
                return;
            }
            EntityModel.update(condition, mapping, {multi : multi}, function (error) {
                callback(error, 'Update done');
            });
        };
        this.Delete = function (params, callback) {
            var EntityModel = EntityCache[params.EntityName],
                condition = params.Condition;
            if (!EntityModel || !condition) {
                callback('Invalid EntityName or condition', null);
                return;
            }
            EntityModel.remove(condition, function (error) {
                callback(error, params.EntityName + ' has been Deleted');
            });
        };
    };

module.exports = CrudProcessor;
