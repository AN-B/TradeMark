/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    PetitionProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            Enums = require('../enums/PetitionEnums.js'),
            guid = require('node-uuid'),
            async = require('async'),
            duplicatePetition = function (petition, petitionersInRequest) {
                var duplicatePetitionerExists = false;
                if (!petition) {
                    return duplicatePetitionerExists;
                }
                petition.Petitioners.forEach(function (petitionerInDB) {
                    petitionersInRequest.forEach(function (petitionerInRequest) {
                        if (petitionerInRequest.MemberId === petitionerInDB.MemberId) {
                            duplicatePetitionerExists = true;
                        }
                    });
                });
                return duplicatePetitionerExists;
            };
        this.GetPetitionsByTypesAndApproverGroupByPetitioner = function (params, callback) {
            var aggregate = [{
                    $match: {
                        PetitionTypeName: {$in: params.PetitionTypes},
                        Status: Enums.Status.Pending,
                        'Approvers.MemberId': params.ApproverMemberId
                    }
                }, {
                    $group: {
                        '_id': {MemberId: '$Petitioners.MemberId', UserId: '$Petitioners.UserId'},
                        rows: {
                            $push: {
                                hgId: '$hgId',
                                PetitionerFullName: '$Petitioners.FullName',
                                ApproverFullName: '$Approvers.FullName',
                                PetitionType: '$PetitionTypeName',
                                EntityId: "$EntityId"
                            }
                        }
                    }
                }, {
                    $skip: parseInt(params.Skip, 10) || 0
                }, {
                    $limit: parseInt(params.Take, 10) || 0
                }];
            if (params.SearchTerm) {
                aggregate[0].$match['Petitioners.FullName'] = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.Petition.aggregate(aggregate, callback);
        };
        this.GetMemberApprovalFromPeitioner = function (params, callback) {
            EntityCache.Petition.find({
                PetitionTypeName: {$in: params.PetitionTypes},
                Status: Enums.Status.Pending,
                'Approvers.MemberId': params.ApproverMemberId,
                'Petitioners.MemberId': params.PetitionerMemberId
            }, callback);
        };
        this.GetPendingPetitionsByApproverAndEntityType = function (params, callback) {
            EntityCache.Petition.find({
                EntityType: params.EntityType,
                Status: Enums.Status.Pending,
                'Approvers.MemberId': params.MemberId
            }, function (error, petitions) {
                callback(error, petitions);
            });
        };
        this.GetPetitionsByEntityIdAndStatusesAndType = function (params, callback) {
            EntityCache.Petition.find({
                EntityId: params.EntityId,
                Status: {$in: params.Statuses},
                PetitionTypeName: params.Type
            }).sort({'_id': -1}).exec(callback);
        };
        this.GetPetitionsByEntityIdAndStatusAndType = function (params, callback) {
            EntityCache.Petition.find({
                EntityId: params.EntityId,
                Status: params.Status,
                PetitionTypeName: params.Type
            }).sort({CreatedDate: -1}).exec(callback);
        };
        this.GetPetitionsByEntityIdsAndStatus = function (params, callback) {
            EntityCache.Petition.find({
                EntityId: {$in: params.EntityIds},
                Status: params.Status
            }, callback);
        };
        this.GetPetitionsByEntityIdsAndStatuses = function (params, callback) {
            EntityCache.Petition.find({
                EntityId: {$in: params.EntityIds},
                Status: {$in: params.Statuses},
            }).sort({'_id': -1}).exec(callback);
        };
        this.TransferPetitionApproval = function (params, callback) {
            var query = {
                PetitionTypeName: { $in: params.EntityTypes },
                Status: Enums.Status.Pending,
                'Approvers.MemberId': params.OldApprovalMemberId
            };
            if (params.DirectReports && params.DirectReports.length) {
                query['Petitioners.MemberId'] = {$in: params.DirectReports};
            }
            EntityCache.Petition.find(query, function (error, data) {
                if (error || !data.length) {
                    return callback(error);
                }
                async.each(data, function (petition, pCallback) {
                    EntityCache.Petition.update({
                        hgId: petition.hgId
                    }, {
                        $set: {
                            Approvers: [{
                                MemberId: params.NewApprovalMemberId,
                                UserId: params.NewApprovalUserId,
                                FullName: params.NewApprovalFullName
                            }]
                        }
                    }, pCallback);
                }, function (uerror) {
                    if (uerror) {
                        return callback(error);
                    }
                    return callback();
                });
            });
        };
        this.GetPendingPetitionsByEntityId = function (params, callback) {
            EntityCache.Petition.find({EntityId: params.EntityId, Status: Enums.Status.Pending}, function (error, petitions) {
                callback(error, petitions);
            });
        };
        this.GetPendingPetitionsByEntityIds = function (params, callback) {
            EntityCache.Petition.find({EntityId: {$in: params.EntityIds}, Status: Enums.Status.Pending}, function (error, petitions) {
                callback(error, petitions);
            });
        };
        this.MakeDecision = function (params, callback) {
            var condition = {
                    PetitionTypeName: params.PetitionTypeName,
                    EntityId: params.EntityId,
                    Status: Enums.Status.Pending
                },
                petitionType = Enums.PetitionTypes[params.PetitionTypeName],
                resolveNewStatus = function (petition) {
                    var approveNum = petition.Approvers.filter(function (a) {
                            return a.Decision === 'Approve';
                        }).length,
                        denyNum = petition.Approvers.filter(function (a) {
                            return a.Decision === 'Deny';
                        }).length,
                        newStatus = 'Pending';
                    if (petitionType.ResolutionType === 'Majority') {
                        if (approveNum > petition.Approvers.length / 2) {
                            newStatus = 'Approved';
                        } else if (denyNum > petition.Approvers.length / 2) {
                            newStatus = 'Denied';
                        }
                    } else if (petitionType.ResolutionType === 'Veto') {
                        if (denyNum >= 1) {
                            newStatus = 'Denied';
                        } else if (approveNum === petition.Approvers.length) {
                            newStatus = 'Approved';
                        }
                    } else if (petitionType.ResolutionType === 'OnePass') {
                        if (approveNum >= 1) {
                            newStatus = 'Approved';
                        } else if (denyNum === petition.Approvers.length) {
                            newStatus = 'Denied';
                        }
                    } else if (petitionType.ResolutionType === 'FirstActionWin') {
                        if (approveNum !== 0) {
                            newStatus = 'Approved';
                        } else if (denyNum !== 0) {
                            newStatus = 'Denied';
                        }
                    }
                    return newStatus;
                };
            if (params.PetitionerMemberIds && params.PetitionerMemberIds.length > 0) {
                condition['Petitioners.MemberId'] = {$in: params.PetitionerMemberIds};
            }
            if (!params.ApproverOverride) {//ApproverOverride means the user who makes the decision doesn't have to be an approver of this petition 
                condition['Approvers.UserId'] = params.UserId;
            }

            EntityCache.Petition.findOne(condition, function (error, petition) {
                var meApprover;
                if (error) {
                    callback(error, null);
                    return;
                }
                if (!petition) {
                    return callback('petition.int.pie');
                }
                meApprover = petition.Approvers.find(function (a) {
                    return a.UserId === params.UserId;
                });
                if (!meApprover && !params.ApproverOverride) {
                    return callback('petition.int.naa');
                }
                if (meApprover && meApprover.length) {
                    meApprover[0].Decision = params.Decision;
                } else {
                    petition.Approvers.push({
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName,
                        Decision: params.Decision
                    });
                }
                petition.Status = resolveNewStatus(petition);
                petition.History.push({
                    Time: Date.now(),
                    Note: params.Note,
                    Activity: params.Decision,
                    MemberId: params.MemberId,
                    UserId: params.UserId,
                    FullName: params.FullName
                });
                petition.markModified('Approvers');
                petition.save(callback);
            });
        };

        this.SubmitPetition = function (params, callback) {
            EntityCache.Petition.findOne({PetitionTypeName: params.PetitionTypeName, EntityId: params.EntityId, Status: Enums.Status.Pending}, function (error, petition) {
                if (error) {
                    callback(error, null);
                    return;
                }
                if (duplicatePetition(petition, params.Petitioners) === true) {//already exist
                    if (petition.Status === Enums.Status.Pending) {
                        return callback(null, 'server.hge.pet.tia');
                    }
                } else {
                    petition = new EntityCache.Petition(params);
                    petition.hgId = guid.v1();
                    petition.CreatedBy = params.UserId;
                    petition.ModifiedBy = params.UserId;
                    petition.History.push({
                        Time: new Date().getTime(),
                        Note: params.Note,
                        Activity: Enums.ActivityType.Submit,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    });
                }
                petition.markModified('History');
                petition.save(function (error) {
                    callback(error, 'Your petition has been submitted');
                });
            });
        };

        this.ArchivePetitions = function (params, callback) {
            var query = {
                EntityId: { $in: params.PetitionIds },
                Status: { $in: ['Pending', 'ApprovalPending'] }
            }, update = {
                $set: {
                    Status: Enums.Status.Archived,
                    ModifiedBy: params.UserId
                },
                $push: {
                    History: params.History
                }
            };
            EntityCache.Petition.update(query, update, {multi: true}, callback);
        };
        this.ArchivePetitionsByEntityIdsAndType = function (params, callback) {
            EntityCache.Petition.update({
                EntityId: {$in: params.EntityIds},
                Status: Enums.Status.Pending,
                PetitionTypeName: params.PetitionType
            }, {
                $set: {Status: Enums.Status.Archived}
            }, {
                multi: true
            }, callback);
        };
        this.ArchivePetitionsByEntityIds = function (params, callback) {
            var condition = {
                    EntityId: {$in: params.EntityIds},
                    Status: Enums.Status.Pending
                };
            EntityCache.Petition.find(condition, function (error, petitions) {
                if (error) {
                    return callback(error);
                }
                EntityCache.Petition.update(condition, {
                    $set: {Status: Enums.Status.Archived}
                }, {
                    multi: true
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, petitions);
                });
            });
        };

        this.ReplaceApproverByEntityId = function (params, callback) {
            var condition = {
                    EntityId: params.EntityId,
                    Status: Enums.Status.Pending,
                    "Approvers.UserId": params.OldApproverUserId
                };
            EntityCache.Petition.find(condition, function (error, petitions) {
                if (error) {
                    return callback(error);
                }
                EntityCache.Petition.update(condition, {
                    $set: { "Approvers.$.MemberId": params.NewApproverMemberId, "Approvers.$.UserId": params.NewApproverUserId, "Approvers.$.FullName": params.NewApproverFullName}
                }, {
                    multi: true
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, petitions);
                });
            });
        };

        this.ReplaceApprover = function (params, callback) {
            var query = {
                    EntityId: { $in: params.EntityIds },
                    "Approvers.UserId": params.OldApproverUserId
                },
                update = {
                    $set: { "Approvers.$.MemberId": params.NewApproverMemberId, "Approvers.$.UserId": params.NewApproverUserId, "Approvers.$.FullName": params.NewApproverFullName}
                };
            EntityCache.Petition.update(query, update, {multi: true}, callback);
        };
    };

module.exports = PetitionProcessor;
