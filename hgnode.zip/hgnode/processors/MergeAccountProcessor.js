'use strict';
/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    MergeAccountProcessor = function () {
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            Async = require('async'),
            HgLog = require('../framework/HgLog.js');

        function getData(key, value, dataArray) {
            var ret = dataArray.filter(function (item) {
                return item[key] === value.toLowerCase();
            });
            return ret.length ? ret[0] : '';
        }
        function coreUpdate(params, callback) {
            EntityCache[params.Entity].update(params.Query, params.Update, {multi: true}, function (error, data) {
                HgLog.debug('updating entity: ' + params.Entity + '. # of records updates:' +  data);
                callback(error);
            });
        }
        function simpleDataReplacement(params, callback) {
            HgLog.debug('Updating several records');
            var entities = [
                {
                    Entity: 'Congrat',
                    Query: {
                        MemberId: params.NewMemberRecord.hgId
                    },
                    Update: {
                        $set: {
                            MemberId: params.OldMemberRecord.hgId
                        }
                    }
                }, {
                    Entity: 'Transaction',
                    Query: {
                        UserId: params.NewMemberRecord.UserId
                    },
                    Update: {
                        $set: {
                            UserId: params.OldMemberRecord.UserId
                        }
                    }
                }, {
                    Entity: 'Conversation',
                    Query: {
                        'Creator.MemberId': params.NewMemberRecord.hgId
                    },
                    Update: {
                        $set: {
                            'Creator.MemberId': params.OldMemberRecord.hgId,
                            'Creator.UserId': params.OldMemberRecord.UserId
                        }
                    }
                }, {
                    Entity: 'Conversation',
                    Query: {
                        'Recipient.MemberId': params.NewMemberRecord.hgId
                    },
                    Update: {
                        $set: {
                            'Recipient.MemberId': params.OldMemberRecord.hgId,
                            'Recipient.UserId': params.OldMemberRecord.UserId
                        }
                    }
                }, {
                    Entity: 'SurveyAnswer',
                    Query: {
                        MemberId: params.NewMemberRecord.hgId
                    },
                    Update: {
                        $set: {
                            MemberId: params.OldMemberRecord.hgId,
                            UserId: params.OldMemberRecord.UserId
                        }
                    }
                },  {
                    Entity: 'Poll',
                    Query: {
                        MemberId: params.NewMemberRecord.hgId
                    },
                    Update: {
                        $set: {
                            MemberId: params.OldMemberRecord.hgId,
                            UserId: params.OldMemberRecord.UserId
                        }
                    }
                }
            ];
            Async.eachSeries(entities, function (daEntity, eCallback) {
                coreUpdate({
                    Entity: daEntity.Entity,
                    Query: daEntity.Query,
                    Update: daEntity.Update
                }, eCallback);
            }, function (error) {
                callback(error);
            });
        }
        function verifyData(params, callback) {
            if (!params.OldUserName || !params.NewUserName || !params.GroupId) {
                return callback('Insufficent data provided: ' + params);
            }
            var dataParams = {};
            HgLog.debug('Gathering data for', params);
            Async.waterfall([
                function (fcallback) {
                    EntityCache.Group.findOne({hgId: params.GroupId}, function (error, data) {
                        if (error || !data) {
                            HgLog.error('Cannot find params for GroupId', params.GroupId);
                            return fcallback(error || 'Cannot find params for GroupId');
                        }
                        dataParams.Group = data;
                        fcallback();
                    });
                },
                function (fcallback) {
                    EntityCache.UserInfo.find({
                        'Preference.DefaultGroupId': params.GroupId,
                        LowercaseUserName: {$in: [
                            params.OldUserName.toLowerCase(),
                            params.NewUserName.toLowerCase()
                        ]}
                    }, function (error, data) {
                        if (error || !data.length || data.length !== 2) {
                            HgLog.error('Cannot find userinfo records:', params);
                            return fcallback(error || 'Cannot find userinfo records:');
                        }
                        dataParams.OldUserInfo = getData('LowercaseUserName', params.OldUserName, data);
                        dataParams.NewUserInfo = getData('LowercaseUserName', params.NewUserName, data);
                        if (!dataParams.OldUserInfo || !dataParams.NewUserInfo) {
                            HgLog.error('Userinfo records found does not match account.');
                            return fcallback('Userinfo records found does not match account');
                        }
                        fcallback();
                    });
                },
                function (fcallback) {
                    EntityCache.Member.find({
                        GroupId: params.GroupId,
                        UserId: {$in: [
                            dataParams.OldUserInfo.hgId,
                            dataParams.NewUserInfo.hgId
                        ]}
                    }, function (error, data) {
                        if (error || !data || !data.length || data.length !== 2) {
                            HgLog.error('Cannot find Member records:', params);
                            return callback(error);
                        }
                        dataParams.OldMemberRecord = getData('UserId', dataParams.OldUserInfo.hgId, data);
                        dataParams.NewMemberRecord = getData('UserId', dataParams.NewUserInfo.hgId, data);
                        if (!dataParams.OldMemberRecord || !dataParams.NewMemberRecord) {
                            HgLog.error('Member records found does not match account: ' + params);
                            return fcallback('Member records found does not match account');
                        }
                        fcallback();
                    });
                },
                function (fcallback) {
                    EntityCache.UserSecurity.find({
                        hgId: {
                            $in: [
                                dataParams.OldUserInfo.hgId,
                                dataParams.NewUserInfo.hgId
                            ]
                        }
                    }, function (error, data) {
                        if (error || !data || !data.length || data.length !== 2) {
                            HgLog.error('Cannot find UserSecurity records:' + params);
                            return fcallback(error || 'Cannot find UserSecurity records');
                        }
                        dataParams.OldUserSecurityRecord = getData('hgId', dataParams.OldUserInfo.hgId, data);
                        dataParams.NewUserSecurityRecord = getData('hgId', dataParams.NewUserInfo.hgId, data);
                        if (!dataParams.OldUserSecurityRecord || !dataParams.NewUserSecurityRecord) {
                            HgLog.error('UserSecurity records found does not match account: ' + params);
                            return fcallback('OldUserSecurityRecord records found does not match account');
                        }
                        fcallback();
                    });
                }
            ], function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, dataParams);
            });
        }
        function createDataBackup(params, callback) {
            HgLog.debug('Creating data backup');
            EntityCache.ArchiveRecord.create([{
                ArchiveId: params.NewUserInfo.hgId,
                Collection: 'UserInfo',
                Content: params.NewUserInfo,
                Note: 'Backup before merging account'
            }, {
                ArchiveId: params.NewMemberRecord.hgId,
                Collection: 'Member',
                Content: params.NewMemberRecord,
                Note: 'Backup before merging account'
            }, {
                ArchiveId: params.NewUserSecurityRecord.hgId,
                Collection: 'UserSecurity',
                Content: params.NewUserSecurityRecord,
                Note: 'Backup before merging account'
            }], function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback();
            });
        }
        function updateUserInfo(params, callback) {
            HgLog.debug('Updating UserInfo');
            EntityCache.UserInfo.update({
                hgId: params.OldUserInfo.hgId
            }, {
                $set: {
                    UserName: params.NewUserInfo.UserName, //<--- IMPORTANT OLD account now has new UserName
                    LowercaseUserName: params.NewUserInfo.LowercaseUserName, //<--- OLD account now has new UserName
                    'UserPersonal.FirstName': params.NewUserInfo.UserPersonal.FirstName,
                    'UserPersonal.LastName': params.NewUserInfo.UserPersonal.LastName,
                    'UserPersonal.FullName': params.NewUserInfo.UserPersonal.FullName,
                    'UserPersonal.Address': params.NewUserInfo.UserPersonal.Address,
                    'UserPersonal.PrimaryEmail': params.NewUserInfo.UserPersonal.PrimaryEmail,
                    'UserPersonal.Birthdate': params.NewUserInfo.UserPersonal.Birthdate,
                    'UserPersonal.Startdate': params.NewUserInfo.UserPersonal.Startdate,
                    'Preference.HomeZip': params.NewUserInfo.Preference.HomeZip,
                    'Preference.WorkZip': params.NewUserInfo.Preference.WorkZip,
                    'Preference.NickName': params.NewUserInfo.Preference.NickName,
                    'Preference.SuppressBirthday': params.NewUserInfo.Preference.SuppressBirthday,
                    'Preference.SuppressAnniversary': params.NewUserInfo.Preference.SuppressAnniversary,
                    'UserContext.MemberTitleInGroup': params.NewUserInfo.UserContext.MemberTitleInGroup,
                    'UserContext.RolesInGroup': params.NewUserInfo.UserContext.RolesInGroup,
                    'UserContext.PermissionsInGroup': params.NewUserInfo.UserContext.PermissionsInGroup,
                    'UserContext.AggregatedSecuredTabs': params.NewUserInfo.UserContext.AggregatedSecuredTabs,
                    'UserContext.MyManagers': params.NewUserInfo.UserContext.MyManagers,
                    'Flags.WelcomeBadgePending': params.NewUserInfo.Flags.WelcomeBadgePending,
                    'Flags.TutorialPending': params.NewUserInfo.Flags.TutorialPending
                }
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback();
            });
        }
        function updateMemberInfo(params, callback) {
            HgLog.debug('Updating Member record');
            EntityCache.Member.update({
                hgId: params.OldMemberRecord.hgId
            }, {
                $set: {
                    FirstName: params.NewMemberRecord.FirstName,
                    LastName: params.NewMemberRecord.LastName,
                    FullName: params.NewMemberRecord.FullName,
                    SearchName: params.NewMemberRecord.SearchName,
                    RolesInGroup: params.NewMemberRecord.RolesInGroup,
                    AddedPermissions: params.NewMemberRecord.AddedPermissions,
                    RemovedPermissions: params.NewMemberRecord.RemovedPermissions,
                    Position: params.NewMemberRecord.Position,
                    StartingDate: params.NewMemberRecord.StartingDate,
                    LastDailyRecapSentDate: params.NewMemberRecord.LastDailyRecapSentDate,
                    MembershipStatus: params.NewMemberRecord.MembershipStatus,
                    MyManagers: params.NewMemberRecord.MyManagers,
                    Preference: {
                        RecapType: params.NewMemberRecord.Preference.RecapType || 'Daily',
                        WeekendDailyRecap: params.NewMemberRecord.Preference.WeekendDailyRecap || false
                    },
                    Location: {
                        hgId: params.NewMemberRecord.Location && params.NewMemberRecord.Location.hgId ? params.NewMemberRecord.Location.hgId : '',
                        Name: params.NewMemberRecord.Location && params.NewMemberRecord.Location.Name ? params.NewMemberRecord.Location.Name : ''
                    },
                    GroupDepartmentName: params.NewMemberRecord.GroupDepartmentName,
                    GroupDepartmentId: params.NewMemberRecord.GroupDepartmentId,
                    Integration: params.NewMemberRecord.Integration,
                    EmployeeId: params.NewMemberRecord.EmployeeId || ''
                }
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback();
            });
        }
        function updateUserSecurity(params, callback) {
            HgLog.debug('Updating UserSecurity');
            EntityCache.UserSecurity.update({
                hgId: params.OldUserSecurityRecord.hgId
            }, {
                $set: {
                    UserName: params.NewUserSecurityRecord.UserName, //<--- IMPORTANT OLD account now has new UserName
                    LowercaseUserName: params.NewUserSecurityRecord.LowercaseUserName, //<--- IMPORTANT OLD account now has new UserName
                    FirstName: params.NewUserSecurityRecord.FirstName,
                    Status: params.NewUserSecurityRecord.Status,
                    Password: params.NewUserSecurityRecord.Password,
                    Password_PBKDF2: params.NewUserSecurityRecord.Password_PBKDF2 || '', //<-- This will set new password to old account
                    PasswordSalt: params.NewUserSecurityRecord.PasswordSalt || '',
                    PasswordIterations: params.NewUserSecurityRecord.PasswordIterations || 0,
                    Roles: params.NewUserSecurityRecord.Roles,
                    Permissions: params.NewUserSecurityRecord.Permissions,
                    ActionToken: params.NewUserSecurityRecord.ActionToken,
                    FailLoginAttempts: params.NewUserSecurityRecord.FailLoginAttempts,
                    LockedOutTime: params.NewUserSecurityRecord.LockedOutTime,
                    LastRefreshTime: params.NewUserSecurityRecord.LastRefreshTime,
                    SSO: {
                        Salesforce: {
                            Username: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.Salesforce ? params.NewUserSecurityRecord.SSO.Salesforce.Username : ''
                        },
                        LinkedIn: {
                            state: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.LinkedIn ? params.NewUserSecurityRecord.SSO.LinkedIn.state : '',
                            state_ref: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.LinkedIn ? params.NewUserSecurityRecord.SSO.LinkedIn.state_ref : '',
                            access_token: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.LinkedIn ? params.NewUserSecurityRecord.SSO.LinkedIn.access_token : '',
                            expires: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.LinkedIn ? params.NewUserSecurityRecord.SSO.LinkedIn.expires : 0
                        },
                        Facebook: {
                            state_ref: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.Facebook ? params.NewUserSecurityRecord.SSO.Facebook.state_ref : '',
                            access_token: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.Facebook ? params.NewUserSecurityRecord.SSO.Facebook.access_token : '',
                            expires: params.NewUserSecurityRecord.SSO && params.NewUserSecurityRecord.SSO.Facebook ? params.NewUserSecurityRecord.SSO.Facebook.expires : ''
                        }
                    }
                }
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback();
            });
        }
        function updateTeamCollection(params, callback) {
            HgLog.debug('Updating Team Type: ' + params.TeamType);
            // get teamId for new member
            EntityCache.Team.findOne({
                GroupId: params.Group.hgId,
                Type: params.TeamType,
                'TeamMembers.MemberId': params.NewMemberRecord.hgId
            }, function (error, team) {
                if (error) {
                    return callback(error);
                }
                //pull both old and new member records
                EntityCache.Team.update({
                    GroupId: params.Group.hgId,
                    Type: params.TeamType
                }, {
                    $pull: {
                        TeamMembers: {
                            MemberId: {
                                $in: [
                                    params.NewMemberRecord.hgId,
                                    params.OldMemberRecord.hgId
                                ]
                            }
                        }
                    }
                }, {
                    multi: true
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    if (!team) {
                        return callback();
                    }
                    EntityCache.Team.update({
                        hgId: team.hgId
                    }, {
                        $addToSet: {
                            TeamMembers: {
                                MemberId: params.OldMemberRecord.hgId,
                                MemberFullName: params.NewMemberRecord.FullName,
                                TeamId: team.hgId
                            }
                        }
                    }, function (error) {
                        callback(error);
                    });
                });
            });
        }
        function updateManagerInfo(params, callback) {
            HgLog.debug('Updating Manager Records for accounts pointing to new account Id');
            EntityCache.Member.find({
                'MyManagers.MemberId': params.NewMemberRecord.hgId
            }, function (error, data) {
                if (error || !data || !data.length) {
                    return callback(error);
                }
                Async.each(data, function (mData, mCallback) {
                    mData.MyManagers.forEach(function (item) {
                        if (item.MemberId === params.NewMemberRecord.hgId) {
                            item.MemberId = params.OldMemberRecord.hgId;
                            item.UserId = params.OldMemberRecord.UserId;
                        }
                    });
                    mData.save(mCallback);
                }, function (error) {
                    callback(error);
                });
            });
        }
        function managerAlertDataUpdate(params, callback) {
            HgLog.debug('Updating Team Tab records');
            Async.parallel({
                manager: function (fcallback) {
                    EntityCache.ManagerAlert.remove({
                        ManagerMemberId: params.OldMemberRecord.hgId
                    }, function (error) {
                        fcallback(error);
                    });
                },
                report: function (fcallback) {
                    EntityCache.ManagerAlert.remove({
                        ReportMemberId: params.OldMemberRecord.hgId
                    }, function (error) {
                        fcallback(error);
                    });
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                Async.parallel({
                    manager: function (fcallback) {
                        coreUpdate({
                            Entity: 'ManagerAlert',
                            Query: {
                                ManagerMemberId: params.NewMemberRecord.hgId
                            },
                            Update: {
                                $set: {
                                    ManagerMemberId: params.OldMemberRecord.hgId
                                }
                            }
                        }, function (error) {
                            fcallback(error);
                        });
                    },
                    report: function (fcallback) {
                        coreUpdate({
                            Entity: 'ManagerAlert',
                            Query: {
                                ReportMemberId: params.NewMemberRecord.hgId
                            },
                            Update: {
                                $set: {
                                    ReportMemberId: params.OldMemberRecord.hgId
                                }
                            }
                        }, function (error) {
                            fcallback(error);
                        });
                    }
                }, function (error) {
                    callback(error);
                });
            });
        }
        function removeMemberBookmark(params, callback) {
            HgLog.debug('Updating MemberBookmark Record');
            //remove new memberId
            EntityCache.MemberBookmark.remove({
                MemberId: params.NewMemberRecord.hgId
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                EntityCache.MemberBookmark.update({
                    FollowedTrackMemberIds: params.NewMemberRecord.hgId
                }, {
                    $pull: {FollowedTrackMemberIds: params.NewMemberRecord.hgId}
                }, {
                    multi: true
                }, function (error) {
                    callback(error);
                });
            });
        }
        function removeMemberTutorial(params, callback) {
            HgLog.debug('Updating Member MemberTutorial Records');
            //remove new member
            EntityCache.MemberTutorial.remove({
                MemberId: params.NewMemberRecord.hgId
            }, function (error) {
                callback(error);
            });
        }
        function updatePointAndCreditAccounts(params, callback) {
            HgLog.debug('Merging Credit and Point accounts');
            // reconcile account by adding new account balance 
            // to new account 
            // then remove new account and leave old account
            function updateAccount(acctParams, pCallback) {
                EntityCache.CreditAccount.find({
                    OwnerId: acctParams.newACCT
                }, function (error, accounts) {
                    if (error || !accounts || !accounts.length) {
                        return pCallback(error);
                    }
                    Async.each(accounts, function (account, aCallback) {
                        if (!account.Balance) {
                            return aCallback(); // when balance is 0 no need to do anything
                        }
                        //now merge accounts
                        EntityCache.CreditAccount.findOne({
                            OwnerId: acctParams.oldACCT,
                            AccountType: account.AccountType
                        }, function (error, data) {
                            if (error) {
                                return aCallback(error);
                            }
                            if (!data) {
                                account.OwnerId = acctParams.oldACCT;
                                EntityCache.CreditAccount.create([account], aCallback);
                            } else {
                                data.Balance += account.Balance;
                                data.save(aCallback);
                            }
                        });
                    }, function (error) {
                        pCallback(error);
                    });
                });
            }
            Async.waterfall([
                function (fcallback) {
                    //USERID
                    updateAccount({
                        newACCT: params.NewMemberRecord.UserId,
                        oldACCT: params.OldMemberRecord.UserId
                    }, fcallback);
                },
                function (fcallback) {
                    //MEMBERID
                    updateAccount({
                        newACCT: params.NewMemberRecord.hgId,
                        oldACCT: params.OldMemberRecord.hgId
                    }, function (error) {
                        fcallback(error);
                    });
                },
                function (fcallback) {
                    //REMOVE NEW ACCOUNTS
                    EntityCache.CreditAccount.remove({
                        OwnerId: {
                            $in: [
                                params.NewMemberRecord.UserId,
                                params.NewMemberRecord.hgId
                            ]
                        }
                    }, function (error) {
                        fcallback(error);
                    });
                }
            ], function (error) {
                callback(error);
            });
        }
        function updateMetricsData(params, callback) {
            HgLog.debug('Merging metrics data');
            function mergeMetricsData(marams, mCallback) {
                EntityCache[marams.Entity].find({
                    m: marams.NewMemberId
                }, function (error, metrics) {
                    if (error || !metrics || !metrics.length) {
                        return mCallback(error);
                    }
                    Async.each(metrics, function (metric, aCallback) {
                        if (marams.Entity === 'MetricsMember') {
                            EntityCache[marams.Entity].findOne({
                                p: metric.p,
                                c: metric.c,
                                m: marams.OldMemberId
                            }, function (error, data) {
                                if (error) {
                                    return aCallback(error);
                                }
                                if (!data) {
                                    EntityCache[marams.Entity].create([{
                                        p: metric.p,
                                        c: metric.c,
                                        g: metric.g,
                                        m: marams.OldMemberId,
                                        t: metric.t
                                    }], function (error, result) {
                                        aCallback(error);
                                    });
                                } else {
                                    data.t += metric.t;
                                    data.save(aCallback);
                                }
                            });
                        } else if (marams.Entity === 'MetricsUserActivity') {
                            EntityCache[marams.Entity].findOne({ p: metric.p, m: marams.OldMemberId}, function (error, data) {
                                if (error || data) {
                                    return aCallback(error);
                                }
                                EntityCache[marams.Entity].create([{
                                    g: metric.g,
                                    p: metric.p,
                                    m: marams.OldMemberId
                                }], aCallback);
                            });
                        } else if (marams.Entity === 'MetricsManager') {
                            EntityCache[marams.Entity].findOne({
                                p: metric.p,
                                m: marams.OldMemberId,
                                a: metric.a,
                                c: metric.g,
                                r: metric.r
                            }, function (error, data) {
                                if (error) {
                                    return aCallback(error);
                                }
                                if (!data) {
                                    EntityCache[marams.Entity].create([{
                                        p: metric.p,
                                        g: metric.g,
                                        m: marams.OldMemberId,
                                        a: metric.a,
                                        c: metric.g,
                                        r: metric.r,
                                        t: metric.t
                                    }], aCallback);
                                } else {
                                    data.t += metric.t;
                                    data.save(aCallback);
                                }
                            });
                        }
                    }, function (error) {
                        mCallback(error);
                    });
                });
            }
            Async.waterfall([
                function (fcallback) {
                    HgLog.debug('Updating MetricsMember');
                    mergeMetricsData({
                        Entity: 'MetricsMember',
                        NewMemberId: params.NewMemberRecord.hgId,
                        OldMemberId: params.OldMemberRecord.hgId
                    }, function (error) {
                        fcallback(error);
                    });
                },
                function (fcallback) {
                    HgLog.debug('Updating MetricsUserActivity');
                    mergeMetricsData({
                        Entity: 'MetricsUserActivity',
                        NewMemberId: params.NewMemberRecord.hgId,
                        OldMemberId: params.OldMemberRecord.hgId
                    }, function (error) {
                        fcallback(error);
                    });
                },
                function (fcallback) {
                    HgLog.debug('Updating MetricsManager');
                    mergeMetricsData({
                        Entity: 'MetricsManager',
                        NewMemberId: params.NewMemberRecord.hgId,
                        OldMemberId: params.OldMemberRecord.hgId
                    }, function (error) {
                        fcallback(error);
                    });
                }
            ], function (error) {
                if (error) {
                    return callback(error);
                }
                Async.parallel({
                    mm: function (fcallback) {
                        HgLog.debug('Removing MetricsMember for new member');
                        EntityCache.MetricsMember.remove({m: params.NewMemberRecord.hgId}, function (error) {
                            fcallback(error);
                        });
                    },
                    mmm: function (fcallback) {
                        HgLog.debug('Removing MetricsUserActivity for new member');
                        EntityCache.MetricsUserActivity.remove({m: params.NewMemberRecord.hgId}, function (error) {
                            fcallback(error);
                        });
                    },
                    mua: function (fcallback) {
                        HgLog.debug('Removing MetricsManager for new member');
                        EntityCache.MetricsManager.remove({m: params.NewMemberRecord.hgId}, function (error) {
                            fcallback(error);
                        });
                    }
                }, function (error) {
                    callback(error);
                });
            });
        }
        function commentDataUpdate(params, callback) {
            HgLog.debug('Updating Comment Record');
            Async.waterfall([
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Comment',
                        Query: {
                            MemberId: params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                MemberId: params.OldMemberRecord.hgId,
                                CommenterUserhgId: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Comment',
                        Query: {
                            'Recipient.MemberId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'Recipient.MemberId': params.OldMemberRecord.hgId,
                                'Recipient.UserId': params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                }
            ], function (error) {
                callback(error);
            });
        }
        function recognitionDataUpdate(params, callback) {
            HgLog.debug('Updating Recognition Records');
            Async.waterfall([
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Recognition',
                        Query: {
                            'CreatorMember.hgId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'CreatorMember.hgId': params.OldMemberRecord.hgId,
                                'CreatorMember.UserId': params.OldMemberRecord.UserId,
                                'CreatorMember.FirstName': params.NewMemberRecord.FirstName,
                                'CreatorMember.LastName': params.NewMemberRecord.LastName,
                                'CreatorMember.FullName': params.NewMemberRecord.FullName
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Recognition',
                        Query: {
                            'RecipientMember.hgId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'RecipientMember.hgId': params.OldMemberRecord.hgId,
                                'RecipientMember.UserId': params.OldMemberRecord.UserId,
                                'RecipientMember.FirstName': params.NewMemberRecord.FirstName,
                                'RecipientMember.LastName': params.NewMemberRecord.LastName,
                                'RecipientMember.FullName': params.NewMemberRecord.FullName
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Recognition',
                        Query: {
                            'RecipientMember.hgId': params.OldMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'RecipientMember.FirstName': params.NewMemberRecord.FirstName,
                                'RecipientMember.LastName': params.NewMemberRecord.LastName,
                                'RecipientMember.FullName': params.NewMemberRecord.FullName
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Recognition',
                        Query: {
                            'CreatorMember.hgId': params.OldMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'CreatorMember.FirstName': params.NewMemberRecord.FirstName,
                                'CreatorMember.LastName': params.NewMemberRecord.LastName,
                                'CreatorMember.FullName': params.NewMemberRecord.FullName
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    EntityCache.Recognition.find({
                        RandCId: params.NewMemberRecord.hgId
                    }, function (error, recognitions) {
                        if (error || !recognitions || !recognitions.length) {
                            return fcallback(error);
                        }
                        //pull records
                        EntityCache.Recognition.update({
                            RandCId: params.NewMemberRecord.hgId
                        }, {
                            $pull: {
                                RandCId: params.NewMemberRecord.hgId
                            }
                        }, {
                            multi: true
                        }, function (error) {
                            if (error) {
                                return fcallback(error);
                            }
                            //add records
                            EntityCache.Recognition.update({
                                hgId: {$in: recognitions.map(function (item) { return item.hgId; }) }
                            }, {
                                $addToSet: {RandCId: params.OldMemberRecord.hgId}
                            }, {
                                multi: true
                            }, function (error) {
                                fcallback(error);
                            });
                        });
                    });
                },
                function (fcallback) {
                    // CongratMemberIds update
                    EntityCache.Recognition.find({
                        CongratMemberIds: params.NewMemberRecord.hgId
                    }, function (error, recognitions) {
                        if (error || !recognitions || !recognitions.length) {
                            return fcallback(error);
                        }
                        //pull records
                        EntityCache.Recognition.update({
                            CongratMemberIds: params.NewMemberRecord.hgId
                        }, {
                            $pull: {
                                CongratMemberIds: params.NewMemberRecord.hgId
                            }
                        }, {
                            multi: true
                        }, function (error) {
                            if (error) {
                                return fcallback(error);
                            }
                            //add records
                            EntityCache.Recognition.update({
                                hgId: {$in: recognitions.map(function (item) { return item.hgId; }) }
                            }, {
                                $addToSet: {CongratMemberIds: params.OldMemberRecord.hgId}
                            }, {
                                multi: true
                            }, function (error) {
                                fcallback(error);
                            });
                        });
                    });
                },
                function (fcallback) {
                    // DismissMemberIds update
                    EntityCache.Recognition.find({
                        DismissMemberIds: params.NewMemberRecord.hgId
                    }, function (error, recognitions) {
                        if (error || !recognitions || !recognitions.length) {
                            return fcallback(error);
                        }
                        //pull records
                        EntityCache.Recognition.update({
                            DismissMemberIds: params.NewMemberRecord.hgId
                        }, {
                            $pull: {
                                DismissMemberIds: params.NewMemberRecord.hgId
                            }
                        }, {
                            multi: true
                        }, function (error) {
                            if (error) {
                                return fcallback(error);
                            }
                            //add records
                            EntityCache.Recognition.update({
                                hgId: {$in: recognitions.map(function (item) { return item.hgId; }) }
                            }, {
                                $addToSet: {DismissMemberIds: params.OldMemberRecord.hgId}
                            }, {
                                multi: true
                            }, function (error) {
                                fcallback(error);
                            });
                        });
                    });
                }
            ], function (error) {
                callback(error);
            });
        }
        function performDataUpdate(params, callback) {
            HgLog.debug('Updating Perform Records');
            Async.waterfall([
                function (fcallback) {
                    coreUpdate({
                        Entity: 'PerformanceReview',
                        Query: {
                            MyMemberId: params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                MyMemberId: params.OldMemberRecord.hgId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'PerformanceReview',
                        Query: {
                            CreatedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                CreatedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'PerformanceReview',
                        Query: {
                            ModifiedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                ModifiedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    EntityCache.PerformanceReview.find({
                        'Peoples.MemberId': params.NewMemberRecord.hgId
                    }, function (error, reviews) {
                        if (error || !reviews || !reviews.length) {
                            return fcallback(error);
                        }
                        Async.each(reviews, function (review, rCallback) {
                            review.Peoples.forEach(function (item) {
                                if (item.MemberId === params.NewMemberRecord.hgId) {
                                    item.UserId = params.OldMemberRecord.UserId;
                                    item.MemberId = params.OldMemberRecord.hgId;
                                }
                            });
                            review.markModified('Peoples');
                            review.save(rCallback);
                        }, function (error) {
                            fcallback(error);
                        });
                    });
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'PerformanceCycle',
                        Query: {
                            CreatedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                CreatedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    EntityCache.PerformanceCycle.find({
                        'Cards.Assignments.Participants.EntityId': params.NewMemberRecord.hgId
                    }, function (error, cycles) {
                        if (error || !cycles || !cycles.length) {
                            return fcallback(error);
                        }
                        Async.each(cycles, function (cycle, rCallback) {
                            if (!(cycle.Assignments && cycle.Assignments.length)) {
                                return rCallback();
                            }
                            cycle.Assignments.forEach(function (assignment) {
                                if (assignment.Participants && assignment.Participants.length) {
                                    assignment.Participants.forEach(function (participant) {
                                        if (participant.EntityId === params.NewMemberRecord.hgId) {
                                            participant.EntityId = params.OldMemberRecord.hgId;
                                            participant.AvatarId = params.OldMemberRecord.UserId;
                                        }
                                    });
                                }
                            });
                            cycle.save(rCallback);
                        }, function (error) {
                            fcallback(error);
                        });
                    });
                }
            ], function (error) {
                callback(error);
            });
        }
        function trackDataUpdate(params, callback) {
            HgLog.debug('Updating Track Record');
            Async.waterfall([
                function (fcallback) {
                    coreUpdate({
                        Entity: 'CareerTrack',
                        Query: {
                            'CreatorMember.hgId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'CreatorMember.hgId': params.OldMemberRecord.hgId,
                                'CreatorMember.UserId': params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'CareerTrack',
                        Query: {
                            'AssignedMember.hgId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'AssignedMember.hgId': params.OldMemberRecord.hgId,
                                'AssignedMember.UserId': params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    //need to just replace id because of Collaborators.AccessLevel
                    EntityCache.CareerTrack.find({
                        'Collaborators.MemberId': params.NewMemberRecord.hgId
                    }, function (error, data) {
                        if (error || !data || !data.length) {
                            return fcallback(error);
                        }
                        Async.each(data, function (tData, tCallback) {
                            tData.Collaborators.forEach(function (item) {
                                if (item.MemberId === params.NewMemberRecord.hgId) {
                                    item.MemberId = params.OldMemberRecord.hgId;
                                    item.UserId = params.OldMemberRecord.UserId;
                                }
                            });
                            tData.save(tCallback);
                        }, fcallback);
                    });
                }
            ], function (error) {
                callback(error);
            });
        }
        function petitionDataUpdate(params, callback) {
            HgLog.debug('Updating Petition Records');
            function updateP(darams, pCallback) {
                EntityCache.Petition.find(darams.Query, function (error, data) {
                    if (error || !data || !data.length) {
                        return pCallback(error);
                    }
                    Async.each(data, function (petition, dCallback) {
                        if (petition[darams.Key] && petition[darams.Key].length) {
                            petition[darams.Key].forEach(function (item) {
                                if (item.MemberId === params.NewMemberRecord.hgId) {
                                    item.MemberId = params.OldMemberRecord.hgId;
                                    item.UserId = params.OldMemberRecord.UserId;
                                }
                            });
                        }
                        petition.save(dCallback);
                    }, function (error) {
                        pCallback(error);
                    });
                });
            }
            Async.waterfall([
                function (fcallback) {
                    updateP({
                        Query: {
                            'Petitioners.MemberId': params.NewMemberRecord.hgId
                        },
                        Key: 'Petitioners'
                    }, fcallback);
                },
                function (fcallback) {
                    updateP({
                        Query: {
                            'Approvers.MemberId': params.NewMemberRecord.hgId
                        },
                        Key: 'Approvers'
                    }, fcallback);
                }
            ], function (error) {
                callback(error);
            });
        }
        function goalCycleUpdate(params, callback) {
            HgLog.debug('Updating GoalCycle Records');
            Async.waterfall([
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycle',
                        Query: {
                            'CompanyGoalOwner.MemberId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'CompanyGoalOwner.MemberId': params.OldMemberRecord.hgId,
                                'CompanyGoalOwner.UserId': params.OldMemberRecord.UserId,
                                'CompanyGoalOwner.FullName': params.NewMemberRecord.FullName,
                                'CompanyGoalOwner.Title': params.NewMemberRecord.Position
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycle',
                        Query: {
                            'CycleOwner.MemberId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'CycleOwner.MemberId': params.OldMemberRecord.hgId,
                                'CycleOwner.UserId': params.OldMemberRecord.UserId,
                                'CycleOwner.FullName': params.NewMemberRecord.FullName
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycle',
                        Query: {
                            CreatedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                CreatedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycle',
                        Query: {
                            ModifiedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                ModifiedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
            ], callback);
        }
        function goalCycleParticipantUpdate(params, callback) {
            HgLog.debug('Updating GoalCycleParticipant Records');
            Async.waterfall([
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycleParticipant',
                        Query: {
                            'Owner.MemberId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'Owner.MemberId': params.OldMemberRecord.hgId,
                                'Owner.UserId': params.OldMemberRecord.UserId,
                                'Owner.FullName': params.NewMemberRecord.FullName,
                                'Owner.Title': params.NewMemberRecord.Position
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycleParticipant',
                        Query: {
                            CreatedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                CreatedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycleParticipant',
                        Query: {
                            ModifiedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                ModifiedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycleParticipant',
                        Query: {
                            ParticipantId: params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                ParticipantId: params.OldMemberRecord.hgId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'GoalCycleParticipant',
                        Query: {
                            AvatarId: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                AvatarId: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                }
            ], callback);
        }
        function goalsUpdate(params, callback) {
            HgLog.debug('Updating Goals Records');
            Async.waterfall([
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Goal',
                        Query: {
                            'Owner.MemberId': params.NewMemberRecord.hgId
                        },
                        Update: {
                            $set: {
                                'Owner.MemberId': params.OldMemberRecord.hgId,
                                'Owner.UserId': params.OldMemberRecord.UserId,
                                'Owner.FullName': params.NewMemberRecord.FullName
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Goal',
                        Query: {
                            CreatedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                CreatedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    coreUpdate({
                        Entity: 'Goal',
                        Query: {
                            ModifiedBy: params.NewMemberRecord.UserId
                        },
                        Update: {
                            $set: {
                                ModifiedBy: params.OldMemberRecord.UserId
                            }
                        }
                    }, fcallback);
                },
                function (fcallback) {
                    EntityCache.Goal.find({'History.MemberId': params.NewMemberRecord.hgId}, function (error, goals) {
                        if (error) {
                            return fcallback(error);
                        }
                        if (!goals.length) {
                            return fcallback();
                        }
                        Async.each(goals, function (goal, goalCallback) {
                            goal.History.forEach(function (item) {
                                if (item.MemberId === params.NewMemberRecord.hgId) {
                                    item.MemberId = params.OldMemberRecord.hgId;
                                    item.UserId = params.OldMemberRecord.UserId;
                                    item.FullName = params.NewMemberRecord.FullName;
                                }
                            });
                            goal.save(goalCallback);
                        }, fcallback);
                    });
                },
                function (fcallback) {
                    EntityCache.Goal.find({$or: [
                        {'KeyResults.CreatedBy': params.NewMemberRecord.UserId},
                        {'KeyResults.ModifiedBy': params.NewMemberRecord.UserId}
                    ]}, function (error, goals) {
                        if (error) {
                            return fcallback(error);
                        }
                        if (!goals.length) {
                            return fcallback();
                        }
                        Async.each(goals, function (goal, goalCallback) {
                            goal.KeyResults.forEach(function (item) {
                                if (item.CreatedBy === params.NewMemberRecord.UserId) {
                                    item.CreatedBy = params.OldMemberRecord.UserId;
                                }
                                if (item.ModifiedBy === params.NewMemberRecord.UserId) {
                                    item.ModifiedBy = params.OldMemberRecord.UserId;
                                }
                            });
                            goal.save(goalCallback);
                        }, fcallback);
                    });
                }
            ], callback);
        }
        function goalsDataUpdate(params, callback) {
            Async.waterfall([
                function (fcallback) {
                    goalCycleUpdate(params, fcallback);
                },
                function (fcallback) {
                    goalCycleParticipantUpdate(params, fcallback);
                },
                function (fcallback) {
                    goalsUpdate(params, fcallback);
                }
            ], callback);
        }
        function removeUserToken(params, callback) {
            //This will force the users to relogin
            HgLog.debug('Removing Active logged in token');
            Async.parallel({
                uiwt: function (fcallback) {
                    EntityCache.UserInfoWithToken.remove({
                        hgId: {
                            $in: [
                                params.OldUserInfo.hgId,
                                params.NewUserInfo.hgId
                            ]
                        }
                    }, function (error) {
                        fcallback(error);
                    });
                },
                uswt: function (fcallback) {
                    EntityCache.UserSecurityWithToken.remove({
                        hgId: {
                            $in: [
                                params.OldUserInfo.hgId,
                                params.NewUserInfo.hgId
                            ]
                        }
                    }, function (error) {
                        fcallback(error);
                    });
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback();
            });
        }
        function removeNewAccount(params, callback) {
            HgLog.debug('Removing New Account');
            Async.parallel({
                ui: function (fcallback) {
                    EntityCache.UserInfo.remove({hgId: params.NewUserInfo.hgId}, fcallback);
                },
                m: function (fcallback) {
                    EntityCache.Member.remove({hgId: params.NewMemberRecord.hgId}, fcallback);
                },
                us: function (fcallback) {
                    EntityCache.UserSecurity.remove({hgId: params.NewUserSecurityRecord.hgId}, fcallback);
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback();
            });
        }
        function mergeAccount(params, callback) {
            HgLog.debug('Merge (new) Account: ' + params.NewUserInfo.UserName + ' -----> into (old) Account: ' + params.OldUserInfo.UserName);
            Async.waterfall([
                function (fcallback) {
                    createDataBackup(params, fcallback);
                },
                function (fcallback) {
                    updateUserInfo(params, fcallback);
                },
                function (fcallback) {
                    updateMemberInfo(params, fcallback);
                },
                function (fcallback) {
                    updateUserSecurity(params, fcallback);
                },
                function (fcallback) {
                    params.TeamType = 'Department';
                    updateTeamCollection(params, fcallback);
                },
                function (fcallback) {
                    params.TeamType = 'Pod';
                    updateTeamCollection(params, fcallback);
                },
                function (fcallback) {
                    updateManagerInfo(params, fcallback);
                },
                function (fcallback) {
                    managerAlertDataUpdate(params, fcallback);
                },
                function (fcallback) {
                    removeMemberBookmark(params, fcallback);
                },
                function (fcallback) {
                    removeMemberTutorial(params, fcallback);
                },
                function (fcallback) {
                    updatePointAndCreditAccounts(params, fcallback);
                },
                function (fcallback) {
                    simpleDataReplacement(params, fcallback);
                },
                function (fcallback) {
                    updateMetricsData(params, fcallback);
                },
                function (fcallback) {
                    commentDataUpdate(params, fcallback);
                },
                function (fcallback) {
                    recognitionDataUpdate(params, fcallback);
                },
                function (fcallback) {
                    trackDataUpdate(params, fcallback);
                },
                function (fcallback) {
                    performDataUpdate(params, fcallback);
                },
                function (fcallback) {
                    petitionDataUpdate(params, fcallback);
                },
                function (fcallback) {
                    goalsDataUpdate(params, fcallback);
                },
                function (fcallback) {
                    removeUserToken(params, fcallback);
                },
                function (fcallback) {
                    removeNewAccount(params, fcallback);
                }
            ], callback);
        }
        this.MergeAccount = function (params, callback) {
            verifyData(params, function (error, data) {
                if (error) {
                    return callback(error);
                }
                mergeAccount(data, callback);
            });
        };
    };

module.exports = MergeAccountProcessor;