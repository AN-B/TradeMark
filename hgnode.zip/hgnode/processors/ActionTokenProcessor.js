/*jslint node:true es5:true*/
/*
    This entire business layer exists for the sole purpose of the Authorize method.
*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ActionToken = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EntityEnums = require('../enums/EntityEnums');

        this.GetActionToken = function (params, callback) {
            EntityCache.ActionToken.findOne({hgId: params.ActionTokenId}, callback);
        };

        this.GetPendingUserActionTokens = function (params, callback) {
            EntityCache.ActionToken.find({
                Type: EntityEnums.ActionTokenType.MemberInvitation,
                Status: EntityEnums.ActionTokenStatus.Pending,
                ExpireDate: { $lte: Date.now() }
            }, function (error, actionTokens) {
                if (error || !actionTokens.length) {
                    return callback(error, []);
                }
                EntityCache.ActionToken.update({
                    hgId: { $in: actionTokens.map(function (item) { return item.hgId; })}
                }, {
                    $set: {
                        Status: EntityEnums.ActionTokenStatus.Fullfilled
                    }
                }, {
                    multi: true
                }, function (error) {
                    callback(error, actionTokens);
                });
            });
        };
    };

module.exports = ActionToken;
