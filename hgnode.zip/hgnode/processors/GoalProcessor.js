/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    DateHelper = require('../util/DateHelper.js'),
    GoalProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            GoalEnums = require('../enums/GoalEnums.js'),
            Enums = require('../enums/EntityEnums.js'),
            ArchiveRecordEnums = require('../enums/ArchiveRecordEnums.js'),
            HGActivityLog = require('../framework/HGActivityLog.js'),
            HgLog = require('../framework/HgLog'),
            guid = require('node-uuid'),
            async = require('async'),
            activeStatuses = [
                GoalEnums.GoalStatus.Editing,
                GoalEnums.GoalStatus.SubmittedForSet,
                GoalEnums.GoalStatus.InProgress,
                GoalEnums.GoalStatus.PendingClosure,
                GoalEnums.GoalStatus.SubmittedForClosure,
                GoalEnums.GoalStatus.Closed
            ],
            outStandingGoalStatuses = [
                GoalEnums.GoalStatus.Editing,
                GoalEnums.GoalStatus.SubmittedForSet,
                GoalEnums.GoalStatus.InProgress,
                GoalEnums.GoalStatus.PendingClosure,
                GoalEnums.GoalStatus.SubmittedForClosure
            ],
            postSetGoalStatuses = [
                GoalEnums.GoalStatus.InProgress,
                GoalEnums.GoalStatus.PendingClosure,
                GoalEnums.GoalStatus.SubmittedForClosure
            ],
            outStandingParticipantStatuses = [
                GoalEnums.ParticipantStatus.PendingDelivery,
                GoalEnums.ParticipantStatus.NotStarted,
                GoalEnums.ParticipantStatus.Setting,
                GoalEnums.ParticipantStatus.SubmittedForSet,
                GoalEnums.ParticipantStatus.InProgress,
                GoalEnums.ParticipantStatus.SubmittedForClosure
            ],
            activeCylceStatuses = [
                GoalEnums.CycleStatus.Building,
                GoalEnums.CycleStatus.Draft,
                GoalEnums.CycleStatus.Pending,
                GoalEnums.CycleStatus.InProgress
            ],
            calculateGoalPercentage = function (goal) {
                var avgKeyResultWeight,
                    completitionPercentage = 0;
                if (goal.KeyResultWeightType === GoalEnums.WeightType.Equal) {
                    avgKeyResultWeight = 100 / goal.KeyResults.length;
                }
                goal.KeyResults.forEach(function (keyResult) {
                    var krPercentage = 0,
                        weightedKrPercentage;
                    keyResult.Progress = keyResult.Progress || 0;
                    if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Numeric) {
                        if (keyResult.Target) {
                            krPercentage = keyResult.Progress / keyResult.Target * 100;
                        }
                    }
                    if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Percentage) {
                        krPercentage = keyResult.Progress;
                    }
                    if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Binary) {
                        krPercentage = keyResult.Progress;
                    }
                    if (goal.KeyResultWeightType === GoalEnums.WeightType.Equal) {
                        weightedKrPercentage = krPercentage * avgKeyResultWeight;
                    } else {
                        weightedKrPercentage = krPercentage * keyResult.Weight;
                    }
                    completitionPercentage += weightedKrPercentage;
                });
                return completitionPercentage / 100;
            };

        this.DefaultEntityName = 'Goal';

        this.GetGoalsByCycleIdsAndOwnerId = function (params, callback) {
            var statusList = postSetGoalStatuses.slice(0);
            if (!params.CycleIds.length || !params.OwnerMemberId) {
                return callback(null, []);
            }
            if (params.IncludeClosed) {
                statusList.push(GoalEnums.GoalStatus.Closed);
            }
            EntityCache.Goal.find({
                CycleId: {$in: params.CycleIds},
                'Owner.MemberId': params.OwnerMemberId,
                Status: {$in: statusList}
            }, callback);
        };

        this.ArchiveGoalsByTemplateId = function (params, callback) {
            EntityCache.Goal.update({
                TemplateId: params.TemplateId,
                GroupId: params.GroupId,
                Status: {$in: outStandingGoalStatuses}
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.Archived
                }
            }, {
                multi: true
            }, callback);
        };

        this.UnassignTemplateGoal = function (params, callback) {
            EntityCache.Goal.update({
                TemplateId: params.TemplateId,
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                "Owner.MemberId": {
                    $in: params.MemberIds
                },
                Status: {$in: outStandingGoalStatuses}
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.Archived
                }
            }, {
                multi: true
            }, callback);
        };

        this.UnassignTemplateByCycle = function (params, callback) {
            EntityCache.Goal.update({
                TemplateId: params.TemplateId,
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: outStandingGoalStatuses}
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.Archived
                }
            }, {
                multi: true
            }, callback);
        };

        this.AssignTemplateGoalToOneMemberInCycle = function (params, callback) {
            var goal = new EntityCache.Goal(params.Template);
            delete goal._id;
            goal.isNew = true;
            goal.hgId = guid.v1();
            goal.CreatedBy = params.UserId;
            goal.ModifiedBy = params.UserId;
            goal.CycleId = params.Cycle.hgId;
            goal.CycleTitle = params.Cycle.Title;
            goal.IsTemplate = false;
            goal.TemplateId = params.Template.hgId;
            goal.Participant = {
                ParticipantType: params.Participant.ParticipantType,
                ParticipantId: params.Participant.ParticipantId,
                AvatarId: params.Member.UserId,
                Name: params.Member.FullName
            };
            goal.Owner = {
                MemberId: params.Member.hgId,
                UserId: params.Member.UserId,
                FullName: params.Member.FullName,
                Title: params.Member.Position
            };
            goal.Approver = params.Member.MyManagers.length && params.Member.MyManagers[0].MemberId ? {
                MemberId: params.Member.MyManagers[0].MemberId,
                UserId: params.Member.MyManagers[0].UserId,
                FullName: params.Member.MyManagers[0].FullName,
            } : {};
            goal.save(callback);
        };

        this.GetActiveGoalsByCycleIdsAndOwnerId = function (params, callback) {
            if (!params.CycleIds.length || !params.OwnerMemberId) {
                return callback(null, []);
            }
            EntityCache.Goal.find({
                CycleId: {$in: params.CycleIds},
                'Owner.MemberId': params.OwnerMemberId,
                Status: {$in: activeStatuses}
            }, callback);
        };

        this.GetCycleGoalsByOwnerId = function (params, callback) {
            var query = {
                CycleId: {$exists: true},
                Status: {$in: [GoalEnums.GoalStatus.InProgress, GoalEnums.GoalStatus.Closed]},
                ModifiedDate: {$gte: params.StartDate, $lte: params.EndDate},
                'Owner.MemberId': params.OwnerMemberId,
                'Participant.ParticipantType': GoalEnums.ParticipantType.Member
            };
            if (params.AccessMode === Enums.ProfileAccess.Manager) {
                query.$or = [
                    {'Approver.MemberId': params.ViewerMemberId},
                    {IsPublic: true}
                ];
            }
            EntityCache.Goal.find(query).sort({ModifiedDate: -1}).exec(callback);
        };

        this.GetTotalAdhocGoalsForClosePrompt = function (params, callback) {
            var condition = {
                    Status: {$in: [GoalEnums.GoalStatus.Editing, GoalEnums.GoalStatus.InProgress, GoalEnums.GoalStatus.PendingClosure]},
                    ClosePromptDate : {
                        $lte: Date.now() + 24 * 3600 * 1000,//the ClosePromptDate is coming within 24 hours
                        $gt: Date.now() //but has not passed
                    },
                    CycleId: {$exists: false}
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.Goal.count(condition, callback);
        };

        this.GetAdhocGoalsForClosePromptBatch = function (params, callback) {
            var condition = {
                    Status: {$in: [GoalEnums.GoalStatus.Editing, GoalEnums.GoalStatus.InProgress, GoalEnums.GoalStatus.PendingClosure]},
                    ClosePromptDate : {
                        $lte: Date.now() + 24 * 3600 * 1000,//the ClosePromptDate is coming within 24 hours
                        $gt: Date.now() //but has not passed
                    },
                    CycleId: {$exists: false}
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.Goal.find(condition)
                .sort({'Owner.FullName': -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.SyncGoalCheckInFrequency = function (params, callback) {
            EntityCache.Goal.update({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                'Participant.ParticipantType': params.ParticipantType
            }, {
                $set: {CheckInFrequency: params.ToValue}
            }, {
                multi: true
            }, function (error, count) {
                if (error) {
                    return callback(error);
                }
                if (!count) {
                    return callback(null, []);
                }
                EntityCache.Goal.find({
                    GroupId: params.GroupId,
                    CycleId: params.CycleId,
                    'Participant.ParticipantType': params.ParticipantType
                }, callback);
            });
        };

        this.SyncCycleTitle = function (params, callback) {
            EntityCache.Goal.update({
                CycleId: params.CycleId,
                GroupId: params.GroupId
            }, {
                $set: {CycleTitle: params.ToValue}
            }, {
                multi: true
            }).exec(callback);
        };

        this.GetCollaboratorTotalNumber = function (params, callback) {
            EntityCache.GoalCollaborator.count({GoalId: params.GoalId}, callback);
        };

        this.GetApproverByGoalId = function (params, callback) {
            EntityCache.Goal.findOne({hgId: params.GoalId}, function (error, goal) {
                if (error || !goal) {
                    return callback('goal.prc.elg');
                }
                callback(null, goal.Approver);
            });
        };

        this.GetCollaboratorsByMemberId = function (params, callback) {
            EntityCache.GoalCollaborator.find({
                MemberId: params.MemberId,
                GroupId: params.GroupId
            }, callback);
        };

        this.GetCollaboratorsByGoalId = function (params, callback) {
            var condition = {
                    GoalId: params.GoalId
                };
            if (params.SearchTerm) {
                condition.FullName = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.GoalCollaborator.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.SetApprover = function (params, callback) {
            EntityCache.Goal.findOne({hgId: params.GoalId}, function (error, goal) {
                if (error || !goal) {
                    return callback('goal.prc.elg');
                }
                EntityCache.Goal.update({
                    hgId: params.GoalId
                }, {
                    $set: {
                        Approver: {
                            MemberId: params.ApproverMemberId,
                            UserId: params.ApproverUserId,
                            FullName: params.ApproverFullname
                        }
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        GoalId: goal.hgId,
                        OldApprover: goal.Approver,
                        NewApprover: {
                            MemberId: params.ApproverMemberId,
                            UserId: params.ApproverUserId,
                            FullName: params.ApproverFullname
                        }
                    });
                });
            });
        };

        this.RemoveCollaborator = function (params, callback) {
            EntityCache.GoalCollaborator.remove({
                GoalId: params.GoalId,
                MemberId: params.CollaboratorMemberId
            }, callback);
        };

        this.AddCollaborator = function (params, callback) {
            EntityCache.Goal.findOne({hgId: params.GoalId}, function (error, goal) {
                if (error) {
                    return callback(error);
                }
                if (!goal) {
                    return callback('goal.prc.elg');
                }
                EntityCache.GoalCollaborator.findOne({
                    GoalId: params.GoalId,
                    MemberId: params.CollaboratorMemberId
                }, function (error, collaborator) {
                    if (error) {
                        return callback(error);
                    }
                    if (collaborator) {
                        return callback(null, {
                            Goal: goal,
                            Collaborator: collaborator
                        });
                    }
                    collaborator = new EntityCache.GoalCollaborator({
                        hgId: guid.v1(),
                        MemberId: params.CollaboratorMemberId,
                        UserId: params.CollaboratorUserId,
                        FullName: params.CollaboratorFullname,
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId,
                        GoalId: params.GoalId,
                        GroupId: params.GroupId
                    });
                    collaborator.save(function (error) {
                        callback(error, {
                            Goal: goal,
                            Collaborator: collaborator
                        });
                    });
                });
            });
        };

        this.UpdateGoalWeights = function (params, callback) {
            async.each(params.Goals, function (goal, gCallback) {
                goal.save(gCallback);
            }, callback);
        };

        this.GetAlignGoalCandidates = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                'Participant.ParticipantType': params.ParticipantType,
                Status: {$in: [
                    GoalEnums.GoalStatus.InProgress,
                    GoalEnums.GoalStatus.PendingClosure,
                    GoalEnums.GoalStatus.SubmittedForClosure,
                    GoalEnums.GoalStatus.Closed
                ]}
            };
            if (params.ParticipantId) {
                condition['Participant.ParticipantId'] = params.ParticipantId;
            }
            EntityCache.Goal.find(condition, callback);
        };

        this.GetGoalsByCycleIdAndParticipant = function (params, callback) {
            EntityCache.Goal.find({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                'Participant.ParticipantType': params.ParticipantType,
                'Participant.ParticipantId': params.ParticipantId,
                Status: {$in: activeStatuses}
            }, callback);
        };

        this.SetUpToDateForGoals = function (params) {
            EntityCache.Goal.update({
                hgId: {$in: params.GoalIds}
            }, {
                $set: {UpToDate: params.UpToDate}
            }, {
                multi: true
            }).exec();
        };

        this.GetGoalsByOwnerName = function (params, callback) {
            EntityCache.Goal.find({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                'Participant.ParticipantType': params.ParticipantType,
                'Owner.FullName': {$regex: params.Search, $options: 'i'},
                Status: {$in: activeStatuses}
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetGoalsByCycleIdAndType = function (params, callback) {
            EntityCache.Goal.find({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: activeStatuses},
                'Participant.ParticipantType': params.ParticipantType
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetIndividualGoalsTotal = function (params, callback) {
            EntityCache.Goal.count({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: activeStatuses},
                'Participant.ParticipantType': GoalEnums.ParticipantType.Member
            }, callback);
        };
        this.GetGoalCountsByTeams = function (params, callback) {
            EntityCache.Goal.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    CycleId: params.CycleId,
                    Status: {$in: activeStatuses},
                    'Participant.ParticipantType': GoalEnums.ParticipantType.Team
                }},
                {$group: { _id: '$Participant.ParticipantId', count: { $sum: 1 }}}
            ], callback);
        };
        this.GetMetricsByCycleId = function (params, callback) {
            var buildCheckInCondition = function (params) {
                    return params.CheckIns.map(function (checkIn) {
                        return {
                            'Participant.ParticipantType': checkIn.ParticipantType,
                            LastCheckInDate: {$gte: checkIn.CutoffDate}
                        };
                    });
                },
                metrics = {
                    TotalGoalNumber: 0,
                    EditingGoalNumber: 0,
                    SubmittedForSetGoalNumber: 0,
                    InProgressGoalNumber: 0,
                    PendingClosureGoalNumber: 0,
                    SubmittedForClosureGoalNumber: 0,
                    ClosedGoalNumber: 0,
                    OntimeGoalNumber: 0,
                    AvgGoalCompletePercentage: 0
                };
            EntityCache.Goal.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    CycleId: params.CycleId,
                    Status: {$in: activeStatuses}
                }},
                {$group:
                    { _id: '$Status', count: { $sum: 1 }}
                    }
            ], function (error, metricsByStatus) {
                if (error) {
                    return callback(error);
                }
                var checkInCondition = buildCheckInCondition(params);
                checkInCondition.push({
                    UpToDate: true
                });
                EntityCache.Goal.aggregate([
                    {$match: {
                        GroupId: params.GroupId,
                        CycleId: params.CycleId,
                        Status: GoalEnums.GoalStatus.InProgress,
                        $or: checkInCondition
                    }},
                    {$group: {_id: '$Status', count: {$sum: 1}, sumCompletition: {$sum: '$PercentCompletion'}} }
                ], function (error, metricsByCheckInAndCompletion) {
                    if (error) {
                        return callback(error);
                    }
                    metricsByStatus.forEach(function (ms) {
                        metrics.TotalGoalNumber += ms.count;
                        switch (ms._id) {
                        case GoalEnums.GoalStatus.Editing:
                            metrics.EditingGoalNumber = ms.count;
                            break;
                        case GoalEnums.GoalStatus.SubmittedForSet:
                            metrics.SubmittedForSetGoalNumber = ms.count;
                            break;
                        case GoalEnums.GoalStatus.InProgress:
                            metrics.InProgressGoalNumber = ms.count;
                            break;
                        case GoalEnums.GoalStatus.PendingClosure:
                            metrics.PendingClosureGoalNumber = ms.count;
                            break;
                        case GoalEnums.GoalStatus.SubmittedForClosure:
                            metrics.SubmittedForClosureGoalNumber = ms.count;
                            break;
                        case GoalEnums.GoalStatus.Closed:
                            metrics.ClosedGoalNumber = ms.count;
                            break;
                        default:
                            break;
                        }
                    });

                    if (metricsByCheckInAndCompletion && metricsByCheckInAndCompletion.length) {
                        metrics.OntimeGoalNumber = metricsByCheckInAndCompletion[0].count;
                        if (metrics.InProgressGoalNumber) {
                            metrics.AvgGoalCompletePercentage = metricsByCheckInAndCompletion[0].sumCompletition / metrics.InProgressGoalNumber;
                        }
                    }
                    callback(null, metrics);
                });
            });
        };
        this.GetGoalsByIds = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    Status: {$in: activeStatuses},
                    hgId: {$in: params.GoalIds}
                };
            if (params.SearchTerm) {
                condition.$or = [
                    { CycleTitle: {$regex: params.SearchTerm, $options: 'i'} },
                    { Name: {$regex: params.SearchTerm, $options: 'i'} },
                    { 'Owner.FullName': {$regex: params.SearchTerm, $options: 'i'} }
                ];
            }

            EntityCache.Goal.find(condition)
                .sort({CycleTitle: 1, Name: 1, 'Owner.FullName': 1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetGoalsByCycleIdsAndParticipants = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    Status: {$in: outStandingGoalStatuses},
                    CycleId: {$in: params.CycleIds},
                    'Participant.ParticipantType': params.ParticipantType,
                    'Participant.ParticipantId': {$in: params.ParticipantIds}
                };
            if (params.Closed) {
                condition.Status = GoalEnums.GoalStatus.Closed;
            }
            EntityCache.Goal.find(condition)
                .sort({CreatedDate: -1})
                .exec(callback);
        };
        this.GetGoalsByCycleIdsAndType = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    Status: {$in: outStandingGoalStatuses},
                    CycleId: {$in: params.CycleIds},
                    'Participant.ParticipantType': params.ParticipantType
                };
            if (params.Closed) {
                condition.Status = GoalEnums.GoalStatus.Closed;
            }
            EntityCache.Goal.find(condition)
                .sort({CreatedDate: -1})
                .exec(callback);
        };
        this.GetAdhocGoalsByOwnerDateRange = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                CycleId: {$exists: false},
                Status: {$in: [GoalEnums.GoalStatus.InProgress, GoalEnums.GoalStatus.Closed]},
                ModifiedDate: {$gte: params.StartDate, $lte: params.EndDate},
                'Owner.MemberId': params.OwnerMemberId,
                'Participant.ParticipantType': GoalEnums.ParticipantType.Member
            };
            if (params.AccessMode === Enums.ProfileAccess.Manager) {
                query.$or = [
                    {'Approver.MemberId': params.ViewerMemberId},
                    {IsPublic: true}
                ];
            }
            EntityCache.Goal.find(query).sort({ModifiedDate: -1}).exec(callback);
        };
        this.GetAdhocGoalNumberByMemberId = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    'Owner.MemberId': params.MemberId,
                    CycleId: null,
                    Status: {$in: activeStatuses},
                    'Participant.ParticipantType': GoalEnums.ParticipantType.Member
                };
            if (params.CurUserMemberId !== params.MemberId) {
                condition.IsPublic = true;
            }
            EntityCache.Goal.count(condition, callback);
        };

        this.GetClosedGoalNumberByMemberId = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    'Owner.MemberId': params.MemberId,
                    Status: GoalEnums.GoalStatus.Closed,
                    $or: [
                        { IsPublic: true },
                        { 'Collaborators.MemberId': params.CurUserMemberId},
                        {'Approver.MemberId': params.CurUserMemberId},
                        {'Owner.MemberId': params.CurUserMemberId}
                    ]
                };
            EntityCache.Goal.count(condition, callback);
        };

        this.GetIndividualGoalsByMemberId = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    'Owner.MemberId': params.MemberId,
                    Status: {$in: outStandingGoalStatuses},
                    'Participant.ParticipantType': GoalEnums.ParticipantType.Member,
                    $or: [
                        { IsPublic: true },
                        { 'Collaborators.MemberId': params.CurUserMemberId},
                        {'Approver.MemberId': params.CurUserMemberId},
                        {'Owner.MemberId': params.CurUserMemberId}
                    ]
                };
            if (params.Closed) {
                condition.Status = GoalEnums.GoalStatus.Closed;
            }
            if (params.CollaboratingGoalIds && params.CollaboratingGoalIds.length) {
                condition.$or.push({
                    hgId: {$in: params.CollaboratingGoalIds}
                });
            }
            EntityCache.Goal.find(condition)
                .sort({CreatedDate: -1})
                .exec(callback);
        };

        this.GetGoalsByMemberId = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    'Owner.MemberId': params.MemberId,
                    Status: {$in: outStandingGoalStatuses},
                    $or: [
                        { IsPublic: true },
                        { 'Collaborators.MemberId': params.CurUserMemberId},
                        {'Approver.MemberId': params.CurUserMemberId},
                        {'Owner.MemberId': params.CurUserMemberId}
                    ]
                };
            if (params.Closed) {
                condition.Status = GoalEnums.GoalStatus.Closed;
            }
            if (params.CollaboratingGoalIds && params.CollaboratingGoalIds.length) {
                condition.$or.push({
                    hgId: {$in: params.CollaboratingGoalIds}
                });
            }
            EntityCache.Goal.find(condition)
                .sort({CreatedDate: -1})
                .exec(callback);
        };

        this.GetGoalById = function (params, callback) {
            EntityCache.Goal.findOne({GroupId: params.GroupId, hgId: params.GoalId}, callback);
        };

        this.GetTemplateById = function (params, callback) {
            EntityCache.Goal.findOne({
                GroupId: params.GroupId,
                hgId: params.TemplateId,
                IsTemplate: true
            }, function (error, template) {
                if (error || !template) {
                    return callback("goal.int.elt");
                }
                callback(null, template);
            });
        };

        this.CloseGoalsForOffboardedMember = function (params, callback) {
            var condition = {
                    'Owner.MemberId': params.MemberId,
                    Status: {$in: activeStatuses}
                };
            EntityCache.Goal.find(condition, function (error, goals) {
                if (error) {
                    return callback(error);
                }
                if (!goals.length) {
                    return callback(null, []);
                }
                EntityCache.Goal.update(condition, {
                    $set: {Status: GoalEnums.GoalStatus.Closed},
                    $addToSet: {
                        History: {
                            Time: Date.now(),
                            Note: 'goal.prc.acd',
                            Activity: GoalEnums.ActivityType.GoalClosed,
                            UserId: params.UserId
                        }
                    }
                }, {multi: true}, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, goals);
                });
            });
        };

        this.ArchiveOutstandingGoalsInCycleByParticipant = function (params, callback) {
            var condition = {
                    CycleId: params.CycleId,
                    'Participant.ParticipantId': params.ParticipantId,
                    'Participant.ParticipantType': params.ParticipantType,
                    Status: {$in: activeStatuses}
                };
            EntityCache.Goal.find(condition, function (error, goals) {
                if (error) {
                    return callback(error);
                }
                if (!goals.length) {
                    return callback(null, []);
                }
                EntityCache.Goal.update(condition, {
                    $set: {Status: GoalEnums.GoalStatus.Archived},
                    $addToSet: {
                        History: {
                            Time: Date.now(),
                            Note: 'goal.prc.acd',
                            Activity: GoalEnums.ActivityType.GoalArchived,
                            UserId: params.UserId
                        }
                    }
                }, {multi: true}, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, goals);
                });
            });
        };
        this.ArchiveOutstandingGoalsInCycle = function (params, callback) {
            var condition = {
                    CycleId: params.CycleId,
                    Status: {$in: activeStatuses}
                };
            EntityCache.Goal.find(condition, function (error, goals) {
                if (error) {
                    return callback(error);
                }
                if (!goals.length) {
                    return callback(null, []);
                }
                EntityCache.Goal.update(condition, {
                    $set: {Status: GoalEnums.GoalStatus.Archived},
                    $addToSet: {
                        History: {
                            Time: Date.now(),
                            Note: 'goal.prc.acd',
                            Activity: GoalEnums.ActivityType.GoalArchived,
                            UserId: params.UserId
                        }
                    }
                }, {multi: true}, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, goals);
                });
            });
        };

        this.CloseOutstandingGoalsInCycle = function (params, callback) {
            var condition = {
                    CycleId: params.CycleId,
                    Status: {$in: activeStatuses}
                };
            EntityCache.Goal.find(condition, function (error, goals) {
                if (error) {
                    return callback(error);
                }
                if (!goals.length) {
                    return callback(null, []);
                }
                EntityCache.Goal.update(condition, {
                    $set: {Status: GoalEnums.GoalStatus.Closed},
                    $addToSet: {
                        History: {
                            Time: Date.now(),
                            Note: 'goal.prc.ccd',
                            Activity: GoalEnums.ActivityType.GoalClosed,
                            UserId: params.UserId
                        }
                    }
                }, {multi: true}, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, goals);
                });
            });
        };

        this.UpdateKeyResults = function (params, callback) {
            EntityCache.Goal.findOne({hgId: params.GoalId}, function (err, goal) {
                var changes = [];
                if (err || !goal) {
                    return callback('goal.prc.elg');
                }
                if (goal.Status !== GoalEnums.GoalStatus.InProgress) {
                    return callback('goal.prc.gsi');
                }
                if (!goal.KeyResults || goal.KeyResults.length < 1) {
                    return callback('goal.prc.mkr');
                }
                if (params.ProgressStatus) {//backward compatibility for Mobile remove when mobile supports progress status
                    goal.ProgressStatus = params.ProgressStatus;
                }
                goal.KeyResults.forEach(function (krInDb) {
                    var krInPayload = params.KeyResults.filter(function (k) {
                            return k.hgId === krInDb.hgId;
                        }),
                        newProgress;
                    if (krInPayload.length) {
                        newProgress = parseFloat(krInPayload[0].Progress);
                        if (krInDb.Progress !== newProgress) {
                            changes.push({
                                hgId: krInDb.hgId,
                                Name: krInDb.Name,
                                MemberId: params.MemberId,
                                UserId: params.UserId,
                                FullName: params.FullName,
                                OldValue: krInDb.Progress,
                                NewValue: newProgress,
                                Measure: krInDb.Measure,
                                Target: krInDb.Target,
                                Prefix: krInDb.Prefix,
                                Suffix: krInDb.Suffix
                            });
                            krInDb.Progress = newProgress;
                        }
                    }
                });
                goal.LastCheckInDate = Date.now();
                goal.UpToDate = true;
                goal.PercentCompletion = calculateGoalPercentage(goal);
                goal.markModified('PercentCompletion');
                goal.markModified('History');
                goal.markModified('KeyResults');
                goal.save(function (err) {
                    callback(err, {UpdatedGoal: goal, Changes: changes});
                });
            });
        };

        this.GetUnclosedGoalsForParticipantByCycleId = function (params, callback) {
            var condition = {
                CycleId: params.CycleId,
                'Participant.ParticipantType': params.ParticipantType,
                'Participant.ParticipantId': params.ParticipantId,
                Status: {$in: [GoalEnums.GoalStatus.Editing, GoalEnums.GoalStatus.SubmittedForSet, GoalEnums.GoalStatus.InProgress, GoalEnums.GoalStatus.PendingClosure, GoalEnums.GoalStatus.SubmittedForClosure]}
            };
            EntityCache.Goal.find(condition, function (err, goals) {
                callback(err, goals);
            });
        };

        this.GetUnsetGoalsForParticipantByCycleId = function (params, callback) {
            var condition = {
                CycleId: params.CycleId,
                'Participant.ParticipantType': params.ParticipantType,
                'Participant.ParticipantId': params.ParticipantId,
                Status: {$in: [GoalEnums.GoalStatus.Editing, GoalEnums.GoalStatus.SubmittedForSet]}
            };
            EntityCache.Goal.find(condition, function (err, goals) {
                callback(err, goals);
            });
        };

        this.GetGoalsByCycleId = function (params, callback) {//this may later support pagination and field projection
            EntityCache.Goal.find({
                CycleId: params.CycleId,
                Status: {$in: activeStatuses}
            }, function (err, goals) {
                callback(err, goals);
            });
        };

        this.GetGoalsForParticipantByCycleId = function (params, callback) {
            EntityCache.Goal.find({
                CycleId: params.CycleId,
                'Participant.ParticipantType': params.ParticipantType,
                'Participant.ParticipantId': params.ParticipantId,
                Status: {$in: activeStatuses}
            }, function (err, goals) {
                callback(err, goals);
            });
        };

        this.RejectClose = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.InProgress,
                    ModifiedBy: params.UserId
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Note: params.Note,
                        Activity: GoalEnums.ActivityType.ClosureRejected,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName,
                        ArchiveId: params.PetitionId
                    }
                }
            }, {
                new: true
            }, function (err, goal) {
                if (err) {
                    return callback(err);
                }
                HGActivityLog.Archive({
                    ArchiveId: params.PetitionId,
                    Collection: ArchiveRecordEnums.Collection.Goal,
                    Content: goal,
                    Note: ArchiveRecordEnums.Reason.GoalClosureRejected,
                    CreatedBy: params.UserId
                }, function (error) {
                    callback(error, goal);
                });
            });
        };

        this.RejectSet = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.Editing,
                    ModifiedBy: params.UserId
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Note: params.Note,
                        Activity: GoalEnums.ActivityType.SetRejected,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName,
                        ArchiveId: params.PetitionId
                    }
                }
            }, {
                new: true
            }, function (err, goal) {
                if (err) {
                    return callback(err);
                }
                HGActivityLog.Archive({
                    ArchiveId: params.PetitionId,
                    Collection: ArchiveRecordEnums.Collection.Goal,
                    Content: goal,
                    Note: ArchiveRecordEnums.Reason.GoalSetRejected,
                    CreatedBy: params.UserId
                }, function (error) {
                    callback(error, goal);
                });
            });
        };

        this.ApproveSet = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.InProgress,
                    ModifiedBy: params.UserId,
                    LastCheckInDate: Date.now(),
                    ProgressStatus: GoalEnums.ProgressStatus.OnTrack
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Note: params.Note,
                        Activity: GoalEnums.ActivityType.SetApproved,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                new: true
            }, callback);
        };

        this.ApproveClose = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.Closed,
                    ModifiedBy: params.UserId
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Note: params.Note,
                        Activity: GoalEnums.ActivityType.ClosureApproved,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                new: true
            }, callback);
        };

        this.UpdatedGoalStatus = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId,
                GroupId: params.GroupId
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, callback);
        };

        this.CloseGoal = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.Closed,
                    ModifiedBy: params.UserId
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Activity: GoalEnums.ActivityType.CloseGoal,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                new: true
            }, callback);
        };
        this.SetGoal = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.InProgress,
                    ModifiedBy: params.UserId,
                    LastCheckInDate: Date.now(),
                    ProgressStatus: GoalEnums.ProgressStatus.OnTrack
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Activity: GoalEnums.ActivityType.SetGoal,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                new: true
            }, callback);
        };
        this.RequestSet = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.SubmittedForSet,
                    ModifiedBy: params.UserId
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Activity: GoalEnums.ActivityType.SubmittedForSet,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                new: true
            }, callback);
        };
        this.GetTemplatesByGroupId = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    IsTemplate: true,
                    Status: GoalEnums.GoalStatus.InProgress
                };
            if (params.Search && params.Search.trim()) {
                condition.Name = new RegExp(["^.*", params.Search.trim(), ".*$"].join(""), "i");
            }
            EntityCache.Goal
                .find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.RequestClose = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.SubmittedForClosure,
                    ModifiedBy: params.UserId
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Activity: GoalEnums.ActivityType.SubmittedForClosure,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                new: true
            }, callback);
        };

        this.ReopenClosedGoal = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.GoalId,
                Status: GoalEnums.GoalStatus.Closed,
            }, {
                $set: {
                    Status: GoalEnums.GoalStatus.InProgress,
                    ModifiedBy: params.UserId
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        Activity: GoalEnums.ActivityType.ReopenGoal,
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                new: true
            }, callback);
        };

        this.GetInProgressGoalsForCycleByMemberId = function (params, callback) {
            var condition = {
                    'Owner.MemberId': params.MemberId,
                    CycleId: params.CycleId,
                    Status: GoalEnums.GoalStatus.InProgress,
                    'Participant.ParticipantType': params.ParticipantType
                };
            if (params.ParticipantType !== GoalEnums.ParticipantType.Company) {
                condition['Participant.ParticipantId'] = params.ParticipantId;
            }
            EntityCache.Goal.find(condition, callback);
        };

        this.GetEditingGoalsForCycleByMemberId = function (params, callback) {
            var condition = {
                    'Owner.MemberId': params.MemberId,
                    CycleId: params.CycleId,
                    Status: GoalEnums.GoalStatus.Editing,
                    'Participant.ParticipantType': params.ParticipantType
                };

            if (params.ParticipantType !== GoalEnums.ParticipantType.Company) {
                condition['Participant.ParticipantId'] = params.ParticipantId;
            }
            EntityCache.Goal.find(condition, callback);
        };

        this.SaveTemplate = function (params, callback) {
            var goalTemplate;
            if (params.TemplateRequest.hgId) {
                return callback("goal.int.tuns");
            }
            goalTemplate = new EntityCache.Goal(params.TemplateRequest);
            goalTemplate.hgId = guid.v1();
            goalTemplate.GroupId = params.GroupId;
            goalTemplate.CreatedBy = params.UserId;
            goalTemplate.ModifiedBy = params.UserId;
            goalTemplate.save(callback);
        };

        this.SaveGoal = function (params, callback) {
            var goal,
                condition,
                update,
                retChanges,
                getGoalChanges = function (oldGoal, newGoal) {
                    var changes = [];
                    if (oldGoal.Name !== newGoal.Name) {
                        changes.push({
                            hgId: newGoal.hgId,
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            FullName: params.FullName,
                            ActivityType: GoalEnums.ActivityType.GoalNameChange,
                            OldValue: oldGoal.Name,
                            NewValue: newGoal.Name
                        });
                    }
                    if (!oldGoal.AlignedGoal.GoalId && newGoal.AlignedGoal.GoalId) {
                        changes.push({
                            hgId: newGoal.hgId,
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            FullName: params.FullName,
                            ActivityType: GoalEnums.ActivityType.AddAlignGoal,
                            NewValue: newGoal.AlignedGoal.Name
                        });
                    }
                    if (oldGoal.AlignedGoal.GoalId && newGoal.AlignedGoal.GoalId && oldGoal.AlignedGoal.GoalId !== newGoal.AlignedGoal.GoalId) {
                        changes.push({
                            hgId: newGoal.hgId,
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            FullName: params.FullName,
                            ActivityType: GoalEnums.ActivityType.ChangeAlignGoal,
                            OldValue: oldGoal.AlignedGoal.Name,
                            NewValue: newGoal.AlignedGoal.Name
                        });
                    }
                    if (oldGoal.IsPublic !== newGoal.IsPublic) {
                        changes.push({
                            hgId: newGoal.hgId,
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            FullName: params.FullName,
                            ActivityType: GoalEnums.ActivityType.ChangeGoalPublicity,
                            OldValue: oldGoal.IsPublic,
                            NewValue: newGoal.IsPublic
                        });
                    }
                    oldGoal.KeyResults.forEach(function (oldKr) {
                        var newKr = newGoal.KeyResults.filter(function (kr) {
                            return oldKr.hgId === kr.hgId;
                        });
                        if (newKr.length) {
                            if (oldKr.Name !== newKr[0].Name) {
                                changes.push({
                                    hgId: newGoal.hgId,
                                    MemberId: params.MemberId,
                                    UserId: params.UserId,
                                    FullName: params.FullName,
                                    ActivityType: GoalEnums.ActivityType.KeyResultNameChange,
                                    OldValue: oldKr.Name,
                                    NewValue: newKr[0].Name
                                });
                            }
                            if (oldKr.Measure === GoalEnums.KeyResultMeasureType.Numeric && oldKr.Target !== newKr[0].Target) {
                                changes.push({
                                    hgId: newGoal.hgId,
                                    MemberId: params.MemberId,
                                    UserId: params.UserId,
                                    FullName: params.FullName,
                                    ActivityType: GoalEnums.ActivityType.KeyResultTargeChange,
                                    OldValue: oldKr.Target,
                                    NewValue: newKr[0].Target,
                                    KeyResultName: newKr[0].Name,
                                    Prefix: newKr[0].Prefix,
                                    Suffix: newKr[0].Suffix
                                });
                            }
                            if (oldKr.Measure !== newKr[0].Measure) {
                                newKr[0].Progress = 0;
                            }
                        } else {//key result is removed
                            changes.push({
                                hgId: newGoal.hgId,
                                MemberId: params.MemberId,
                                UserId: params.UserId,
                                FullName: params.FullName,
                                ActivityType: GoalEnums.ActivityType.KeyResultRemoved,
                                KeyResultName: oldKr.Name
                            });
                        }
                    });
                    newGoal.KeyResults.forEach(function (newKr) {
                        var oldKr = oldGoal.KeyResults.filter(function (kr) {
                            return newKr.hgId === kr.hgId;
                        });
                        if (!oldKr.length) {//new key result is added
                            changes.push({
                                hgId: newGoal.hgId,
                                MemberId: params.MemberId,
                                UserId: params.UserId,
                                FullName: params.FullName,
                                ActivityType: GoalEnums.ActivityType.KeyResultAdded,
                                KeyResultName: newKr.Name
                            });
                        }
                    });
                    return changes;
                };

            if (!params.GoalRequest.hgId) {
                goal = new EntityCache.Goal(params.GoalRequest);
                //New PersonalGoal without an Approver
                if (!goal.CycleId && goal.Approver && !goal.Approver.MemberId) {
                    goal.ProgressStatus = GoalEnums.ProgressStatus.OnTrack;
                }
                goal.hgId = guid.v1();
                goal.GroupId = params.GroupId;
                goal.CreatedBy = params.UserId;
                goal.ModifiedBy = params.UserId;
                goal.History.push({
                    Time: Date.now(),
                    Activity: GoalEnums.ActivityType.CreateGoal,
                    MemberId: params.MemberId,
                    UserId: params.UserId,
                    FullName: params.FullName
                });
                goal.save(function (err) {
                    callback(err, {Goal: goal});
                });
            } else {
                condition = {hgId: params.GoalRequest.hgId};
                update = {$set: {
                    ModifiedBy: params.UserId,
                    Name: params.GoalRequest.Name,
                    IsPublic: params.GoalRequest.IsPublic,
                    KeyResultWeightType: params.GoalRequest.KeyResultWeightType || GoalEnums.WeightType.Equal,
                    KeyResults: params.GoalRequest.KeyResults,
                    AlignedGoal: params.GoalRequest.AlignedGoal,
                    Description: params.GoalRequest.Description || '',
                    Approver: params.GoalRequest.Approver
                }};
                if (params.GoalRequest.CheckInFrequency) {
                    update.$set.CheckInFrequency = params.GoalRequest.CheckInFrequency;
                }
                if (params.GoalRequest.ClosePromptDate) {
                    update.$set.ClosePromptDate = params.GoalRequest.ClosePromptDate;
                }
                EntityCache.Goal.findOne(condition, function (error, goal) {
                    if (error || !goal) {
                        return callback('goal.prc.elg');
                    }
                    retChanges = getGoalChanges(goal, params.GoalRequest);//please note this function actually changes values in params.GoalRequest, so i do need this single use variable here
                    update.PercentCompletion = calculateGoalPercentage(params.GoalRequest);
                    EntityCache.Goal.findOneAndUpdate(condition, update, {new: true}, function (error, updatedGoal) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, {
                            Goal: updatedGoal,
                            GoalId: goal.hgId,
                            OldApprover: goal.Approver,
                            NewApprover: updatedGoal.Approver,
                            Changes: retChanges
                        });
                    });
                });
            }
        };
        this.DeleteTemplateGoal = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.TemplateId,
                IsTemplate: true
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Status: GoalEnums.GoalStatus.Archived
                }
            }, {
                new: true
            }, callback);
        };
        this.DeleteGoal = function (params, callback) {
            EntityCache.Goal.findOneAndUpdate({
                hgId: params.GoalId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Status: GoalEnums.GoalStatus.Archived
                }
            }, {
                new: true
            }, callback);
        };
        this.ValidateGoalTransfer = function (params, callback) {
            EntityCache.Goal.count({
                'Approver.MemberId': params.FromMemberId,
                'Participant.ParticipantType': params.Type,
                Status: { $in: activeStatuses},
                'Owner.MemberId': params.ToMember.MemberId
            }, callback);
        };
        this.ValidateGoalApproverTransfer = function (params, callback) {
            if (!params.TransferMemberDutyOffboarding && (!params.DirectReports || !params.DirectReports.length)) {
                return callback("goal.int.drn");
            }
            if (params.FromMember.MemberId === params.ToMember.MemberId) {
                return callback("goal.int.nos");
            }
            if (params.DirectReports &&  params.DirectReports.length && params.DirectReports.indexOf(params.ToMember.MemberId) > -1) {
                return callback("goal.int.oas");
            }
            callback(null, true);
        };
        this.TransferGoalByType = function (params, callback) {
            EntityCache.Goal.update({
                'Owner.MemberId': params.FromMemberId,
                'Participant.ParticipantType': params.Type,
                Status: { $in: activeStatuses}
            }, {
                $set: {
                    'Owner.MemberId': params.ToMember.MemberId,
                    'Owner.UserId': params.ToMember.UserId,
                    'Owner.FullName': params.ToMember.FullName,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };
        this.TransferGoalApprovalByType = function (params, callback) {
            var query = {
                'Approver.MemberId': params.FromMemberId,
                'Participant.ParticipantType': params.Type,
                Status: { $in: outStandingGoalStatuses}
            };
            if (params.DirectReports && params.DirectReports.length) {
                query['Owner.MemberId'] = {$in: params.DirectReports};
            }
            EntityCache.Goal.update(query, {
                $set: {
                    'Approver.MemberId': params.ToMember.MemberId,
                    'Approver.UserId': params.ToMember.UserId,
                    'Approver.FullName': params.ToMember.FullName,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };
        this.TransferGoalCycleOwner = function (params, callback) {
            EntityCache.GoalCycle.update({
                'CompanyGoalOwner.MemberId': params.FromMemberId,
                Status: { $in: activeCylceStatuses}
            }, {
                $set: {
                    'CompanyGoalOwner.MemberId': params.ToMember.MemberId,
                    'CompanyGoalOwner.UserId': params.ToMember.UserId,
                    'CompanyGoalOwner.FullName': params.ToMember.FullName,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };
        this.TransferGoalOwnerByType = function (params, callback) {
            EntityCache.GoalCycleParticipant.update({
                'Owner.MemberId': params.FromMemberId,
                ParticipantType: params.Type,
                Status: { $in: outStandingParticipantStatuses}
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    'Owner.MemberId': params.ToMember.MemberId,
                    'Owner.UserId': params.ToMember.UserId,
                    'Owner.FullName': params.ToMember.FullName
                }
            }, {
                multi: true
            }, callback);
        };
        this.GetGoalOwnerByMemberIdAndType = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                'Owner.MemberId': params.MemberId,
                ParticipantType: params.Type,
                Status: { $in: outStandingParticipantStatuses}
            }, callback);
        };
        this.GetGoalApprovalCount = function (params, callback) {
            var query = {
                'Approver.MemberId': params.MemberId,
                'Participant.ParticipantType': params.Type,
                Status: { $in: outStandingGoalStatuses}
            };
            if (params.DirectReports  && params.DirectReports.length) {
                query['Owner.MemberId'] =  {$in: params.DirectReports};
            }
            EntityCache.Goal.find(query, callback);
        };

        this.GetGoalsForApproverNotification = function (params, callback) {
            var query = {
                    GroupId: {$in: params.GroupIds},
                    Status: {
                        $in: [
                            GoalEnums.GoalStatus.SubmittedForSet,
                            GoalEnums.GoalStatus.InProgress,
                            GoalEnums.GoalStatus.PendingClosure,
                            GoalEnums.GoalStatus.SubmittedForClosure
                        ]
                    },
                    'Approver.MemberId': {$exists: true},
                    CycleId: {$exists: true}        //we don't want ad hoc goals, AKA goals without a cycleid
                },
                group = {
                    _id: {
                        MemberId: '$Approver.MemberId',
                        UserId: '$Approver.UserId',
                        FullName: '$Approver.FullName'
                    },
                    rows: {
                        $push: {
                            GoalId: '$hgId',
                            GroupId: '$GroupId',
                            ModifiedDate: '$ModifiedDate',
                            FullName: '$Owner.FullName',
                            MemberId: '$Owner.MemberId',
                            Name: '$Name',
                            LastCheckInDate: '$LastCheckInDate',
                            CheckInFrequency: '$CheckInFrequency',
                            UpToDate: '$UpToDate',
                            PercentCompletion: '$PercentCompletion'
                        }
                    }
                };

            EntityCache.Goal.aggregate([{$match: query}, {$sort: {FullName: 1, ModifiedDate: 1}}, {$group: group}], callback);
        };
        function buildDasboardQuery(params) {
            var query = {
                GroupId: params.GroupId,
                Status: {$in: postSetGoalStatuses}
            };
            if (params.CycleId) {
                query.CycleId = params.CycleId;
            }
            if (params.GoalType && params.GoalType !== GoalEnums.Personal) {
                query['Participant.ParticipantType'] = params.GoalType;
                if (!params.CycleId) {
                    query.CycleId = {$exists: true};
                }
            } else if (params.GoalType && params.GoalType === GoalEnums.Personal) {
                query.CycleId = null;
            }
            if (params.GoalMembers && params.GoalMembers.length) {
                query['Owner.MemberId'] = {
                    $in: params.GoalMembers.map(function (item) {
                        return item.hgId;
                    })
                };
            }
            if (params.ProgressStatus) {
                query.ProgressStatus = params.ProgressStatus;
            }
            return query;
        }
        this.GetGoalsDashboardStats = function (params, callback) {
            var vData = {},
                openGoals = 0,
                query = buildDasboardQuery(params) || {};
            query.ProgressStatus = {$in: [
                GoalEnums.ProgressStatus.OnTrack,
                GoalEnums.ProgressStatus.Behind,
                GoalEnums.ProgressStatus.AtRisk
            ]};
            EntityCache.Goal.aggregate([
                {$match: query},
                {$group: {
                    _id: "$ProgressStatus",
                    count: {$sum: 1}
                }}
            ], function (error, data) {
                if (error) {
                    HgLog.error({methodName: 'GetGoalsDashboardStats', error: error});
                    return callback('goal.prc.eds');
                }
                data.forEach(function (item) {
                    openGoals += item.count;
                    vData[item._id] = item.count;
                });
                vData.OpenGoals = openGoals;
                callback(null, vData);
            });
        };
        this.GetDashboardGoals = function (params, callback) {
            var query = buildDasboardQuery(params),
                columnsMap = {
                    Name: 'Name',
                    Owner: 'Owner.FullName',
                    Progress: 'PercentCompletion',
                    Status: 'Status',
                    Type: 'Participant.ParticipantType'
                },
                sort = {};
            sort[columnsMap[params.SortCol || columnsMap.Name]] = params.SortDir || -1;
            if (!query.ProgressStatus) {
                query.ProgressStatus = {$in: [
                    GoalEnums.ProgressStatus.OnTrack,
                    GoalEnums.ProgressStatus.Behind,
                    GoalEnums.ProgressStatus.AtRisk
                ]};
            }
            EntityCache.Goal.find(query)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort(sort)
                .exec(callback);
        };
        this.GetDashboardGoalsCount = function (params, callback) {
            var query = buildDasboardQuery(params);
            if (!query.ProgressStatus) {
                query.ProgressStatus = {$in: [
                    GoalEnums.ProgressStatus.OnTrack,
                    GoalEnums.ProgressStatus.Behind,
                    GoalEnums.ProgressStatus.AtRisk
                ]};
            }
            EntityCache.Goal.count(query, callback);
        };
        this.GetDashboardAlignedGoals = function (params, callback) {
            var vData = {};
            async.waterfall([
                function (fcallback) {
                    var query = {
                        GroupId: params.GroupId,
                        Status: {$in: postSetGoalStatuses}
                    };
                    if (params.DepartmentId) {
                        query['Participant.ParticipantType'] = GoalEnums.ParticipantType.Team;
                        query['Participant.ParticipantId'] = params.DepartmentId;
                    } else {
                        query['Participant.ParticipantType'] = GoalEnums.ParticipantType.Company;
                    }
                    EntityCache.Goal.find(query)
                        .skip(parseInt(params.Skip, 10) || 0)
                        .limit(parseInt(params.Take, 10) || 0)
                        .exec(function (error, goals) {
                            if (error) {
                                HgLog.error({methodName: 'GetDashboardAlignedGoals.1', error: error});
                                return fcallback('goal.prc.elg');
                            }
                            vData.Goals = goals;
                            return fcallback();
                        });
                },
                function (fcallback) {
                    if (!vData.Goals || !vData.Goals.length) {
                        return fcallback();
                    }
                    EntityCache.Goal.aggregate([
                        {$match: {
                            GroupId: params.GroupId,
                            Status: {$in: postSetGoalStatuses},
                            'AlignedGoal.GoalId': {
                                $in: vData.Goals.map(function (item) {
                                    return item.hgId;
                                })
                            }
                        }},
                        {$group: {
                            _id: {
                                goalId: '$AlignedGoal.GoalId',
                                status: "$ProgressStatus"
                            },
                            count: {$sum: 1}
                        }}
                    ], function (error, data) {
                        if (error) {
                            HgLog.error({methodName: 'GetDashboardAlignedGoals.2', error: error});
                            return callback('goal.prc.elg');
                        }
                        var temp = {};
                        data.forEach(function (item) {
                            if (!temp[item._id.goalId]) {
                                temp[item._id.goalId] = {};
                            }
                            temp[item._id.goalId][item._id.status] = item.count;
                        });
                        vData.AlignedGoals = temp;
                        fcallback();
                    });
                }
            ], function (error) {
                if (error) {
                    return callback(error);
                }
                return callback(null, vData);
            });
        };
        this.GetDashboardAlignedGoalsById = function (params, callback) {
            var columnsMap = {
                    Name: 'Name',
                    Owner: 'Owner.FullName',
                    Progress: 'PercentCompletion',
                    Status: 'Status',
                    Type: 'Participant.ParticipantType'
                },
                sort = {};
            sort[columnsMap[params.SortCol || columnsMap.Name]] = params.SortDir || -1;
            EntityCache.Goal.find({
                GroupId: params.GroupId,
                Status: {$in: postSetGoalStatuses},
                'AlignedGoal.GoalId': params.GoalId
            }).skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort(sort)
                .exec(callback);
        };
        this.GetDashboardAlignedGoalsCount = function (params, callback) {
            EntityCache.Goal.find({
                GroupId: params.GroupId,
                Status: {$in: postSetGoalStatuses},
                'AlignedGoal.GoalId': params.GoalId
            }).count(callback);
        };
        this.GetOpenCyclesCount = function (params, callback) {
            EntityCache.GoalCycle.count({
                GroupId: params.GroupId,
                Status: GoalEnums.CycleStatus.InProgress
            }, callback);
        };
    };

module.exports = GoalProcessor;
