/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ClientProfile = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var uuid = require('node-uuid'),
            EntityCache = require('../framework/EntityCache.js'),
            config = require('../configurations/config.js'),
            APIKeyStatus = require('../enums/APIKeyStatus');

        this.GetProfileByAPIKey = function (params, callback) {
            EntityCache.ClientProfile.findOne({APIKey: params.clientkey}, callback);
        };

        this.GetAPIKeys = function (params, callback) {
            EntityCache.ClientProfile.find({ GroupId : params.GroupId, APIKeyStatus : 'Active'}, callback);
        };
        this.RegenerateAPIKey = function (params, callback) {
            var newAPIKey = uuid.v1(),
                query = {
                    GroupId: params.GroupId,
                    APIKeyStatus: 'Active',
                    APIKey: params.APIKey
                };
            EntityCache.ClientProfile.findOne(query, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!data) {
                    return callback('business.clientprof.err.apk');
                }
                EntityCache.ClientProfile.update(query, {
                    $set: {
                        ModifiedBy: params.UserId,
                        APIKey: newAPIKey
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {NewAPIKey: newAPIKey});
                });
            });
        };
        this.UpdateAPISettings = function (params, callback) {
            EntityCache.ClientProfile.findOneAndUpdate({
                GroupId: params.GroupId,
                APIKey: params.APIKey,
                APIKeyVersion: params.APIKeyVersion
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    AvailableServices: params.AvailableServices,
                    APIKeyStatus: params.APIKeyStatus,
                }
            }, {
                new: true
            }, callback);
        };
        this.CreateAPISettings = function (params, callback) {
            EntityCache.ClientProfile.findOne({GroupId : params.GroupId, APIKeyVersion : params.APIKeyVersion }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (data) {
                    return callback(params.GroupName + ' API Profile already exist for version ' +  params.APIKeyVersion);
                }
                var clientProfile = new EntityCache.ClientProfile({
                    hgId : uuid.v1(),
                    ClientName: params.GroupName,
                    GroupId: params.GroupId,
                    APIKey: uuid.v1(),
                    APIKeyStatus: APIKeyStatus.Active,
                    APIKeyVersion : params.APIKeyVersion,
                    AvailableServices: params.AvailableServices,
                    APIKeyLastAccessedFrom : config.hg_api_host,
                    ModifiedBy : params.UserId,
                    ModifiedDate : new Date().getTime(),
                    CreatedBy : params.UserId,
                    CreatedDate : new Date().getTime()
                });
                clientProfile.save(function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, clientProfile);
                    }
                });
            });
        };
    };

module.exports = ClientProfile;