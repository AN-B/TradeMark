/*jslint node:true es5:true */
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    IntegrationEnums = require('../enums/IntegrationEnums.js'),
    MemberProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            ProcessorHelper = require('../util/ProcessorHelper.js'),
            DateHelper = require('../util/DateHelper.js'),
            EntityEnums = require('../enums/EntityEnums'),
            ConstantEnums = require('../enums/ConstantEnums'),
            MemberEnums = require('../enums/MemberEnums.js'),
            AutocompleteEnums = require('../enums/AutocompleteEnums.js'),
            paramUtil = require('../util/params'),
            Async = require('async'),
            i18nHelper = require('../helpers/i18nHelper.js'),
            HgCache = require('../framework/RedisConnectionCache'),
            HgLog = require('../framework/HgLog'),
            defaultLanguage = 'en',
            self = this;

        this.DefaultEntityName = 'Member';

        this.GetMemberIdsByDeptId = function (params, callback) {
            var cacheKey = 'DepartmentMemberMap-' + params.GroupId;
            HgCache.GlobalGet(cacheKey, function (error, map) {
                if (error || !map) {//map doesn't exist in redis, build it
                    map = {};//map[DepartmentId][memberId] is true if memberId belong to the department
                    EntityCache.Member.find({
                        GroupId: params.GroupId,
                        MembershipStatus: EntityEnums.MembershipStatus.Active
                    }, {
                        _id: 0,
                        hgId: 1,
                        GroupDepartmentId: true
                    }, {
                        lean: true
                    }, function (err, members) {
                        if (err) {
                            return callback(err);
                        }
                        members.forEach(function (member) {
                            if (map[member.GroupDepartmentId]) {
                                map[member.GroupDepartmentId][member.hgId] = true;
                            } else {
                                map[member.GroupDepartmentId] = {};
                                map[member.GroupDepartmentId][member.hgId] = true;
                            }
                        });
                        HgCache.GlobalSet(cacheKey, map, function (err) {
                            if (err) {
                                HgLog.info('*** Unable to set value to Redis: ' + err.toString() + ' ***');
                            }
                            return callback(null, map[params.DepartmentId]);
                        }, ConstantEnums.SECONDS_IN_TWENTY_FOUR_HOURS);
                    });
                } else {
                    callback(null, JSON.parse(map)[params.DepartmentId]);
                }
            });
        };
        this.GetMemberIdsByLocationId = function (params, callback) {
            var cacheKey = 'LocationMemberMap-' + params.GroupId;
            if (!params.LocationId) {
                return callback(null, []);
            }
            HgCache.GlobalGet(cacheKey, function (error, map) {
                if (error || !map) {//map doesn't exist in redis, build it
                    map = {};//map[DepartmentId][memberId] is true if memberId belong to the department
                    EntityCache.Member.find({
                        GroupId: params.GroupId,
                        MembershipStatus: EntityEnums.MembershipStatus.Active
                    }, {
                        _id: 0,
                        hgId: 1,
                        "Location.hgId": true
                    }, {
                        lean: true
                    }, function (err, members) {
                        if (err) {
                            return callback(err);
                        }
                        members.forEach(function (member) {
                            if (member.Location && member.Location.hgId) {
                                if (map[member.Location.hgId]) {
                                    map[member.Location.hgId][member.hgId] = true;
                                } else {
                                    map[member.Location.hgId] = {};
                                    map[member.Location.hgId][member.hgId] = true;
                                }
                            }
                        });
                        HgCache.GlobalSet(cacheKey, map, function (err) {
                            if (err) {
                                HgLog.info('*** Unable to set value to Redis: ' + err.toString() + ' ***');
                            }
                            return callback(null, map[params.LocationId]);
                        }, ConstantEnums.SECONDS_IN_TWENTY_FOUR_HOURS);
                    });
                } else {
                    callback(null, JSON.parse(map)[params.LocationId]);
                }
            });
        };

        this.FuzzySearch = function (params, callback) {
            if (!params.SearchTerm || !params.SearchTerm.length) {
                return callback(null, []);
            }
            EntityCache.Member.find({
                GroupId: params.GroupId,
                MembershipStatus: params.Status ? {$in: params.Status} : EntityEnums.MembershipStatus.Active,
                FullName: {$regex: i18nHelper.convertTextToAscii(params.SearchTerm).fuzzy(), $options: 'i'}
            }, callback);
        };
        this.FuzzyFilter = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    MembershipStatus: params.Status ? {$in: params.Status} : EntityEnums.MembershipStatus.Active
                };
            if (params.SearchTerm && params.SearchTerm.length) {
                condition.SearchName = {$regex: i18nHelper.convertTextToAscii(params.SearchTerm).fuzzy(), $options: 'i'};
            }
            if (params.DeptId) {
                condition.GroupDepartmentId = params.DeptId;
            }
            EntityCache.Member.count(condition, function (error, count) {
                if (error) {
                    return callback(error);
                }
                EntityCache.Member.find(condition)
                    .sort({FullName: 1})
                    .skip(parseInt(params.Skip, 10) || 0)
                    .limit(parseInt(params.Take, 10) || 0)
                    .exec(function (error, members) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, {
                            Total: count,
                            Members: members
                        });
                    });
            });
        };

        this.SetPreferenceByMemberId = function (params, callback) {
            EntityCache.Member.findOneAndUpdate({
                hgId: params.MemberId
            }, {
                $set: {
                    Preference: {
                        WeekendDailyRecap: params.Preference.WeekendDailyRecap,
                        RecapType: params.Preference.RecapType,
                        OptOutPublicRec: params.Preference.OptOutPublicRec
                    }
                }
            }, {
                new: true
            }, callback);
        };

        this.GetPreferenceByMemberId = function (params, callback) {
            EntityCache.Member.findOne({hgId: params.MemberId}, function (err, member) {
                if (err && !member) {
                    return callback('server.hge.mem.mde');
                }
                callback(null, member.Preference);
            });
        };

        this.GetTotalMembersForWeeklyRecap = function (params, callback) {
            EntityCache.Member.count({
                MembershipStatus: MemberEnums.Status.Active,
                GroupId: {$in: params.GroupIds},
                'Preference.RecapType': EntityEnums.RecapType.Weekly,
                LastDailyRecapSentDate: {
                    $lt: DateHelper.getDayBegining()
                },
                LastLoginTime: {
                    $gt: 0
                }
            }, callback);
        };

        this.GetNextBatchMembersForWeeklyRecap = function (params, callback) {
            EntityCache.Member.find({
                MembershipStatus: MemberEnums.Status.Active,
                GroupId: {$in: params.GroupIds},
                'Preference.RecapType': EntityEnums.RecapType.Weekly,
                LastDailyRecapSentDate: {
                    $lt: DateHelper.getDayBegining()
                },
                LastLoginTime: {
                    $gt: 0
                }
            }, {
                hgId: true,
                UserId: true,
                FullName: true,
                GroupId: true,
                GroupName: true,
                RolesInGroup: true,
                Position: true,
                GroupDepartmentName: true,
                GroupDepartmentId: true,
                EmployeeId: true,
                Location: true
            })
                .sort({GroupId: 1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(function (error, members) {
                    if (error) {
                        return callback(error);
                    }
                    EntityCache.Member.update({
                        hgId: {$in: members.map(function (m) {
                            return m.hgId;
                        })}
                    }, {
                        $set: {LastDailyRecapSentDate: Date.now()}
                    }, {
                        multi: true
                    }, function (error) {
                        callback(error, members);
                    });
                });
        };

        this.GetTotalMembersForDailyRecap = function (params, callback) {
            EntityCache.Member.count({
                MembershipStatus: MemberEnums.Status.Active,
                GroupId: {$in: params.GroupIds},
                'Preference.RecapType': EntityEnums.RecapType.Daily,
                LastDailyRecapSentDate: {
                    $lt: DateHelper.getDayBegining()
                },
                LastLoginTime: {
                    $gt: 0
                }
            }, callback);
        };
        this.GetTotalActiveMemberByGroupId = function (params, callback) {
            EntityCache.Member.count({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active
            }, callback);
        };

        this.LoadActiveMembersBatch = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active
            }).skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetNextBatchMembersForDailyRecap = function (params, callback) {
            EntityCache.Member.find({
                MembershipStatus: MemberEnums.Status.Active,
                GroupId: {$in: params.GroupIds},
                'Preference.RecapType': EntityEnums.RecapType.Daily,
                LastDailyRecapSentDate: {
                    $lt: DateHelper.getDayBegining()
                },
                LastLoginTime: {
                    $gt: 0
                }
            }).sort({GroupId: 1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(function (error, members) {
                    if (error) {
                        return callback(error);
                    }
                    EntityCache.Member.update({
                        hgId: {$in: members.map(function (m) {
                            return m.hgId;
                        })}
                    }, {
                        $set: {LastDailyRecapSentDate: Date.now()}
                    }, {
                        multi: true
                    }, function (error) {
                        callback(error, members);
                    });
                });
        };

        this.GetMembersCanGiveAchievement = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                RemovedPermissions: {$ne: MemberEnums.MemberPermission.AchievementRecognition.Name},
                $or: [
                    {RolesInGroup: {$in: [
                        MemberEnums.MemberRole.ResellerAdmin.Name,
                        MemberEnums.MemberRole.HGAdmin.Name
                    ].concat(params.AdditionalRoles || [])}},
                    {AddedPermissions: MemberEnums.MemberPermission.AchievementRecognition.Name}
                ]
            }).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(callback);
        };

        this.SetMemberLocation = function (params, callback) {
            EntityCache.Member.update({
                hgId: params.MemberId
            }, {
                $set: {
                    Location: params.Location,
                    ModifiedBy: params.UserId
                }
            }, function (error) {
                callback(error, params.Member);
            });
        };

        this.SetGRSMemberId = function (params, callback) {
            EntityCache.Member.findOne({
                hgId: params.MemberId
            }, function (err, member) {
                if (err) {
                    return callback(err);
                }

                var foundGRSMemberId = false;
                member.ModifiedDate = Date.now();
                member.ModifiedBy = params.UserId;

                if (!member.Integration) {
                    member.Integration = [];
                }

                member.Integration.forEach(function (integration) {
                    if (integration.Application === IntegrationEnums.Applications.GRS) {
                        foundGRSMemberId = true;
                        integration.UserId = params.GRSMemberId;
                    }
                });

                if (!foundGRSMemberId) {
                    member.Integration.push({
                        Application: IntegrationEnums.Applications.GRS,
                        UserId: params.GRSMemberId
                    });
                }

                member.save(function (err) {
                    callback(err);
                });
            });
        };

        this.GetMembersByLocationId = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active,
                'Location.hgId': params.LocationId
            }, callback);
        };

        this.GetMembersByDepartmentId = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active,
                GroupDepartmentId: params.DepartmentId
            }, callback);
        };

        this.GetMembersByDepartmentIds = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                MembershipStatus: EntityEnums.MembershipStatus.Active,
                GroupDepartmentId: { $in: params.DepartmentIds}
            };
            if (params.ExcludeMemberIds && params.ExcludeMemberIds.length) {
                query.hgId = { $in: params.ExcludeMemberIds };
            }
            EntityCache.Member.find(query, callback);
        };
        this.GetMemberIdsForLocationIds = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                'Location.hgId': {$in: params.LocationIds},
                MembershipStatus: MemberEnums.Status.Active
            }, {
                _id: 0,
                'hgId': 1
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data.map(function (m) { return m.hgId; }));
            });
        };
        this.GetMemberCountsByLocations = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active
            },
                group = {
                    _id: {
                        LocationId: '$Location.hgId'
                    },
                    Count: {
                        '$sum': 1
                    }
                };
            EntityCache.Member.aggregate([{
                $match: condition
            }, {
                $group: group
            }], function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data.map(function (item) {
                    return {
                        LocationId: item._id.LocationId,
                        Count: item.Count
                    };
                }));
            });
        };
        this.GetNonAdminMembersByGroupId = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                MembershipStatus: {
                    $in: [MemberEnums.Status.Active, MemberEnums.Status.OffBoarded]
                },
                RolesInGroup: {
                    $nin: [MemberEnums.MemberRole.Admin.Name, MemberEnums.MemberRole.HGAdmin.Name]
                }
            }, { UserId: 1 }, function (error, data) {
                if (error || !data) {
                    return callback(error || 'server.hge.grp.elms');
                }
                callback(null, data.map(function (m) {
                    return m.UserId;
                }));
            });
        };
        this.HasSubordinateMembers = function (params, callback) {
            EntityCache.Member.count({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active,
                'MyManagers.MemberId': params.MemberId
            }, callback);
        };

        this.GetDirectReportsByMemberId = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active,
                'MyManagers.MemberId': params.MemberId
            }, params.Fields || {}, callback);
        };

        this.GetDirectReportsByMemberIds = function (params, callback) {
            EntityCache.Member.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    MembershipStatus: MemberEnums.Status.Active,
                    'MyManagers.MemberId': {$in: params.MemberIds}
                }},
                {$lookup: {
                    from: 'UserInfo',
                    localField: 'UserId',
                    foreignField: 'hgId',
                    as: 'User_Member_Record'
                }},
                {$group: {
                    _id: "$MyManagers.MemberId",
                    data: {$push: {
                        MemberId: "$hgId",
                        hgId: "$UserId",
                        UserId: "$UserId",
                        EmpID: "$EmployeeId",
                        FullName: "$FullName",
                        FirstName: "$FirstName",
                        LastName: "$LastName",
                        UserName: {$arrayElemAt: [ "$User_Member_Record.LowercaseUserName", 0]},
                        HomeZip: {$arrayElemAt: [ "$User_Member_Record.Preference.HomeZip", 0]},
                        WorkZip: {$arrayElemAt: [ "$User_Member_Record.Preference.WorkZip", 0]},
                        SuppressBirthday: {$arrayElemAt: [ "$User_Member_Record.Preference.SuppressBirthday", 0]},
                        SuppressAnniversary: {$arrayElemAt: [ "$User_Member_Record.Preference.SuppressAnniversary", 0]},
                        Email: {$arrayElemAt: [ "$User_Member_Record.UserPersonal.PrimaryEmail", 0]},
                        LocationId: "$Location.hgId",
                        Location: "$Location.Name",
                        DepartmentId: "$GroupDepartmentId",
                        Department: "$GroupDepartmentName",
                        StartDate: "$StartingDate",
                        Birthdate: "$Birthdate",
                        Position: "$Position",
                        Role: {$arrayElemAt: ["$RolesInGroup", 0]},
                        JobLevel: "$JobLevel",
                        JobCode: "$JobCode",
                        HomeCountry: "$HomeCountry",
                        BenefitStatus: "$BenefitStatus",
                        MailCD: "$MailCD",
                        UnionCode: "$UnionCode"
                    }}
                }}
            ], callback);
        };

        this.GetMemberBySalesForce = function (params, callback) {
            EntityCache.Member.findOne({
                Integration: {
                    $elemMatch: {
                        Application: 'SalesForce',
                        UserEmail: params.UserEmail
                    }
                }
            }, callback);
        };

        this.SwitchGroupMembersRecapType = function (params, callback) {
            EntityCache.Member.update({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active
            }, {
                $set: {
                    'Preference.RecapType': params.RecapType
                }
            }, {
                multi: true
            }, function (error) {
                if (callback) {
                    callback(error, 'server.info.mem.memsup');
                }
            });
        };

        this.GetMemberKeyByEmployeeId = function (params, callback) {
            var data_key = {};
            EntityCache.Member.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    EmployeeId: {$in: params.EmployeeIds}
                }},
                {$lookup: {
                    from: 'UserInfo',
                    localField: 'UserId',
                    foreignField: 'hgId',
                    as: 'User_Member_Record'
                }},
                {$project: {
                    MemberId: "$hgId",
                    UserId: "$UserId",
                    EmployeeId: "$EmployeeId",
                    FullName: "$FullName",
                    FirstName: "$FirstName",
                    LastName: "$LastName",
                    UserName: {$arrayElemAt: [ "$User_Member_Record.LowercaseUserName", 0]}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    data_key[item.EmployeeId] = {
                        hgId: item.MemberId,
                        FullName: item.FullName,
                        EmployeeId: item.EmployeeId,
                        UserName: item.UserName,
                        FirstName: item.FirstName,
                        LastName: item.LastName
                    };
                });
                callback(null, data_key);
            });
        };

        // TD: NEED TO ADD ADDITONAL CHECKS FOR CIRCULAR REFERENCE AND DE-DUPING CODE
        this.GetAllSubordinatesByMemberId = function (params, callback) {
            var subs = {},
                recurseLevel = process.env.RECURSE_LEVEL || 20,
                getDirectReports = function (memberArray, finalCallback) {
                    EntityCache.Member.find({
                        GroupId: params.GroupId,
                        MembershipStatus: MemberEnums.Status.Active,
                        "MyManagers.MemberId": {
                            $in: memberArray
                        }
                    }, {
                        hgId: 1,
                        UserId: 1,
                        FullName: 1,
                        GroupDepartmentName: 1
                    }, function (err, members) {
                        if (!err && members && members.length && recurseLevel > 0) {
                            members.reduce(function (memo, member) {
                                memo[member.hgId] = member;
                                return memo;
                            }, subs);
                            recurseLevel -= 1;
                            getDirectReports(members.map(function (member) {
                                return member.hgId;
                            }), finalCallback);
                        } else {
                            finalCallback(null, Object.keys(subs).map(function (k) {
                                return {
                                    hgId: subs[k].hgId,
                                    UserId: subs[k].UserId,
                                    FullName: subs[k].FullName,
                                    Department: subs[k].GroupDepartmentName
                                };
                            }));
                        }
                    });
                };
            getDirectReports([params.MemberId], callback);
        };

        this.GetGroupBillableMembersCount = function (params, callback) {
            var dataRecords = {},
                matchQuery = {
                    MembershipStatus: MemberEnums.Status.Active
                },
                groupQuery = {
                    _id: {
                        GroupId: '$GroupId'
                    },
                    MemberCount: {
                        $sum: 1
                    }
                };
            EntityCache.Member.aggregate([{
                $match: matchQuery
            }, {
                $group: groupQuery
            }], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.map(function (item) {
                    if (!dataRecords[item._id.GroupId]) {
                        dataRecords[item._id.GroupId] = item.MemberCount;
                    }
                });
                callback(null, dataRecords);
            });
        };

        this.GetGroupAdminsByGroupId = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                RolesInGroup: MemberEnums.MemberRole.Admin.Name,
                MembershipStatus: MemberEnums.Status.Active
            }, callback);
        };

        this.UpdateMembersDepartment = function (params, callback) {
            EntityCache.Member.update({
                hgId: { $in: params.MemberIds}
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    GroupDepartmentName: params.DepartmentName,
                    GroupDepartmentId: params.DepartmentId || ''
                }
            }, {
                multi: true
            }, callback);
        };

        this.GetMemberStatusById = function (params, callback) {
            EntityCache.Member.findOne({
                hgId: params.MemberId
            }, {
                _id: 0,
                MembershipStatus: 1
            }, function (error, member) {
                if (error) {
                    callback('server.hge.mem.mde');
                } else {
                    callback(null, member.MembershipStatus);
                }
            });
        };

        this.UpdateMemberRecord = function (params, callback) {
            var fullName = i18nHelper.convertTextToAscii(params.Member.FullName);
            EntityCache.Member.update({
                hgId: params.Member.hgId
            }, {
                $set: {
                    FirstName: params.Member.FirstName,
                    LastName: params.Member.LastName,
                    FullName: params.Member.FullName,
                    SearchName: fullName,
                    SearchField: paramUtil.GetSearchField(fullName, true),
                    RolesInGroup: params.Member.RolesInGroup,
                    Position: params.Member.Position || '',
                    StartingDate: params.Member.StartingDate,
                    Birthdate: params.Member.Birthdate,
                    GroupDepartmentName: params.Member.GroupDepartmentName,
                    GroupDepartmentId: params.Member.GroupDepartmentId,
                    EmployeeId: params.Member.EmployeeId || '',
                    ModifiedBy: params.UserId,
                    MyManagers: params.Member.MyManagers,
                    Location: params.Member.Location
                }
            }, callback);
        };

        this.CheckValidEmployeeId = function (params, callback) {
            if (!params.EmployeeId || params.EmployeeId === '') {
                return callback();
            }
            EntityCache.Member.findOne({
                GroupId: params.GroupId,
                hgId: {
                    $ne: params.MemberId
                },
                EmployeeId: params.EmployeeId
            }, function (error, member) {
                if (error) {
                    callback(error);
                } else if (member) {
                    callback(i18nHelper.translate(params.Lang || defaultLanguage, 'server.hge.mem.meidiu', {
                        EmployeeId: params.EmployeeId,
                        FullName: member.FullName
                    }));
                } else {
                    callback();
                }
            });
        };

        this.GetMemberByUserId = function (params, callback) {
            EntityCache.Member.findOne({GroupId: params.GroupId, UserId: params.UserId}, params.Fields || {}, callback);
        };

        this.UpdateMembersManagerFromProvision = function (params, callback) {
            self.GetMembersByUserIds({
                GroupId: params.GroupId,
                UserIds: params.ManagerUserIds
            }, function (error, managerRecords) {
                if (error || !managerRecords || !managerRecords.length) {
                    return callback(error || [i18nHelper.translate(params.Lang || defaultLanguage, 'server.hge.mem.muids'), params.ManagerUserIds.join(', ')].join(' '));
                }
                //add defensive check to prevent duplicate managers
                var managers = {};
                managerRecords.map(function (record) {
                    if (!managers[record.hgId]) {
                        managers[record.hgId] = {
                            MemberId: record.hgId,
                            UserId: record.UserId,
                            FullName: record.FullName
                        };
                    }
                });
                EntityCache.Member.update({
                    GroupId: params.GroupId,
                    UserId: {$in: params.DirectReportsUserIds}
                }, {
                    $set: {
                        ModifiedBy: params.UserId,
                        MyManagers: Object.keys(managers).map(function (item) {
                            return {
                                MemberId: managers[item].MemberId,
                                UserId: managers[item].UserId,
                                FullName: managers[item].FullName
                            };
                        })
                    }
                }, {
                    multi: true
                }, callback);
            });
        };

        this.UpdateMemberManagerName = function (params, callback) {
            var membersToUpdate = [];

            function removeOldManagerName(params, cb) {
                EntityCache.Member.find({
                    GroupId: params.GroupId,
                    'MyManagers.MemberId': params.MemberId
                }, function (error, members) {
                    if (error) {
                        return callback(error);
                    }
                    Async.eachSeries(members, function (member, tCb) {
                        membersToUpdate.push(member.hgId);
                        EntityCache.Member.update({
                            hgId: member.hgId
                        }, {
                            $set: {
                                MyManagers: member.MyManagers.filter(function (manager) {
                                    return manager.MemberId !== params.MemberId;
                                })
                            }
                        }, function (error) {
                            return tCb(error);
                        });
                    }, cb);
                });
            }

            function addNewManagerName(params, cb) {
                EntityCache.Member.update({
                    GroupId: params.GroupId,
                    hgId: {
                        $in: membersToUpdate
                    }
                }, {
                    $addToSet: {
                        MyManagers: {
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            FullName: params.FullName
                        }
                    },
                    $set: {
                        ModifiedBy: params.UserId
                    }
                }, {
                    multi: true
                }, cb);
            }

            Async.waterfall([
                function (wCb) {
                    removeOldManagerName(params, wCb);
                },
                function (wCb) {
                    addNewManagerName(params, wCb);
                }
            ], function (error) {
                callback(error);
            });
        };

        this.RemoveMembers = function (params, callback) {
            //This should probably be a soft delete
            if (!params.MemberIds || params.MemberIds.length === 0) {
                return callback(null, 'server.info.mem.msrm');
            }
            EntityCache.Member.remove({
                hgId: {
                    $in: params.MemberIds
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, 'server.info.mem.msrm');
            });
        };

        this.GetSubordinateMembers = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active,
                'MyManagers.MemberId': params.MemberId
            };
            if (params.Search) {
                query.FullName = {$regex: params.Search, $options: 'i'};
            }
            if (params.ReportIds && params.ReportIds.length) {
                query.hgId = {$in: params.ReportIds};
                params.Take = 0;
                params.Skip = 0;
            }
            if (params.DepartmentId) {
                query.GroupDepartmentId = params.DepartmentId;
            }
            EntityCache.Member.find(query, null, {
                sort: {
                    FirstName: 1
                },
                limit: parseInt(params.Take, 10) || 0,
                skip: parseInt(params.Skip, 10) || 0
            }, callback);
        };

        this.GetMembersByUserIdsNoGroup = function (params, callback) {
            EntityCache.Member.find({
                UserId: { $in: params.UserIds},
                MembershipStatus: MemberEnums.Status.Active
            }, callback);
        };

        this.GetMembersByUserIds = function (params, callback) {
            var fields = params.Fields || {},
                query = {
                    GroupId: params.GroupId,
                    UserId: {$in: params.UserIds}
                };
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            EntityCache.Member.find(query, fields, callback);
        };

        this.GetSubordinateMembersForMemberIds = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    MembershipStatus: MemberEnums.Status.Active,
                    'MyManagers.MemberId': {
                        $in: params.MemberIds
                    }
                };
            if (params.Search) {
                condition.FullName = {$regex: params.Search, $options: 'i'};
            }
            EntityCache.Member.find(condition).sort({
                FirstName: 1
            }).exec(function (err, members) {
                callback(err, members);
            });
        };

        this.GetSubordinateCount = function (params, callback) {
            EntityCache.Member.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    MembershipStatus: EntityEnums.MembershipStatus.Active,
                    'MyManagers.MemberId': {
                        $in: params.ReportMemberIds
                    }
                }},
                {$group: {
                    _id: "$MyManagers.MemberId",
                    count: { $sum: 1 }
                }}
            ]).exec(function (err, data) {
                callback(err, data);
            });
        };

        this.GetMembersByFilter = function (params, callback) {
            //If the query ends up been {}, then it going to slow and not optimal.
            //Also in this case, it would return all members regardless of GroupId
            //We probably want to Include GroupId in the query
            //If the query ends up been just UserId then it is not optimal either
            //Changes
            //1 - Index Update handles UserId Filter
            var mquery = EntityCache.Member.find({});
            if (params.UserIds && params.UserIds.length > 0) {
                mquery.where('UserId', {
                    $in: params.UserIds
                });
            }
            if (params.GroupId) {
                mquery.where('GroupId', params.GroupId);
            }
            if (params.MembershipStatus) {
                mquery.where('MembershipStatus', params.MembershipStatus);
            }
            mquery.exec(function (error, members) {
                if (!error) {
                    members.forEach(function (member) {
                        if (!member.FullName) {
                            member.FullName = member.FirstName + ' ' + member.LastName;
                        }
                    });
                    callback(null, members);
                } else {
                    callback('server.hge.grp.elms');
                }
            });
        };

        this.UpdateSingleMember = function (params, callback) {
            EntityCache.Member.update({
                hgId: params.Member.hgId
            }, {
                $set: ProcessorHelper.GetUpdateJson(params.Fields, params.Member, params.UserId)
            }, callback);
        };

        this.UpdateMembers = function (params, callback) {
            function updateMember(member, callback) {
                EntityCache.Member.update({
                    hgId: member.hgId
                }, {
                    $set: ProcessorHelper.GetUpdateJson(params.Fields, member, params.UserId)
                }, function () {
                    callback();
                });
            }
            if (params.Members && params.Members.length) {
                Async.each(params.Members, updateMember, function () {
                    callback(null, 'server.info.mem.mup');
                });
            } else {
                callback(null, 'server.info.mem.mup');
            }
        };

        this.AddMembers = function (params, callback) {
            var fullName;
            if (!params.Members || !params.Members.length) {
                return callback(null, 'server.info.mem.madd');
            }
            params.Members.forEach(function (member) {
                fullName = i18nHelper.convertTextToAscii(member.FullName);
                member.SearchName = fullName;
                member.SearchField = paramUtil.GetSearchField(fullName, true);
            });
            return EntityCache.Member.insertMany(params.Members, callback);
        };

        this.GetMemberManagerUsersNames = function (params, callback) {
            var memberManagerIndex = {};
            EntityCache.Member.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    hgId: {$in: params.MemberIds}
                }},
                {$unwind: {path: "$MyManagers", preserveNullAndEmptyArrays: true}},
                {$lookup: {
                    from: 'UserInfo',
                    localField: 'MyManagers.UserId',
                    foreignField: 'hgId',
                    as: 'Member_ManagerUser_Record'
                }},
                {$project: {
                    FullName: "$FullName",
                    MemberId: "$hgId",
                    UserId: "$UserId",
                    ManagerUserName: {$arrayElemAt: [ "$Member_ManagerUser_Record.LowercaseUserName", 0]},
                    ManagerFullName: {$arrayElemAt: [ "$Member_ManagerUser_Record.UserPersonal.FullName", 0]},
                    ManagerUserId: {$arrayElemAt: [ "$Member_ManagerUser_Record.hgId", 0]}
                }},
                {$group: {
                    _id: "$MemberId",
                    data: {$push: "$$ROOT"}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    memberManagerIndex[item._id] = item.data;
                });
                callback(null, memberManagerIndex);
            });
        };

        this.GetMemberManagersByIds = function (params, callback) {
            EntityCache.Member.find({
                hgId: {
                    $in: params.MemberIds
                }
            }, params.Fields || {
                hgId: 1,
                FullName: 1,
                MyManagers: 1,
                GroupId: 1
            }, {lean: true}, callback);
        };

        this.GetActiveMembersByGroupId = function (params, callback) {
            EntityCache.Member.find({GroupId: params.GroupId, MembershipStatus: MemberEnums.Status.Active}, callback);
        };

        this.GetMemberByEmployeeId = function (params, callback) {
            EntityCache.Member.findOne({
                GroupId: params.GroupId,
                EmployeeId: params.EmployeeId
            }, function (error, member) {
                if (error) {
                    return callback(error);
                }
                callback(null, member);
            });
        };

        this.GetMemberByEmployeeIds = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                EmployeeId: {$in: params.EmployeeIds}
            }, params.Fields || {}, callback);
        };

        this.GetMemberIdsByUserIds = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                UserId: { $in: params.UserIds }
            };
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            EntityCache.Member.find(query, {hgId: 1, UserId: 1}, callback);
        };

        this.GetActiveMemberCount = function (params, callback) {
            var query = {
                UserId: {$in: params.UserIds},
                RolesInGroup: {$in: [
                    MemberEnums.MemberRole.Consultant.Name,
                    MemberEnums.MemberRole.Employee.Name,
                    MemberEnums.MemberRole.Manager.Name,
                    MemberEnums.MemberRole.Director.Name,
                    MemberEnums.MemberRole.Executive.Name,
                    MemberEnums.MemberRole.Admin.Name,
                    MemberEnums.MemberRole.Owner.Name,
                    MemberEnums.MemberRole.ResellerAdmin.Name,
                    MemberEnums.MemberRole.HGAdmin.Name
                ]}
            };
            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            EntityCache.Member.count(query, callback);
        };

        this.GetActiveMemberIdsByUserIds = function (params, callback) {
            var query = {
                UserId: {$in: params.UserIds},
                RolesInGroup: {$in: [
                    MemberEnums.MemberRole.Consultant.Name,
                    MemberEnums.MemberRole.Employee.Name,
                    MemberEnums.MemberRole.Manager.Name,
                    MemberEnums.MemberRole.Director.Name,
                    MemberEnums.MemberRole.Executive.Name,
                    MemberEnums.MemberRole.Admin.Name,
                    MemberEnums.MemberRole.Owner.Name,
                    MemberEnums.MemberRole.ResellerAdmin.Name,
                    MemberEnums.MemberRole.HGAdmin.Name
                ]}
            };
            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            EntityCache.Member.find(query, {hgId: 1, UserId: 1, GroupName: 1, FullName: 1}, callback);
        };

        this.GetMembersByMemberIds = function (params, callback) {
            var query = {
                hgId: {$in: params.MemberIds}
            };
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            if (params.SearchFilter) {
                query.FullName = new RegExp(["^.*", params.SearchFilter, ".*$"].join(""), "i");
            }
            if (params.GroupDepartmentName) {
                query.GroupDepartmentName = new RegExp(["^.*", params.GroupDepartmentName, ".*$"].join(""), "i");
            }
            EntityCache.Member.find(query, params.Fields || null, {sort: {FullName: 1}})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(function (error, data) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, !data.length ? data : data.map(function (item) {
                        return item.toObject();
                    }));
                });
        };

        this.GetActiveMembersByIdsProjection = function (params, callback) {
            EntityCache.Member.find({
                hgId: {
                    $in: params.MemberIds
                },
                MembershipStatus: EntityEnums.MembershipStatus.Active
            }, {
                _id: 0,
                FullName: 1,
                hgId: 1,
                UserId: 1,
                GroupDepartmentName: 1
            }, function (err, members) {
                if (err) {
                    return callback(err);
                }
                callback(null, members);
            });
        };

        this.GetMemberByMemberId = function (params, callback) {
            var query = {
                hgId: params.MemberId
            }, fields;
            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            if (params.MembershipStatus) {
                query.MembershipStatus = params.MembershipStatus;
            }
            if (params.Fields) {
                fields = params.Fields;     //example: {hgId: true, FirstName: true}
            }
            EntityCache.Member.findOne(query, fields, callback);
        };

        this.GetMemberById_V2 = function (params, callback) {
            EntityCache.Member.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    hgId: params.MemberId
                }},
                {$lookup: {
                    from: 'UserInfo',
                    localField: 'UserId',
                    foreignField: 'hgId',
                    as: 'User_Member_Record'
                }},
                {$project: {
                    MemberId: "$hgId",
                    UserId: "$UserId",
                    MembershipStatus: "$MembershipStatus",
                    FullName: "$FullName",
                    EmployeeId: "$EmployeeId",
                    MyManagers: "$MyManagers",
                    UserName: {$arrayElemAt: [ "$User_Member_Record.LowercaseUserName", 0]}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!data.length) {
                    return callback('Error loading member');
                }
                callback(null, data[0]);
            });
        };

        this.SearchMembers = function (params, callback) {
            var condition = {};
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            if (params.MembershipStatus) {
                condition.MembershipStatus = params.MembershipStatus;
            }
            if (params.FullName) {
                condition.FullName = (params.IsStartWith) ? {$regex: '^' + params.FullName + '.*$', $options: 'i'} : {$regex: params.FullName, $options: 'i'};
            }
            if (params.Since && params.Until) {
                if (params.DateField === 'StartingDate') {
                    condition.StartingDate = { $gte: params.Since, $lte: params.Until };
                }
            } else if (params.Since && !params.Until) {
                if (params.DateField === 'StartingDate') {
                    condition.StartingDate = { $gte: params.Since };
                }
            } else if (!params.Since && params.Until) {
                if (params.DateField === 'StartingDate') {
                    condition.StartingDate = { $lte: params.Until };
                }
            }
            EntityCache.Member.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort(params.SortBy)
                .exec(callback);
        };

        this.GetTopExecutive = function (params, callback) {
            var condition = {};
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            if (params.FullName) {
                condition.FullName = {$regex: params.FullName, $options: 'i'};
            }
            condition.MembershipStatus = EntityEnums.MembershipStatus.Active;
            condition.$or = [
                {'MyManagers.MemberId': null},
                {MyManagers: null},
                {'MyManagers.MemberId': ''}
            ];
            EntityCache.Member.find(condition, {
                _id: 0,
                hgId: 1,
                UserId: 1,
                FullName: 1,
                Position: 1,
                GroupDepartmentName: 1
            }).exec(callback);
        };

        this.GetMembersInHierarchy = function (params, callback) {
            var groupId = params.GroupId,
                levelCount = 1,
                levelMap = {};

            function findSubordinates(members, findSubordinatesCallBack) {
                var subs = EntityCache.Member.aggregate([
                        {$match: {
                            GroupId: groupId,
                            MembershipStatus: EntityEnums.MembershipStatus.Active,
                            'MyManagers.MemberId': {$in: members.map(function (member) {
                                return member.MemberId;
                            })}
                        }},
                        {$group: {
                            _id: '$MyManagers.MemberId',
                            Members: {
                                $push: {
                                    FullName: '$FullName',
                                    Department: '$GroupDepartmentName',
                                    Title: '$Position',
                                    MemberId: '$hgId',
                                    UserId: '$UserId'
                                }
                            }
                        }}
                    ]),
                    allMembers = [],
                    i,
                    len,
                    setSubOrds = function (members, setSubOrdsCallback) {
                        Async.each(members, function (member, levelReferenceCallback) {
                            if (!levelMap[member.MemberId]) {
                                return levelReferenceCallback();
                            }
                            member.Manages = levelMap[member.MemberId];
                            setSubOrds(member.Manages, levelReferenceCallback);
                        }, function () {
                            setSubOrdsCallback();
                        });
                    };
                subs.exec(function (error, result) {
                    if (!(result && result.length)) {
                        return findSubordinatesCallBack();
                    }
                    levelCount += 1;
                    result.forEach(function (sub) {
                        levelMap[sub._id] = sub.Members;
                        allMembers = allMembers.concat(sub.Members);
                    });
                    for (i = 0, len = allMembers.length; i < len; i += 1) {
                        allMembers[i].Level = levelCount;
                    }
                    setSubOrds(members, function () {
                        findSubordinates(allMembers, findSubordinatesCallBack);
                    });
                });
            }
            self.GetTopExecutive(params, function (error, members) {
                if (error) {
                    return callback(error);
                }
                var org = members.map(function (member) {
                    return {
                        FullName:  member.FullName,
                        Title: member.Position,
                        Department: member.GroupDepartmentName,
                        MemberId: member.hgId,
                        UserId: member.UserId,
                        Level: 1
                    };
                });
                findSubordinates(org, function () {
                    callback(null, org);
                });
            });
        };

        this.GetActiveMembersByGroupId = function (params, callback) {
            EntityCache.Member.find({
                MembershipStatus: MemberEnums.Status.Active,
                GroupId: params.GroupId
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetMembersByCriteria = function (params, callback) {
            var query = {
                    MembershipStatus: MemberEnums.Status.Active,
                    GroupId: params.GroupId
                },
                loadManagerMemberIds = function (lParams, lcallback) {
                    if (!lParams.HasSubordinates) {
                        return lcallback(null, []);
                    }
                    EntityCache.Member.find({
                        GroupId: lParams.GroupId,
                        MembershipStatus: MemberEnums.Status.Active
                    }, {
                        MyManagers: true
                    }, function (error, members) {
                        var managerMemberIds = [];
                        if (error) {
                            return lcallback(error);
                        }
                        members.forEach(function (m) {
                            m.MyManagers.forEach(function (mm) {
                                if (managerMemberIds.indexOf(mm.MemberId) === -1) {
                                    managerMemberIds.push(mm.MemberId);
                                }
                            });
                        });
                        return lcallback(null, managerMemberIds);
                    });
                },
                projection = {};
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            if (params.DepartmentId) {
                query.GroupDepartmentId = params.DepartmentId;
            }
            if (params.LocationId) {
                query['Location.hgId'] = params.LocationId;
            }
            if (params.RolesInGroup) {
                query.RolesInGroup = params.RolesInGroup;
            }
            if (params.HgIdOnly) {
                projection = {hgId: true};
            }
            loadManagerMemberIds({
                GroupId: params.GroupId,
                HasSubordinates: params.HasSubordinates
            }, function (error, managerMemberIds) {
                if (error) {
                    return callback(error);
                }
                if (params.HasSubordinates) {
                    query.hgId = {$in: managerMemberIds};
                }
                EntityCache.Member.find(query, projection)
                    .skip(parseInt(params.Skip, 10) || 0)
                    .limit(parseInt(params.Take, 10) || 0)
                    .exec(callback);
            });
        };

        this.GetMembersByGroupId = function (params, callback) {
            var fields = params.Fields || {},
                query = {
                    GroupId: params.GroupId
                };
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            if (params.DepartmentId) {
                query.GroupDepartmentId = params.DepartmentId;
            }
            if (params.LocationId) {
                query['Location.hgId'] = params.LocationId;
            }
            if (params.RolesInGroup) {
                query.RolesInGroup = params.RolesInGroup;
            }
            if (params.ManagerId) {
                query['MyManagers.MemberId'] = params.ManagerId;
            }
            if (params.MemberStatus) {
                query.MembershipStatus = {
                    $in: params.MemberStatus
                };
            }
            if (params.SelfMemberId && params.ExcludeSelf) {
                query.hgId = {
                    $ne: params.SelfMemberId
                };
            }
            EntityCache.Member.find(query, fields)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetMembersByGroupIdCount = function (params, callback) {
            EntityCache.Member.count({
                GroupId: params.GroupId,
                MembershipStatus: params.MembershipStatus
            }, callback);
        };

        this.TransferManagerSubordinates = function (params, callback) {
            Async.each(params.DirectReports, function (directReportId, eachCb) {
                EntityCache.Member.findOne({
                    hgId: directReportId
                }, function (err, member) {
                    var myManagers;
                    if (err) {
                        return eachCb(err);
                    }
                    myManagers = member.MyManagers.map(function (manager) {
                        return manager.MemberId;
                    });
                    if (!myManagers.length) {
                        return eachCb();
                    }
                    if (myManagers.indexOf(params.NewManager.hgId) > -1) {
                        return eachCb();
                    }
                    member.MyManagers.splice(myManagers.indexOf(params.OldManager.hgId), 1, {
                        FullName: params.NewManager.FullName,
                        UserId: params.NewManager.UserId,
                        MemberId: params.NewManager.hgId
                    });
                    member.save(function (err) {
                        eachCb(err);
                    });
                });
            }, callback);
        };

        this.GetRecentlyOnBoardedMember = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active
            }, null, {
                sort: {
                    CreatedDate: -1
                },
                limit: params.Take
            }, callback);
        };

        this.GetMembersByAnniversary = function (params, callback) {
            var nowDate = new Date();

            EntityCache.Member.find({
                MembershipStatus: EntityEnums.MembershipStatus.Active,
                GroupId: params.GroupId,
                $where: [
                    'var d = new Date(this.StartingDate); return d.getUTCDate() === ',
                    nowDate.getDate(),
                    ' && d.getUTCMonth() === ',
                    nowDate.getMonth(),
                    ' && d.getUTCFullYear() !== ',
                    nowDate.getUTCFullYear()
                ].join('')
            }, {UserId: 1, StartingDate: 1})
                .skip(parseInt(params.skip, 10) || 0)
                .limit(parseInt(params.take, 10) || 0)
                .exec(callback);
        };
        this.GetMembersWithDirectReportsPreselector = function (params, callback) {
            EntityCache.Member.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    MembershipStatus: MemberEnums.Status.Active,
                    hgId: {$in: params.PreSelectedId }
                }},
                {$project: {
                    _id: 0,
                    Id: '$hgId',
                    hgId: '$hgId',
                    Name: '$FullName',
                    FullName: '$FullName',
                    FirstName: '$FirstName',
                    LastName: '$LastName',
                    UserId: '$UserId',
                    AvatarId: '$UserId',
                    DepartmentName: '$GroupDepartmentName',
                    DepartmentId: '$GroupDepartmentId',
                    LocationName: '$Location.Name',
                    LocationId: '$Location.hgId',
                    MyManagers: '$MyManagers',
                    EmployeeId: '$EmployeeId',
                    Role: '$RolesInGroup',
                    Position: '$Position',
                    MailCD: '$MailCD',
                    Type: {$concat: ['MembersWithDirectReports']}
                }}
            ], callback);
        };
        this.GetMembersWithDirectReports = function (params, callback) {
            var query = {
                'MyManagers.MemberId': {$ne: ""}
            }, hMap = {},
                projection = {
                    _id: 0,
                    Id: '$hgId',
                    hgId: '$hgId',
                    Name: '$FullName',
                    FullName: '$FullName',
                    FirstName: '$FirstName',
                    LastName: '$LastName',
                    UserId: '$UserId',
                    AvatarId: '$UserId',
                    DepartmentName: '$GroupDepartmentName',
                    DepartmentId: '$GroupDepartmentId',
                    LocationName: '$Location.Name',
                    LocationId: '$Location.hgId',
                    MyManagers: '$MyManagers',
                    EmployeeId: '$EmployeeId',
                    Role: '$RolesInGroup',
                    Position: '$Position',
                    MailCD: '$MailCD',
                    Type: {$concat: ['MembersWithDirectReports']}
                },
                aggregateParam,
                aggregateFirstParam;
            params.Excluded = params.Excluded || [];
            params.Selected = params.Selected || [];
            params.Excluded = params.Excluded.concat(params.Selected.map(function (item) { return item.Id; }));
            if (params.SearchTerm) {
                query.$or = [{'MyManagers.FullName': {$regex: i18nHelper.convertTextToAscii(params.SearchTerm).fuzzy(), $options: 'i'}}];
            }
            if (params.Excluded.length) {
                query['MyManagers.MemberId'] = {$nin: params.Excluded};
            }
            aggregateFirstParam = [
                {$match: {
                    GroupId: params.GroupId,
                    MembershipStatus: MemberEnums.Status.Active,
                    'MyManagers.MemberId': {$exists: true}
                }},
                {$match: query},
                {$group: {
                    _id: '$MyManagers.MemberId',
                    DRCount: {$sum: 1}
                }}
            ];
            EntityCache.Member.aggregate(aggregateFirstParam, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!data || !data.length) {
                    return callback(null, []);
                }
                data.forEach(function (item) {
                    hMap[item._id[0]] = item.DRCount;
                });
                aggregateParam = [
                    {$match: {
                        GroupId: params.GroupId,
                        MembershipStatus: MemberEnums.Status.Active,
                        hgId: {$in: data.map(function (item) { return item._id[0]; })}
                    }},
                    {$project: AutocompleteEnums.SearchProjection(params, projection)},
                    {$project: AutocompleteEnums.SearchProximityProjection(projection)}
                ];
                if (!params.IgnoreProximitySort) {
                    aggregateParam.push({$sort: {ProximityScore: -1}});
                }
                aggregateParam.push({$skip: parseInt(params.Skip, 10) || 0});
                if (!params.NoLimit) {
                    aggregateParam.push({$limit: parseInt(params.Take, 10) || 10});
                }
                EntityCache.Member.aggregate(aggregateParam, function (error, members) {
                    if (error) {
                        return callback(error);
                    }
                    members.forEach(function (item) {
                        item.DRCount = hMap[item.Id];
                    });
                    callback(null, members);
                });
            });
        };
        this.GetMemberDepartmentsMap = function (params, callback) {
            var vData = {};
            EntityCache.Member.find({
                GroupId: params.GroupId,
                hgId: {$in: params.MemberIds}
            }, {
                hgId: 1,
                GroupDepartmentName: 1
            }, function (error, members) {
                if (error) {
                    return callback(error);
                }
                members.forEach(function (item) {
                    vData[item.hgId] = {
                        DepartmentName: item.GroupDepartmentName,
                        DepartmentId: item.GroupDepartmentId
                    };
                });
                callback(null, vData);
            });
        };

        this.UpdateMemberIntegration = function (params, callback) {
            var members = params.Members;
            if (!members) {
                return callback('business.mem.pro.mmi');
            }
            Async.each(members, function (member, eCb) {
                EntityCache.Member.update({
                    hgId: member.MemberId
                }, {
                    $addToSet: {
                        Integration: member.Integration
                    },
                    $set: {
                        ModifiedBy: params.UserId
                    }
                }, eCb);
            }, function (err) {
                callback(err, 'business.mem.pro.miu');
            });
        };

        this.GetMemberInfoByIntegration = function (params, callback) {
            EntityCache.Member.find({
                GroupId: params.GroupId,
                'Integration.Application': {
                    $ne: params.Application
                },
                MembershipStatus: params.MembershipStatus
            }, params.Fields || null)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetPointMasterMember = function (params, callback) {
            EntityCache.Member.findOne({
                hgId: params.PointMasterMemberId
            }, function (err, member) {
                callback(err ? 'server.hge.grp.elm' : null, member);
            });
        };

        this.GetMembersForProvision = function (params, callback) {
            var dataIndex = {},
                cursor = EntityCache.UserInfo.aggregate([
                    {$match: {
                        "Preference.DefaultGroupId": params.GroupId
                    }},
                    {$lookup: {
                        from: 'Member',
                        localField: 'hgId',
                        foreignField: 'UserId',
                        as: 'User_Member_Record'
                    }},
                    {$project: {
                        _id: 0,
                        UserId: "$hgId",
                        UserName: "$LowercaseUserName",
                        Email: "$UserPersonal.PrimaryEmail",
                        SuppressBirthday: "$Preference.SuppressBirthday",
                        SuppressAnniversary: "$Preference.SuppressAnniversary",
                        MemberId: {$arrayElemAt: [ "$User_Member_Record.hgId", 0]},
                        Status: {$arrayElemAt: [ "$User_Member_Record.MembershipStatus", 0]},
                        Role: {$arrayElemAt: [ "$User_Member_Record.RolesInGroup", 0]}
                    }}
                ]).cursor({batchSize: 250}).exec();
            cursor.on('data', function (item) {
                dataIndex[item.UserName] = item;
            });
            cursor.on('end', function () {
                return callback(null, dataIndex);
            });
        };

        this.GetProductSuggestionApprovers = function (params, callback) {
            EntityCache.Member.find({
                AddedPermissions: MemberEnums.MemberPermission.ApproveProductSuggestion.Name,
                MembershipStatus: EntityEnums.MembershipStatus.Active,
                GroupId: params.GroupId
            }, {
                hgId: true,
                UserId: true,
                FullName: true,
                _id: false
            }, function (err, approvers) {
                if (err) {
                    return callback('server.hge.grp.elms');
                }
                callback(null, approvers);
            });
        };

        this.UpdateMemberLocationName = function (params, callback) {
            if (!params.GroupId || !params.LocationId || !params.LocationName) {
                return callback();
            }
            EntityCache.Member.update({
                GroupId: params.GroupId,
                'Location.hgId': params.LocationId
            }, {
                $set: {
                    Location: {
                        hgId: params.LocationId,
                        Name: params.LocationName
                    },
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };

        this.LoadRecipentMembers = function (params, callback) {
            EntityCache.Member.find({
                hgId: {
                    $in: params.RecipientMemberIds
                },
                GroupId: params.GroupId
            }, function (err, recipients) {
                callback(err ? 'server.hge.grp.elms' : null, recipients);
            });
        };

        this.IsManagerPresentInDirectReports = function (params, callback) {
            EntityCache.Member.count({
                hgId: {
                    $in: params.DirectReports
                },
                'MyManagers.MemberId': params.NewManager.hgId
            }, callback);
        };

        this.GetMembersByUserNames = function (params, callback) {
            if (!params.UserNames || !params.UserNames.length) {
                return callback();
            }
            EntityCache.UserInfo.aggregate([
                {$match: {
                    UserName: {$in: params.UserNames}
                }},
                {$lookup: {
                    from: 'Member',
                    localField: 'hgId',
                    foreignField: 'UserId',
                    as: 'User_Member_Record'
                }},
                {$project: {
                    UserId: "$hgId",
                    UserName: "$LowercaseUserName",
                    MemberId: {$arrayElemAt: [ "$User_Member_Record.hgId", 0]},
                    MembershipStatus: {$arrayElemAt: [ "$User_Member_Record.MembershipStatus", 0]},
                    FullName: {$arrayElemAt: [ "$User_Member_Record.FullName", 0]},
                    EmployeeId: {$arrayElemAt: [ "$User_Member_Record.EmployeeId", 0]},
                    MyManagers: {$arrayElemAt: [ "$User_Member_Record.MyManagers", 0]}
                }}
            ], callback);
        };
        this.GetMemberByEmail = function (params, callback) {
            if (!params.Email || !params.GroupId) {
                return callback();
            }
            EntityCache.UserInfo.aggregate([
                {$match: {
                    'UserPersonal.PrimaryEmail': new RegExp(params.Email, "i"),
                    'Preference.DefaultGroupId': params.GroupId
                }},
                {$lookup: {
                    from: 'Member',
                    localField: 'hgId',
                    foreignField: 'UserId',
                    as: 'User_Member_Record'
                }},
                {$project: {
                    UserId: "$hgId",
                    UserName: "$LowercaseUserName",
                    MemberId: {$arrayElemAt: [ "$User_Member_Record.hgId", 0]},
                    MembershipStatus: {$arrayElemAt: [ "$User_Member_Record.MembershipStatus", 0]},
                    FullName: {$arrayElemAt: [ "$User_Member_Record.FullName", 0]}
                }}
            ], callback);
        };
        this.GetGroupCustomMemberField = function (params, callback) {
            EntityCache.GroupCustomMemberField.findOne({GroupId: params.GroupId}, params.Fields || {}, {lean: true}, callback);
        };
        this.CheckIsSubordinate = function (params, callback) {
            if (params.MemberId === params.SubMemberId) {
                return callback(null, {IsSubordinate: false});
            }
            EntityCache.Member.findOne({
                hgId: params.SubMemberId,
                GroupId: params.GroupId,
                MembershipStatus: MemberEnums.Status.Active
            }, function (error, subMember) {
                if (error) {
                    return callback(error);
                }
                if (!subMember) {
                    return callback("services.int.mem.elm");
                }
                if (subMember.MyManagers.some(function (manager) {
                        return manager.MemberId === params.MemberId;
                    })) {
                    return callback(null, {IsSubordinate: true});
                }
                self.GetManagerHierarchy({
                    GroupId: params.GroupId,
                    Managers: subMember.MyManagers.map(function (m) {
                        return m.MemberId;
                    })
                }, function (error, managerIds) {
                    if (error) {
                        return callback(error);
                    }
                    if (managerIds.indexOf(params.MemberId) > -1) {
                        return callback(null, {IsSubordinate: true});
                    }
                    callback(null, {IsSubordinate: false});
                });
            });
        };
        this.GetManagerHierarchy = function (params, callback) {
            // params.GroupId = GUID of company
            // params.Managers = array of manager member id's
            var managers = {},
                recurseLevels = {},
                cacheKey = 'ManagerHierarchyMap-' + params.GroupId,
                cacheKeyBeingBuilt = 'ManagerHierarchyMapBuilding-' + params.GroupId,
                getManagersByManagerIds = function () {
                    var managerTree = [],
                        deDupe = {};
                    if (params.Managers) {
                        params.Managers.forEach(function (m) {
                            managerTree.push(m);
                            if (managers[m]) {
                                managerTree = managerTree.concat(managers[m]);
                            }
                        });
                    }
                    // de-dupe
                    managerTree.forEach(function (mt) {
                        deDupe[mt] = 1;
                    });
                    callback(null, Object.keys(deDupe));
                },
                loadGroupMembers = function (params, fcallback) {
                    if (params.AllMembers) {
                        return fcallback(null, params.AllMembers);
                    }
                    EntityCache.Member.find({
                        GroupId: params.GroupId,
                        MembershipStatus: EntityEnums.MembershipStatus.Active
                    }, {
                        _id: 0,
                        MyManagers: 1,
                        hgId: 1
                    }, {
                        lean: true
                    }, fcallback);
                };
            HgCache.GlobalGet(cacheKeyBeingBuilt, function (berr, bret) {
                if (bret && bret === 'true') {
                    return callback(null, []);
                }
                HgCache.GlobalGet(cacheKey, function (err, ret) {
                    if (err || !ret) {
                        // this is fire and forget cache set so don't have to wrap the rest into the return callback
                        HgCache.GlobalSet(cacheKeyBeingBuilt, 'true', function (cerr) {
                            if (cerr) {
                                HgLog.info('*** Unable to set value to Redis: ' + cerr.toString() + ' ***');
                            }
                        }, ConstantEnums.SECONDS_IN_TWENTY_FOUR_HOURS);
                        loadGroupMembers(params, function (err, members) {
                            var allMembers = {},
                                recurseManagerTree = function (orig, next) {
                                    if (managers[next] && recurseLevels[orig]) {
                                        recurseLevels[orig] -= 1;
                                        managers[next].forEach(function (m) {
                                            if (managers[orig].indexOf(m) === -1) {
                                                managers[orig].push(m);
                                            }
                                            if (orig !== m) {
                                                recurseManagerTree(orig, m);
                                            }
                                        });
                                    }
                                };
                            if (err) {
                                return callback(err);
                            }
                            members.forEach(function (member) {
                                if (member.MyManagers) {
                                    member.MyManagers.forEach(function (m) {
                                        if (!managers[m.MemberId]) {
                                            managers[m.MemberId] = [];
                                        }
                                    });
                                }
                                allMembers[member.hgId] = member.MyManagers;
                            });
                            Object.keys(managers).forEach(function (key) {
                                recurseLevels[key] = process.env.RECURSE_LEVEL || 20;
                                if (allMembers[key]) {
                                    managers[key] = managers[key].concat(allMembers[key].map(function (m) {
                                        return m.MemberId;
                                    }));
                                }
                            });
                            Object.keys(managers).forEach(function (key) {
                                recurseManagerTree(key, key);
                            });
                            HgCache.GlobalSet(cacheKey, managers, function (err) {
                                if (err) {
                                    HgLog.info('*** Unable to set value to Redis: ' + err.toString() + ' ***');
                                }
                                // this is fire and forget cache delete
                                HgCache.GlobalDelete(cacheKeyBeingBuilt, function (derr) {
                                    if (derr) {
                                        HgLog.info('*** Unable to set value to Redis: ' + derr.toString() + ' ***');
                                    }
                                });
                                return getManagersByManagerIds(callback);
                            }, ConstantEnums.SECONDS_IN_TWENTY_FOUR_HOURS);
                        });
                    } else {
                        managers = JSON.parse(ret);
                        getManagersByManagerIds(callback);
                    }
                });
            });

        };

        this.GetGroupDepartmentMemberCount = function (params, callback) {
            var query = {
                GroupId: params.GroupId
            },
                aggregateParam;
            if (params.Status) {
                query.MembershipStatus = params.Status;
            }
            if (params.MemberIds) {
                query.hgId = {$in: params.MemberIds};
            }
            if (params.DepartmentIds) {
                query.GroupDepartmentId = {$in: params.DepartmentIds};
            }
            aggregateParam = [
                {$match: query},
                {$group: {
                    _id: {
                        DepartmentId: "$GroupDepartmentId",
                        DepartmentName: "$GroupDepartmentName"
                    },
                    count: {$sum: 1}
                }},
                {$skip: params.Skip}
            ];
            if (params.Take) {
                aggregateParam.push({$limit: params.Take});
            }
            EntityCache.Member.aggregate(aggregateParam, function (error, data) {
                if (error) {
                    return callback(error);
                }
                var deptDataIndex = {};
                data.forEach(function (item) {
                    deptDataIndex[item._id.DepartmentId] = {
                        Name: item._id.DepartmentName,
                        Count: item.count
                    };
                });
                callback(null, deptDataIndex);
            });
        };
    };

module.exports = MemberProcessor;
