/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    BadgeProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            FileHelper = require('../util/FileHelper.js'),
            guid = require('node-uuid'),
            Async = require('async'),
            self = this,
            HgError = require('../common/HgError.js');

        this.GetBadgeById = function (params, callback) {
            EntityCache.Badge.findOne({hgId: params.BadgeId}, function (err, badge) {
                if (!err) {
                    if (callback) {
                        callback(err, badge);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badge));
                    }
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                }
            });
        };

        this.GetBadgeByFileName = function (params, callback) {
            EntityCache.Badge.findOne({Filename: params.Filename}, function (err, badge) {
                if (!err) {
                    if (callback) {
                        callback(err, badge);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badge));
                    }
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                }
            });
        };

        this.GetBadgesByFileNames = function (params, callback) {
            if (!params.Filenames || !params.Filenames.length) {
                return callback ? callback('server.hge.bdg.elb') : EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
            }
            EntityCache.Badge.find({'Filename' : {$in : params.Filenames}}, function (err, badges) {
                if (!err) {
                    if (callback) {
                        callback(null, badges);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badges));
                    }
                } else {
                    if (callback) {
                        callback('server.hge.bdg.elb');
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                    }
                }
            });
        };

        this.GetAllBadges = function (params) {
            EntityCache.Badge.find({Archive: false}).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 10).exec(function (err, badges) {
                if (!err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badges));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                }
            });
        };

        this.GetBadges = function (params, callback) {
            var mquery = {
                    Archive: false,
                    $or: [
                        {Federated: false},
                        {Federated: null},
                        {GroupId: params.GroupId}
                    ]
                };
            if (params.SearchTerm) {
                params.SearchTerm = [params.SearchTerm, params.SearchTerm.replace(/\s/g, '')].join("|");
                mquery.BadgeName = {
                    $regex: params.SearchTerm,
                    $options: 'i'
                };
            }
            if (params.SpecialUsage) {
                if (params.SpecialUsage !== 'None') {
                    mquery.SpecialUsages = {$in: params.SpecialUsage};
                } else {
                    mquery.SpecialUsages = {$size: 0};
                }
            }
            if (params.Category) {
                mquery.Category = params.Category;
            }
            EntityCache.Badge.find(mquery).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, badges) {
                if (!err) {
                    if (callback) {
                        callback(null, badges);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badges));
                    }
                } else {
                    if (callback) {
                        callback('server.hge.bdg.elb');
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                    }
                }
            });

        };

        this.GetCategories = function (params, callback) {
            var mquery = {
                    Archive: false,
                    $or: [
                        {Federated: false},
                        {Federated: null},
                        {GroupId: params.GroupId}
                    ]
                },
                i,
                categories = [];
            if (params.SpecialUsage) {
                if (params.SpecialUsage !== 'None') {
                    mquery.SpecialUsages = {$in: params.SpecialUsage};
                } else {
                    mquery.SpecialUsages = {$size: 0};
                }
            }
            EntityCache.Badge.find(mquery).exec(function (err, badges) {
                var len = badges.length;
                for (i = 0; i < len; i += 1) {
                    categories = categories.concat(badges[i].Category);
                }
                categories = categories.filter(function (elem, index, self) {
                    return index === self.indexOf(elem);
                });
                if (!err) {
                    if (callback) {
                        callback(null, categories);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, categories));
                    }
                } else {
                    if (callback) {
                        callback('server.hge.bdg.elb');
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                    }
                }
            });
        };

        this.GetDefaultBadge = function (params) {
            EntityCache.Badge.findOne({Archive: false}, function (err, badge) {
                if (!err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badge));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                }
            });
        };

        this.Create = function (params, callback) {
            var badge = EntityCache.Badge(params.BadgeRequest);
            badge.hgId = params.BadgeRequest.hgId || guid.v1();
            badge.CreatedBy = params.UserId;
            badge.ModifiedBy = params.UserId;
            EntityCache.Badge.findOne({Filename: badge.Filename}, function (err, existingBadge) {
                if (err) {
                    if (callback) {
                        callback('server.hge.bdg.elb');
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.bdg.elb'));
                    }
                } else if (existingBadge) {
                    if (callback) {
                        callback('Badge with same fileName exist.');
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'Badge with same fileName exist.'));
                    }
                } else {
                    badge.save(function (err) {
                        if (!err) {
                            if (callback) {
                                callback(null, badge);
                            } else {
                                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badge));
                            }
                        } else {
                            if (callback) {
                                callback(HgError.Enums.Badge.ErrorSavingBadge);
                            } else {
                                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, HgError.Enums.Badge.ErrorSavingBadge));
                            }
                        }
                    });
                }
            });
        };

        this.Update = function (params, callback) {
            var BadgeRequest = params.BadgeRequest;
            EntityCache.Badge.update({
                hgId: BadgeRequest.hgId
            }, {
                $set: {
                    BadgeName: BadgeRequest.BadgeName,
                    Filename: BadgeRequest.Filename,
                    Tags: BadgeRequest.Tags,
                    Category: BadgeRequest.Category,
                    Archive: BadgeRequest.Archive,
                    Federated: BadgeRequest.Federated,
                    SpecialUsages: BadgeRequest.SpecialUsages,
                    GroupId: BadgeRequest.GroupId,
                    ModifiedBy: params.UserId
                }
            }, {
                upsert: false
            }, function (error) {
                if (error) {
                    if (callback) {
                        callback(HgError.Enums.Badge.ErrorUpdatingBadge);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Badge.ErrorUpdatingBadge));
                    }
                } else {
                    EntityCache.Badge.findOne({hgId: BadgeRequest.hgId}, function (error, badge) {
                        if (!error) {
                            if (callback) {
                                callback(null, badge);
                            } else {
                                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, badge));
                            }
                        } else {
                            if (callback) {
                                callback(HgError.Enums.Badge.ErrorUpdatingBadge);
                            } else {
                                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Badge.ErrorUpdatingBadge));
                            }

                        }
                    });
                }
            });
        };

        this.SaveOrUpdateBadges = function (params, callback) {
            var saveUpdateProvisionBadge = function (badge, callback) {
                var newParams = {
                    UserId: params.UserId,
                    BadgeRequest: {
                        BadgeName: badge.BadgeName,
                        Filename: badge.Filename,
                        Tags: badge.Tags,
                        Category: badge.Category,
                        Federated: badge.Federated,
                        SpecialUsages: badge.SpecialUsages,
                        Archive: false,
                        GroupId: params.GroupId,
                        ModifiedBy: params.UserId,
                        ModifiedDate: Date.now()
                    }
                };
                if (badge.hgId) {
                    newParams.BadgeRequest.hgId = badge.hgId;
                    self.Update(newParams, callback);
                } else {
                    self.Create(newParams, callback);
                }
            };
            if (params.Badges && params.Badges.rows && params.Badges.rows.length > 0) {
                Async.each(params.Badges.rows, saveUpdateProvisionBadge, function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, 'Provisioned Badge(s) Saved');
                    }
                });
            } else {
                callback(null, 'Provisioned Badge(s) Saved');
            }
        };
        this.CreateBadgeWithBackground = function (params, callback) {
            EntityCache.Badge.findOne({hgId: params.BadgeId}, function (error, badge) {
                if (error || !badge) {
                    return callback(error);
                }
                EntityCache.Badge.findOne({hgId: params.BackgroundBadgeId}, function (error, backgroundBadge) {
                    if (error || !backgroundBadge) {
                        return callback(error);
                    }
                    FileHelper.CompositeBackFront({
                        FrontImageFilename: badge.Filename,
                        BackImageFilename: backgroundBadge.Filename,
                        CompositeFilename: params.Id + '.svg',
                        FriendlyGroupId: params.FriendlyGroupId,
                        Callback: callback
                    });
                });
            });
        };
    };

module.exports = BadgeProcessor;
