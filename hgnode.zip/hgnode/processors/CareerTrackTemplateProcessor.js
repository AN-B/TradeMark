/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    CareerTrackTemplateProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            guid = require('node-uuid'),
            EventResponder = require('../util/EventResponder.js'),
            HgError = require('../common/HgError.js'),
            HgLog = require('../framework/HgLog'),
            FileHelper = require('../util/FileHelper.js');

        this.Create = function (params) {
            var i,
                len = params.MileStoneTemplates.length,
                trackTemplate = EntityCache.CareerTrackTemplate({
                    hgId : guid.v1(),
                    Title : params.Title,
                    TrackType : params.TrackType,
                    GroupId : params.GroupId,
                    GroupName : params.GroupName,
                    CreatedBy : params.UserId,
                    ModifiedBy : params.UserId,
                    AccessLevel : params.AccessLevel
                });
            trackTemplate.Goal = EntityCache.MileStone.MileStoneEmbedded({
                RecognitionTemplate : params.GoalTemplate
            });
            for (i = 0; i < len; i += 1) {
                trackTemplate.MileStones.push(EntityCache.MileStone.MileStoneEmbedded({
                    RecognitionTemplate : params.MileStoneTemplates[i]
                }));
            }
            trackTemplate.save(function (err) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrackTemplate.ErrorSavingCareerTrackTemplate));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'Track template created.'));
                }
            });
        };

        this.UpdateTemplate = function (params) {
            var needsTitle = false;
            if (!params.Template || !params.UserId) {
                EventResponder.RespondWithError(EventEmitterCache, params, 'Template was not specified.');
            } else {
                // hoisting may cause this line to fail if both var declaration and assignment is here
                needsTitle = params.Template.Goal.RecognitionTemplate.Title.length === 0;
                EntityCache.Group.findOne({'hgId' : params.Template.GroupId}, function (err, group) {
                    var i,
                        creditValue = params.Template.Goal.RecognitionTemplate.CreditValue,
                        len = params.Template.MileStones.length,
                        hasCreditValueInRange = false;
                    if (!err) {
                        if (params.Template.Goal.BadgeId) {
                            params.Template.Goal.RecognitionTemplate.hgId = guid.v1();
                            FileHelper.CopyBadgeImage({
                                BadgeId : params.Template.Goal.BadgeId,
                                FriendlyGroupId : group.FriendlyGroupId,
                                TemplateId : params.Template.Goal.RecognitionTemplate.hgId
                            });
                            delete params.Template.Goal.BadgeId;
                        }
                        for (i = 0; i < len; i += 1) {
                            if (!needsTitle) {
                                needsTitle = params.Template.MileStones[i].RecognitionTemplate.Title.length === 0;
                            }
                            if (params.Template.MileStones[i].hgId.length === 0) {
                                params.Template.MileStones[i].hgId = guid.v1();
                            }
                            params.Template.MileStones[i].DisplayName = params.Template.MileStones[i].RecognitionTemplate.Title;
                            if (params.Template.MileStones[i].BadgeId) {
                                params.Template.MileStones[i].RecognitionTemplate.hgId = guid.v1();
                                FileHelper.CopyBadgeImage({
                                    BadgeId : params.Template.MileStones[i].BadgeId,
                                    FriendlyGroupId : group.FriendlyGroupId,
                                    TemplateId : params.Template.MileStones[i].RecognitionTemplate.hgId
                                });
                                delete params.Template.MileStones[i].BadgeId;
                            }
                            if (!hasCreditValueInRange && (params.Template.MileStones[i].RecognitionTemplate.CreditValue > 0 && (params.Template.MileStones[i].RecognitionTemplate.CreditValue < group.CreditSetting.MinRecognition || params.Template.MileStones[i].RecognitionTemplate.CreditValue > group.CreditSetting.MaxRecognition))) {
                                hasCreditValueInRange = true;
                            }
                        }
                        if (needsTitle) {
                            EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.oam');
                        } else if (creditValue > 0 && (creditValue < group.CreditSetting.MinRecognition || creditValue > group.CreditSetting.MaxRecognition)) {
                            EventResponder.RespondWithError(EventEmitterCache, params,  'Credit value should be between ' + group.CreditSetting.MinRecognition + ' and ' + group.CreditSetting.MaxRecognition);
                        } else if (hasCreditValueInRange) {
                            EventResponder.RespondWithError(EventEmitterCache, params,  'Credit value should be between ' + group.CreditSetting.MinRecognition + ' and ' + group.CreditSetting.MaxRecognition);
                        } else {
                            params.Template.ModifiedBy = params.UserId;
                            params.Template.ModifiedDate = new Date().getTime();
                            if (params.Template._id) {
                                delete params.Template._id;
                            }
                            EntityCache.CareerTrackTemplate.update({'hgId' : params.Template.hgId}, params.Template, function (err) {
                                if (!err) {
                                    EventResponder.RespondWithData(EventEmitterCache, params, true);
                                } else {
                                    EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CareerTrack.ErrorLoadingCareerTrack);
                                }
                            });
                        }
                    }
                });
            }
        };
        //keep milestone weights at 100 % by adjusting the last milestone weight
        this.AdjustMileStoneWeights = function (params, callback) {
            var trackTemplate = params.CareerTrackTemplate,
                milestones =  trackTemplate.MileStones,
                len = milestones ? milestones.length : 0,
                totalWeight = 0,
                milestoneWeightType = trackTemplate.MilestoneWeightType,
                isValid = true;
            if (milestoneWeightType === "Custom") {//custom, adjust the last milestone's weight to make the total to 100%
                milestones.forEach(function (m, index) {
                    if (isNaN(m.Weight)) {
                        isValid = false;
                    } else if (parseInt(m.Weight, 10) < 1) {
                        isValid = false;
                    } else {
                        if (index === len - 1) {
                            if (isValid) {
                                m.Weight = totalWeight < 100 ? 100 - totalWeight : 0;
                            }
                        } else {
                            totalWeight += parseInt(m.Weight, 10);
                        }
                    }
                });
                EntityCache.CareerTrackTemplate.update({'hgId': params.TrackId}, {'MileStones': milestones}, function (err, data) {
                    if (!err) {
                        callback(null, data);
                    } else {
                        callback(err);
                    }
                });
            } else {
                callback(null, 'crtrk.tpp.err.mae');
            }
        };
        this.Update = function (params) {
            var i,
                len = params.MileStoneTemplates,
                trackTemplate = EntityCache.CareerTrackTemplate({
                    hgId : params.hgId,
                    Title : params.Title,
                    TrackType : params.TrackType,
                    GroupId : params.GroupId,
                    GroupName : params.GroupName,
                    CreatedBy : params.UserId,
                    ModifiedBy : params.UserId,
                    AccessLevel : params.AccessLevel,
                    Description : params.Description,
                    IsLinear : params.IsLinear
                });
            EntityCache.CareerTrackTemplate.remove({'hgId' : params.hgId}, function (err) {
                if (err) {
                    HgLog.error({methodName: 'CareerTrackTemplateProcessor.Update', error: err});
                }
            });
            trackTemplate.Goal = EntityCache.MileStone.MileStoneEmbedded({
                RecognitionTemplate : params.GoalTemplate
            });
            for (i = 0; i < len; i += 1) {
                trackTemplate.MileStones.push(EntityCache.MileStone.MileStoneEmbedded({
                    RecognitionTemplate : params.MileStoneTemplates[i]
                }));
            }
            trackTemplate.save(function (err) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrackTemplate.ErrorUpdatingCareerTrackTemplate));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'Track template updated'));
                }
            });
        };

        this.GetTemplates = function (params) {
            //THIS METHOD NEEDS TO BE REFACTORED
            var i,
                len,
                teamIds = [];
            EntityCache.Team.find({GroupId: params.GroupId, Status: 'Active', $or: [{'TeamMembers.MemberId': params.MemberId}, {IsPublic: true}]}, function (err, teams) {
                if (err) {
                    EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData, new EventData(params.correlationId, 'Error loading teams'));
                } else {
                    for (i = 0, len = teams.length; i < len; i += 1) {
                        teamIds.push(teams[i].hgId);
                    }
                    EntityCache.CareerTrackTemplate.find({'GroupId' : params.GroupId, $or : [{'TeamId' : {$in : teamIds}, 'AccessLevel' : 'WithinTeam'}, {'CreatedBy' : params.UserId}, {'AccessLevel' : 'WithinGroup'}]}, function (err, templates) {
                        if (!err) {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, templates));
                        } else {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.ett'));
                        }
                    });
                }
            });
        };

        this.GetTemplatesByIds = function (params) {
            EntityCache.CareerTrackTemplate.find({'hgId' : {$in : params.TemplateIds}}, function (err, templates) {
                if (!err) {
                    EventResponder.RespondWithData(EventEmitterCache, params, templates);
                } else {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.ett');
                }
            });
        };

        this.GetTemplateById = function (params) {
            EntityCache.CareerTrackTemplate.findOne({'hgId' : params.TemplateId}, function (err, template) {
                if (!err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, template));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.ett'));
                }
            });
        };

        this.DeleteTemplate = function (params) {
            EntityCache.CareerTrackTemplate.findOne({'hgId' : params.TemplateId}, function (err, template) {
                if (err || !template) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrackTemplate.ErrorLoadingCareerTrackTemplates));
                } else {
                    template.remove(function (err) {
                        if (err) {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrackTemplate.ErrorSavingCareerTrackTemplate));
                        } else {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'track template deleted'));
                        }
                    });
                }
            });
        };

        this.DeleteMileStone = function (params) {
            EntityCache.CareerTrackTemplate.update({
                hgId: params.TrackId
            }, {
                $pull: {
                    MileStones: {
                        hgId: params.MileStoneId
                    }
                },
                ModifiedBy: params.UserId
            }, function (err, data) {
                if (!err) {
                    EntityCache.CareerTrackTemplate.findOne({hgId: params.TrackId}, function (err, data) {
                        if (!err) {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, data));
                        } else {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.eum'));
                        }
                    });
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.eum'));
                }
            });
        };

        this.GetCareerTrackTemplatesByGroupId = function (params, callback) {
            EntityCache.CareerTrackTemplate.find({$or: [{'GroupId': params.GroupId}, {'MileStones.RecognitionTemplate.GroupId' : params.GroupId}]}, function (err, careerTrackTemplates) {
                if (!err) {
                    callback(null, careerTrackTemplates);
                } else {
                    callback(err);
                }
            });
        };
    };

module.exports = CareerTrackTemplateProcessor;
