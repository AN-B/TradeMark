/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    RelevancyProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            BucketEnums = require('../enums/BucketEnums.js'),
            guid = require('node-uuid'),
            self = this;

        this.AddRelevants = function (params, callback) {
            var relevancy = new EntityCache.MemberRelevancy({
                GroupId: params.GroupId,
                MemberId: params.SubjectMember.hgId,
                CreatedBy: params.UserId,
                ModifiedBy: params.UserId
            });
            self.AddItemsToBucket({
                Bucket: relevancy,
                Content: params.Relevants,
                BucketTypeName: BucketEnums.BucketTypes.MemberRelevancy.Name
            }, callback);
        };

        this.AddOneToMultiMembers = function (params, callback) {
            EntityCache.MemberRelevancy.find({
                GroupId: params.GroupId,
                MemberId: {$in: params.SubjectMemberIds},
                Status: BucketEnums.Status.Active,
                Size: {$lt: BucketEnums.BucketTypes.MemberRelevancy.BucketCap}
            }, function (error, relevancies) {
                if (error) {
                    return callback(error);
                }
                EntityCache.MemberRelevancy.update({
                    GroupId: params.GroupId,
                    hgId: {$in: relevancies.map(function (relevancy) {
                        return relevancy.hgId;
                    })}
                }, {
                    $push: {
                        Relevants: params.RelevantMemberId
                    },
                    $inc: {
                        Size: 1
                    },
                    $set: {
                        ModifiedBy: params.UserId
                    }
                }, {
                    multi: true
                }, function (error) {
                    var newRelevancies = [],
                        existingMemberIdMapping = {};//if existingMemberIdMapping[memberId] is true, memberId has an existing bucket
                    if (error) {
                        return callback(error);
                    }
                    relevancies.forEach(function (relevancy) {
                        existingMemberIdMapping[relevancy.MemberId] = true;
                    });
                    params.SubjectMemberIds.forEach(function (subjectMemberId) {
                        if (!existingMemberIdMapping[subjectMemberId]) {
                            newRelevancies.push({
                                hgId: guid.v1(),
                                GroupId: params.GroupId,
                                MemberId: subjectMemberId,
                                Relevants: [params.RelevantMemberId],
                                Size: 1,
                                Status: BucketEnums.Status.Active,
                                CreatedBy: params.UserId,
                                ModifiedBy: params.UserId
                            });
                        }
                    });
                    EntityCache.MemberRelevancy.create(newRelevancies, callback);
                });
            });
        };

        this.AddRelevantMember = function (params, callback) {
            EntityCache.MemberRelevancy.count({//check if the RelevantMemberId is already in SubjectMemberId's relevants list
                GroupId: params.GroupId,
                MemberId: params.SubjectMemberId,
                Relevants: params.RelevantMemberId
            }, function (error, count) {
                if (error) {
                    return callback(error);
                }
                if (count) {
                    return callback();
                }
                self.AddRelevants({
                    GroupId: params.GroupId,
                    SubjectMember: {
                        hgId: params.SubjectMemberId
                    },
                    UserId: params.UserId,
                    Relevants: [params.RelevantMemberId]
                }, callback);
            });
        };

        this.SaveInteraction = function (params, callback) {
            var incObj = {
                    ModifiedBy: params.UserId,
                    $inc: {}
                };
            Object.keys(params.Updates).forEach(function (fieldName) {
                incObj.$inc[fieldName] = params.Updates[fieldName];
            });

            EntityCache.MemberInteraction.findOne({
                GroupId: params.GroupId,
                SubjectMemberId: params.SubjectMemberId,
                ObjectMemberId: params.ObjectMemberId
            }, function (error, interaction) {
                if (error) {
                    return callback(error);
                }
                if (interaction) {
                    Object.keys(params.Updates).forEach(function (fieldName) {
                        if (interaction[fieldName]) {
                            interaction[fieldName] += params.Updates[fieldName];
                        } else {
                            interaction[fieldName] = params.Updates[fieldName];
                        }
                    });
                } else {
                    interaction = new EntityCache.MemberInteraction({
                        GroupId: params.GroupId,
                        SubjectMemberId: params.SubjectMemberId,
                        ObjectMemberId: params.ObjectMemberId,
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId
                    });
                    Object.keys(params.Updates).forEach(function (fieldName) {
                        interaction[fieldName] = params.Updates[fieldName];
                    });
                }
                interaction.save(callback);
            });
        };

        this.RemoveMemberFromRelevancy = function (params, callback) {
            EntityCache.MemberRelevancy.update({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                Status: BucketEnums.Status.Active
            }, {
                $set: {
                    Status: BucketEnums.Status.Archived
                }
            }, {
                multi: true
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                EntityCache.MemberRelevancy.update({
                    GroupId: params.GroupId,
                    Relevants: params.MemberId,
                    Status: BucketEnums.Status.Active
                }, {
                    $pull: {
                        Relevants: params.MemberId
                    },
                    $inc: {
                        Size: -1
                    }
                }, {
                    multi: true
                }, callback);
            });
        };

        this.GetMemberInteractionsByMemberIds = function (params, callback) {
            EntityCache.MemberInteraction.find({
                GroupId: params.GroupId,
                $or: [{
                    SubjectMemberId: {$in: params.MemberIds}
                }, {
                    ObjectMemberId: {$in: params.MemberIds}
                }]
            }, callback);
        };

        this.GetRelevants = function (params, callback) {
            self.GetItemsFromBuckets({
                Bucket: {
                    GroupId: params.GroupId,
                    MemberId: params.SubjectMemberId
                },
                BucketTypeName: BucketEnums.BucketTypes.MemberRelevancy.Name
            }, callback);
        };

        this.GetBulkRelevance = function (params, callback) {
            self.GetBulkItemsFromBuckets({
                Buckets: params.SubjectsMembers.map(function (member) {
                    return {
                        GroupId: member.GroupId,
                        MemberId: member.MemberId
                    };
                }),
                BucketTypeName: BucketEnums.BucketTypes.MemberRelevancy.Name
            }, callback);
        };

        this.RemoveRelevants = function (params, callback) {
            var relevancy = new EntityCache.MemberRelevancy({
                GroupId: params.GroupId,
                MemberId: params.SubjectMemberId,
                ModifiedBy: params.UserId
            });
            self.RemoveItemsFromBucket({
                Bucket: relevancy,
                Content: params.Relevants,
                BucketTypeName: BucketEnums.BucketTypes.MemberRelevancy.Name
            }, callback);
        };
    };

module.exports = RelevancyProcessor;