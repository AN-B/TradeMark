/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    TransactionProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventResponder = require('../util/EventResponder.js'),
            FriendlyIdHelper = require('../util/FriendlyIdHelper.js'),
            RowVersionHelper = require('../util/RowVersionHelper.js'),
            HgLog = require('../framework/HgLog'),
            Uuid = require('node-uuid'),
            ParamUtil = require('../util/params.js');

        function validTransaction(transactionParams) {

            return ParamUtil.checkForRequiredParameters(
                [
                    'AccountId',
                    'GroupId',
                    'UserId',
                    'GroupName',
                    'UserName',
                    'FirstName',
                    'LastName',
                    'Type',
                    'Status',
                    'CreditQuantity'
                ],
                transactionParams
            );

        }
        function parseTransaction(transactionParams, userId, callback) {

            var transaction;
            if (validTransaction(transactionParams)) {
                transaction = EntityCache.Transaction();
                transaction.AccountId = transactionParams.AccountId;
                transaction.GroupId = transactionParams.GroupId;
                transaction.GroupName = transactionParams.GroupName;
                transaction.UserId = transactionParams.UserId;
                transaction.UserName = transactionParams.UserName;
                transaction.FirstName = transactionParams.FirstName;
                transaction.LastName = transactionParams.LastName;
                transaction.Type = transactionParams.Refund ? 'Refund' : transactionParams.Type;
                transaction.Info = transactionParams.Info || '';
                transaction.Status = transactionParams.Status;
                transaction.ReferenceId = transactionParams.ReferenceId;
                transaction.CreditQuantity = transactionParams.CreditQuantity;
                transaction.UnitType = transactionParams.UnitType || 'Credit';
                transaction.ModifiedBy = userId;
                transaction.ModifiedDate = new Date().getTime();
                callback(null, transaction);
            } else {
                callback('server.hge.tran.tmp');
            }

        }

        // Note this method defaults Row Version to 1.
        this.InsertBulkTransactions = function (params, callback) {
            FriendlyIdHelper.GenerateFriendlyId({correlationId: params.correlationId, EntityName: 'Transaction'}, function (error, data) {
                var parseError = null;
                if (error !== undefined && error !== null) {
                    return callback(error);
                }
                if (!params.BulkTransactions || params.BulkTransactions.length === 0) {
                    return callback(null, 'No Transactions to Create');
                }
                params.BulkTransactions.forEach(function (transaction) {
                    parseTransaction(transaction, params.UserId, function (error, ret) {
                        if (!error) {
                            transaction = ret;
                            transaction.CreatedBy = params.UserId;
                            transaction.CreatedDate = new Date().getTime();
                            transaction.hgId = Uuid.v1();
                            transaction.FriendlyId = data.payload;
                            transaction.ReferenceNumbers = params.ReferenceNumbers;
                            transaction.GenerateRowVersion = 1;
                        } else {
                            HgLog.error({methodName: 'InsertBulkTransactions', error: parseError});
                            parseError = error;
                        }
                    });
                });
                if (!parseError) {
                    EntityCache.Transaction.create(params.BulkTransactions, function (error) {
                        callback(error, 'Transactions Added');
                    });
                } else {
                    callback(parseError);
                }

            });
        };

        this.InsertTransaction = function (params, callback) {
            FriendlyIdHelper.GenerateFriendlyId({correlationId: params.correlationId, EntityName: 'Transaction'}, function (error, friendlyIdData) {
                if (error !== undefined && error !== null) {
                    callback(error);
                } else {
                    parseTransaction(params.TransactionParameters, params.UserId, function (parseError, data) {
                        if (!parseError) {
                            var newTransaction = data;
                            newTransaction.CreatedBy = params.UserId;
                            newTransaction.CreatedDate = new Date().getTime();
                            newTransaction.hgId = Uuid.v1();
                            newTransaction.FriendlyId = friendlyIdData.payload;
                            newTransaction.ReferenceNumbers = params.ReferenceNumbers;
                            newTransaction.RowVersion = 1;//by refactoring, we don't need to use hgcommon/RowVersion table to maintain row version, so just set it to 1
                            newTransaction.save(function (error, transaction) {
                                if (error) {
                                    callback(error);
                                } else {
                                    callback(null, transaction);
                                }
                            });

                        } else {
                            callback(parseError);
                        }
                    });
                }
            });
        };

        this.GetTransaction = function (params) {
            EntityCache.Transaction.find({'hgId': params.hgId}).sort({RowVersion : -1}).limit(1).exec(function (error, transaction) {
                if (error) {
                    EventResponder.RespondWithError(EventEmitterCache, params, error);
                } else {
                    if (transaction && transaction.length > 0) {
                        EventResponder.RespondWithData(EventEmitterCache, params, transaction[0]);
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.tran.tnf');
                    }
                }
            });
        };

        this.UpdateTransaction = function (params) {
            EntityCache.Transaction.findOne({'hgId': params.TransactionParameters.hgId}).limit(1).sort('RowVersion').exec(function (originalError, originalTransaction) {
                if (originalError) {
                    EventResponder.RespondWithError(EventEmitterCache, params, originalError);
                } else {
                    RowVersionHelper.GenerateRowVersion({EntityId : params.TransactionParameters.hgId, EntityType : 'Transaction'}, function (rowVersionError, newRowVersion) {
                        if (rowVersionError) {
                            EventResponder.RespondWithError(EventEmitterCache, params, rowVersionError);
                        } else {
                            parseTransaction(params.TransactionParameters, originalTransaction.UserId, function (parseError, data) {
                                if (!parseError) {
                                    var newTransaction = data;
                                    newTransaction.hgId = originalTransaction.hgId;
                                    newTransaction.AccountId = originalTransaction.AccountId;
                                    newTransaction.GroupId = originalTransaction.GroupId;
                                    newTransaction.UserId = originalTransaction.UserId;
                                    newTransaction.ReferenceNumbers = originalTransaction.ReferenceNumbers;
                                    newTransaction.GroupName = originalTransaction.GroupName;
                                    newTransaction.UserName = originalTransaction.UserName;
                                    newTransaction.FirstName = originalTransaction.FirstName;
                                    newTransaction.LastName = originalTransaction.LastName;
                                    newTransaction.CreatedBy = originalTransaction.CreatedBy;
                                    newTransaction.CreatedDate = originalTransaction.CreatedDate;
                                    newTransaction.FriendlyId = originalTransaction.FriendlyId;
                                    newTransaction.RowVersion = newRowVersion;
                                    newTransaction.save(function (updatedError, updatedTransaction) {
                                        if (updatedError) {
                                            EventResponder.RespondWithError(EventEmitterCache, params, updatedError);
                                        } else {
                                            EventResponder.RespondWithData(EventEmitterCache, params, updatedTransaction);
                                        }
                                    });
                                } else {
                                    EventResponder.RespondWithError(EventEmitterCache, params, parseError);
                                }

                            });

                        }
                    });
                }
            });
        };

        this.GetTransactionsForAccounts = function (params) {
            EntityCache.Transaction.find({'AccountId': { $in: params.AccountIds }}).sort({'CreatedDate' : -1}).exec(function (error, transactions) {
                if (error) {
                    EventResponder.RespondWithError(EventEmitterCache, params, error);
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, RowVersionHelper.filterToLatestVersions(transactions, 'hgId', 'RowVersion'));
                }
            });
        };

        this.GetTransactionsForAccount = function (params) {
            params.AccountIds = [params.AccountId];
            this.GetTransactionsForAccounts(params);
        };

        this.GetTransactionsByReferenceNumber = function (params) {
            var mquery;
            if (params.ReferenceValue && params.ReferenceType) {
                mquery = EntityCache.Transaction.find({'ReferenceNumbers': {$elemMatch : {'TypeName' : params.ReferenceType, 'Value' : params.ReferenceValue}}, 'GroupId' : params.GroupId});
            } else if (params.ReferenceValue) {
                mquery = EntityCache.Transaction.find({'ReferenceNumbers.Value': params.ReferenceValue, 'GroupId' : params.GroupId});
            } else if (params.ReferenceType) {
                mquery = EntityCache.Transaction.find({'ReferenceNumbers.TypeName': params.ReferenceType, 'GroupId' : params.GroupId});
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, 'You need to specify either reference type or value');
                return;
            }

            mquery.exec(function (error, transactions) {
                if (error) {
                    EventResponder.RespondWithError(EventEmitterCache, params, error);
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, transactions);
                }
            });
        };

        this.GetGroupInvoiceBillMeLaterFee = function (params, callback) {
            var dataRecords = {},
                query = {
                    Type : 'BillMeLater',
                    Status : { $nin : [ 'Complete', 'Failed'] },
                    CreatedDate : {
                        $lt : params.EndDate
                    }
                },
                matchQuery = {
                    $match : query
                },
                groupQuery = {
                    $group : {
                        _id : {
                            GroupId : '$GroupId'
                        },
                        TotalCreditQuantity : { $sum : '$CreditQuantity'}
                    }
                };
            EntityCache.Transaction.aggregate([matchQuery, groupQuery], function (error, data) {
                if (error) {
                    callback(error);
                } else {
                    data.map(function (item) {
                        if (!dataRecords[item._id.GroupId]) {
                            dataRecords[item._id.GroupId] = item.TotalCreditQuantity;
                        }
                    });
                    callback(null, dataRecords);
                }
            });
        };

        this.GetFilteredTransactions = function (params, callback) {
            var trans = [],
                query = {},
                startDate = 0,
                endDate = 0;
            if (params.Unit) {
                query.UnitType = params.Unit;
            }

            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            if (params.UserId) {
                query.UserId = params.UserId;
            }
            if (params.AccountIds) {
                query.AccountId = {$in: params.AccountIds};
            }
            if (params.StartDate) {
                params.StartDate = new Date(params.StartDate);
                startDate = (new Date(params.StartDate.getFullYear(), params.StartDate.getMonth(), params.StartDate.getDate())).getTime();
                query.CreatedDate = {$gte: startDate};
            }
            if (params.EndDate) {
                params.EndDate = new Date(params.EndDate);
                params.EndDate.setDate(params.EndDate.getDate() + 1);
                endDate = (new Date(params.EndDate.getFullYear(), params.EndDate.getMonth(), params.EndDate.getDate())).getTime();
                if (query.CreatedDate) {
                    query.CreatedDate.$lt = endDate;
                } else {
                    query.CreatedDate = {$lt: endDate};
                }
            }
            if (params.Area) {
                switch (params.Area) {
                case 'Exposures':
                    query.Type = 'BillMeLater';
                    break;
                case 'ACH':
                    query.Type = 'eCheck';
                    break;
                }
            }
            if (params.SearchTerm && params.SearchTerm.length) {
                query.$or = [
                    {Info: {$regex: '.*' + params.SearchTerm + '.*', $options: 'i'}},
                    {Name: {$regex: '.*' + params.SearchTerm + '.*', $options: 'i'}},
                    {"ReferenceNumbers.TypeName": {$regex: '.*' + params.SearchTerm + '.*', $options: 'i'}},
                    {"ReferenceNumbers.Value": {$regex: '.*' + params.SearchTerm + '.*', $options: 'i'}},
                    {Type: {$regex: '.*' + params.SearchTerm + '.*', $options: 'i'}}
                ];
                if (params.transMode === 'super') {
                    query.$or.push({GroupName: {$regex: '.*' + params.SearchTerm + '.*', $options: 'i'}});
                }
            }
            EntityCache.Transaction.aggregate([
                {$match: query},
                {$sort: {RowVersion: -1}},
                {$group: {
                    _id: "$hgId",
                    rows: {$push: {
                        CreatedDate: "$CreatedDate",
                        Type: "$Type",
                        CreditQuantity: "$CreditQuantity",
                        UserName: "$UserName",
                        FirstName : "$FirstName",
                        LastName : "$LastName",
                        ReferenceNumbers: "$ReferenceNumbers",
                        Info: "$Info",
                        Status: "$Status",
                        GroupName: "$GroupName",
                        RowVersion: "$RowVersion",
                        hgId: "$hgId",
                        UserId: "$UserId"
                    }}
                }},
                {$sort: {"rows.CreatedDate": -1}},
                {$skip: parseInt(params.Skip, 10) || 0},
                {$limit: parseInt(params.Take, 10) || 100}
            ], function (err, data) {
                var userIds = {},
                    i,
                    len;
                if (err) {
                    if (callback) {
                        callback(err);
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, err);
                    }
                } else {
                    for (i = 0, len = data.length; i < len; i += 1) {
                        userIds[data[i].rows[0].UserId] = '';
                    }
                    EntityCache.Member.find({UserId: {$in: Object.keys(userIds)}}).exec(function (error, members) {
                        var temp;
                        if (error) {
                            EventResponder.RespondWithError(EventEmitterCache, params, error);
                        } else {
                            for (i = 0, len = members.length; i < len; i += 1) {
                                userIds[members[i].UserId] = members[i];
                            }
                            for (i = 0, len = data.length; i < len; i += 1) {
                                temp = data[i].rows[0];
                                temp.EmployeeId = userIds[temp.UserId] ? userIds[temp.UserId].EmployeeId : '';
                                trans.push(temp);
                            }
                            if (callback) {
                                callback(null, trans);
                            } else {
                                EventResponder.RespondWithData(EventEmitterCache, params, trans);
                            }
                        }
                    });
                }
            });
        };
        this.GetTransactionsByGroup = function (params, callback) {
            EntityCache.Transaction.find({'GroupId' : params.GroupId}, function (err, news) {
                if (!err) {
                    callback(null, news);
                } else {
                    callback(err);
                }
            });
        };
    };

module.exports = TransactionProcessor;