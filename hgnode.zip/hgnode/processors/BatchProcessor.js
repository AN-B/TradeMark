/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    BatchProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            BatchEnums = require('../enums/BatchEnums.js'),
            guid = require('node-uuid');

        this.CreateBatch = function (params, callback) {
            var batch = new EntityCache.Batch(params);
            batch.hgId = guid.v1();
            batch.save(callback);
        };

        this.GetAndLockBatchById = function (params, callback) {
            EntityCache.Batch.findOneAndUpdate({
                hgId: params.BatchId,
                GroupId: params.GroupId,
                Status: BatchEnums.Status.New
            }, {
                $set: {
                    Status: BatchEnums.Status.Processing
                }
            }, {
                new: true
            }, callback);
        };

        this.SetTotalNumber = function (params, callback) {
            EntityCache.Batch.update({
                hgId: params.BatchId,
                GroupId: params.GroupId
            }, {
                $set: {
                    TotalNumber: params.TotalNumber
                }
            }, callback);
        };

        this.UpdateProcessedNumber = function (params, callback) {
            EntityCache.Batch.update({
                hgId: params.BatchId,
                GroupId: params.GroupId
            }, {
                $inc: {
                    ProcessedNumber: params.NumRecords
                },
                $addToSet: {
                    History: {
                        Time: Date.now(),
                        NumRecords: params.NumRecords,
                        Error: params.Error
                    }
                }
            }, callback);
        };

        this.UpdateBatchStatus = function (params) {
            EntityCache.Batch.update({
                hgId: params.BatchId,
                GroupId: params.GroupId
            }, {
                $set: {
                    Status: params.Status
                }
            }).exec();
        };
    };

module.exports = BatchProcessor;
