/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    DemoProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid');

        this.SaveDemoSettings = function (params, callback) {
            EntityCache.DemoEnvironment.update({
                Type: params.Type,
            }, {
                $set: {
                    FeatureFlags: params.Flags,
                    ModifiedBy: params.UserId
                },
                $setOnInsert: {
                    hgId: guid.v1(),
                    CreatedBy: params.UserId,
                    CreatedDate: Date.now()
                }
            }, {
                upsert: true,
                new: true
            }, callback);
        };
        this.GetDemoSettings = function (params, callback) {
            EntityCache.DemoEnvironment.findOne({Type: params.Type}, params.Fields || {}, callback);
        };
    };

module.exports = DemoProcessor;
