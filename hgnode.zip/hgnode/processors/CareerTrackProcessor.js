/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    CareerTrackProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            EventResponder = require('../util/EventResponder.js'),
            guid = require('node-uuid'),
            HgError = require('../common/HgError.js'),
            HgLog = require('../framework/HgLog.js'),
            FileHelper = require('../util/FileHelper.js'),
            arrayUtil = require('../util/arrayUtil.js'),
            Enums = require('../enums/EntityEnums.js'),
            Async = require('async'),
            recordLimit = 750,
            //if MilestoneTarget is entered due to the change from non-numeric goal to numeric, populate NumericValue
            //then calculate percentComplete
            calculatePercentCompleteOnNumericValue = function (milestone, org) {
                var newNumericValue;
                //if original milestone was passed and it was NOT numeric value, and that is changed to numeric value
                if (org && !org.MilestoneTarget && milestone.MilestoneTarget) {
                    //modify Numeric value from 0 to whatever calculated based on target value and existing % complete
                    newNumericValue = milestone.MilestoneTarget && org.PercentAchieved ? parseInt((milestone.MilestoneTarget * org.PercentAchieved) / 100, 10) : 0;
                    milestone.NumericValue = newNumericValue;
                } else {
                    newNumericValue = milestone.NumericValue;
                }
                return (newNumericValue && milestone.MilestoneTarget) ? (newNumericValue / milestone.MilestoneTarget) * 100 : 0;
            },
            calculatePercentCompleteOnNonNumericValue = function (milestone, org) {
                var ret;
                if (org && !milestone.MilestoneTarget) {
                    //if the existing PercentAchieved is great than 0 while milestone is changed to non-numeric
                    if (org.PercentAchieved > 100) {
                        ret = 100;
                    } else {
                        ret = org.PercentAchieved;
                    }
                } else {
                    ret = milestone.PercentAchieved;
                }
                return ret;
            },
            assignOneTrackToOneMember = function (request, callback) {
                var track = EntityCache.CareerTrack({
                        hgId: guid.v1(),
                        BatchId: request.batchId,
                        Status: 'Assigned',
                        CreatedBy: request.userId,
                        ModifiedBy: request.userId,
                        AssignedMember: request.recipientMember,
                        CreatorMember: request.issuerMember,
                        ObjectiveWeight: request.ObjectiveWeight,
                        NotificationFrequency: request.NotificationFrequency,
                        ModifiedDate: Date.now()
                    });
                track.CareerTrackTemplate = EntityCache.CareerTrackTemplate(request.template);
                track.assignOneTrackToOneMember = request.assignOneTrackToOneMember;
                if (request.template.TrackType === 'Goal') {
                    track.ObjectiveLabel = 'Goal';
                    track.MilestoneLabel = 'Keyresult';
                }
                // self assigned
                if (request.recipientMember.hgId === request.issuerMember.hgId) {
                    track.CareerTrackTemplate.Goal.RequiresApproval = false;
                }
                track.Collaborators = request.collaborators || [];
                arrayUtil.ObjectIndexOf(track.Collaborators, 'UserId', request.recipientMember.UserId, function (index) {
                    if (index !== -1) {
                        track.Collaborators.splice(index, 1);
                    }
                });
                track.assignOneTrackToOneMember = request.assignOneTrackToOneMember;
                track.CareerTrackTemplate.MileStones.forEach(function (t) {
                    t.hgId = guid.v1();
                });
                track.CareerTrackTemplate.Goal.hgId = guid.v1();
                request.Track = track;
                track.markModified('CareerTrackTemplate.MileStones.hgId');
                track.save(function (err) {
                    if (err) {
                        HgLog.error({methodName: 'assignOneTrackToOneMember', error: err});
                        callback(err);
                    } else {
                        callback(null, track);
                    }
                });
            },
            getTrackTemplate = function (params) {
                var userId = params.UserId,
                    groupId = params.GroupId,
                    groupName = params.GroupName,
                    goalRequest = params.Data,
                    goal = goalRequest.CareerTrackTemplate.Goal,
                    milestones = goalRequest.CareerTrackTemplate.MileStones,
                    Group = params.Group,
                    GoalTemplate = EntityCache.RecognitionTemplate({
                        hgId: goal.BadgeId ? guid.v1() : goal.RecognitionTemplate.hgId,
                        Category: Enums.RecognitionCategory.Achievement,
                        Title: goalRequest.CareerTrackTemplate.Title,
                        Description: goal.RecognitionTemplate.Description,
                        GroupId: groupId,
                        GroupName: groupName,
                        AccessLevel: goalRequest.CareerTrackTemplate.AccessLevel,
                        CreditValue: goal.RecognitionTemplate.CreditValue,
                        PointValue: goal.RecognitionTemplate.PointValue,
                        MilestoneWeightType: goalRequest.CareerTrackTemplate.MilestoneWeightType || 'Equally'
                    }),
                    trackTemplate = EntityCache.CareerTrackTemplate({
                        hgId: guid.v1(),
                        Title: goalRequest.CareerTrackTemplate.Title,
                        Description: goal.RecognitionTemplate.Description,
                        TrackType: goalRequest.CareerTrackTemplate.TrackType,
                        GroupId: groupId,
                        GroupName: groupName,
                        CreatedBy: userId,
                        ModifiedBy: userId,
                        AccessLevel: goalRequest.CareerTrackTemplate.AccessLevel,
                        IsLinear: goalRequest.CareerTrackTemplate.IsLinear,
                        TeamId: goalRequest.CareerTrackTemplate.TeamId || 0,
                        NotificationFrequency: goalRequest.CareerTrackTemplate.NotificationFrequency,
                        ObjectiveWeight: goalRequest.CareerTrackTemplate.ObjectiveWeight,
                        MilestoneWeightType: goalRequest.CareerTrackTemplate.MilestoneWeightType || 'Equally'
                    }),
                    i,
                    len,
                    template,
                    milestone;
                GoalTemplate.FriendlyGroupId = Group.FriendlyGroupId;
                trackTemplate.Goal = EntityCache.MileStone.MileStoneEmbedded({
                    hgId: guid.v1(),
                    RecognitionTemplate: GoalTemplate,
                    CreatedBy: userId,
                    ModifiedBy: userId,
                    RequiresApproval: true
                });
                if (goal.Badge) {
                    FileHelper.CopyBadgeImage({
                        BadgeId: goal.Badge.hgId,
                        FriendlyGroupId: Group.FriendlyGroupId,
                        TemplateId: GoalTemplate.hgId
                    });
                }
                for (i = 0, len = milestones.length; i < len; i += 1) {
                    template = EntityCache.RecognitionTemplate({
                        hgId:  milestones[i].BadgeId ? guid.v1() : milestones[i].RecognitionTemplate.hgId,
                        Title: milestones[i].RecognitionTemplate.Title,
                        Description: milestones[i].RecognitionTemplate.Description,
                        FriendlyGroupId: Group.FriendlyGroupId,
                        GroupId: groupId,
                        GroupName: groupName,
                        AccessLevel: goalRequest.AccessLevel,
                        CreditValue: milestones[i].RecognitionTemplate.CreditValue,
                        PointValue: milestones[i].RecognitionTemplate.PointValue
                    });
                    milestone = EntityCache.MileStone.MileStoneEmbedded({
                        RecognitionTemplate: template,
                        TargetDate:  milestones[i].TargetDate,
                        DisplayName: milestones[i].RecognitionTemplate.Title,
                        RequiresApproval: milestones[i].RequiresApproval,
                        CreatedBy: userId,
                        ModifiedBy: userId,
                        Weight: milestones[i].Weight,
                        MilestoneTarget: milestones[i].MilestoneTarget
                    });
                    trackTemplate.MileStones.push(milestone);
                    if (milestones[i].Badge) {
                        FileHelper.CopyBadgeImage({
                            BadgeId: milestones[i].Badge.hgId,
                            FriendlyGroupId: Group.FriendlyGroupId,
                            TemplateId: template.hgId
                        });
                    }
                }
                return trackTemplate;
            },
            updateOverdueMileStonesForOneTrack = function (track, callback) {
                // This method is called by the worker process thus no userinfo object exist
                var i,
                    len = track.CareerTrackTemplate.MileStones.length,
                    curTime = new Date().setHours(0, 0, 0, 0),
                    theMileStone,
                    isOverDue,
                    dirty = false;
                for (i = 0; i < len; i += 1) {
                    theMileStone = track.CareerTrackTemplate.MileStones[i];
                    // this type of chained comparison is to reduce the complexity of a boolean evaluation and increase readability of code
                    isOverDue = theMileStone.TargetDate < curTime;
                    isOverDue &= theMileStone.TargetDate > 0;
                    isOverDue &= theMileStone.PercentAchieved !== 100;
                    isOverDue &= [Enums.MilestoneStatus.NotStarted, Enums.MilestoneStatus.InProgress].indexOf(theMileStone.Status) > -1;
                    if (isOverDue) {
                        theMileStone.Status = Enums.MilestoneStatus.OverDue;
                        dirty = true;
                    }
                }
                if (dirty) {
                    track.markModified('CareerTrackTemplate.MileStones');
                    track.save(function (err) {
                        if (err) {
                            HgLog.error({methodName: 'updateOverdueMileStonesForOneTrack', error: err});
                            callback(err);
                        } else {
                            callback(null, track);
                        }
                    });
                } else {
                    callback(null, track);
                }
            },
            populateTracksPercentageAchieved = function (tracks) {
                if (!tracks || (!tracks.map && !tracks.filter)) {
                    return;
                }
                var i, len = tracks.length;
                for (i = 0; i < len; i += 1) {
                    tracks[i].SetPercentAchieved();
                }
            },
            checkAllMilestonesCompleted = function (track, mlstId) {
                return !track.CareerTrackTemplate.MileStones.some(function (m) {
                    return m.hgId !== mlstId && [Enums.MilestoneStatus.InProgress, Enums.MilestoneStatus.NotStarted].indexOf(m.Status) > -1;
                });
            },
            checkClosedMilestoneExists = function (track) {
                return track.CareerTrackTemplate.MileStones.some(function (m) {
                    return m.Status === Enums.MilestoneStatus.Closed;
                });
            },
            updateCareerTrack = function (params, callback) {
                if (params.Track === undefined) {
                    return callback('Track was not specified.');
                }
                var i, isSelfAssigned = params.Track.AssignedMember.UserId === params.Track.CreatorMember.UserId,
                    hasCreditValue = params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue > 0,
                    needsTitle = params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.Title.length === 0,
                    len,
                    isRequestComplete;
                params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.Title = params.Track.CareerTrackTemplate.Title;
                if (params.Track.CareerTrackTemplate.Goal.BadgeId) {
                    params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId = guid.v1();
                    FileHelper.CopyBadgeImage({
                        BadgeId: params.Track.CareerTrackTemplate.Goal.BadgeId,
                        FriendlyGroupId: params.FriendlyGroupId,
                        TemplateId: params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId
                    });
                    delete params.Track.CareerTrackTemplate.Goal.BadgeId;
                }
                for (i = 0, len = params.Track.CareerTrackTemplate.MileStones.length; i < len; i += 1) {
                    if (!hasCreditValue) {
                        hasCreditValue = params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.CreditValue > 0;
                    }
                    if (!needsTitle) {
                        needsTitle = params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.Title.length === 0;
                    }
                    if (params.Track.CareerTrackTemplate.MileStones[i].hgId.length === 0) {
                        params.Track.CareerTrackTemplate.MileStones[i].hgId = guid.v1();
                    }
                    params.Track.CareerTrackTemplate.MileStones[i].DisplayName = params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.Title;
                    if (params.Track.CareerTrackTemplate.MileStones[i].BadgeId) {
                        params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.hgId = guid.v1();
                        FileHelper.CopyBadgeImage({
                            BadgeId: params.Track.CareerTrackTemplate.MileStones[i].BadgeId,
                            FriendlyGroupId: params.FriendlyGroupId,
                            TemplateId: params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.hgId
                        });
                        delete params.Track.CareerTrackTemplate.MileStones[i].BadgeId;
                    }
                    if (['RequestComplete', 'Completed'].indexOf(params.Track.CareerTrackTemplate.Goal.Status) > -1 &&
                            ['RequestComplete', 'Completed'].indexOf(params.Track.CareerTrackTemplate.MileStones[i].Status) === -1) {
                        params.Track.CareerTrackTemplate.Goal.Status = 'Partial';
                    }
                }
                //if Track Status is either RequestComplete or Complete, and all milestones are NOT completed, change its status to Partial
                if (!checkAllMilestonesCompleted(params.Track, 0) && ['RequestComplete', 'Completed'].indexOf(params.Track.Status) > -1) {
                    params.Track.Status = 'Partial';
                } else {
                    // this type of chained comparison is to reduce the complexity of a boolean evaluation and increase readability of code
                    isRequestComplete = checkAllMilestonesCompleted(params.Track, 0);
                    isRequestComplete &= params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue > 0;
                    isRequestComplete |= params.Track.CareerTrackTemplate.Goal.RequiresApproval;
                    if (isRequestComplete) {
                        params.Track.CareerTrackTemplate.Goal.Status = Enums.TrackStatus.RequestComplete;
                        params.Track.Status = Enums.TrackStatus.RequestComplete;
                    }
                }
                if (isSelfAssigned && hasCreditValue) {
                    callback(HgError.Enums.CareerTrack.ErrorSelfAssignWithCredits);
                } else if (needsTitle) {
                    callback(HgError.Enums.CareerTrack.ErrorTitleNeeded);
                } else {
                    delete params.Track._id;
                    EntityCache.CareerTrack.update({hgId: params.Track.hgId}, params.Track, function (err) {
                        if (err) {
                            HgLog.error({methodName: 'updateCareerTrack', error: err});
                            callback('server.hge.crt.elt');
                        } else {
                            callback(null, true);
                        }
                    });
                }
            },
            useFiltersOnTracks = function (params, callback) {
                var filters = params.Filters,
                    regex,
                    andConditions = [],
                    orCriteria = [];
                if (filters) {
                    if (filters.keyword && filters.keyword.trim().length > 0) {
                        // need a comment on what this regex does. i suspect it's to remove reserved regex characters to prevent regex injection
                        regex = new RegExp(filters.keyword.replace(/([.*?=+&#!:${}()|\[\]\/\\\^\+])/g, "\\$1"), "i");
                        andConditions.push({
                            $or: [
                                {'CareerTrackTemplate.Title': regex },
                                {'AssignedMember.FullName': regex},
                                {'CreatorMember.FullName': regex },
                                {'CareerTrackTemplate.MileStones': {$elemMatch: {DisplayName: regex}}},
                                {Collaborators: {$elemMatch: {FullName: regex}}}
                            ]
                        });
                    }
                    if (filters.tagTrackIds && filters.tagTrackIds.length) {
                        if (filters.tagTrackIds.length > 1) {
                            andConditions.push({hgId: { $in: filters.tagTrackIds}});
                        } else {
                            andConditions.push({hgId: filters.tagTrackIds[0]});
                        }
                    }
                    if (filters.trackFilter) {
                        switch (filters.trackFilter) {
                        case 'Me':
                            andConditions.push({'AssignedMember.hgId': params.MemberId});
                            break;
                        case 'Assigned':
                            andConditions.push({'CreatorMember.hgId': params.MemberId}, {'AssignedMember.hgId': {$ne: params.MemberId}});
                            break;
                        case 'Collaborate':
                            andConditions.push({'Collaborators.MemberId': params.MemberId});
                            break;
                        case 'FollowMember':
                            andConditions.push({'CareerTrackTemplate.GroupId': params.GroupId});
                            break;
                        case 'All':
                        case 'ByFolder':
                            orCriteria = [
                                {'AssignedMember.hgId': params.MemberId},
                                {'CreatorMember.hgId': params.MemberId},
                                {'CareerTrackTemplate.GroupId': params.GroupId, 'CareerTrackTemplate.AccessLevel': 'WithinGroup'},
                                {'Collaborators.MemberId': params.MemberId}
                            ];
                            if (params.myTeamIds && params.myTeamIds.length) {
                                orCriteria.push({'CareerTrackTemplate.TeamId': {$in: params.myTeamIds[0]}, 'CareerTrackTemplate.AccessLevel': 'WithinTeam'});
                            }
                            andConditions.push({$or: orCriteria});
                            break;
                        }
                    }
                    if (!params.andConditions) {
                        params.andConditions = andConditions;
                    } else {
                        params.andConditions = params.andConditions.concat(andConditions);
                    }
                }
                callback(params);
            },
            //return all batchIds that are queried based on the given criteria
            getTrackBatchIds = function (params, callback) {
                var mquery = EntityCache.CareerTrack.find({'CareerTrackTemplate.GroupId': params.GroupId}),
                    batchIds = [],
                    returnResults = function (err, trackBatchData) {
                        if (err) {
                            callback(err);
                        } else {
                            if (trackBatchData && trackBatchData.length) {
                                batchIds = trackBatchData.map(function (item) {
                                    return item._id;
                                });
                            }
                            callback(null, batchIds);
                        }
                    };
                if (params.andConditions && params.andConditions.length > 0) {
                    params.andConditions.push({BatchId: {$exists: true}});
                    mquery.and(params.andConditions);
                } else if (params.orConditions && params.orConditions.length > 0) {
                    mquery.or(params.orConditions);
                }
                //get tracks grouped by BatchIds
                EntityCache.CareerTrack.aggregate([
                    {$match: mquery._conditions || {} },
                    {$group: { _id: "$BatchId", count: { $sum: 1 }, max: {$max: '$ModifiedDate'}}},
                    {$sort: { max: -1}}
                ]).exec(function (err, data) {
                    returnResults(err, data);
                });
            },
            //get BatchIds for Group Tracks 
            getTrackBatchIdsGroupOnly = function (params, callback) {
                var conditions = {$and: [{'CareerTrackTemplate.GroupId': params.GroupId}]};
                if (params.andConditions && params.andConditions.length) {
                    params.andConditions.push({BatchId: {$exists: true}});
                    conditions.$and = conditions.$and.concat(params.andConditions);
                } else if (params.orConditions && params.orConditions.length) {
                    conditions.$or = params.orConditions;
                }
                //get tracks grouped by BatchIds
                EntityCache.CareerTrack.aggregate([{$match: conditions },
                    {$group: { _id: "$BatchId", count: { $sum: 1 }, max: {$max: '$ModifiedDate'}}},
                    {$sort: { max: -1}}]).exec(function (err, trackBatchData) {
                    if (err) {
                        callback(err);
                    } else {
                        if (trackBatchData && trackBatchData.length > 0) {
                            //collect all BatchIds
                            EntityCache.CareerTrack.aggregate([
                                {$match: {BatchId: {$in: trackBatchData.map(function (item) {
                                    return item._id;
                                })}}},
                                {$group: { _id: "$BatchId", count: { $sum: 1 }, max: {$max: '$ModifiedDate'}}},
                                {$match: {count: {$gt: 1} }},
                                {$sort: { max: -1}}]).exec(function (err, tracks) {
                                //then skip and limit
                                if (err) {
                                    callback(err);
                                } else {
                                    //collect all BatchIds
                                    callback(null, tracks.map(function (item) {
                                        return item._id;
                                    }));
                                }
                            });
                        } else {
                            callback(null, []);
                        }
                    }
                });
            },
            getPagedData = function (params, batchIds, meta, callback) {
                var skip = parseInt(params.Skip, 10) || 0,
                    take = parseInt(params.Take, 10) || 10,
                    numberOfBatches,
                    filteredBatchIds = [],
                    getGroupTrack = function (params, meta, BatchId, callback) {
                        var filters = params.Filters,
                            groupTrack = meta.filter(function (track) {
                                return track.BatchId === BatchId;
                            }),
                            isOpenGroupTrack = function () {
                                return groupTrack.some(function (gt) {
                                    return ['Completed', 'Void', 'Closed'].indexOf(gt.Status) === -1;
                                });
                            },
                            isCancelledTrack = function () {
                                return groupTrack.some(function (gt) {
                                    return gt.Status === 'Void';
                                });
                            },
                            isArchivedTrack = function () {
                                return groupTrack.some(function (gt) {
                                    return ['Completed', 'Closed'].indexOf(gt.Status) > -1;
                                });
                            };
                        if (filters.trackFilter) {
                            switch (filters.trackFilter) {
                            case 'Me':
                            case 'Assigned':
                            case 'Collaborate':
                            case 'FollowMember':
                            case 'All':
                            case 'ByFolder':
                            case 'Group':
                                callback(isOpenGroupTrack());
                                break;
                            case 'Cancelled':
                                callback(isCancelledTrack());
                                break;
                            case 'Archived':
                                callback(isArchivedTrack());
                                break;
                            default:
                                callback(isOpenGroupTrack());
                            }
                        } else {
                            //default
                            callback(isOpenGroupTrack());
                        }
                    },
                    returnResults = function (err, batchIdsInRange) {
                        if (err) {
                            return callback(err);
                        }
                        if (batchIdsInRange && batchIdsInRange.length > 0) {
                            EntityCache.CareerTrack.find({
                                BatchId: { $in: batchIdsInRange }
                            }, null, { limit: recordLimit }).exec(function (err, tracks) {
                                if (err) {
                                    HgLog.error({methodName: 'returnResults', error: err});
                                    return callback('cartrk.err.gpt');
                                }
                                tracks.sort(function (a, b) {
                                    return a.ModifiedDate > b.ModifiedDate ? 1 : -1;
                                });
                                callback(null, {tracks: tracks || [], totalCount: numberOfBatches});
                            });
                        } else {
                            callback(null, {tracks: [], totalCount: numberOfBatches});
                        }
                    },
                    //further narrow down on data based on track status criteria
                    //For Group Track, all tracks in the Group need to be examine to determin
                    //Group Track Status (getGroupTrack)
                    getFilteredBatchIds = function (params, batchIds, meta, callback) {
                        var BatchId;
                        if (batchIds.length === 0) {
                            //all batchIds were examined
                            return callback(filteredBatchIds);
                        }
                        BatchId = batchIds.shift();
                        getGroupTrack(params, meta, BatchId, function (eligibleBatch) {
                            if (eligibleBatch) {
                                filteredBatchIds.push(BatchId);
                            }
                            getFilteredBatchIds(params, batchIds, meta, callback);
                        });
                    };
                //get All batchIds which are refined based on Track Status
                getFilteredBatchIds(params, batchIds, meta, function (filteredBatchIds) {
                    numberOfBatches = filteredBatchIds.length;
                    if (take > -1) {
                        //get batchIds in the range in skip and take
                        EntityCache.CareerTrack.aggregate([{$match: {BatchId: {$in: filteredBatchIds}} },
                            {$group: { _id: "$BatchId", count: { $sum: 1 }, max: {$max: '$ModifiedDate'}}},
                            {$sort: { max: -1}}]).skip(skip).limit(take).exec(function (err, trackBatchData) {
                            if (trackBatchData && trackBatchData.length) {
                                returnResults(err, trackBatchData.map(function (item) {
                                    return item._id;
                                }));
                            } else {
                                callback(null, []);
                            }
                        });
                    } else {//if take was not passed or not valid, return all
                        returnResults(null, batchIds);
                    }
                });
            };

        this.GetTotalTracksForCheckin = function (params, callback) {
            var condition = {
                    NotificationFrequency: {$in: params.CheckInTypes},
                    Status: {$in: ['Assigned', 'Partial']}
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.CareerTrack.count(condition, callback);
        };

        this.GetTracksForCheckinBatch = function (params, callback) {
            var condition = {
                    NotificationFrequency: {$in: params.CheckInTypes},
                    Status: {$in: ['Assigned', 'Partial']}
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.CareerTrack.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetTracksByCondition = function (params, callback) {
            EntityCache.CareerTrack.find(params.Condition, function (err, tracks) {
                callback(err, tracks);
            });
        };

        this.GetTracksByIds = function (params, callback) {
            EntityCache.CareerTrack.find({hgId: {$in: params.TrackIds}}, function (err, tracks) {
                if (err || !tracks) {
                    if (callback) {
                        callback('server.hge.crt.elc');
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                    }
                } else {
                    if (callback) {
                        callback(null, tracks);
                    } else {
                        EventResponder.RespondWithData(EventEmitterCache, params, tracks);
                    }
                }
            });
        };

        this.GetTracksWithOverdueMileStones = function (params) {
            var curTime = new Date().setHours(0, 0, 0, 0);
            EntityCache.CareerTrack.find({
                'CareerTrackTemplate.MileStones.TargetDate': {$lt: curTime, $gt: 0},
                'CareerTrackTemplate.MileStones.Status': {$in: ['NotStarted', 'InProgress']}
            }, function (err, tracks) {
                if (!err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, tracks));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.elc'));
                }
            });
        };

        this.BatchAssignTracks = function (params) {
            var requests = [],
                len;
            params.Templates.forEach(function (template) {
                var batchId = guid.v1();
                requests = requests.concat(params.RecipientMembers.map(function (recipient) {
                    return {
                        batchId: batchId,
                        template: template,
                        recipientMember: recipient,
                        issuerMember: params.IssuerMember,
                        userId: params.UserId,
                        Track: {}
                    };
                }));
            });
            len = requests.length;
            Async.whilst(
                function () {
                    len -= 1;
                    return len > -1;
                },
                function (callback) {
                    assignOneTrackToOneMember(requests[len], callback);
                },
                function (err) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                    } else {
                        EntityCache.CareerTrack.find({hgId: { $in: requests.map(function (r) {
                            return r.Track.hgId;
                        })}}, function (err, results) {
                            if (err) {
                                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                            } else {
                                EventResponder.RespondWithData(EventEmitterCache, params, results);
                            }
                        });
                    }
                }
            );
        };

        this.UpdateOverdueMileStones = function (params) {
            var overdueTracks = params.OverdueTracks;
            Async.each(overdueTracks, updateOverdueMileStonesForOneTrack, function (err) {
                if (err) {
                    HgLog.error({methodName: 'UpdateOverdueMileStones', error: err});
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrack.ErrorUpdatingTrackMilestone));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, params));
                }
            });
        };

        this.SetObjectiveChain = function (params) {
            var updateRequest = params.UpdateRequest,
                track = params.Track,
                existingChain,
                parentTrackId = updateRequest.ParentTrackId,
                parentMilestoneId = updateRequest.ParentMileStoneId,
                chainFilter = function (el) {
                    return el.TrackId === parentTrackId && el.MileStoneId === parentMilestoneId;
                },
                chain = {};

            track.CareerTrackTemplate = EntityCache.CareerTrackTemplate(track.CareerTrackTemplate);

            existingChain = track.CareerTrackTemplate.Goal.ObjectiveChain.filter(chainFilter);

            if (!existingChain || existingChain.length === 0) {
                chain.TrackId = parentTrackId;
                chain.MileStoneId = parentMilestoneId;
                track.CareerTrackTemplate.Goal.ObjectiveChain.push(chain);
                track.markModified('CareerTrackTemplate.Goal');
                track.ModifiedDate = Date.now();
                track.markModified('ModifiedDate');
                track.save(function (err) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrack.ErrorUpdatingTrackMilestone));
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'cartrk.err.tmu'));
                    }
                });
            } else {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrack.TracksMilestoneIdInvalid));
            }
        };

        this.AddContributors = function (params) {
            var updateRequest = params.UpdateRequest,
                track = params.Track,
                i,
                previousCollaborators = [],
                len;
            for (i = 0, len = track.Collaborators.length; i < len; i += 1) {
                previousCollaborators.push(track.Collaborators[i]);
            }
            arrayUtil.ObjectIndexOf(updateRequest.Collaborators, 'UserId', track.AssignedMember.UserId, function (index) {
                if (index !== -1) {
                    updateRequest.Collaborators.splice(index, 1);
                }
            });
            track.Collaborators = updateRequest.Collaborators;

            track.markModified('Collaborators');
            track.ModifiedDate = Date.now();
            track.markModified('ModifiedDate');
            track.save(function (err) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.eum'));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                        collaborators: updateRequest.Collaborators,
                        previousCollaborators: previousCollaborators,
                        track: track
                    }));
                }
            });
        };

        this.AddLinkTracks = function (params) {
            var updateRequest = params.UpdateRequest,
                track = params.Track,
                i,
                len;
            if (track.CareerTrackTemplate.Goal.hgId === updateRequest.MileStoneId) {
                track.CareerTrackTemplate.Goal.ObjectiveChain = updateRequest.LinkTracks;
                track.markModified('CareerTrackTemplate.Goal');
            }
            for (i = 0, len = track.CareerTrackTemplate.MileStones.length; i < len; i += 1) {
                if (track.CareerTrackTemplate.MileStones[i].hgId === updateRequest.MileStoneId) {
                    track.CareerTrackTemplate.MileStones[i].ObjectiveChain = updateRequest.LinkTracks;
                    track.markModified('CareerTrackTemplate.MileStones');
                }
            }
            track.ModifiedDate = Date.now();
            track.markModified('ModifiedDate');
            track.save(function (err) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.eum'));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'cartrk.err.tlu'));
                }
            });
        };

        this.UpdateMileStone = function (params) {
            var userId = params.UserId,
                updateRequest = params.UpdateRequest,
                track = params.Track,
                i,
                len,
                updated = false,
                allMilestonesCompleted = false,
                completedMilestone,
                completedObjective,
                completedTrack,
                pendingMilestone,
                pendingTrack,
                needsApproval = true,
                milestone;
            track.CareerTrackTemplate = EntityCache.CareerTrackTemplate(track.CareerTrackTemplate);
            // check goal first
            if (track.CareerTrackTemplate.Goal.hgId === updateRequest.MileStoneId) {
                updated = true;
                if (updateRequest.TargetDate !== undefined) {
                    track.CareerTrackTemplate.Goal.TargetDate = updateRequest.TargetDate;
                }
                if (updateRequest.LastReasonCode !== undefined) {
                    track.CareerTrackTemplate.Goal.LastReasonCode = updateRequest.LastReasonCode;
                }
                if (updateRequest.Status !== undefined) {
                    HgLog.debug("changing Goal Status to..." + updateRequest.Status);
                    track.CareerTrackTemplate.Goal.Status = updateRequest.Status;
                    switch (track.CareerTrackTemplate.Goal.Status) {
                    case Enums.MilestoneStatus.Cancelled:
                        track.Status = 'Void';
                        for (i = 0; i < track.CareerTrackTemplate.MileStones.length; i += 1) {
                            track.CareerTrackTemplate.MileStones[i].Status = Enums.MilestoneStatus.Cancelled;
                        }
                        break;
                    case Enums.MilestoneStatus.Completed:
                        track.CareerTrackTemplate.Goal.ClosedDate = Date.now();
                        track.Status = Enums.MilestoneStatus.Completed;
                        if (track.AssignedMember.hgId !== track.CreatorMember.hgId) {
                            track.CareerTrackTemplate.Goal.RecognitionId = guid.v1();
                            completedTrack = track;
                        }
                        break;
                    case Enums.MilestoneStatus.InProgress:
                        if (track.Status === Enums.MilestoneStatus.RequestComplete) {//canceled Track was restored
                            for (i = 0; i < track.CareerTrackTemplate.MileStones.length; i += 1) {
                                track.CareerTrackTemplate.MileStones[i].Status = Enums.MilestoneStatus.InProgress;
                            }
                        }
                        break;
                    }
                }
            }
            //Milestone was updated
            if (!updated) {
                for (i = 0, len = track.CareerTrackTemplate.MileStones.length; i < len; i += 1) {
                    if (track.CareerTrackTemplate.MileStones[i].hgId === updateRequest.MileStoneId) {
                        updated = true;
                        milestone = track.CareerTrackTemplate.MileStones[i];
                        if (updateRequest.TargetDate !== undefined) {
                            milestone.TargetDate = updateRequest.TargetDate;
                            if (milestone.Status === Enums.MilestoneStatus.OverDue && new Date(milestone.TargetDate).setHours(0, 0, 0, 0) >= new Date().setHours(0, 0, 0, 0)) {
                                updateRequest.Status = Enums.MilestoneStatus.InProgress;
                            }
                        }
                        if (updateRequest.LastReasonCode !== undefined) {
                            milestone.LastReasonCode = updateRequest.LastReasonCode;
                        }
                        //if NumericValue is entered, update PercentAchieved as well
                        if (updateRequest.NumericValue !== undefined) {
                            milestone.NumericValue = updateRequest.NumericValue;
                            updateRequest.PercentAchieved = calculatePercentCompleteOnNumericValue(milestone);
                        }
                        if (updateRequest.PercentAchieved !== undefined) {
                            milestone.PercentAchieved = updateRequest.PercentAchieved;
                            if (updateRequest.Status !== Enums.MilestoneStatus.RequestComplete) {
                                if (milestone.Status === Enums.MilestoneStatus.NotStarted) {
                                    updateRequest.Status = Enums.MilestoneStatus.InProgress;
                                }
                            }
                        }
                        if (updateRequest.Status !== undefined) {
                            milestone.Status = updateRequest.Status;
                            switch (milestone.Status) {
                            case Enums.MilestoneStatus.NotStarted:
                            case Enums.MilestoneStatus.InProgress:
                                track.CareerTrackTemplate.Goal.Status = Enums.MilestoneStatus.InProgress;
                                if (track.Status !== 'Partial') {
                                    track.Status = 'Partial';
                                }
                                break;
                            case Enums.MilestoneStatus.Completed:
                                //check on milestone
                                needsApproval = (milestone.RecognitionTemplate.CreditValue && milestone.RecognitionTemplate.CreditValue > 0) || milestone.RequiresApproval;
                                if (needsApproval) {
                                    if (userId === track.AssignedMember.UserId) {
                                        updateRequest.Status = Enums.MilestoneStatus.RequestComplete;
                                    } else {
                                        updateRequest.Status = Enums.MilestoneStatus.Completed;
                                    }
                                } else {
                                    updateRequest.Status = Enums.MilestoneStatus.Completed;
                                }
                                if (updateRequest.Status === Enums.MilestoneStatus.Completed) {//really completed!
                                    completedMilestone = milestone;
                                    milestone.ClosedDate = Date.now();
                                }
                                //check on the objective
                                allMilestonesCompleted = checkAllMilestonesCompleted(track, milestone.hgId);
                                needsApproval = (track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue && track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue > 0) || track.CareerTrackTemplate.Goal.RequiresApproval;
                                if (allMilestonesCompleted) {
                                    if (needsApproval) {//if user is manager, probably should COMPLETE?
                                        track.CareerTrackTemplate.Goal.Status = Enums.MilestoneStatus.RequestComplete;
                                        track.Status = Enums.TrackStatus.RequestComplete;
                                        pendingTrack = track;
                                    } else {
                                        track.CareerTrackTemplate.Goal.Status = track.Status = checkClosedMilestoneExists(track) ? Enums.MilestoneStatus.Closed : Enums.MilestoneStatus.Completed;
                                        track.CareerTrackTemplate.Goal.ClosedDate = Date.now();
                                        completedObjective = track.CareerTrackTemplate.Goal;
                                        if (track.AssignedMember.hgId !== track.CreatorMember.hgId) {
                                            track.CareerTrackTemplate.Goal.RecognitionId = guid.v1();
                                            completedTrack = track;
                                        }
                                    }
                                } else {
                                    track.Status = Enums.TrackStatus.Partial;
                                }
                                break;
                            case Enums.MilestoneStatus.RequestComplete:
                                pendingMilestone = milestone;
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            if (updated) {
                track.markModified('CareerTrackTemplate.Goal');
                track.markModified('CareerTrackTemplate.MileStones');
                track.ModifiedDate = Date.now();
                track.markModified('ModifiedDate');
                track.markModified('Status');
                track.SetPercentAchieved();
                track.save(function (err) {
                    if (err) {
                        return EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.eum'));
                    }
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                        Message: 'Tracks milestone updated',
                        CompletedMilestone: completedMilestone,
                        CompletedObjective: completedObjective,
                        PendingMilestone: pendingMilestone,
                        CompletedTrack: completedTrack,
                        PendingTrack: pendingTrack,
                        track: track
                    }));
                });
            } else {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.itm'));
            }
        };

        //keep milestone weights at 100 % by adjusting the last milestone weight
        this.AdjustMileStoneWeights = function (params, callback) {
            var trackTemplate = params.CareerTrackTemplate,
                milestones =  trackTemplate.MileStones,
                len = milestones ? milestones.length - 1 : 0,
                milestoneWeightType = trackTemplate.MilestoneWeightType;
            if (milestoneWeightType === "Custom" && len > 0) {
                //custom, adjust the last milestone's weight to make the total equate to 100%
                milestones.reduce(function (a, b, index) {
                    if (index === len) {
                        b.Weight = a < 100 ? 100 - a : 0;
                    } else {
                        return a + (parseInt(b.Weight, 10) || 0);
                    }
                    return 0;
                }, 0);
                EntityCache.CareerTrack.findOneAndUpdate({
                    hgId: params.TrackId
                }, {
                    $set: {
                        'CareerTrackTemplate.MileStones': milestones
                    }
                }, {
                    new: true
                }, function (err, data) {
                    if (err) {
                        return callback(err);
                    }
                    //recalculate percent completion based on updated milestone weights
                    data.SetPercentAchieved();
                    data.save(callback);
                });
            } else {
                //recalculate percent complete on milestone weights
                EntityCache.CareerTrack.findOne({hgId: params.TrackId}, function (err, data) {
                    if (err) {
                        return callback(err);
                    }
                    //recalculate percent completion based on updated milestone weights
                    data.SetPercentAchieved();
                    data.save(callback);
                });
            }
        };

        this.DeleteMileStone = function (params) {
            EntityCache.CareerTrack.update({
                hgId: params.TrackId
            }, {
                $pull: {
                    'CareerTrackTemplate.MileStones': {hgId: params.MileStoneId}
                },
                ModifiedBy: params.UserId
            }, function (err) {
                if (err) {
                    return EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.eum'));
                }
                EntityCache.CareerTrack.findOne({hgId: params.TrackId}, function (err, data) {
                    if (err) {
                        return EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.eum'));
                    }
                    return EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, data));
                });
            });
        };

        this.GetTracksByIssuerMemberId = function (params, callback) {
            useFiltersOnTracks(params, function (params) {
                //get tracks grouped by BatchIds
                //first get all BatchIds
                getTrackBatchIds(params, function (err, batchIds) {
                    if (err) {
                        return callback(err);
                    }
                    //get all tracks for BatchIds
                    EntityCache.CareerTrack.find({
                        BatchId: {$in: batchIds}
                    }, null, {
                        sort: {ModifiedDate: -1}
                    }).exec(function (err, tracks) {
                        if (err) {
                            return callback(err);
                        }
                        //filter BatchIds based on track status criteria and examining Group Tracks
                        getPagedData(params, batchIds, tracks, function (err, data) {
                            //finally get tracks in the given range (skip & take)
                            if (err) {
                                return callback(err);
                            }
                            populateTracksPercentageAchieved(data.tracks);
                            callback(null, {tracks: data.tracks, totalCount: data.totalCount});
                        });
                    });
                });
            });
        };

        this.GetTracksCollaboratedByMemberId = function (params, callback) {
            useFiltersOnTracks(params, function (params) {
                //get tracks grouped by BatchIds
                getTrackBatchIds(params, function (err, batchIds) {
                    if (err) {
                        callback(err);
                    } else {
                        EntityCache.CareerTrack.find({
                            BatchId: {$in: batchIds}
                        }, null, {
                            sort: { ModifiedDate: -1}
                        }).exec(function (err, tracks) {
                            if (err) {
                                callback(null, tracks);
                            } else {
                               //filter BatchIds based on track status criteria and examining Group Tracks 
                                getPagedData(params, batchIds, tracks, function (err, data) {
                                    //finally get tracks in the given range (skip & take)
                                    if (err) {
                                        callback(err);
                                    } else {
                                        populateTracksPercentageAchieved(data.tracks);
                                        callback(null, {tracks: data.tracks, totalCount: data.totalCount});
                                    }
                                });
                            }
                        });
                    }
                });
            });
        };

        this.GetTracksByBatchIds = function (params, callback) {
            EntityCache.CareerTrack.find({
                $and: [{BatchId: {$in: params.BatchIds}}, {hgId: {$nin: params.hgIds}}]
            }).exec(function (err, tracks) {
                if (err || !tracks) {
                    if (callback) {
                        callback(err);
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                    }
                } else {
                    populateTracksPercentageAchieved(tracks);
                    if (callback) {
                        callback(null, tracks);
                    } else {
                        EventResponder.RespondWithData(EventEmitterCache, params, tracks);
                    }
                }
            });
        };

        this.GetTracksForMember = function (params, callback) {
            var memberId = params.MemberId,
                //get tracks grouped by BatchIds
                executeQuery = function (err, batchIds) {
                    if (err) {
                        callback(err);
                    } else {
                        EntityCache.CareerTrack.find({
                            'CareerTrackTemplate.GroupId': params.GroupId
                        }).where('BatchId').in(batchIds).limit(recordLimit).exec(function (err, tracks) {
                            if (err || !tracks) {
                                HgLog.error({methodName: 'GetTracksForMember', error: err});
                                callback('cartrk.err.gpt');
                            } else {
                                tracks = tracks.sort(function (a, b) {
                                    return a.ModifiedDate > b.ModifiedDate ? 1 : -1;
                                });
                                //filter BatchIds based on track status criteria and examining Group Tracks 
                                getPagedData(params, batchIds, tracks, function (err, data) {
                                    //finally get tracks in the given range (skip & take)
                                    if (err) {
                                        callback(err);
                                    } else {
                                        populateTracksPercentageAchieved(data.tracks);
                                        callback(null, {tracks: data.tracks, totalCount: data.totalCount});
                                    }
                                });
                            }
                        });
                    }
                };
            params.andConditions = [];
            useFiltersOnTracks(params, function (params) {
                EntityCache.Team.find({'TeamMembers.MemberId': memberId, GroupId: params.GroupId, Status: {$ne: 'Deleted'}}, function (err, teams) {
                    var orCriteria = [{'AssignedMember.hgId': memberId}, {'CreatorMember.hgId': memberId}, {'Collaborators.MemberId': memberId}];
                    if (err) {
                        return HgLog.error({methodName: 'GetTracksForMember', error: err});
                    }
                    if (teams && teams.length) {
                        orCriteria.push({
                            'CareerTrackTemplate.TeamId': {$in: teams.map(function (team) {
                                return team.hgId;
                            })}
                        });
                    }
                    params.andConditions.push({$or: orCriteria});
                    if (params.Filters.trackFilter && params.Filters.trackFilter === 'Group') {
                        getTrackBatchIdsGroupOnly(params, executeQuery);
                    } else {
                        getTrackBatchIds(params, executeQuery);
                    }
                });
            });
        };

        this.GetTracksByTeamId = function (params) {
            EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                if (err || !team) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'cartrk.err.gti'));
                    return;
                }
                var i,
                    memberIds = [],
                    len;
                for (i = 0, len = team.TeamMembers.length; i < len; i += 1) {
                    memberIds.push(team.TeamMembers[i].MemberId);
                }
                EntityCache.CareerTrack.find({
                    $or: [
                        {'AssignedMember.hgId': {$in: memberIds}},
                        {'CreatorMember.hgId': {$in: memberIds}},
                        {'Collaborators.MemberId': {$in: memberIds}}
                    ]
                }).exec(function (err, tracks) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.elc'));
                    } else {
                        populateTracksPercentageAchieved(tracks);
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, tracks));
                    }
                });

            });
        };

        this.GetTracksForMembers = function (params, callback) {
            var memberId = params.MemberId,
                myTeamIds = [],
                followedTrackMemberIds = params.FollowedTrackMemberIds,
                query = { $or: []};
            params.andConditions = [];
            if (followedTrackMemberIds && followedTrackMemberIds.length !== 0) {
                EntityCache.Team.find({'TeamMembers.MemberId': memberId, Status: {$ne: 'Deleted'}}, function (err, teams) {
                    if (err) {
                        return callback(err);
                    }
                    if (teams && teams.length) {
                        teams.forEach(function (team) {
                            team.TeamMembers.forEach(function (member) {
                                if (followedTrackMemberIds.indexOf(member.MemberId) > -1 && myTeamIds.indexOf(team.hgId) === -1) {
                                    myTeamIds.push(team.hgId);
                                }
                            });
                        });
                    }
                    query.$or.push({
                        'AssignedMember.hgId':  {$in: followedTrackMemberIds},
                        'CareerTrackTemplate.AccessLevel': 'WithinGroup'
                    });
                    query.$or.push({
                        'AssignedMember.hgId':  {$in: followedTrackMemberIds},
                        'CreatorMember.hgId': memberId,
                        'CareerTrackTemplate.AccessLevel': 'Individual'
                    });
                    if (myTeamIds.length > 0) {
                        query.$or.push({
                            'CareerTrackTemplate.TeamId': {$in: myTeamIds},
                            'AssignedMember.hgId':  {$in: followedTrackMemberIds},
                            'CareerTrackTemplate.AccessLevel': 'WithinTeam'
                        });
                    }
                    params.andConditions.push(query);
                    useFiltersOnTracks(params, function (params) {
                        getTrackBatchIds(params, function (err, batchIds) {
                            if (err) {
                                if (callback) {
                                    callback(err);
                                } else {
                                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                                }
                            } else {
                                EntityCache.CareerTrack.find({
                                    BatchId: {$in: batchIds}
                                }, null, {
                                    limit: recordLimit
                                }).exec(function (err, tracks) {
                                    if (err) {
                                        if (callback) {
                                            HgLog.error({methodName: 'GetTracksForMembers', error: err});
                                            callback('cartrk.err.gpt');
                                        } else {
                                            EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                                        }
                                    } else {
                                        tracks.sort(function (a, b) {
                                            return a.ModifiedDate > b.ModifiedDate ? 1 : -1;
                                        });
                                        //filter BatchIds based on track status criteria and examining Group Tracks 
                                        getPagedData(params, batchIds, tracks, function (err, data) {
                                            //finally get tracks in the given range (skip & take)
                                            if (err) {
                                                if (callback) {
                                                    callback(err);
                                                } else {
                                                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                                                }
                                            } else {
                                                populateTracksPercentageAchieved(data.tracks);
                                                if (callback) {
                                                    callback(null, {tracks: data.tracks, totalCount: data.totalCount});
                                                } else {
                                                    EventResponder.RespondWithData(EventEmitterCache, params, data.tracks);
                                                }
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    });
                });
            } else {
                if (callback) {
                    callback(null, {tracks: null, totalCount: 0});
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, null);
                }
            }
        };

        this.GetMyTeamsTracks = function (params) {
            var memberId = params.MemberId,
                myTeamIds = [],
                i,
                len;
            EntityCache.Team.find({'TeamMembers.MemberId': memberId, Status: {$ne: 'Deleted'}}, function (err, teams) {
                if (err) {
                    return EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.elc'));
                }
                if (teams && teams.length) {
                    for (i = 0, len = teams.length; i < len; i += 1) {
                        myTeamIds.push(teams[i].hgId);
                    }
                }
                EntityCache.CareerTrack.find({
                    'CareerTrackTemplate.TeamId': {$in: myTeamIds},
                    'CareerTrackTemplate.AccessLevel': 'WithinTeam'
                }).exec(function (err, tracks) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.elc'));
                    } else {
                        populateTracksPercentageAchieved(tracks);
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, tracks));
                    }
                });
            });
        };

        this.GetGroupPublicTracks = function (params, callback) {
            params.myTeamIds = [];
            EntityCache.Team.find({
                'TeamMembers.MemberId': params.MemberId,
                Status: {$ne: 'Deleted'}
            }, function (err, teams) {
                if (err) {
                    return callback(err);
                }
                if (teams && teams.length) {
                    params.myTeamIds.push(teams.map(function (team) {
                        return team.hgId;
                    }));
                }
                useFiltersOnTracks(params, function (params) {
                    //get tracks grouped by BatchIds
                    getTrackBatchIds(params, function (err, batchIds) {
                        if (err) {
                            return callback(err);
                        }
                        EntityCache.CareerTrack.find({BatchId: {$in: batchIds}}, null, {
                            limit: recordLimit
                        }).sort({ ModifiedDate: -1 }).exec(function (err, tracks) {
                            if (err) {
                                HgLog.error({methodName: 'GetGroupPublicTracks', error: err});
                                return callback('cartrk.err.gpt');
                            }
                            tracks.sort(function (a, b) {
                                return a.ModifiedDate > b.ModifiedDate ? 1 : -1;
                            });
                            //filter BatchIds based on track status criteria and examining Group Tracks
                            getPagedData(params, batchIds, tracks, function (err, data) {
                                //finally get tracks in the given range (skip & take)
                                if (err) {
                                    return callback(err);
                                }
                                populateTracksPercentageAchieved(data.tracks);
                                callback(null, {tracks: data.tracks, totalCount: data.totalCount});
                            });
                        });
                    });
                });
            });
        };

        this.GetDashBoardTracksByRecipientMemberId = function (params) {
            EntityCache.CareerTrack.find({
                'AssignedMember.hgId': params.MemberId,
                Status: { $nin: ['Closed', 'Void', 'Completed']}
            }).limit(params.Limit).sort({ModifiedDate: -1}).exec(function (err, tracks) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                } else {
                    populateTracksPercentageAchieved(tracks);
                    EventResponder.RespondWithData(EventEmitterCache, params, tracks);
                }
            });
        };

        this.GetTracksByRecipientMemberId = function (params) {
            var memberId = params.MemberId,
                mquery = EntityCache.CareerTrack.find({'AssignedMember.hgId': memberId}),
                filters = params.Filters,
                regex,
                orConditions = [],
                andConditions = [];
            if (filters) {
                if (filters.keyword && filters.keyword.trim().length > 0) {
                    regex = new RegExp(filters.keyword.replace(/([.*?=+&#!:${}()|\[\]\/\\\^\+])/g, "\\$1"), "i");
                    andConditions.push({
                        $or: [
                            {'CareerTrackTemplate.Title': regex },
                            {'AssignedMember.FullName': regex},
                            {'CreatorMember.FullName': regex },
                            {'CareerTrackTemplate.MileStones': {$elemMatch: {DisplayName: regex}}},
                            {Collaborators: {$elemMatch: {FullName: regex}}}
                        ]
                    });
                }
                if (filters.tagTrackIds && filters.tagTrackIds.length) {
                    if (filters.tagTrackIds.length > 1) {
                        andConditions.push({'hgId': { $in: filters.tagTrackIds}});
                    } else {
                        andConditions.push({'hgId': filters.tagTrackIds[0]});
                    }
                }
                if (andConditions.length > 0) {
                    mquery.and(andConditions);
                } else if (orConditions.length > 0) {
                    mquery.or(orConditions);
                }
            }
            mquery.exec(function (err, tracks) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                } else {
                    populateTracksPercentageAchieved(tracks);
                    EventResponder.RespondWithData(EventEmitterCache, params, tracks);
                }
            });
        };

        this.GetTracksAndGroupTracksByRecipientMemberId = function (params, callback) {
            params.andConditions = [];
            useFiltersOnTracks(params, function (params) {
                //get tracks grouped by BatchIds
                getTrackBatchIds(params, function (err, batchIds) {
                    if (err) {
                        return callback(err);
                    }
                    EntityCache.CareerTrack.find({
                        BatchId: {$in: batchIds}
                    }, null, { limit: recordLimit }).exec(function (err, tracks) {
                        if (err) {
                            HgLog.error({methodName: 'GetTracksAndGroupTracksByRecipientMemberId', error: err});
                            return callback('cartrk.err.gpt');
                        }
                        tracks.sort(function (a, b) {
                            return a.ModifiedDate > b.ModifiedDate ? 1 : -1;
                        });
                        //filter BatchIds based on track status criteria and examining Group Tracks
                        getPagedData(params, batchIds, tracks, function (err, data) {
                            //finally get tracks in the given range (skip & take)
                            if (err) {
                                return callback(err);
                            }
                            populateTracksPercentageAchieved(data.tracks);
                            callback(null, {tracks: data.tracks, totalCount: data.totalCount});
                        });
                    });
                });
            });
        };

        this.GetTrackByTrackId = function (params) {
            EntityCache.CareerTrack.findOne({hgId: params.TrackId}, function (err, track) {
                if (err || !track) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, track);
                }
            });
        };

        this.GetTracksByBatchId = function (params, callback) {
            EntityCache.CareerTrack.find({BatchId: params.BatchId}, function (err, tracks) {
                if (err) {
                    if (callback) {
                        callback('server.hge.crt.elc', null);
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                    }
                } else {
                    populateTracksPercentageAchieved(tracks);
                    if (callback) {
                        callback(null, tracks);
                    } else {
                        EventResponder.RespondWithData(EventEmitterCache, params, tracks);
                    }
                }
            });
        };

        this.GetTrackByMilestoneId = function (params, callback) {
            EntityCache.CareerTrack.find({'CareerTrackTemplate.MileStones.hgId': params.MilestoneId}, function (err, track) {
                if (err) {
                    if (callback) {
                        callback('server.hge.crt.elc', null);
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elc');
                    }
                } else {
                    if (callback) {
                        callback(null, track);
                    } else {
                        EventResponder.RespondWithData(EventEmitterCache, params, track);
                    }
                }
            });
        };

        this.SetMilestoneStatus = function (params) {
            var track = params.Track,
                theMilestones = track.CareerTrackTemplate.MileStones.filter(function (m) {
                    return m.hgId === params.MileStoneId;
                });
            if (theMilestones.length === 1) {
                theMilestones[0].Status = params.NewStatus;
                if (params.NewStatus === 'Closed') {
                    theMilestones[0].ClosedDate = Date.now();
                }
            }
            track.markModified('CareerTrackTemplate.MileStones');
            track.save(function (err) {
                if (err || !track) {
                    EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CareerTrack.ErrorUpdatingTrackMilestone);
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, track);
                }
            });
        };

        this.SetTrackAndGoalStatus = function (params) {
            var track = params.Track;
            track.Status = params.NewStatus;
            track.CareerTrackTemplate.Goal.Status = params.NewStatus;
            if (params.NewStatus === 'Closed') {
                track.CareerTrackTemplate.Goal.ClosedDate = Date.now();
            }
            track.markModified('CareerTrackTemplate.Goal');
            track.save(function (err) {
                if (err || !track) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.eum');
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, track);
                }
            });
        };

        this.GetTrackById = function (params, callback) {
            var trackId = params.TrackId;
            EntityCache.CareerTrack.findOne({$or: [
                {hgId: trackId},
                {'CareerTrackTemplate.MileStones.hgId': trackId},
                {'CareerTrackTemplate.Goal.hgId': trackId}
            ]}, function (err, track) {
                if (err) {
                    if (callback) {
                        callback(err);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.elt'));
                    }
                } else {
                    if (track) {
                        track.SetPercentAchieved();
                    }
                    if (callback) {
                        callback(null, track);
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, track));
                    }
                }
            });
        };

        this.GetMembersWithGivenTrack = function (params) {
            EntityCache.CareerTrack.find({'CareerTrackTemplate.hgId': params.TemplateId}, function (err, tracks) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.elt'));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, tracks.map(function (t) {
                        return t.AssignedMember;
                    })));
                }
            });
        };

        this.DeleteTrack = function (params) {
            var canIDeleteTrack = function (track, roles, memberId) {
                var i,
                    len;
                if (track.CreatorMember.hgId === memberId) {
                    return true;
                }
                for (i = 0, len = roles.length; i < len; i += 1) {
                    if (['Admin', 'Owner', 'HGAdmin'].indexOf(roles[i]) !== -1) {
                        return true;
                    }
                }
                return false;
            };
            EntityCache.CareerTrack.findOne({hgId: params.TrackId}, function (err, track) {
                if (err || !track) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.elt'));
                    return;
                }
                if (canIDeleteTrack(track, params.RolesInGroup, params.MemberId) !== true) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'ser.tds.yhg'));
                    return;
                }
                track.remove(function (err) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.crt.edt'));
                        return;
                    }
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'track deleted'));
                });
            });
        };

        this.UpdateGroupCareerTrack = function (params) {
            var hasCreditValue = params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue,
                needsTitle = params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.Title.length === 0;
            if (params.Track === undefined || params.UserId === undefined) {
                return EventResponder.RespondWithError(EventEmitterCache, params, 'ser.tds.bul.tws');
            }
            if (needsTitle) {
                return EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.oam');
            }
            EntityCache.Group.findOne({hgId: params.Track.CareerTrackTemplate.GroupId}, function (err, group) {
                if (err) {
                    return EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.grp.elg');
                }
                if (hasCreditValue > 0 && (hasCreditValue < group.CreditSetting.MinRecognition || hasCreditValue > group.CreditSetting.MaxRecognition)) {
                    return EventResponder.RespondWithError(EventEmitterCache, params,
                        JSON.stringify(['ser.tds.mam', {minreco: group.CreditSetting.MinRecognition, maxreco: group.CreditSetting.MaxRecognition}]));
                }
                EntityCache.CareerTrack.find({'BatchId': params.Track.BatchId}, function (err, tracks) {
                    var requests = [],
                        milestones,
                        oldMilestones,
                        i,
                        len;
                    if (err || !tracks) {
                        return EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elt');
                    }
                    tracks.forEach(function (track) {
                        track.ModifiedBy = params.UserId;
                        milestones = params.Track.CareerTrackTemplate.MileStones;
                        oldMilestones = track.CareerTrackTemplate.MileStones;
                        track.CareerTrackTemplate = params.Track.CareerTrackTemplate;
                        for (i = 0, len = oldMilestones.length; i < len; i += 1) {
                            if (milestones[i]) {
                                track.CareerTrackTemplate.MileStones[i].hgId = milestones[i].hgId;
                                track.CareerTrackTemplate.MileStones[i].Status = milestones[i].Status;
                                track.CareerTrackTemplate.MileStones[i].PercentAchieved = milestones[i].PercentAchieved;
                                //if NumericValue is entered, update PercentAchieved as well
                                if (milestones[i].MilestoneTarget === undefined) {
                                    track.CareerTrackTemplate.MileStones[i].PercentAchieved = calculatePercentCompleteOnNonNumericValue(milestones[i], oldMilestones[i]);
                                } else {
                                    track.CareerTrackTemplate.MileStones[i].PercentAchieved = calculatePercentCompleteOnNumericValue(milestones[i], oldMilestones[i]);
                                }
                                hasCreditValue = milestones[i].RecognitionTemplate.CreditValue;
                                if (hasCreditValue > 0 && (hasCreditValue < group.CreditSetting.MinRecognition || hasCreditValue > group.CreditSetting.MaxRecognition)) {
                                    return EventResponder.RespondWithError(EventEmitterCache, params,
                                        JSON.stringify(['ser.tds.mam', {minreco: group.CreditSetting.MinRecognition, maxreco: group.CreditSetting.MaxRecognition}]));
                                }
                            }
                            if (oldMilestones[i] && track.CareerTrackTemplate.MileStones[i]) {
                                track.CareerTrackTemplate.MileStones[i].Status = oldMilestones[i].Status;
                            }
                        }
                        track.SetPercentAchieved();
                        track.Collaborators = params.Track.Collaborators;
                        arrayUtil.ObjectIndexOf(track.Collaborators, 'UserId', track.AssignedMember.UserId, function (index) {
                            if (index !== -1) {
                                track.Collaborators.splice(index, 1);
                            }
                        });
                        requests.push({
                            Track: JSON.parse(JSON.stringify(track)),
                            FriendlyGroupId: params.FriendlyGroupId
                        });
                    });
                    len = requests.length;
                    Async.whilst(
                        function () {
                            len -= 1;
                            return len > -1;
                        },
                        function (callback) {
                            updateCareerTrack(requests[len], callback);
                        },
                        function (err) {
                            if (err) {
                                HgLog.error({methodName: 'UpdateGroupCareerTrack', error: err});
                                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elt');
                            } else {
                                EventResponder.RespondWithData(EventEmitterCache, params, requests.map(function (req) {
                                    return req.Track;
                                }));
                            }
                        }
                    );
                });
            });
        };

        this.UpdateCareerTrack = function (params) {
            var isSelfAssigned = params.Track.AssignedMember.UserId === params.Track.CreatorMember.UserId,
                hasCreditValue = params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue > 0,
                needsTitle = params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.Title.length === 0,
                BatchId = params.Track.BatchId,
                hasCreditValueInRange = false;
            if (params.Track === undefined || params.UserId === undefined) {
                return EventResponder.RespondWithError(EventEmitterCache, params, 'Track was not specified.');
            }
            EntityCache.Group.findOne({hgId: params.Track.CareerTrackTemplate.GroupId}, function (err, group) {
                if (err) {
                    return EventResponder.RespondWithError(EventEmitterCache, params, err);
                }
                if (params.Track.CareerTrackTemplate.Goal.BadgeId) {
                    params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId = guid.v1();
                    FileHelper.CopyBadgeImage({
                        BadgeId: params.Track.CareerTrackTemplate.Goal.BadgeId,
                        FriendlyGroupId: group.FriendlyGroupId,
                        TemplateId: params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId
                    });
                    delete params.Track.CareerTrackTemplate.Goal.BadgeId;
                }
                params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.Title = params.Track.CareerTrackTemplate.Title;
                EntityCache.CareerTrack.findOne({hgId: params.Track.hgId}, function (err, originalTrack) {
                    var i,
                        len;
                    if (err) {
                        return EventResponder.RespondWithError(EventEmitterCache, params, err);
                    }
                    for (i = 0, len = params.Track.CareerTrackTemplate.MileStones.length; i < len; i += 1) {
                        if (!hasCreditValue) {
                            hasCreditValue = params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.CreditValue > 0;
                        }
                        if (!needsTitle) {
                            needsTitle = params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.Title.length === 0;
                        }
                        if (params.Track.CareerTrackTemplate.MileStones[i].hgId.length === 0) {
                            params.Track.CareerTrackTemplate.MileStones[i].hgId = guid.v1();
                        }
                        if (!hasCreditValueInRange && (params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.CreditValue > 0 && (params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.CreditValue < group.CreditSetting.MinRecognition || params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.CreditValue > group.CreditSetting.MaxRecognition))) {
                            hasCreditValueInRange = true;
                        }
                        //if NumericValue is entered, update PercentAchieved as well
                        if (params.Track.CareerTrackTemplate.MileStones[i].MilestoneTarget !== undefined) {
                            params.Track.CareerTrackTemplate.MileStones[i].PercentAchieved = calculatePercentCompleteOnNumericValue(params.Track.CareerTrackTemplate.MileStones[i], originalTrack.CareerTrackTemplate.MileStones[i]);
                        } else {
                            params.Track.CareerTrackTemplate.MileStones[i].PercentAchieved = calculatePercentCompleteOnNonNumericValue(params.Track.CareerTrackTemplate.MileStones[i], originalTrack.CareerTrackTemplate.MileStones[i]);
                        }
                        params.Track.CareerTrackTemplate.MileStones[i].DisplayName = params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.Title;
                        if (params.Track.CareerTrackTemplate.MileStones[i].BadgeId) {
                            params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.hgId = guid.v1();
                            FileHelper.CopyBadgeImage({
                                BadgeId: params.Track.CareerTrackTemplate.MileStones[i].BadgeId,
                                FriendlyGroupId: group.FriendlyGroupId,
                                TemplateId: params.Track.CareerTrackTemplate.MileStones[i].RecognitionTemplate.hgId
                            });
                            delete params.Track.CareerTrackTemplate.MileStones[i].BadgeId;
                        }
                        if (['RequestComplete', 'Completed'].indexOf(params.Track.CareerTrackTemplate.Goal.Status) > -1 &&
                                ['RequestComplete', 'Completed'].indexOf(params.Track.CareerTrackTemplate.MileStones[i].Status) === -1) {
                            params.Track.CareerTrackTemplate.Goal.Status = Enums.TrackStatus.Partial;
                        }
                    }
                    //if Track Status is eitehr RequestComplete or Complete, and all milestones are NOT completed, change its status to Partial
                    if (!checkAllMilestonesCompleted(params.Track, 0) && ['RequestComplete', 'Completed'].indexOf(params.Track.Status) > -1) {
                        params.Track.Status = Enums.TrackStatus.Partial;
                    }
                    if (isSelfAssigned && hasCreditValue) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.twc');
                    } else if (needsTitle) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.oam');
                    } else if (params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue > 0 && (params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue < group.CreditSetting.MinRecognition || params.Track.CareerTrackTemplate.Goal.RecognitionTemplate.CreditValue > group.CreditSetting.MaxRecognition)) {
                        EventResponder.RespondWithError(EventEmitterCache, params,  'Credit value should be between ' + group.CreditSetting.MinRecognition + ' and ' + group.CreditSetting.MaxRecognition);
                    } else if (hasCreditValueInRange) {
                        EventResponder.RespondWithError(EventEmitterCache, params,  'Credit value should be between ' + group.CreditSetting.MinRecognition + ' and ' + group.CreditSetting.MaxRecognition);
                    } else {
                        params.Track.ModifiedBy = params.UserId;
                        params.Track.ModifiedDate = Date.now();
                        EntityCache.CareerTrack.findOneAndUpdate({
                            hgId: params.Track.hgId
                        }, {
                            $set: {
                                Collaborators: params.Track.Collaborators,
                                CareerTrackTemplate: params.Track.CareerTrackTemplate,
                                ModifiedDate: params.Track.ModifiedDate,
                                ModifiedBy: params.Track.ModifiedBy,
                                Status: params.Track.Status,
                                NotificationFrequency: params.Track.NotificationFrequency
                            }
                        }, {
                            new: true
                        }, function (err, doc) {
                            if (err) {
                                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elt');
                            } else {
                                doc.SetPercentAchieved();
                                doc.save(function (err) {
                                    if (err) {
                                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.crt.elt');
                                    } else {
                                        EventResponder.RespondWithData(EventEmitterCache, params, BatchId);
                                    }
                                });
                            }
                        });
                    }
                });
            });
        };

        this.CreateGoalTrack = function (params) {
            var requests = [],
                len,
                batchId = params.Data.BatchId || guid.v1();
            switch (params.Data.Type) {
            case 'Private':
            case 'Public':
                requests = params.RecipientMembers.map(function (recipient) {
                    return {
                        batchId: batchId,
                        template: getTrackTemplate(params),
                        recipientMember:  recipient,
                        issuerMember: params.IssuerMember,
                        userId: params.UserId,
                        collaborators: params.Data.Collaborators,
                        NotificationFrequency: params.Data.NotificationFrequency,
                        Track: {}
                    };
                });
                len = requests.length;
                Async.whilst(
                    function () {
                        len -= 1;
                        return len > -1;
                    },
                    function (callback) {
                        assignOneTrackToOneMember(requests[len], callback);
                    },
                    function (err) {
                        if (err) {
                            HgLog.error({methodName: 'CreateGoalTrack', error: err});
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, err + ' todo: error happened, need to reverse'));
                        } else {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, requests.map(function (r) {
                                return r.Track;
                            })));
                        }
                    }
                );
                break;
            case 'Template':
                getTrackTemplate(params).save(function (err) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CareerTrackTemplate.ErrorSavingCareerTrackTemplate));
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'Track template created'));
                    }
                });
                break;
            }
        };

        this.GetGroupNotificationTracks = function (params, callback) {
            var query = {
                    'CreatorMember.GroupId': { $in: params.GroupIds},
                    Status: { $nin: ['Created', 'Completed',  'Closed', 'Void'] },
                    NotificationFrequency: { $exists: true, $ne: 'Never' }
                },
                group = {
                    _id: '$AssignedMember.hgId',
                    rows: {$push: {
                        ModifiedDate: '$ModifiedDate',
                        NotificationFrequency: '$NotificationFrequency',
                        Collaborators: '$Collaborators',
                        FullName: '$AssignedMember.FullName',
                        MyManagers: '$AssignedMember.MyManagers',
                        CreatorHgId: '$CreatorMember.hgId',
                        GroupId: '$CreatorMember.GroupId',
                        hgId: '$hgId',
                        Title: '$CareerTrackTemplate.Title',
                        PercentAchieved: '$PercentAchieved',
                        UserId: '$AssignedMember.UserId'
                    }}
                };
            EntityCache.CareerTrack.aggregate([{ $match: query}, {$sort: {ModifiedDate: 1}}, { $group: group}], function (err, data) {
                if (err) {
                    callback(err);
                } else {
                    callback(null, data);
                }
            });
        };

        this.GetCareerTracksByGroupId = function (params, callback) {
            EntityCache.CareerTrack.find({$or: [
                {'CareerTrackTemplate.MileStones.RecognitionTemplate.GroupId': params.GroupId},
                {'CreatorMember.GroupId': params.GroupId}
            ]}, function (err, careerTracks) {
                if (err) {
                    callback(err);
                } else {
                    callback(null, careerTracks);
                }
            });
        };

        //Mark all tracks and those milestones as Void/Cancelled
        this.SoftDeleteTracks = function (params, callback) {
            var tracks = params.Tracks,
                batchId = tracks[0].BatchId,
                trackId = tracks[0].hgId,
                i,
                len;
            Async.forEach(tracks, function (track, callback) {
                track.CareerTrackTemplate = EntityCache.CareerTrackTemplate(track.CareerTrackTemplate);
                track.CareerTrackTemplate.Goal.Status = Enums.MilestoneStatus.Cancelled;
                track.Status = 'Void';
                len = track.CareerTrackTemplate.MileStones.length;
                for (i = 0; i < len; i += 1) {
                    track.CareerTrackTemplate.MileStones[i].Status = Enums.MilestoneStatus.Cancelled;
                }
                track.markModified('CareerTrackTemplate.Goal');
                track.markModified('CareerTrackTemplate.MileStones');
                track.ModifiedDate = Date.now();
                track.markModified('ModifiedDate');
                track.markModified('Status');
                track.save(function (err) {
                    if (err) {
                        callback(err);
                    } else {
                        callback();
                    }
                });
            }, function (err) {
                if (err) {
                    callback(err);
                } else {
                    callback(null, {Message: 'Tracks have been deleted', BatchId: batchId, TrackId: trackId});
                }
            });
        };

        //Mark all tracks and those milestones as In Progress
        this.RestoreTracks = function (params, callback) {
            var tracks = params.Tracks,
                batchId = tracks[0].BatchId,
                trackId = tracks[0].hgId,
                i,
                len,
                track,
                restoreTracks = function () {
                    //if track processed was the last one
                    if (tracks.length === 0) {
                        return callback(null, { Message: 'Tracks Have been restored',  BatchId: batchId, TrackId: trackId});
                    }
                    track = tracks.pop();
                    track.CareerTrackTemplate = EntityCache.CareerTrackTemplate(track.CareerTrackTemplate);
                    track.CareerTrackTemplate.Goal.Status = Enums.MilestoneStatus.InProgress;
                    track.Status = Enums.TrackStatus.Partial;
                    len = track.CareerTrackTemplate.MileStones.length;
                    for (i = 0; i < len; i += 1) {
                        track.CareerTrackTemplate.MileStones[i].Status = Enums.MilestoneStatus.InProgress;
                    }
                    track.markModified('CareerTrackTemplate.Goal');
                    track.markModified('CareerTrackTemplate.MileStones');
                    track.ModifiedDate = Date.now();
                    track.markModified('ModifiedDate');
                    track.markModified('Status');
                    track.save(function (err) {
                        if (err) {
                            callback(err);
                        } else {
                            restoreTracks();
                        }
                    });
                };
            restoreTracks();
        };

        this.CloseTracksByAssigneeMemberId = function (params, callback) {
            EntityCache.CareerTrack.update(
                {'AssignedMember.hgId': params.MemberId},
                {$set: {Status: 'Closed', 'CareerTrackTemplate.Goal.Status': 'Closed', 'CareerTrackTemplate.Goal.ClosedDate': Date.now()}},
                {multi: true},
                function (err) {
                    if (err) {
                        callback(err);
                    } else {
                        callback(null, 'Tracks closed');
                    }
                }
            );
        };

        this.TransferManagerTracks = function (params, callback) {
            function isACollaborator(memberId, collaborators) {
                return collaborators.some(function (c) {
                    return c.MemberId === memberId;
                });
            }
            function updateTransferManagerTracks(tracks) {
                tracks.forEach(function (trackItem) {
                    // if oldManager is the Assigner of the Track we want to set it to the new manager
                    if (isACollaborator(params.NewManager.hgId, trackItem.Collaborators) && trackItem.CreatorMember.hgId !== params.OldManager.hgId) { // New manager is a collaborator
                        trackItem.Collaborators.forEach(function (collaboratorItem) {
                            if (collaboratorItem.MemberId === params.NewManager.hgId && collaboratorItem.AccessLevel !== 'Manager') {
                                collaboratorItem.AccessLevel = 'Manager';
                            }
                        });
                    } else if (trackItem.CreatorMember.hgId !== params.NewManager.hgId && trackItem.CreatorMember.hgId !== params.OldManager.hgId) { // new manager is not the creator of the track
                        trackItem.Collaborators.push({
                            FullName: params.NewManager.FullName,
                            UserId: params.NewManager.UserId,
                            MemberId: params.NewManager.hgId,
                            AccessLevel: 'Manager'
                        });
                    } else if (isACollaborator(params.NewManager.hgId, trackItem.Collaborators) && (trackItem.CreatorMember.hgId === params.OldManager.hgId)) {
                        trackItem.CreatorMember = params.NewManagerRecord;
                        trackItem.Collaborators = trackItem.Collaborators.filter(function (collaboratorItem) {
                            return collaboratorItem.MemberId !== params.NewManager.hgId;
                        });
                    } else if (trackItem.CreatorMember.hgId === params.OldManager.hgId) { // replace old Creator to with new Manager, change to allow new manager to approve tracks
                        trackItem.CreatorMember = params.NewManagerRecord;
                    }
                    if (isACollaborator(params.OldManager.hgId, trackItem.Collaborators)) { // Old manager is a collaborator
                        trackItem.Collaborators = trackItem.Collaborators.filter(function (collaboratorItem) {
                            return collaboratorItem.MemberId !== params.OldManager.hgId;
                        });
                    }
                    trackItem.save();
                });
            }
            function transferManagerTracks(params, callback) {
                var query = {
                    Status: { $nin: ['Created', 'Completed',  'Closed', 'Void'] }, // inprogress
                    $or: [
                        { 'Collaborators.MemberId': params.OldManager.hgId },
                        {
                            'CreatorMember.hgId': params.OldManager.hgId,
                            'AssignedMember.hgId': { $ne:  params.OldManager.hgId}
                        }
                    ]
                };
                //limit transfer to selected direct reports
                if (params.DirectReports.length > 0) {
                    query['AssignedMember.hgId'] = { $in: params.DirectReports };
                }
                EntityCache.CareerTrack.find(query, function (err, data) {
                    if (err) {
                        callback(err);
                    } else {
                        if (data && data.length > 0) {
                            updateTransferManagerTracks(data, callback);
                        }
                        callback(null, 'Tracks Transferred');
                    }
                });
            }
            transferManagerTracks(params, function (err, data) {
                if (err) {
                    callback(err);
                } else {
                    callback(null, data);
                }
            });
        };
    };

module.exports = CareerTrackProcessor;
