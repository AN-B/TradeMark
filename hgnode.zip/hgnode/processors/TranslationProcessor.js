/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    Translation = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            TranslationEnums = require('../enums/TranslationEnums.js');

        function addTranslation(params, callback) {
            var translation = EntityCache.Translations(params);
            translation.CreatedBy = params.UserId;
            translation.save(callback);
        }

        function updateTranslation(params, callback) {
            EntityCache.Translations.findOneAndUpdate({
                GroupId: params.GroupId,
                EntityId: params.EntityId,
                EntityType: params.EntityType,
                Lang: params.Lang
            }, {
                $set: {
                    ModifiedDate: Date.now(),
                    ModifiedBy: params.UserId,
                    Values: params.Values,
                    Status: params.Status
                }
            }, {
                new: true
            }, callback);
        }
        this.SaveTranslation = function (params, callback) {
            EntityCache.Translations.findOne({
                GroupId: params.GroupId,
                EntityId: params.EntityId,
                EntityType: params.EntityType,
                Lang: params.Lang
            }, function (error, translation) {
                if (error) {
                    return callback(error);
                }
                if (translation && translation.EntityId) {
                    updateTranslation(params, callback);
                } else {
                    addTranslation(params, callback);
                }
            });
        };

        this.GetTranslation = function (params, callback) {
            EntityCache.Translations.findOne({
                GroupId: params.GroupId,
                EntityId: params.EntityId,
                Lang: params.Lang
            }, callback);
        };

        this.GetTranslationsByEntityId = function (params, callback) {
            EntityCache.Translations.aggregate([
                {
                    $match: {
                        GroupId: params.GroupId,
                        EntityId: {$in: params.EntityIds}
                    }
                },
                {
                    $group: {
                        _id: { EntityId: "$EntityId"},
                        data: { "$addToSet": {
                            lang: "$Lang",
                            values: "$Values"
                        }}
                    }
                }
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data.map(function (item) {
                    return {
                        EntityId: item._id.EntityId,
                        Data: item.data
                    };
                }));
            });
        };

        this.GetTranslationsByLanguage = function (params, callback) {
            EntityCache.Translations.find({
                GroupId: params.GroupId,
                EntityId: {$in: params.EntityIds},
                Lang: params.Lang,
                Status: TranslationEnums.Status.Active
            }, callback);
        };
    };

module.exports = Translation;
