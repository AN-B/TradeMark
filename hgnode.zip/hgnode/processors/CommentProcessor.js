/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    CommentProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid'),
            HgError = require('../common/HgError.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            HgMessage = require('../common/HgMessage.js');

        this.Like = function (params, callback) {
            EntityCache.Comment.findOneAndUpdate({
                hgId: params.CommentId,
                'LikedMembers.MemberId': {$ne: params.MemberId}
            },
                {
                    $inc: {
                        LikedCount: 1
                    },
                    $addToSet: {
                        LikedMembers: {
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            FullName: params.FullName
                        }
                    }
                },
                {
                    new: true
                }, callback);
        };

        this.ArchiveCoachingNotesForEntities = function (params, callback) {
            EntityCache.Comment.update(
                {
                    EntityId: {$in: params.EntityIds},
                    EntityType: EntityEnums.CommentEntityType.Coaching
                },
                {
                    $set: {
                        Status: EntityEnums.CommentStatus.Archived,
                        ModifiedBy: params.UserId
                    }
                },
                {
                    upsert: false,
                    multi: true
                },
                function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, 'Notes Archived');
                    }
                }
            );
        };
        this.GetCommentsByEntityId = function (params, callback) {
            EntityCache.Comment.find({
                EntityId: params.EntityId,
                Status: EntityEnums.CommentStatus.Active
            }).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).sort({_id: -1}).exec(function (error, data) {
                callback(error, !data.length ? [] : data.map(function (item) {
                    return item.toObject();
                }));
            });
        };
        this.GetCommentsByEntityAndType = function (params, callback) {
            EntityCache.Comment.find({
                Type: params.Type,
                EntityId: params.EntityId
            }).sort({_id: -1}).exec(callback);
        };

        this.GetCoachingReceivedByMemberId = function (params, callback) {
            var sort = { sort : { CreatedDate: -1} },
                query = {
                    Type : 'Coaching',
                    'Recipient.MemberId' : params.MemberId,
                    Status : 'Active',
                    IsPublic : true
                };
            if (params.StartDate && params.EndDate) {
                query.CreatedDate = { $gte : params.StartDate, $lte : params.EndDate };
            }
            EntityCache.Comment.find(query, null, sort, function (error, data) {
                callback(error, data);
            });
        };

        this.GetCoachingNoteGivenByMemberId = function (params, callback) {
            var query = {
                    Type : 'Coaching',
                    MemberId : params.MemberId,
                    Status : 'Active',
                    IsPublic : true
                };
            if (params.StartDate && params.EndDate) {
                query.CreatedDate = { $gte : params.StartDate, $lte : params.EndDate };
            }
            EntityCache.Comment.find(query, null, { sort: { CreatedDate: -1} }, callback);
        };

        this.GetCoachingNotesForMember = function (params, callback) {
            var mquery = EntityCache.Comment.find({Type : 'Coaching',  $or : [
                    {$and: [{'Recipient.MemberId' : params.RecipientMemberId}, {'Recipient.MemberId' : params.MemberId}, {'Status' : 'Active'}]},//You are the recipient
                    {$and: [{'Recipient.MemberId' : params.RecipientMemberId}, {'MemberId' : params.MemberId}, {'Status' : {$in: ['Active', 'Draft']}}]},//you are the coach
                    {$and: [{'Recipient.MemberId' : params.RecipientMemberId}, {'IsPublic' : true}, {'Status' : 'Active'}]}
                ]});  //you are neither abo
            mquery.sort({ModifiedDate : -1}).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (error, comments) {
                callback(error, comments);
            });
        };

        this.GetCoachingNoteById = function (params, callback) {
            EntityCache.Comment.findOneAndUpdate({hgId: params.NoteId}, {$addToSet: {ReadBy: params.MemberId}}, {new: true}, callback);
        };

        this.GetCoachingNoteComments = function (params, callback) {
            EntityCache.Comment.find({EntityId: params.NoteId}, null, { sort: { CreatedDate: -1} }, callback);
        };

        this.DeleteRecognitionComment = function (params, callback) {
            var query = {EntityType : 'Recognition', EntityId : params.EntityId},
                update = {$set : {Status : 'Deleted', ModifiedBy : params.UserId}};
            EntityCache.Comment.update(query, update, {multi : true}, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, HgMessage.Enums.Comment.SuccessDeleted);
            });
        };

        this.MarkCommentAsDeleted = function (params, callback) {
            EntityCache.Comment.update({
                hgId: params.CommentId
            }, {
                $set: {
                    Status: EntityEnums.CommentStatus.Deleted,
                    ModifiedBy: params.UserId
                }
            }, function (error) {
                callback(error, 'business.com.pro.com');
            });
        };

        this.UpdateCoachingNoteModifiedDate = function (params, callback) {
            EntityCache.Comment.update({
                hgId: params.NoteId
            }, {
                $set: {
                    ModifiedBy: params.UserId
                }
            }, function (error) {
                callback(error);
            });
        };

        this.UpdateCoachingNote = function (params, callback) {
            var updateQuery = {
                $set: {
                    Header: params.Header,
                    Comment: params.Note,
                    ModifiedBy: params.UserId,
                    Status: params.Draft ? EntityEnums.CommentStatus.Draft : EntityEnums.CommentStatus.Active,
                    IsPublic: !params.Draft
                }
            };
            if (params.TrackId) {
                updateQuery.$set.TrackId = params.TrackId;
            } else if (params.UnsetTrackId) {
                updateQuery.$unset = {
                    TrackId : ''
                };
            }
            EntityCache.Comment.update(
                {hgId : params.NoteId},
                updateQuery,
                function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback();
                    }
                }
            );
        };

        this.MarkCommentsAsDeletedByOrderId = function (params, callback) {
            EntityCache.Comment.update({
                EntityType: EntityEnums.CommentEntityType.Recognition,
                GroupId: params.GroupId,
                'Attachments.OrderId': params.OrderId
            }, {
                $set: {
                    Status: EntityEnums.CommentStatus.Deleted
                }
            }, {
                multi: true
            }, function (error, data) {
                callback(error, 'business.com.pro.com');
            });
        };

        this.MarkCommentsAsDeletedByEntityId = function (params, callback) {
            EntityCache.Comment.update({
                EntityId: {$in : params.EntityIds}
            }, {
                $set: {
                    Status:  EntityEnums.CommentStatus.Deleted,
                    ModifiedBy: params.UserId
                }
            }, function (error) {
                callback(error, 'business.com.pro.cmd');
            });
        };
        //Note: Devs Do not call this method directly
        //Call CommentInternalService.GetCommentById
        this.GetCommentById = function (params, callback) {
            EntityCache.Comment
                .findOne({hgId: params.CommentId})
                .exec(function (error, comment) {
                    if (error || !comment) {
                        return callback('business.com.pro.err');
                    }
                    callback(null, comment);
                });
        };

        this.GetByEntityId = function (params, callback) {
            var query = {
                EntityId: params.EntityId,
                Status: EntityEnums.CommentStatus.Active
            };
            if (Array.isArray(params.Types)) {
                query.Type = {$in: params.Types};
            }
            EntityCache.Comment.find(query).sort({_id: 1}).lean().exec(function (error, data) {
                callback(error, !data.length ? [] : data.map(function (item) {
                    return item;
                }));
            });
        };

        this.Get = function (params, callback) {
            // This query needs to be simplified
            // It seems it is only called with EntityType of Milestone or Coaching via tracks

            // validation for entity should be moved out of this processor 
            var mquery, equery, entityGroupId;
            if (params.EntityType === 'Recognition') {
                equery = EntityCache.Recognition.findOne({hgId: params.EntityId});
            } else {
                equery = EntityCache.CareerTrack.findOne({$or: [{'CareerTrackTemplate.Goal.hgId': params.EntityId}, {'CareerTrackTemplate.MileStones.hgId' : params.EntityId}]});
            }
            if (!params.EntityId || params.EntityId === '') {
                callback(HgError.Enums.Comment.EmptyEntityId);
            } else {
                mquery = EntityCache.Comment.find({EntityId: params.EntityId, Status: EntityEnums.CommentStatus.Active, IsPublic: params.IsPublic});
                if (params.EntityType) {
                    mquery.where('EntityType', params.EntityType);
                }
                if (params.Type) {
                    mquery.where('Type', params.Type);
                }
                equery.exec(function (error, entity) {
                    if (error || !entity) {
                        callback('business.com.pro.errl');
                    } else {
                        if (params.EntityType === 'Recognition') {
                            entityGroupId = entity.Template.GroupId;
                        } else if (entity.CareerTrackTemplate) {
                            entityGroupId = entity.CareerTrackTemplate.GroupId;
                        }
                        if (entityGroupId !== params.GroupId) {
                            callback('business.com.pro.acc');
                        } else {
                            mquery.sort({CreatedDate: -1}).exec(function (error, data) {
                                callback(error, !data.length ? [] : data.map(function (item) {
                                    return item.toObject();
                                }));
                            });
                        }
                    }
                });
            }
        };

        this.GetCommentsByEntityIds = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Status: EntityEnums.CommentStatus.Active,
                IsPublic: params.IsPublic,
                Type: {$in: [EntityEnums.CommentType.KeyResultUpdate, EntityEnums.CommentType.Comment, EntityEnums.CommentType.Coaching]}
            };
            // this should require that entityids are passed in
            if (!params.EntityIds || !params.EntityIds.length) {
                return callback(null, []);
            }
            if (params.EntityIds.length) {
                query.EntityId = {$in: params.EntityIds};
            }
            if (!params.ExcludeGift) {
                query.Type.$in.push(EntityEnums.CommentType.Gift);
            }
            if (params.ShowPointsInFeed) {
                query.Type.$in.push(EntityEnums.CommentType.AddPoints);
            }
            //this method is a potiential problem because it would load
            //all comments in the system when entityIds are not passed in or when a large amount of entityis are passed in
            //we need to limit to top 10 and make the caller pass skip and take
            //the next method after this loads tagged users so their is chain
            //event when large comments are loaded then loads all tagged users 
            //with in the comments. 
            //method needs a refactor
            EntityCache.Comment.find(query).sort({_id: -1}).exec(function (error, data) {
                callback(error, !data.length ? [] : data.map(function (item) {
                    return item.toObject();
                }));
            });
        };

        this.RemoveComments = function (params, callback) {
            EntityCache.Comment.remove({GroupId: params.GroupId, EntityId: {$in: params.EntityIds}}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'Comments Deleted');
                }
            });
        };

        this.Create = function (params, callback) {
            var comment = EntityCache.Comment(params.CommentRequest);
            comment.hgId = guid.v1();
            comment.CreatedBy = comment.ModifiedBy = comment.CommenterUserhgId = params.UserId;
            comment.CommenterFirstName = params.FirstName;
            comment.CommenterLastName = params.LastName;
            comment.GroupId = params.GroupId;
            comment.MemberId = params.MemberId;
            comment.Attachments = params.CommentRequest.Attachments;
            comment.save(callback);
        };
        this.GetCommentCountByEntityId = function (params, callback) {
            var search = {
                    EntityId: { $in: params.EntityIds},
                    Status: EntityEnums.CommentStatus.Active,
                    IsPublic: params.IsPublic
                },
                query;

            if (params.Type) {
                search.Type = params.Type;
            }

            query = EntityCache.Comment.aggregate([
                {$match: search },
                {$group: {
                    _id: '$EntityId',
                    count: { $sum: 1 }
                }}]);

            query.exec(function (err, data) {
                callback(err, data);
            });
        };
        this.EditComment = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                hgId: params.CommentId
            };
            if (!params.IsAdmin) {
                query.ModifiedDate = {$gte: Date.now() - params.CommentEditInterval};
            }
            EntityCache.Comment.findOne(query, function (error, data) {
                if (error || !data) {
                    return callback(error || 'Error Loading Comment');
                }
                data.Comment = params.Comment;
                data.ModifiedBy = params.UserId;
                data.TaggedUser = params.TaggedUser;
                data.save(callback);
            });
        };
        this.GetCommentByGroupId = function (params, callback) {
            EntityCache.Comment.find({GroupId: params.GroupId}, callback);
        };
    };

module.exports = CommentProcessor;
