/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    RecognitionTemplateProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            FileHelper = require('../util/FileHelper.js'),
            PusherManager = require('../util/PusherManager'),
            guid = require('node-uuid'),
            HgError = require('../common/HgError.js'),
            HgLog = require('../framework/HgLog'),
            EventResponder = require('../util/EventResponder.js'),
            RecognitionMessageTemplates = require('../enums/RecognitionMessage.js'),
            RecognitionEnums = require('../enums/RecognitionEnums.js'),
            TemplateDto = require('../util/RecTemplateDTO.js'),
            HgCache = require('../framework/RedisConnectionCache'),
            crytoHelper = require('../helpers/cryptoHelper.js'),
            config = require('../configurations/config.js'),
            createImagesForValueLevels = function (params) {
                var group = params.Group;
                if (!group.ValueLevelSetting.Levels || group.ValueLevelSetting.Levels.length < 1) {
                    return;
                }
                EntityCache.Badge.findOne({hgId: params.BadgeId}, function (err, badge) {
                    var iconFilename,
                        borderFilename,
                        compositeFilename;
                    if (err || !badge) {
                        return;
                    }
                    iconFilename = badge.Filename;
                    group.ValueLevelSetting.Levels.forEach(function (level) {
                        var compositeParams;
                        borderFilename = level.ImageId + '.svg';
                        compositeFilename = params.ImageId + '_' + level.Name + '.svg';
                        compositeParams = {
                            FirstImageFilename: borderFilename,
                            SecondImageFilename: iconFilename,
                            CompositeFilename: compositeFilename,
                            FriendlyGroupId: group.FriendlyGroupId,
                            ForegroundFillColor: params.ForegroundFillColor,
                            BackgroundFillColor: params.BackgroundFillColor
                        };
                        FileHelper.CompositeImages(compositeParams);
                    });

                });
            },
            createBadgeWithBackground = function (params) {
                EntityCache.Badge.findOne({hgId: params.BadgeId}, function (err, badge) {
                    if (err || !badge) {
                        return;
                    }
                    EntityCache.Badge.findOne({hgId: params.BackgroundBadgeId}, function (err, backgroundBadge) {
                        if (err || !backgroundBadge) {
                            return;
                        }
                        FileHelper.CompositeBackFront({
                            FrontImageFilename: badge.Filename,
                            BackImageFilename: backgroundBadge.Filename,
                            CompositeFilename: params.CompositeFilename || params.TemplateId + '.svg',
                            FriendlyGroupId: params.FriendlyGroupId,
                            Callback: params.Callback,
                            ForegroundFillColor: params.ForegroundFillColor,
                            BackgroundFillColor: params.BackgroundFillColor
                        });
                    });
                });
            },
            resolveImageFilenames = function (params, callback) {
                var fileName, backgroundFilename;
                if (!params.BadgeId && !params.BackgroundBadgeId) {
                    callback(null, null);
                    return;
                }
                EntityCache.Badge.findOne({hgId: params.BadgeId}, function (err, badge) {
                    if (err) {
                        callback(null, null);
                    } else {
                        fileName = badge ? badge.Filename : '';
                    }
                    EntityCache.Badge.findOne({hgId: params.BackgroundBadgeId}, function (err, backgroundBadge) {
                        if (err) {
                            callback(badge.Filename, null);
                        } else {
                            backgroundFilename = backgroundBadge ? backgroundBadge.Filename : '';
                        }
                        callback(fileName, backgroundFilename);
                    });
                });
            },
            validateGroupValueLevelSetting = function (group) {
                var level;
                if (group.ValueLevelSetting.Enabled === true) {
                    level = group.ValueLevelSetting.Levels.filter(function (level) {return level.Name === 'Silver'; });
                    if (!level || level.length !== 1 || !level[0].ImageId) {
                        return false;
                    }
                    level = group.ValueLevelSetting.Levels.filter(function (level) {return level.Name === 'Gold'; });
                    if (!level || level.length !== 1 || !level[0].ImageId) {
                        return false;
                    }
                    level = group.ValueLevelSetting.Levels.filter(function (level) {return level.Name === 'Platinum'; });
                    if (!level || level.length !== 1 || !level[0].ImageId) {
                        return false;
                    }
                    return true;
                }
                level = group.ValueLevelSetting.Levels.filter(function (level) {return level.Name === 'Default'; });
                if (!level || level.length !== 1 || !level[0].ImageId) {
                    return false;
                }
                return true;
            };
        this.DefaultEntityName = 'RecognitionTemplate';
        this.CreateOrUpdateTemplate = function (params, callback) {
            var TemplateRequest = params.TemplateRequest,
                templateColorsModified = TemplateRequest.IconPickerColor || TemplateRequest.BkgdPickerColor,
                recognitionTemplateModified = TemplateRequest.badgeChosen || TemplateRequest.backgroundChosen,
                subValues = [],
                i,
                userId = params.UserId,
                recognitionTemplate,
                subValue,
                updateSetting;
            TemplateRequest.SubValues = TemplateRequest.SubValues || [];

            resolveImageFilenames(params, function (foregroundFilename, backgroundFilename) {
                EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                    if (err) {
                        return callback(err);
                    }
                    //if this is for saving values templates, need to check if the group's values level border images have been set up
                    if (TemplateRequest.Category === 'Values') {
                        if (validateGroupValueLevelSetting(group) !== true) {
                            return callback('bisnes.rtp.vli');
                        }
                    }
                    if (TemplateRequest.Category === 'Achievement' && TemplateRequest.RestrictUsers &&
                            ((TemplateRequest.RestrictUsers.TeamIds && TemplateRequest.RestrictUsers.TeamIds.length) ||
                            (TemplateRequest.RestrictUsers.MemberIds && TemplateRequest.RestrictUsers.MemberIds.length) ||
                            (TemplateRequest.RestrictUsers.Roles && TemplateRequest.RestrictUsers.Roles.length))) {
                        TemplateRequest.AccessLevel = 'WithinTeam';
                    }
                    if (TemplateRequest.hgId) {
                        TemplateRequest.SubValues.forEach(function (requestSubValue) {
                            var subTemplateColorsModified = requestSubValue.IconPickerColor || TemplateRequest.BkgdPickerColor,
                                subRecognitionTemplateModified = requestSubValue.badgeChosen || TemplateRequest.backgroundChosen;
                            subValue = {
                                Name: requestSubValue.Name,
                                Description: requestSubValue.Description,
                                IconPickerColor: requestSubValue.IconPickerColor,
                                BadgeId: requestSubValue.BadgeId
                            };
                            if (!requestSubValue.ImageId) {//a new badge is selected
                                subValue.ImageId = guid.v1();
                                FileHelper.CopyBadgeImage({
                                    BadgeId: requestSubValue.BadgeId,
                                    FriendlyGroupId: group.FriendlyGroupId,
                                    TemplateId: subValue.ImageId
                                });
                                if (backgroundFilename) {
                                    createBadgeWithBackground({
                                        BadgeId: requestSubValue.BadgeId,
                                        BackgroundBadgeId: params.BackgroundBadgeId,
                                        FriendlyGroupId: group.FriendlyGroupId,
                                        TemplateId: TemplateRequest.hgId,
                                        CompositeFilename: subValue.ImageId + '_' + params.BackgroundBadgeId + '.svg',
                                        ForegroundFillColor: requestSubValue.IconPickerColor || '',
                                        BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                    });
                                }
                                // create value badge with level bg
                                createImagesForValueLevels({
                                    BadgeId: requestSubValue.BadgeId,
                                    FriendlyGroupId: group.FriendlyGroupId,
                                    ImageId: subValue.ImageId,
                                    Group: group,
                                    ForegroundFillColor: requestSubValue.IconPickerColor || '',
                                    BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                });

                            } else if (requestSubValue.ImageId) {//didn't select a new badge
                                subValue.ImageId = requestSubValue.ImageId;
                                if (backgroundFilename) {
                                    if (subRecognitionTemplateModified || subTemplateColorsModified) {
                                        FileHelper.CompositeImages({
                                            BorderSrc: true,
                                            FirstImageFilename: subValue.ImageId + '.svg',
                                            SecondImageFilename: backgroundFilename,
                                            CompositeFilename: subValue.ImageId + '_' + params.BackgroundBadgeId + '.svg',
                                            FriendlyGroupId: group.FriendlyGroupId,
                                            ForegroundFillColor: requestSubValue.IconPickerColor || '',
                                            BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                        });
                                    }
                                } else {
                                    if (group.ValueLevelSetting.Levels && group.ValueLevelSetting.Levels.length > 0) {
                                        group.ValueLevelSetting.Levels.forEach(function (level) {
                                            if (subRecognitionTemplateModified || subTemplateColorsModified) {
                                                FileHelper.EditCompositeImages({
                                                    BorderSrc: true,
                                                    FirstImageFilename: subValue.ImageId + '.svg',
                                                    SecondImageFilename: level.ImageId + '.svg',
                                                    CompositeFilename: subValue.ImageId + '_' + level.Name + '.svg',
                                                    FriendlyGroupId: group.FriendlyGroupId,
                                                    ForegroundFillColor: requestSubValue.IconPickerColor || '',
                                                    BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                                });
                                            }
                                        });
                                    }
                                }
                            }
                            subValues.push(subValue);
                        });
                        updateSetting = {
                            Title: TemplateRequest.Title,
                            Description: TemplateRequest.Description,
                            CreditValue: TemplateRequest.CreditValue || 0,
                            PointValue: TemplateRequest.PointValue || 0,
                            Type: TemplateRequest.Type || 'Recognition',
                            Category: TemplateRequest.Category,
                            AccessLevel: TemplateRequest.AccessLevel || 'WithinGroup',
                            Publicity: TemplateRequest.Publicity || 'Private',
                            Tags: TemplateRequest.Tags || '',
                            ModifiedBy: params.UserId,
                            TeamId: TemplateRequest.TeamId || '',
                            SubValues: subValues,
                            Levels: TemplateRequest.Levels || [],
                            DepartmentName: TemplateRequest.DepartmentName || '',
                            RestrictUsers: params.RestrictUsers || [],
                            RestrictDepartments: params.RestrictDepartments || [],
                            IconPickerColor: TemplateRequest.IconPickerColor || '',
                            BkgdPickerColor: TemplateRequest.BkgdPickerColor || '',
                            ModifiedDate: Date.now()
                        };
                        if (foregroundFilename) {
                            updateSetting.ForegroundFilename = foregroundFilename;
                        }
                        if (backgroundFilename) {
                            updateSetting.BackgroundFilename = backgroundFilename;
                        }
                        if (params.BadgeId) {
                            updateSetting.BadgeId = params.BadgeId;
                        }
                        if (params.BackgroundBadgeId) {
                            updateSetting.BackgroundBadgeId = params.BackgroundBadgeId;
                        }
                        EntityCache.RecognitionTemplate.findOneAndUpdate(
                            {hgId: TemplateRequest.hgId},
                            {$set: updateSetting},
                            {new: true},
                            function (err, newdoc) {
                                var sendResponse = function () {
                                        callback(null, TemplateDto.get([newdoc])[0]);
                                    };
                                if (err) {
                                    callback(err);
                                } else if (!newdoc) {
                                    callback('bisnes.rtp.rtl');
                                } else {
                                    if (TemplateRequest.Category === 'Values' && params.BadgeId) {
                                        if (recognitionTemplateModified || templateColorsModified) {
                                            createImagesForValueLevels({
                                                BadgeId: params.BadgeId,
                                                FriendlyGroupId: TemplateRequest.FriendlyGroupId,
                                                ImageId: TemplateRequest.hgId,
                                                Group: group,
                                                ForegroundFillColor: TemplateRequest.IconPickerColor || '',
                                                BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                            });
                                        }
                                    }
                                    if (params.BadgeId) {
                                        if (!TemplateRequest.BackgroundBadgeId) {
                                            FileHelper.CopyBadgeImage({
                                                BadgeId: params.BadgeId,
                                                FriendlyGroupId: TemplateRequest.FriendlyGroupId,
                                                TemplateId: TemplateRequest.hgId,
                                                Callback: sendResponse
                                            });
                                        } else {
                                            if (recognitionTemplateModified || templateColorsModified) {
                                                createBadgeWithBackground({
                                                    BadgeId: params.BadgeId,
                                                    BackgroundBadgeId: params.BackgroundBadgeId,
                                                    FriendlyGroupId: TemplateRequest.FriendlyGroupId,
                                                    TemplateId: TemplateRequest.hgId,
                                                    Callback: sendResponse,
                                                    ForegroundFillColor: TemplateRequest.IconPickerColor || '',
                                                    BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                                });
                                            } else {
                                                sendResponse();
                                            }
                                        }
                                    } else {
                                        sendResponse();
                                    }
                                    // clear out cache
                                    HgCache.GlobalDelete(crytoHelper.md5(config.s3store.imageStore[0] + '/badges/group/' + TemplateRequest.FriendlyGroupId + '/' + TemplateRequest.hgId + '.svg'), function (err) {
                                        if (err) {
                                            HgLog.info('*** Ubale to delete value from redis: ' + err.toString() + ' ***');
                                            callback();
                                        }
                                    });
                                }
                            }
                        );
                    } else {//new template
                        recognitionTemplate = new EntityCache.RecognitionTemplate(TemplateRequest);
                        recognitionTemplate.ForegroundFilename = foregroundFilename;
                        recognitionTemplate.BackgroundFilename = backgroundFilename;
                        recognitionTemplate.hgId = guid.v1();
                        recognitionTemplate.CreatedBy = userId;
                        recognitionTemplate.ModifiedBy = userId;
                        recognitionTemplate.GroupId = params.GroupId;
                        recognitionTemplate.GroupName = group.GroupName;
                        recognitionTemplate.FriendlyGroupId = group.FriendlyGroupId;

                        for (i = 0; i < TemplateRequest.SubValues.length; i += 1) {
                            if (!TemplateRequest.SubValues[i].BadgeId) {
                                return callback('bisnes.rtp.yms');
                            }
                            subValue = {
                                Name: TemplateRequest.SubValues[i].Name,
                                Description: TemplateRequest.SubValues[i].Description,
                                IconPickerColor: TemplateRequest.SubValues[i].IconPickerColor,
                                ImageId: guid.v1(),
                                BadgeId: TemplateRequest.SubValues[i].BadgeId
                            };
                            subValues.push(subValue);

                            FileHelper.CopyBadgeImage({
                                BadgeId: TemplateRequest.SubValues[i].BadgeId,
                                FriendlyGroupId: group.FriendlyGroupId,
                                TemplateId: subValue.ImageId
                            });
                            createImagesForValueLevels({
                                BadgeId: TemplateRequest.SubValues[i].BadgeId,
                                FriendlyGroupId: TemplateRequest.FriendlyGroupId,
                                ImageId: subValue.ImageId,
                                Group: group,
                                ForegroundFillColor: TemplateRequest.SubValues[i].IconPickerColor || '',
                                BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                            });

                            if (recognitionTemplate.BackgroundFilename) {
                                createBadgeWithBackground({
                                    BadgeId: TemplateRequest.SubValues[i].BadgeId,
                                    BackgroundBadgeId: params.BackgroundBadgeId,
                                    FriendlyGroupId: group.FriendlyGroupId,
                                    TemplateId: recognitionTemplate.hgId,
                                    CompositeFilename: subValue.ImageId + '_' + params.BackgroundBadgeId + '.svg',
                                    ForegroundFillColor: TemplateRequest.SubValues[i].IconPickerColor || '',
                                    BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                });
                            }
                        }
                        recognitionTemplate.SubValues = subValues;
                        if (params.RestrictUsers && params.RestrictUsers.length) {
                            recognitionTemplate.RestrictUsers = params.RestrictUsers;
                        }
                        recognitionTemplate.RestrictDepartments = params.RestrictDepartments || [];
                        recognitionTemplate.save(function (saveErr, newdoc) {
                            var sendResponse = function () {
                                callback(null, TemplateDto.get([newdoc])[0]);
                            };
                            if (saveErr) {
                                return callback(saveErr);
                            }
                            if (TemplateRequest.Category === 'Values' && TemplateRequest.SubValues.length < 1) {
                                createImagesForValueLevels({
                                    BadgeId: params.BadgeId,
                                    FriendlyGroupId: group.FriendlyGroupId,
                                    ImageId: recognitionTemplate.hgId,
                                    Group: group,
                                    ForegroundFillColor: TemplateRequest.IconPickerColor || '',
                                    BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                });
                            }
                            //copy badge image without background without Sub Values
                            if (!TemplateRequest.BackgroundBadgeId && TemplateRequest.SubValues.length < 1) {
                                FileHelper.CopyBadgeImage({
                                    BadgeId: params.BadgeId,
                                    FriendlyGroupId: group.FriendlyGroupId,
                                    TemplateId: recognitionTemplate.hgId,
                                    Callback: sendResponse
                                });
                            //neither BadgeId and BackgroudId are sent without Sub Values, then create badge with background as default icon
                            } else if (TemplateRequest.BadgeId && TemplateRequest.SubValues.length < 1) {
                                createBadgeWithBackground({
                                    BadgeId: params.BadgeId,
                                    BackgroundBadgeId: params.BackgroundBadgeId,
                                    FriendlyGroupId: group.FriendlyGroupId,
                                    TemplateId: recognitionTemplate.hgId,
                                    Callback: sendResponse,
                                    ForegroundFillColor: TemplateRequest.IconPickerColor || '',
                                    BackgroundFillColor: TemplateRequest.BkgdPickerColor || ''
                                });
                            } else if (TemplateRequest.SubValues.length >= 1) {
                                sendResponse();
                            } else {
                                callback("bisnes.rtp.rtr");
                            }
                        });
                    }
                });
            });
        };

        this.GetTemplateById = function (params) {
            EntityCache.RecognitionTemplate.findOne({hgId: params.TemplateId}).exec(function (err, template) {
                if (err) {
                    EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData, new EventData(params.correlationId, 'Error loading template'));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, template));
                }
            });
        };
        this.GetTemplateByIdEventCallback = function (params, callback) {
            EntityCache.RecognitionTemplate.findOne({hgId: params.TemplateId}).exec(function (err, template) {
                callback(err, template);
            });
        };
        this.GetTemplatesByCategory = function (params, callback) {
            var regex = params.SearchTerm ? new RegExp(params.SearchTerm.replace(/([.*?=+&#!:${}()|\[\]\/\\\^\+])/g, "\\$1"), "i") : '';
            EntityCache.Team.find({
                'TeamMembers.MemberId': params.MemberId,
                Status: 'Active'
            }, {
                hgId: true
            }, {
                lean: true
            }, function (err, teams) {
                var groupId = params.GroupId,
                    query,
                    i,
                    len,
                    teamIds = [];
                if (err) {
                    if (callback) {
                        callback('bisnes.rtp.elt', null);
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'Error loading teams');
                    }
                } else {
                    for (i = 0, len = teams.length; i < len; i += 1) {
                        teamIds.push(teams[i].hgId);
                    }
                    if (params.Manage === 'true' || params.Manage === true) {
                        query = {GroupId: groupId, Category: params.Category, DefaultGivenToNewMembers: false};
                    } else {
                        if (params.Category === "Achievement") {
                            query = {
                                GroupId: groupId,
                                Category: params.Category,
                                DefaultGivenToNewMembers: false,
                                $or: [
                                    {'RestrictUsers.TeamIds': {$in: teamIds}},
                                    {'RestrictUsers.MemberIds': params.MemberId },
                                    {'RestrictUsers.Roles': params.Role},
                                    {AccessLevel: 'WithinGroup'}
                                ]
                            };
                        } else {
                            query = {GroupId: groupId, Category: params.Category, DefaultGivenToNewMembers: false, $or: [{TeamId: {$in: teamIds}}, {AccessLevel: 'WithinGroup'}, {CreatedBy: params.UserId}]};
                        }
                        if (params.privateOnly) {
                            query.Publicity = {$in: ['Private', 'Both']};
                        }
                    }
                    if (regex) {
                        query.Title = regex;
                    }
                    EntityCache.RecognitionTemplate.find(query).sort({CreatedDate: -1})
                        .skip(parseInt(params.Skip, 10) || 0)
                        .limit(parseInt(params.Take, 10) || 0).exec(function (err, templates) {
                            callback(err, templates.map(function (item) { return item.toJSON(); }));
                        });
                }
            });
        };
        this.GetTemplates = function (params) {
            EntityCache.Team.find({
                'TeamMembers.MemberId': params.MemberId,
                Status: 'Active'
            }, {
                hgId: true
            }, {
                lean: true
            }, function (err, teams) {
                var groupId = params.GroupId,
                    Types = params.Types,
                    query,
                    i,
                    len,
                    teamIds = [];
                if (err) {
                    EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData, new EventData(params.correlationId, 'Error loading teams'));
                } else {
                    for (i = 0, len = teams.length; i < len; i += 1) {
                        teamIds.push(teams[i].hgId);
                    }
                    if (Types) {
                        query = {GroupId: groupId, DefaultGivenToNewMembers: false, Type: {$in: Types}, $or: [{TeamId: {$in: teamIds}}, {AccessLevel: 'WithinGroup'}, {CreatedBy: params.UserId}]};
                    } else {
                        query = {GroupId: groupId, DefaultGivenToNewMembers: false, $or: [{TeamId: {$in: teamIds}}, {AccessLevel: 'WithinGroup'}, {CreatedBy: params.UserId}]};
                    }
                    if (params.privateOnly) {
                        query.Publicity = {$in: ['Private', 'Both']};
                    }
                    EntityCache.RecognitionTemplate.find(query)
                        .skip(parseInt(params.Skip, 10) || 0)
                        .limit(parseInt(params.Take, 10) || 0).exec(function (err, templates) {
                            if (err) {
                                EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData, new EventData(params.correlationId, 'Error loading templates'));
                            } else {
                                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, templates));
                            }
                        });
                }
            });
        };

        this.GetPublicTemplatesForMember = function (params) {
            EntityCache.Member.findOne({hgId: params.MemberId}, function (err, member) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.RecognitionTemplate.ErrorLoadingMember));
                } else if (!member) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.RecognitionTemplate.MemberDoesNotExist));
                } else {
                    EntityCache.RecognitionTemplate.find({GroupId: member.GroupId, Publicity: {$in: ['Both', 'Public']}, Type: {$in: params.Types}}, function (err, templates) {
                        if (err) {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.RecognitionTemplate.ErrorLoadingTemplates));
                        } else {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, templates));
                        }
                    });
                }
            });
        };

        this.GetTemplatesByIds = function (params) {
            EntityCache.RecognitionTemplate.find({hgId: {$in: params.TemplateIds}}).exec(function (err, templates) {
                if (err) {
                    EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData, new EventData(params.correlationId, HgError.Enums.RecognitionTemplate.ErrorLoadingTemplates));
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, templates));
                }
            });
        };

        this.GetSingleTemplateById = function (id, callback) {
            if (!id) {
                callback('Template id is null');
            } else {
                EntityCache.RecognitionTemplate.findOne({hgId: id}, function (err, template) {
                    if (err) {
                        callback(HgError.Enums.RecognitionTemplate.ErrorLoadingTemplates);
                    } else {
                        callback(null, template);
                    }
                });
            }
        };

        this.BuildCustomizedRecognitionTemplate = function (params, callback) {
            var backgroundParam, recognitionTemplate = new EntityCache.RecognitionTemplate(params);
            recognitionTemplate.hgId = guid.v1();
            recognitionTemplate.CreatedBy = params.UserId;
            recognitionTemplate.ModifiedBy = params.UserId;
            recognitionTemplate.Title = params.Title;
            if (!params.BackgroundBadgeId) {
                FileHelper.CopyBadgeImage({
                    BadgeId: params.BadgeId,
                    FriendlyGroupId: params.FriendlyGroupId,
                    TemplateId: recognitionTemplate.hgId
                });
            } else {
                backgroundParam = {
                    BadgeId: params.BadgeId,
                    BackgroundBadgeId: params.BackgroundBadgeId,
                    FriendlyGroupId: params.FriendlyGroupId,
                    TemplateId: recognitionTemplate.hgId
                };
                createBadgeWithBackground(backgroundParam);
            }
            callback(null, recognitionTemplate);
        };
        this.SaveSystemTemplate = function (params, callback) {
            var recognitionTemplate = new EntityCache.RecognitionTemplate(params.TemplateRequest),
                backgroundParam;
            recognitionTemplate.hgId = guid.v1();
            recognitionTemplate.CreatedBy = params.UserId;
            recognitionTemplate.GroupId = params.GroupId;
            recognitionTemplate.GroupName = params.GroupName;
            recognitionTemplate.FriendlyGroupId = params.FriendlyGroupId;
            recognitionTemplate.save(function (error, template) {
                if (error) {
                    return callback(error);
                }
                backgroundParam = {
                    BadgeId: recognitionTemplate.BadgeId,
                    BackgroundBadgeId: recognitionTemplate.BackgroundBadgeId,
                    FriendlyGroupId: recognitionTemplate.FriendlyGroupId,
                    TemplateId: recognitionTemplate.hgId
                };
                createBadgeWithBackground(backgroundParam);
                callback(null, template);
            });
        };
        this.UpdateSystemTemplate = function (params, callback) {
            var template = params.TemplateRequest;
            EntityCache.RecognitionTemplate.update({
                hgId: template.hgId
            }, {
                $set: {
                    Title: template.Title,
                    Message: template.Message,
                    Description: template.Description || '',
                    CreditValue: template.CreditValue || 0,
                    PointValue: template.PointValue || 0,
                    BadgeId: template.BadgeId,
                    ForegroundFilename: template.ForegroundFilename,
                    BackgroundBadgeId: template.BackgroundBadgeId,
                    BackgroundFilename: template.BackgroundFilename,
                    ModifiedBy: params.UserId,
                    TranslatedValues: template.TranslatedValues || [],
                    ModifiedDate: Date.now()
                }
            }, {
                upsert: false
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                createBadgeWithBackground({
                    BadgeId: template.BadgeId,
                    BackgroundBadgeId: template.BackgroundBadgeId,
                    FriendlyGroupId: template.FriendlyGroupId,
                    TemplateId: template.hgId
                });
                callback(null, data);
            });
        };
        this.CreateOrUpdateTemplateProvion = function (params) {
            var TemplateRequest = params.TemplateRequest,
                subValues = [],
                levels = [],
                level,
                i,
                userId = params.UserId,
                subValue,
                group = params.Group,
                callback = params.Callback;
            if (!TemplateRequest.SubValues) {
                TemplateRequest.SubValues = [];
            }
            EntityCache.RecognitionTemplate.findOne({Title: TemplateRequest.Title}, function (err, recognitionTemplate) {
                if (err) {
                    callback(err);
                    return;
                }
                if (recognitionTemplate && recognitionTemplate.Title) {
                    HgLog.debug('recognitionTemplate exists');
                    callback(null);
                    return;
                }
                recognitionTemplate = new EntityCache.RecognitionTemplate(params.TemplateRequest);
                recognitionTemplate.hgId = guid.v1();
                recognitionTemplate.CreatedBy = userId;
                recognitionTemplate.ModifiedBy = userId;
                recognitionTemplate.GroupId = params.GroupId;
                if (TemplateRequest.SubValueNames) {
                    for (i = 0; i < TemplateRequest.SubValueNames.length; i += 1) {
                        subValue = {
                            Name: TemplateRequest.SubValueNames[i],
                            ImageId: guid.v1()
                        };
                        subValues.push(subValue);
                        FileHelper.CopyImageFromOriginalFolder({
                            ImageFilename: TemplateRequest.SubValueImageFilenames[i],
                            FriendlyGroupId: group.FriendlyGroupId,
                            TemplateId: subValue.ImageId
                        });
                    }
                }
                if (TemplateRequest.LevelNames) {
                    for (i = 0; i < TemplateRequest.LevelNames.length; i += 1) {
                        level = {
                            Name: TemplateRequest.LevelNames[i],
                            PointValue: TemplateRequest.LevelPoints[i],
                            CreditValue: TemplateRequest.LevelCredits[i]
                        };
                        levels.push(level);
                    }
                }
                recognitionTemplate.Levels = levels;
                recognitionTemplate.SubValues = subValues;
                recognitionTemplate.GroupName = group.GroupName;
                recognitionTemplate.FriendlyGroupId = group.FriendlyGroupId;
                recognitionTemplate.save(function (saveErr) {
                    if (!saveErr) {
                        FileHelper.CopyImageFromOriginalFolder({
                            ImageFilename: TemplateRequest.BadgeFilename,
                            FriendlyGroupId: group.FriendlyGroupId,
                            TemplateId: recognitionTemplate.hgId
                        });
                        callback(null, recognitionTemplate);
                    } else {
                        callback(saveErr);
                    }
                });
            });
        };

        this.UpdateComplete = function (params) {
            var TemplateRequest = params.TemplateRequest;
            EntityCache.RecognitionTemplate.update(
                {hgId: TemplateRequest.hgId},
                {$set: {
                    Title: TemplateRequest.Title,
                    Description: TemplateRequest.Description,
                    CreditValue: TemplateRequest.CreditValue,
                    PointValue: TemplateRequest.PointValue,
                    Type: TemplateRequest.Type,
                    Category: TemplateRequest.Category,
                    AccessLevel: TemplateRequest.AccessLevel,
                    Publicity: TemplateRequest.Publicity,
                    DefaultGivenToNewMembers: TemplateRequest.DefaultGivenToNewMembers,
                    Tags: TemplateRequest.Tags,
                    ModifiedBy: params.UserId,
                    TeamId: TemplateRequest.TeamId || '',
                    DepartmentName: TemplateRequest.DepartmentName || '',
                    ModifiedDate: Date.now()
                }},
                {upsert: false},
                function (err) {
                    if (err) {
                        HgLog.error({methodName: 'UpdateComplete', error: err});
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.RecognitionTemplate.ErrorUpdating));
                    } else {
                        if (params.BadgeId) {
                            FileHelper.CopyBadgeImage({
                                BadgeId: params.BadgeId,
                                FriendlyGroupId: TemplateRequest.FriendlyGroupId,
                                TemplateId: TemplateRequest.hgId
                            });
                        }
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'update template complete'));
                    }
                }
            );
        };

        this.CreateTemplate = function (params) {
            var userId = params.UserId,
                recognitionTemplate = EntityCache.RecognitionTemplate(params.TemplateRequest);
            recognitionTemplate.hgId = guid.v1();
            recognitionTemplate.CreatedBy = userId;
            recognitionTemplate.ModifiedBy = userId;
            recognitionTemplate.GroupId = params.GroupId;
            recognitionTemplate.IsPublic = (params.TemplateRequest.IsPublic === 'true' || params.TemplateRequest.IsPublic === true);
            if (recognitionTemplate.IsPublic && recognitionTemplate.CreditValue > 0) {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'Public recognitionTemplate can only have 0 Credit Value'));
            } else if ((recognitionTemplate.Type === 'Thanks' || recognitionTemplate.Type === 'Congrats' || recognitionTemplate.Type === 'Quick')  && recognitionTemplate.CreditValue > 0) {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'Thanks, Congrats, Quick recognitionTemplate can only have 0 Credit Value'));
            } else {
                EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                    if (err) {
                        EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData, new EventData(params.correlationId, 'Error loading group'));
                    } else {
                        recognitionTemplate.GroupName = group.GroupName;
                        recognitionTemplate.FriendlyGroupId = group.FriendlyGroupId;
                        if (recognitionTemplate.CreditValue > 0 && (recognitionTemplate.CreditValue < group.CreditSetting.MinRecognition || recognitionTemplate.CreditValue > group.CreditSetting.MaxRecognition)) {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'The template credit value should be between ' + group.CreditSetting.MinRecognition + ' and ' + group.CreditSetting.MaxRecognition));
                        } else if (recognitionTemplate.PointValue > 0 && (recognitionTemplate.PointValue < group.PointSetting.MinPoints || recognitionTemplate.PointValue > group.PointSetting.MaxPoints)) {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'The template experience value should be between ' + group.PointSetting.MinPoints + ' and ' + group.PointSetting.MaxPoints));
                        } else {
                            recognitionTemplate.save(function (saveErr, template) {
                                if (!saveErr) {
                                    PusherManager.RecognitionTemplateCreated({
                                        correlationId: params.correlationId,
                                        GroupId: params.GroupId,
                                        UserId: userId,
                                        Template: recognitionTemplate
                                    });
                                    FileHelper.CopyBadgeImage({
                                        BadgeId: params.BadgeId,
                                        FriendlyGroupId: group.FriendlyGroupId,
                                        TemplateId: recognitionTemplate.hgId
                                    });
                                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, recognitionTemplate));
                                } else {
                                    HgLog.error({methodName: 'CreateTemplate', error: saveErr});
                                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'Saving template failed'));
                                }
                            });
                        }
                    }
                });
            }
        };

        this.GetRecognitionMessageTemplates = function (params) {
            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, RecognitionMessageTemplates));
        };

        this.GetRecognitionTemplatesByGroupId = function (params, callback) {
            EntityCache.RecognitionTemplate.find({GroupId: params.GroupId}, function (err, recognitionTemplates) {
                if (!err) {
                    callback(null, recognitionTemplates);
                } else {
                    callback(err);
                }
            });
        };
        this.GetGroupTemplateCount = function (params, callback) {
            var search = {
                GroupId: params.GroupId,
                Category: params.Category,
                DefaultGivenToNewMembers: false,
                $or: [
                    {TeamId: {$in: [params.TeamId, '']}, DepartmentName: {$nin: ['--All Departments--', '']}},
                    {TeamId: { $exists: false }, DepartmentName: {$nin: ['--All Departments--', '']}}
                ]
            };
            EntityCache.RecognitionTemplate.aggregate([
                {
                    $match: search
                }, {
                    $group: {
                        _id: null,
                        Count: {
                            $sum: 1
                        }
                    }
                }
            ]).exec(function (err, data) {
                callback(err, data);
            });
        };
        this.GetAllTemplatesByCategory = function (params, callback) {
            params.TeamId = params.TeamId || '';
            params.SubCategory = params.SubCategory || '';

            EntityCache.RecognitionTemplate.find({
                GroupId: params.GroupId,
                Category: params.Category,
                SubCategory: params.SubCategory,
                DefaultGivenToNewMembers: false,
                $or: [
                    {TeamId: {$in: [params.TeamId, '']}},
                    {TeamId: { $exists: false }}
                ]
            }, function (err, templates) {
                callback(err, templates);
            });
        };
        this.GetCurrentGroupDefaultBadges = function (params, callback) {
            EntityCache.RecognitionTemplate.find({
                GroupId: params.GroupId,
                DefaultBadge: true
            }, callback);
        };
        this.SaveSystemBadge = function (params, callback) {
            EntityCache.RecognitionTemplate.findOne({
                hgId: params.Badge.Id,
                GroupId: params.GroupId
            }, function (error, template) {
                if (error) {
                    HgLog.error({methodName: 'SaveSystemBadge', error: error});
                    return callback(error);
                }
                if (!template) {
                    template = new EntityCache.RecognitionTemplate(params.Badge);
                    template.hgId = params.Badge.Id;
                }
                if (params.Badge.Type === RecognitionEnums.TemplateType.Anniversary) {
                    template.Type = RecognitionEnums.TemplateType.Anniversary;
                }
                template.Title = params.Badge.Title;
                template.Message = params.Badge.Message;
                template.ForegroundBadgeId = params.Badge.ForegroundBadgeId;
                template.ForegroundFilename = params.Badge.ForegroundFilename;
                template.BackgroundBadgeId = params.Badge.BackgroundBadgeId;
                template.BackgroundFilename = params.Badge.BackgroundFilename;
                template.ModifiedBy = params.UserId;
                template.DefaultBadge = true;
                template.Category = RecognitionEnums.RecognitionCategory.System;
                template.save(callback);
            });
        };
        this.GetSystemBadgeTemplate = function (params, callback) {
            EntityCache.RecognitionTemplate.findOne({
                GroupId: params.GroupId,
                Type: params.Type,
                Category: RecognitionEnums.RecognitionCategory.System,
                DefaultBadge: true
            }, callback);
        };
    };
module.exports = RecognitionTemplateProcessor;
