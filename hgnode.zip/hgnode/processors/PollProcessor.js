/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    Poll = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            PollEnums = require('../enums/PollEnums.js'),
            Async = require('async'),
            uuid = require('node-uuid'),
            self = this;

        this.CreatePollQuestion = function (params, callback) {
            var pollQuestion = new EntityCache.PollQuestion({
                hgId: uuid.v1(),
                GroupId: params.GroupId,
                CreatedBy: params.UserId,
                ModifiedBy: params.UserId,
                CreatedDate: Date.now(),
                StartDate: params.StartDate,
                EndDate: params.EndDate,
                Question: params.Question,
                Description: params.Description,
                AnswerOptions: params.AnswerOptions,
                Participants: params.Participants
            });
            pollQuestion.save(callback);
        };
        this.CreatePolls = function (params, callback) {
            EntityCache.Poll.create(params, callback);
        };
        this.GetPollQuestionByCreatorCount = function (params, callback) {
            EntityCache.PollQuestion.count({
                GroupId: params.GroupId,
                CreatedBy: params.UserId,
                Status: { $in: params.Status}
            }, callback);
        };
        this.GetPollByCreatorId = function (params, callback) {
            EntityCache.PollQuestion.find({
                GroupId: params.GroupId,
                CreatedBy: params.UserId,
                Status: params.Status
            }, callback);
        };
        this.GetPollQuestionsByIds = function (params, callback) {
            EntityCache.PollQuestion.find({
                GroupId: params.GroupId,
                hgId: { $in: params.PollQuestionIds},
                Status: params.Status
            }, callback);
        };
        this.GetPollQuestionById = function (params, callback) {
            EntityCache.PollQuestion.findOne({hgId: params.PollQuestionId}, callback);
        };
        this.GetPollById = function (params, callback) {
            EntityCache.Poll.findOne({hgId: params.PollId}, callback);
        };
        this.GetPollsByMemberId = function (params, callback) {
            EntityCache.Poll.find({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                Status: {$in: [PollEnums.QuestionStatus.Pending, PollEnums.QuestionStatus.Completed]},
                ExpireDate: {$gte: Date.now()}
            }, callback);
        };
        this.GetAnsweredPollParticipant = function (params, callback) {
            EntityCache.Poll.find({
                PollQuestionId: params.PollQuestionId,
                Status: PollEnums.QuestionStatus.Completed
            }, callback);
        };
        this.GetPollResultById = function (params, callback) {
            Async.parallel({
                pollQuestion: function (fcallback) {
                    self.GetPollQuestionById({PollQuestionId: params.PollQuestionId}, fcallback);
                },
                pollResult: function (fcallback) {
                    EntityCache.Poll.aggregate([
                        {$match: {
                            PollQuestionId: params.PollQuestionId,
                            Status: PollEnums.QuestionStatus.Completed
                        }},
                        {$group: {
                            _id: "$AnswerValue",
                            Total: {$sum: 1}
                        }}
                    ], fcallback);
                }
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                var resultId = {},
                    votes = {
                        PollQuestionId: params.PollQuestionId,
                        ParticipantsCount: data.pollQuestion.ParticipantsCount,
                        result: []
                    };
                data.pollResult.forEach(function (item) {
                    resultId[item._id] = item.Total;
                });
                data.pollQuestion.AnswerOptions.forEach(function (item) {
                    votes.result.push({
                        Text: item.Text,
                        Vote: parseInt(resultId[item.Value] || 0, 10)
                    });
                });
                votes.OutstandingVotes = data.pollQuestion.ParticipantsCount - votes.result.reduce(function (itemA, itemB) {
                    return itemA + itemB.Vote;
                }, 0);
                return callback(null, votes);
            });
        };
        this.UpdateStatus = function (params, callback) {
            var update = {
                Status: params.Status
            };
            if (params.ParticipantsCount) {
                update.ParticipantsCount = params.ParticipantsCount;
            }
            EntityCache.PollQuestion.update({
                hgId: params.PollQuestionId
            }, {
                $set: update
            }, callback);
        };
        this.SubmitPoll = function (params, callback) {
            EntityCache.Poll.update({
                hgId: params.PollId
            }, {
                $set: {
                    AnswerValue: params.AnswerValue,
                    Status: PollEnums.QuestionStatus.Completed,
                    CompletedDate: Date.now()
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                self.GetPollResultById(params, callback);
            });
        };
    };

module.exports = Poll;
