/*jslint node:true es5:true*/
"use strict";
var PDFConstants = require('../pdfGenerators/PDFConstants.js'),
    i18nHelper = require('../../helpers/i18nHelper.js'),
    PDFHelper = require('./PDFHelper.js'),
    DateHelper = require('../../util/DateHelper.js'),
    FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    Lang,
    TZ;

function cycleHeader(doc, name) {
    PDFHelper.nextLine(doc, 10);
    doc
        .font(PDFConstants.Font.OpenSansSemibold)
        .fontSize(PDFConstants.FontSize.Medium)
        .fill(PDFConstants.Color.HeaderText)
        .text(name, PDFConstants.Size.MarginLeft, doc.y, {width: 540});
    PDFHelper.nextLine(doc, 5);
    doc
        .lineWidth(2)
        .moveTo(PDFConstants.Size.MarginLeft, doc.y)
        .lineTo(576, doc.y)
        .stroke(PDFConstants.Color.Underline);
    doc.lineWidth(1);
    PDFHelper.nextLine(doc, 5);
}
function requestedBy(doc, session, participant, userAvatarBuffers) {
    PDFHelper.nextLine(doc, 10);
    var docY = doc.y;
    PDFHelper.generateAvatar(doc, participant.UserId, userAvatarBuffers, PDFConstants.Size.CommentImage);
    doc
        .fontSize(PDFConstants.FontSize.Small)
        .font(PDFConstants.Font.OpenSansSemibold)
        .fill(PDFConstants.Color.Black)
        .text(i18nHelper.translate(Lang, (session.CycleType === FeedbackEnums.CycleType.Give ? 'pdf.stb' : 'pdf.rcb'), {name: participant.FullName}), PDFConstants.Size.MarginComment, docY, {width: PDFConstants.Size.LabelWidth});
    doc
        .text(DateHelper.formatDateStringFromTimestamp(session.CreatedDate - TZ), PDFConstants.Size.MarginComment, docY, {
            width: PDFConstants.Size.LabelWidth,
            align: 'right'
        });
    PDFHelper.nextLine(doc, 3);
    doc
        .fontSize(PDFConstants.FontSize.Small)
        .font(PDFConstants.Font.OpenSansRegular)
        .text(session.RequestNote, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
    PDFHelper.nextLine(doc, 15);
    doc
        .moveTo(PDFConstants.Size.MarginLeft, doc.y)
        .dash(2)
        .lineTo(576, doc.y)
        .stroke(PDFConstants.Color.Underline).undash();
    PDFHelper.nextLine(doc, 5);
}
function responseBy(doc, participant, userAvatarBuffers) {
    PDFHelper.nextLine(doc, 10);
    var docY = doc.y;
    PDFHelper.generateAvatar(doc, participant.UserId, userAvatarBuffers, PDFConstants.Size.CommentImage);
    doc
        .fontSize(PDFConstants.FontSize.Small)
        .font(PDFConstants.Font.OpenSansSemibold)
        .fill(PDFConstants.Color.Black)
        .text(i18nHelper.translate(Lang, 'pdf.pb', {name: participant.FullName}), PDFConstants.Size.MarginComment, docY, {width: PDFConstants.Size.LabelWidth});
    doc
        .text(DateHelper.formatDateStringFromTimestamp(participant.SubmittedDate - TZ), PDFConstants.Size.MarginComment, docY, {
            width: PDFConstants.Size.LabelWidth,
            align: 'right'
        });
    PDFHelper.nextLine(doc, 30);
}
function noteFrom(doc, session, participant, userAvatarBuffers) {
    PDFHelper.nextLine(doc, 10);
    var docY = doc.y;
    PDFHelper.generateAvatar(doc, participant.UserId, userAvatarBuffers, PDFConstants.Size.CommentImage);
    doc
        .fontSize(PDFConstants.FontSize.Small)
        .font(PDFConstants.Font.OpenSansSemibold)
        .text(i18nHelper.translate(Lang, 'pdf.nfr', {name: participant.FullName}), PDFConstants.Size.MarginComment, docY, {width: PDFConstants.Size.LabelWidth});
    PDFHelper.nextLine(doc, 3);
    doc
        .fontSize(PDFConstants.FontSize.Small)
        .font(PDFConstants.Font.OpenSansRegular)
        .text(session.RatingNote, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
    PDFHelper.nextLine(doc, 30);
}
function RenderAnswer(doc, question) {
    doc
        .font(PDFConstants.Font.OpenSansBold)
        .fontSize(PDFConstants.FontSize.Small)
        .fill(PDFConstants.Color.Black)
        .text(question.Question, PDFConstants.Size.MarginQuestion, doc.y, {width: PDFConstants.Size.LabelWidth});
    PDFHelper.nextLine(doc, 10);

    this.ShortAnswer = function (answer) {
        if (!answer.Text) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        doc
            .fontSize(PDFConstants.FontSize.Small)
            .fill(PDFConstants.Color.RegularText)
            .font(PDFConstants.Font.OpenSansRegular)
            .text(answer.Text, PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 20);
    };
    this.RadioButton = function (answer) {
        var selection = answer.SelectedValues && answer.SelectedValues.length && question.AnswerSelector.find(function (selected) {
            return selected.Value === answer.SelectedValues[0];
        });
        if (!selection) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        PDFHelper.nextLine(doc, 3);
        doc.circle(PDFConstants.Size.MarginLeftHeader, doc.y + 8, 8).fill(PDFConstants.Color.HeaderText);
        doc
            .fontSize(PDFConstants.FontSize.Small)
            .fill(PDFConstants.Color.RegularText)
            .font(PDFConstants.Font.OpenSansRegular)
            .text(selection.Text, PDFConstants.Size.MarginAnswer + 27, doc.y, {
                width: PDFConstants.Size.LabelWidth,
                align: 'left'
            });
        PDFHelper.nextLine(doc, 20);
    };
    this.RatingScale = function (answer) {
        var selection, docY;
        if (!answer.SelectedValues || !answer.SelectedValues.length) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        question.AnswerSelector.forEach(function (selector, index) {
            selection = answer.SelectedValues.find(function (selectedAnswer) {
                return selector.Value === selectedAnswer;
            });
            docY = doc.y;
            doc
                .circle(PDFConstants.Size.MarginLeftHeader, doc.y + 8, 8)
                .fillAndStroke(
                    selection === undefined ? PDFConstants.Color.White : PDFConstants.Color.HeaderText,
                    selection === undefined ? PDFConstants.Color.RegularText : PDFConstants.Color.HeaderText
                );
            doc
                .fontSize(PDFConstants.FontSize.Xsmall)
                .fill(selection !== undefined ? PDFConstants.Color.White : PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'feedback.asw.' + 'a' + index), PDFConstants.Size.MarginAnswer + 4, doc.y + 2, {
                    width: 20,
                    align: 'center'
                });
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(selection !== undefined ? PDFConstants.Color.HeaderText : PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(selector.Text, PDFConstants.Size.MarginAnswer + 27, docY, {
                    width: PDFConstants.Size.LabelWidth,
                    align: 'left'
                });
            PDFHelper.nextLine(doc, 10);
        });
        PDFHelper.nextLine(doc, 5);
    };
    this.CheckBox = function (answer) {
        var selection;
        if (!answer.SelectedValues || !answer.SelectedValues.length) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        answer.SelectedValues.forEach(function (selectedAnswer) {
            selection = question.AnswerSelector.find(function (selected) {
                return selected.Value === selectedAnswer;
            });
            doc.circle(PDFConstants.Size.MarginLeftHeader, doc.y + 8, 8).fill(PDFConstants.Color.HeaderText);
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(selection.Text, PDFConstants.Size.MarginAnswer + 27, doc.y, {
                    width: PDFConstants.Size.LabelWidth,
                    align: 'left'
                });
            PDFHelper.nextLine(doc, 10);
        });
        PDFHelper.nextLine(doc, 5);
    };
}
function GeneratePdf(doc, sessions, lang, tz, userAvatarBuffers, callback) {
    var subject, reviewer, answerFactory;
    Lang = lang;
    TZ = tz;
    sessions.forEach(function (session) {
        session.Participants.forEach(function (p) {
            if ([FeedbackEnums.SessionParticipantType.Subject,
                    FeedbackEnums.SessionParticipantType.Requester].indexOf(p.ParticipantType) !== -1) {
                subject = p;
            }
            if (p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer) {
                reviewer = p;
            }
        });

        cycleHeader(doc, session.CycleTitle);
        requestedBy(doc, session, (session.CycleType === FeedbackEnums.CycleType.Give ? reviewer : subject), userAvatarBuffers);
        if (session.CycleType !== FeedbackEnums.CycleType.Give) {
            responseBy(doc, reviewer, userAvatarBuffers);
        }

        session.Card.Sections.forEach(function (section) {
            if (section.Title) {
                doc
                    .fontSize(PDFConstants.FontSize.Small)
                    .font(PDFConstants.Font.OpenSansBold)
                    .fill(PDFConstants.Color.HeaderText)
                    .text(section.Title, PDFConstants.Size.MarginLeft, doc.y, {width: PDFConstants.Size.LabelWidth});
            }
            PDFHelper.nextLine(doc, 5);
            section.Questions.forEach(function (question) {
                answerFactory = new RenderAnswer(doc, question);
                question.Answers.forEach(function (answer) {
                    answerFactory[question.Type](answer);
                });
            });
        });

        if (session.RatingNote) {
            noteFrom(doc, session, subject, userAvatarBuffers);
        }
    });
    callback();
}

module.exports = {
    GeneratePdf: GeneratePdf
};