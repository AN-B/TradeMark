/*jslint node:true es5:true regexp: true*/
"use strict";
var fs = require('fs'),
    parseXml = require('xml2js').parseString,
    processElement = require('../../util/SvgHelper.js'),
    HgLog = require('../../framework/HgLog'),
    isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
    parseXml = require('xml2js').parseString,
    htmlToText = require('html-to-text'),
    Async = require('async'),
    https = require('https'),
    config = require('../../configurations/config.js'),
    i18nHelper = require('../../helpers/i18nHelper.js'),
    PDFConstants = require('../pdfGenerators/PDFConstants.js');

function createArch(PDF) {
    PDF.prototype.arc = function (x, y, radius, startAngle, endAngle, anticlockwise) {
        var startX = x + radius * Math.cos(startAngle),
            startY = y + radius * Math.sin(startAngle),
            endX = x + radius * Math.cos(endAngle),
            endY = y + radius * Math.sin(endAngle),
            arcAngle = endAngle - startAngle,
            largeArc = (arcAngle > Math.PI) ^ (startAngle > endAngle) ^ anticlockwise;
        return this.path("M " + startX + "," + startY +
            " A " + radius + "," + radius +
            " 0 " + (largeArc ? "1" : "0") + "," + (anticlockwise ? "0" : "1") +
            " " + endX + "," + endY);
    };
}
function generateGoalDonut(doc, docY, percent, lang) {
    var leftMargin = PDFConstants.Size.PageWidth / 2;
    doc
        .circle(leftMargin, docY + PDFConstants.Size.GoalRadius, PDFConstants.Size.GoalRadius)
        .lineWidth(10)
        .stroke(PDFConstants.Color.LightShade);
    doc
        .circle(leftMargin, docY + PDFConstants.Size.GoalRadius, PDFConstants.Size.GoalRadius)
        .lineWidth(5)
        .stroke(percent === 100 ? PDFConstants.Color.HeaderText : PDFConstants.Color.ProgressLight);
    if (percent !== 100) {
        doc
            .lineWidth(5)
            .arc(leftMargin, docY + PDFConstants.Size.GoalRadius, PDFConstants.Size.GoalRadius, 0, percent / 100 * 360 * Math.PI / 180, false)
            .rotate(-100, {origin: [leftMargin, docY + PDFConstants.Size.GoalRadius]})
            .stroke(PDFConstants.Color.HeaderText);
        doc.rotate(100, {origin: [leftMargin, docY + PDFConstants.Size.GoalRadius]});
    }
    doc.lineWidth(1);
    doc
        .fontSize(PDFConstants.FontSize.Large)
        .fill(PDFConstants.Color.RegularText)
        .font(PDFConstants.Font.OpenSansRegular)
        .text(percent, leftMargin - PDFConstants.Size.GoalRadius, docY + 10, {width: PDFConstants.Size.GoalRadius * 2, align: 'center'});
    doc
        .fontSize(PDFConstants.FontSize.Small)
        .text(i18nHelper.translate(lang, 'common.pct'), leftMargin - PDFConstants.Size.GoalRadius, docY + 30, {width: PDFConstants.Size.GoalRadius * 2, align: 'center'});
}
function processShapes(ele, doc) {
    var i, len, shape;

    Object.keys(ele).forEach(function (e) {
        if (ele.hasOwnProperty(e)) {
            shape = e.toString();
            if (shape === 'g') {
                for (i = 0, len = ele[e].length; i < len; i += 1) {
                    if (!ele[e][i].$ || ele[e][i].$.display !== 'none') {
                        processShapes(ele[e][i], doc);
                    }
                }
            } else if (processElement[shape]) {
                processElement[shape]({ele: ele[e], doc: doc});
            } else {
                HgLog.error('Element ' + shape + ' is not supported!');
            }
        }
    });
}
function parseHTML(value) {
    return htmlToText.fromString(value.replace(/•/g, '\u2022 ')
                .replace(/\t/g, '')
                .replace(/\r\n/g, '\n')
                .replace(/<div/g, '<br')
                .replace(/<b>/g, ''));

}
function extractTaggedUserName(comment) {
    return comment.replace(/<input.*?value="/g, '').replace(/">/g, '');
}
function convertBadgeToJSON(svg, callback) {
    parseXml(svg, {explicitArray: true}, function (err, result) {
        callback(result.svg);
    });
}
function convertBadgeToSvg(badgeSvgs, callback) {
    var len = Object.keys(badgeSvgs).length, badgeKey, badgeImages = {};
    if (!len) {
        return callback();
    }
    Async.whilst(
        function () {
            len -= 1;
            badgeKey = len > -1 ? Object.keys(badgeSvgs)[len] : '';
            return len > -1;
        },
        function (badgeCallback) {
            var xml = '';
            if (isLocal) {
                fs.readFile(badgeSvgs[badgeKey], 'utf8', function (error, svg) {
                    if (error) {
                        HgLog.error({methodName: 'readBadgeImages', error: error});
                        badgeSvgs[badgeKey] = 'css/images/empty-badge.png';
                        badgeCallback();
                        //return badgeCallback('pdf.rev.errg');
                    } else {
                        svg = svg.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                        convertBadgeToJSON(svg, function (data) {
                            if (!badgeImages[badgeKey]) {
                                badgeImages[badgeKey] = data;
                            }
                            badgeCallback();
                        });
                    }
                });
            } else {
                https.get({
                    host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
                    path: badgeSvgs[badgeKey]
                }, function (ret) {
                    ret.on("data", function (chunk) {
                        xml += chunk;
                    }).on("end", function () {
                        xml = xml.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                        if (!xml) {
                            HgLog.error('ERROR: ' + badgeSvgs[badgeKey]);
                            return badgeCallback();
                        }
                        convertBadgeToJSON(xml, function (data) {
                            if (!badgeImages[badgeKey]) {
                                badgeImages[badgeKey] = data;
                            }
                            badgeCallback();
                        });
                    });
                }).on('error', function (e) {
                    HgLog.error('ERROR: ' + e.message);
                    return badgeCallback('pdf.rev.errg');
                });
            }
        },
        function (error) {
            if (error) {
                return callback(error);
            }
            callback(null, badgeImages);
        }
    );
}
function bufferUserAvatars(userIds, callback) {
    var userAvatarBuffers = [];
    Async.eachLimit(userIds, 9, function (userId, fcallback) {
        var userAvatarBuffer = [];
        https.get({
            host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
            path: '/user/' + userId + '.jpg'
        }, function (ret) {
            ret.on("data", function (chunk) {
                userAvatarBuffer = userAvatarBuffer || [];
                userAvatarBuffer.push(chunk);
            }).on("end", function () {
                userAvatarBuffer = Buffer.concat(userAvatarBuffer);
                userAvatarBuffers[userId] = userAvatarBuffer;
                fcallback();
            });
        }).on('error', function (e) {
            fcallback('ERROR: ' + e.message);
        });
    }, function (error) {
        callback(error, userAvatarBuffers);
    });
}
function avatarPath(userId, userAvatarBuffers) {
    return isLocal ?
            './static' + config.s3store.imageStore[config.nextIndex()] + '/user/' + userId + '.jpg' :
            userAvatarBuffers[userId];
}
function generateAvatar(doc, userId, userAvatarBuffers, width) {
    var leftMargin = PDFConstants.Size.MarginLeft,
        cornerRadius = 4,
        docY = doc.y;

    if (width === PDFConstants.Size.AvatarImage) {
        cornerRadius += 4;
    } else {
        leftMargin += 10;
    }
    doc.save();
    try {
        doc.roundedRect(leftMargin, docY, width, width, cornerRadius).clip();
        doc.image(avatarPath(userId, userAvatarBuffers), leftMargin, docY, {width: width});
        doc.roundedRect(leftMargin, docY, width, width, cornerRadius).stroke(PDFConstants.Color.RegularText);
    } catch (ex) {
        HgLog.debug(ex);
        doc.roundedRect(leftMargin, docY, width, width, cornerRadius).clip();
        doc.image('./static/css/images/boy.jpg', leftMargin, docY, {width: width});
        doc.roundedRect(leftMargin, docY, width, width, cornerRadius).stroke(PDFConstants.Color.RegularText);
    }
    doc.restore();
}
function nextLine(doc, margin) {
    doc.y += margin;
    if (doc.y > PDFConstants.Size.PageBreak) {
        doc.y = PDFConstants.Size.MarginTop;
        doc.addPage();
    }
}

module.exports = {
    convertBadgeToSvg: convertBadgeToSvg,
    createArch: createArch,
    parseHTML: parseHTML,
    extractTaggedUserName: extractTaggedUserName,
    processShapes: processShapes,
    bufferUserAvatars: bufferUserAvatars,
    generateAvatar: generateAvatar,
    nextLine: nextLine,
    avatarPath: avatarPath,
    generateGoalDonut: generateGoalDonut
};