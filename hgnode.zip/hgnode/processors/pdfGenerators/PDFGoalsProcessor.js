/*jslint node:true es5:true*/
"use strict";
var PDFConstants = require('../pdfGenerators/PDFConstants.js'),
    i18nHelper = require('../../helpers/i18nHelper.js'),
    PDFHelper = require('./PDFHelper.js'),
    translateMap = require('../../helpers/translateHelper.js').Goal,
    DateHelper = require('../../util/DateHelper.js'),
    FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    GoalEnums = require('../../enums/GoalEnums.js'),
    Lang;

function GeneratePdf(doc, goals, lang, userAvatarBuffers, callback) {
    var progressUnit,
        i,
        docY,
        goalDeailsInfo = {};
    Lang = lang;
    goals.forEach(function (goal) {
        PDFHelper.nextLine(doc, 10);
        PDFHelper.generateGoalDonut(doc, doc.y, Math.round(goal.PercentCompletion), Lang);
        PDFHelper.nextLine(doc, 30);
        doc
            .font(PDFConstants.Font.OpenSansBold)
            .fontSize(PDFConstants.FontSize.Medium)
            .fill(PDFConstants.Color.HeaderText)
            .text(goal.Name, 0, doc.y, {width: PDFConstants.Size.PageWidth, align: 'center'});
        PDFHelper.nextLine(doc, 10);
        if (!goal.IsPublic) {
            // doc.save();
            // doc.translate(PDFConstants.Size.PageWidth / 2, doc.y).scale(0.35);
            // PDFHelper.processShapes(PDFConstants.Svg.Lock, doc);
            // doc.restore();
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.Red)
                .text(i18nHelper.translate(Lang, 'common.pr'), 0, doc.y, {width: PDFConstants.Size.PageWidth, align: 'center'});
            PDFHelper.nextLine(doc, 10);
        }
        if (goal.ProgressStatus) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansBold)
                .fill(PDFConstants.Color.ProgressStatus[goal.ProgressStatus])
                .text(i18nHelper.translate(Lang, translateMap.Status[goal.ProgressStatus]), 0, doc.y, {
                    width: PDFConstants.Size.PageWidth,
                    align: 'center'
                });
            PDFHelper.nextLine(doc, 10);
        }

        if (goal.Description) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansRegular)
                .fill(PDFConstants.Color.RegularText)
                .text(goal.Description, PDFConstants.Size.MarginLeft, doc.y, {
                    width: PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2,
                    align: 'center'
                });
            PDFHelper.nextLine(doc, 20);
        }
        goalDeailsInfo = {};
        if (goal.ClosePromptDate) {
            goalDeailsInfo['pdf.cmb'] = DateHelper.formatDateStringFromTimestamp(goal.ClosePromptDate);
        }
        if (goal.CycleTitle) {
            goalDeailsInfo['pdf.cyn'] = goal.CycleTitle;
        }
        if (goal.CheckInFrequency) {
            goalDeailsInfo['pdf.cif'] = goal.CheckInFrequency;
        }
        if (goal.Status) {
            goalDeailsInfo['common.sta'] = i18nHelper.translate(Lang, translateMap.GoalStatus[goal.Status]);
        }
        if (goal.Approver.FullName) {
            goalDeailsInfo['pdf.app'] = goal.Approver.FullName;
        }

        Object.keys(goalDeailsInfo).forEach(function (key, ind) {
            if (ind % 2 === 1) {
                doc
                    .rect(PDFConstants.Size.MarginLeft, doc.y, PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2, 25)
                    .fill(PDFConstants.Color.LightShade);
            }
            PDFHelper.nextLine(doc, 2);
            docY = doc.y;
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansBold)
                .fill(PDFConstants.Color.RegularText)
                .text(i18nHelper.translate(Lang, key), PDFConstants.Size.MarginLeft, docY, {
                    width: 100,
                    align: 'right'
                });
            doc
                .font(PDFConstants.Font.OpenSansRegular)
                .text(goalDeailsInfo[key], PDFConstants.Size.MarginLeft + 120, docY, {width: 250, align: 'left'});
            PDFHelper.nextLine(doc, 10);
        });

        PDFHelper.nextLine(doc, 5);
        goal.KeyResults.forEach(function (keyResult) {
            if (doc.y > PDFConstants.Size.PageBreak - 50) {
                PDFHelper.nextLine(doc, 50);
            }
            doc
                .rect(PDFConstants.Size.MarginLeft, doc.y, PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2, 50)
                .fill(PDFConstants.Color.LightShade);
            PDFHelper.nextLine(doc, 5);
            docY = doc.y;
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansSemibold)
                .fill(PDFConstants.Color.RegularText)
                .text(keyResult.Name, PDFConstants.Size.MarginLeft + 20, docY, {width: 400});

            if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Numeric) {
                if (keyResult.NumericType === GoalEnums.KeyResultNumericType.Percentage && keyResult.Target === 100) {
                    doc
                        .font(PDFConstants.Font.OpenSansBold)
                        .text(keyResult.Progress + keyResult.Suffix || '', 400, docY, {
                            width: 150,
                            align: 'right'
                        });
                } else {
                    doc
                        .font(PDFConstants.Font.OpenSansBold)
                        .text(i18nHelper.translate(lang, 'pdf.out', {
                            progress: keyResult.Progress + (keyResult.Suffix || ''),
                            target: keyResult.Target + (keyResult.Suffix || '')
                        }), 400, docY, {width: 150, align: 'right'});
                }
                PDFHelper.nextLine(doc, 15);
                if (keyResult.Progress >= keyResult.Target) {
                    doc
                        .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                        .lineWidth(4)
                        .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                        .stroke(PDFConstants.Color.HeaderText);
                } else {
                    if (keyResult.Target === 100) {
                        progressUnit = keyResult.Progress * 5;
                    } else {
                        progressUnit = keyResult.Progress / keyResult.Target * 500;
                    }
                    doc
                        .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                        .lineWidth(4)
                        .lineTo(PDFConstants.Size.MarginProgress + progressUnit, doc.y)
                        .stroke(PDFConstants.Color.HeaderText);
                    doc
                        .moveTo(PDFConstants.Size.MarginProgress + progressUnit, doc.y)
                        .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                        .stroke(PDFConstants.Color.RegularText);
                }
            } else if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Percentage) {
                doc
                    .font(PDFConstants.Font.OpenSansBold)
                    .fill(PDFConstants.Color.RegularText)
                    .text(i18nHelper.translate(Lang, 'profile.goals.pp', { progress: keyResult.Progress}), 400, docY, {
                        width: 150,
                        align: 'right'
                    });
                PDFHelper.nextLine(doc, 15);
                doc
                    .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                    .lineWidth(4)
                    .lineTo(PDFConstants.Size.MarginProgress + keyResult.Progress * 5, doc.y)
                    .stroke(PDFConstants.Color.HeaderText);
                if (keyResult.Progress !== 100) {
                    doc
                        .moveTo(PDFConstants.Size.MarginProgress + keyResult.Progress * 5, doc.y)
                        .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                        .stroke(PDFConstants.Color.RegularText);
                }
            } else if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Binary) {
                doc
                    .font(PDFConstants.Font.OpenSansBold)
                    .fill(PDFConstants.Color.RegularText)
                    .text(i18nHelper.translate(Lang, keyResult.Progress === 100 ? 'common.com' : 'common.inco'), 400, docY, {
                        width: 150,
                        align: 'right'
                    });
                PDFHelper.nextLine(doc, 15);
                doc
                    .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                    .lineWidth(4)
                    .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                    .stroke(keyResult.Progress === 100 ? PDFConstants.Color.HeaderText : PDFConstants.Color.RegularText);
            }
            doc.lineWidth(1);
            PDFHelper.nextLine(doc, 20);
        });
        PDFHelper.nextLine(doc, 20);

        if (goal.CommentTotalCount) {
            doc
                .font(PDFConstants.Font.OpenSansBold)
                .fill(PDFConstants.Color.RegularText)
                .text(i18nHelper.translate(Lang, 'common.cmt'), PDFConstants.Size.MarginLeft, doc.y, {width: 110});
            PDFHelper.nextLine(doc, 20);
            for (i = goal.Comments.length - 1; i >= 0; i -= 1) {
                docY = doc.y;
                PDFHelper.generateAvatar(doc, goal.Comments[i].UserId, userAvatarBuffers, PDFConstants.Size.CommentImage);
                doc
                    .fontSize(PDFConstants.FontSize.Small)
                    .font(PDFConstants.Font.OpenSansBold)
                    .text(goal.Comments[i].Name, PDFConstants.Size.MarginComment, docY, {width: PDFConstants.Size.LabelWidth});
                PDFHelper.nextLine(doc, 5);
                doc
                    .fontSize(PDFConstants.FontSize.Small)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(i18nHelper.translate(Lang, PDFHelper.parseHTML(goal.Comments[i].Comment)), PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
                PDFHelper.nextLine(doc, 15);
            }
            PDFHelper.nextLine(doc, 15);
        }
    });
    callback();
}

module.exports = {
    GeneratePdf: GeneratePdf
};