/*jslint node:true es5:true*/
"use strict";
var PDFConstants = require('../pdfGenerators/PDFConstants.js'),
    PDFHelper = require('./PDFHelper.js');

function GeneratePdf(doc, recognitions, badgeImages, userAvatarBuffers, callback) {
    var badge, docY;
    recognitions.forEach(function (rec) {
        badge  = badgeImages[rec.TemplateId];
        PDFHelper.nextLine(doc, 10);
        if (badge) {
            doc.save();
            doc.translate(PDFConstants.Size.MarginLeft, doc.y).scale(0.35);
            PDFHelper.processShapes(badge, doc);
            doc.restore();
        }
        doc
            .fontSize(PDFConstants.FontSize.Medium)
            .fill(PDFConstants.Color.RegularText)
            .font(PDFConstants.Font.OpenSansBold)
            .text(rec.title, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 5);
        doc
            .fontSize(PDFConstants.FontSize.Small)
            .font(PDFConstants.Font.OpenSansItalic)
            .text(rec.issuer.fullName, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 5);
        doc
            .font(PDFConstants.Font.OpenSansRegular)
            .text(rec.message, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 15);

        if (rec.comments.length) {
            doc
                .moveTo(PDFConstants.Size.MarginLeft, doc.y)
                .dash(2)
                .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, doc.y)
                .stroke(PDFConstants.Color.Underline).undash();
            rec.comments.forEach(function (comment) {
                if (comment.Comment) {
                    PDFHelper.nextLine(doc, 10);
                    docY = doc.y;
                    PDFHelper.generateAvatar(doc, comment.UserId, userAvatarBuffers, PDFConstants.Size.CommentImage);
                    doc
                        .fontSize(PDFConstants.FontSize.Small)
                        .font(PDFConstants.Font.OpenSansBold)
                        .text(comment.Name, PDFConstants.Size.MarginComment, docY, {width: PDFConstants.Size.LabelWidth});
                    PDFHelper.nextLine(doc, 3);
                    doc
                        .fontSize(PDFConstants.FontSize.Small)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(PDFHelper.parseHTML(PDFHelper.extractTaggedUserName(comment.Comment)), PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
                    PDFHelper.nextLine(doc, 5);
                }
            });
            PDFHelper.nextLine(doc, 5);
        }
        doc
            .moveTo(PDFConstants.Size.MarginLeft, doc.y)
            .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, doc.y)
            .stroke(PDFConstants.Color.Underline);
        PDFHelper.nextLine(doc, 5);
    });
    callback();
}

module.exports = {
    GeneratePdf: GeneratePdf
};