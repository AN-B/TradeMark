/*jslint node:true es5:true regexp: true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    FeedbackPDFProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var PDF = require('pdfkit'),
            Async = require('async'),
            fs = require('fs.extra'),
            doc,
            docBuffers = [],
            userAvatarBuffers = [],
            isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
            HgLog = require('../../framework/HgLog'),
            PDFConstants = require('../pdfGenerators/PDFConstants.js'),
            PDFHelper = require('./PDFHelper.js'),
            RecognitionsProcessor = require('./PDFRecognitionsProcessor.js'),
            GoalsProcessor = require('./PDFGoalsProcessor.js'),
            FeedbackProcessor = require('./PDFFeedbackProcessor.js'),
            CheckinsProcessor = require('./PDFCheckinsProcessor.js'),
            i18nHelper = require('../../helpers/i18nHelper.js'),
            s3Util = require('../../helpers/s3Util.js'),
            DateHelper = require('../../util/DateHelper.js'),
            FeedbackEnums = require('../../enums/FeedbackEnums.js'),
            cryptoHelper = require('../../helpers/cryptoHelper.js'),
            lang,
            profile,
            tz;

        function addUserId(userIds, id) {
            if (userIds.indexOf(id) === -1) {
                userIds.push(id);
            }
            return userIds;
        }
        function readBadgeImages(callback) {
            var badgeSvgs = {}, recogntionSections = [];

            Async.parallel({
                recognitions: function (fcallback) {
                    if (profile.recognitions && profile.recognitions.length) {
                        profile.recognitions.forEach(function (data) {
                            if (!badgeSvgs[data.TemplateId]) {
                                badgeSvgs[data.TemplateId] = (isLocal ? './static/img' : '') + data.badgeUrl + '.svg';
                            }
                        });
                    }
                    fcallback();
                },
                checkins: function (fcallback) {
                    if (profile.checkins && profile.checkins.length) {
                        profile.checkins.forEach(function (data) {
                            recogntionSections = recogntionSections.concat(
                                data.Card.Sections.filter(function (section) {
                                    return section.Type === FeedbackEnums.SectionType.Recognitions;
                                })
                            );
                        });

                        recogntionSections.forEach(function (recogntionSection) {
                            if (Array.isArray(recogntionSection.AuxiliaryData) && recogntionSection.AuxiliaryData.length) {
                                recogntionSection.AuxiliaryData.forEach(function (data) {
                                    if (!badgeSvgs[data.TemplateId]) {
                                        badgeSvgs[data.TemplateId] = (isLocal ? './static/img' : '') + data.badgeUrl + '.svg';
                                    }
                                });
                            }
                        });
                    }
                    fcallback();
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                PDFHelper.convertBadgeToSvg(badgeSvgs, callback);
            });
        }
        function bufferUserAvatar(callback) {
            if (isLocal) {
                return callback();
            }
            var userIds = [profile.member.UserId];

            Async.parallel({
                goals: function (fcallback) {
                    if (profile.goals && profile.goals.length) {
                        profile.goals.forEach(function (g) {
                            if (g.Comments && g.Comments.length) {
                                g.Comments.forEach(function (c) {
                                    userIds = addUserId(userIds, c.UserId);
                                });
                            }
                        });
                    }
                    fcallback();
                },
                recognitions: function (fcallback) {
                    if (profile.recognitions && profile.recognitions.length) {
                        profile.recognitions.forEach(function (r) {
                            if (r.comments && r.comments.length) {
                                r.comments.forEach(function (c) {
                                    userIds = addUserId(userIds, c.UserId);
                                });
                            }
                        });
                    }
                    fcallback();
                },
                feedback: function (fcallback) {
                    if (profile.feedback && profile.feedback.length) {
                        profile.feedback.forEach(function (f) {
                            f.Participants.forEach(function (p) {
                                userIds = addUserId(userIds, p.UserId);
                            });
                        });
                    }
                    fcallback();
                },
                checkins: function (fcallback) {
                    if (profile.checkins && profile.checkins.length) {
                        profile.checkins.forEach(function (cycle) {
                            cycle.Card.Sections.forEach(function (section) {
                                section.Questions.forEach(function (question) {
                                    if (Array.isArray(question.Answers)) {
                                        question.Answers.forEach(function (answer) {
                                            userIds = addUserId(userIds, answer.UserId);
                                        });
                                    }
                                    if (Array.isArray(question.ManagerNotes)) {
                                        question.ManagerNotes.forEach(function (note) {
                                            userIds = addUserId(userIds, note.UserId);
                                        });
                                    }
                                    if (Array.isArray(question.PdfManagerNotes)) {
                                        question.PdfManagerNotes.forEach(function (note) {
                                            userIds = addUserId(userIds, note.UserId);
                                        });
                                    }
                                });
                                if (Array.isArray(section.AuxiliaryData)) {
                                    section.AuxiliaryData.forEach(function (data) {
                                        if (data.OwnerUserId) {
                                            userIds = addUserId(userIds, data.OwnerUserId);
                                        }
                                        if (data.ManagerUserId) {
                                            userIds = addUserId(userIds, data.ManagerUserId);
                                        }
                                        if (data.comments && data.comments.length) {
                                            data.comments.forEach(function (c) {
                                                userIds = addUserId(userIds, c.UserId);
                                            });
                                        }
                                    });
                                } else if (section.AuxiliaryData && section.AuxiliaryData.hgId) {
                                    if (section.AuxiliaryData.Approver) {
                                        userIds = addUserId(userIds, section.AuxiliaryData.Approver.UserId);
                                    }
                                    if (section.AuxiliaryData.Owner) {
                                        userIds = addUserId(userIds, section.AuxiliaryData.Owner.UserId);
                                    }
                                    if (section.AuxiliaryData.Comments && section.AuxiliaryData.Comments.length) {
                                        section.AuxiliaryData.Comments.forEach(function (c) {
                                            userIds = addUserId(userIds, c.UserhgId);
                                        });
                                    }
                                }
                            });
                        });
                    }
                    fcallback();
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                PDFHelper.bufferUserAvatars(userIds, callback);
            });
        }
        function sectionHeader(name) {
            PDFHelper.nextLine(doc, 10);
            doc
                .font(PDFConstants.Font.OpenSansSemibold)
                .fontSize(PDFConstants.FontSize.Large)
                .fill(PDFConstants.Color.HeaderText)
                .text(name, PDFConstants.Size.MarginLeft, doc.y, {width: 540});
            PDFHelper.nextLine(doc, 5);
            doc
                .lineWidth(5)
                .moveTo(PDFConstants.Size.MarginLeft, doc.y)
                .lineTo(576, doc.y)
                .stroke(PDFConstants.Color.Underline);
            doc.lineWidth(1);
            PDFHelper.nextLine(doc, 5);
        }
        function profileHeader() {
            PDFHelper.nextLine(doc, 10);
            PDFHelper.generateAvatar(doc, profile.member.UserId, userAvatarBuffers, PDFConstants.Size.AvatarImage);
            doc
                .fontSize(PDFConstants.FontSize.Medium)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansSemibold)
                .text(profile.member.FullName, PDFConstants.Size.MarginLeftHeader, doc.y - PDFConstants.Size.AvatarImage, {width: PDFConstants.Size.LabelWidth});
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(lang, "pdf.rev.btw", {
                    start_date: DateHelper.formatDateStringFromTimestamp(profile.startDate),
                    end_date: DateHelper.formatDateStringFromTimestamp(profile.endDate)
                }), PDFConstants.Size.MarginLeft, doc.y - 15,
                    {
                        width: PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2,
                        align: 'right'
                    });
            PDFHelper.nextLine(doc, 4);
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(profile.member.GroupDepartmentName, PDFConstants.Size.MarginLeftHeader, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 4);
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(profile.member.Position, PDFConstants.Size.MarginLeftHeader, doc.y, {width: PDFConstants.Size.LabelWidth});
            if (profile.member.MyManagers.length) {
                PDFHelper.nextLine(doc, 4);
                doc
                    .fontSize(PDFConstants.FontSize.Small)
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(i18nHelper.translate(lang, "pdf.rpt", {manager_name: profile.member.MyManagers[0].FullName}), PDFConstants.Size.MarginLeftHeader, doc.y, {width: PDFConstants.Size.LabelWidth});
            }
            PDFHelper.nextLine(doc, 10);
        }
        function buildPDF() {
            doc.y = 0;
            profileHeader();
            Async.waterfall([
                function (wf) {
                    if (!profile.goals) {
                        return wf();
                    }
                    sectionHeader(i18nHelper.translate(lang, 'common.gls'));
                    if (profile.goals.length) {
                        GoalsProcessor.GeneratePdf(doc, profile.goals, lang, userAvatarBuffers, wf);
                    } else {
                        doc
                            .font(PDFConstants.Font.OpenSansRegular)
                            .fontSize(PDFConstants.FontSize.Medium)
                            .fill(PDFConstants.Color.RegularText)
                            .text(i18nHelper.translate(lang, 'pdf.ngs'), PDFConstants.Size.MarginLeft, doc.y, {width: 540});
                        PDFHelper.nextLine(doc, 15);
                        wf();
                    }
                },
                function (wf) {
                    if (!profile.feedback) {
                        return wf();
                    }
                    sectionHeader(i18nHelper.translate(lang, 'common.fdb'));
                    if (profile.feedback.length) {
                        FeedbackProcessor.GeneratePdf(doc, profile.feedback, lang, tz, userAvatarBuffers, wf);
                    } else {
                        doc
                            .font(PDFConstants.Font.OpenSansRegular)
                            .fontSize(PDFConstants.FontSize.Medium)
                            .fill(PDFConstants.Color.RegularText)
                            .text(i18nHelper.translate(lang, 'pdf.rev.nfa'), PDFConstants.Size.MarginLeft, doc.y, {width: 540});
                        PDFHelper.nextLine(doc, 15);
                        wf();
                    }
                },
                function (wf) {
                    if (!profile.recognitions) {
                        return wf();
                    }
                    sectionHeader(i18nHelper.translate(lang, 'common.re'));
                    if (profile.recognitions.length) {
                        readBadgeImages(function (error, badgeImages) {
                            if (error) {
                                return wf('pdf.rev.errg');
                            }
                            RecognitionsProcessor.GeneratePdf(doc, profile.recognitions, badgeImages, userAvatarBuffers, wf);
                        });
                    } else {
                        PDFHelper.nextLine(doc, 15);
                        doc
                            .font(PDFConstants.Font.OpenSansRegular)
                            .fontSize(PDFConstants.FontSize.Medium)
                            .fill(PDFConstants.Color.RegularText)
                            .text(i18nHelper.translate(lang, 'pdf.rev.nar'), PDFConstants.Size.MarginLeft, doc.y, {width: 540});
                        PDFHelper.nextLine(doc, 15);
                        wf();
                    }
                },
                function (wf) {
                    if (!profile.checkins) {
                        return wf();
                    }
                    sectionHeader(i18nHelper.translate(lang, 'pdf.cks'));
                    if (profile.checkins.length) {
                        readBadgeImages(function (error, badgeImages) {
                            if (error) {
                                return wf('pdf.rev.errg');
                            }
                            CheckinsProcessor.GeneratePdf(doc, profile.checkins, lang, badgeImages, userAvatarBuffers, wf);
                        });
                    } else {
                        doc
                            .font(PDFConstants.Font.OpenSansRegular)
                            .fontSize(PDFConstants.FontSize.Medium)
                            .fill(PDFConstants.Color.RegularText)
                            .text(i18nHelper.translate(lang, 'pdf.cna'), PDFConstants.Size.MarginLeft, doc.y, {width: 540});
                        PDFHelper.nextLine(doc, 15);
                        wf();
                    }
                }], function (error) {
                if (error) {
                    HgLog.error('buildPDF: ' + error);
                }
                doc.save().end();
            });
        }

        PDFHelper.createArch(PDF);
        this.GeneratePdf = function (params, callback) {
            var encryptedFilePath = __dirname.replace('hgnode/processors/pdfGenerators', 'provision/encrypted_') + params.FileName,
                outputFileName = 'encrypted_' + params.FileName,
                fileWrite = fs.createWriteStream(encryptedFilePath),
                fileRead,
                cipher = cryptoHelper.createCipher();
            profile = params.Profile;
            lang = params.Lang;
            tz = (params.tz || 0) * DateHelper.intervals.millisecPerTimeZone;

            doc = new PDF({
                info: {
                    Title: profile.member.FullName,
                    Author: PDFConstants.Author,
                    Producer: PDFConstants.Author
                },
                size: 'letter',
                margins: {
                    top: PDFConstants.Size.MarginTop,
                    bottom: PDFConstants.Size.MarginBottom,
                    left: 24,
                    right: 24
                },
                bufferPages: true
            });
            Object.keys(PDFConstants.Font).forEach(function (key) {
                doc.registerFont(key, PDFConstants.Font[key]);
            });
            doc.lineWidth(1);
            doc
                .pipe(cipher)
                .pipe(fileWrite)
                .on('data', function (data) {
                    docBuffers.push(data);
                })
                .on('error', function (error) {
                    return callback(error);
                })
                .on('finish', function () {
                    if (!isLocal) {
                        fileRead = fs.createReadStream(encryptedFilePath);
                        s3Util.pushS3FileBuffer(fileRead, 'binary', 'application/pdf', 'provision/' + outputFileName, callback);
                    } else {
                        callback();
                    }
                });
            bufferUserAvatar(function (error, data) {
                if (error) {
                    return callback(error);
                }
                userAvatarBuffers = data || [];
                buildPDF();
            });
        };
    };

module.exports = FeedbackPDFProcessor;
