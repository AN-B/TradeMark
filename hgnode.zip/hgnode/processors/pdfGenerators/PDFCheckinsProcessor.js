/*jslint node:true es5:true*/
"use strict";
var PDFConstants = require('../pdfGenerators/PDFConstants.js'),
    i18nHelper = require('../../helpers/i18nHelper.js'),
    PDFHelper = require('./PDFHelper.js'),
    DateHelper = require('../../util/DateHelper.js'),
    FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    GoalEnums = require('../../enums/GoalEnums.js'),
    translateMap = require('../../helpers/translateHelper.js').Goal,
    Lang;


function RenderAnswer(doc, question) {
    doc
        .font(PDFConstants.Font.OpenSansBold)
        .fontSize(PDFConstants.FontSize.Small)
        .fill(PDFConstants.Color.Black)
        .text(question.Question, PDFConstants.Size.MarginQuestion, doc.y, {width: PDFConstants.Size.LabelWidth});
    PDFHelper.nextLine(doc, 10);

    this.ShortAnswer = function (answer) {
        if (!answer.Text) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        doc
            .fontSize(PDFConstants.FontSize.Small)
            .fill(PDFConstants.Color.RegularText)
            .font(PDFConstants.Font.OpenSansRegular)
            .text(answer.Text, PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 20);
    };
    this.RadioButton = function (answer) {
        var selection = answer.SelectedValues && answer.SelectedValues.length && question.AnswerSelector.find(function (selected) {
            return selected.Value === answer.SelectedValues[0];
        });
        if (!selection) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        PDFHelper.nextLine(doc, 3);
        doc.circle(PDFConstants.Size.MarginLeftHeader, doc.y + 8, 8).fill(PDFConstants.Color.HeaderText);
        doc
            .fontSize(PDFConstants.FontSize.Small)
            .fill(PDFConstants.Color.RegularText)
            .font(PDFConstants.Font.OpenSansRegular)
            .text(selection.Text, PDFConstants.Size.MarginAnswer + 27, doc.y, {width: PDFConstants.Size.LabelWidth, align: 'left'});
        PDFHelper.nextLine(doc, 20);
    };
    this.RatingScale = function (answer) {
        var selection, docY;
        if (!answer.SelectedValues || !answer.SelectedValues.length) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        question.AnswerSelector.forEach(function (selector, index) {
            selection = answer.SelectedValues.find(function (selectedAnswer) {
                return selector.Value === selectedAnswer;
            });
            docY = doc.y;
            doc
                .circle(PDFConstants.Size.MarginLeftHeader, doc.y + 8, 8)
                .fillAndStroke(
                    selection === undefined ? PDFConstants.Color.White : PDFConstants.Color.HeaderText,
                    selection === undefined ? PDFConstants.Color.RegularText : PDFConstants.Color.HeaderText
                );
            doc
                .fontSize(PDFConstants.FontSize.Xsmall)
                .fill(selection !== undefined ? PDFConstants.Color.White : PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'feedback.asw.' + 'a' + index), PDFConstants.Size.MarginAnswer + 4, doc.y + 2, {width: 20, align: 'center'});
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(selection !== undefined ? PDFConstants.Color.HeaderText : PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(selector.Text, PDFConstants.Size.MarginAnswer + 27, docY, {width: PDFConstants.Size.LabelWidth, align: 'left'});
            PDFHelper.nextLine(doc, 10);
        });
        PDFHelper.nextLine(doc, 5);
    };
    this.CheckBox = function (answer) {
        var selection;
        if (!answer.SelectedValues || !answer.SelectedValues.length) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(i18nHelper.translate(Lang, 'pdf.awp'), PDFConstants.Size.MarginAnswer, doc.y, {width: PDFConstants.Size.LabelWidth});
            PDFHelper.nextLine(doc, 10);
            return;
        }
        answer.SelectedValues.forEach(function (selectedAnswer) {
            selection = question.AnswerSelector.find(function (selected) {
                return selected.Value === selectedAnswer;
            });
            doc.circle(PDFConstants.Size.MarginLeftHeader, doc.y + 8, 8).fill(PDFConstants.Color.HeaderText);
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .fill(PDFConstants.Color.RegularText)
                .font(PDFConstants.Font.OpenSansRegular)
                .text(selection.Text, PDFConstants.Size.MarginAnswer + 27, doc.y, {width: PDFConstants.Size.LabelWidth, align: 'left'});
            PDFHelper.nextLine(doc, 10);
        });
        PDFHelper.nextLine(doc, 5);
    };
}
function RenderAuxiliaryData(doc, data, badgeImages, userAvatarBuffers) {
    this.Recognitions = function () {
        var badge  = badgeImages[data.TemplateId], docY;
        PDFHelper.nextLine(doc, 10);
        if (badge) {
            doc.save();
            doc.translate(PDFConstants.Size.MarginLeft, doc.y).scale(0.35);
            PDFHelper.processShapes(badge, doc);
            doc.restore();
        }
        doc
            .fontSize(PDFConstants.FontSize.Medium)
            .fill(PDFConstants.Color.RegularText)
            .font(PDFConstants.Font.OpenSansBold)
            .text(data.title, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 5);
        doc
            .fontSize(PDFConstants.FontSize.Small)
            .font(PDFConstants.Font.OpenSansItalic)
            .text(data.issuer.fullName, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 5);
        doc
            .font(PDFConstants.Font.OpenSansRegular)
            .text(data.message, PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
        PDFHelper.nextLine(doc, 15);

        if (data.comments.length) {
            doc
                .moveTo(PDFConstants.Size.MarginLeft, doc.y)
                .dash(2)
                .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, doc.y)
                .stroke(PDFConstants.Color.Underline).undash();
            data.comments.forEach(function (comment) {
                if (comment.Comment) {
                    PDFHelper.nextLine(doc, 10);
                    docY = doc.y;
                    PDFHelper.generateAvatar(doc, comment.UserId, userAvatarBuffers, PDFConstants.Size.CommentImage);
                    doc
                        .fontSize(PDFConstants.FontSize.Small)
                        .font(PDFConstants.Font.OpenSansBold)
                        .text(comment.Name, PDFConstants.Size.MarginComment, docY, {width: PDFConstants.Size.LabelWidth});
                    PDFHelper.nextLine(doc, 5);
                    doc
                        .fontSize(PDFConstants.FontSize.Small)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(PDFHelper.parseHTML(comment.Comment), PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
                    PDFHelper.nextLine(doc, 10);
                }
            });
            PDFHelper.nextLine(doc, 5);
        }
        doc
            .moveTo(PDFConstants.Size.MarginLeft, doc.y)
            .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, doc.y)
            .stroke(PDFConstants.Color.Underline);
        PDFHelper.nextLine(doc, 5);
    };
    this.Goals = function (params) {
        var progressUnit,
            i,
            goalDeailsInfo = {},
            docY;
        if (!params.singleGoal) {
            PDFHelper.nextLine(doc, 10);
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansRegular)
                .fill(PDFConstants.Color.RegularText)
                .text(i18nHelper.translate(Lang, 'pdf.of', {current: params.index, total: params.total}), 0, doc.y, {
                    width: PDFConstants.Size.PageWidth,
                    align: 'center'
                });
            PDFHelper.nextLine(doc, 10);
        }
        PDFHelper.nextLine(doc, 10);
        PDFHelper.generateGoalDonut(doc, doc.y, Math.round(params.singleGoal ? data.PercentCompletion : data.Completion), Lang);
        PDFHelper.nextLine(doc, 25);
        doc
            .font(PDFConstants.Font.OpenSansBold)
            .fontSize(PDFConstants.FontSize.Medium)
            .fill(PDFConstants.Color.HeaderText)
            .text(params.singleGoal ? data.Name : data.GoalName, 0, doc.y, {width: PDFConstants.Size.PageWidth, align: 'center'});
        PDFHelper.nextLine(doc, 10);
        if (data.ProgressStatus) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansBold)
                .fill(PDFConstants.Color.ProgressStatus[data.ProgressStatus])
                .text(i18nHelper.translate(Lang, translateMap.Status[data.ProgressStatus]), 0, doc.y, {width: PDFConstants.Size.PageWidth, align: 'center'});
            PDFHelper.nextLine(doc, 10);
        }
        if (!params.singleGoal) {
            doc
                .fontSize(PDFConstants.FontSize.Small)
                .font(PDFConstants.Font.OpenSansRegular)
                .fill(PDFConstants.Color.RegularText)
                .text(i18nHelper.translate(Lang, data.KrNumber > 1 ? 'pdf.mrs' : 'pdf.mrs1', {results_number: data.KrNumber}), 0, doc.y, {
                    width: PDFConstants.Size.PageWidth,
                    align: 'center'
                });
            PDFHelper.nextLine(doc, 15);
            doc
                .moveTo(PDFConstants.Size.MarginLeft, doc.y)
                .dash(2)
                .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, doc.y)
                .stroke(PDFConstants.Color.Underline).undash();
        } else {
            if (data.Description) {
                doc
                    .font(PDFConstants.Font.OpenSansRegular)
                    .fill(PDFConstants.Color.RegularText)
                    .text(data.Description, PDFConstants.Size.MarginLeft, doc.y, {
                        width: PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2,
                        align: 'center'
                    });
                PDFHelper.nextLine(doc, 20);
            }

            //goal details
            goalDeailsInfo = {};
            if (data.ClosePromptDate) {
                goalDeailsInfo['pdf.cmb'] = DateHelper.formatDateStringFromTimestamp(data.ClosePromptDate);
            }
            if (data.CycleTitle) {
                goalDeailsInfo['pdf.cyn'] = data.CycleTitle;
            }
            if (data.CheckInFrequency) {
                goalDeailsInfo['pdf.cif'] = data.CheckInFrequency;
            }
            if (data.Status) {
                goalDeailsInfo['common.sta'] = i18nHelper.translate(Lang, translateMap.GoalStatus[data.Status]);
            }
            if (data.Approver.FullName) {
                goalDeailsInfo['pdf.app'] = data.Approver.FullName;
            }

            Object.keys(goalDeailsInfo).forEach(function (key, ind) {
                if (ind % 2 === 1) {
                    doc
                        .rect(PDFConstants.Size.MarginLeft, doc.y, PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2, 25)
                        .fill(PDFConstants.Color.LightShade);
                }
                PDFHelper.nextLine(doc, 2);
                docY = doc.y;
                doc
                    .fontSize(PDFConstants.FontSize.Small)
                    .font(PDFConstants.Font.OpenSansBold)
                    .fill(PDFConstants.Color.RegularText)
                    .text(i18nHelper.translate(Lang, key), PDFConstants.Size.MarginLeft + 20, docY, {
                        width: 70,
                        align: 'right'
                    });
                doc
                    .font(PDFConstants.Font.OpenSansRegular)
                    .text(goalDeailsInfo[key], PDFConstants.Size.MarginLeft + 120, docY, {
                        width: 250,
                        align: 'left'
                    });
                PDFHelper.nextLine(doc, 10);
            });

            PDFHelper.nextLine(doc, 5);
            data.KeyResults.forEach(function (keyResult) {
                doc
                    .rect(PDFConstants.Size.MarginLeft, doc.y, PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft * 2, 50)
                    .fill(PDFConstants.Color.LightShade);
                PDFHelper.nextLine(doc, 5);
                docY = doc.y;
                doc
                    .font(PDFConstants.Font.OpenSansSemibold)
                    .fill(PDFConstants.Color.RegularText)
                    .text(keyResult.Name, PDFConstants.Size.MarginLeft + 20, docY, {width: 400});

                if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Numeric) {
                    if (keyResult.NumericType === GoalEnums.KeyResultNumericType.Percentage && keyResult.Target === 100) {
                        doc
                            .font(PDFConstants.Font.OpenSansBold)
                            .text(keyResult.Progress + keyResult.Suffix || '', 400, docY, {
                                width: 150,
                                align: 'right'
                            });
                    } else {
                        doc
                            .font(PDFConstants.Font.OpenSansBold)
                            .text(i18nHelper.translate(Lang, 'pdf.out', {
                                progress: keyResult.Progress + (keyResult.Suffix || ''),
                                target: keyResult.Target + (keyResult.Suffix || '')
                            }), 400, docY, {width: 150, align: 'right'});
                    }
                    PDFHelper.nextLine(doc, 15);
                    if (keyResult.Progress >= keyResult.Target) {
                        doc
                            .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                            .lineWidth(4)
                            .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                            .stroke(PDFConstants.Color.HeaderText);
                    } else {
                        if (keyResult.Target === 100) {
                            progressUnit = keyResult.Progress * 5;
                        } else {
                            progressUnit = keyResult.Progress / keyResult.Target * 500;
                        }
                        doc
                            .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                            .lineWidth(4)
                            .lineTo(PDFConstants.Size.MarginProgress + progressUnit, doc.y)
                            .stroke(PDFConstants.Color.HeaderText);
                        doc
                            .moveTo(PDFConstants.Size.MarginProgress + progressUnit, doc.y)
                            .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                            .stroke(PDFConstants.Color.RegularText);
                    }
                } else if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Percentage) {
                    doc
                        .font(PDFConstants.Font.OpenSansBold)
                        .fill(PDFConstants.Color.RegularText)
                        .text(i18nHelper.translate(Lang, 'profile.goals.pp', { progress: keyResult.Progress}), 400, docY, {
                            width: 150,
                            align: 'right'
                        });
                    PDFHelper.nextLine(doc, 15);
                    doc
                        .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                        .lineWidth(4)
                        .lineTo(PDFConstants.Size.MarginProgress + keyResult.Progress * 5, doc.y)
                        .stroke(PDFConstants.Color.HeaderText);
                    if (keyResult.Progress !== 100) {
                        doc
                            .moveTo(PDFConstants.Size.MarginProgress + keyResult.Progress * 5, doc.y)
                            .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                            .stroke(PDFConstants.Color.RegularText);
                    }
                } else if (keyResult.Measure === GoalEnums.KeyResultMeasureType.Binary) {
                    doc
                        .font(PDFConstants.Font.OpenSansBold)
                        .fill(PDFConstants.Color.RegularText)
                        .text(i18nHelper.translate(Lang, keyResult.Progress === 100 ? 'common.com' : 'common.inco'), 400, docY, {
                            width: 150,
                            align: 'right'
                        });
                    PDFHelper.nextLine(doc, 15);
                    doc
                        .moveTo(PDFConstants.Size.MarginProgress, doc.y)
                        .lineWidth(4)
                        .lineTo(PDFConstants.Size.ProgressWidth, doc.y)
                        .stroke(keyResult.Progress === 100 ? PDFConstants.Color.HeaderText : PDFConstants.Color.RegularText);
                }
                doc.lineWidth(1);
                PDFHelper.nextLine(doc, 25);
            });
            PDFHelper.nextLine(doc, 20);

            //goal comments
            if (data.CommentTotalCount) {
                doc
                    .font(PDFConstants.Font.OpenSansBold)
                    .fill(PDFConstants.Color.RegularText)
                    .text(i18nHelper.translate(Lang, 'common.cmt'), PDFConstants.Size.MarginLeft, doc.y, {width: 110});
                PDFHelper.nextLine(doc, 20);
                for (i = data.Comments.length - 1; i >= 0; i -= 1) {
                    docY = doc.y;
                    PDFHelper.generateAvatar(doc, data.Comments[i].UserhgId, userAvatarBuffers, PDFConstants.Size.CommentImage);
                    doc
                        .fontSize(PDFConstants.FontSize.Small)
                        .font(PDFConstants.Font.OpenSansBold)
                        .text(data.Comments[i].Name, PDFConstants.Size.MarginComment, docY, {width: PDFConstants.Size.LabelWidth});
                    PDFHelper.nextLine(doc, 5);
                    doc
                        .fontSize(PDFConstants.FontSize.Small)
                        .font(PDFConstants.Font.OpenSansRegular)
                        .text(i18nHelper.translate(Lang, PDFHelper.parseHTML(data.Comments[i].Comment)), PDFConstants.Size.MarginComment, doc.y, {width: PDFConstants.Size.LabelWidth});
                    PDFHelper.nextLine(doc, 15);
                }
            }
        }
    };
}
function cycleHeader(doc, name) {
    PDFHelper.nextLine(doc, 10);
    doc
        .font(PDFConstants.Font.OpenSansSemibold)
        .fontSize(PDFConstants.FontSize.Large)
        .fill(PDFConstants.Color.HeaderText)
        .text(name, PDFConstants.Size.MarginLeft, doc.y, {width: 540});
    PDFHelper.nextLine(doc, 5);
    doc
        .lineWidth(2)
        .moveTo(PDFConstants.Size.MarginLeft, doc.y)
        .lineTo(576, doc.y)
        .stroke(PDFConstants.Color.Underline);
    doc.lineWidth(1);
    PDFHelper.nextLine(doc, 5);
}
function sectionHeader(doc, tabName) {
    PDFHelper.nextLine(doc, 10);
    if (tabName) {
        doc
            .font(PDFConstants.Font.OpenSansSemibold)
            .fontSize(PDFConstants.FontSize.Medium)
            .fill(PDFConstants.Color.HeaderText)
            .text(tabName, PDFConstants.Size.MarginLeft, doc.y, {width: 540});
        PDFHelper.nextLine(doc, 5);
    }
    doc
        .lineWidth(2)
        .moveTo(PDFConstants.Size.MarginLeft, doc.y)
        .lineTo(576, doc.y)
        .stroke(PDFConstants.Color.Underline);
    doc.lineWidth(1);
    PDFHelper.nextLine(doc, 5);
}
function renderManagerNotes(doc, notes, userAvatarBuffers) {
    var docY;
    doc
        .fontSize(PDFConstants.FontSize.Medium)
        .fill(PDFConstants.Color.HeaderText)
        .font(PDFConstants.Font.OpenSansItalic)
        .text(i18nHelper.translate(Lang, "pdf.mnt"), PDFConstants.Size.MarginLeft, doc.y, {width: 100});
    PDFHelper.nextLine(doc, 25);
    notes.forEach(function (note) {
        docY = doc.y;
        PDFHelper.generateAvatar(doc, note.UserId, userAvatarBuffers, PDFConstants.Size.CommentImage);
        doc
            .fontSize(PDFConstants.FontSize.Small)
            .fill(PDFConstants.Color.RegularText)
            .font(PDFConstants.Font.OpenSansRegular)
            .text(note.Notes, PDFConstants.Size.MarginAnswer + 30, docY, {width: PDFConstants.Size.LabelWidth});
    });
    PDFHelper.nextLine(doc, 20);
}
function sectionBody(doc, section, badgeImages, userAvatarBuffers) {
    var auxiliaryDataFactory,
        answerFactory,
        len = section.AuxiliaryData.length,
        auxiliaryType = section.Type;

    if ([FeedbackEnums.SectionType.CycleGoal, FeedbackEnums.SectionType.AdhocGoal].indexOf(auxiliaryType) > -1) {
        auxiliaryType = 'Goals';
    }

    if (Array.isArray(section.AuxiliaryData) && section.AuxiliaryData.length) {
        section.AuxiliaryData.forEach(function (auxi, ind) {
            auxiliaryDataFactory = new RenderAuxiliaryData(doc, auxi, badgeImages, userAvatarBuffers);
            if (typeof auxiliaryDataFactory[auxiliaryType] === 'function') {
                auxiliaryDataFactory[auxiliaryType]({index: ind + 1, total: len});
            }
        });
    } else if (typeof section.AuxiliaryData === 'object' && section.AuxiliaryData.hgId) {
        auxiliaryDataFactory = new RenderAuxiliaryData(doc, section.AuxiliaryData, badgeImages, userAvatarBuffers);
        if (typeof auxiliaryDataFactory[auxiliaryType] === 'function') {
            auxiliaryDataFactory[auxiliaryType]({singleGoal: true});
        }
    } else if (auxiliaryType === 'Goals') {
        doc
            .font(PDFConstants.Font.OpenSansRegular)
            .fontSize(PDFConstants.FontSize.Medium)
            .fill(PDFConstants.Color.RegularText)
            .text(i18nHelper.translate(Lang, 'pdf.ngs'), PDFConstants.Size.MarginLeft, doc.y, {width: 540});
        PDFHelper.nextLine(doc, 15);
    }
    doc
        .font(PDFConstants.Font.OpenSansBold)
        .fontSize(PDFConstants.FontSize.Medium)
        .fill(PDFConstants.Color.HeaderText)
        .text(i18nHelper.translate(Lang, 'pdf.qaa'), PDFConstants.Size.MarginLeft, doc.y, {width: 540});
    PDFHelper.nextLine(doc, 15);
    section.Questions.forEach(function (question) {
        answerFactory = new RenderAnswer(doc, question);
        question.Answers.forEach(function (answer) {
            answerFactory[question.Type](answer);
        });
        if (question.PdfManagerNotes && question.PdfManagerNotes.length) {
            renderManagerNotes(doc, question.PdfManagerNotes, userAvatarBuffers);
        }
    });
    if (section.QuestionForEachGoal) {
        PDFHelper.nextLine(doc, 10);
        doc
            .moveTo(PDFConstants.Size.MarginLeft, doc.y)
            .dash(2)
            .lineTo(PDFConstants.Size.PageWidth - PDFConstants.Size.MarginLeft, doc.y)
            .stroke(PDFConstants.Color.Underline).undash();
    }
}
function GeneratePdf(doc, cycles, lang, badgeImages, userAvatarBuffers, callback) {
    var currentSection;
    Lang = lang;
    cycles.forEach(function (cycle) {
        cycleHeader(doc, cycle.CycleTitle);
        cycle.Card.Tabs.forEach(function (tab) {
            sectionHeader(doc, tab.name);
            tab.sectionIds.forEach(function (section) {
                currentSection = cycle.Card.Sections.find(function (sec) { return sec.hgId === section.hgId; });
                if (currentSection) {
                    sectionBody(doc, currentSection, badgeImages, userAvatarBuffers);
                }
            });
        });
    });
    callback();
}

module.exports = {
    GeneratePdf: GeneratePdf
};
