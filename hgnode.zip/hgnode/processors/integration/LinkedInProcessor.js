/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    LinkedInProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EventEmitterCache = this.EventEmitterCache,
            EventResponder = require('../../util/EventResponder.js'),
            Keystore = require('../../configurations/keystore.js'),
            HgError = require('../../common/HgError.js'),
            Logger = require('../../framework/HgLog.js'),
            ParamUtil = require('../../util/params.js'),
            Config = require('../../configurations/config.js'),
            https = require('https'),
            xml2js = require('xml2js');

        function getObjectFromXMLResponse(responseXML, callback) {
            var xmlParser = new xml2js.Parser(),
                cleanedString = responseXML.replace("\ufeff", ""); // Remove BOD, sax doesn't like it.
            xmlParser.parseString(cleanedString, function (error, result) {
                if (!error) {
                    callback(null, result);
                } else {
                    callback(error, result);
                }
            });
        }

        function sendLinkedInAPIRequest(host, path, requestBody, isJSONResponse, callback) {
            if (!requestBody) {
                requestBody = '';
            }
            var loginOptions = {
                    host: host,
                    path: path,
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/xml',
                        'Content-Length': requestBody.length
                    }
                },
                linkedInRequest = https.request(loginOptions, function (response) {
                    var httpResponse = '';
                    response.setEncoding('utf8');
                    response.on('data', function (dataChunk) {
                        httpResponse += dataChunk;
                    });
                    response.on('end', function () {
                        if (isJSONResponse) {
                            try {
                                httpResponse = JSON.parse(httpResponse);
                                callback(null, httpResponse);
                            } catch (linkedinError) {
                                Logger.error('Error parsing LinkedIn JSON: ' + linkedinError + '. LinkedIn response: ' + httpResponse);
                                callback('Error parsing LinkedIn JSON: ' + httpResponse);
                            }
                        } else {
                            getObjectFromXMLResponse(httpResponse, callback);
                        }
                    });
                }).on('error', function (error) {
                    callback(error, null);
                });
            linkedInRequest.write(requestBody);
            linkedInRequest.end();
        }

        this.GenerateAuthorizationCodeUrl = function (params, callback) {
            var redirectUrl = 'https://' + Config.linkedin.oauthhost + Config.linkedin.oauthpath.authorization;
            redirectUrl += '?response_type=code';
            redirectUrl += '&client_id=' + Keystore.linkedin.api_key;
            redirectUrl += '&scope=w_share';
            redirectUrl += '&state=' + params.correlationId;
            redirectUrl += '&redirect_uri=' + Config.protocol + Config.baseUrl + 'svc/SSO/LinkedInAuthCodeResponse';
            callback(null, {url: redirectUrl, state: params.correlationId});
        };

        this.RequestAccessToken = function (params) {
            if (ParamUtil.checkForRequiredParameters(['AuthCode'], params)) {
                var oauthpath = Config.linkedin.oauthpath.accessToken;
                oauthpath += '?grant_type=authorization_code';
                oauthpath += '&code=' + params.AuthCode;
                oauthpath += '&redirect_uri=' + Config.protocol + Config.baseUrl + 'svc/SSO/LinkedInAuthCodeResponse';
                oauthpath += '&client_id=' + Keystore.linkedin.api_key;
                oauthpath += '&client_secret=' + Keystore.linkedin.secret_key;
                sendLinkedInAPIRequest(Config.linkedin.oauthhost, oauthpath, null, true, function (error, returnData) {
                    if (!error) {
                        if (!returnData.error) {
                            EventResponder.RespondWithData(EventEmitterCache, params, returnData);
                        } else {
                            Logger.warn('SSO: LinkedIn RequestAccessToken Error >>> ' + returnData.error_description);
                            EventResponder.RespondWithError(EventEmitterCache, params, returnData.error);
                        }
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, error);
                    }
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
            }
        };

        this.PostToSocialFeed = function (params) {
            if (ParamUtil.checkForRequiredParameters(['AccessToken', 'Comment', 'Title', 'Description'], params)) {
                var host = Config.linkedin.api.host,
                    path = Config.linkedin.api.share + '?oauth2_access_token=' + params.AccessToken,
                    requestBody = '<share>';
                requestBody += '  <comment>' + params.Comment + '</comment>';
                requestBody += '    <content>';
                requestBody += '    <title>' + params.Title + '</title>';
                requestBody += '    <description>' + params.Description + '</description>';
                requestBody += params.SubmittedUrl ? '    <submitted-url>' + params.SubmittedUrl + '</submitted-url>' : '';
                requestBody += params.SubmittedImageUrl ? '    <submitted-image-url>' + params.SubmittedImageUrl + '</submitted-image-url>' : '';
                requestBody += '  </content>';
                requestBody += '  <visibility>';
                requestBody += '    <code>anyone</code>';
                requestBody += '  </visibility>';
                requestBody += '</share>';

                sendLinkedInAPIRequest(host, path, requestBody, false, function (error, returnData) {
                    if (!error) {
                        if (!returnData.error) {
                            Logger.debug('Success posting to LinkedIn social feed API: ' + JSON.stringify(returnData));
                            EventResponder.RespondWithData(EventEmitterCache, params, returnData);
                        } else {
                            Logger.warn('LinkedIn API Error: ' + JSON.stringify(returnData));
                            EventResponder.RespondWithError(EventEmitterCache, params, 'Error in request');
                        }
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, error);
                    }
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
            }
        };
    };

module.exports = LinkedInProcessor;