/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    FacebookProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EventEmitterCache = this.EventEmitterCache,
            EventResponder = require('../../util/EventResponder.js'),
            Keystore = require('../../configurations/keystore.js'),
            Config = require('../../configurations/config.js');

        this.GenerateAuthorizationCodeUrl = function (params) {
            var redirectUrl = 'https://' + Config.linkedin.oauthhost + Config.linkedin.oauthpath.authorization;
            redirectUrl += '?response_type=code';
            redirectUrl += '&client_id=' + Keystore.linkedin.api_key;
            redirectUrl += '&scope=rw_nus';
            redirectUrl += '&state=' + params.correlationId;
            redirectUrl += '&redirect_uri=' + Config.protocol + Config.baseUrl + 'svc/SSO/LinkedInAuthCodeResponse';
            EventResponder.RespondWithData(EventEmitterCache, params, {url: redirectUrl, state: params.correlationId});
        };
    };

module.exports = FacebookProcessor;