/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    TangoProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var https = require('https'),
            uuid = require('node-uuid'),
            eventEmitter = this.EventEmitterCache,
            HgLog = require('../../framework/HgLog.js'),
            hgError = require('../../common/HgError.js'),
            EntityCache = require('../../framework/EntityCache.js'),
            httpResponseCodes = require('../../enums/HttpResponseCodes.js'),
            ProcessorHelper = require('../../util/ProcessorHelper.js'),
            eventResponder = require('../../util/EventResponder.js'),
            paramUtil = require('../../util/params.js'),
            keystore = require('../../configurations/keystore.js'),
            config = require('../../configurations/config.js'),
            tangoApiVersion = '/raas/v1/',
            Async = require('async'),
            httpMethod = {
                GET: 'GET',
                POST: 'POST'
            },
            self = this;

        function createFilterString(params) {
            var filterString = '';
            if (params.start_date) {
                filterString = filterString + '&start_date=' + params.start_date;
            }
            if (params.end_date) {
                filterString = filterString + '&end_date=' + params.end_date;
            }
            if (params.offset) {
                filterString = filterString + '&offset=' + params.offset;
            }
            if (params.limit) {
                filterString = filterString + '&limit=' + params.limit;
            }
            if (params.account_identifier) {
                filterString = filterString + '&account_identifier=' + params.account_identifier;
            }
            if (params.customer) {
                filterString = filterString + '&customer=' + params.customer;
            }
            if (filterString.length > 0 && filterString.substring(0, 1) === '&') {
                filterString = filterString.substring(1);
            }
            return filterString;
        }

        function sendRequest(resource, method, requestData, callback) {
            if (!resource || !method || !callback) {
                callback('Resource, method, or callback is missing from sendRequest() call in TangoProcessor.');
            } else {
                if (!requestData) {
                    requestData = '';
                } else {
                    requestData = JSON.stringify(requestData);
                }
                var request,
                    requestOptions = {
                        hostname: config.tango.host,
                        path: tangoApiVersion + resource,
                        auth: keystore.tango.platform + ':' + keystore.tango.key,
                        method: method,
                        headers: {
                            'Content-Type': 'application/json',
                            'Content-Length': requestData.length
                        }
                    },
                    responseData = '';
                request = https.request(requestOptions, function (response) {
                    response.on('data', function (dataChunk) {
                        responseData += dataChunk;
                    }).on('end', function () {
                        try {
                            responseData = JSON.parse(responseData);
                        } catch (tangoError) {
                            HgLog.error('Error parsing Tango JSON: ' + tangoError + '. Tango response: ' + responseData);
                            return callback('Error parsing Tango JSON: ' + responseData);
                        }
                        if (response.statusCode === httpResponseCodes.Success.OK || response.statusCode === httpResponseCodes.Success.Created) {
                            if (responseData.system_message) {
                                HgLog.warn(responseData.system_message);
                            }
                            if (responseData.error_message) {
                                HgLog.error(responseData.error_message);
                            }
                            if (responseData.success !== true) {
                                callback('There was a problem with the request.', responseData);
                            } else {
                                callback(null, responseData);
                            }
                        } else {
                            var errorMessage = 'Tango Error';
                            errorMessage += '\nHttp Response Code: ' + response.statusCode;
                            if (response.headers['x-status-reason']) {
                                errorMessage += '\nX-Status-Reason: ' + response.headers['x-status-reason'];
                            }
                            if (responseData.error_message) {
                                errorMessage += '\nError Message: ' + responseData.error_message;
                            }
                            if (responseData.invalid_inputs) {
                                errorMessage += '\nInput Validation Errors:';
                                responseData.invalid_inputs.forEach(function (item) {
                                    errorMessage += '\n ' + item.field + ': ' + item.error;
                                });
                            }
                            if (responseData.denial_code) {
                                errorMessage += '\nDenial Code: ' + responseData.denial_code;
                            }
                            if (responseData.denial_message) {
                                errorMessage += '\nDenial Message: ' + responseData.denial_message;
                            }
                            callback(errorMessage, responseData);
                        }
                    });
                }).on('error', function (error) {
                    HgLog.error(error);
                    callback(error);
                });
                request.write(requestData);
                request.end();
            }
        }

        function deleteAllTangoCards(callback) {
            EntityCache.TangoCard.remove({}, function (deleteError, rowsDeleted) {
                callback(deleteError, rowsDeleted);
            });
        }

        function batchImportTangoCards(tangoCards, callback) {
            if (tangoCards) {
                deleteAllTangoCards(function (deleteError) {
                    if (!deleteError) {
                        EntityCache.TangoCard.create(tangoCards, function (saveError) {
                            callback(saveError);
                        });
                    } else {
                        callback(deleteError);
                    }
                });
            } else {
                callback(new Error('No data passed in for tango card import.'));
            }
        }
        function getTangoCharityCardsByGroupId(groupId, callback) {
            EntityCache.TangoCard.find({ GroupIds: { $in: [groupId, 'all'] }, ExcludedGroupIds: { $nin: [groupId] }, Type: 'charity'}, function (findError, tangoCards) {
                callback(findError, tangoCards);
            });
        }

        function saveTangoOrder(order, callback) {
            var newTangoOrder = EntityCache.TangoCardOrder(order);
            newTangoOrder.save(function (saveError, savedOrder) {
                callback(saveError, savedOrder);
            });
        }

        function manageOneCardAsync(tangoCard, asyncCallback) {
            var condition = {
                    CardName : tangoCard.CardName,
                    Type : tangoCard.Type
                };
            EntityCache.TangoCard.findOne(condition, function (error, card) {
                if (error) {
                    asyncCallback(error);
                } else if (!card) {
                    if (tangoCard.ImageUrl && tangoCard.EmailTemplateId && tangoCard.Type) {
                        card = new EntityCache.TangoCard(tangoCard);
                        card.save();
                    }
                    asyncCallback(null);
                } else {
                    if (tangoCard.ImageUrl && tangoCard.EmailTemplateId && tangoCard.Type) {
                        card.ImageUrl = tangoCard.ImageUrl;
                        card.EmailTemplateId = tangoCard.EmailTemplateId;
                        card.Country = tangoCard.Country;
                        card.Denominations = tangoCard.Denominations;
                        card.markModified('Denominations');
                        card.save();
                        asyncCallback(null);
                    } else {//if any of above fields is missing, delete the card
                        EntityCache.TangoCard.remove({hgId: card.hgId}, function (deleteError) {
                            if (deleteError) {
                                HgLog.error({methodName: 'manageOneCardAsync', error: deleteError});
                            }
                            asyncCallback(null);
                        });
                    }
                }
            });
        }

        this.ManageCards = function (params, callback) {
            var tangoCards = params.TangoCards,
                len = tangoCards ? tangoCards.length : 0;
            Async.whilst(
                function () {
                    len -= 1;
                    return len > -1;
                },
                function (asyncCallback) {
                    manageOneCardAsync(tangoCards[len], asyncCallback);
                },
                function (err) {
                    if (err) {
                        HgLog.error({methodName: 'ManageCards', error: err});
                    }
                    callback(null, params.UserId);
                }
            );
        };

        this.GetandSetInvoicedGroupCardsPurchasedWithServiceFees = function (params, callback) {
            var key, dataRecords = {}, query = {
                CardName: { $in: params.CardNames },
                Invoiced : { $exists : false },
                CreatedDate: {
                    '$lt': params.EndDate
                }
            }, matchQuery = {
                $match : query
            }, groupQuery = {
                $group : {
                    _id : {
                        GroupId : '$GroupId',
                        CardName : '$CardName'
                    },
                    TotalCards : { $sum : 1}
                }
            };
            EntityCache.TangoCardOrder.aggregate([matchQuery, groupQuery], function (error, data) {
                if (error) { return callback('Error Finding TangoOrders'); }
                data.map(function (item) {
                    key = item._id.GroupId + '.' + item._id.CardName;
                    if (!dataRecords[key]) {
                        dataRecords[key] = item.TotalCards;
                    }
                });
                EntityCache.TangoCardOrder.update(query, {$set: {
                    Invoiced: true,
                    ModifiedDate: Date.now()
                }}, {multi : true}, function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, dataRecords);
                    }
                });
            });
        };

        this.GetCardsWithServiceFees = function (params, callback) {
            var query = {
                $and : [{ServiceFee : { $exists : true }}, {ServiceFee : { $gt : 0 }}]
            }, project = {
                _id : 0,
                CardName : 1,
                ServiceFee : 1
            };
            EntityCache.TangoCard.find(query, project, function (error, data) {
                callback(error, data);
            });
        };

        this.CreatePlatformAccount = function (params) {
            if (paramUtil.checkForRequiredParameters(['identifier', 'email', 'customer'], params)) {
                var requestData = {
                        identifier: params.identifier,
                        email: params.email,
                        customer: params.customer
                    };
                sendRequest('accounts', httpMethod.POST, requestData, function (error, data) {
                    eventResponder.RespondGeneric(eventEmitter, params, error, data, false);
                });
            } else {
                eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
            }
        };

        this.GetPlatformAccount = function (params, callback) {
            if (paramUtil.checkForRequiredParameters(['customer', 'account'], params)) {
                sendRequest('accounts/' + params.customer + '/' + params.account, httpMethod.GET, null, function (error, data) {
                    if (callback) {
                        callback(error, data);
                    } else {
                        eventResponder.RespondGeneric(eventEmitter, params, error, data, false);
                    }
                });
            } else {
                if (callback) {
                    callback(hgError.Enums.Generic.MissingParameters);
                } else {
                    eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
                }
            }
        };

        this.FundPlatformAccount = function (params) {
            if (paramUtil.checkForRequiredParameters(['customer', 'account_identifier', 'amount', 'client_ip', 'credit_card'], params)) {
                if (paramUtil.checkForRequiredParameters(['number', 'expiration', 'security_code', 'billing_address'], params.credit_card)) {
                    if (paramUtil.checkForRequiredParameters(['f_name', 'l_name', 'address', 'city', 'state', 'country', 'zip', 'email'], params.credit_card.billing_address)) {
                        var requestData = {
                                customer: params.customer,
                                account_identifier: params.account_identifier,
                                amount: params.amount,
                                client_ip: params.client_ip,
                                credit_card: params.credit_card
                            };
                        sendRequest('funds', httpMethod.POST, requestData, function (error, data) {
                            eventResponder.RespondGeneric(eventEmitter, params, error, data, false);
                        });
                    } else {
                        eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
                    }

                } else {
                    eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
                }
            } else {
                eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
            }
        };

        this.GetRewards = function (callback) {
            sendRequest('rewards', httpMethod.GET, null, function (error, data) {
                callback(error, data);
            });
        };

        this.GetTangoCardBySku = function (params, callback) {
            EntityCache.TangoCard.findOne({'Denominations.SKU' : params.SKU}, function (error, data) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, data);
                }
            });
        };

        this.PlaceOrder = function (params, callback) {
            if (paramUtil.checkForRequiredParameters(['customer', 'account_identifier', 'recipient', 'sku', 'amount', 'reward_message', 'reward_subject', 'reward_from'], params)) {
                if (paramUtil.checkForRequiredParameters(['name', 'email'], params.recipient)) {
                    var requestData = {
                            customer: params.customer,
                            account_identifier: params.account_identifier,
                            recipient: params.recipient,
                            sku: params.sku,
                            reward_message: params.reward_message,
                            reward_subject: params.reward_subject,
                            reward_from: params.reward_from,
                            send_reward: false // HighGround will be sending the reward fulfullment emails.
                        };
                    if (params.isVariableDenomination) {
                        requestData.amount = params.amount;
                    }
                    self.GetTangoCardBySku({SKU : params.sku}, function (error, tangoCard) {
                        if (error) {
                            callback(error);
                        } else if (!tangoCard) {
                            callback('Unable to Find Card with SKU:' + params.sku);
                        } else {
                            sendRequest('orders', httpMethod.POST, requestData, function (error, data) {
                                if (data.success) {
                                    data.order.UserId = params.currentuser.hgId;
                                    data.order.CreatedBy = params.currentuser.hgId;
                                    data.order.ModifiedBy = params.currentuser.hgId;
                                    data.order.GroupId = params.currentuser.UserContext.CurrentGroupId;
                                    data.order.CardName = tangoCard.CardName;
                                    data.order.CardType = tangoCard.Type;
                                    data.order.hgId = uuid.v1();
                                    saveTangoOrder(data.order, function (saveOrderError, savedOrder) {
                                        callback(error || saveOrderError, savedOrder);
                                    });
                                } else {
                                    callback(error || 'Unable to place Tango card order.');
                                }
                            });
                        }
                    });
                } else {
                    callback(hgError.Enums.Generic.MissingParameters);
                }
            } else {
                callback(hgError.Enums.Generic.MissingParameters);
            }
        };

        this.GetOrder = function (params) {
            if (paramUtil.checkForRequiredParameters(['orderId'], params)) {
                sendRequest('orders/' + params.orderId, httpMethod.GET, null, function (error, data) {
                    eventResponder.RespondGeneric(eventEmitter, params, error, data, false);
                });
            } else {
                eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
            }
        };

        this.GetOrders = function (params) {
            if (paramUtil.checkForRequiredParameters([], params)) {
                // Optional filters for this request:
                //  start_date / end_date: datetimes (ISO 8601) between which to search
                //  offset: How far into the resultset to start.
                //  limit: How many to return (maximum of 100).
                //  account_identifier: Filter to only a single platform account.
                //  customer: Filter only to a single customer.
                sendRequest('orders?' + createFilterString(params), httpMethod.GET, null, function (error, data) {
                    eventResponder.RespondGeneric(eventEmitter, params, error, data, false);
                });
            } else {
                eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
            }
        };

        this.ImportCards = function (params) {
            if (params.TangoCards && params.TangoCards.length > 0) {
                batchImportTangoCards(params.TangoCards, function (importError, result) {
                    eventResponder.RespondGeneric(eventEmitter, params, importError, result, false);
                });
            } else {
                eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
            }
        };

        this.GetAvalibleGiftCardByGroupId = function (params, callback) {
            var query = {
                    GroupIds: { $in: [params.GroupId, 'all'] },
                    ExcludedGroupIds: { $nin: [params.GroupId] },
                    Type: 'giftcard',
                    Country: {$in: params.Countries}
                };
            if (params.searchTerm && params.searchTerm.length) {
                query.CardName = {$regex: params.searchTerm, $options: 'i'};
            }
            EntityCache.TangoCard.find(query)
                .skip(parseInt(params.skip, 10) || 0)
                .limit(parseInt(params.take, 10) || 0)
                .exec(function (err, tangoCards) {
                    if (!err) {
                        callback(null, tangoCards);
                    } else {
                        callback(err);
                    }
                });
        };
        this.GetAvalibleCharityCardByGroupId = function (params) {
            if (params.GroupId) {
                getTangoCharityCardsByGroupId(params.GroupId, function (getError, tangoCards) {
                    eventResponder.RespondGeneric(eventEmitter, params, getError, tangoCards);
                });
            } else {
                eventResponder.RespondWithError(eventEmitter, params, hgError.Enums.Generic.MissingParameters, false);
            }
        };
        this.GetTangoCards = function (data, callback) {
            var query = {Type : {$ne : 'disabled'}}; //filter out disabled cards
            EntityCache.TangoCard.find(query, null, {sort : {CardName: 1}}, function (error, tangoCards) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, tangoCards);
                }
            });
        };

        this.UpdateTangoCards = function (params, callback) {
            function updateTangoCards(card, callback) {
                var fieldsToUpdate = ProcessorHelper.GetUpdateJson(params.Fields, card, params.UserId);
                EntityCache.TangoCard.update({hgId : card.hgId}, {$set: fieldsToUpdate}, function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null);
                    }
                });
            }
            if (params.Cards && params.Cards.length > 0) {
                Async.each(params.Cards, updateTangoCards, function (error) {
                    if (error) {
                        callback('Error updating Tango Card(s).');
                    } else {
                        callback(null, 'Tango Card(s) updated successfully.');
                    }
                });
            } else {
                callback(null, 'No changes to update.');
            }
        };

        this.GetGiftCardById = function (hgId, callback) {
            EntityCache.TangoCard.findOne({hgId: hgId}, function (error, card) {
                callback(error, card);
            });
        };
    };

module.exports = TangoProcessor;