/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    AuthorizeNetProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EventEmitterCache = this.EventEmitterCache,
            EventData = require('../../common/EventData.js'),
            EventResponder = require('../../util/EventResponder.js'),
            Configuration = require('../../configurations/config.js'),
            Keystore = require('../../configurations/keystore.js'),
            HgError = require('../../common/HgError.js'),
            HgLog = require('../../framework/HgLog.js'),
            https = require('https'),
            xml2js = require('xml2js'),
            parseAuthorizeNetErrorCode = function (messages) {
                var errorString = '';
                switch (messages.message[0].code[0]) {
                case 'E00027':
                    if (messages.message[0].text[0]) {
                        errorString = messages.message[0].text[0];
                    }
                    if (errorString && errorString.charAt(errorString.length - 1) !== '.') {
                        errorString += '.';
                    }
                    errorString += ' ' + HgError.Enums.Payment.TransactionFailedGenericMessage;
                    break;
                default:
                    errorString = messages.message[0].text[0];
                    break;
                }
                return errorString;
            },
            checkForError = function (response) {
                var errorString = null;
                if (Object.keys(response).indexOf('ErrorResponse') > -1) {
                    errorString = String(response.ErrorResponse.messages[0].message[0].text[0]);
                    HgLog.error(errorString);
                }
                return errorString;
            },
            getObjectFromXMLResponse = function (originalParams, responseXML, callback) {
                var xmlParser = new xml2js.Parser(),
                    cleanedString = responseXML.replace("\ufeff", ""); // Remove BOD, sax doesn't like it.
                xmlParser.parseString(cleanedString, function (error, result) {
                    if (!error) {
                        callback(null, originalParams, result);
                    } else {
                        HgLog.error(HgError.Enums.Payment.ErrorParsingXMLResponse + ' ' + error);
                        callback(error, originalParams, result);
                    }
                });
            },
            onHttpRequestError = function (error) {
                var errorMessage = HgError.Enums.Payment.HttpRequestError + ' ' + Configuration.authorizenet.cim_host + Configuration.authorizenet.cim_path + '\n' + error.message;
                HgLog.error(errorMessage);
                throw new Error(errorMessage);
            },
            sendAuthorizeNetRequest = function (originalParams, authorizeNetXMLRequest, callback) {
                var loginOptions = {
                        host: Configuration.authorizenet.cim_host,
                        path: Configuration.authorizenet.cim_path,
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/xml',
                            'Content-Length': authorizeNetXMLRequest.length
                        }
                    },
                    authorizeNetRequest = https.request(loginOptions, function (response) {
                        var httpXmlResponse = '';
                        response.setEncoding('utf8');
                        response.on('data', function (dataChunk) {
                            httpXmlResponse += dataChunk;
                        });
                        response.on('end', function () {
                            getObjectFromXMLResponse(originalParams, httpXmlResponse, callback);
                        });
                    }).on('error', onHttpRequestError);
                authorizeNetRequest.write(authorizeNetXMLRequest);
                authorizeNetRequest.end();
            },
            getMerchantAuthorizationXML = function () {
                var authObject = '\t<merchantAuthentication>\n';
                authObject += '\t\t<name>' + Keystore.authorizenet_api.loginid + '</name>\n';
                authObject += '\t\t<transactionKey>' + Keystore.authorizenet_api.key + '</transactionKey>\n';
                authObject += '\t</merchantAuthentication>\n';
                return authObject;
            },
            onCreateCustomerProfileRequestComplete = function (error, originalParams, response) {
                var newCustomerProfileId = 0,
                    returnData = {};
                if (error) {
                    EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, error));
                } else {
                    if (String(response.createCustomerProfileResponse.messages[0].resultCode) === 'Ok') {
                        newCustomerProfileId = Number(response.createCustomerProfileResponse.customerProfileId[0]);
                        returnData.AuthorizeNetCustomerProfileId = newCustomerProfileId;
                        returnData.params = originalParams;
                        EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, returnData));
                    } else {
                        HgLog.error(JSON.stringify(response.createCustomerProfileResponse.messages[0].message));
                        EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, 'server.hge.pay.eui'));
                    }
                }
            },
            createCustomerProfileRequest = function (params) {
                var customerProfileRequest;
                customerProfileRequest = '<?xml version="1.0" encoding="utf-8"?>\n';
                customerProfileRequest += '<createCustomerProfileRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">';
                customerProfileRequest += getMerchantAuthorizationXML();
                customerProfileRequest += '\t<profile>\t\t<description>' + params.hgId + '</description>\n\t\t<email>' + params.PrimaryEmail + '</email>\n\t</profile>';
                customerProfileRequest += '</createCustomerProfileRequest>';
                sendAuthorizeNetRequest(params, customerProfileRequest, onCreateCustomerProfileRequestComplete);
            },
            onCreateCCPaymentProfileRequestComplete = function (error, originalParams, response) {
                var PaymentProfileId = 0,
                    errorString = null;
                if (error) {
                    EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, error));
                } else {
                    errorString = checkForError(response);
                    if (errorString !== null) {
                        EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, errorString));
                    } else {
                        if (String(response.createCustomerPaymentProfileResponse.messages[0].resultCode) === 'Ok') {
                            PaymentProfileId = Number(response.createCustomerPaymentProfileResponse.customerPaymentProfileId[0]);
                            EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, {CustomerProfileId: originalParams.AuthorizeNetCustomerProfileId, PaymentProfileId: PaymentProfileId, hgId: originalParams.hgId, IsDefault: originalParams.NewProfile.DefaultProfile, FriendlyName: originalParams.NewProfile.FriendlyName, Type: originalParams.Type}));
                        } else {
                            HgLog.error(JSON.stringify(response.createCustomerPaymentProfileResponse.messages[0].message));
                            EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, HgError.Enums.Payment.ErrorUpdatingUserInfoWithNewCustomerProfile));
                        }
                    }
                }
            },
            createCCPaymentProfileRequest = function (params) {
                var paymentProfile = params.NewProfile,
                    paymentProfileRequest = '<?xml version="1.0" encoding="utf-8"?>\n';
                paymentProfileRequest += '<createCustomerPaymentProfileRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">\n';
                paymentProfileRequest += getMerchantAuthorizationXML();
                paymentProfileRequest += '\t<customerProfileId>' + params.AuthorizeNetCustomerProfileId + '</customerProfileId>\n';
                paymentProfileRequest += '\t<paymentProfile>\n';
                paymentProfileRequest += '\t\t<billTo>\n';
                paymentProfileRequest += '\t\t\t<firstName>' + paymentProfile.FirstName + '</firstName>\n';
                paymentProfileRequest += '\t\t\t<lastName>' + paymentProfile.LastName + '</lastName>\n';
                paymentProfileRequest += '\t\t\t<company>' + paymentProfile.Company + '</company>\n';
                paymentProfileRequest += '\t\t\t<address>' + paymentProfile.Address + '</address>\n';
                paymentProfileRequest += '\t\t\t<city>' + paymentProfile.City + '</city>\n';
                paymentProfileRequest += '\t\t\t<state>' + paymentProfile.State + '</state>\n';
                paymentProfileRequest += '\t\t\t<zip>' + paymentProfile.Zip + '</zip>\n';
                paymentProfileRequest += '\t\t\t<country>' + paymentProfile.Country + '</country>\n';
                paymentProfileRequest += '\t\t\t<phoneNumber>' + paymentProfile.Phone + '</phoneNumber>\n';
                paymentProfileRequest += '\t\t\t<faxNumber>' + paymentProfile.Fax + '</faxNumber>\n';
                paymentProfileRequest += '\t\t</billTo>\n';
                paymentProfileRequest += '\t\t<payment>\n';
                paymentProfileRequest += '\t\t\t<creditCard>\n';
                paymentProfileRequest += '\t\t\t\t<cardNumber>' + paymentProfile.CardNumber + '</cardNumber>\n';
                paymentProfileRequest += '\t\t\t\t<expirationDate>' + paymentProfile.ExpirationDate + '</expirationDate>\n';
                paymentProfileRequest += '\t\t\t</creditCard>\n';
                paymentProfileRequest += '\t\t</payment>\n';
                paymentProfileRequest += '\t</paymentProfile>\n';
                paymentProfileRequest += '</createCustomerPaymentProfileRequest>\n';
                sendAuthorizeNetRequest(params, paymentProfileRequest, onCreateCCPaymentProfileRequestComplete);
            },
            onCreateACHPaymentProfileRequestComplete = function (error, originalParams, response) {
                var PaymentProfileId = 0,
                    errorString = null;
                if (error) {
                    EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, error));
                } else {
                    errorString = checkForError(response);
                    if (errorString !== null) {
                        EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, errorString));
                    } else {
                        if (String(response.createCustomerPaymentProfileResponse.messages[0].resultCode) === 'Ok') {
                            PaymentProfileId = Number(response.createCustomerPaymentProfileResponse.customerPaymentProfileId[0]);
                            EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, {CustomerProfileId: originalParams.AuthorizeNetCustomerProfileId, PaymentProfileId: PaymentProfileId, hgId: originalParams.hgId, IsDefault: originalParams.NewProfile.DefaultProfile, FriendlyName: originalParams.NewProfile.FriendlyName, Type: originalParams.Type}));
                        } else {
                            HgLog.error(response.createCustomerPaymentProfileResponse.messages[0].message);
                            EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, HgError.Enums.Payment.ErrorUpdatingUserInfoWithNewCustomerProfile));
                        }
                    }
                }
            },
            createACHPaymentProfileRequest = function (params) {
                var paymentProfile = params.NewProfile,
                    paymentProfileRequest = '<?xml version="1.0" encoding="utf-8"?>\n';
                paymentProfileRequest += '<createCustomerPaymentProfileRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">\n';
                paymentProfileRequest += getMerchantAuthorizationXML();
                paymentProfileRequest += '\t<customerProfileId>' + params.AuthorizeNetCustomerProfileId + '</customerProfileId>\n';
                paymentProfileRequest += '\t<paymentProfile>\n';
                paymentProfileRequest += '\t\t<payment>\n';
                paymentProfileRequest += '\t\t\t<bankAccount>\n';
                paymentProfileRequest += '\t\t\t\t<accountType>' + paymentProfile.AccountType + '</accountType>\n';
                paymentProfileRequest += '\t\t\t\t<routingNumber>' + paymentProfile.RoutingNumber + '</routingNumber>\n';
                paymentProfileRequest += '\t\t\t\t<accountNumber>' + paymentProfile.AccountNumber + '</accountNumber>\n';
                paymentProfileRequest += '\t\t\t\t<nameOnAccount>' + paymentProfile.NameOnAccount + '</nameOnAccount>\n';
                paymentProfileRequest += '\t\t\t\t<bankName>' + paymentProfile.BankName + '</bankName>\n';
                paymentProfileRequest += '\t\t\t</bankAccount>\n';
                paymentProfileRequest += '\t\t</payment>\n';
                paymentProfileRequest += '\t</paymentProfile>\n';
                paymentProfileRequest += '</createCustomerPaymentProfileRequest>\n';
                sendAuthorizeNetRequest(params, paymentProfileRequest, onCreateACHPaymentProfileRequestComplete);
            },
            onDeletePaymentProfileRequestComplete = function (error, originalParams) {
                if (error) {
                    EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, null, error));
                } else {
                    EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, {params: originalParams}));
                }
            },
            deletePaymentProfileRequest = function (params) {
                var deleteProfileRequest = '<?xml version="1.0" encoding="utf-8"?>';
                deleteProfileRequest += '<deleteCustomerPaymentProfileRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">';
                deleteProfileRequest += getMerchantAuthorizationXML();
                deleteProfileRequest += '\t<customerProfileId>' + params.AuthorizeNetCustomerProfileId + '</customerProfileId>';
                deleteProfileRequest += '\t<customerPaymentProfileId>' + params.AuthorizeNetPaymentProfileId + '</customerPaymentProfileId>';
                deleteProfileRequest += '</deleteCustomerPaymentProfileRequest>';
                sendAuthorizeNetRequest(params, deleteProfileRequest, onDeletePaymentProfileRequestComplete);
            },
            onCreateCustomerProfileTransactionRequestComplete = function (error, originalParams, response) {
                var directResponse = '',
                    errorString = '',
                    TransactionResult = '',
                    AuthorizationCode = '',
                    TransactionId = '',
                    dataResponse;
                if (error) {
                    EventResponder.RespondWithError(EventEmitterCache, originalParams, error);
                } else {
                    errorString = checkForError(response);
                    if (errorString !== null) {
                        EventEmitterCache.emit(originalParams.EventName, new EventData(originalParams.correlationId, {TransactionResult: 'Error'}, errorString));
                    } else {
                        if (String(response.createCustomerProfileTransactionResponse.messages[0].resultCode) === 'Ok') {
                            directResponse = String(response.createCustomerProfileTransactionResponse.directResponse).split(',');
                            TransactionResult = '';
                            AuthorizationCode = directResponse[4] || '';
                            TransactionId = directResponse[6] || '';
                            switch (directResponse[0]) {
                            case '1':
                                TransactionResult = 'Approved';
                                break;
                            case '2':
                                TransactionResult = 'Declined';
                                break;
                            case '3':
                                TransactionResult = 'Error';
                                break;
                            case '4':
                                TransactionResult = 'Held';
                                break;
                            default:
                                TransactionResult = 'Unknown';
                                break;
                            }
                            dataResponse = {
                                TransactionResult: TransactionResult,
                                AuthorizationCode: AuthorizationCode,
                                TransactionId: TransactionId
                            };
                            EventResponder.RespondWithData(EventEmitterCache, originalParams, dataResponse);
                        } else {
                            HgLog.error(response.createCustomerProfileTransactionResponse.messages[0].message[0].text[0]);
                            errorString = parseAuthorizeNetErrorCode(response.createCustomerProfileTransactionResponse.messages[0]);
                            EventResponder.RespondWithError(EventEmitterCache, originalParams, errorString);
                        }
                    }
                }
            },
            createCustomerProfileTransactionRequest = function (params) {
                var request = '<?xml version="1.0" encoding="utf-8"?>';
                request += '<createCustomerProfileTransactionRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">\n';
                request += getMerchantAuthorizationXML();
                request += '\t<transaction>\n';
                request += '\t\t<profileTransAuthCapture>\n';
                request += '\t\t\t<amount>' + params.Amount + '</amount>\n';
                request += '\t\t\t<customerProfileId>' + params.AuthorizeNetCustomerProfileId + '</customerProfileId>\n';
                request += '\t\t\t<customerPaymentProfileId>' + params.AuthorizeNetPaymentProfileId + '</customerPaymentProfileId>\n';
                if (params.CardCode !== undefined) {
                    request += '\t\t\t<cardCode>' + params.CardCode + '</cardCode>\n';
                }
                request += '\t\t</profileTransAuthCapture>\n';
                request += '\t</transaction>\n';
                request += '\t<extraOptions><![CDATA[x_customer_ip=' + params.CustomerIPAddress + ']]></extraOptions>\n';
                request += '</createCustomerProfileTransactionRequest>\n';
                sendAuthorizeNetRequest(params, request, onCreateCustomerProfileTransactionRequestComplete);
            };

        this.CreateCustomerProfile = function (params) {
            createCustomerProfileRequest(params);
        };

        this.AddCCPaymentProfile = function (params) {
            if (params.NewProfile.HgId === undefined) {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.pay.hpm'));
            }
            params.hgId = params.currentuser.hgId;
            createCCPaymentProfileRequest(params);
        };

        this.AddACHPaymentProfile = function (params) {
            if (params.NewProfile.HgId === undefined) {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.pay.hpm'));
            }
            params.hgId = params.currentuser.hgId;
            createACHPaymentProfileRequest(params);
        };

        this.DeletePaymentProfile = function (params) {
            if (params.AuthorizeNetPaymentProfileId === undefined || params.AuthorizeNetPaymentProfileId <= 0) {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'server.hge.pay.ppm'));
            } else {
                deletePaymentProfileRequest(params);
            }
        };

        this.Transact = function (params) {
            if (!params.AuthorizeNetPaymentProfileId || params.Amount === undefined || params.ClientIPAddress === undefined) {
                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.pay.tpm');
            } else {
                createCustomerProfileTransactionRequest(params);
            }
        };
    };

module.exports = AuthorizeNetProcessor;