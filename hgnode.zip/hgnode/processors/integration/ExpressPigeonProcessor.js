/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    ExpressPigeonProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EventEmitterCache = this.EventEmitterCache,
            EventData = require('../../common/EventData.js'),
            Keystore = require('../../configurations/keystore.js'),
            https = require('https'),
            request = require('request'),
            csv = require('csv-stream'),
            qs = require('querystring');

        this.GetMessages = function (params) {
            var originalParams = params.query,
                path = 'https://api.expresspigeon.com/messages',
                authKey = Keystore.expresspigeon_api,
                url;

            originalParams.auth_key = authKey;
            url = path + '?' + qs.unescape(qs.stringify(originalParams));

            https.get(url, function (response) {
                var epResponse = '';
                response.setEncoding('utf8');
                response.on('data', function (chunk) {
                    epResponse += chunk;
                });
                response.on('end', function () {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, epResponse));
                });
            });
        };
        this.GetSuppressedList = function (params, callback) {
            var emails = [];
            request({
                url: 'https://api.expresspigeon.com/lists/suppress_list/csv',
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-auth-key': Keystore.expresspigeon_api
                }
            }).pipe(csv.createStream({
                escapeChar: ' "',
                enclosedChar: '"'
            })).on('data', function (item) {
                emails.push(item);
            }).on('end', function () {
                callback(null, emails.map(function (item) {
                    return {
                        Email: item.Email
                    };
                }));
            });
        };
    };

module.exports = ExpressPigeonProcessor;