/*jslint node:true es5:true*/

var HgBaseProcessor = require('../framework/HgProcessor.js'),
    WishListProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var uuid = require('node-uuid'),
            EntityCache = require('../framework/EntityCache.js'),
            WishListItemStatus = require('../enums/EntityEnums').WishListItemStatus;

        this.CreateWish = function (params, callback) {
            var wishList, newRankList;
            EntityCache.Wish.findOne({GroupId: params.GroupId, MemberId: params.MemberId, 'Item.Id': params.Item.Id, Status: WishListItemStatus.Active}, function (error, match) {
                if (error) {
                    callback(error);
                } else if (match) {
                    callback('srv.wsh.err.dup');
                } else {
                    EntityCache.WishListItemRanking.findOne({GroupId: params.GroupId, MemberId: params.MemberId}, function (error, rankList) {
                        if (error) {
                            callback(error);
                        } else {
                            wishList = new EntityCache.Wish({
                                hgId: uuid.v1(),
                                MemberId: params.MemberId,
                                GroupId: params.GroupId,
                                Type: params.Item.Type,
                                Item: {
                                    Id: params.Item.Id,
                                    Name: params.Item.Name
                                }
                            });
                            if (!rankList) {
                                newRankList = new EntityCache.WishListItemRanking({
                                    MemberId: params.MemberId,
                                    GroupId: params.GroupId,
                                    RankingList: [{
                                        ItemId: params.Item.Id,
                                        Rank: 0
                                    }]
                                });
                                newRankList.save(function (error) {
                                    if (error) {
                                        callback(error);
                                    } else {
                                        wishList.save(function (error) {
                                            if (error) {
                                                return callback(error);
                                            }
                                            callback(null, {Rank: newRankList, Wish: wishList});
                                        });
                                    }
                                });
                            } else {
                                rankList.RankingList.push({
                                    Rank: 0,
                                    ItemId: params.Item.Id
                                });
                                rankList.save(function (error) {
                                    if (error) {
                                        callback(error);
                                    } else {
                                        wishList.save(function (error) {
                                            if (error) {
                                                return callback(error);
                                            }
                                            callback(null, {Rank: rankList, Wish: wishList});
                                        });
                                    }
                                });
                            }
                        }
                    });
                }
            });
        };
        this.GetWishRank = function (params, callback) {
            var i, len, rank;
            EntityCache.WishListItemRanking.findOne({GroupId: params.GroupId, MemberId: params.MemberId}, function (error, list) {
                if (error) {
                    return callback(error);
                }
                if (!list) {
                    return callback('srv.wsh.err.nwi');
                }
                for (i = 0, len = list.RankingList.length; i < len; i += 1) {
                    if (list.RankingList[i].ItemId === params.ItemId) {
                        rank = list.RankingList[i].Rank;
                        break;
                    }
                }
                callback(null, rank);
            });
        };
        this.GetWishListByMemberId = function (params, callback) {
            EntityCache.Wish.find({GroupId: params.GroupId, MemberId: params.MemberId, Status: params.Status})
                .skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (error, list) {
                    if (error) {
                        callback(error);
                    } else {
                        EntityCache.WishListItemRanking.findOne({GroupId: params.GroupId, MemberId: params.MemberId}, function (error, ranking) {
                            if (error) {
                                return callback(error);
                            }
                            callback(null, {Rank: ranking, List: list});
                        });
                    }
                });
        };
        this.GetWishListItemRanking = function (params, callback) {
            EntityCache.WishListItemRanking.findOne({GroupId: params.GroupId, MemberId: params.MemberId}, function (error, ranking) {
                if (error) {
                    return callback(error);
                }
                callback(null, ranking);
            });
        };
        this.UpdateWishListRank = function (params, callback) {
            // sorts the ranking of each item in the RankingList array
            var reorderRankings = function (rankList) {
                    // start and end are the rank of the wish in the rank array
                    // rmin and rmax are the range on which the rank array is sorted,
                    // sign is the direction in which the list will be sorted, barring the initial element
                    var sign,
                        rmin = params.Start < params.End ? params.Start : params.End,
                        rmax = params.Start > params.End ? params.Start : params.End;
                    sign = (params.Start < params.End) ? -1 : 1;

                    if (params.isInserted) {
                        sign = 1;
                    }
                    if (params.isRemoved) {
                        rmax = rankList.length;
                    }
                    rankList.forEach(function (item) {
                        if (params.StartId === item.ItemId) {
                            // if the id of the initial element is the one in the list, set rank of item to intended rank
                            item.Rank = params.End;
                        } else if ((item.ItemId !== params.InsertedId) && (item.ItemId !== params.StartId) &&
                                (item.Rank >= rmin) && (item.Rank <= rmax)) {
                            // if this item is not being inserted into the list, and
                            // if the item is within the range of the ranks that need to be reordered
                            // move each rank by 1 in the direction of the sort
                            item.Rank += sign;
                        }
                    });
                    return rankList;
                },
                splice;
            EntityCache.WishListItemRanking.findOne({GroupId: params.GroupId, MemberId: params.MemberId}, function (error, itemRanking) {
                var i, len;
                if (error) {
                    return callback(error);
                }
                if (params.isRemoved) {
                    params.End = itemRanking.RankingList.length - 1;
                    // set splice equal to the index of the wish item that will be removed
                    for (i = 0, len = itemRanking.RankingList.length; i < len; i += 1) {
                        if (!params.Start && itemRanking.RankingList[i].ItemId === params.ItemId) {
                            params.Start = itemRanking.RankingList[i].Rank;
                        }
                        if (itemRanking.RankingList[i].Rank === params.Start) {
                            splice = i;
                            break;
                        }
                    }
                    itemRanking.RankingList.splice(splice, 1);
                }
                itemRanking.RankingList = reorderRankings(itemRanking.RankingList);
                itemRanking.save(function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, true);
                });
            });
        };
        this.FulfillWish = function (params, callback) {
            EntityCache.Wish.update({GroupId: params.GroupId, hgId: params.ListId, Status: WishListItemStatus.Active},
                {$set: {Status: WishListItemStatus.Fulfilled, FulfillmentMemberId: params.GifterId}},
                function (error, data) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, true);
                });
        };
        this.GetWishByItemId = function (params, callback) {
            EntityCache.Wish.findOne({GroupId: params.GroupId, MemberId: params.MemberId, Status: WishListItemStatus.Active, 'Item.Id': params.ItemId}, function (error, match) {
                if (error) {
                    callback(error);
                } else {
                    EntityCache.WishListItemRanking.findOne({GroupId: params.GroupId, MemberId: params.MemberId}, function (error, rank) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, {Rank: rank, Wish: match});
                    });
                }
            });
        };
        this.RemoveFromWishList = function (params, callback) {
            EntityCache.Wish.update({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                'Item.Id': params.ItemId,
                Status: WishListItemStatus.Active
            }, {$set: {
                ModifiedDate: Date.now(),
                Status: WishListItemStatus.Deleted
            }}, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, true);
            });
        };
    };

module.exports = WishListProcessor;
