/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    PerformanceProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var PDF = require('pdfkit'),
            config = require('../../configurations/config.js'),
            EntityEnums = require('../../enums/EntityEnums.js'),
            HgLog = require('../../framework/HgLog'),
            https = require('https'),
            htmlToText = require('html-to-text'),
            fs = require('fs'),
            docBuffers,
            processElement = require('../../util/SvgHelper.js'),
            parseXml = require('xml2js').parseString,
            Async = require('async'),
            ColorHelper = require('../../util/ColorHelper.js'),
            i18nHelper = require('../../helpers/i18nHelper.js'),
            generators = require('./ReviewGenerators.js'),
            lang,
            isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1;

        this.GenerateReviewPdf = function (params, serviceCallback) {
            params.doc = new PDF({
                info: {
                    Title: params.Cycle.Title,
                    Author: 'HighGround Enterprise Solutions, Inc.',
                    Producer: 'HighGround Enterprise Solutions, Inc.'
                },
                size: 'letter',
                margins: {
                    top: 36,
                    bottom: 48,
                    left: 24,
                    right: 24
                },
                bufferPages: true
            });
            lang = params.lang;
            this.GenerateReviewPdf_Internal(params, serviceCallback);
        };

        this.GenerateReviewPdf_Internal = function (params, serviceCallback) {
            var review = params.Review,
                goalsData = params.GoalsData,
                cycle = params.Cycle,
                doc = params.doc,
                headerColor = '#2F3D44',
                whiteTextColor = '#ffffff',
                cardTextColor = '#666666',
                underlineColor = '#bbbbbb',
                lightShade = '#eeeeee',
                errorTextColor = '#af111c',
                subheadTextColor = '#868686',
                ratingScaleDarkColor = '#2b3538',
                ratingScaleTableRowColor = '#f4f4f4',
                startColor = new ColorHelper.RgbColor(231, 144, 155),
                endColor = new ColorHelper.RgbColor(117, 206, 165),
                pageWidth = 612,
                pageHeight = 792,
                marginLeft = 36,
                topMargin = 36,
                pageBreak = 684,
                answerMargin = marginLeft + 26,
                ratingScaleAnswerWidth = pageWidth - marginLeft - answerMargin,
                ratingScaleTableRowIdx = 0,
                sectionBreakThreshold = 611,
                reviewee = null,
                answerFactory = {},
                badgeImages = [],
                answerColorMatrix = {},
                userAvatarBuffers = {},
                reviewAvatarId,
                hasScaleRating = false,
                tzo = parseInt((params.tz || 0), 10),
                peepKey = {
                    Subject: i18nHelper.translate(lang, 'common.rwe'),
                    Manager: i18nHelper.translate(lang, 'common.mgr'),
                    Peer: i18nHelper.translate(lang, 'pdf.rev.peer')
                },
                preTranslated = {
                    Level: i18nHelper.translate(lang, 'pdf.rev.levl'),
                    Noma: i18nHelper.translate(lang, 'pdf.rev.noma'),
                    Noco: i18nHelper.translate(lang, 'pdf.rev.noco'),
                    Not: i18nHelper.translate(lang, 'common.not'),
                    Nore: i18nHelper.translate(lang, 'pdf.rev.nore'),
                    Re: i18nHelper.translate(lang, 'common.re'),
                    Recc: i18nHelper.translate(lang, 'pdf.rev.recc'),
                    Com: i18nHelper.translate(lang, 'pdf.rev.com'),
                    Has: i18nHelper.translate(lang, 'pdf.rev.has'),
                    Ntay: i18nHelper.translate(lang, 'pdf.rev.ntay'),
                    Trep: i18nHelper.translate(lang, 'pdf.rev.trep'),
                    Avg: i18nHelper.translate(lang, 'admin.sur.res.avg'),
                    Rvqu: i18nHelper.translate(lang, 'pdf.rev.rvqu'),
                    Hges: i18nHelper.translate(lang, 'pdf.rev.hges'),
                    Sign: i18nHelper.translate(lang, 'pdf.rev.sign'),
                    Cmt: i18nHelper.translate(lang, 'common.cmt')
                };

            function getPeepString(peepType) {
                return peepKey[peepType] || peepType;
            }

            function setPageBreak(params) {
                var thePageBreak = pageBreak,
                    didBreak = false,
                    altCondition = false;
                if (params.pageBreak) {
                    thePageBreak = params.pageBreak;
                }
                if (params.condition) {
                    altCondition = params.condition();
                }
                if (doc.y > thePageBreak || altCondition) {
                    doc.addPage();
                    didBreak = true;
                    if (params.x) {
                        doc.x = params.x;
                    }
                    if (params.y) {
                        doc.y = params.y;
                    }
                    if (params.callback) {
                        params.callback();
                    }
                }
                return didBreak;
            }

            function formatDateString(theDate) {
                if (!isNaN(theDate)) {
                    theDate = new Date(theDate);
                }
                if (theDate instanceof Date) {
                    theDate.setMinutes(theDate.getMinutes() - tzo);
                    theDate = theDate.getMonth() + 1 + '/' + theDate.getDate() + '/' + theDate.getFullYear();
                }
                return theDate;
            }

            function truncateLongString(text, width) {
                var startLen = text.length;
                while (doc.widthOfString(text + '...') > width) {
                    text = text.substring(0, text.length - 1);
                }
                return text + (startLen === text.length ? '' : '...');
            }

            function sanitizeTextString(text) {
                if (text) {
                    text = text.replace(/•/g, '\u2022 ')
                        .replace(/\t/g, '')
                        .replace(/\r\n/g, '\n')
                        .replace(/<div/g, '<br');
                }
                return text;
            }

            // this adds linefeeds where needed, including blank lines
            function outputStringParts(text, width) {
                var parts,
                    i,
                    len;
                if (text) {
                    parts = text.split('\n');
                    for (i = 0, len = parts.length; i < len; i += 1) {
                        if (!parts[i]) {
                            parts[i] = ' ';
                        }
                        if (width) {
                            doc.font('OpenSans-Regular').text(parts[i], {
                                width: width
                            });
                        } else {
                            doc.font('OpenSans-Regular').text(parts[i]);
                        }
                    }
                }
            }

            function generateReviewHeader() {
                doc.rect(0, 0, 612, 60).fill(headerColor);
                doc.font('OpenSans-Semibold').fontSize(12).fill(whiteTextColor).text(truncateLongString(sanitizeTextString(review.CycleName), 540), marginLeft, 20, {width: 540});
                doc.font('OpenSans-Italic').text(sanitizeTextString(review.Card.GroupName), marginLeft, 36, {width: 540});
            }

            function renderAvatarFile(params) {
                try {
                    doc.image(params.path, params.x, params.y, params.attr);
                } catch (ex) {
                    HgLog.debug(ex);
                    doc.image('./static/css/images/boy.jpg', params.x, params.y, params.attr);
                }
            }

            function generateAvatarImage(docY, height, memberId) {
                var user,
                    avatarPath,
                    avatarRadius = 20;
                if (isLocal) {
                    user = review.Peoples.find(function (peep) {
                        return peep.MemberId === memberId;
                    });
                    if (user) {
                        avatarPath = './static' + config.s3store.imageStore[config.nextIndex()] + '/user/' + user.UserId + '.jpg';
                    }
                } else if (userAvatarBuffers[memberId]) {
                    avatarPath = userAvatarBuffers[memberId];
                } else {
                    avatarPath = './static/css/images/boy.jpg';
                }
                if (memberId === reviewAvatarId && !height) {
                    doc.circle(marginLeft + avatarRadius, docY + avatarRadius, avatarRadius).clip();
                    renderAvatarFile({
                        path: avatarPath,
                        x: marginLeft,
                        y: docY,
                        attr: {width: avatarRadius * 2}
                    });
                    doc.circle(marginLeft + avatarRadius, docY + avatarRadius, avatarRadius).stroke();
                } else {
                    renderAvatarFile({
                        path: avatarPath,
                        x:  answerMargin + 10,
                        y: docY,
                        attr: {height: height}
                    });
                }
            }

            function generateCardHeader() {
                var subject = [],
                    manager = [],
                    participants = [],
                    participantsList,
                    docY,
                    avatarRadius = 20,
                    infoX,
                    infoLabel = [
                        {
                            text: i18nHelper.translate(lang, 'pdf.rev.name'),
                            h: 1
                        },
                        {
                            text: i18nHelper.translate(lang, 'common.posi'),
                            h: 1
                        },
                        {
                            text: i18nHelper.translate(lang, 'common.mgr'),
                            h: 1
                        },
                        {
                            text: i18nHelper.translate(lang, 'pdf.rev.revp'),
                            h: 1
                        },
                        {
                            text: i18nHelper.translate(lang, 'pdf.rev.subd'),
                            h: 1
                        },
                        {
                            text: i18nHelper.translate(lang, 'pdf.rev.part'),
                            h: 2
                        }
                    ],
                    i,
                    len,
                    yIdx,
                    yLine = 0,
                    headerHeight = 0;

                doc.font('OpenSans-Bold').fontSize(20).fill(cardTextColor).text(sanitizeTextString(review.Card.Title), marginLeft, 70, {width: 540});
                doc.moveTo(marginLeft, doc.y + 6).lineTo(576, doc.y + 6).stroke(underlineColor);

                review.Peoples.forEach(function (peep) {
                    switch (peep.PeopleType) {
                    case 'Subject':
                        subject.push(peep);
                        break;
                    case 'Manager':
                        manager.push(peep);
                        break;
                    default:
                        participants.push(peep);
                        break;
                    }
                });

                // require at least one subject and one manager
                if (subject.length === 1 && manager.length === 1) {
                    reviewee = subject = subject[0];
                    manager = manager[0];
                    participantsList = [];

                    // build participants list
                    for (i = 0, len = participants.length; i < len; i += 1) {
                        participantsList.push(participants[i].MemberFullname);
                    }
                    if (participantsList.length) {
                        participantsList = participantsList.join(', ');
                    } else {
                        participantsList = i18nHelper.translate(lang, 'pdf.rev.nopa');
                    }

                    docY = doc.y + 24;

                    doc.save();
                    generateAvatarImage(docY, 0, reviewAvatarId);
                    doc.restore();

                    // render subject info
                    infoX = marginLeft + avatarRadius * 2 + 10;
                    doc.font('OpenSans-Semibold').fontSize(10);
                    yIdx = 1;
                    for (i = 0, len = infoLabel.length; i < len; i += 1) {
                        yLine += infoLabel[i].h;
                        if (i > 0) {
                            yIdx = infoLabel[i - 1].h;
                        }
                        if (i % 2 === 1) {
                            doc.rect(infoX, docY + i * 24 - 8, pageWidth - infoX - 36, infoLabel[i].h * 24).fill(lightShade);
                        }
                        doc.fill(cardTextColor).text(sanitizeTextString(infoLabel[i].text), infoX + 10, docY + (i + yIdx - 1) * 24 - 4);
                    }
                    infoX += 94;
                    doc.moveTo(infoX, docY).lineTo(infoX, docY + yLine * 24 - 8).stroke(underlineColor);
                    infoX += 16;
                    doc.font('OpenSans-Regular').fill(cardTextColor);
                    infoLabel[0].value = subject.MemberFullname;
                    infoLabel[1].value = subject.Position || i18nHelper.translate(lang, 'pdf.rev.nota');
                    infoLabel[2].value = manager.MemberFullname;
                    infoLabel[3].value = formatDateString(cycle.ReviewPeriodStart) + ' - ' + formatDateString(cycle.ReviewPeriodEnd);
                    infoLabel[4].value = subject.SubmitDate ? formatDateString(subject.SubmitDate) : i18nHelper.translate(lang, 'pdf.rev.nots');
                    infoLabel[5].value = participantsList;
                    yIdx = 1;
                    for (i = 0, len = infoLabel.length; i < len; i += 1) {
                        if (i > 0) {
                            yIdx = infoLabel[i - 1].h;
                        }
                        headerHeight = docY + (i + yIdx - 1) * 24 - 4;
                        doc.font('OpenSans-Regular').text(sanitizeTextString(infoLabel[i].value), infoX, headerHeight);
                    }
                    headerHeight += 48;
                    if (doc.y < headerHeight) {
                        doc.y = headerHeight;
                    }
                }
            }

            function generateAnswerMemberName(params) {
                doc.fill(cardTextColor).font('OpenSans-Italic').fontSize(8).text(sanitizeTextString(params.answerMember), params.x, params.y, params.options);
            }

            function determineWidestTextByAnswerSelectors(answerSelectors) {
                var widest = 0,
                    i,
                    len = answerSelectors.length || 0,
                    w;
                for (i = 0; i < len; i += 1) {
                    w = Math.ceil(doc.widthOfString(answerSelectors[i].Text));
                    if (w > widest) {
                        widest = w;
                    }
                }
                return widest;
            }

            function generateAnswerText(params) {
                setPageBreak({
                    y: topMargin,
                    x: answerMargin
                });
                doc.font('OpenSans-Regular').fill(cardTextColor).fontSize(10).text('', answerMargin, doc.y + 8, {
                    width: pageWidth - marginLeft - answerMargin
                });
                outputStringParts(sanitizeTextString(params.Text));
                if (params.MemberName) {
                    doc.font('OpenSans-Italic').fontSize(8).text('- ' + params.MemberName, doc.x, doc.y, {
                        width: pageWidth - marginLeft - answerMargin,
                        align: 'right'
                    });
                }
                doc.moveTo(answerMargin, doc.y + 6).dash(2).lineTo(pageWidth - marginLeft, doc.y + 6).stroke(underlineColor).undash();
            }

            function processShapes(ele) {
                var keys = Object.keys(ele),
                    e,
                    klen =  keys.length,
                    k,
                    i,
                    len;
                for (k = 0; k < klen; k += 1) {
                    e = keys[k];
                    if (e === 'g') {
                        for (i = 0, len = ele[e].length; i < len; i += 1) {
                            if (!ele[e][i].$ || ele[e][i].$.display !== 'none') {
                                processShapes(ele[e][i]);
                            }
                        }
                    } else if (processElement[e]) {
                        processElement[e]({ele: ele[e], doc: doc});
                    } else {
                        HgLog.error('Element ' + e + ' is not supported!');
                    }
                }
            }

            function generateCommenterName(comment) {
                if (comment.CommenterFirstName || comment.CommenterLastName) {
                    return ['- ', comment.CommenterFirstName, ' ', comment.CommenterLastName, ' (', formatDateString(comment.CreatedDate), ')'].join('');
                }
                return '';
            }

            function generateTrackComments(params) {
                var trackMargin = answerMargin + 44,
                    commentMargin = trackMargin + 14,
                    commentWidth = pageWidth - marginLeft - commentMargin,
                    comments = params.Comments.filter(function (comment) {
                        if (params.EntityType === 'Milestone') {
                            return comment.Type !== 'Coaching' && comment.EntityId === params.EntityId;
                        }
                        return comment.Type === 'Coaching' && comment.EntityId === params.EntityId && comment.IncludePerformance;
                    });
                setPageBreak({
                    y: topMargin,
                    x: commentMargin
                });
                if (comments.length) {
                    doc.x = trackMargin;
                    doc.font('OpenSans-Semibold').fill(subheadTextColor).fontSize(8).text(sanitizeTextString(params.HeaderText), trackMargin, doc.y);
                    comments.forEach(function (comment) {
                        doc.font('OpenSans-Regular').fill(cardTextColor).fontSize(10).text('', commentMargin, doc.y, {
                            width: commentWidth
                        });
                        outputStringParts(htmlToText.fromString(sanitizeTextString(comment.Comment)));
                        doc.font('OpenSans-Italic').fontSize(8).text(generateCommenterName(comment), commentMargin, doc.y, {
                            width: commentWidth,
                            align: 'right'
                        });
                        doc.y += 2;
                        doc.moveTo(commentMargin, doc.y).dash(2).lineTo(pageWidth - marginLeft, doc.y).stroke(underlineColor).undash();
                        doc.y += 2;
                    });
                } else {
                    doc.font('OpenSans-Semibold').fill(subheadTextColor).fontSize(8).text('No ' + sanitizeTextString(params.HeaderText), trackMargin, doc.y);
                }
            }

            function generateTrackInfo(params) {
                var question = params.question,
                    track = [],
                    badge = [],
                    docY,
                    trackDesc,
                    trackMargin = answerMargin + 44,
                    collaborators = [],
                    answerWidth = pageWidth - marginLeft - trackMargin;
                if (review.AllTracks && review.AllTracks.length) {
                    track = review.AllTracks.filter(function (theTrack) {
                        return theTrack.hgId === question.TrackId;
                    });
                }
                if (track.length === 1) {
                    if (!question.trackRendered) {
                        setPageBreak({
                            y: topMargin,
                            x: marginLeft
                        });
                        track = track[0];
                        // render track badge and title
                        doc.y += 4;
                        badge = badgeImages.filter(function (theBadge) {
                            return theBadge.hgId === track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId;
                        });
                        if (badge.length === 1) {
                            doc.save();
                            doc.translate(doc.x, doc.y).scale(0.35);
                            processShapes(badge[0].result);
                            doc.restore();
                        }
                        // track title
                        doc.font('OpenSans-Bold').fontSize(12).fill(cardTextColor).text(sanitizeTextString(track.CareerTrackTemplate.Title) + ' (' + track.PercentAchieved + '%)', trackMargin, doc.y + 10, {
                            width: answerWidth
                        });
                        // track description
                        trackDesc = track.CareerTrackTemplate.Goal.RecognitionTemplate.Description || track.CareerTrackTemplate.Description;
                        if (trackDesc) {
                            doc.y += 3;
                            doc.font('OpenSans-Italic').fontSize(10).text('', trackMargin, doc.y, {
                                width: answerWidth
                            });
                            outputStringParts(sanitizeTextString(trackDesc));
                        }
                        // track assigner
                        doc.y += 8;
                        docY = doc.y + 1;
                        doc.font('OpenSans-Semibold').fontSize(10).text(i18nHelper.translate(lang, 'common.asg') + ': ');
                        doc.font('OpenSans-Regular').text(track.CreatorMember.FullName, trackMargin + 74, docY);
                        doc.x = trackMargin;
                        // track collaborators
                        if (track.Collaborators.length) {
                            docY = doc.y + 1;
                            doc.font('OpenSans-Semibold').fontSize(10).text(i18nHelper.translate(lang, 'common.col') + ': ');
                            track.Collaborators.forEach(function (participant) {
                                collaborators.push(participant.FullName);
                            });
                            doc.font('OpenSans-Regular').text(sanitizeTextString(collaborators.join(', ')), trackMargin + 74, docY);
                            doc.x = trackMargin;
                        }
                        // track status
                        docY = doc.y + 1;
                        doc.font('OpenSans-Semibold').fontSize(10).text(i18nHelper.translate(lang, 'common.sta') + ': ');
                        doc.font('OpenSans-Regular').text(track.Status, trackMargin + 74, docY);
                        // track due date, if exists
                        docY = doc.y + 1;
                        if (track.CareerTrackTemplate.Goal.TargetDate) {
                            doc.font('OpenSans-Semibold').fontSize(10).text(i18nHelper.translate(lang, 'common.dud') + ': ', trackMargin, docY);
                            doc.font('OpenSans-Regular').text(formatDateString(track.CareerTrackTemplate.Goal.TargetDate), trackMargin + 74, docY);
                        }
                        doc.x = trackMargin;
                        doc.y += 4;
                        doc.moveTo(trackMargin, doc.y).dash(2).lineTo(pageWidth - marginLeft, doc.y).stroke(underlineColor).undash();
                        doc.y += 4;
                        setPageBreak({
                            y: topMargin,
                            x: trackMargin
                        });

                        // goal comments and coaching notes
                        generateTrackComments({
                            Comments: track.Comments,
                            EntityType: 'Milestone',
                            EntityId: track.CareerTrackTemplate.Goal.hgId,
                            HeaderText: i18nHelper.translate(lang, 'common.cmt')
                        });
                        doc.y += 4;
                        generateTrackComments({
                            Comments: track.Comments,
                            EntityType: 'Coaching',
                            EntityId: track.CareerTrackTemplate.Goal.hgId,
                            HeaderText: i18nHelper.translate(lang, 'common.coan')
                        });
                        // milestone comments and coaching notes
                        track.CareerTrackTemplate.MileStones.forEach(function (ms) {
                            if (!setPageBreak({
                                    y: topMargin,
                                    x: trackMargin
                                })) {
                                doc.y += 6;
                            }
                            // milestone title
                            doc.circle(answerMargin + 19, doc.y + 7, 5).stroke(cardTextColor);
                            doc.font('OpenSans-Bold').fill(cardTextColor).fontSize(12).text(sanitizeTextString(ms.RecognitionTemplate.Title) + ' (' + ms.Status + ': ' + ms.PercentAchieved + '%)', trackMargin - 16, doc.y, {
                                width: answerWidth + 16
                            });
                            // milestone description
                            if (ms.RecognitionTemplate.Description) {
                                doc.y += 3;
                                doc.font('OpenSans-Italic').fontSize(8).text('', trackMargin - 16, doc.y, {
                                    width: answerWidth + 16
                                });
                                outputStringParts(sanitizeTextString(ms.RecognitionTemplate.Description));
                            }
                            doc.y += 6;
                            // milestone due date, if exists
                            if (ms.TargetDate) {
                                doc.font('OpenSans-Regular').fontSize(10).text(i18nHelper.translate(lang, 'common.dud') + ': ' +
                                    formatDateString(ms.TargetDate), trackMargin - 16, doc.y, {
                                        width: answerWidth
                                    });
                            }
                            // milestone comments
                            generateTrackComments({
                                Comments: track.Comments,
                                EntityType: 'Milestone',
                                EntityId: ms.hgId,
                                HeaderText: i18nHelper.translate(lang, 'common.cmt')
                            });
                            doc.y += 4;
                            // milestone coaching notes
                            generateTrackComments({
                                Comments: track.Comments,
                                EntityType: 'Coaching',
                                EntityId: ms.hgId,
                                HeaderText: i18nHelper.translate(lang, 'common.coan')
                            });
                        });
                        // set review comments header
                        doc.x = answerMargin;
                        doc.y += 8;
                        setPageBreak({
                            y: topMargin,
                            x: answerMargin
                        });
                        doc.font('OpenSans-Semibold').fill(cardTextColor).fontSize(10).text(i18nHelper.translate(lang, 'pdf.rev.revc'));
                        question.trackRendered = true;
                    }
                } else {
                    doc.font('OpenSans-Semibold').fontSize(10).fill(errorTextColor).text(i18nHelper.translate(lang, 'pdf.rev.notr'));
                }
            }

            function generateOneRecognition(recognition) {
                var recogMargin = answerMargin + 44,
                    recogGiverWidth = pageWidth - marginLeft - recogMargin,
                    levelname = "";
                //recognition message
                doc.y += 8;
                if (recognition.Template.Category === 'Achievement' && recognition.LevelName) {
                    levelname = [preTranslated.Level, recognition.LevelName, ': '].join(' ');
                }
                doc.font('OpenSans-Regular').fontSize(10);
                outputStringParts(sanitizeTextString(levelname + recognition.Message) || preTranslated.Noma);
                //recognition giver and date
                doc.x = recogMargin;
                if (recognition.CreatorMember.FullName || (recognition.PublicCreatorInfo && recognition.PublicCreatorInfo.FullName)) {
                    doc.font('OpenSans-Italic').fontSize(8).text('- ' + (recognition.CreatorMember.FullName || recognition.PublicCreatorInfo.FullName) + ' (' + formatDateString(recognition.CreatedDate) + ')', recogMargin, doc.y, {
                        width: recogGiverWidth,
                        align: 'right'
                    });
                    doc.y += 2;
                }
                doc.moveTo(recogMargin, doc.y).dash(2).lineTo(pageWidth - marginLeft, doc.y).stroke(underlineColor).undash();
                doc.y += 2;
            }

            function generateRecognitionsByTemplate(recognitions) {
                var recogMargin = answerMargin + 44,
                    answerWidth = pageWidth - marginLeft - recogMargin,
                    badge,
                    recognition = recognitions[0];
                setPageBreak({
                    y: topMargin,
                    x: marginLeft
                });
                // render recognition badge
                doc.y += 4;
                badge = badgeImages.filter(function (theBadge) {
                    return theBadge.hgId === recognition.BadgeFilename;
                });
                if (badge.length === 1) {
                    doc.save();
                    doc.translate(answerMargin, doc.y).scale(0.35);
                    processShapes(badge[0].result);
                    doc.restore();
                }
                // recognition title
                doc.font('OpenSans-Bold').fontSize(12).fill(cardTextColor).text(sanitizeTextString(recognition.Template.Title), recogMargin, doc.y + 10, {
                    width: answerWidth
                });
                // recognition description
                if (recognition.Template.Description) {
                    doc.y += 3;
                    doc.font('OpenSans-Italic').fontSize(10).text('', recogMargin, doc.y, {
                        width: answerWidth
                    });
                    outputStringParts(sanitizeTextString(recognition.Template.Description));
                }
                //generate all recognitions for the template
                recognitions.forEach(function (eachRecog) {
                    generateOneRecognition(eachRecog);
                });
            }

            function generateRecognitionTypeHeader(params) {
                var lineWidth;
                doc.font('OpenSans-Bold').fontSize(12).fill(cardTextColor).text(params.headerText, params.x, doc.y, {
                    width: params.w
                });
                lineWidth = Math.ceil(doc.widthOfString(params.headerText));
                doc.rect(params.x + lineWidth + 4, doc.y - 8, params.w - lineWidth + marginLeft, 4).fill(lightShade);
            }

            answerFactory.Paragraph = function (params) {
                answerFactory.ShortText(params);
            };

            answerFactory.ShortText = function (params) {
                setPageBreak({
                    y: topMargin,
                    x: answerMargin
                });
                doc.moveTo(answerMargin, doc.y).dash(2).lineTo(pageWidth - marginLeft, doc.y).stroke(underlineColor).undash();
                doc.moveTo(answerMargin, doc.y + 4);
                doc.font('OpenSans-Regular').fontSize(10).fill(cardTextColor).text('', answerMargin, doc.y + 4, {
                    width: pageWidth - marginLeft - answerMargin
                });
                outputStringParts(sanitizeTextString(params.answer.Text));
                if (params.answerMember) {
                    doc.font('OpenSans-Italic').fontSize(8).text('- ' + params.answerMember, doc.x, doc.y, {
                        width: pageWidth - marginLeft - answerMargin,
                        align: 'right'
                    });
                    doc.moveDown();
                }
            };

            answerFactory.Templated = function (params) {
                var answer = params.answer,
                    answerWidth = pageWidth - marginLeft - answerMargin;
                generateTrackInfo(params);
                // review track comments
                if (answer.Text) {
                    setPageBreak({
                        y: topMargin,
                        x: answerMargin
                    });
                    doc.font('OpenSans-Regular').fontSize(10).fill(cardTextColor).text('', doc.x, doc.y + 4);
                    outputStringParts(sanitizeTextString(answer.Text));
                    if (params.answerMember) {
                        doc.font('OpenSans-Italic').fontSize(8).text('- ' + params.answerMember, doc.x, doc.y, {
                            width: answerWidth,
                            align: 'right'
                        });
                        doc.y += 4;
                    }
                    doc.moveTo(answerMargin, doc.y).dash(2).lineTo(pageWidth - marginLeft, doc.y).stroke(underlineColor).undash();
                } else {
                    doc.font('OpenSans-Regular').fontSize(10).fill(cardTextColor).text(preTranslated.Noco, doc.x, doc.y + 4);
                }
            };

            answerFactory.Goal = function (params) {
                var answer = params.answer,
                    answerWidth = pageWidth - marginLeft - answerMargin;
                params.$ = {
                    review: review,
                    doc: doc,
                    cardTextColor: cardTextColor,
                    topMargin: topMargin,
                    answerMargin: answerMargin,
                    pageWidth: pageWidth,
                    marginLeft: marginLeft,
                    sanitizeTextString: sanitizeTextString,
                    outputStringParts: outputStringParts,
                    setPageBreak: setPageBreak,
                    Goals: goalsData
                };
                // params.Goals should contain the array of goals
                if (!params.question.GoalsRendered) {
                    generators.generateGoals(params);
                    params.question.GoalsRendered = true;
                }
                if (answer.Text) {
                    setPageBreak({
                        y: topMargin,
                        x: answerMargin
                    });
                    doc.font('OpenSans-Regular').fontSize(10).fill(cardTextColor).text('', doc.x, doc.y + 4);
                    outputStringParts(sanitizeTextString(answer.Text));
                    if (params.answerMember) {
                        doc.font('OpenSans-Italic').fontSize(8).text('- ' + params.answerMember, doc.x, doc.y, {
                            width: answerWidth,
                            align: 'right'
                        });
                        doc.y += 4;
                    }
                    doc.moveTo(answerMargin, doc.y).dash(2).lineTo(pageWidth - marginLeft, doc.y).stroke(underlineColor).undash();
                } else {
                    doc.font('OpenSans-Regular').fontSize(10).fill(cardTextColor).text(preTranslated.Noco, doc.x, doc.y + 4);
                }
            };

            answerFactory.ScaleRating = function (params) {
                var answer = params.answer,
                    ratingBoxHeight = 20,
                    answerKey,
                    answerOffset,
                    notAppAnswer = false,
                    notAppText = 'N/A',
                    numLines = 1,
                    ratingScaleSummaryDelta = 60,
                    textLeftMargin = answerMargin + ratingBoxHeight + 30,
                    answerWidth = 0,
                    maxAnswerWidth = ratingScaleAnswerWidth + ratingScaleSummaryDelta - textLeftMargin,
                    totalAnswerTextHeight = 0,
                    docY,
                    lineHeightFunc = function () {
                        return doc.y + totalAnswerTextHeight + ratingBoxHeight > pageBreak;
                    };
                doc.y += 4;
                doc.font('OpenSans-Regular').fontSize(8);
                if (answer.Text) {
                    answerWidth = Math.ceil(doc.widthOfString(answer.Text));
                    numLines = Math.ceil(answerWidth / maxAnswerWidth);
                }
                totalAnswerTextHeight = numLines * doc.currentLineHeight() + 3;
                setPageBreak({
                    condition: lineHeightFunc,
                    y: topMargin,
                    x: answerMargin
                });
                doc.font('OpenSans-Semibold').fill('#000000').fontSize(10);
                docY = doc.y;
                if (answer.Selections && answer.Selections.length > 0) {
                    answerKey = answer.Selections[0].Value;
                } else if (answer.SelectedValues && answer.SelectedValues.length > 0) {
                    answerKey = params.question.NAText;
                    notAppAnswer = true;
                }
                if (params.answerMember && (answerKey || notAppAnswer)) {
                    doc.rect(answerMargin, doc.y, ratingScaleAnswerWidth - ratingScaleSummaryDelta, ratingBoxHeight).fill((ratingScaleTableRowIdx % 2 === 0) ? ratingScaleTableRowColor : whiteTextColor);
                    if (answerColorMatrix[params.question.hgId] && answerColorMatrix[params.question.hgId][answerKey]) {
                        doc.rect(answerMargin + ratingScaleAnswerWidth - ratingScaleSummaryDelta, doc.y, ratingScaleSummaryDelta, ratingBoxHeight).fill(answerColorMatrix[params.question.hgId][answerKey]);
                    } else {
                        doc.rect(answerMargin + ratingScaleAnswerWidth - ratingScaleSummaryDelta, doc.y, ratingScaleSummaryDelta, ratingBoxHeight).fill((ratingScaleTableRowIdx % 2 === 0) ? ratingScaleTableRowColor : whiteTextColor);
                    }
                    ratingScaleTableRowIdx += 1;
                    doc.save();
                    generateAvatarImage(doc.y, ratingBoxHeight, answer.MemberId);
                    doc.restore();
                    doc.fontSize(8).fill(cardTextColor).text(sanitizeTextString(params.answerMember), textLeftMargin, docY + 4);
                    if (notAppAnswer) {
                        answerOffset = (ratingScaleSummaryDelta - doc.widthOfString(notAppText)) / 2;
                    } else {
                        answerOffset = ratingScaleSummaryDelta / 2;
                    }
                    doc.fontSize(10).text(notAppAnswer ? notAppText : answerKey, (answerMargin + ratingScaleAnswerWidth - ratingScaleSummaryDelta) + answerOffset, docY + 4);
                    if (answer.Text) {
                        doc.fill('#000000').font('OpenSans-Regular').fontSize(8).text(answer.Text, textLeftMargin, doc.y + 5, {
                            width: maxAnswerWidth,
                            align: 'left'
                        });
                    }
                }
            };

            answerFactory.ScaleRatingPlain = function (params) {
                var question = params.question,
                    answer = params.answer,
                    value,
                    ratingBoxSize = 20,
                    i,
                    len,
                    recX = marginLeft + 26,
                    recY = doc.y,
                    textColor;
                doc.font('OpenSans-Italic').fontSize(10);
                if (setPageBreak({
                        y: topMargin
                    })) {
                    recY = doc.y;
                }
                for (i = 0, len = question.AnswerSelectors.length; i < len; i += 1) {
                    value = question.AnswerSelectors[i].Value;
                    if (answer.Selections && answer.Selections[0] && answer.Selections[0].Value === value) {
                        textColor = whiteTextColor;
                        doc.rect(recX, recY, ratingBoxSize, ratingBoxSize).fill(cardTextColor).stroke(lightShade);
                    } else {
                        textColor = cardTextColor;
                        doc.rect(recX, recY, ratingBoxSize, ratingBoxSize).stroke(lightShade);
                    }
                    doc.fill(textColor).text(value, recX, recY + 3, {
                        width: ratingBoxSize,
                        align: 'center'
                    });
                    recX += ratingBoxSize;
                }
                // determine if N/A was chosen
                if (question.NAEnable) {
                    ratingBoxSize = Math.ceil(doc.widthOfString('N/A')) + 12;
                    if (answer.SelectedValues && answer.SelectedValues[0] === 'N/A') {
                        textColor = whiteTextColor;
                        doc.rect(recX, recY, ratingBoxSize, 20).fill(cardTextColor).stroke(lightShade);
                    } else {
                        textColor = cardTextColor;
                        doc.rect(recX, recY, ratingBoxSize, 20).stroke(lightShade);
                    }
                    doc.fill(textColor).text(preTranslated.Not, recX, recY + 3, {
                        width: ratingBoxSize,
                        align: 'center'
                    });
                    recX += ratingBoxSize;
                }
                if (answer.Text && answer.Text.length) {
                    generateAnswerText({Text: answer.Text, MemberName: params.answerMember});
                } else {
                    generateAnswerMemberName({
                        answerMember: params.answerMember,
                        x: recX + 4,
                        y: doc.y - 10,
                        options: {
                            width: pageWidth - marginLeft - recX
                        }
                    });
                }
                doc.moveDown(2);
            };

            answerFactory.RadioButton = function (params) {
                answerFactory.Option(params);
            };

            answerFactory.CheckBox = function (params) {
                answerFactory.Option(params);
            };

            answerFactory.Option = function (params) {
                var answer = params.answer,
                    widest,
                    widestGutter,
                    maxWidth = 300,
                    lineHeight,
                    selections = params.answer.Selections || [],
                    i,
                    len,
                    docX,
                    docY,
                    nameY,
                    totalHeight,
                    hasAnswer = answer.Text && answer.Text.length,
                    condition = doc.y > sectionBreakThreshold && hasAnswer,
                    lineHeightFunc = function () {
                        return doc.y + totalHeight > pageBreak;
                    };
                if (!setPageBreak({
                        y: topMargin,
                        x: answerMargin,
                        condition: function () {
                            return condition;
                        }
                    })) {
                    doc.y += 4;
                }
                docX = doc.x;
                docY = doc.y;
                // find widest answer and use that width to draw the rounded rectangle
                doc.font('OpenSans-Regular').fontSize(9).fill(cardTextColor);
                lineHeight = doc.currentLineHeight();
                widest = determineWidestTextByAnswerSelectors(params.question.AnswerSelectors);
                if (!widest) {
                    return;
                }
                // if the widest is actually wider than the page, then calculate the height for multi-lines
                if (widest > maxWidth) {
                    widest = maxWidth;
                }
                widestGutter = widest;
                widest += 12;
                nameY = docY;
                for (i = 0, len = selections.length; i < len; i += 1) {
                    totalHeight = Math.ceil(doc.widthOfString(selections[i].Text) / widestGutter) * lineHeight + 3;
                    if (setPageBreak({
                            y: topMargin,
                            x: answerMargin,
                            condition: lineHeightFunc
                        })) {
                        docX = doc.x;
                        docY = doc.y;
                        doc.font('OpenSans-Regular').fontSize(9).fill(cardTextColor);
                        nameY = docY;
                    }
                    doc.text('', docX + 6, docY + 3);
                    outputStringParts(sanitizeTextString(selections[i].Text), widestGutter);
                    if (doc.y > docY + 3 + totalHeight) {
                        totalHeight += lineHeight;
                    }
                    doc.roundedRect(docX, docY + 2, widest, totalHeight + 2, 7).stroke(lightShade);
                    doc.x = docX;
                    docY = docY + totalHeight + 6;
                }
                if (hasAnswer) {
                    generateAnswerText({Text: answer.Text, MemberName: params.answerMember});
                    doc.y += lineHeight;
                } else {
                    generateAnswerMemberName({
                        answerMember: params.answerMember,
                        x: docX + widest + 6,
                        y: nameY + 4,
                        options: {
                            width: pageWidth - marginLeft - widest - 6
                        }
                    });
                    doc.y = docY + 6;
                }
                if (params.question.AnswerType === EntityEnums.AnswerTypes.CheckBox && !hasAnswer) {
                    doc.moveTo(answerMargin, doc.y).dash(2).lineTo(pageWidth - marginLeft, doc.y).stroke(underlineColor).undash();
                }
                doc.x = answerMargin;
            };

            answerFactory.RecognitionDiscussion = function (params) {
                var recogMargin = answerMargin + 44,
                    answerWidth = pageWidth - marginLeft - recogMargin,
                    recognitions =  review.AllRecognitions || [],
                    recognitionsPerTemp = [],
                    len = recognitions.length,
                    categories = ['Achievement', 'Values', 'Everyday', 'External'],
                    catKeys = {
                        Achievement: i18nHelper.translate(lang, 'common.acm'),
                        Values: i18nHelper.translate(lang, 'common.val'),
                        Everyday: i18nHelper.translate(lang, 'common.eve'),
                        External: i18nHelper.translate(lang, 'common.ext')
                    },
                    recs,
                    groupedTemplate = [],
                    groupkey;
                if (len === 0) {
                    doc.font('OpenSans-Semibold').fontSize(10).fill(errorTextColor).text(preTranslated.Nore);
                } else if (!recognitions.renderedFlag) {
                    recognitions.renderedFlag = true;
                    // split everyday to internal/external
                    recognitions.map(function (r) {
                        if (r.PublicCreatorInfo.FullName) {
                            r.Template.Category = 'External';
                        }
                    });
                    categories.forEach(function (cat) {
                        recs = recognitions.filter(function (r) {
                            return r.Template.Category === cat;
                        });
                        if (recs.length > 0) {
                            groupedTemplate = []; //start from empty array
                            setPageBreak({
                                y: topMargin,
                                x: marginLeft
                            });
                            //category header
                            generateRecognitionTypeHeader({
                                headerText: [catKeys[cat], preTranslated.Re].join(' '),
                                x: answerMargin,
                                w: answerWidth
                            });
                            if (cat === "Values") {
                                recs.forEach(function (recognition) {
                                    recognitionsPerTemp = [];
                                    setPageBreak({
                                        y: topMargin,
                                        x: marginLeft
                                    });
                                    if (recognition.Template.SubValues && recognition.Template.SubValues.length > 0) {
                                        groupkey = recognition.Template.hgId + '|' + recognition.BadgeFilename;
                                        if (groupedTemplate.indexOf(groupkey) === -1) {
                                            recognitionsPerTemp = recs.filter(function (eachRecog) {
                                                return eachRecog.Template.hgId === recognition.Template.hgId && eachRecog.BadgeFilename === recognition.BadgeFilename;
                                            });
                                        }
                                    } else {
                                        groupkey = recognition.Template.hgId;
                                        if (groupedTemplate.indexOf(groupkey) === -1) {
                                            recognitionsPerTemp = recs.filter(function (eachRecog) {
                                                return eachRecog.Template.hgId === recognition.Template.hgId;
                                            });
                                        }
                                    }
                                    if (groupedTemplate.indexOf(groupkey) === -1) {
                                        groupedTemplate.push(groupkey);
                                        //generate Recognition Template section here
                                        generateRecognitionsByTemplate(recognitionsPerTemp);
                                    }
                                });
                            } else {
                                recs.forEach(function (recognition) {
                                    setPageBreak({
                                        y: topMargin,
                                        x: marginLeft
                                    });
                                    if (groupedTemplate.indexOf(recognition.Template.hgId) === -1) {
                                        groupedTemplate.push(recognition.Template.hgId);
                                        recognitionsPerTemp = recs.filter(function (eachRecog) {
                                            return eachRecog.Template.hgId === recognition.Template.hgId;
                                        });
                                        //generate Recognition Template section here
                                        generateRecognitionsByTemplate(recognitionsPerTemp);
                                    }
                                });
                            }
                        }
                    });
                    doc.moveDown();
                    doc.fontSize(10).font('OpenSans-Semibold').fill(cardTextColor).text(preTranslated.Recc, answerMargin, doc.y, {
                        width: answerWidth
                    });
                }
                answerFactory.ShortText(params);
            };

            function generateOneAnswer(params) {
                var answer = params.answer;
                if (params.question.Answers.length < 3 && params.question.AnswerType === 'ScaleRating') {
                    params.question.AnswerType += 'Plain';
                }
                if (answerFactory[params.question.AnswerType]) {
                    answerFactory[params.question.AnswerType]({
                        answer: answer,
                        question: params.question,
                        answerMember: answer.MemberName ? [answer.MemberName, ' (', getPeepString(answer.PeopleType), ')'].join('') : ''
                    });
                } else {
                    doc.font('OpenSans-Semibold').fontSize(10).fill(errorTextColor).text(i18nHelper.translate(lang, 'pdf.rev.atns', {answerType: params.question.AnswerType}));
                }
            }

            function generateScaleRatingLegend(question) {
                var answerSelectors,
                    i,
                    len,
                    legend = [];
                if (question && question.AnswerSelectors) {
                    answerSelectors = question.AnswerSelectors;
                    len = answerSelectors.length || 0;
                    doc.font('OpenSans-Regular').fontSize(8).fill(cardTextColor);
                    for (i = 0; i < len; i += 1) {
                        legend.push(answerSelectors[i].Value + ' = ' + answerSelectors[i].Text);
                    }
                    if (question.NAEnable) {
                        legend.push([preTranslated.Not, ' = ', question.NAText].join(''));
                    }
                    legend = legend.join(', ');
                    doc.font('OpenSans-Regular').text(legend).moveDown();
                }
            }

            function generateAverageScaleRating(answers) {
                var i,
                    len = answers.length,
                    answered = 0,
                    tot = 0;

                for (i = 0; i < len; i += 1) {
                    if (answers[i].Selections && answers[i].Selections[0]) {
                        answered += 1;
                        tot += answers[i].Selections[0].Value;
                    }
                }
                if (tot > 0) {
                    tot = (Math.round(tot / answered * 10) / 10).toFixed(1);
                }
                return tot;
            }

            function generateAnswerColorMatrix(question) {
                var selectors = question.AnswerSelectors || [],
                    colorArray = ColorHelper.getColorInterpolatedArray(startColor, endColor, selectors.length),
                    len,
                    i;
                answerColorMatrix[question.hgId] = {};
                for (i = 0, len = selectors.length; i < len; i += 1) {
                    answerColorMatrix[question.hgId][selectors[i].Value] = colorArray[i];
                }
            }

            function generateAnswerMatrix(question, answerMatrix) {
                var selectors = question.AnswerSelectors || [],
                    i,
                    len;
                if (question.NAEnable) {
                    answerMatrix[question.NAText] = {
                        count: 0,
                        percentage: 0,
                        percentagef: '0%'
                    };
                }
                for (i = 0, len = selectors.length; i < len; i += 1) {
                    answerMatrix[selectors[i].Value] = {
                        count: 0,
                        percentage: 0,
                        percentagef: '0%'
                    };
                }
            }

            function populateAnswerMatrixStats(question, answerMatrix) {
                var answers = question.Answers || [],
                    selectors = question.AnswerSelectors || [],
                    ansLen,
                    len,
                    i;
                if (question.NAEnable) {
                    ansLen = answers.filter(function (answer) {
                        return answer.SelectedValues[0] !== question.NAText;
                    }).length;
                } else {
                    ansLen = answers.length;
                }
                for (i = 0, len = answers.length; i < len; i += 1) {
                    if (answers[i].Selections && answers[i].Selections[0] && answerMatrix[answers[i].Selections[0].Value]) {
                        answerMatrix[answers[i].Selections[0].Value].count += 1;
                    } else if (question.NAEnable && answers[i].SelectedValues[0] === question.NAText) {
                        answerMatrix[question.NAText].count += 1;
                    }
                }
                for (i = 0, len = selectors.length; i < len; i += 1) {
                    if (answerMatrix[selectors[i].Value] && answerMatrix[selectors[i].Value].count > 0) {
                        answerMatrix[selectors[i].Value].percentage = answerMatrix[selectors[i].Value].count / ansLen;
                        answerMatrix[selectors[i].Value].percentagef = [(answerMatrix[selectors[i].Value].percentage * 100).toFixed(1).toString(), '%'].join('');
                    }
                }
                if (question.NAEnable) {
                    if (answerMatrix[question.NAText] && answerMatrix[question.NAText].count > 0) {
                        answerMatrix[question.NAText].percentage = answerMatrix[question.NAText].count / answers.length;
                        answerMatrix[question.NAText].percentagef = [(answerMatrix[question.NAText].percentage * 100).toFixed(1).toString(), '%'].join('');
                    }
                }
            }

            function generateScaleRatingLegendBarAndRuler(question, answerMatrix) {
                var selectors = question.AnswerSelectors || [],
                    rectWidth = 0,
                    docY,
                    rectStartX = answerMargin,
                    barHeight = 20,
                    textOffset = 0,
                    len,
                    i;
                doc.fill('#000000').font('OpenSans-Regular').fontSize(10);
                doc.moveDown(0.5);
                setPageBreak({
                    condition: function () {
                        return doc.y + barHeight + 18 > pageBreak;
                    },
                    y: topMargin,
                    x: answerMargin
                });
                docY = doc.y;
                for (i = 0, len = selectors.length; i < len; i += 1) {
                    if (answerMatrix[selectors[i].Value] && answerMatrix[selectors[i].Value].count > 0) {
                        rectWidth = answerMatrix[selectors[i].Value].percentage * ratingScaleAnswerWidth;
                        doc.rect(rectStartX, docY, rectWidth, barHeight).fillAndStroke(answerColorMatrix[question.hgId][selectors[i].Value], ratingScaleDarkColor);
                        textOffset = doc.widthOfString(answerMatrix[selectors[i].Value].percentagef);
                        if (textOffset < (rectWidth - 10)) {
                            doc.fill('#000000').text(answerMatrix[selectors[i].Value].percentagef, (rectStartX + rectWidth / 2 - textOffset / 2).toFixed(1), docY + 4);
                        }
                        rectStartX += rectWidth;
                    }
                }
            }

            function generateScaleRatingLegendData(question, answerMatrix) {
                var answerSelectors,
                    len,
                    i,
                    docY,
                    dynamicX = answerMargin,
                    rectWidth = 10,
                    rectHeight = 12,
                    rectToAnsTextSpace = 12,
                    pageLeftToRightMargin = pageWidth - marginLeft,
                    answerText,
                    answerTextWidth = 0,
                    condition = function () {
                        return doc.y + rectHeight > pageBreak;
                    };
                if (question && question.AnswerSelectors) {
                    answerSelectors = question.AnswerSelectors;
                    doc.font('OpenSans-Regular').fontSize(8).fill('#000000');
                    doc.moveDown(1);
                    docY = doc.y;
                    for (i = 0, len = answerSelectors.length; i < len; i += 1) {
                        answerText = [
                            answerSelectors[i].Text,
                            ' (',
                            answerMatrix[answerSelectors[i].Value] ? answerMatrix[answerSelectors[i].Value].count : 0,
                            ') ',
                            ' [',
                            answerMatrix[answerSelectors[i].Value] ? answerMatrix[answerSelectors[i].Value].percentagef : '',
                            ']'
                        ].join('');
                        answerTextWidth = doc.widthOfString(answerText);
                        if ((dynamicX + rectWidth + rectToAnsTextSpace + answerTextWidth) > pageLeftToRightMargin) {
                            doc.moveDown(0.5);
                            dynamicX = answerMargin; // reset x for new line
                            setPageBreak({
                                condition: condition,
                                y: topMargin,
                                x: answerMargin
                            });
                            docY = doc.y;
                        }
                        doc.rect(dynamicX, docY, rectWidth, rectHeight).fill(answerColorMatrix[question.hgId][answerSelectors[i].Value]);
                        doc.fill('#000000').text(answerSelectors[i].Value, dynamicX + 3, docY);
                        dynamicX += rectToAnsTextSpace;
                        doc.font('OpenSans-Regular').text(answerText, dynamicX, docY);
                        dynamicX += answerTextWidth + rectWidth;
                    }
                }
            }

            function generateScaleRatingAnswerSectionHeader() {
                doc.moveDown();
                setPageBreak({
                    condition: function () {
                        return doc.y + doc.currentLineHeight() > pageBreak;
                    },
                    y: topMargin,
                    x: answerMargin
                });
                doc.font('OpenSans-Regular').text(preTranslated.Com, answerMargin, doc.y);
                doc.moveUp(0.5);
            }

            function generateScaleRatingQuestionAndAnswers(question) {
                var answerMatrix = {};
                if (question.Answers.length) {
                    generateAnswerMatrix(question, answerMatrix);
                    populateAnswerMatrixStats(question, answerMatrix);
                    generateAnswerColorMatrix(question);
                    generateScaleRatingLegendBarAndRuler(question, answerMatrix);
                    generateScaleRatingLegendData(question, answerMatrix);
                    generateScaleRatingAnswerSectionHeader();
                }
            }

            function generateNoAnswerMessage(peopleType) {
                var typeString;
                if (['Reviewee', 'Manager'].indexOf(peopleType) === -1) {
                    typeString = i18nHelper.translate(lang, 'pdf.rev.onmo', {peopleType: getPeepString(peopleType)});
                } else {
                    typeString = [getPeepString(peopleType), ' ', preTranslated.Has].join('');
                }
                doc.font('OpenSans-Semibold').fontSize(10).fill(errorTextColor).text([typeString, preTranslated.Ntay].join(' '), answerMargin, doc.y, {
                    width: pageWidth - answerMargin - marginLeft
                });
                doc.y += 4;
            }

            function generateOneQuestionAndAllAnswers(question) {
                var peopleMap = {
                        Subject: [],
                        Manager: [],
                        Participants: []
                    },
                    managerType = review.Peoples.filter(function (peep) {
                        return peep.PeopleType === 'Manager';
                    })[0],
                    managerId = managerType ? managerType.MemberId : null,
                    docY,
                    allPeopleType = [],
                    questionMargin = answerMargin,
                    isScaleRating = question.AnswerType === EntityEnums.AnswerTypes.ScaleRating && question.AnswerSelectors.length > 1,
                    questionWidth = pageWidth - marginLeft * 2 - 26 - (isScaleRating ? 30 : 0),
                    externalDataMap = [EntityEnums.AnswerTypes.Templated, EntityEnums.AnswerTypes.Goal];
                question.Answers.forEach(function (peep) {
                    if (peopleMap[peep.PeopleType]) {
                        if (peep.PeopleType === 'Manager' && peep.MemberId !== managerId) {
                            peep = null;
                        }
                        if (peep) {
                            peopleMap[peep.PeopleType].push(peep);
                        }
                    } else {
                        peopleMap.Participants.push(peep);
                    }
                });
                setPageBreak({
                    pageBreak: sectionBreakThreshold,
                    y: topMargin
                });
                // store the different people types
                review.Card.PeopleTypes.map(function (pt) {
                    var peepCount;
                    if (['Subject', 'Manager'].indexOf(pt.PeopleTypeName) === -1) {
                        peepCount = review.Peoples.filter(function (rp) {
                            return rp.PeopleType === pt.PeopleTypeName;
                        });
                        allPeopleType.push({
                            type: pt.PeopleTypeName,
                            value: peepCount.length,
                            optional: question.OptionalTo && question.OptionalTo.indexOf(pt.PeopleTypeName) > -1,
                            required: question.ToBeAnsweredBy && question.ToBeAnsweredBy.indexOf(pt.PeopleTypeName) > -1
                        });
                    }
                });
                docY = doc.y + 13;
                doc.circle(marginLeft + 10, docY + 10, 10).fill(lightShade);
                doc.fill(cardTextColor).font('OpenSans-Regular').fontSize(14).text(question.QuestionNumber, marginLeft, docY, {
                    width: 20,
                    align: 'center'
                });
                // the question text
                doc.fill(cardTextColor).font('OpenSans-Semibold').fontSize(11).
                    text(sanitizeTextString(question.QuestionText), questionMargin, docY, {
                        width: questionWidth
                    });
                // the help text, if exists
                if (question.QuestionHelp && question.QuestionHelp.length) {
                    doc.font('OpenSans-Italic').fontSize(9).text('', questionMargin, doc.y, {
                        width: questionWidth
                    });
                    outputStringParts(sanitizeTextString(question.QuestionHelp));
                }
                // if rating scale, generate the legend
                if (isScaleRating) {
                    if (question.Answers.length < 3) {
                        generateScaleRatingLegend(question);
                    } else {
                        generateScaleRatingQuestionAndAnswers(question);
                    }
                }
                // display subject answer first
                if (peopleMap.Subject.length === 1) {
                    generateOneAnswer({
                        answer: peopleMap.Subject[0],
                        question: question
                    });
                } else if (question.OptionalTo && question.OptionalTo.indexOf('Subject') === -1) {
                    if (question.ToBeAnsweredBy && question.ToBeAnsweredBy.indexOf('Subject') > -1) {
                        generateOneAnswer({
                            answer: '',
                            question: question
                        });
                        generateNoAnswerMessage('Reviewee');
                    }
                } else if (externalDataMap.indexOf(question.AnswerType) > -1) {
                    // generate a blank answer for optional track questions
                    generateOneAnswer({
                        answer: '',
                        question: question
                    });
                }
                // display manager answer second
                if (peopleMap.Manager.length === 1) {
                    generateOneAnswer({
                        answer: peopleMap.Manager[0],
                        question: question
                    });
                } else if (question.ToBeAnsweredBy && question.ToBeAnsweredBy.indexOf('Manager') > -1 && question.OptionalTo && question.OptionalTo.indexOf('Manager') === -1) {
                    generateNoAnswerMessage('Manager');
                }
                // display all other answers last
                peopleMap.Participants.map(function (p) {
                    generateOneAnswer({
                        answer: p,
                        question: question
                    });
                    allPeopleType.map(function (apt) {
                        if (apt.type === p.PeopleType) {
                            apt.value -= 1;
                        }
                    });
                });
                // check if there are unanswered questions from other participants that are not included in the answers
                allPeopleType.map(function (apt) {
                    if (apt.value > 0 && !apt.optional && apt.required) {
                        generateNoAnswerMessage(apt.type);
                    }
                });
            }

            function transformRatingScaleToMatrix(questions) {
                var i,
                    q,
                    matrix = [];
                for (i = questions.length - 1; i > -1; i -= 1) {
                    q = questions[i];
                    if (q.AnswerType === 'ScaleRating' && q.Matrix) {
                        matrix.push(questions.splice(i, 1)[0]);
                        if (matrix.length === 2) {
                            questions.splice(i, 0, {
                                AnswerType: 'NineBox',
                                Axis: JSON.parse(JSON.stringify(matrix))
                            });
                            matrix = [];
                        }
                    }
                }
            }

            function generateAllQuestions(questions) {
                var rectHeight = 20,
                    docY,
                    questionNumber = 1,
                    processQuestion = function (question, callback) {
                        question.QuestionNumber = questionNumber;
                        questionNumber += 1;
                        if (question.AnswerType === 'ScaleRating' && question.Answers.length > 2) {
                            generateOneQuestionAndAllAnswers(question);
                            doc.fill(whiteTextColor).font('OpenSans-Regular').fontSize(10);
                            doc.y += 4;
                            setPageBreak({
                                condition: function () {
                                    return doc.y + rectHeight > pageBreak;
                                },
                                y: topMargin,
                                x: answerMargin
                            });
                            docY = doc.y;
                            doc.rect(answerMargin, docY, ratingScaleAnswerWidth, rectHeight).fill(ratingScaleDarkColor);
                            doc.fill(whiteTextColor).text(question.Answers.length + " " + preTranslated.Trep, answerMargin + 10, docY + 3);
                            if (question.Answers.length) {
                                doc.font('OpenSans-Regular').text(preTranslated.Avg + generateAverageScaleRating(question.Answers), answerMargin, docY + 3,
                                    {
                                        width: ratingScaleAnswerWidth - 10,
                                        align: 'right'
                                    });
                            }
                            ratingScaleTableRowIdx = 0;
                        } else if (question.AnswerType === 'NineBox') {
                            generators.generateNineBox({
                                doc: doc,
                                question: question,
                                pageWidth: pageWidth,
                                marginLeft: marginLeft,
                                i18nHelper: i18nHelper,
                                topMargin: topMargin,
                                pageBreak: pageBreak,
                                lang: lang
                            });
                        } else {
                            generateOneQuestionAndAllAnswers(question);
                        }
                        callback();
                    };
                Async.eachSeries(questions, processQuestion, function (err) {
                    if (err) {
                        return serviceCallback(i18nHelper.translate(lang, 'pdf.rev.errg'));
                    }
                });
            }

            function generateSectionHeader(section) {
                if (!setPageBreak({
                        pageBreak: sectionBreakThreshold,
                        y: topMargin
                    })) {
                    doc.moveDown();
                }
                transformRatingScaleToMatrix(section.Questions);
                if (!section.Title.length) {
                    section.Title = [preTranslated.Rvqu, ' (', section.Questions.length, ')'].join('');
                }
                doc.fill(cardTextColor).font('OpenSans-Bold').fontSize(16).text(sanitizeTextString(section.Title), marginLeft, doc.y, {
                    width: pageWidth - marginLeft * 2
                });
                if (section.length) {
                    doc.font('OpenSans-Italic').fontSize(10).text('', marginLeft, doc.y, {
                        width: pageWidth - marginLeft * 2
                    });
                    outputStringParts(sanitizeTextString(section.Description));
                }
                doc.moveTo(marginLeft, doc.y + 4).lineTo(pageWidth - marginLeft, doc.y + 4).stroke(underlineColor);
                generateAllQuestions(section.Questions);
            }

            function generateAllSections() {
                var sections = review.Card.Sections,
                    len = sections.length || 0,
                    i;
                for (i = 0; i < len; i += 1) {
                    if (sections[i].Questions.length) {
                        generateSectionHeader(sections[i]);
                    }
                }
            }

            function generatePageFooter() {
                var i,
                    len = doc.bufferedPageRange().count,
                    cycleNameTruncated = review.CycleName,
                    cardNameTruncated = review.Card.Title;
                if (cycleNameTruncated.length > 40) {
                    cycleNameTruncated = cycleNameTruncated.substring(0, 40) + '~';
                }
                if (cardNameTruncated.length > 40) {
                    cardNameTruncated = cardNameTruncated.substring(0, 40) + '~';
                }
                for (i = 0; i < len; i += 1) {
                    doc.switchToPage(i);
                    // reset the margins to 24 to allow the footer to be generated
                    doc.page.margins.bottom = 24;
                    doc.font('OpenSans-Regular').fontSize(8).fill(cardTextColor).text([
                        sanitizeTextString(cycleNameTruncated),
                        sanitizeTextString(cardNameTruncated),
                        reviewee.MemberFullname,
                        i18nHelper.translate(lang, 'pdf.rev.page', {
                            number: (i + 1),
                            total: len
                        })
                    ].join(' / '), marginLeft, pageHeight - 36, {
                        width: pageWidth - marginLeft * 2,
                        align: 'right'
                    });
                    doc.fontSize(6).text(preTranslated.Hges, marginLeft, pageHeight - 36, {
                        width: 200,
                        align: 'left'
                    });
                }
            }

            function convertBadgeToJSON(params) {
                parseXml(params.xml, {explicitArray: true}, function (err, result) {
                    // ignore the error
                    badgeImages.push({
                        hgId: params.hgId,
                        result: result.svg
                    });
                    params.cb();
                });
            }

            function generateSignatureSection() {
                var peopleWithSignatures;
                if (review.NeedsSignOff) {
                    peopleWithSignatures = review.Peoples.filter(function (person) {
                        return person.Signature.Name !== '';
                    });
                    if (peopleWithSignatures.length > 0) {
                        if (!setPageBreak({
                                pageBreak: sectionBreakThreshold,
                                y: topMargin
                            })) {
                            doc.moveDown();
                        }
                        doc.fill(cardTextColor).font('OpenSans-Bold').fontSize(16).text(preTranslated.Sign, marginLeft, doc.y, {
                            width: pageWidth - marginLeft * 2
                        });
                        doc.moveTo(marginLeft, doc.y + 4).lineTo(pageWidth - marginLeft, doc.y + 4).stroke(underlineColor);
                        peopleWithSignatures.sort(function (a, b) {
                            return a.Signature.SignedAt - b.Signature.SignedAt;     //sort by order of most recent signed
                        });
                        doc.y += 15;
                        peopleWithSignatures.forEach(function (person) {
                            if (!setPageBreak({
                                    pageBreak: sectionBreakThreshold,
                                    y: topMargin
                                })) {
                                doc.moveDown();
                            }
                            if (person.Signature.Comment && (['Subject', 'Manager'].indexOf(review.MyTypeInReview) > -1 || review.MyMemberId === person.MemberId || review.StatusByAdminView === 'Closed')) {
                                doc.font('OpenSans-Semibold').fill(cardTextColor).fontSize(11).text(sanitizeTextString(preTranslated.Cmt), marginLeft + 20, doc.y);
                                doc.font('OpenSans-Regular').fill(cardTextColor).fontSize(10).text('', marginLeft + 20, doc.y, {
                                    width: pageWidth - marginLeft * 2
                                });
                                outputStringParts(htmlToText.fromString(sanitizeTextString(person.Signature.Comment)));
                            }
                            doc.font('LaBelleAurore').fontSize(24).text(sanitizeTextString(person.Signature.Name), marginLeft + 20, doc.y, {
                                lineBreak: false,
                                continued: true
                            });
                            doc.font('OpenSans-Italic').fontSize(10).text([person.MemberFullname, ' (', getPeepString(person.PeopleType), ') - ', formatDateString(person.Signature.SignedAt)].join(''), marginLeft + 20, doc.y + 30);
                            doc.moveDown();
                        });
                    }
                }
            }

            function generateReviewPDF() {
                generateReviewHeader();
                generateCardHeader();
                generateAllSections();
                generateSignatureSection();
                generatePageFooter();
                doc.end();
            }

            function getTemplateFromObject(obj) {
                var template;
                if (obj.CareerTrackTemplate) {
                    template = obj.CareerTrackTemplate.Goal.RecognitionTemplate;
                    template.badgefilename = template.hgId;
                } else if (obj.Template) {
                    template = obj.Template;
                    template.badgefilename = obj.BadgeFilename || template.hgId;
                }
                return template;
            }

            function addToBadgeArray(params) {
                //if subValues exist, check on BadgeFilename
                if (params.temp.SubValues && params.temp.SubValues.length) {
                    if (!params.badgeInfoArray.filter(function (b) {
                            return b.hgId === params.temp.hgId && b.badgefilename === params.temp.badgefilename;
                        }).length) {
                        params.badgeInfoArray.push({
                            FriendlyGroupId: params.temp.FriendlyGroupId,
                            hgId: params.temp.hgId,
                            badgefilename: params.temp.badgefilename
                        });
                    }
                } else {
                    if (!params.badgeInfoArray.filter(function (b) {
                            return b.hgId === params.temp.hgId;
                        }).length) {
                        params.badgeInfoArray.push({
                            FriendlyGroupId: params.temp.FriendlyGroupId,
                            hgId: params.temp.hgId,
                            badgefilename: params.temp.badgefilename
                        });
                    }
                }
            }

            function readBadgeImages() {
                // pull any badge images and store in memory
                var badgeInfoArray = [];
                if (review.AllTracks && review.AllTracks.length) {
                    review.AllTracks.forEach(function (t) {
                        addToBadgeArray({
                            badgeInfoArray: badgeInfoArray,
                            temp: getTemplateFromObject(t)
                        });
                    });
                }
                if (review.AllRecognitions && review.AllRecognitions.length) {
                    review.AllRecognitions.forEach(function (t) {
                        addToBadgeArray({
                            badgeInfoArray: badgeInfoArray,
                            temp: getTemplateFromObject(t)
                        });
                    });
                }
                if (badgeInfoArray && badgeInfoArray.length) {
                    Async.eachLimit(badgeInfoArray, 9, function (template, badgeCallback) {
                        var xml = '';
                        if (isLocal) {
                            fs.readFile('./static/img/badges/group/' + template.FriendlyGroupId + '/' + template.badgefilename + '.svg', 'utf8', function (error, svg) {
                                if (error) {
                                    HgLog.error({methodName: 'readBadgeImages', error: error});
                                    return serviceCallback(i18nHelper.translate(lang, 'pdf.rev.errg'));
                                }
                                svg = svg.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, "");
                                convertBadgeToJSON({
                                    hgId: template.badgefilename,
                                    xml: svg,
                                    cb: badgeCallback
                                });
                            });
                        } else {
                            https.get({
                                host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
                                path: '/badges/group/' + template.FriendlyGroupId + '/' + template.badgefilename + '.svg'
                            }, function (ret) {
                                ret.on("data", function (chunk) {
                                    xml += chunk;
                                }).on("end", function () {
                                    convertBadgeToJSON({
                                        hgId: template.badgefilename,
                                        xml: xml.replace(/[\r\n\t]+/gm, "").replace(/[\t]+/gm, ""),
                                        cb: badgeCallback
                                    });
                                });
                            }).on('error', function (e) {
                                HgLog.error('ERROR: ' + e.message);
                                serviceCallback(i18nHelper.translate(lang, 'pdf.rev.errg'));
                            });
                        }
                    }, function (err) {
                        if (err) {
                            return serviceCallback(i18nHelper.translate(lang, 'pdf.rev.errg'));
                        }
                        generateReviewPDF();
                    });
                } else {
                    generateReviewPDF();
                }
            }

            function bufferUserAvatar(peep, callback) {
                var userAvatarBuffer = [];
                if (peep.UserId && !isLocal && !userAvatarBuffers[peep.MemberId]) {
                    https.get({
                        host: config.s3store.imageStore[config.nextIndex()].replace('//', ''),
                        path: '/user/' + peep.UserId + '.jpg'
                    }, function (ret) {
                        ret.on("data", function (chunk) {
                            userAvatarBuffer.push(chunk);
                        }).on("end", function () {
                            userAvatarBuffers[peep.MemberId] = Buffer.concat(userAvatarBuffer);
                            callback();
                        });
                    }).on('error', function (e) {
                        serviceCallback('ERROR: ' + e.message);
                    });
                } else {
                    callback();
                }
            }

            // register all fonts that will be used in this pdf - these fonts are stored on the node server, not S3
            // pdfkit errors out when trying to access fonts stored on S3
            doc.registerFont('LaBelleAurore', './static/fonts/LaBelleAurore.ttf');
            doc.registerFont('OpenSans-Regular', './static/fonts/Open_Sans/OpenSans-Regular.ttf');
            doc.registerFont('OpenSans-Semibold', './static/fonts/Open_Sans/OpenSans-Semibold.ttf');
            doc.registerFont('OpenSans-Italic', './static/fonts/Open_Sans/OpenSans-Italic.ttf');
            doc.registerFont('OpenSans-Bold', './static/fonts/Open_Sans/OpenSans-Bold.ttf');
            doc.registerFont('OpenSans-Light', './static/fonts/Open_Sans/OpenSans-Light.ttf');
            doc.lineWidth(1);
            docBuffers = [];
            doc.on('data', function (data) {
                docBuffers.push(data);
            });
            doc.on('end', function () {
                if (docBuffers.length) {
                    serviceCallback(null, Buffer.concat(docBuffers));
                } else {
                    serviceCallback(i18nHelper.translate(lang, 'pdf.rev.errg'));
                }
            });

            // just cache all the participant avatars from the Peoples array instead of going through all the questions
            // in a future iteration, these avatars could be cached to eliminate the need to read from S3
            if (review.Peoples) {
                review.Card.Sections.forEach(function (s) {
                    hasScaleRating |= s.Questions.some(function (q) {
                        return q.AnswerType === EntityEnums.AnswerTypes.ScaleRating && q.Answers.length > 2;
                    });
                });
                Async.forEachLimit(review.Peoples, 9, function (peep, callback) {
                    if (peep.PeopleType === 'Subject') {
                        reviewAvatarId = peep.MemberId;
                        bufferUserAvatar(peep, callback);
                    } else if (hasScaleRating) {
                        // only buffer the avatars if the review has scale rating questions that have more that 2 answers
                        bufferUserAvatar(peep, callback);
                    } else {
                        callback();
                    }
                }, function (err) {
                    if (err) {
                        return serviceCallback(err);
                    }
                    readBadgeImages();
                });
            }
        };
    };

module.exports = PerformanceProcessor;
