/*jslint node:true es5:true*/
'use strict';

function generateGoals(params) {
    var doc = params.$.doc,
        cardTextColor = params.$.cardTextColor,
        review = params.$.review,
        topMargin = params.$.topMargin,
        answerMargin = params.$.answerMargin,
        pageWidth = params.$.pageWidth,
        marginLeft = params.$.marginLeft,
        answerWidth = pageWidth - marginLeft,
        sanitizeTextString = params.$.sanitizeTextString,
        outputStringParts = params.$.outputStringParts,
        setPageBreak = params.$.setPageBreak,
        measureTypeFactory = {
            Percentage: function (kr) {
                return kr.Progress >= 100 ? 'completed' : kr.Progress + '%';
            },
            Binary: function (kr) {
                return kr.Progress ? 'completed' : 'incomplete';
            },
            Numeric: function (kr) {
                var percent = Math.round(kr.Progress / kr.Target * 10000) / 100,
                    countText = kr.Progress + ' of ' + kr.Target;
                return percent >= 100 ? 'completed ' + countText : countText + ', ' + percent + '%';
            }
        };

    // test code to fill with mock goals
    // test url http://localhost:8095/#/Profile/Perform/0a3d9d90-906e-11e4-97d6-874588a9496b/0a460200-906e-11e4-97d6-874588a9496b
    review.Goals = params.$.Goals;
    review.GoalsForCurQuestion = review.Goals.filter(function (goal) {
        return goal.CycleId === params.question.GoalCycleId;
    });

    function renderOneKeyResult(kr) {
        if (!setPageBreak({
                y: topMargin,
                x: answerMargin
            })) {
            doc.y += 6;
        }
        // key result title
        doc.circle(answerMargin + 18, doc.y + 8, 5).stroke(cardTextColor);
        doc.font('OpenSans-Bold').fill(cardTextColor).fontSize(12).
            text(sanitizeTextString(kr.Name) + ' (' + measureTypeFactory[kr.Measure](kr) + ')', answerMargin + 28, doc.y, {
                width: answerWidth - 100
            });
        // key result description
        if (kr.Description) {
            doc.y += 3;
            doc.font('OpenSans-Italic').fontSize(8).text('', answerMargin + 28, doc.y, {
                width: answerWidth
            });
            outputStringParts(sanitizeTextString(kr.Description), 450);
        }
        doc.y += 3;
    }

    review.GoalsForCurQuestion.forEach(function (goal) {
        if (!setPageBreak({
                y: topMargin,
                x: answerMargin
            })) {
            doc.y += 6;
        }
        // goal title
        doc.font('OpenSans-Bold').fontSize(14).fill(cardTextColor).
            text(sanitizeTextString(goal.Name) + ' (' + goal.PercentCompletion + '%)', answerMargin, doc.y, {
                width: answerWidth
            });
        // goal description
        if (goal.Description) {
            doc.y += 3;
            doc.font('OpenSans-Italic').fontSize(10).text('', answerMargin, doc.y, {
                width: answerWidth
            });
            outputStringParts(sanitizeTextString(goal.Description));
        }
        // key results
        goal.KeyResults.forEach(function (kr) {
            renderOneKeyResult(kr);
        });
        doc.y += 6;
    });
}

function generateNineBox(params) {
    var BOX_SIZE = 24,
        MAX_NUM_VALUES = 10,
        matrixTop,
        maxBottom = 0,
        maxNumValues = 0,
        errorTextColor = '#af111c',
        doc = params.doc,
        currentPage = doc.bufferedPageRange().count,
        returnPage = 0,
        drawMatrix = function (box, doc) {
            var xpos = doc.x,
                ypos,
                lineColor = '#666666',
                selectedColor = '#4594d0',
                i,
                j,
                ratingText = 'pdf.rev.rby';
            if (box.p === 'Subject') {
                ratingText = 'pdf.rev.sra';
            }
            ratingText = params.i18nHelper.translate(params.lang, ratingText, { name: box.n });
            // render rating header
            doc.font('OpenSans-Semibold').fill(lineColor).text(ratingText, doc.x + 16, doc.y);
            doc.y += 4;
            ypos = doc.y;
            // render y-axis label
            doc.save();
            doc.rotate(-90, {origin: [doc.x, doc.y]});
            doc.font('OpenSans-Regular').fill(lineColor).text(box.y.text, doc.x - box.y.size * box.s, doc.y - 16);
            doc.restore();
            // render matrix
            xpos += 16;
            doc.x = xpos;
            doc.y = ypos;
            for (i = 0; i < box.x.size; i += 1) {
                for (j = 0; j < box.y.size; j += 1) {
                    if (box.x.value === i && box.y.value === j) {
                        doc.rect(xpos, ypos, box.s, box.s).fill(selectedColor);
                    }
                    doc.rect(xpos, ypos, box.s, box.s).stroke(lineColor);
                    ypos += box.s;
                }
                xpos += box.s;
                ypos = doc.y;
            }
            // render x-axis label
            doc.fill(lineColor).text(box.x.text, doc.x, doc.y + box.s * box.y.size);
            // render comments
            if (box.x.comment || box.y.comment) {
                doc.y += 12;
                xpos = doc.x;
                doc.font('OpenSans-Bold').fill(lineColor).text(params.i18nHelper.translate(params.lang, 'pdf.rev.com'));
                if (box.y.comment) {
                    doc.font('OpenSans-Regular').fill(selectedColor).text(box.y.text);
                    doc.font('OpenSans-Italic').fill(lineColor).text(box.y.comment, xpos + 12, doc.y, {
                        width: 230
                    });
                }
                if (box.x.comment) {
                    doc.x = xpos;
                    doc.font('OpenSans-Regular').fill(selectedColor).text(box.x.text);
                    doc.font('OpenSans-Italic').fill(lineColor).text(box.x.comment, xpos + 12, doc.y, {
                        width: 230
                    });
                }
            }
            if (doc.bufferedPageRange().count !== currentPage) {
                returnPage = doc.bufferedPageRange().count;
                maxBottom = doc.y;
                doc.switchToPage(currentPage - 1);
                doc.y = matrixTop;
            } else if (doc.y > maxBottom) {
                maxBottom = doc.y;
            }
        },
        // this is the default state of the matrices
        matrixData = {
            Subject: {
                x: {
                    size: 0,
                    value: -1,
                    text: '',
                    comment: ''
                },
                y: {
                    size: 0,
                    value: -1,
                    text: '',
                    comment: ''
                },
                p: 'Subject',
                n: params.i18nHelper.translate(params.lang, 'common.mrole.emp'),
                s: BOX_SIZE
            },
            Manager: {
                x: {
                    size: 0,
                    value: -1,
                    text: '',
                    comment: ''
                },
                y: {
                    size: 0,
                    value: -1,
                    text: '',
                    comment: ''
                },
                p: 'Manager',
                n: params.i18nHelper.translate(params.lang, 'common.mrole.man'),
                s: BOX_SIZE
            }
        };

    doc.x = params.marginLeft;

    params.question.Axis.forEach(function (question) {
        var part;
        if (question.Matrix) {
            part = question.Matrix.split('-');
            if (part.length === 2) {
                part = part[0];
                matrixData.Subject[part].text = question.QuestionText;
                matrixData.Subject[part].size = question.AnswerSelectors.length;
                matrixData.Manager[part].text = question.QuestionText;
                matrixData.Manager[part].size = question.AnswerSelectors.length;
                if (part === 'x') {
                    maxNumValues =  question.AnswerSelectors.length;
                }
                if (question.Answers && question.Answers.length) {
                    question.Answers.forEach(function (answer) {
                        if (answer.SelectedValues && answer.SelectedValues.length) {
                            matrixData[answer.PeopleType][part].value = part === 'y' ? question.AnswerSelectors.length - answer.SelectedValues[0] : answer.SelectedValues[0] - 1;
                        }
                        matrixData[answer.PeopleType].n = answer.MemberName;
                        matrixData[answer.PeopleType][part].comment = answer.Text;
                    });
                }
            }
        }
    });

    doc.y += 20;
    if (doc.y > params.pageBreak) {
        doc.addPage();
        doc.x = params.marginLeft;
    }
    matrixTop = doc.y;
    doc.fontSize(10);

    // do not try to render anyting bigger than 10 scale rating values
    if (maxNumValues > MAX_NUM_VALUES) {
        doc.font('OpenSans-Bold').fill(errorTextColor).text(params.i18nHelper.translate(params.lang, 'pdf.rev.mve', { max: MAX_NUM_VALUES}));
    } else {
        drawMatrix(matrixData.Subject, doc);
        if (returnPage) {
            doc.switchToPage(returnPage - 1);
        }
        doc.x = params.pageWidth / 2;
        doc.y = matrixTop;
        drawMatrix(matrixData.Manager, doc);
        if (returnPage) {
            doc.switchToPage(doc.bufferedPageRange().count - 1);
        }
    }

    if (returnPage || maxBottom > doc.y) {
        doc.y = maxBottom + 20;
    }
}

module.exports = {
    generateGoals: generateGoals,
    generateNineBox: generateNineBox
};
