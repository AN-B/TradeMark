/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    GoalCycleProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            GoalEnums = require('../enums/GoalEnums.js'),
            ConstantEnums = require('../enums/ConstantEnums'),
            Async = require('async'),
            guid = require('node-uuid'),
            activeParticipantStatues = [
                GoalEnums.ParticipantStatus.PendingDelivery,
                GoalEnums.ParticipantStatus.NotStarted,
                GoalEnums.ParticipantStatus.Setting,
                GoalEnums.ParticipantStatus.SubmittedForSet,
                GoalEnums.ParticipantStatus.InProgress,
                GoalEnums.ParticipantStatus.SubmittedForClosure,
                GoalEnums.ParticipantStatus.Completed],
            deliveredActiveParticipantStatues = [
                GoalEnums.ParticipantStatus.NotStarted,
                GoalEnums.ParticipantStatus.Setting,
                GoalEnums.ParticipantStatus.SubmittedForSet,
                GoalEnums.ParticipantStatus.InProgress,
                GoalEnums.ParticipantStatus.SubmittedForClosure,
                GoalEnums.ParticipantStatus.Completed],
            deliveredOutstandingParticipantStatues = [
                GoalEnums.ParticipantStatus.NotStarted,
                GoalEnums.ParticipantStatus.Setting,
                GoalEnums.ParticipantStatus.SubmittedForSet,
                GoalEnums.ParticipantStatus.InProgress,
                GoalEnums.ParticipantStatus.SubmittedForClosure],
            clsdelParticipantStatus = [
                GoalEnums.ParticipantStatus.NotStarted,
                GoalEnums.ParticipantStatus.Setting,
                GoalEnums.ParticipantStatus.SubmittedForSet,
                GoalEnums.ParticipantStatus.InProgress,
                GoalEnums.ParticipantStatus.SubmittedForClosure],
            pendingToInProgressParticipantStatus = [
                GoalEnums.ParticipantStatus.PendingDelivery,
                GoalEnums.ParticipantStatus.NotStarted,
                GoalEnums.ParticipantStatus.Setting,
                GoalEnums.ParticipantStatus.SubmittedForSet,
                GoalEnums.ParticipantStatus.InProgress],
            activeCycleStatus = [
                GoalEnums.CycleStatus.Building,
                GoalEnums.CycleStatus.Draft,
                GoalEnums.CycleStatus.Pending,
                GoalEnums.CycleStatus.InProgress
            ],
            validCycleStatus = [
                GoalEnums.CycleStatus.Building,
                GoalEnums.CycleStatus.Draft,
                GoalEnums.CycleStatus.Pending,
                GoalEnums.CycleStatus.InProgress,
                GoalEnums.CycleStatus.Closed
            ];

        this.DefaultEntityName = 'GoalCycle';

        this.GetGroupCycles = function (params, callback) {
            var condition = {
                GroupId: params.GroupId
            };
            if (params.Closed) {
                condition.Status = {$in: validCycleStatus};
            } else {
                condition.Status = {$in: activeCycleStatus};
            }
            EntityCache.GoalCycle.find(condition, callback);
        };

        this.AssignTemplateToCycle = function (params, callback) {
            EntityCache.GoalCycle.update({
                GroupId: params.GroupId,
                hgId: params.CycleId
            }, {
                $addToSet: {
                    TemplateIds: params.TemplateId
                },
                $set: {
                    ModifiedBy: params.UserId
                }
            }, callback);
        };

        this.RemoveTemplateFromCycle = function (params, callback) {
            EntityCache.GoalCycle.update({
                hgId: params.CycleId,
                GroupId: params.GroupId
            }, {
                $pull: {
                    TemplateIds: params.TemplateId
                },
                $set: {
                    ModifiedBy: params.UserId
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                EntityCache.GoalCycleParticipant.update({
                    CycleId: params.CycleId,
                    GroupId: params.GroupId,
                    Status: {
                        $in: pendingToInProgressParticipantStatus
                    }
                }, {
                    $pull: {
                        TemplateIds: params.TemplateId
                    },
                    $set: {
                        ModifiedBy: params.UserId
                    }
                }, {
                    multi: true
                }, callback);
            });
        };

        this.GetPartipants = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                Status: {
                    $in: pendingToInProgressParticipantStatus
                },
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType
            };
            if (params.SearchTerm && params.SearchTerm.trim()) {
                condition.Name = new RegExp(["^.*", params.SearchTerm.trim(), ".*$"].join(""), "i");
            }
            if (params.Title && params.Title.trim()) {
                condition['Owner.Title'] = new RegExp(["^.*", params.Title.trim(), ".*$"].join(""), "i");
            }
            if (params.DeptId) {
                condition['Owner.DeptId'] = params.DeptId;
            }
            if (params.LocId) {
                condition['Owner.LocId'] = params.LocId;
            }
            EntityCache.GoalCycleParticipant.count(condition, function (error, total) {
                if (error) {
                    return callback(error);
                }
                EntityCache.GoalCycleParticipant.find(condition)
                    .sort({Name: 1})
                    .skip(parseInt(params.Skip, 10) || 0)
                    .limit(parseInt(params.Take, 10) || 0)
                    .exec(function (error, participants) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, {
                            Total: total,
                            Participants: participants
                        });
                    });
            });
        };

        this.GetAssignedCyclesByTemplateId = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                Status: {
                    $in: activeCycleStatus
                },
                TemplateIds: params.TemplateId
            };
            if (params.SearchTerm && params.SearchTerm.trim()) {
                condition.Title = new RegExp(["^.*", params.SearchTerm.trim(), ".*$"].join(""), "i");
            }
            EntityCache.GoalCycle.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetPartipantNumberByTemplateId = function (params, callback) {
            EntityCache.GoalCycleParticipant.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    Status: {$in: activeParticipantStatues},
                    TemplateIds: params.TemplateId
                }},
                {$group: {_id: '$CycleId', count: {$sum: 1}}}
            ], callback);
        };

        this.GetCycleCandiatesByTemplateId = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                Status: {
                    $in: activeCycleStatus
                },
                TemplateIds: {
                    $ne: params.TemplateId
                }
            };
            if (params.SearchTerm && params.SearchTerm.trim()) {
                condition.Title = new RegExp(["^.*", params.SearchTerm.trim(), ".*$"].join(""), "i");
            }
            EntityCache.GoalCycle.find(condition, callback);
        };

        this.TransferCyclesOwnership = function (params, callback) {
            var condition = {
                'CycleOwner.MemberId': params.FromMember.MemberId,
                Status: {$in: activeCycleStatus}
            };
            EntityCache.GoalCycle.find(condition, function (error, cycles) {
                if (error) {
                    return callback(error);
                }
                cycles.forEach(function (cycle) {
                    cycle.CycleOwner = params.ToMember;
                });
                EntityCache.GoalCycle.update(condition, {
                    $set: {
                        CycleOwner: {
                            MemberId: params.ToMember.MemberId,
                            UserId: params.ToMember.UserId,
                            FullName: params.ToMember.FullName
                        }
                    }
                }, {
                    multi: true
                }, function (error) {
                    callback(error, cycles);
                });
            });
        };

        this.GetMemberGoalCycleAdminCount = function (params, callback) {
            EntityCache.GoalCycle.count({
                'CycleOwner.MemberId': params.MemberId,
                Status: {$in: activeCycleStatus}
            }, callback);
        };

        this.SyncParticipantClosePromptAndDueDates = function (params, callback) {
            EntityCache.GoalCycle.findOne({hgId: params.CycleId}, function (error, cycle) {
                if (error || !cycle) {
                    return callback('goalcycle.err.elc');
                }
                EntityCache.GoalCycleParticipant.update({
                    CycleId: params.CycleId,
                    Status: {$in: activeParticipantStatues}
                }, {
                    $set: {
                        ClosePromptDate: cycle.ClosePromptDate,
                        CloseDueDate: cycle.ClosePromptDate + cycle.ClosePeriod * 24 * 3600 * 1000
                    }
                }, {
                    multi: true
                }, function (error, updateCount) {
                    if (error) {
                        return callback(error);
                    }
                    EntityCache.GoalCycleParticipant.count({
                        CycleId: params.CycleId,
                        Status: {$in: deliveredActiveParticipantStatues}
                    }, function (error, deliveredCount) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, {
                            Cycle: cycle,
                            UpdatedCount: updateCount,
                            DeliveredCount: deliveredCount
                        });
                    });
                });
            });
        };

        this.SyncParticipantDeliveryDate = function (params, callback) {
            EntityCache.GoalCycleParticipant.update({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                Status: {$in: activeParticipantStatues}
            }, {
                $set: {
                    DeliveryDate: params.ToValue
                }
            }, {
                multi: true
            }, function (error, updateCount) {
                if (error) {
                    return callback(error);
                }
                EntityCache.GoalCycleParticipant.count({
                    CycleId: params.CycleId,
                    ParticipantType: params.ParticipantType,
                    Status: {$in: deliveredActiveParticipantStatues}
                }, function (error, deliveredCount) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        UpdatedCount: updateCount,
                        DeliveredCount: deliveredCount
                    });
                });
            });
        };

        this.SyncParticipantSetDueDate = function (params, callback) {
            EntityCache.GoalCycleParticipant.update({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                Status: {$in: activeParticipantStatues}
            }, {
                $set: {
                    SetDueDate: params.ToValue
                }
            }, {
                multi: true
            }, function (error, updateCount) {
                if (error) {
                    return callback(error);
                }
                EntityCache.GoalCycleParticipant.count({
                    CycleId: params.CycleId,
                    ParticipantType: params.ParticipantType,
                    Status: {$in: deliveredActiveParticipantStatues}
                }, function (error, deliveredCount) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        UpdatedCount: updateCount,
                        DeliveredCount: deliveredCount
                    });
                });
            });
        };

        this.SyncParticipants = function (params, callback) {
            var deliveryMethod = params.Cycle.DeliveryMethods.filter(function (method) {
                    return method.ParticipantType === params.ParticipantType;
                });
            if (!deliveryMethod.length) {
                return callback('goalcycle.err.idm');
            }
            EntityCache.GoalCycleParticipant.update({
                CycleId: params.Cycle.hgId,
                ParticipantType: params.ParticipantType,
                Status: {$in: activeParticipantStatues}
            }, {
                $set: {
                    DeliveryDate: deliveryMethod[0].DeliveryDate,
                    SetDueDate: deliveryMethod[0].SetDueDate,
                    SetDueInDays: deliveryMethod[0].SetDueInDays || 0,
                    ClosePromptDate: params.Cycle.ClosePromptDate,
                    CloseDueDate: params.Cycle.ClosePromptDate + params.Cycle.ClosePeriod * 24 * 3600 * 1000,
                    ModifiedBy: params.UserId
                }
            }, {multi: true}, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, true);
            });
        };
        this.RemoveCompanyGoalOwner = function (params, callback) {
            EntityCache.GoalCycle.findOneAndUpdate({
                hgId: params.CycleId
            }, {
                $set: {
                    CompanyGoalOwner: {},
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, function (error, cycle) {
                if (error || !cycle) {
                    return callback('goalcycle.err.elc');
                }
                EntityCache.GoalCycleParticipant.findOneAndUpdate({
                    CycleId: params.CycleId,
                    ParticipantType: GoalEnums.ParticipantType.Company,
                    Status: {$in: activeParticipantStatues}
                }, {
                    $set : {Status: GoalEnums.ParticipantStatus.Removed},
                    ModifiedBy: params.UserId
                }, {
                    new: true
                }, function (error, participant) {
                    if (error) {
                        return callback('goalcycle.err.elp');
                    }
                    callback(null, {Cycle: cycle, Participant: participant});
                });
            });
        };
        this.SetCompanyGoalOwnerOnCycle = function (params, callback) {
            EntityCache.GoalCycle.findOneAndUpdate({
                hgId: params.CycleId,
                Status: {$in: [GoalEnums.CycleStatus.Draft, GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress]}
            }, {
                $set: {
                    CompanyGoalOwner: {
                        MemberId: params.CompanyGoalOwnerMember.hgId,
                        UserId: params.CompanyGoalOwnerMember.UserId,
                        FullName: params.CompanyGoalOwnerMember.FullName,
                        Title: params.CompanyGoalOwnerMember.Position
                    },
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, callback);
        };

        this.GetTotalPartipantsForCloseGoalOverdue = function (params, callback) {
            var date = new Date(Date.now() + ConstantEnums.TWENTY_FOUR_HOURS_BEFORE),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.Setting, GoalEnums.ParticipantStatus.InProgress]},
                    CloseDueDate : {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                            ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                            ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte: new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.count(condition, callback);
        };

        this.GetPartipantsForCloseGoalOverdue = function (params, callback) {
            var date = new Date(Date.now() + ConstantEnums.TWENTY_FOUR_HOURS_BEFORE),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.Setting, GoalEnums.ParticipantStatus.InProgress]},
                    CloseDueDate : {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                            ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                            ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte: new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetTotalPartipantsForCloseGoalPrompt = function (params, callback) {
            var date = new Date(),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.NotStarted, GoalEnums.ParticipantStatus.Setting, GoalEnums.ParticipantStatus.InProgress]},
                    ClosePromptDate: {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                            ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                            ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte:  new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.count(condition, callback);
        };

        this.GetPartipantsForCloseGoalPrompt = function (params, callback) {
            var date = new Date(),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.InProgress]},
                    ClosePromptDate: {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                            ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                            ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte:  new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetTotalParticipantsNumberGoalOverdue = function (params, callback) {
            var date = new Date(Date.now() + ConstantEnums.TWENTY_FOUR_HOURS_BEFORE),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.NotStarted, GoalEnums.ParticipantStatus.Setting, GoalEnums.ParticipantStatus.InProgress]},
                    SetDueDate : {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                            ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                            ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte: new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.count(condition, callback);
        };

        this.GetPartipantsForGoalOverdueReminder = function (params, callback) {
            var date = new Date(Date.now() + ConstantEnums.TWENTY_FOUR_HOURS_BEFORE),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.NotStarted, GoalEnums.ParticipantStatus.Setting]},
                    SetDueDate : {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                            ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                            ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte: new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetTotalPartipantsForGoalCreation = function (params, callback) {
            var date = new Date(Date.now() + ConstantEnums.TWENTY_FOUR_HOURS_AFTER),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.NotStarted, GoalEnums.ParticipantStatus.Setting]},
                    SetDueDate : {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                            ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                            ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte: new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.count(condition, callback);
        };
        this.GetPartipantsForGoalCreationReminder = function (params, callback) {
            var date = new Date(Date.now() + ConstantEnums.TWENTY_FOUR_HOURS_AFTER),
                condition = {
                    Status: {$in: [GoalEnums.ParticipantStatus.NotStarted, GoalEnums.ParticipantStatus.Setting]},
                    SetDueDate : {
                        $lte: new Date(date.getFullYear(), date.getMonth(), date.getDate(),
                                ConstantEnums.LAST_HOUR_OF_DAY, ConstantEnums.LAST_MINUTE_OF_HOUR,
                                ConstantEnums.LAST_SECOND_OF_MINUTE, ConstantEnums.LAST_MILISECOND_OF_SECOND).getTime(),
                        $gte: new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
                    }
                };
            if (params.GroupId) {
                condition.GroupId = params.GroupId;
            }
            EntityCache.GoalCycleParticipant.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetParticipantByHgId = function (params, callback) {
            EntityCache.GoalCycleParticipant.findOne({hgId: params.ParticipantHgId}, callback);
        };
        this.GetParticipantsByHgIds = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                GroupId: params.GroupId,
                hgId: {$in: params.ParticipantHgIds}
            }, callback);
        };
        this.UnassignTemplateGoalFromCycle = function (params, callback) {
            EntityCache.GoalCycle.update({
                GroupId: params.GroupId,
                hgId: params.CycleId,
                Status: {$in: activeCycleStatus}
            }, {
                $pull: {
                    TemplateIds: params.TemplateId
                }
            }, {
                multi: true
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                EntityCache.GoalCycleParticipant.update({
                    GroupId: params.GroupId,
                    ParticipantType: GoalEnums.ParticipantType.Member,
                    CycleId: params.CycleId,
                    Status: {
                        $in: pendingToInProgressParticipantStatus
                    }
                }, {
                    $pull: {
                        TemplateIds: params.TemplateId
                    }
                }, {
                    multi: true
                }, callback);
            });
        };
        this.UnassignTemplateGoalFromParticipants = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                GroupId: params.GroupId,
                ParticipantType: GoalEnums.ParticipantType.Member,
                ParticipantId: {
                    $in: params.MemberIds
                },
                CycleId: params.CycleId,
                Status: {
                    $in: pendingToInProgressParticipantStatus
                }
            }, function (error, participants) {
                Async.parallel(participants.map(function (participant) {
                    return function (callback) {
                        var ind;
                        participant.TemplateIds = participant.TemplateIds || [];
                        ind = participant.TemplateIds.indexOf(params.TemplateId);
                        if (ind !== -1) {
                            participant.TemplateIds.splice(ind, 1);
                        }
                        participant.ModifiedBy = params.UserId;
                        if (participant.GoalNumber === 0 && !participant.TemplateIds.length) {
                            participant.Status = GoalEnums.ParticipantStatus.NotStarted;
                        }
                        participant.save(callback);
                    };
                }), function (error) {
                    callback(error, participants);
                });
            });
        };

        this.GetParticipantsNumberCycleIdTemplateId = function (params, callback) {
            EntityCache.GoalCycleParticipant.count({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {
                    $in: pendingToInProgressParticipantStatus
                },
                TemplateIds: params.TemplateId
            }, callback);
        };
        this.AssignTemplateToParticipants = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                GroupId: params.GroupId,
                ParticipantType: params.ParticipantType,
                ParticipantId: {
                    $in: params.ParticipantIds
                },
                CycleId: params.CycleId,
                Status: {
                    $in: pendingToInProgressParticipantStatus
                }
            }, function (error, participants) {
                if (error) {
                    return callback(error);
                }
                var ind;
                Async.parallel(participants.map(function (participant) {
                    return function (callback) {
                        participant.TemplateIds = participant.TemplateIds || [];
                        ind = participant.TemplateIds.indexOf(params.TemplateId);
                        if (ind === -1) {
                            participant.TemplateIds.push(params.TemplateId);
                        }
                        participant.GoalNumber += 1;
                        participant.ModifiedBy = params.UserId;
                        if (participant.Status === GoalEnums.ParticipantStatus.NotStarted) {
                            participant.Status = GoalEnums.ParticipantStatus.InProgress;
                        }
                        participant.save(callback);
                    };
                }), function (error) {
                    callback(error, participants);
                });
            });
        };

        this.GetParticipantByCycleIdAndParticipantId = function (params, callback) {
            var condition = {
                    CycleId: params.CycleId,
                    ParticipantType: params.ParticipantType,
                    ParticipantId: params.ParticipantId,
                    Status: {$in: activeParticipantStatues}
                };
            EntityCache.GoalCycleParticipant.findOne(condition, callback);
        };
        this.GetActivePartipantsByCycleIdsAndTypeAndParticipantIds = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                Status: {$in: activeParticipantStatues},
                CycleId: {$in: params.CycleIds},
                GroupId: params.GroupId,
                ParticipantType: params.ParticipantType,
                ParticipantId: {$in: params.ParticipantIds}
            })
                .sort({Name: 1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetActivePartipantsByCycleIdsAndType = function (params, callback) {
            var condition = {
                    Status: {$in: activeParticipantStatues},
                    CycleId: {$in: params.CycleIds},
                    ParticipantType: params.ParticipantType
                };
            if (params.SearchTerm && params.SearchTerm.trim()) {
                condition.Name = new RegExp(["^.*", params.SearchTerm.trim(), ".*$"].join(""), "i");
            }
            EntityCache.GoalCycleParticipant.find(condition)
                .sort({Name: 1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetActivePartipantsCountByCycleIdsAndType = function (params, callback) {
            EntityCache.GoalCycleParticipant.count({
                Status: {$in: activeParticipantStatues},
                CycleId: {$in: params.CycleIds},
                ParticipantType: params.ParticipantType
            }, callback);
        };

        this.GetPendingPartipantsByCycleIdsAndType = function (params, callback) {
            var condition = {
                    Status: GoalEnums.ParticipantStatus.PendingDelivery,
                    CycleId: {$in: params.CycleIds},
                    ParticipantType: params.ParticipantType
                };
            EntityCache.GoalCycleParticipant.find(condition, callback);
        };

        this.AddParticipantToCycle = function (params, callback) {
            var participant = new EntityCache.GoalCycleParticipant(params.Participant);
            participant.save(function (error) {
                callback(error, participant);
            });
        };

        this.GetCyclesByIds = function (params, callback) {
            var query = {hgId: {$in: params.CycleIds}};
            if (Array.isArray(params.Statuses)) {
                query.Status = {$in: params.Statuses};
            }
            EntityCache.GoalCycle.find(query, callback);
        };
        this.GetActiveCycleParticipantsByMemberId = function (params, callback) {
            var condition = {
                    Status: {$in: deliveredActiveParticipantStatues},
                    'Owner.MemberId': params.MemberId
                };
            if (params.ParticipantType) {
                condition.ParticipantType = params.ParticipantType;
            }
            EntityCache.GoalCycleParticipant.find(condition, callback);
        };

        this.GetCycleParticipantsByMemberId = function (params, callback) {
            var condition = {
                    'Owner.MemberId': params.MemberId
                };
            if (params.ParticipantType) {
                condition.ParticipantType = params.ParticipantType;
            }
            if (params.Closed) {
                condition.Status = GoalEnums.ParticipantStatus.Completed;
            } else {
                if (params.IncludeCompleted) {
                    condition.Status = {$in: deliveredActiveParticipantStatues};
                } else {
                    condition.Status = {$in: deliveredOutstandingParticipantStatues};
                }
            }
            EntityCache.GoalCycleParticipant.find(condition, callback);
        };

        this.UpdateGoalCycleStatus = function (params, callback) {
            EntityCache.GoalCycle.update({
                GroupId: params.GroupId,
                hgId: params.CycleId
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, callback);
        };

        this.CreateParticipants = function (params, callback) {
            if (params.Participants && params.Participants.length) {
                EntityCache.GoalCycleParticipant.create(params.Participants, function (error, result) {
                    if (error || !result) {
                        return callback(error);
                    }
                    return callback(null, params.Participants);
                });
            } else {
                callback(null, []);
            }
        };

        this.GetPartipantMetricsByCycle = function (params, callback) {
            var metrics = {
                    PreInProgressParticipantNumWithGoals: 0,
                    TotalParticipantNumWithGoals: 0
                };
            EntityCache.GoalCycleParticipant.aggregate([
                {$match: {
                    CycleId: params.CycleId,
                    Status: {$in: activeParticipantStatues},
                    GoalNumber: {$gte: 1}
                }},
                {$group: {_id: '$Status', count: {$sum: 1}}}
            ], function (error, metricsbyStatus) {
                if (error) {
                    return callback(error);
                }
                metricsbyStatus.forEach(function (mbs) {
                    if ([GoalEnums.ParticipantStatus.NotStarted, GoalEnums.ParticipantStatus.Setting].indexOf(mbs._id) > -1) {
                        metrics.PreInProgressParticipantNumWithGoals += mbs.count;
                    }
                    metrics.TotalParticipantNumWithGoals += mbs.count;
                });
                callback(null, metrics);
            });
        };

        this.GetTotalPartipantsForForRemove = function (params, callback) {
            EntityCache.GoalCycleParticipant.count({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: clsdelParticipantStatus}
            }, callback);
        };

        this.GetPartipantsForRemoveBatch = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: clsdelParticipantStatus}
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetTotalPartipantsForClose = function (params, callback) {
            EntityCache.GoalCycleParticipant.count({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: clsdelParticipantStatus}
            }, callback);
        };

        this.GetPartipantsForCloseBatch = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: clsdelParticipantStatus}
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetPartipantsByCycle = function (params, callback) {
            var condition = {
                CycleId: params.CycleId,
                Status: {$in: activeParticipantStatues}
            };
            if (params.ParticipantType) {
                condition.ParticipantType = params.ParticipantType;
            }
            EntityCache.GoalCycleParticipant.find(condition, callback);
        };
        this.GetPartipantByCycleTypeAndId = function (params, callback) {
            EntityCache.GoalCycleParticipant.findOne({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                ParticipantId: params.ParticipantId,
                Status: {$in: activeParticipantStatues}
            }, callback);
        };
        this.GetPartipantsByCycleTypeAndId = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                ParticipantId: {$in: params.ParticipantIds},
                Status: {$in: activeParticipantStatues}
            }, callback);
        };
        this.RemoveParticipantFromCycle = function (params, callback) {
            EntityCache.GoalCycleParticipant.findOneAndUpdate({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                ParticipantId: params.ParticipantId,
                Status: {$in: activeParticipantStatues}
            }, {
                $set : {
                    Status: GoalEnums.ParticipantStatus.Removed,
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, callback);
        };
        this.RemoveParticipantsFromCycle = function (params, callback) {
            EntityCache.GoalCycleParticipant.find({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                ParticipantId: {$in: params.ParticipantIds},
                Status: {$in: activeParticipantStatues}
            }, function (error, participants) {
                if (error) {
                    return callback(error);
                }
                EntityCache.GoalCycleParticipant.update({
                    CycleId: params.CycleId,
                    ParticipantType: params.ParticipantType,
                    ParticipantId: {$in: params.ParticipantIds},
                    Status: {$in: activeParticipantStatues}
                }, {
                    $set : {
                        Status: GoalEnums.ParticipantStatus.Removed,
                        ModifiedBy: params.UserId
                    }
                }, {
                    multi: true
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, participants);
                });
            });
        };
        this.RemoveParticipantsFromCycleByType = function (params, callback) {
            EntityCache.GoalCycleParticipant.findOneAndUpdate({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                Status: {$in: activeParticipantStatues}
            }, {
                $set: {Status: GoalEnums.ParticipantStatus.Removed},
                ModifiedBy: params.UserId
            }, {
                new: true
            }, callback);
        };

        this.GetCycleById = function (params, callback) {
            EntityCache.GoalCycle.findOne({
                hgId: params.CycleId,
                GroupId: params.GroupId
            }, callback);
        };

        this.UpdateGoalCycleSnapshot = function (params, callback) {
            EntityCache.GoalCycle.update({
                hgId: params.CycleId
            }, {
                $set: {
                    'CycleSnapshot.TotalGoalNumber': params.TotalGoalNumber,
                    'CycleSnapshot.EditingGoalNumber': params.EditingGoalNumber,
                    'CycleSnapshot.SubmittedForSetGoalNumber': params.SubmittedForSetGoalNumber,
                    'CycleSnapshot.InProgressGoalNumber': params.InProgressGoalNumber,
                    'CycleSnapshot.PendingClosureGoalNumber': params.PendingClosureGoalNumber,
                    'CycleSnapshot.SubmittedForClosureGoalNumber': params.SubmittedForClosureGoalNumber,
                    'CycleSnapshot.ClosedGoalNumber': params.ClosedGoalNumber,
                    'CycleSnapshot.OntimeGoalNumber': params.OntimeGoalNumber,
                    'CycleSnapshot.AvgGoalCompletePercentage': params.AvgGoalCompletePercentage,
                    'CycleSnapshot.PreInProgressParticipantNumWithGoals': params.PreInProgressParticipantNumWithGoals,
                    'CycleSnapshot.TotalParticipantNumWithGoals': params.TotalParticipantNumWithGoals
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, 'goalcycle.prc.msu');
            });
        };

        this.GetCyclesByGroupId = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId
                },
                statusArr = [GoalEnums.CycleStatus.Draft, GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress, GoalEnums.CycleStatus.Closed];
            if (params.Status) {
                condition.Status = params.Status;
                statusArr = [params.Status];
            } else {
                condition.Status = {$in: statusArr};
            }
            if (params.Search && params.Search.trim()) {
                condition.Title = new RegExp(["^.*", params.Search.trim(), ".*$"].join(""), "i");
            }
            EntityCache.GoalCycle.find(condition)
                .sort({CreatedDate: -1, ClosePromptDate: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.SetDeliveryAndSetDueDatesForParticipants = function (params, callback) {
            var cycle = params.Cycle,
                participants = params.ParticipantsToBeTirggered,
                setDeliveryAndSetDueDatesForOneParticipant = function (participant, asyncCallback) {
                    var method = cycle.DeliveryMethods.filter(function (method) {
                            return method.ParticipantType === participant.ParticipantType;
                        }),
                        setDueInDays;
                    if (method && method.length > 0) {
                        setDueInDays = method[0].SetDueInDays;
                    }
                    participant.DeliveryDate = Date.now();
                    participant.SetDueDate = participant.DeliveryDate + setDueInDays * 24 * 3600 * 1000;
                    participant.save(function (error) {
                        asyncCallback(error);
                    });
                };
            Async.forEach(participants, setDeliveryAndSetDueDatesForOneParticipant, function (error) {
                callback(error, cycle);
            });
        };

        this.UpdateParticipantsStatus = function (params, callback) {
            EntityCache.GoalCycleParticipant.update({
                hgId: {$in: params.ParticipantHgIds}
            }, {
                $set: {
                    Status: params.ParticipantStatus,
                    ModifiedBy: params.UserId
                }
            }, {multi: true}, callback);
        };

        this.UpdateParticipantStatus = function (params, callback) {
            var setObj = {
                $set: {
                    Status: params.ParticipantStatus,
                    ModifiedBy: params.UserId
                }
            };
            if (params.NewGoalCreated) {
                setObj.$inc = {GoalNumber: 1};
            }
            EntityCache.GoalCycleParticipant.update({
                CycleId: params.CycleId,
                ParticipantType: params.ParticipantType,
                ParticipantId: params.ParticipantId,
                Status: {$in: activeParticipantStatues}
            }, setObj, callback);
        };

        this.UpdateParticipantWeightingStatusType = function (params, callback) {
            EntityCache.GoalCycleParticipant.findOneAndUpdate({
                hgId: params.ParticipantHgId
            }, {
                $set: {WeightingStatus: params.NewStatus, GoalWeightType: params.GoalWeightType}
            }, {
                new: true
            }, callback);
        };

        this.UpdateCyclesAfterDelivery = function (params, callback) {
            var updateOneCycleByOneDelivery = function (cycle, delivery) {
                delivery.Participant.Status = GoalEnums.ParticipantStatus.NotStarted;
                delivery.Participant.save();
                if (cycle.Status === GoalEnums.CycleStatus.Pending) {
                    cycle.Status = GoalEnums.CycleStatus.InProgress;
                }
            };
            params.Deliveries.forEach(function (delivery) {
                var cycle = params.Cycles.filter(function (cycle) {
                    return cycle.hgId === delivery.CycleId;
                });
                if (cycle && cycle.length === 1) {
                    updateOneCycleByOneDelivery(cycle[0], delivery);
                }
            });
            params.Cycles.forEach(function (cycle) {
                cycle.LockedForDelivery = false;
                cycle.save();
            });
            callback(null, params.Cycles);
        };

        this.LoadDeliveryDueCycles = function (params, callback) {
            var condition = {
                    Status : {$in : [GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress]}
                    // LockedForDelivery : false
                };
            EntityCache.GoalCycle.find(condition, function (error, cycles) {
                if (error) {
                    return callback(error);
                }
                if (!cycles || cycles.length < 1) {
                    return callback(null, []);
                }
                EntityCache.GoalCycleParticipant.aggregate([
                    {$match: {
                        CycleId: {$in: cycles.map(function (cycle) {return cycle.hgId; })},
                        DeliveryDate: {$lte : Date.now()},
                        Status : GoalEnums.ParticipantStatus.PendingDelivery
                    }},
                    {$group: {
                        _id: '$CycleId',
                        count: {$sum: 1}
                    }}
                ], function (error, countsByCycleId) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, cycles.filter(function (cycle) {
                        return countsByCycleId.map(function (countByCycleId) {
                            return countByCycleId._id;
                        }).indexOf(cycle.hgId) > -1;
                    }));
                });
            });
        };

        this.GetTotalDeliveryDueParticipantByCycleId = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    hgId: params.CycleId,
                    Status: {$in: [GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress]}
                };
            EntityCache.GoalCycle.findOne(condition, function (error, cycle) {
                if (error || !cycle) {
                    return callback('Error loading the cycle, or it has been deleted: ' + params.CycleId);
                }
                EntityCache.GoalCycleParticipant.count({
                    CycleId: params.CycleId,
                    DeliveryDate: {$lte: Date.now()},
                    Status: GoalEnums.ParticipantStatus.PendingDelivery
                }, callback);
            });
        };

        this.LoadDeliveryDueParticipantByCycleIdBatch = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    hgId: params.CycleId,
                    Status: {$in: [GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress]}
                };
            EntityCache.GoalCycle.findOne(condition, function (error, cycle) {
                if (error || !cycle) {
                    return callback('Error loading the cycle, or it has been deleted: ' + params.CycleId);
                }
                EntityCache.GoalCycleParticipant.find({
                    CycleId: params.CycleId,
                    DeliveryDate: {$lte: Date.now()},
                    Status: GoalEnums.ParticipantStatus.PendingDelivery
                })
                    .skip(parseInt(params.Skip, 10) || 0)
                    .limit(parseInt(params.Take, 10) || 0)
                    .exec(function (error, participants) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, participants.map(function (participant) {
                            return {
                                CycleId: cycle.hgId,
                                CycleTitle: cycle.Title,
                                GroupId: cycle.GroupId,
                                Notes: cycle.Notes,
                                CompanyGoalOwner: cycle.CompanyGoalOwner,
                                Participant: participant,
                                AdminUserId: cycle.CycleOwner.UserId,
                                Note: cycle.Note
                            };
                        }));
                    });
            });
        };
        this.LoadDeliveryDueParticipantByCycleId = function (params, callback) {
            EntityCache.GoalCycle.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.CycleId,
                Status: {$in: [GoalEnums.CycleStatus.Pending, GoalEnums.CycleStatus.InProgress]}
            }, {
                $set: {LockedForDelivery: true}
            }, {
                new: true
            }, function (error, cycle) {
                if (error || !cycle) {
                    return callback(error);
                }
                EntityCache.GoalCycleParticipant.find({
                    CycleId: params.CycleId,
                    DeliveryDate: {$lte: Date.now()},
                    Status: GoalEnums.ParticipantStatus.PendingDelivery
                }, function (error, participants) {
                    var deliveries;
                    if (error) {
                        return callback(error);
                    }
                    deliveries = participants.map(function (participant) {
                        return {
                            CycleId: cycle.hgId,
                            CycleTitle: cycle.Title,
                            GroupId: cycle.GroupId,
                            Notes: cycle.Notes,
                            CompanyGoalOwner: cycle.CompanyGoalOwner,
                            Participant: participant,
                            AdminUserId: cycle.CycleOwner.UserId
                        };
                    });
                    callback(null, {Deliveries: deliveries, Cycles: [cycle]});
                });
            });
        };
        this.SaveCycleAsIs = function (params, callback) {
            var cycle = new EntityCache.GoalCycle(params.CycleRequest);
            cycle.save(function (err) {
                callback(err, cycle);
            });
        };
        this.GetCycleByRoundId = function (params, callback) {
            EntityCache.GoalCycle.findOne({
                RoundId: params.RoundId,
                GroupId: params.GroupId
            }, callback);
        };
        this.DeleteCycle = function (params, callback) {
            EntityCache.GoalCycle.findOneAndUpdate({
                hgId: params.CycleId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Status: GoalEnums.CycleStatus.Archived
                }
            }, {
                new: true
            }, callback);
        };
        this.ArchiveParticipantsByLevelCycleId = function (params, callback) {
            EntityCache.GoalCycleParticipant.update({
                GroupId: params.GroupId,
                CycleId: params.CycleId
            }, {
                $set: {Status: GoalEnums.ParticipantStatus.Removed}
            }, {
                multi: true
            }, callback);
        };
        this.SetRoundId = function (params, callback) {
            EntityCache.GoalCycle.findOneAndUpdate({
                hgId: params.CycleId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    RoundId: params.RoundId
                }
            }, {
                new: true
            }, callback);
        };
        this.CloseCycle = function (params, callback) {
            EntityCache.GoalCycle.findOneAndUpdate({
                hgId: params.CycleId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Status: GoalEnums.CycleStatus.Closed
                }
            }, {
                new: true
            }, callback);
        };
        this.CreateGoalCycle = function (params, callback) {
            var cycle = new EntityCache.GoalCycle(params.CycleRequest);

            cycle.hgId = guid.v1();
            cycle.CreatedBy = params.UserId;
            cycle.ModifiedBy = params.UserId;
            cycle.GroupId = params.GroupId;
            cycle.GroupName = params.GroupName;
            cycle.CycleOwner = {
                MemberId: params.MemberId,
                UserId: params.UserId,
                FullName: params.FullName
            };

            cycle.save(function (err) {
                callback(err, cycle);
            });
        };

        this.SyncParticipantGoalWeighting = function (params, callback) {
            EntityCache.GoalCycleParticipant.update({
                CycleId: params.CycleId,
                GroupId: params.GroupId
            }, {
                $set: {GoalWeighting: params.ToValue}
            }, {
                multi: true
            }).exec(function (error, participant) {
                if (error || !participant) {
                    return callback('goalcycle.err.elp');
                }
                EntityCache.GoalCycleParticipant.find({
                    CycleId: params.CycleId,
                    GroupId: params.GroupId,
                    Status: {$in: deliveredOutstandingParticipantStatues}
                }, callback);
            });
        };

        this.UpdateGoalCycle = function (params, callback) {
            EntityCache.GoalCycle.findOne({GroupId: params.GroupId, hgId: params.CycleRequest.hgId}, function (error, cycle) {
                if (error || !cycle || [GoalEnums.CycleStatus.Draft, GoalEnums.CycleStatus.InProgress, GoalEnums.CycleStatus.Pending].indexOf(cycle.Status) === -1) {
                    return callback('goalcycle.err.elc');
                }
                cycle.Title = params.CycleRequest.Title;
                cycle.GoalWeighting = params.CycleRequest.GoalWeighting;
                cycle.Description = params.CycleRequest.Description;
                cycle.ClosePeriod = params.CycleRequest.ClosePeriod;
                cycle.ClosePromptDate = params.CycleRequest.ClosePromptDate;
                cycle.DeliveryMethods = params.CycleRequest.DeliveryMethods;
                cycle.Note = params.CycleRequest.Note;
                cycle.ModifiedBy = params.UserId;
                cycle.ModifiedDate = Date.now();
                cycle.RecurrenceFrequency = params.CycleRequest.RecurrenceFrequency;
                cycle.save(callback);
            });
        };
    };

module.exports = GoalCycleProcessor;
