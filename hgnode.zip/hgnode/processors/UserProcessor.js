/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    UserProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            HgLog = require('../framework/HgLog'),
            cryptoHelper = require('../helpers/cryptoHelper'),
            uuid = require('node-uuid'),
            HgError = require('../common/HgError.js'),
            Async = require('async'),
            i18nHelper = require('../helpers/i18nHelper.js'),
            ProcessorHelper = require('../util/ProcessorHelper.js'),
            config = require('../configurations/config.js'),
            FileHelper = require('../util/FileHelper.js'),
            fileUpload = require('../helpers/fileUpload.js'),
            AccountTypeEnums = require('../enums/AccountType'),
            EntityEnums = require('../enums/EntityEnums'),
            EventResponder = require('../util/EventResponder.js'),
            ParamUtil = require('../util/params.js'),
            https = require('https'),
            queryByDateAndMonth,
            setOneUserSecurity = function (subjectUserId, roles, permissions, selfUserId) {
                EntityCache.UserSecurity.update(
                    {hgId: subjectUserId},
                    {
                        $set: {
                            Roles: roles,
                            Permissions: permissions
                        }
                    },
                    {upsert: true},
                    function (err) {
                        HgLog.error('Error updating user security', err);
                    }
                );
            },
            createCreditAccount = function (OwnerId, AccountType, createdBy) {
                var creditAccount = EntityCache.CreditAccount({
                    hgId: uuid.v1(),
                    OwnerId: OwnerId,
                    AccountType: AccountType,
                    CreateBy: createdBy,
                    ModifiedBy: createdBy
                });
                creditAccount.save();
            },
            loadUserPoints = function (params, callback) {
                var userInfoWithToken = params.UserInfoWithToken;
                EntityCache.CreditAccount.findOne({
                    OwnerId: userInfoWithToken.UserContext.MemberIdInGroup,
                    AccountType: AccountTypeEnums.PointSpend
                }, function (err, pointSpend) {
                    if (err) {
                        callback(err);
                    } else {
                        EntityCache.CreditAccount.findOne({
                            OwnerId: userInfoWithToken.UserContext.MemberIdInGroup,
                            AccountType: AccountTypeEnums.PointTransfer
                        }, function (err, pointTransfer) {
                            if (err) {
                                callback(err);
                            } else {
                                if (!pointSpend) {
                                    userInfoWithToken.UserFinance.PointSpendingBalance = 0;
                                    createCreditAccount(userInfoWithToken.PointSpend, AccountTypeEnums.PointSpend, userInfoWithToken.UserContext.MemberIdInGroup);
                                } else {
                                    userInfoWithToken.UserFinance.PointSpendingBalance = pointSpend.Balance;
                                }
                                if (!pointTransfer) {
                                    userInfoWithToken.UserFinance.PointTransferBalance = 0;
                                    createCreditAccount(userInfoWithToken.PointSpend, 'PointTransfer', userInfoWithToken.UserContext.MemberIdInGroup);
                                } else {
                                    userInfoWithToken.UserFinance.PointTransferBalance = pointTransfer.Balance;
                                }
                                callback(null, userInfoWithToken);
                            }
                        });
                    }
                });
            },
            loadUserFinance = function (params) {
                var userInfo = params.UserInfo,
                    newParams = {
                        correlationId: params.correlationId
                    };
                EntityCache.CreditAccount.findOne({
                    OwnerId: userInfo.hgId,
                    AccountType: AccountTypeEnums.Spend
                }, function (err, spendingAccount) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, err);
                    } else {
                        EntityCache.CreditAccount.findOne({
                            OwnerId: userInfo.UserContext.MemberIdInGroup,
                            AccountType: AccountTypeEnums.Transfer
                        }, function (err, transferAccount) {
                            if (err) {
                                EventResponder.RespondWithError(EventEmitterCache, params, err);
                            } else {
                                EntityCache.CreditAccount.findOne({
                                    OwnerId: userInfo.UserContext.MemberIdInGroup,
                                    AccountType: AccountTypeEnums.PointSpend
                                }, function (err, pointSpend) {
                                    if (err) {
                                        EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData,
                                            new EventData(params.correlationId, null, 'business.user.noauth.elmc'));
                                    } else {
                                        EntityCache.CreditAccount.findOne({
                                            OwnerId: userInfo.UserContext.MemberIdInGroup,
                                            AccountType: AccountTypeEnums.PointTransfer
                                        }, function (err, pointTransfer) {
                                            if (err) {
                                                EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData,
                                                    new EventData(params.correlationId, null, 'business.user.noauth.elmc'));
                                            } else {
                                                if (!spendingAccount) {
                                                    userInfo.UserFinance.SpendingAccountBalance = 0;
                                                    createCreditAccount(userInfo.hgId, 'SPND', userInfo.hgId);
                                                } else {
                                                    userInfo.UserFinance.SpendingAccountBalance = spendingAccount.Balance;
                                                }
                                                if (!transferAccount) {
                                                    userInfo.UserFinance.TransferAccountBalanceInGroup = 0;
                                                    createCreditAccount(userInfo.UserContext.MemberIdInGroup, 'TRFR', userInfo.hgId);
                                                } else {
                                                    userInfo.UserFinance.TransferAccountBalanceInGroup = transferAccount.Balance;
                                                }
                                                if (!pointSpend) {
                                                    userInfo.UserFinance.PointSpendingBalance = 0;
                                                    createCreditAccount(userInfo.UserContext.MemberIdInGroup, AccountTypeEnums.PointSpend, userInfo.hgId);
                                                } else {
                                                    userInfo.UserFinance.PointSpendingBalance = pointSpend.Balance;
                                                }
                                                if (!pointTransfer) {
                                                    userInfo.UserFinance.PointTransferBalance = 0;
                                                    createCreditAccount(userInfo.UserContext.MemberIdInGroup, 'PointTransfer', userInfo.hgId);
                                                } else {
                                                    userInfo.UserFinance.PointTransferBalance = pointTransfer.Balance;
                                                }
                                                newParams.UserInfoWithToken = userInfo;
                                                loadUserPoints(newParams, function (error, userInfoWithToken) {
                                                    if (error) {
                                                        EventEmitterCache.emit(EventEmitterCache.EventEnum.RequestManager.GenericSendData,
                                                            new EventData(params.correlationId, null, 'Error loading user points'));
                                                    }
                                                    userInfoWithToken.save();
                                                    EventResponder.RespondWithData(EventEmitterCache, params, userInfoWithToken);
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            },
            copyUserDefaultAvatar = function (copyParam) {
                if (process.env.NODE_ENV === 'test') {
                    return;
                }
                fileUpload.copyUserDefaultAvatar({
                    request: {
                        srcFilePath: FileHelper.AppRootPath + '/' + config.filepath.Provision + '/default_user_avatar.jpg',
                        destFilePath: FileHelper.AppRootPath + '/' + config.filepath.ImageRoot,
                        source: config.s3store.defaultAvatars + 'default_user_avatar.jpg',
                        dest: config.filepath.UserProfile + copyParam.UserId + '.jpg'
                    },
                    callback: function (err) {
                        if (copyParam.Callback) {
                            copyParam.Callback();
                        }
                    }
                });
            },
            mapUpdateUserInfo_Internal = function (params) {
                var uiwt = params.userInfoWithToken,
                    ui = params.userInfo,
                    ur = params.updateRequest;
                uiwt.UserPersonal.FirstName = ui.UserPersonal.FirstName = ur.FirstName;
                uiwt.UserPersonal.LastName = ui.UserPersonal.LastName = ur.LastName;
                uiwt.UserPersonal.FullName = ui.UserPersonal.FullName = ur.FullName;
                uiwt.UserPersonal.PrimaryEmail = ui.UserPersonal.PrimaryEmail = ur.PrimaryEmail;
                uiwt.Preference.DefaultGroupId = ui.Preference.DefaultGroupId = ur.DefaultGroupId;
                uiwt.Preference.DefaultChannel = ui.Preference.DefaultChannel = ur.DefaultChannel;
                uiwt.Preference.HomeZip = ui.Preference.HomeZip = ur.HomeZip;
                uiwt.Preference.WorkZip = ui.Preference.WorkZip = ur.WorkZip;
                uiwt.Preference.SuppressBirthday = ui.Preference.SuppressBirthday = ur.SuppressBirthday;
                uiwt.Preference.SuppressAnniversary = ui.Preference.SuppressAnniversary = ur.SuppressAnniversary;
                EntityCache.UserInfoWithToken.update({hgId: ui.hgId},
                    {
                        $set: {
                            'UserPersonal.FirstName': ur.FirstName,
                            'UserPersonal.LastName': ur.LastName,
                            'UserPersonal.FullName': ur.FullName,
                            'UserPersonal.PrimaryEmail': ur.PrimaryEmail,
                            'Preference.DefaultGroupId': ur.DefaultGroupId,
                            'Preference.DefaultChannel': ur.DefaultChannel,
                            'Preference.HomeZip': ur.HomeZip,
                            'Preference.WorkZip': ur.WorkZip,
                            'Preference.SuppressBirthday': ur.SuppressBirthday,
                            'Preference.SuppressAnniversary': ur.SuppressAnniversary
                        }
                    },
                    {multi: true},
                    function (error) {
                        if (error) {
                            HgLog.error({methodName: 'mapUpdateUserInfo_Internal', error: error});
                        }
                    });
            };
        this.DefaultEntityName = 'UserInfo';
        this.GetUserIdsByUserNames = function (params, callback) {
            EntityCache.UserInfo.find({
                LowercaseUserName: {
                    $in: params.UserNames.map(function (item) {
                        return item.toLowerCase();
                    })
                }
            }, {
                UserName: 1,
                hgId: 1
            }, callback);
        };
        this.UpdateUserLanguageAndFlags = function (params, callback) {
            EntityCache.UserInfo.findOneAndUpdate({
                hgId: params.UserId
            }, {
                $set: {
                    i18n: params.i18n,
                    'Preference.SuppressBirthday': params.SuppressBirthday,
                    'Preference.SuppressAnniversary': params.SuppressAnniversary
                }
            }, {
                new: true
            }, callback);
        };
        this.ChangeOneUserName = function (oldNewUserNamePair, callback) {
            var query = {LowercaseUserName: oldNewUserNamePair.OldUserName.toLowerCase()},
                setObj = {
                    $set: {
                        UserName: oldNewUserNamePair.NewUserName.toLowerCase(),
                        LowercaseUserName: oldNewUserNamePair.NewUserName.toLowerCase()
                    }
                };
            EntityCache.UserInfo.find({
                LowercaseUserName: oldNewUserNamePair.NewUserName.toLowerCase()
            }, function (error, existingUsers) {
                if (!error && existingUsers.length) {
                    return callback(oldNewUserNamePair.NewUserName + ' already exists!');
                }
                Async.parallel({
                    userInfo: function (fcallback) {
                        EntityCache.UserInfo.update(query, setObj, fcallback);
                    },
                    userSecurity: function (fcallback) {
                        EntityCache.UserSecurity.update(query, setObj, fcallback);
                    },
                    userInfoWithToken: function (fcallback) {
                        EntityCache.UserInfoWithToken.remove(query, fcallback);
                    },
                    userSecurityWithToken: function (fcallback) {
                        EntityCache.UserSecurityWithToken.remove(query, fcallback);
                    }
                }, function (error) {
                    if (error) {
                        HgLog.error({methodName: 'ChangeOneUserName', error: error});
                        return callback(error);
                    }
                    callback();
                });
            });
        };
        this.MassUpdateUsernames = function (params, callback) {
            Async.each(params.OldNewUserNames, this.ChangeOneUserName, callback);
        };
        this.GetOnlineUsersByUserIds = function (params, callback) {
            EntityCache.UserInfoWithToken.find({
                hgId: {$in: params.UserIds},
                DevicePlatform: {$in: ['iOS', 'Android']}
            }, function (err, users) {
                callback(err, users);
            });
        };
        this.GetAvailableEnvironments = function (params, callback) {
            EntityCache.Environment.find({
                Enabled: true,
                PermissionRequired: params.SwitchEnvironmentType
            }, function (err, environments) {
                callback(err, environments);
            });
        };
        this.LoadByUserToken = function (params) {
            EntityCache.UserInfoWithToken.findOne({UserToken: params.UserToken}, function (err, userInfoWithToken) {
                if (err || !userInfoWithToken) {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, null, 'no userInfoWithToken available'));
                } else {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, userInfoWithToken));
                }
            });
        };

        this.UpdateUserFinanceCallback = function (params, callback) {
            if (params.hgId === undefined || params.UserFinance === undefined) {
                callback('Missing hgId or UserFinance parameters.', null);
            }
            EntityCache.UserInfo.findOne({hgId: params.hgId}, function (err, user) {
                if (err) {
                    callback(err, null);
                } else {
                    user.UserFinance = params.UserFinance;
                    user.markModified('UserFinance');
                    user.save();
                    EntityCache.UserInfoWithToken.find({hgId: params.hgId}, function (err, userInfoWithTokens) {
                        var index = 0,
                            len;
                        if (err) {
                            callback(err, null);
                        } else {
                            for (index = 0, len = userInfoWithTokens.length; index < len; index += 1) {
                                userInfoWithTokens[index].UserFinance = params.UserFinance;
                                userInfoWithTokens[index].markModified('UserFinance');
                                userInfoWithTokens[index].save();
                            }
                            callback(null, 'done update');
                        }
                    });
                }
            });
        };

        this.SaveUserInfo = function (params, callback) {
            params.UserInfo.save(callback);
        };

        this.UpdateUserFinance = function (params) {
            if (params.hgId === undefined || params.UserFinance === undefined) {
                EventEmitterCache.emit(params.EventName,
                    new EventData(params.correlationId, null, 'Missing hgId or UserFinance parameters.'));
            } else {
                EntityCache.UserInfo.findOne({hgId: params.hgId}, function (err, user) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName,
                            new EventData(params.correlationId, null, err));
                    } else {
                        user.UserFinance = params.UserFinance;
                        user.markModified('UserFinance');
                        user.save();
                        EntityCache.UserInfoWithToken.find({hgId: params.hgId}, function (err, userInfoWithTokens) {
                            var index = 0,
                                len;
                            if (err) {
                                EventEmitterCache.emit(params.EventName,
                                    new EventData(params.correlationId, null, err));
                            } else {
                                for (index = 0, len = userInfoWithTokens.length; index < len; index += 1) {
                                    userInfoWithTokens[index].UserFinance = params.UserFinance;
                                    userInfoWithTokens[index].markModified('UserFinance');
                                    userInfoWithTokens[index].save();
                                }
                                EventEmitterCache.emit(params.EventName,
                                    new EventData(params.correlationId, params));
                            }
                        });
                    }
                });
            }
        };

        this.LoadByUserIdWithParameters = function (params) {
            if (params.hgId === undefined || params.params === undefined) {
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'Missing hgId or param parameters.'));
            } else {
                EntityCache.UserInfo.findOne({hgId: params.hgId}, function (err, user) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.User.ErrorLoadingUserById));
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                            user: user,
                            params: params.params
                        }));
                    }
                });
            }
        };
        this.LoadByUserIdCallback = function (params, callback) {
            EntityCache.UserInfo.findOne({hgId: params.UserId}, function (err, user) {
                callback(err, user);
            });
        };

        this.LoadByUserId = function (params) {
            EntityCache.UserInfo.findOne({'hgId': params.payload.UserId}, function (err, user) {
                if (err) {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, null, HgError.Enums.User.ErrorLoadingUserById));
                } else {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, user));
                }
            });
        };

        this.LoadByUserName = function (params) {
            EntityCache.UserInfo.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, user) {
                if (err) {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, null, HgError.Enums.User.ErrorLoadingUserById));
                } else {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, user));
                }
            });
        };

        this.LoadByUserNames = function (params) {
            EntityCache.UserInfo.find({LowercaseUserName: {$in: params.UserNames}}, function (err, users) {
                if (err) {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, null, HgError.Enums.User.ErrorLoadingUserById));
                } else {
                    EventEmitterCache.emit(params.EventName,
                        new EventData(params.correlationId, users));
                }
            });
        };

        this.BatchSetUserSecurity = function (params) {
            var i,
                len;
            for (i = 0, len = params.SubjectUserIds.length; i < len; i += 1) {
                setOneUserSecurity(params.SubjectUserIds[i], params.Roles, params.Permissions, params.SelfUserId);
            }
            EventEmitterCache.emit(params.EventName,
                new EventData(params.correlationId, 'successful'));
        };

        // This is apparently only used by the useradmin service, and even then that service doens't seem to be working. --Demetri
        this.GetUserSecurity = function (params) {
            EntityCache.UserSecurity.findOne({hgId: params.UserId}, function (err, userSecurity) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'business.user.noauth.elus'));
                } else {
                    if (userSecurity) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, userSecurity));
                    } else {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'business.user.noauth.usdne'));
                    }
                }
            });
        };

        function checkMD5orPBKDF2PasswordMatch(params, callback) {
            if (params.userSecurity.Password) {
                callback(params.userSecurity.Password === cryptoHelper.md5(params.password));
            } else {
                cryptoHelper.generatePasswordHash({
                    password: params.password,
                    salt: params.userSecurity.PasswordSalt,
                    iterations: params.userSecurity.PasswordIterations
                }, function (err, data) {
                    callback(params.userSecurity.Password_PBKDF2 === data.passwordHash);
                });
            }
        }

        this.UpdateUserProfile = function (params) {
            var userInfoWithToken = params.UserInfoWithToken,
                userId = params.UserId,
                updateRequest = params.UpdateProfileRequest,
                notificationEmailChanged = false,
                updateUserInfo,
                UpdateCallback = function (err) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.uuf');
                    } else {
                        if (updateRequest.ContainValidPasswordChangeRequest()) {
                            EntityCache.UserSecurity.findOne({hgId: params.UserId}, function (err, userSecurity) {
                                if (err) {
                                    return EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.uad', true);
                                }
                                if (!userSecurity) {
                                    return EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.ude', true);
                                }
                                checkMD5orPBKDF2PasswordMatch({
                                    userSecurity: userSecurity,
                                    password: updateRequest.CurrentPassword
                                }, function (match) {
                                    if (match) {
                                        //check if current password matches new password1
                                        checkMD5orPBKDF2PasswordMatch({
                                            userSecurity: userSecurity,
                                            password: updateRequest.NewPassword1
                                        }, function (match) {
                                            if (match) {
                                                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.User.PasswordShouldBeDifferent, true);
                                            } else {
                                                cryptoHelper.generatePasswordHash({
                                                    password: updateRequest.NewPassword1
                                                }, function (err, data) {
                                                    userSecurity.Password_PBKDF2 = data.passwordHash;
                                                    userSecurity.PasswordSalt = data.salt;
                                                    userSecurity.PasswordIterations = data.iterations;
                                                    userSecurity.save();
                                                    EntityCache.UserInfoWithToken.remove({
                                                        hgId: userSecurity.hgId,
                                                        UserToken: {$ne: userInfoWithToken.UserToken}
                                                    }, function (err) {
                                                        if (err) {
                                                            HgLog.error({
                                                                methodName: 'UpdateUserProfile.UserInfoWithToken',
                                                                error: err
                                                            });
                                                        }
                                                        EntityCache.UserSecurityWithToken.remove({
                                                            hgId: userSecurity.hgId,
                                                            UserToken: {$ne: userInfoWithToken.UserToken}
                                                        }, function (err) {
                                                            if (err) {
                                                                HgLog.error({
                                                                    methodName: 'UpdateUserProfile.UserSecurityWithToken',
                                                                    error: err
                                                                });
                                                            }
                                                        }); // logout this user from all devices except this one
                                                    }); // logout this user from all devices except this one

                                                    EventResponder.RespondWithData(EventEmitterCache, params,
                                                        {
                                                            NotificationEmailChanged: notificationEmailChanged,
                                                            PasswordChanged: true,
                                                            UpdatedUserInfo: updateUserInfo
                                                        });
                                                });
                                            }
                                        });
                                    } else {
                                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.cpi', true);
                                    }
                                });
                            });
                        } else {
                            EventResponder.RespondWithData(EventEmitterCache, params,
                                {
                                    NotificationEmailChanged: notificationEmailChanged,
                                    PasswordChanged: false,
                                    UpdatedUserInfo: updateUserInfo
                                });
                        }
                    }
                };

            EntityCache.Member.update(
                {UserId: params.UserId},
                {
                    $set: {
                        FirstName: updateRequest.FirstName,
                        LastName: updateRequest.LastName,
                        FullName: updateRequest.FullName,
                        SearchName: i18nHelper.convertTextToAscii(updateRequest.FullName)
                    }
                },
                {upsert: false},
                function (err) {
                    if (err) {
                        HgLog.error({methodName: 'UpdateUserProfile', error: err});
                    }
                }
            );

            EntityCache.UserInfo.findOne({hgId: params.UserId}, function (err, userInfo) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.uad');
                } else if (!userInfo) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'business.user.noauth.uidne', true);
                } else if (userInfo.UserPersonal.PrimaryEmail === updateRequest.PrimaryEmail) {// user not trying to update the primary email
                    mapUpdateUserInfo_Internal({
                        userInfoWithToken: userInfoWithToken,
                        userInfo: userInfo,
                        updateRequest: updateRequest
                    });
                    updateUserInfo = userInfo;
                    userInfo.save(UpdateCallback);
                } else { //trying to update primary email, need to verify password
                    EntityCache.UserSecurity.findOne({hgId: userId}, function (err, userSecurity) {
                        if (err) {
                            return EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.uad', true);
                        }
                        if (!userSecurity) {
                            return EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.ude', true);
                        }
                        checkMD5orPBKDF2PasswordMatch({
                            userSecurity: userSecurity,
                            password: updateRequest.CurrentPassword
                        }, function (match) {
                            if (!match) {
                                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.cpi', true);
                            } else {
                                notificationEmailChanged = true;
                                mapUpdateUserInfo_Internal({
                                    userInfoWithToken: userInfoWithToken,
                                    userInfo: userInfo,
                                    updateRequest: updateRequest
                                });
                                updateUserInfo = userInfo;
                                userInfo.save(UpdateCallback);
                            }
                        });
                    });
                }
            });
        };

        this.UpdateUserContext = function (params) {
            var groupId = params.GroupId,
                userInfo = params.UserInfo,
                i,
                len;
            for (i = 0, len = userInfo.MyMemberships.length; i < len; i += 1) {
                if (userInfo.MyMemberships[i].GroupId === groupId) {
                    break;
                }
            }
            if (i < userInfo.MyMemberships.length) {
                EntityCache.Group.findOne({hgId: groupId}, function (err, group) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'business.gro.pro.elg'));
                        return;
                    }
                    userInfo.UserContext.MyManagers = userInfo.MyMemberships[i].MyManagers;
                    userInfo.UserContext.GravatarEmail = userInfo.MyMemberships[i].GravatarEmail;
                    userInfo.UserContext.MemberIdInGroup = userInfo.MyMemberships[i].MemberIdInGroup;
                    userInfo.UserContext.MemberTitleInGroup = userInfo.MyMemberships[i].Position;
                    userInfo.UserContext.CurrentGroupBannerUrl = userInfo.MyMemberships[i].BannerUrl;
                    userInfo.UserContext.CurrentGroupName = userInfo.MyMemberships[i].GroupName;
                    userInfo.UserContext.CurrentProgramName = userInfo.MyMemberships[i].ProgramName;
                    userInfo.UserContext.CurrentGroupId = userInfo.MyMemberships[i].GroupId;
                    userInfo.UserContext.CurrentGroupDepartmentName = userInfo.MyMemberships[i].GroupDepartmentName;
                    userInfo.UserContext.ExperiencePoint = userInfo.MyMemberships[i].ExperiencePoint;
                    userInfo.UserContext.RolesInGroup = userInfo.MyMemberships[i].RolesInGroup;
                    userInfo.UserContext.FriendlyId = userInfo.MyMemberships[i].FriendlyId;
                    userInfo.UserContext.AggregatedSecuredTabs = userInfo.MyMemberships[i].AggregatedSecuredTabs;
                    loadUserFinance({
                        correlationId: params.correlationId,
                        EventName: EventEmitterCache.EventEnum.UserSelfService.GeneralProcessorCallComplate,
                        UserInfo: userInfo,
                        Callback: params.Callback
                    });
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.nig');
            }
        };

        this.UpdateUserPasswordExpiration = function (params, callback) {
            if (!params.UserId) {
                return callback('server.hge.pay.hpm');
            }
            // if params.expiration is not provided, set password expiration to today's date
            // if params.expiration is provided and is greater than zero, set password expiration to today + expiration(days)
            // if params.expiration is provided and is zero, set password expiration to zero (doesn't expire)
            var date = new Date(),
                expDays = parseInt(params.Expiration, 10),
                expDate;
            if (expDays === 0) {
                expDate = 0;
            } else {
                expDate = expDays > 0 ? date.setDate(date.getDate() + expDays) : Date.now();
            }
            EntityCache.UserSecurity.update({
                hgId: { $in: !Array.isArray(params.UserId) ? [params.UserId] : params.UserId }
            }, {
                $set: {
                    PasswordExpiration: expDate
                }
            }, { multi: true }, callback);
        };

        this.UpdateAvatarVersion = function (params, callback) {
            var avatarVersion = Date.now();
            Async.parallel({
                ui: function (fcallback) {
                    EntityCache.UserInfo.update({
                        hgId: params.UserId
                    }, {
                        $set: {
                            AvatarVersion: avatarVersion,
                            ModifiedDate: avatarVersion,
                            AvatarUploaded: true
                        }
                    }, fcallback);
                },
                uiwt: function (fcallback) {
                    EntityCache.UserInfoWithToken.update({
                        hgId: params.UserId
                    }, {
                        $set: {
                            AvatarVersion: avatarVersion,
                            ModifiedDate: avatarVersion,
                            AvatarUploaded: true
                        }
                    }, fcallback);
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, avatarVersion.toString());
            });
        };

        queryByDateAndMonth = function (key, date, month) {
            return {
                "$where": "var d = new Date(this." + key + "); return d.getUTCDate() === " + date + " && d.getUTCMonth() === " + month + " && d.getUTCFullYear() !== " + (new Date()).getUTCFullYear()
            };
        };

        this.GetUsersByBirthday = function (params, callback) {
            var date = new Date(),
                queryBirthday = queryByDateAndMonth('Birthdate', date.getDate(), date.getMonth()),
                gquery,
                groupData = {},
                userData = {};
            if (params.GroupId) {
                gquery = EntityCache.Group.find({hgId: params.GroupId});
            } else {
                gquery = EntityCache.Group.find({'Preference.BirthdayEmailEnabled': true});
            }
            gquery.exec(function (error, groups) {
                if (error || !groups.length) {
                    return callback('business.gro.pro.elg');
                }
                queryBirthday.MembershipStatus = EntityEnums.MembershipStatus.Active;
                queryBirthday.GroupId = {
                    $in: groups.map(function (item) {
                        groupData[item.hgId] = item;
                        return item.hgId;
                    })
                };
                EntityCache.Member.find(queryBirthday, function (error, members) {
                    if (error) {
                        return callback('server.hge.grp.elms');
                    }
                    if (!members.length) {
                        return callback();
                    }
                    EntityCache.UserInfo.find({
                        'Preference.SuppressBirthday': {$ne: true},
                        hgId: {
                            $in: members.map(function (item) {
                                userData[item.UserId] = {
                                    m: item
                                };
                                return item.UserId;
                            })
                        }
                    }, function (error, users) {
                        if (error) {
                            return callback(error);
                        }
                        users.forEach(function (item) {
                            if (!userData[item.hgId]) {
                                delete userData[item.hgId];
                            } else {
                                userData[item.hgId].u = item;
                            }
                        });
                        callback(error, {
                            GroupData: groupData,
                            UserData: userData
                        });
                    });
                });
            });
        };

        this.GetUsersByAnniversary = function (params, callback) {
            var date = new Date(),
                memberDateQuery = queryByDateAndMonth('StartingDate', date.getDate(), date.getMonth());

            EntityCache.Group.find({'Preference.AnniversaryEmailEnabled': true}, function (err, groups) {
                if (err || !groups.length) {
                    callback('server.hge.grp.elg');
                }
                memberDateQuery.MembershipStatus = 'Active';
                memberDateQuery.GroupId = {
                    $in: groups.map(function (group) {
                        return group.hgId;
                    })
                };

                EntityCache.Member.find(memberDateQuery, function (err, members) {
                    if (err) {
                        return callback('server.hge.grp.elms');
                    }

                    callback(null, members);
                });
            });
        };

        // This needs to be converted to an event-based function call. --Demetri
        this.GetMemberByUserId = function (userId, callback) {
            EntityCache.Member.find({UserId: userId}, function (err, member) {
                callback(err, member);
            });
        };

        // This needs to be converted to an event-based function call. --Demetri
        this.GetMemberByMemberId = function (memberId, callback) {
            if (!memberId) {
                callback('member id is null');
            } else {
                EntityCache.Member.findOne({hgId: memberId}, function (err, member) {
                    callback(err, member);
                });
            }
        };

        // This needs to be converted to an event-based function call. --Demetri
        this.GetGroupByGroupId = function (groupId, callback) {
            if (!groupId) {
                callback('group id is null');
            } else {
                EntityCache.Group.findOne({hgId: groupId}, function (err, group) {
                    callback(err, group);
                });
            }
        };

        this.GetUserInfoById = function (params, callback) {
            if (ParamUtil.checkForRequiredParameters(['UserId'], params)) {
                EntityCache.UserInfo.findOne({hgId: params.UserId}, function (err, userInfo) {
                    callback(err, userInfo);
                });
            } else {
                callback('server.hge.gnr.spa');
            }
        };

        this.GetUserSecurityById = function (params) {
            if (ParamUtil.checkForRequiredParameters(['UserId'], params)) {
                EntityCache.UserSecurity.findOne({hgId: params.UserId}, function (err, userSecurity) {
                    EventResponder.RespondGeneric(EventEmitterCache, params, err, userSecurity);
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
            }
        };

        this.SaveLinkedInCodeState = function (params) {
            if (ParamUtil.checkForRequiredParameters(['UserId', 'State'], params)) {
                EntityCache.UserSecurity.update({hgId: params.UserId}, {
                    '$set': {
                        'SSO.LinkedIn.state': params.State,
                        'SSO.LinkedIn.state_ref': params.StateRef
                    }
                }, function (err, userInfo) {
                    EventResponder.RespondGeneric(EventEmitterCache, params, err, userInfo);
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
            }
        };

        this.SaveLinkedInAuthToken = function (params) {
            if (ParamUtil.checkForRequiredParameters(['UserId', 'AccessToken', 'Expires'], params)) {
                EntityCache.UserSecurity.update({hgId: params.UserId}, {
                    '$set': {
                        'SSO.LinkedIn.access_token': params.AccessToken,
                        'SSO.LinkedIn.expires': params.Expires
                    }
                }, function (err, userInfo) {
                    EventResponder.RespondGeneric(EventEmitterCache, params, err, userInfo);
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
            }
        };

        this.SetGravatar = function (params) {
            var userId = params.UserId;
            if (params.UserId && params.GravatarEmail && params.MemberId) {
                EntityCache.Member.update({'hgId': params.MemberId}, {$set: {'GravatarEmail': params.GravatarEmail}}, function (err) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, err);
                    } else {
                        EntityCache.UserInfoWithToken.update({hgId: userId}, {$set: {'UserContext.GravatarEmail': params.GravatarEmail}}, {multi: true}, function (err) {
                            var buffers = [];
                            if (err) {
                                EventResponder.RespondWithError(EventEmitterCache, params, err);
                            } else {
                                // download the gravatar image
                                https.get('https://www.gravatar.com/avatar/' + cryptoHelper.md5(params.GravatarEmail) + '?s=100&d=identicon', function (ret) {
                                    ret.setEncoding('binary');
                                    ret.on('data', function (chunk) {
                                        buffers.push(chunk);
                                    }).on('end', function () {
                                        // copy the gravatar image to S3
                                        fileUpload.uploadGravatar({
                                            UserId: userId,
                                            Image: buffers,
                                            Callback: function (err) {
                                                if (err) {
                                                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                                                } else {
                                                    EventResponder.RespondWithData(EventEmitterCache, params, 'successful');
                                                }
                                            }
                                        });
                                    });
                                }).on('error', function (e) {
                                    HgLog.error({methodName: 'SetGravatar', error: e.message});
                                    EventResponder.RespondWithError(EventEmitterCache, params, e);
                                });
                            }
                        });
                    }
                });
            } else {
                EventEmitterCache.emit(params.EventName,
                    new EventData(params.correlationId, null, HgError.Enums.Generic.MissingParameters));
            }
        };
        this.GetUserByUsernameOrEmail = function (params, callback) {
            EntityCache.UserInfo.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (error, user) {
                if (error) {
                    return callback(error);
                }
                if (user) {
                    return callback(null, user);
                }
                //didn't find matching by username, now need to find by primiary email
                EntityCache.UserInfo.findOne({'UserPersonal.PrimaryEmail': params.UserEmail}, callback);
            });
        };

        this.GetUserByUserId = function (params, callback) {
            EntityCache.UserInfo.findOne({hgId: params.UserId}, callback);
        };

        this.RemoveGravatar = function (params) {
            var userId = params.UserId;
            if (params.UserId && params.MemberId) {
                EntityCache.Member.update({'hgId': params.MemberId}, {$set: {'GravatarEmail': ''}}, function (err) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.esu');
                    } else {
                        EntityCache.UserInfoWithToken.update({hgId: userId}, {$set: {'UserContext.GravatarEmail': ''}}, function (err) {
                            if (err) {
                                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.usr.esu');
                            } else {
                                if (!params.dontCopyDefault) {
                                    copyUserDefaultAvatar({
                                        UserId: userId,
                                        Callback: function (err) {
                                            if (err) {
                                                EventResponder.RespondWithError(EventEmitterCache, params, err);
                                            } else {
                                                EventResponder.RespondWithData(EventEmitterCache, params, 'successful');
                                            }
                                        }
                                    });
                                } else {
                                    EventResponder.RespondWithData(EventEmitterCache, params, 'successful');
                                }
                            }
                        });
                    }
                });
            } else {
                EventEmitterCache.emit(params.EventName,
                    new EventData(params.correlationId, null, HgError.Enums.Generic.MissingParameters));
            }
        };

        this.UpdateUserInfos = function (params, callback) {
            function updateUserInfo(userInfo, callback) {
                var fieldsToUpdate = ProcessorHelper.GetUpdateJson(params.Fields, userInfo, params.UserId);
                EntityCache.UserInfo.update({hgId: userInfo.hgId}, {$set: fieldsToUpdate}, callback);
            }

            if (!params.UserInfoList || !params.UserInfoList.length) {
                return callback(null, 'User Updated');
            }
            Async.each(params.UserInfoList, updateUserInfo, function (error) {
                callback(null, 'User Updated');
            });
        };

        this.GetUsersByUserIds = function (params, callback) {
            var query = {
                hgId: {
                    $in: params.UserIds
                }
            };
            if (params.GroupId) {
                query['Preference.DefaultGroupId'] = params.GroupId;
            }
            EntityCache.UserInfo.find(query, params.Fields || {}, callback);
        };

        this.GetUsersByUserNames = function (params, callback) {
            var query = {
                LowercaseUserName: {
                    $in: params.UserNames.map(function (item) {
                        return item.toLowerCase();
                    })
                }
            };
            if (params.GroupId) {
                query['Preference.DefaultGroupId'] = params.GroupId;
            }
            EntityCache.UserInfo.find(query, callback);
        };

        this.GetUserInfoByUserName = function (params, callback) {
            EntityCache.UserInfo.findOne({LowercaseUserName: params.UserName.toLowerCase()}, callback);
        };

        this.AddActionTokens = function (params, callback) {
            if (!params.UserActionTokens || !params.UserActionTokens.length) {
                return callback();
            }
            EntityCache.ActionToken.insertMany(params.UserActionTokens, callback);
        };

        this.AddUserSecurityRecords = function (params, callback) {
            if (!params.UserSecurityList || !params.UserSecurityList.length) {
                return callback();
            }
            EntityCache.UserSecurity.insertMany(params.UserSecurityList, callback);
        };

        this.AddUserInfoRecords = function (params, callback) {
            if (!params.UserInfoList || !params.UserInfoList.length) {
                callback(null, 'UserInfo List added');
            }
            EntityCache.UserInfo.insertMany(params.UserInfoList, function (error) {
                if (error) {
                    return callback(error);
                }
                if (params.DoNotCopyDefaultAvatar) {
                    return callback();
                }
                params.UserInfoList.forEach(function (userInfo) {
                    copyUserDefaultAvatar({UserId: userInfo.hgId});
                });
                callback(null, 'UserInfo List added');
            });
        };
        this.GetUserEmailByUserId = function (params, callback) {
            EntityCache.UserInfo.findOne({
                hgId: params.UserId
            }, {
                'UserPersonal.PrimaryEmail': 1
            }, callback);
        };
        this.RemoveUsersSecurityToken = function (params, callback) {
            EntityCache.UserInfoWithToken.remove({hgId: {$in: params.UserIds}}, function (error) {
                if (error) {
                    return callback(error);
                }
                EntityCache.UserSecurityWithToken.remove({hgId: {$in: params.UserIds}}, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, 'Security Tokens Removed');
                });
            });
        };
        //special method used in provision
        this.GetUserIdByUserNames = function (params, callback) {
            EntityCache.UserInfo.find({
                LowercaseUserName: {$in: params.UserNames},
                'Preference.DefaultGroupId': params.GroupId
            }, {hgId: 1}, callback);
        };
        this.GetUserEmailByUserIds = function (params, callback) {
            var dataRecords = {},
                query = {hgId: {$in: params.UserIds}},
                project = {hgId: 1, 'UserPersonal.PrimaryEmail': 1};
            EntityCache.UserInfo.find(query, project, function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.map(function (item) {
                    dataRecords[item.hgId] = item.UserPersonal.PrimaryEmail;
                });
                callback(null, dataRecords);
            });
        };
        this.UpdateDeviceToken = function (params, callback) {
            EntityCache.UserInfoWithToken.update({
                DeviceUuid: params.DeviceUuid
            }, {
                $set: {
                    DeviceToken: params.DeviceToken,
                    RegistrationId: params.RegistrationId
                }
            }, callback);
        };
        //used by provision
        this.GetUserIdsByEmails = function (params, callback) {
            var emailUserIdKey = {},
                query = {
                    'UserPersonal.PrimaryEmail': {$in: params.Emails}
                };
            EntityCache.UserInfo.find(query, {hgId: 1, 'UserPersonal.PrimaryEmail': 1}, function (error, result) {
                if (error) {
                    return callback(error);
                }
                result.map(function (item) {
                    emailUserIdKey[item.UserPersonal.PrimaryEmail.toLowerCase()] = {
                        UserId: item.hgId
                    };
                });
                callback(null, emailUserIdKey);
            });
        };
        //used by provision
        this.GetUserKeyByUserNames = function (params, callback) {
            var userNameUserIdKey = {},
                query = {
                    LowercaseUserName: {$in: params.UserNames}
                };
            if (params.GroupId) {
                query['Preference.DefaultGroupId'] = params.GroupId;
            }
            EntityCache.UserInfo.find(query, {
                hgId: 1,
                LowercaseUserName: 1,
                'UserPersonal.PrimaryEmail': 1,
                'Preference.DefaultGroupId': 1
            }, {
                lean: true
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                result.map(function (item) {
                    userNameUserIdKey[item.LowercaseUserName] = {
                        UserId: item.hgId,
                        Email: item.UserPersonal.PrimaryEmail,
                        GroupId: item.Preference.DefaultGroupId
                    };
                });
                callback(null, userNameUserIdKey);
            });
        };
        this.GetUserIdByUserName = function (params, callback) {
            EntityCache.UserInfo.findOne({
                LowercaseUserName: params.UserName.toLowerCase(),
                'Preference.DefaultGroupId': params.GroupId
            }, {hgId: 1}, callback);
        };
        this.GetUserIdByEmail = function (params, callback) {
            EntityCache.UserInfo.findOne(params.query, {
                hgId: 1,
                'UserPersonal.PrimaryEmail': 1
            }, callback);
        };
        this.GetUserIdsByEmail = function (params, callback) {
            EntityCache.UserInfo.find(params.query, {
                hgId: 1,
                'UserPersonal.PrimaryEmail': 1
            }, callback);
        };
        this.UpdateUserInfo = function (params, callback) {
            EntityCache.UserInfo.update({
                hgId: params.Member.UserId
            }, {
                $set: {
                    UserName: params.Member.UserName.toLowerCase(),
                    LowercaseUserName: params.Member.UserName.toLowerCase(),
                    'UserPersonal.FirstName': params.Member.FirstName,
                    'UserPersonal.LastName': params.Member.LastName,
                    'UserPersonal.FullName': params.Member.FullName,
                    ModifiedBy: params.UserId,
                }
            }, callback);
        };
        this.UpdateUserSecurity = function (params, callback) {
            EntityCache.UserSecurity.update({
                hgId: params.Member.UserId
            }, {
                $set: {
                    UserName: params.Member.UserName.toLowerCase(),
                    LowercaseUserName: params.Member.UserName.toLowerCase(),
                    FirstName: params.Member.FirstName,
                    ModifiedBy: params.UserId
                }
            }, callback);
        };
        this.UpdateUserContextById = function (params, callback) {
            EntityCache.UserInfoWithToken.update({
                hgId: params.Member.UserId,
                UserContext: {$exists: true}
            }, {
                $set: {
                    'UserContext.BirthdateInGroup': params.Member.Birthdate,
                    'UserContext.StartingDateInGroup': params.Member.StartingDate
                }
            }, {
                multi: true
            }, callback);
        };
        this.UpdateUserZipcode = function (params, callback) {
            EntityCache.UserInfo.update({
                hgId: params.Member.UserId
            }, {
                $set: {
                    'Preference.HomeZip': params.Member.HomeZip,
                    'Preference.WorkZip': params.Member.WorkZip
                }
            }, callback);
        };
        this.UpdateUserZipcodeWithToken = function (params, callback) {
            EntityCache.UserInfoWithToken.update({
                hgId: params.Member.UserId
            }, {
                $set: {
                    'Preference.HomeZip': params.Member.HomeZip,
                    'Preference.WorkZip': params.Member.WorkZip
                }
            }, {
                multi: true
            }, callback);
        };
        this.RemoveGroupUserToken = function (params, callback) {
            var userNameList = [],
                cursor = EntityCache.UserInfoWithToken.find({
                    'UserContext.CurrentGroupId': params.GroupId
                }, {
                    UserName: 1
                }, {
                    lean: true
                }).cursor({batchSize: 250});
            cursor.eachAsync(function (item) {
                userNameList.push(item.UserName);
            }).then(function () {
                if (!userNameList.length) {
                    return callback();
                }
                Async.parallel({
                    removeUserInfoToken: function (fcallback) {
                        EntityCache.UserInfoWithToken.remove({
                            UserName: {$in: userNameList}
                        }, fcallback);
                    },
                    RemoveUserSecurityToken: function (fcallback) {
                        EntityCache.UserSecurityWithToken.remove({
                            UserName: {$in: userNameList}
                        }, fcallback);
                    }
                }, callback);
            });
        };
        this.RemoveGroupUserSecurityToken = function (params, callback) {
            EntityCache.UserSecurityWithToken.remove({
                hgId: params.Member.UserId
            }, callback);
        };
        this.RemoveUserInfoToken = function (params, callback) {
            EntityCache.UserInfoWithToken.remove({hgId: params.Member.UserId}, callback);
        };
        this.RemoveUserSecurityToken = function (params, callback) {
            EntityCache.UserSecurityWithToken.remove({hgId: params.Member.UserId}, callback);
        };
        this.UpdateUserEmail = function (params, callback) {
            EntityCache.UserInfo.update({
                hgId: params.Member.UserId
            }, {
                $set: {
                    'UserPersonal.PrimaryEmail': params.Member.PrimaryEmail,
                    ModifiedBy: params.UserId
                }
            }, callback);
        };
        this.GetUsersWithoutAvatars = function (params, callback) {
            var condition = {
                'Preference.DefaultGroupId': params.GroupId,
                AvatarUploaded: {$in: [null, false]}
            };
            if (params.UserIds && params.UserIds.length) {
                condition.hgId = {$in: params.UserIds};
            }
            EntityCache.UserInfo.find(condition, {
                'UserPersonal.FullName': 1,
                'UserPersonal.PrimaryEmail': 1
            }, {
                lean: true
            }, callback);
        };
        this.MassAvatarUploaded = function (params, callback) {
            EntityCache.UserInfo.update({
                'Preference.DefaultGroupId': params.GroupId,
                hgId: {$in: params.UserIds}
            }, {
                $set: {
                    AvatarUploaded: true,
                    AvatarVersion: Date.now()
                }
            }, {
                multi: true
            }, callback);
        };
        this.GetNeverLoggedInUsers = function (params, callback) {
            EntityCache.UserInfo.find({
                'Preference.DefaultGroupId': params.GroupIdToSend,
                LastLoginTime: 0
            }, params.Fields).sort({_id: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.MobileUserCheckIn = function (params, callback) {
            EntityCache.UserInfo.update({
                hgId: params.UserId
            }, {
                $set: {
                    LastCheckInTime: Date.now()
                }
            }, callback);
        };
        this.DisableSurveyMode = function (params, callback) {
            EntityCache.UserInfoWithToken.update({
                UserToken: params.UserToken
            }, {
                $set: {
                    SurveyAccessModeInProgress: false
                }
            }, callback);
        };
        this.EnableAdminKioskMode = function (params, callback) {
            var query = params.ActAsUserToken ? { ActAsUserToken: params.ActAsUserToken} : { UserToken: params.UserToken };
            EntityCache.UserInfoWithToken.update(query, {
                $set: {
                    SurveyAccessModeInProgress: true
                }
            }, callback);
        };
    };
module.exports = UserProcessor;
