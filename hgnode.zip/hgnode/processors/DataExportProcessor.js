/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    DataExportProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid'),
            ProcessorHelper = require('../util/ProcessorHelper.js');

        this.GetExportedDataByStatus = function (params, callback) {
            EntityCache.DataExport.find({Status : params.Status}, function (err, data) {
                if (err) {
                    callback(err, null);
                } else {
                    callback(null, data);
                }
            });
        };

        this.GetRecordById = function (params, callback) {
            EntityCache.DataExport.findOne({'hgId' : params.DataExportId}, function (err, data) {
                if (err) {
                    callback(err, null);
                } else {
                    callback(null, data);
                }
            });
        };

        this.Create = function (params, callback) {
            var exportObj = new EntityCache.DataExport({
                hgId: guid.v1(),
                GroupName: params.GroupName,
                GroupId: params.GroupId,
                CreatedBy: params.CreatedBy,
                CreatedDate: Date.now()
            });
            exportObj.save(callback);
        };

        this.Update = function (params, callback) {
            var fieldsToUpdate = ProcessorHelper.GetUpdateJson(params.Fields, params.DataExport, params.UserId);
            EntityCache.DataExport.update({hgId : params.DataExport.hgId}, {$set: fieldsToUpdate}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'Record Updated');
                }
            });
        };
    };

module.exports = DataExportProcessor;
