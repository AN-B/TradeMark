/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    PerformanceProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            HGActivityLog = require('../framework/HGActivityLog.js'),
            guid = require('node-uuid'),
            EventResponder = require('../util/EventResponder.js'),
            PerformanceEnums = require('../enums/PerformanceEnums.js'),
            PerformanceCard = EntityCache.PerformanceCard,
            PerformanceReview = EntityCache.PerformanceReview,
            PerformanceCycle = EntityCache.PerformanceCycle,
            Member = EntityCache.Member,
            QuestionTemplate = EntityCache.QuestionTemplate,
            AnswerTemplate = EntityCache.AnswerTemplate,
            DailyHourRangeType = require('../enums/DailyHourRangeType.js'),
            ArchiveRecordEnums = require('../enums/ArchiveRecordEnums.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            Team = EntityCache.Team,
            Async = require('async'),
            HgError = require('../common/HgError.js'),
            HgMessage = require('../common/HgMessage.js'),
            paramUtil = require('../util/params.js'),
            HgLog = require('../framework/HgLog.js'),
            i18nHelper = require('../helpers/i18nHelper.js'),
            self = this,
            activeStatus = [
                PerformanceEnums.ReviewStatus.NotStarted,
                PerformanceEnums.ReviewStatus.InProgress,
                PerformanceEnums.ReviewStatus.Submitted,
                PerformanceEnums.ReviewStatus.WaitingForSignOff,
                PerformanceEnums.ReviewStatus.Overdue,
                PerformanceEnums.ReviewStatus.Closed,
                PerformanceEnums.ReviewStatus.PendingDelivery
            ],
            getSelectionByValue = function (value, question) {
                var i,
                    len = question.AnswerSelectors.length,
                    retVal;
                for (i = 0; i < len; i += 1) {
                    if (value === question.AnswerSelectors[i].Value) {
                        retVal = question.AnswerSelectors[i];
                        break;
                    }
                }
                return retVal;
            },
            shapeAnswerDTO = function (answer, question) {
                var dto = {
                        MemberId: answer.MemberId,
                        MemberName: answer.MemberName,
                        PeopleType: answer.PeopleType,
                        Text: answer.Text,
                        SelectedValues: answer.SelectedValues,
                        TrackId: answer.TrackId,
                        Selections: []
                    },
                    i,
                    len,
                    selection;
                if (answer.SelectedValues && answer.SelectedValues.length) {
                    for (i = 0, len = answer.SelectedValues.length; i < len; i += 1) {
                        selection = getSelectionByValue(answer.SelectedValues[i], question);
                        if (selection) {
                            dto.Selections.push({
                                Value: selection.Value,
                                Text: selection.Text
                            });
                        }
                    }
                }
                return dto;
            },

            hideUnauthorizedAnswersInQuestion = function (question, myTypeInReview, memberId, iCanSeeResponse, canSeeReleasedVersion) {
                var i,
                    len,
                    answers = [];
                for (i = 0, len = question.Answers.length; i < len; i += 1) {
                    if (myTypeInReview === PerformanceEnums.DefaultPeopleTypes.Admin) {
                        answers.push(shapeAnswerDTO(question.Answers[i], question));
                    } else {
                        if (question.Confidential !== true || myTypeInReview !== PerformanceEnums.DefaultPeopleTypes.Subject) {
                            if (question.Answers[i].MemberId !== memberId) {
                                if (iCanSeeResponse || canSeeReleasedVersion) {
                                    answers.unshift(shapeAnswerDTO(question.Answers[i], question));
                                }
                            } else {
                                answers.push(shapeAnswerDTO(question.Answers[i], question));
                            }
                        }
                    }
                }
                question.Answers = answers;
            },

            hideUnauthorizedQuestionsInSection = function (section, myTypeInReview, memberId, iCanSeeResponse, canSeeReleasedVersion) {
                var Questions = [];
                if (section) {
                    section.Questions.forEach(function (question) {
                        var addQuestion = false;
                        hideUnauthorizedAnswersInQuestion(question, myTypeInReview, memberId, iCanSeeResponse, canSeeReleasedVersion);
                        if (question.OptionalTo && question.OptionalTo.indexOf(myTypeInReview) !== -1) {
                            question.OptionalToMe = true;
                        }
                        addQuestion |= iCanSeeResponse && !question.Confidential;
                        addQuestion |= iCanSeeResponse && myTypeInReview !== PerformanceEnums.DefaultPeopleTypes.Subject;
                        addQuestion |= [PerformanceEnums.DefaultPeopleTypes.Admin, PerformanceEnums.DefaultPeopleTypes.Manager].indexOf(myTypeInReview) !== -1;
                        addQuestion |= question.ToBeAnsweredBy.indexOf(myTypeInReview) !== -1;
                        addQuestion |= myTypeInReview === PerformanceEnums.DefaultPeopleTypes.Subject && !question.Confidential;
                        //if I should answer this question or i'm the subject
                        if (addQuestion) {
                            Questions.push(question);
                        }
                    });
                    section.Questions = Questions;
                }
            },
            hideUnauthorizedQuestionsInReview = function (review, memberId, canSeeReleasedVersion) {
                var i,
                    len = review.Card.Sections.length;
                for (i = 0; i < len; i += 1) {
                    hideUnauthorizedQuestionsInSection(review.Card.Sections[i], review.MyTypeInReview, memberId, review.ICanSeeResponse, canSeeReleasedVersion);
                }
            },
            hideAnonymousPeopleInAnswers = function (review, anonymousMemberIds, anonymousIds) {
                var anonymousIndex;
                review.Card.Sections.forEach(function (section) {
                    section.Questions.forEach(function (question) {
                        question.Answers.forEach(function (answer) {
                            anonymousIndex = anonymousMemberIds.indexOf(answer.MemberId);
                            if (anonymousIndex > -1) {
                                if (anonymousIds.length > 1) {
                                    answer.MemberName = 'Anonymous ' + anonymousIds[anonymousIndex];
                                } else {
                                    answer.MemberName = 'Anonymous';
                                }
                            }
                        });
                    });
                });
            },
            resolveMyRejectees = function (peoples, me) {
                if (me.CanReject !== true) {
                    return null;
                }
                return peoples.filter(function (people) {
                    return people.PeopleType === me.RejectPeopleType && people.StatusInCurrentReview === PerformanceEnums.ParticipantStatus.Submitted;
                }).map(function (peep) {
                    return peep.MemberFullname;
                });
            },
            resolveICanReject = function (peoples, me) {
                if (me.CanReject !== true) {
                    return false;
                }
                return peoples.some(function (people) {
                    return people.PeopleType === me.RejectPeopleType && people.StatusInCurrentReview === PerformanceEnums.ParticipantStatus.Submitted;
                });
            },
            resolveICanReqEdit = function (review, me) {
                //you haven't submitted the review, why do you need to "Request edit"?
                if (me.StatusInCurrentReview !== PerformanceEnums.ParticipantStatus.Submitted) {
                    return false;
                }
                if ([PerformanceEnums.ReviewStatus.Archived, PerformanceEnums.ReviewStatus.Closed].indexOf(review.StatusByAdminView) > -1) {//the review has been archived or closed
                    return false;
                }
                //the review has been released
                if (review.MeetingDate && review.MeetingDate < new Date().getTime()) {
                    return false;
                }
                return true;
            },
            getAnonymousText = function (params) {
                if (params.count > 1) {
                    return i18nHelper.translate(params.lang, 'common.anx', {index: params.id});
                }
                return i18nHelper.translate(params.lang, 'common.ann');
            },
            shapeReviewDataForRendering = function (params) {
                var memberId = params.MemberId,
                    review = params.Review,
                    rolesInGroup = params.RolesInGroup,
                    userId = params.UserId,
                    subordinateMemberIds = params.SubordinateMemberIds,
                    seeAllCycles = params.SeeAllCycles,
                    lang = params.Lang,
                    anonymousMemberIds = [],
                    anonymousIds = [],
                    i,
                    len = review.Peoples.length,
                    anonymousCount = 0,
                    subjectMemberId,
                    canSeeReleasedVersion = false,
                    meInReview,
                    initiators;
                for (i = 0; i < len; i += 1) {
                    if (review.Peoples[i].Anonymous) {
                        anonymousCount += 1;
                    }
                    if (review.Peoples[i].PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject) {
                        subjectMemberId = review.Peoples[i].MemberId;
                    }
                }
                if (review.ArchivedPeoples) {
                    anonymousCount += review.ArchivedPeoples.filter(function (peep) {
                        return peep.Anonymous;
                    }).length;
                }
                review.MyTypeInReview = null;
                review.Peoples.forEach(function (data) {
                    if (data.MemberId === memberId) {
                        review.MyTypeInReview = data.PeopleType;
                        review.MyStatusInCurrentReview = data.StatusInCurrentReview;
                        review.MyPercentAchieved = data.PercentAchieved;
                        review.MyDueDate = data.DueDate;
                        review.MySubmitDate = data.SubmitDate;
                        review.MyAnonymous = data.Anonymous;
                        review.MyAnonymousId = data.AnonymousId;
                        review.ICanSeeResponse = data.CanSeeResponse;
                        review.ICanReject = resolveICanReject(review.Peoples, data);
                        review.ICanReqEdit = resolveICanReqEdit(review, data);
                        review.MyRejectees = resolveMyRejectees(review.Peoples, data);
                        review.ICanSignOff = data.SignsOff;
                    }
                    if (data.Anonymous) {
                        anonymousMemberIds.push(data.MemberId);
                        anonymousIds.push(parseInt(data.AnonymousId, 10));
                        data.MemberFullname = getAnonymousText({count: anonymousCount, id: data.AnonymousId, lang: lang});
                        data.MemberId = '';
                        data.UserId = '';
                    }
                });
                if (review.ArchivedPeoples) {
                    review.ArchivedPeoples.forEach(function (peep) {
                        if (peep.Anonymous) {
                            anonymousMemberIds.push(peep.MemberId);
                            peep.AnonymousId = peep.AnonymousId || Math.max.apply(null, anonymousIds) + 1;
                            anonymousIds.push(parseInt(peep.AnonymousId, 10));
                            peep.MemberFullname = getAnonymousText({
                                count: anonymousCount,
                                id: peep.AnonymousId,
                                lang: lang
                            });
                            peep.MemberId = '';
                            peep.UserId = '';
                        }
                    });
                }
                if (!review.MyTypeInReview) {
                    if (rolesInGroup.indexOf(PerformanceEnums.DefaultPeopleTypes.Admin) > -1 || rolesInGroup.indexOf('Owner') > -1 || rolesInGroup.indexOf('HGAdmin') > -1 || review.CreatedBy === userId || seeAllCycles === true) {
                        review.MyTypeInReview = PerformanceEnums.DefaultPeopleTypes.Admin;
                    }
                }
                if (!review.MyTypeInReview) {
                    if (subordinateMemberIds.indexOf(subjectMemberId) > -1) {
                        review.MyTypeInReview = PerformanceEnums.DefaultPeopleTypes.Manager;
                    }
                }
                if ([PerformanceEnums.ReviewStatus.Submitted,
                        PerformanceEnums.ReviewStatus.Closed].indexOf(review.StatusByAdminView) > -1  &&
                        review.MeetingDate && review.MeetingDate < Date.now() &&
                        [PerformanceEnums.DefaultPeopleTypes.Subject,
                            PerformanceEnums.DefaultPeopleTypes.Manager,
                            PerformanceEnums.DefaultPeopleTypes.Admin].indexOf(review.MyTypeInReview) > -1) {
                    canSeeReleasedVersion = true;
                }
                if (review.NeedsSignOff && review.StatusByAdminView === PerformanceEnums.ReviewStatus.Closed &&
                        [PerformanceEnums.DefaultPeopleTypes.Subject,
                            PerformanceEnums.DefaultPeopleTypes.Manager,
                            PerformanceEnums.DefaultPeopleTypes.Admin].indexOf(review.MyTypeInReview) > -1) {
                    canSeeReleasedVersion = true;
                }
                if (review.ICanSignOff &&
                        review.StatusByAdminView === PerformanceEnums.ReviewStatus.WaitingForSignOff &&
                        review.MyTypeInReview === PerformanceEnums.DefaultPeopleTypes.Subject) {
                    meInReview = review.Peoples.filter(function (p) {
                        return p.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject;
                    });
                    initiators = review.Peoples.filter(function (p) {
                        return p.InitiatesSignOff && p.SignsOff;
                    });
                    if (meInReview.length && meInReview[0].InitiatesSignOff) {
                        canSeeReleasedVersion = true;
                    }
                    if (!canSeeReleasedVersion && !initiators.some(function (p) {
                            return p.StatusInCurrentReview !== PerformanceEnums.ParticipantStatus.SignedOff;
                        })) {
                        canSeeReleasedVersion = true;
                    }
                }

                hideUnauthorizedQuestionsInReview(review, memberId, canSeeReleasedVersion);
                if (anonymousMemberIds.length > 0) {
                    hideAnonymousPeopleInAnswers(review, anonymousMemberIds, anonymousIds);
                }
            },
            shapeReviewData = function (memberId, review, rolesInGroup, returnAllQuestions, subordinateMemberIds, ViewedMemberIsSubordinate) {
                var allQuestions = [],
                    i,
                    len = review.Peoples.length,
                    subjectMemberId;
                for (i = 0; i < len; i += 1) {
                    if (review.Peoples[i].PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject) {
                        subjectMemberId = review.Peoples[i].MemberId;
                    }
                }
                review.MyTypeInReview = null;
                review.Peoples.forEach(function (data) {
                    if (data.MemberId === memberId) {
                        review.MyTypeInReview = data.PeopleType;
                        review.MyStatusInCurrentReview = data.StatusInCurrentReview;
                        review.MyPercentAchieved = data.PercentAchieved;
                        review.MyDueDate = data.DueDate;
                        review.MySubmitDate = data.SubmitDate;
                        review.MyAnonymous = data.Anonymous;
                        review.MyAnonymousId = data.AnonymousId;
                        review.MyMemberId = data.MemberId;
                        review.ICanSeeResponse = data.CanSeeResponse;
                        review.ICanReject = resolveICanReject(review.Peoples, data);
                        review.ICanReqEdit = resolveICanReqEdit(review, data);
                        review.MyRejectees = resolveMyRejectees(review.Peoples, data);
                    }
                });
                if (!review.MyTypeInReview) {
                    if (rolesInGroup.indexOf(PerformanceEnums.DefaultPeopleTypes.Admin) > -1 || rolesInGroup.indexOf('Owner') > -1 || rolesInGroup.indexOf('HGAdmin') > -1) {
                        review.ICanSeeResponse = true;
                        review.MyTypeInReview = PerformanceEnums.DefaultPeopleTypes.NA;
                    }
                }
                if (!review.MyTypeInReview && subordinateMemberIds && subordinateMemberIds.length > 0 && subordinateMemberIds.indexOf(subjectMemberId) > -1) {
                    review.MyTypeInReview = PerformanceEnums.DefaultPeopleTypes.NA;
                }
                if (!review.MyTypeInReview && ViewedMemberIsSubordinate) {
                    review.MyTypeInReview = PerformanceEnums.DefaultPeopleTypes.NA;
                }
                if (!returnAllQuestions) {
                    hideUnauthorizedQuestionsInReview(review, memberId);
                    review.Card.Sections.forEach(function (section) {
                        var myQuestions = section.Questions.filter(function (question) {
                            return question.ToBeAnsweredBy && question.ToBeAnsweredBy.indexOf(review.MyTypeInReview) !== -1;
                        });
                        allQuestions = allQuestions.concat(myQuestions);
                    });
                    review.TotalOptionalQuestions = allQuestions.filter(function (q) {return q.OptionalTo && q.OptionalTo.indexOf(review.MyTypeInReview) !== -1; }).length;
                    review.TotalRequiredQuestions = allQuestions.length - review.TotalOptionalQuestions;
                    review.AnsweredRequiredQuestions = allQuestions.filter(function (q) {return !(q.OptionalTo && q.OptionalTo.indexOf(review.MyTypeInReview) !== -1) && q.Answers && q.Answers.filter(function (a) {return a.MemberId === memberId; }).length > 0; }).length;
                }
            },
            shapeReviewDataForRenderingEmployeeView = function (params) {//memberId, review, rolesInGroup, userId
                var anonymousMemberIds = [],
                    anonymousIds = [],
                    anonymousCount = params.Review.Peoples.filter(function (peep) {
                        return peep.Anonymous;
                    }).length,
                    allQuestions = [],
                    lang = params.Lang,
                    meInReview = params.Review.Peoples.filter(function (p) {
                        return p.MemberId === params.CurMemberId;
                    }),
                    iCanSeeResponse = false;
                params.Review.MyTypeInReview = null;
                if (params.Review.ArchivedPeoples) {
                    anonymousCount += params.Review.ArchivedPeoples.filter(function (peep) {
                        return peep.Anonymous;
                    }).length;
                }
                if (meInReview && meInReview.length && meInReview[0].PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject) {//if i'm the Reviewee, return immediately because i don't have access to this
                    return;
                }
                if (meInReview && meInReview.length && meInReview[0].CanSeeResponse) {//if i'm a party in review, and i can see response
                    iCanSeeResponse = true;
                }
                if (params.Review.CreatedBy === params.CurUserId) {
                    iCanSeeResponse = true;
                }
                if (!iCanSeeResponse) {//if i can't see response
                    if (params.RolesInGroup.indexOf(PerformanceEnums.DefaultPeopleTypes.Admin) === -1 && params.RolesInGroup.indexOf('Owner') === -1 && params.RolesInGroup.indexOf('HGAdmin') === -1) {//and i'm not an admin in group
                        return;
                    }
                }
                params.Review.Peoples.forEach(function (data) {
                    if (data.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject) {
                        params.Review.MyTypeInReview = data.PeopleType;
                        params.Review.MyStatusInCurrentReview = data.StatusInCurrentReview;
                        params.Review.MyPercentAchieved = data.PercentAchieved;
                        params.Review.MyDueDate = data.DueDate;
                        params.Review.MySubmitDate = data.SubmitDate;
                        params.Review.MyAnonymous = data.Anonymous;
                        params.Review.MyAnonymousId = data.AnonymousId;
                        params.Review.MyMemberId = data.MemberId;
                        params.Review.ICanSeeResponse = data.CanSeeResponse;
                        params.Review.ICanReject = resolveICanReject(params.Review.Peoples, data);
                        params.Review.ICanReqEdit = resolveICanReqEdit(params.Review, data);
                        params.Review.MyRejectees = resolveMyRejectees(params.Review.Peoples, data);
                    }
                    if (data.Anonymous) {
                        anonymousMemberIds.push(data.MemberId);
                        anonymousIds.push(data.AnonymousId);
                        data.MemberFullname = getAnonymousText({count: anonymousCount, id: data.AnonymousId, lang: lang});
                        data.MemberId = '';
                        data.UserId = '';
                    }
                });
                if (params.Review.ArchivedPeoples) {
                    params.Review.ArchivedPeoples.forEach(function (peep) {
                        if (peep.Anonymous) {
                            anonymousMemberIds.push(peep.MemberId);
                            peep.AnonymousId = peep.AnonymousId || Math.max.apply(null, anonymousIds) + 1;
                            anonymousIds.push(parseInt(peep.AnonymousId, 10));
                            peep.MemberFullname = getAnonymousText({
                                count: anonymousCount,
                                id: peep.AnonymousId,
                                lang: lang
                            });
                            peep.MemberId = '';
                            peep.UserId = '';
                        }
                    });
                }
                hideUnauthorizedQuestionsInReview(params.Review, params.CurMemberId, true);
                params.Review.Card.Sections.forEach(function (section) {
                    var myQuestions = section.Questions.filter(function (question) {
                        return question.ToBeAnsweredBy && question.ToBeAnsweredBy.indexOf(params.Review.MyTypeInReview) !== -1;
                    });
                    allQuestions = allQuestions.concat(myQuestions);
                });
                params.Review.TotalOptionalQuestions = allQuestions.filter(function (q) {return q.OptionalTo && q.OptionalTo.indexOf(params.Review.MyTypeInReview) !== -1; }).length;
                params.Review.TotalRequiredQuestions = allQuestions.length - params.Review.TotalOptionalQuestions;
                params.Review.AnsweredRequiredQuestions = allQuestions.filter(function (q) {return !(q.OptionalTo && q.OptionalTo.indexOf(params.Review.MyTypeInReview) !== -1) && q.Answers && q.Answers.filter(function (a) {return a.MemberId === params.CurMemberId; }).length > 0; }).length;
                if (anonymousMemberIds.length > 0) {
                    hideAnonymousPeopleInAnswers(params.Review, anonymousMemberIds, anonymousIds);
                }
            },
            populateQuestionId = function (card) {
                var i,
                    sLen,
                    j,
                    qLen;
                for (i = 0, sLen = card.Sections.length; i < sLen; i += 1) {
                    if (!card.Sections[i].hgId || card.Sections[i].hgId.length < 1) {
                        card.Sections[i].hgId = guid.v1();
                    }
                    for (j = 0, qLen = card.Sections[i].Questions.length; j < qLen; j += 1) {
                        if (!card.Sections[i].Questions[j].hgId || card.Sections[i].Questions[j].hgId.length < 1) {
                            card.Sections[i].Questions[j].hgId = guid.v1();
                        }
                    }
                }
            },
            getReviewsForCycle = function (params, callback) {
                var condition = {
                        CycleId: params.CycleId,
                        StatusByAdminView: {$in: activeStatus}
                    };
                if (params.DeptName) {
                    condition['Peoples.Department'] = params.DeptName;
                }
                if (params.CardId) {
                    condition['Card.hgId'] = params.CardId;
                }
                PerformanceReview.find(condition, function (err, reviews) {
                    if (err) {
                        return callback(err);
                    }
                    // return all reviews in which the subject's department matches the department filter while nulling out any zero-value dates
                    callback(null, reviews.filter(function (review) {
                        // if no department filter is passed in, then always include the review in this filter
                        var includeIt = !params.DeptName;
                        review.Peoples.forEach(function (peep) {
                            peep.DueDate = peep.DueDate || null;
                            peep.SubmitDate = peep.SubmitDate || null;
                            if (peep.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject && peep.Department === params.DeptName) {
                                includeIt = true;
                            }
                        });
                        return includeIt;
                    }));
                });
            },
            importOneQuestion = function (request, callback) {
                QuestionTemplate.findOne({QuestionText: request.QuestionText}, function (err, template) {
                    if (err) {
                        return callback(err);
                    }
                    if (template) {
                        return callback();
                    }
                    template = EntityCache.QuestionTemplate(request);
                    template.hgId = guid.v1();
                    template.save(function (err) {
                        if (err) {
                            return callback(err);
                        }
                        callback();
                    });
                });
            },

            importOneAnswer = function (request, callback) {
                AnswerTemplate.findOne({Text: request.Text}, function (err, template) {
                    if (err) {
                        return callback(err);
                    }
                    if (template) {
                        return callback();
                    }
                    template = EntityCache.AnswerTemplate(request);
                    template.hgId = guid.v1();
                    template.save(function (err) {
                        if (err) {
                            return callback(err);
                        }
                        callback();
                    });
                });
            },
            resolvePeopleTypesHaveQuestionsInCard = function (card) {
                var peopleTypeIndex,
                    pLen,
                    sectionIndex,
                    sLen,
                    questionIndex,
                    qLen;
                for (peopleTypeIndex = 0, pLen = card.PeopleTypes.length; peopleTypeIndex < pLen; peopleTypeIndex += 1) {
                    card.PeopleTypes[peopleTypeIndex].ContainQuestionForMe = false;
                    for (sectionIndex = 0, sLen = card.Sections.length; sectionIndex < sLen; sectionIndex += 1) {
                        for (questionIndex = 0, qLen = card.Sections[sectionIndex].Questions.length; questionIndex < qLen; questionIndex += 1) {
                            if (card.Sections[sectionIndex].Questions[questionIndex].ToBeAnsweredBy.indexOf(card.PeopleTypes[peopleTypeIndex].PeopleTypeName) > -1) {
                                card.PeopleTypes[peopleTypeIndex].ContainQuestionForMe = true;
                                sectionIndex = sLen;
                                break;
                            }
                        }
                    }
                }
            },

            isDetectableRolesOnly = function (card) {
                var detectableRolesOnly = true;
                card.PeopleTypes.forEach(function (peopleType) {
                    if (peopleType.ContainQuestionForMe) {
                        if (!peopleType.Hierarchy &&
                                peopleType.PeopleTypeName !== PerformanceEnums.DefaultPeopleTypes.Subject &&
                                peopleType.PeopleTypeName !== PerformanceEnums.DefaultPeopleTypes.Manager) {
                            detectableRolesOnly = false;
                        }
                    }
                });
                return detectableRolesOnly;
            },
            convertReviewSummary = function (review) {
                return {
                    ReviewId: review.hgId,
                    Peoples: review.Peoples,
                    StatusByAdminView: review.StatusByAdminView,
                    DetectableRolesOnly: review.Card.DetectableRolesOnly,
                    CardTitle: review.Card.Title,
                    CardId: review.Card.hgId,
                    MeetingDate: review.MeetingDate
                };
            },
            getCycleQuery = function (params, callback) {
                var cycleIds = [],
                    deliveriesIds = [],
                    returnedCycleIndex = {},
                    createdBy,
                    projection = {
                        hgId: true,
                        Title: true,
                        GroupId: true,
                        GroupName: true,
                        ReviewPeriodStart: true,
                        ReviewPeriodEnd: true,
                        PercentCompletion: true,
                        PercentPreInProgess: true,
                        'Cards.Title': true
                    },
                    mquery = PerformanceCycle.find({GroupId: params.GroupId}, projection);
                if (!params.GetAllCycles) {
                    mquery = mquery.where('CreatedBy', params.UserId);
                    mquery.options = {sort: {CreatedDate: -1}};
                } else {
                    if (params.CreatedBy && params.CreatedBy.length > 0) {
                        createdBy = params.CreatedBy.split(',');
                        mquery = mquery.where('CreatedBy').in(createdBy);
                    }
                }
                if (params.Title) {
                    params.Title = paramUtil.EscapeBadChars(params.Title);
                }
                if (params.TagCycleIds && params.TagCycleIds.length > 0 && params.Title) {
                    mquery.or = [{hgId: { $in: params.TagCycleIds} }, {Title: new RegExp(["^.*", params.Title, ".*$"].join(""), "i")}];
                } else if (params.Title) {
                    mquery.where('Title', new RegExp(["^.*", params.Title, ".*$"].join(""), "i"));
                } else if (params.TagCycleIds && params.TagCycleIds.length > 0) {
                    mquery.where('hgId', { $in: params.TagCycleIds});
                }
                if (params.Status === 'Completed') {
                    mquery.where('PercentCompletion', 100);
                }
                if (params.Status === PerformanceEnums.ReviewStatus.InProgress) {
                    mquery.where('PercentPreInProgess', {$lt: 100 });
                    mquery.where('PercentCompletion', {$lt: 100 });
                }
                if (params.Status === PerformanceEnums.ReviewStatus.NotStarted) {
                    mquery.where('PercentPreInProgess', 100);
                }
                if (params.StartDate && params.EndDate) {
                    mquery.where('CreatedDate', { $gte: params.StartDate, $lte: params.EndDate});
                }
                mquery.exec(function (error, cycles) {
                    if (error) { return callback(error); }
                    if (!cycles  || cycles.length === 0) {
                        return callback(null, {
                            CycleIds: cycleIds,
                            DeliveriesIds: deliveriesIds
                        });
                    }
                    cycles.forEach(function (cycle) {
                        cycleIds.push(cycle.hgId);
                        returnedCycleIndex[cycle.hgId] = cycle;
                    });
                    callback(null, {
                        CycleIds: cycleIds,
                        DeliveriesIds: deliveriesIds,
                        ReturnedCycleIndex: returnedCycleIndex
                    });
                });
            };

        this.CloseOutstandingReviewsByCycleId = function (params) {
            PerformanceReview.update(
                {CycleId: params.CycleId, StatusByAdminView: {$in: [
                    PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Overdue
                ]}},
                {$set: {StatusByAdminView: PerformanceEnums.ReviewStatus.Closed}},
                {multi: true},
                function (err) {
                    EventResponder.RespondGeneric(EventEmitterCache, params, err, HgError.Enums.Perform.OutstandingReviewsClosed);
                }
            );
        };
        this.CloseReviewsForOffboardedReviewees = function (params, callback) {
            var updateOneCyclePercentCompletion = function (cycle, asyncCallback) {
                    self.UpdateCyclePercentCompletion({CycleId: cycle.hgId}, asyncCallback);
                },
                funcFilter = function (review) {
                    return review.CycleId;
                },
                syncReviewCycleForOffboardedReviewee = function (review, asyncCallback) {
                    var subject = review.Peoples.filter(function (p) {
                            return p.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject;
                        });
                    if (!subject || !subject.length) {
                        return asyncCallback('cannot find the subject');//ESB, no translation
                    }
                    EntityCache.PerformanceCycle.findOne({hgId: review.CycleId}, function (error, cycle) {
                        if (error) {
                            return asyncCallback(error);
                        }
                        HGActivityLog.Archive({
                            Collection: ArchiveRecordEnums.Collection.PerformanceCycle,
                            Content: cycle,
                            Note: ArchiveRecordEnums.Reason.ChangeDueToManagerTransfer,
                            CreatedBy: params.UserId
                        }, function (error) {
                            if (error) {
                                return asyncCallback(error);
                            }
                            var cardFromCycle = cycle.Cards.filter(function (c) {
                                    return c.hgId === review.Card.hgId;
                                });
                            if (!cardFromCycle || !cardFromCycle.length) {
                                return asyncCallback('cannot find the card');//ESB, no translation
                            }
                            cardFromCycle[0].Assignments = cardFromCycle[0].Assignments.filter(function (assignment) {
                                return !assignment.Participants.some(function (participant) {
                                    return participant.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject && participant.EntityId === subject[0].MemberId;
                                });
                            });
                            cycle.save(asyncCallback);
                        });
                    });
                },
                closeOneReview = function (review, asyncCallback) {
                    review.StatusByAdminView = PerformanceEnums.ReviewStatus.Closed;
                    review.Peoples.forEach(function (people) {
                        if ([PerformanceEnums.ParticipantStatus.NA, PerformanceEnums.ParticipantStatus.Submitted].
                                indexOf(people.StatusInCurrentReview) === -1) {
                            people.StatusInCurrentReview = PerformanceEnums.ParticipantStatus.Closed;
                        }
                    });
                    review.save(function (error) {
                        if (error) {
                            return asyncCallback(error);
                        }
                        syncReviewCycleForOffboardedReviewee(review, asyncCallback);
                    });
                };
            Async.each(params.Reviews, closeOneReview, function (error) {
                if (error) {
                    return callback(error);
                }
                EntityCache.PerformanceCycle.find({
                    hgId: {$in: params.Reviews.map(funcFilter)}
                }, function (error, cycles) {
                    if (error) {
                        return callback(error);
                    }
                    Async.each(cycles, updateOneCyclePercentCompletion, callback);
                });
            });
        };
        this.RemoveOffboardedReviewers = function (params, callback) {
            var syncReviewCycleForOffboardedReviewer  = function (review, asyncCallback) {
                    var subject = review.Peoples.filter(function (p) {
                            return p.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject;
                        }),
                        matchingAssignment;
                    if (!subject || !subject.length) {
                        return asyncCallback('cannot find the subject');//ESB, no translation
                    }
                    EntityCache.PerformanceCycle.findOne({hgId: review.CycleId}, function (error, cycle) {
                        if (error) {
                            return asyncCallback(error);
                        }
                        HGActivityLog.Archive({
                            Collection: ArchiveRecordEnums.Collection.PerformanceCycle,
                            Content: cycle,
                            Note: ArchiveRecordEnums.Reason.ChangeDueToManagerTransfer,
                            CreatedBy: params.UserId
                        }, function (error) {
                            if (error) {
                                return asyncCallback(error);
                            }
                            var cardFromCycle = cycle.Cards.filter(function (c) {
                                    return c.hgId === review.Card.hgId;
                                });
                            if (!cardFromCycle || !cardFromCycle.length) {
                                return asyncCallback('cannot find the card');//ESB, no translation
                            }
                            matchingAssignment = cardFromCycle[0].Assignments.filter(function (assignment) {
                                return assignment.Participants.some(function (participant) {
                                    return participant.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject && participant.EntityId === subject[0].MemberId;
                                });
                            });
                            if (!matchingAssignment || !matchingAssignment.length) {
                                return asyncCallback('cannot find the assignment');
                            }
                            matchingAssignment[0].Participants = matchingAssignment[0].Participants.filter(function (participant) {
                                return participant.EntityId !== params.MemberId;
                            });
                            cycle.save(asyncCallback);
                        });
                    });
                },
                removeOneOffboardedReviewer = function (review, asyncCallback) {
                    review.ArchivedPeoples = review.ArchivedPeoples.concat(review.Peoples.filter(function (p) {
                        return p.MemberId === params.MemberId;
                    }));
                    review.Peoples = review.Peoples.filter(function (p) {
                        return p.MemberId !== params.MemberId;
                    });
                    review.Card.Sections.forEach(function (section) {
                        section.Questions.forEach(function (question) {
                            question.Answers = question.Answers.filter(function (answer) {
                                return answer.MemberId !== params.MemberId;
                            });
                        });
                    });
                    var pplWithQuestions = review.Peoples.filter(function (p) {return p.ContainQuestionForMe; }),
                        submitted = pplWithQuestions.filter(function (p) {return p.StatusInCurrentReview === PerformanceEnums.ParticipantStatus.Submitted; }),
                        closed = pplWithQuestions.filter(function (p) {return p.StatusInCurrentReview === PerformanceEnums.ParticipantStatus.Closed; });

                    if (pplWithQuestions.length === submitted.length) {
                        if (review.NeedsSignOff) {
                            review.StatusByAdminView = PerformanceEnums.ReviewStatus.WaitingForSignOff;
                        } else {
                            review.StatusByAdminView = PerformanceEnums.ReviewStatus.Submitted;
                        }
                    } else if (pplWithQuestions.length === closed.length) {
                        review.StatusByAdminView = PerformanceEnums.ReviewStatus.Closed;
                    } else {
                        review.StatusByAdminView = PerformanceEnums.ReviewStatus.InProgress;
                    }

                    review.save(function (error) {
                        if (error) {
                            return asyncCallback(error);
                        }
                        syncReviewCycleForOffboardedReviewer(review, asyncCallback);
                    });
                };
            Async.each(params.Reviews, removeOneOffboardedReviewer, function (error) {
                callback(error);
            });
        };
        this.UpdateReviewStatus = function (params, callback) {
            PerformanceReview.update({hgId: params.ReviewId}, {$set: {StatusByAdminView: params.NewStatus}}, callback);
        };
        this.SetMeetingDate = function (params, callback) {
            PerformanceReview.findOne({hgId: params.ReviewId}, function (error, review) {
                if (error || !review) {
                    return callback('Error loading review for SetMeetingDate');
                }
                review.MeetingDate = params.MeetingDate;
                review.save(function (error) {
                    callback(error, review);
                });
            });
        };
        this.SetReleaseDate = function (params, callback) {
            var releaseableState = [
                PerformanceEnums.ReviewStatus.Submitted,
                PerformanceEnums.ReviewStatus.Closed
            ];
            PerformanceReview.find({CycleId: params.CycleId, StatusByAdminView: {$in: releaseableState}}, function (err, reviews) {
                if (err) {
                    return callback(err);
                }
                PerformanceReview.update(
                    {CycleId: params.CycleId, StatusByAdminView: {$in: releaseableState}},
                    {$set: {MeetingDate: params.ReleaseDate}},
                    {multi: true},
                    function (err) {
                        if (err) {
                            return callback(err);
                        }
                        PerformanceCycle.update(
                            {hgId: params.CycleId},
                            {$set: {ReleaseDate: params.ReleaseDate}},
                            {multi: true},
                            function (err) {
                                callback(err, reviews);
                            }
                        );
                    }
                );
            });
        };

        this.LoadDeliveryTriggeredReviewsWithPeoples = function (params, callback) {
            var deliveries = [],
                peoplesToBeDeliveredForThisReview = [],
                review = params.Review,
                myTypeInReview = review.MyTypeInReview,
                i;

            //make sure all people of the same type have submitted review
            for (i = 0; i < review.Peoples.length; i += 1) {
                if (review.Peoples[i].PeopleType === myTypeInReview && review.Peoples[i].StatusInCurrentReview !== PerformanceEnums.ParticipantStatus.Submitted) {
                    //someone didn't, so delivery won't happen
                    return callback(null, deliveries);
                }
            }
            //now everyone of my type has submitted, check if delivery will be triggered by me
            for (i = 0; i < review.Peoples.length; i += 1) {
                if (review.Peoples[i].DlvTrgPplType === myTypeInReview && review.Peoples[i].StatusInCurrentReview === PerformanceEnums.ParticipantStatus.PendingDelivery) {
                    //this person's delivery depends on my submission
                    review.Peoples[i].StatusInCurrentReview = PerformanceEnums.ParticipantStatus.NotStarted;
                    if (review.Peoples[i].DueInDays) {
                        review.Peoples[i].DeliveryDate = new Date().getTime();
                        review.Peoples[i].DueDate = Date.now() + review.Peoples[i].DueInDays * 24 * 3600 * 1000;
                    }
                    peoplesToBeDeliveredForThisReview.push(review.Peoples[i]);
                }
            }
            if (peoplesToBeDeliveredForThisReview.length > 0) {
                deliveries.push({
                    Peoples: peoplesToBeDeliveredForThisReview,
                    Review: review
                });
            }
            callback(null, deliveries);
        };

        this.LoadDeliveryDueReviewsWithPeoples = function (params, callback) {
            var condition = {
                    Peoples: {
                        $elemMatch: {
                            StatusInCurrentReview: PerformanceEnums.ParticipantStatus.PendingDelivery,
                            DeliveryDate: {$lte: Date.now()}
                        }
                    },
                    StatusByAdminView: {
                        $in: [
                            PerformanceEnums.ReviewStatus.PendingDelivery,
                            PerformanceEnums.ReviewStatus.NotStarted,
                            PerformanceEnums.ReviewStatus.InProgress,
                            PerformanceEnums.ReviewStatus.Overdue,
                            PerformanceEnums.ReviewStatus.Submitted
                        ]
                    },
                    'Card.GroupId': {$in: params.GroupIds}
                };
            if (params.CycleId) {
                condition.CycleId = params.CycleId;
            }
            PerformanceReview.find(condition, function (err, reviews) {
                var i,
                    iLen,
                    j,
                    jLen,
                    deliveries = [],
                    peoplesToBeDeliveredForThisReview,
                    trgPeople,
                    submittedPeople,
                    filterFunction = function (people) {
                        return people.PeopleType === reviews[i].Peoples[j].DlvTrgPplType;
                    },
                    submittedFilter = function (people) {
                        return people.StatusInCurrentReview === PerformanceEnums.ParticipantStatus.Submitted;
                    };
                if (err) {
                    return callback(err);
                }
                for (i = 0, iLen = reviews.length; i < iLen; i += 1) {
                    peoplesToBeDeliveredForThisReview = [];
                    for (j = 0, jLen = reviews[i].Peoples.length; j < jLen; j += 1) {
                        if (reviews[i].Peoples[j].StatusInCurrentReview === PerformanceEnums.ParticipantStatus.PendingDelivery &&
                                reviews[i].Peoples[j].DeliveryDate <= Date.now() && !reviews[i].Peoples[j].DlvTrgPplType) {
                            reviews[i].Peoples[j].StatusInCurrentReview = PerformanceEnums.ParticipantStatus.NotStarted;
                            peoplesToBeDeliveredForThisReview.push(reviews[i].Peoples[j]);
                        } else if (reviews[i].Peoples[j].StatusInCurrentReview === PerformanceEnums.ParticipantStatus.PendingDelivery &&
                                reviews[i].Peoples[j].DeliveryDate <= Date.now() && reviews[i].Peoples[j].DlvTrgPplType) {
                            trgPeople = reviews[i].Peoples.filter(filterFunction);
                            if (trgPeople && trgPeople.length) {
                                submittedPeople = trgPeople.filter(submittedFilter);
                                if (submittedPeople && submittedPeople.length && submittedPeople.length === trgPeople.length) {//all trigger people have submitted
                                    reviews[i].Peoples[j].StatusInCurrentReview = PerformanceEnums.ParticipantStatus.NotStarted;
                                    peoplesToBeDeliveredForThisReview.push(reviews[i].Peoples[j]);
                                }
                            }
                        }
                    }
                    if (peoplesToBeDeliveredForThisReview.length > 0) {//there is one or more people to be delivered in this review
                        deliveries.push({
                            Peoples: peoplesToBeDeliveredForThisReview,
                            Review: reviews[i]
                        });
                    }
                }
                callback(null, deliveries);
            });
        };

        this.ImportQuestions = function (params) {
            var requests = params.QuestionRequests;
            Async.each(requests, importOneQuestion, function (err) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, params.QuestionRequests);
                }
            });
        };

        this.ImportAnswers = function (params) {
            var requests = params.AnswerRequests;
            Async.each(requests, importOneAnswer, function (err) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, params.AnswerRequests);
                }
            });
        };

        this.ImportCards = function (params, callback) {
            function saveCard(card, fcallback) {
                var pcard = new EntityCache.PerformanceCard(card);
                pcard.save(fcallback);
            }
            Async.each(params.Cards, saveCard, function (error) {
                if (error) {
                    return callback(error);
                }
                return callback(null, 'Cards Imported');
            });
        };

        this.UpdateCyclePercentCompletion = function (params, callback) {
            PerformanceReview.find({
                CycleId: params.CycleId,
                StatusByAdminView: {$in: [
                    PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Submitted,
                    PerformanceEnums.ReviewStatus.WaitingForSignOff,
                    PerformanceEnums.ReviewStatus.Overdue,
                    PerformanceEnums.ReviewStatus.Closed
                ]}
            }, function (err, reviews) {
                var len = reviews.length,
                    completedReviewNumber,
                    preInProgressReviewsNumber;
                if (err) {
                    return callback(err);
                }
                completedReviewNumber = reviews.filter(function (review) {
                    if ([PerformanceEnums.ReviewStatus.Submitted, PerformanceEnums.ReviewStatus.Closed].indexOf(review.StatusByAdminView) > -1) {
                        if (review.MeetingDate && review.MeetingDate < Date.now()) {
                            return true;
                        }
                        var requireSignoffPeopleNumber = review.Peoples.filter(function (people) {
                                return people.SignsOff === true;
                            }).length,
                            actualSignoffPeoplesNumber = review.Peoples.filter(function (people) {
                                return people.SignsOff === true && people.StatusInCurrentReview === PerformanceEnums.ParticipantStatus.SignedOff;
                            }).length;
                        if (!requireSignoffPeopleNumber) {
                            return false;
                        }
                        if (!actualSignoffPeoplesNumber || actualSignoffPeoplesNumber < requireSignoffPeopleNumber) {
                            return false;
                        }
                        return true;
                    }
                }).length;
                preInProgressReviewsNumber  = reviews.filter(function (review) {
                    return [PerformanceEnums.ReviewStatus.PendingDelivery, PerformanceEnums.ReviewStatus.NotStarted].indexOf(review.StatusByAdminView) > -1;
                }).length;
                PerformanceCycle.findOne({hgId: params.CycleId}, function (err, cycle) {
                    if (err) {
                        return callback(err);
                    }
                    cycle.PercentCompletion = len ? Math.round(completedReviewNumber * 100 / len) : 0;
                    cycle.PercentPreInProgess = len ? Math.round(preInProgressReviewsNumber * 100 / len) : 0;
                    cycle.save();
                    return callback(null, cycle);
                });
            });
        };

        this.GetCycleReviewNumberById = function (params, callback) {
            PerformanceCycle.findOne({hgId: params.CycleId}, function (err, cycle) {
                if (err || !cycle) {
                    return callback(HgError.Enums.Perform.ErrorLoadingCycle);
                }
                PerformanceReview.count({
                    CycleId: params.CycleId,
                    StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}
                }, callback);
            });
        };

        this.GetCycleReviewsById = function (params, callback) {
            PerformanceCycle.findOne({hgId: params.CycleId}, function (err, cycle) {
                var cycleDetail;
                if (err || !cycle) {
                    return callback(HgError.Enums.Perform.ErrorLoadingCycle);
                }
                cycleDetail = EntityCache.CycleDetail(cycle);
                getReviewsForCycle({
                    CycleId: cycle.hgId,
                    Skip: parseInt(params.Skip, 10) || 0,
                    Take: parseInt(params.Take, 10) || 0
                }, function (error, reviews) {
                    if (error) {
                        return callback(err);
                    }
                    cycleDetail.Reviews = reviews;
                    callback(null, cycleDetail);
                });
            });
        };
        this.ConvertReviewSummary = function (params) {
            EventResponder.RespondWithData(EventEmitterCache, params, convertReviewSummary(params.Review));
        };
        this.LoadCycleByIdNoGroupId = function (params, callback) {
            var errKey = 'server.hge.per.elc';
            if (params.lang) {
                errKey = i18nHelper.translate(params.lang, errKey);
            }
            PerformanceCycle.findOne({hgId: params.CycleId}, function (err, cycle) {
                if (err || !cycle) {
                    return callback(errKey);
                }
                callback(null, cycle);
            });
        };
        this.LoadCycleById = function (params, callback) {
            var errKey = 'server.hge.per.elc';
            if (params.lang) {
                errKey = i18nHelper.translate(params.lang, errKey);
            }
            PerformanceCycle.findOne({GroupId: params.GroupId, hgId: params.CycleId}, function (err, cycle) {
                if (err || !cycle) {
                    return callback(errKey);
                }
                callback(null, cycle);
            });
        };
        this.LoadArchivedReviewsForCycle = function (cycle, callback) {
            PerformanceReview.find({
                CycleId: cycle.hgId,
                StatusByAdminView: PerformanceEnums.ReviewStatus.Archived
            }, function (err, reviews) {
                if (err) {
                    return callback(err);
                }
                callback(null, reviews);
            });
        };

        this.GetDistinctDepartmentsByCycle = function (params, callback) {
            PerformanceReview.aggregate([
                {$match: {
                    CycleId: params.CycleId,
                    StatusByAdminView: {$in: activeStatus}
                }},
                {$unwind: "$Peoples"},
                {$match: {"Peoples.PeopleType": PerformanceEnums.DefaultPeopleTypes.Subject}},
                {$group: {_id: {dept: "$Peoples.Department", cardId: "$Card.hgId"}}},
                {$sort: {_id: 1}}
            ], function (err, departments) {
                var filterDepts = function () {
                    return departments.filter(function (dept) {
                        return dept._id.cardId === params.CardId;
                    }).map(function (dept) {
                        return dept._id.dept;
                    });
                };
                if (err || !departments) {
                    return callback(err);
                }
                PerformanceCycle.findOne({hgId: params.CycleId}, {_id: 0, Cards: 1}, function (err, cycle) {
                    var theCards,
                        selectedCard;
                    if (err) {
                        return callback(err);
                    }
                    if (!cycle) {
                        return callback(null, filterDepts());
                    }
                    theCards = cycle.Cards.filter(function (c) {
                        return !c.AllReviewsArchived;
                    });
                    if (params.CardId) {
                        selectedCard = theCards.filter(function (c) {
                            return c.hgId === params.CardId;
                        })[0];
                        if (!selectedCard) {
                            selectedCard = theCards[0];
                        }
                    } else {
                        selectedCard = theCards[0];
                    }
                    if (selectedCard) {
                        params.CardId = selectedCard.hgId;
                    }
                    callback(null, filterDepts());
                });
            });
        };

        this.GetCycleDetailById = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                hgId: params.CycleId
            };
            if (!params.GetAllCycles) {
                condition.CreatedBy = params.UserId;
            }
            PerformanceCycle.findOne(condition, function (err, cycle) {
                var cycleDetail,
                    maxReviewsThreshold = 301,
                    theCard;
                if (err || !cycle || !cycle.hgId) {
                    return callback(HgError.Enums.Perform.ErrorLoadingCycle);
                }
                cycleDetail = new EntityCache.CycleDetail(cycle);
                // determine if there are any active reviews in this card
                theCard = cycle.Cards.filter(function (card) {
                    return params.CardId === card.hgId && !card.AllReviewsArchived;
                })[0];
                if (!theCard) {
                    theCard = cycle.Cards.filter(function (c) {
                        return !c.AllReviewsArchived;
                    })[0];
                    if (!theCard) {
                        return callback(null, []);
                    }
                }
                // get the number of reviews in this cycle, if less than 301 reviews, then blank out the DeptName parameter
                if (theCard.Assignments.length < maxReviewsThreshold) {
                    params.DeptName = "";
                    cycleDetail.NoDepartments = true;
                }
                params.CardId = params.CardId || theCard.hgId;
                getReviewsForCycle({
                    CycleId: cycle.hgId,
                    DeptName: params.DeptName,
                    CardId: params.CardId
                }, function (error, reviews) {
                    var tallyMap = {
                            NotStarted: 'NotStartedReviewNumber',
                            PendingDelivery: 'NotStartedReviewNumber',
                            InProgress: 'InProgressReviewNumber',
                            Submitted: 'SubmittedReviewNumber',
                            Closed: 'SubmittedReviewNumber',
                            WaitingForSignOff: 'SubmittedReviewNumber'
                        };
                    if (error) {
                        return callback(error);
                    }
                    if (reviews.length) {
                        cycleDetail.ReviewSummaries = reviews.map(function (r) {
                            cycleDetail[tallyMap[r.StatusByAdminView]] += 1;
                            return convertReviewSummary(r);
                        });
                        cycleDetail.TotalReviewNumber = reviews.length;
                        cycleDetail.TotalCards = cycle.Cards.filter(function (card) {
                            return !card.AllReviewsArchived;
                        }).map(function (card) {
                            return {
                                CardId: card.hgId,
                                Title: card.Title
                            };
                        });
                        callback(null, cycleDetail);
                    } else {
                        theCard.AllReviewsArchived = true;
                        cycle.save(function (err) {
                            if (err) {
                                return callback(err);
                            }
                            params.CardId = null;
                            self.GetCycleDetailById(params, callback);
                        });
                    }
                });
            });
        };

        this.GetUserCycles = function (params, callback) {
            var cycleIds = [], createdBy = [], mquery = PerformanceCycle.find({GroupId: params.GroupId}, {hgId: 1});
            if (!params.GetAllCycles) {
                mquery.where('CreatedBy', params.UserId);
            } else {
                if (params.CreatedBy && params.CreatedBy.length > 0) {
                    createdBy = params.CreatedBy.split(',');
                    mquery.where('CreatedBy').in(createdBy);
                }
            }
            mquery.exec(function (error, cycles) {
                if (error) { return callback(error); }
                cycles.forEach(function (cycle) { cycleIds.push(cycle.hgId); });
                callback(null, cycleIds);
            });
        };

        this.GetCycleSummariesByGroupId = function (params, callback) {
            var summaries = [],
                mAggregateQuery,
                mAggregateFilterQuery = {},
                returnedCycleIndex = {},
                cardType = 'Card.Type',
                skip = parseInt(params.Skip, 10) || 0,
                take = parseInt(params.Take, 10) || 10;
            getCycleQuery(params, function (error, cycleData) {
                if (error) { return callback(error); }
                returnedCycleIndex = cycleData.ReturnedCycleIndex;
                mAggregateFilterQuery = {
                    CycleId: {$in: cycleData.CycleIds},
                    StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}
                };
                if (params.CardType) {
                    mAggregateFilterQuery[cardType] = params.CardType;
                }
                mAggregateQuery = PerformanceReview.aggregate([
                    {$match: mAggregateFilterQuery},
                    {$group: { _id: { CycleId: '$CycleId' }, Total: { $sum: 1 } }},
                    {$match: { Total: { $gt: 0 } } }]);
                mAggregateQuery.skip(skip).limit(take).exec(function (error, data) {
                    if (error) { return callback(error); }
                    if (!data || !data.length) { return callback(null, summaries); }
                    data.forEach(function (item) {
                        summaries.push({
                            hgId: item._id.CycleId,
                            Title: returnedCycleIndex[item._id.CycleId].Title,
                            GroupId: returnedCycleIndex[item._id.CycleId].GroupId,
                            GroupName: returnedCycleIndex[item._id.CycleId].GroupName,
                            ReviewPeriodStart: returnedCycleIndex[item._id.CycleId].ReviewPeriodStart,
                            ReviewPeriodEnd: returnedCycleIndex[item._id.CycleId].ReviewPeriodEnd,
                            PercentCompletion: returnedCycleIndex[item._id.CycleId].PercentCompletion,
                            TotalReviewNumber: item.Total,
                            Cards: returnedCycleIndex[item._id.CycleId].Cards ? returnedCycleIndex[item._id.CycleId].Cards.map(function (card) { return card.Title; }) : []
                        });
                    });
                    callback(null, summaries);
                });
            });
        };
        this.GetRawReviewsByCycleId = function (params, callback) {
            PerformanceReview.find({CycleId: params.CycleId}, function (error, reviews) {
                if (error || !reviews) {
                    return callback(HgError.Enums.Perform.ErrorLoadingReview);
                }
                callback(null, reviews);
            });
        };

        //note the following method should be used only for ESB, where group Id is unavailable
        this.GetRawReviewByIdNoGroupId = function (params, callback) {
            PerformanceReview.findOne({
                hgId: params.ReviewId,
                StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}
            }, function (err, review) {
                if (err || !review) {
                    return callback(HgError.Enums.Perform.ErrorLoadingReview);
                }
                callback(null, review);
            });
        };

        this.GetRawReviewById = function (params, callback) {
            PerformanceReview.findOne({
                hgId: params.ReviewId,
                'Card.GroupId': params.GroupId,
                StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}
            }, function (err, review) {
                if (err || !review) {
                    return callback(HgError.Enums.Perform.ErrorLoadingReview);
                }
                callback(null, review);
            });
        };

        this.GetReviewById = function (params) {
            PerformanceReview.findOne({
                hgId: params.ReviewId,
                'Card.GroupId': params.GroupId,
                StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}
            }, function (err, review) {
                var s,
                    sl,
                    q,
                    ql,
                    sections,
                    questions,
                    track,
                    tracks = [],
                    entityIds = [],
                    recoDisQuestion = {},
                    getRecognitions = function (review, recoDisQuestion, callback) {
                        var recognitionFilter = recoDisQuestion.RecognitionFilter,
                            queryObject,
                            categoryArray = [],
                            subjects = review.Peoples.filter(function (people) {
                                return people.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject;
                            });
                        if (!subjects || subjects.length !== 1) {
                            return callback("cannot find a reviewee");
                        }
                        PerformanceCycle.findOne({hgId: review.CycleId}, function (err, cycle) {
                            if (err || !cycle) {
                                return callback(err);
                            }
                            queryObject = {Status: 'Active', 'RecipientMember.hgId': subjects[0].MemberId,
                                'Template.Type': {$nin: ['Newsfeed', 'ProductItem', 'PollResult', 'GoalKeyResultUpdate']}, Message: { $ne: "This track has been completed."},
                                CreatedDate: {$gt: cycle.ReviewPeriodStart, $lt: (cycle.ReviewPeriodEnd + (24 * 60 * 60 * 1000))}};
                            if (recognitionFilter.indexOf('EverydayInternal') > -1 || recognitionFilter.indexOf('EverydayExternal') > -1) {
                                categoryArray.push('Everyday');
                                if (recognitionFilter.indexOf('EverydayInternal') === -1) {
                                    queryObject['PublicCreatorInfo.FullName'] = {$nin: ['', 'HighGround']};
                                }
                                if (recognitionFilter.indexOf('EverydayExternal') === -1) {
                                    queryObject['PublicCreatorInfo.FullName'] = '';
                                }
                            }
                            if (recognitionFilter.indexOf('Values') > -1) {
                                categoryArray.push('Values');
                            }
                            if (recognitionFilter.indexOf('Achievement') > -1) {
                                categoryArray.push('Achievement');
                            }
                            queryObject['Template.Category'] = {$in: categoryArray};
                            EntityCache.Recognition.find(queryObject, null,  { sort: { ModifiedDate: -1} }, function (err, recognitions) {
                                if (err) {
                                    return callback(err);
                                }
                                recognitions = recognitions.filter(function (recognition) {
                                    return recognition.Template.Title.toLowerCase().indexOf('birthday') === -1 && recognition.Template.Title.toLowerCase().indexOf('anniversary') === -1;
                                });
                                callback(null, recognitions);
                            });
                        });
                    },
                    getTracks = function (review, tracks, callback) {
                        EntityCache.CareerTrack.find({hgId: {$in: tracks}}, function (err, allTracks) {
                            if (err) {
                                return callback(err);
                            }
                            // get all comments and coaching notes for each track and attach them to the tracks
                            ql = allTracks.length;
                            Async.whilst(
                                function () {
                                    ql -= 1;
                                    return ql > -1;
                                },
                                function (callback) {
                                    // get all track entity ids
                                    entityIds.push(allTracks[ql].CareerTrackTemplate.Goal.hgId);
                                    for (s = 0, sl = allTracks[ql].CareerTrackTemplate.MileStones.length; s < sl; s += 1) {
                                        entityIds.push(allTracks[ql].CareerTrackTemplate.MileStones[s].hgId);
                                    }
                                    // get comments and coaching notes for track
                                    EntityCache.Comment.find({
                                        EntityId: {$in: entityIds},
                                        EntityType: {$in: [EntityEnums.CommentEntityType.Milestone, EntityEnums.CommentEntityType.Coaching]},
                                        Status: EntityEnums.CommentStatus.Active
                                    }).sort({CreatedDate: 1}).exec(function (err, allComments) {
                                        if (!err) {
                                            allTracks[ql].Comments = allComments;
                                        }
                                        callback();
                                    });
                                },
                                function (err) {
                                    if (err) {
                                        return callback(err);
                                    }
                                    callback(null, allTracks);
                                }
                            );
                        });
                    };
                if (err || !review) {
                    EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Perform.ErrorLoadingReview);
                } else if (review.Card.GroupId !== params.GroupId) {
                    EventResponder.RespondWithError(EventEmitterCache, params, params.lang ?  i18nHelper.translate(params.lang, 'perf.grbi.nsg') : 'perf.grbi.nsg');
                } else {
                    if (!params.ForRendering) {
                        shapeReviewData(params.MemberId, review, params.RolesInGroup, params.ForManage);
                    } else if (params.EmployeeView === 'true') {
                        shapeReviewDataForRenderingEmployeeView({
                            CurMemberId: params.MemberId,
                            Review: review,
                            RolesInGroup: params.RolesInGroup,
                            CurUserId: params.UserId,
                            Lang: params.lang
                        });
                    } else {
                        shapeReviewDataForRendering({
                            MemberId: params.MemberId,
                            Review: review,
                            RolesInGroup: params.RolesInGroup,
                            UserId: params.UserId,
                            SubordinateMemberIds: params.SubordinateMemberIds,
                            SeeAllCycles: params.SeeAllCycles,
                            Lang: params.lang
                        });
                    }
                    if (review.MyTypeInReview || params.ForManage === true) {
                        // determine if any tracks are included and return them
                        // and if any recognitions are included
                        sections = review.Card.Sections;
                        for (s = 0, sl = sections.length; s < sl; s += 1) {
                            questions = sections[s].Questions;
                            for (q = 0, ql = questions.length; q < ql; q += 1) {
                                track = questions[q].TrackId;
                                if (track) {
                                    tracks.push(track);
                                }
                                if (questions[q].AnswerType === 'RecognitionDiscussion') {
                                    recoDisQuestion = questions[q];
                                }
                            }
                        }
                        if (recoDisQuestion.RecognitionFilter && tracks.length) {
                            getRecognitions(review, recoDisQuestion, function (err, data) {
                                if (err) {
                                    EventResponder.RespondWithError(EventEmitterCache, params,  HgError.Enums.Perform.ErrorLoadingReview);
                                } else {
                                    review.AllRecognitions = data;
                                    getTracks(review, tracks, function (err, data) {
                                        if (err) {
                                            EventResponder.RespondWithError(EventEmitterCache, params,  HgError.Enums.Perform.ErrorLoadingReview);
                                        } else {
                                            review.AllTracks = data;
                                            EventResponder.RespondWithData(EventEmitterCache, params, review);
                                        }
                                    });
                                }
                            });
                        } else if (recoDisQuestion.RecognitionFilter) {
                            getRecognitions(review, recoDisQuestion, function (err, data) {
                                if (err) {
                                    EventResponder.RespondWithError(EventEmitterCache, params,  HgError.Enums.Perform.ErrorLoadingReview);
                                } else {
                                    review.AllRecognitions = data;
                                    EventResponder.RespondWithData(EventEmitterCache, params, review);
                                }
                            });
                        } else if (tracks.length) {
                            getTracks(review, tracks, function (err, data) {
                                if (err) {
                                    EventResponder.RespondWithError(EventEmitterCache, params,  HgError.Enums.Perform.ErrorLoadingReview);
                                } else {
                                    review.AllTracks = data;
                                    EventResponder.RespondWithData(EventEmitterCache, params, review);
                                }
                            });
                        } else {
                            EventResponder.RespondWithData(EventEmitterCache, params, review);
                        }
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.per.pdr');
                    }
                }
            });
        };

        this.CheckOnceManager = function (params, callback) {
            var condition = {
                    Peoples: {$elemMatch: {MemberId: params.SubjectId, PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject}},
                    StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}
                },
                i,
                j,
                reviewFound = false;
            EntityCache.PerformanceReview.find(condition, function (error, reviews) {
                if (error || !reviews || reviews.length < 1) {
                    return callback(null, false);
                }
                for (i = 0; i < reviews.length; i += 1) {
                    for (j = 0; j < reviews[i].Peoples.length; j += 1) {
                        if (reviews[i].Peoples[j].PeopleType === PerformanceEnums.DefaultPeopleTypes.Manager && reviews[i].Peoples[j].MemberId === params.ManagerId) {
                            reviewFound = true;
                            break;
                        }
                    }
                    if (reviewFound) {
                        break;
                    }
                }
                callback(null, {OnceManager: reviewFound});
            });
        };

        this.GetOutstandingReviewsByMemberId = function (params, callback) {
            var today = new Date(),
                curentDate = DailyHourRangeType.ConvertToPlainDay(new Date(today.setDate(today.getDate() + 1)).getTime()),
                condition = {
                    Peoples: {$elemMatch: {
                        MemberId: params.MemberId,
                        StatusInCurrentReview: {$in: [
                            PerformanceEnums.ParticipantStatus.PendingDelivery,
                            PerformanceEnums.ParticipantStatus.NotStarted,
                            PerformanceEnums.ParticipantStatus.InProgress,
                            PerformanceEnums.ParticipantStatus.ReadyToSubmit,
                            PerformanceEnums.ParticipantStatus.Overdue,
                            PerformanceEnums.ParticipantStatus.Submitted,
                            PerformanceEnums.ParticipantStatus.SignedOff]},
                        PeopleType: {$ne: PerformanceEnums.DefaultPeopleTypes.Manager}
                    }},
                    StatusByAdminView: {$in: [
                        PerformanceEnums.ReviewStatus.PendingDelivery,
                        PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress,
                        PerformanceEnums.ReviewStatus.Submitted,
                        PerformanceEnums.ReviewStatus.WaitingForSignOff,
                        PerformanceEnums.ReviewStatus.Overdue]},
                    $or: [{MeetingDate: {$not: {$lt: curentDate}}}, {StatusByAdminView: {$in: [
                        PerformanceEnums.ReviewStatus.PendingDelivery,
                        PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress,
                        PerformanceEnums.ReviewStatus.Overdue]}}]
                };
            EntityCache.PerformanceReview.find(condition, callback);
        };

        this.GetReviewsForMember = function (params, callback) {
            var mquery, countQuery, condition, cycleQuery, cycleIds = [],
                today = new Date(),
                curentDate = DailyHourRangeType.ConvertToPlainDay(new Date(today.setDate(today.getDate() + 1)).getTime()),
                filterReviewsForOnceManagerMode = function (reviews, managerId) {
                    var filteredReviews = [], i, j,
                        rLen,
                        pLen;
                    for (rLen = reviews.length, i = 0; i < rLen; i += 1) {
                        for (pLen = reviews[i].Peoples.length, j = 0; j < pLen; j += 1) {
                            if (reviews[i].Peoples[j].PeopleType === PerformanceEnums.DefaultPeopleTypes.Manager && reviews[i].Peoples[j].MemberId === managerId) {
                                filteredReviews.push(reviews[i]);
                                break;
                            }
                        }
                    }
                    return filteredReviews;
                };
            if (params.Pending) {//all that member's reviews if it has not been archieved or closed or released
                if (params.UserMemberId === params.MemberId) {
                    condition = {
                        Peoples: {$elemMatch: {
                            MemberId: params.MemberId,
                            StatusInCurrentReview: {$in: [
                                PerformanceEnums.ParticipantStatus.NotStarted,
                                PerformanceEnums.ParticipantStatus.InProgress,
                                PerformanceEnums.ParticipantStatus.ReadyToSubmit,
                                PerformanceEnums.ParticipantStatus.Overdue,
                                PerformanceEnums.ParticipantStatus.Submitted,
                                PerformanceEnums.ParticipantStatus.SignedOff]}
                        }},
                        $and: [{StatusByAdminView: {$nin: [PerformanceEnums.ReviewStatus.Archived, PerformanceEnums.ReviewStatus.Closed]}},
                                {$or: [{MeetingDate: {$not: {$lt: curentDate}}}, {StatusByAdminView: {$in: [
                                PerformanceEnums.ReviewStatus.NotStarted,
                                PerformanceEnums.ReviewStatus.InProgress,
                                PerformanceEnums.ReviewStatus.Overdue]}}]}
                            ]
                    };//attention: don't expose the $or directly under condition, otherwise it will conflict with the "orCond" in search term below
                } else {
                    condition = {
                        Peoples: {$elemMatch: {
                            MemberId: params.MemberId,
                            Anonymous: false,
                            StatusInCurrentReview: {$in: [
                                PerformanceEnums.ParticipantStatus.NotStarted,
                                PerformanceEnums.ParticipantStatus.InProgress,
                                PerformanceEnums.ParticipantStatus.ReadyToSubmit,
                                PerformanceEnums.ParticipantStatus.Overdue,
                                PerformanceEnums.ParticipantStatus.Submitted,
                                PerformanceEnums.ParticipantStatus.SignedOff]}
                        }},
                        $and: [{StatusByAdminView: {$nin: [PerformanceEnums.ReviewStatus.Archived, PerformanceEnums.ReviewStatus.Closed]}},
                                {$or: [{MeetingDate: {$not: {$lt: curentDate}}}, {StatusByAdminView: {$in: [
                                PerformanceEnums.ReviewStatus.NotStarted,
                                PerformanceEnums.ReviewStatus.InProgress,
                                PerformanceEnums.ReviewStatus.Overdue]}}]}
                            ]
                    };//attention: don't expose the $or directly under condition, otherwise it will conflict with the "orCond" in search term below
                }
            } else {
                condition =  {
                    Peoples: {$elemMatch: {MemberId: params.MemberId, PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject}},
                    StatusByAdminView: {$in: [PerformanceEnums.ReviewStatus.Submitted, PerformanceEnums.ReviewStatus.Closed]},
                    $and: [
                        {$or: [
                            {MeetingDate: {$lt: curentDate}},
                            {MeetingDate: null}
                        ]}
                    ]
                };//attention: don't expose the $or directly under condition, otherwise it will conflict with the "orCond" in search term below
            }
            if (params.Title) {
                params.Title = paramUtil.EscapeBadChars(params.Title);
            }
            mquery = PerformanceReview.find(condition);
            countQuery = PerformanceReview.find(condition);
            cycleQuery = mquery;
            cycleQuery.exec(function (error, cycleReviews) {
                if (error) {
                    return callback(error);
                }
                cycleReviews.forEach(function (cycle) { cycleIds.push(cycle.CycleId); });
                if (params.Title) {
                    var searchRegex = new RegExp(["^.*", params.Title, ".*$"].join(""), "i"),
                        orCond = [
                            {'Card.Title': searchRegex},
                            {CycleName: searchRegex}
                        ];
                    if (params.SeeAllCycles) {
                        orCond.push({Peoples: { $elemMatch: {PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject, MemberFullname: searchRegex}}});
                    } else {
                        orCond.push({$and: [
                            {Peoples: { $elemMatch: {PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject, MemberFullname: searchRegex}}},
                            {Peoples: { $elemMatch: {PeopleType: PerformanceEnums.DefaultPeopleTypes.Manager, UserId: params.UserId}}}
                        ]});
                    }
                    mquery.or(orCond);
                    countQuery.or(orCond);
                }
                if (params.TagCycleIds && params.TagCycleIds.length > 0) {
                    mquery.where('CycleId', { $in: params.TagCycleIds});
                    countQuery.where('CycleId', { $in: params.TagCycleIds});
                }
                //sorting still in progress
                mquery.exec(function (error, reviews) {
                    if (error) {
                        return callback(error);
                    }
                    // Get the total number of found reviews so we can display it to the user
                    countQuery.count(function (error, total) {
                        if (error) {
                            return callback(error);
                        }
                        if (params.OnceManagerMode) {
                            reviews = filterReviewsForOnceManagerMode(reviews, params.UserMemberId);
                        }
                        reviews.forEach(function (review) {
                            shapeReviewData(params.UserMemberId,
                                review,
                                params.RolesInGroup,
                                false,
                                params.SubordinateMemberIds,
                                params.ViewedMemberIsSubordinate);
                        });
                        reviews.sort(function (a, b) {
                            if (a.MyPercentAchieved < b.MyPercentAchieved) {
                                return -1;
                            }
                            if (a.MyPercentAchieved > b.MyPercentAchieved) {
                                return 1;
                            }
                            if (a.SubmitDate < b.SubmitDate) {
                                return -1;
                            }
                            if (a.SubmitDate > b.SubmitDate) {
                                return 1;
                            }
                        });
                        if (!params.Pending) {
                            if (params.UserMemberId === params.MemberId) {
                                reviews = reviews.filter(function (review) {
                                    var questionNum = 0;
                                    if (review.Card && review.Card.Sections && review.Card.Sections.length > 0) {
                                        review.Card.Sections.forEach(function (section) {
                                            if (section.Questions) {
                                                questionNum += section.Questions.length;
                                            }
                                        });
                                    }
                                    return questionNum > 0;
                                });
                            }
                            reviews = reviews.filter(function (review) {//check if the review has been release or signed off
                                if (review.MeetingDate && review.MeetingDate < Date.now()) {
                                    return true;
                                }
                                var requireSignoffPeoples = review.Peoples.filter(function (people) {return people.SignsOff === true; }),
                                    actualSignoffPeoples = review.Peoples.filter(function (people) {return people.SignsOff === true && people.StatusInCurrentReview === PerformanceEnums.ParticipantStatus.SignedOff; });
                                if (!requireSignoffPeoples || requireSignoffPeoples.length < 1) {
                                    return false;
                                }
                                if (!actualSignoffPeoples || actualSignoffPeoples.length < 1 || actualSignoffPeoples.length < requireSignoffPeoples.length) {
                                    return false;
                                }
                                return true;
                            });
                        }
                        total = reviews.length;
                        var start = parseInt(params.Skip, 10) <= reviews.length - 1 ? parseInt(params.Skip, 10) : reviews.length - 1,
                            end = start + parseInt(params.Take, 10) <= reviews.length ? start + parseInt(params.Take, 10) : reviews.length,
                            range = reviews.slice(start, end);

                        callback(null, {Reviews: range, CycleIds: cycleIds, TotalMatchingReviews: total});
                    });
                });
            });
        };

        this.GetMyEmployeeReviews = function (params, callback) {
            var cycleIds = [],
                cquery,
                today = new Date(),
                meetingDate = DailyHourRangeType.ConvertToPlainDay(new Date(today.setDate(today.getDate() + 1)).getTime()),
                mquery =  PerformanceReview.find({
                    Peoples:
                        {$elemMatch:
                            {$or: [{MemberId: params.MemberId,
                                PeopleType: PerformanceEnums.DefaultPeopleTypes.Manager},
                                {MemberId: {$in: params.SubordinateMemberIds},
                                    PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject}]
                                }},
                    StatusByAdminView: {$in: [PerformanceEnums.ReviewStatus.Submitted, PerformanceEnums.ReviewStatus.Closed]},
                    MeetingDate: {$lt: meetingDate }
                });
            PerformanceReview.find({ ManagerCanSeePastReview: params.MemberId}, function (error, viewPastReviews) {
                cquery = mquery;
                cquery.exec(function (error, cycleReviews) {
                    cycleReviews.forEach(function (cycle) { cycleIds.push(cycle.CycleId); });
                    if (params.Title) {
                        mquery.or([{'Peoples.MemberFullname': new RegExp(["^.*", params.Title, ".*$"].join(""), "i")}, {'Card.Title': new RegExp(["^.*", params.Title, ".*$"].join(""), "i")}, {CycleName: new RegExp(["^.*", params.Title, ".*$"].join(""), "i")}]);
                    }
                    if (params.TagCycleIds && params.TagCycleIds.length > 0) {
                        mquery.where('CycleId', { $in: params.TagCycleIds});
                    }
                    mquery.skip(parseInt(params.Skip, 10) || 0);
                    mquery.limit(parseInt(params.Take, 10) || 0);
                    mquery.exec(function (error, reviews) {
                        var i, len;
                        if (error) {
                            return callback(error);
                        }
                        if (viewPastReviews && viewPastReviews.length > 0) {
                            viewPastReviews.forEach(function (reviewItem) { reviews.push(reviewItem); });
                        }
                        for (i = 0, len = reviews.length; i < len; i += 1) {
                            shapeReviewData(params.MemberId, reviews[i], params.RolesInGroup);
                        }
                        callback(null, {Reviews: reviews, CycleIds: cycleIds});
                    });
                });
            });
        };

        this.CreateGivenReview = function (params, callback) {
            var review = EntityCache.PerformanceReview(params.Review);
            review.hgId = guid.v1();
            review.CreatedDate = new Date().getTime();
            review.ModifiedDate = new Date().getTime();
            review.save(function (err) {
                return callback(err, review);
            });
        };

        this.CreateReviewForOneSubjectMemberOrTeam = function (params) {
            var callback = params.Callback,
                ManagerDueDate = params.ManagerDueDate,
                PeerDueDate = params.PeerDueDate,
                SubjectMemberId = params.SubjectMemberId,
                SubjectTeamId = params.SubjectTeamId,
                ManagerMemberId = params.ManagerMemberId,
                PeerMemberIds = params.PeerMemberIds,
                UserId = params.UserId,
                cycleId = params.CycleId,
                review,
                reviews = [];
            if (!PeerMemberIds) {
                PeerMemberIds = [];
            }
            Member.findOne({hgId: ManagerMemberId}, function (err, managerMember) {
                if (err || !managerMember) {
                    return callback(HgError.Enums.Perform.ErrorLoadingManager);
                }
                var manager = EntityCache.ReviewPeople({
                    MemberId: managerMember.hgId,
                    MemberFullname: managerMember.FullName,
                    PeopleType: PerformanceEnums.DefaultPeopleTypes.Manager,
                    DueDate: ManagerDueDate,
                    StatusInCurrentReview: PerformanceEnums.ReviewStatus.NotStarted
                });
                Member.find({hgId: {$in: PeerMemberIds}}, function (err, peerMembers) {
                    var peers = [],
                        i,
                        len,
                        subjectMemberIdExists = function () {
                            Member.findOne({hgId: SubjectMemberId}, function (err, subjectMember) {
                                if (err || !subjectMember) {
                                    callback(HgError.Enums.Perform.ErrorLoadingSubject);
                                } else {
                                    review = EntityCache.PerformanceReview({
                                        hgId: guid.v1(),
                                        CycleId: cycleId,
                                        Card: PerformanceCard,
                                        Subject: EntityCache.ReviewPeople({
                                            MemberId: subjectMember.hgId,
                                            MemberFullname: subjectMember.FullName,
                                            PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject,
                                            DueDate: PeerDueDate,
                                            StatusInCurrentReview: PerformanceEnums.ReviewStatus.NotStarted
                                        }),
                                        Manager: manager,
                                        Peers: peers,
                                        CreatedBy: UserId,
                                        ModifiedBy: UserId
                                    });
                                    review.save(function (err) {
                                        if (err) {
                                            return callback(err);
                                        }
                                        callback(null);
                                    });
                                }
                            });
                        },
                        subjectTeamIdExists = function () {
                            Team.findOne({hgId: SubjectTeamId}, function (err, team) {
                                if (err) {
                                    return callback(err);
                                }
                                for (i = 0, len = team.TeamMembers.length; i < len; i += 1) {
                                    review = EntityCache.PerformanceReview({
                                        hgId: guid.v1(),
                                        CycleId: cycleId,
                                        Card: PerformanceCard,
                                        Subject: {
                                            MemberId: team.TeamMembers[i].MemberId,
                                            MemberFullname: team.TeamMembers[i].MemberFullName,
                                            PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject,
                                            DueDate: PeerDueDate,
                                            StatusInCurrentReview: PerformanceEnums.ReviewStatus.NotStarted
                                        },
                                        Manager: manager,
                                        Peers: peers,
                                        CreatedBy: UserId,
                                        ModifiedBy: UserId
                                    });
                                    reviews.push(review);
                                }
                                for (i = 0, len = reviews.length; i < len; i += 1) {
                                    reviews[i].save();
                                }
                                callback();
                            });
                        };
                    if (err) {
                        return callback('error loading peerMembers!');
                    }
                    for (i = 0, len = peerMembers.length; i < len; i += 1) {
                        peers.push(EntityCache.ReviewPeople({
                            MemberId: peerMembers[i].hgId,
                            MemberFullname: peerMembers[i].FullName,
                            PeopleType: PerformanceEnums.DefaultPeopleTypes.Peer,
                            DueDate: PeerDueDate,
                            StatusInCurrentReview: PerformanceEnums.ReviewStatus.NotStarted
                        }));
                    }
                    if (SubjectMemberId) {
                        subjectMemberIdExists();
                    } else if (SubjectTeamId) {
                        subjectTeamIdExists();
                    }
                });
            });
        };
        this.AddReviewToCycle = function (params, callback) {
            var cycle = params.Cycle;
            cycle.markModified("Cards");
            cycle.markModified("Cards.Assignments");
            cycle.save(function (err) {
                callback(err, cycle);
            });
        };
        this.CreateCycle = function (params, callback) {
            var cycle = new EntityCache.PerformanceCycle(params.CycleRequest);
            cycle.hgId = guid.v1();
            cycle.PercentCompletion = 0;
            cycle.GroupId = params.GroupId;
            cycle.GroupName = params.GroupName;
            cycle.CreatedBy = params.UserId;
            cycle.ModifiedBy = params.UserId;
            cycle.CreatedDate = Date.now();
            cycle.Notes = params.Notes;
            cycle.save(function (err) {
                callback(err, cycle);
            });
        };

        this.GetCardsByIds = function (params, callback) {
            PerformanceCard.find({hgId: {$in:  params.CardIds}}, function (error, cards) {
                if (error) {
                    return callback(error);
                }
                callback(null, cards);
            });
        };
        this.GetCardById = function (params, callback) {
            PerformanceCard.findOne({hgId: params.CardId}, function (err, card) {
                if (err || !card) {
                    return callback('server.hge.per.erc');
                }
                callback(null, card);
            });
        };

        this.ArchiveCard = function (params, callback) {
            PerformanceCard.update(
                {hgId: params.CardId},
                {$set: {Status: PerformanceEnums.ReviewStatus.Archived}},
                function (err) {
                    if (callback) {
                        callback(err);
                    } else {
                        EventResponder.RespondGeneric(EventEmitterCache, params, err, HgMessage.Enums.Performance.CardArchived);
                    }
                }
            );
        };

        //close all reviews in cycle
        this.CloseAllReviewsInCycle = function (params, callback) {
            var deliveries = [],
                peoples = [],
                asyncSaveOneReview = function (review, asyncCallback) {
                    review.save(function (error) {
                        asyncCallback(error);
                    });
                };
            PerformanceReview.find({
                CycleId: params.CycleId,
                StatusByAdminView: {$nin: [PerformanceEnums.ReviewStatus.Archived,
                    PerformanceEnums.ReviewStatus.Closed,
                    PerformanceEnums.ReviewStatus.Submitted]}
            }, function (err, reviews) {
                if (err) {
                    return callback(HgError.Enums.Perform.ErrorLoadingReviews);
                }
                reviews.forEach(function (review) {
                    review.StatusByAdminView = PerformanceEnums.ReviewStatus.Closed;
                    review.ReviewClosedDate = new Date().getTime();
                    review.MyStatusInCurrentReview = PerformanceEnums.ReviewStatus.Closed;
                    review.Peoples.forEach(function (people) {
                        peoples.push({
                            MemberFullname: people.MemberFullname,
                            MemberId: people.MemberId,
                            DueDate: people.DueDate,
                            CycleId: review.CycleId,
                            ReviewId: review.hgId,
                            UserId: people.UserId,
                            PeopleType: people.PeopleType,
                            CycleName: review.CycleName,
                            StatusInCurrentReview: people.StatusInCurrentReview,
                            Review: review
                        });
                        if (people.StatusInCurrentReview !== PerformanceEnums.ParticipantStatus.NA && people.StatusInCurrentReview !== PerformanceEnums.ReviewStatus.Submitted) {
                            if (people.StatusInCurrentReview !== PerformanceEnums.ReviewStatus.PendingDelivery) {
                                deliveries.push({
                                    MemberFullname: people.MemberFullname,
                                    MemberId: people.MemberId,
                                    DueDate: people.DueDate,
                                    CycleId: review.CycleId,
                                    ReviewId: review.hgId,
                                    UserId: people.UserId,
                                    PeopleType: people.PeopleType,
                                    CycleName: review.CycleName,
                                    Review: review
                                });
                            }
                            people.StatusInCurrentReview = PerformanceEnums.ReviewStatus.Closed;
                        }
                    });
                    review.markModified('Peoples');
                });
                Async.each(reviews, asyncSaveOneReview, function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, {
                            deliveries: deliveries,
                            peoples: peoples
                        });
                    }
                });
            });
        };

        this.ArchiveAllReviewsInCycle = function (params, callback) {
            var deliveries = [],
                peoples = [];
            PerformanceReview.find({CycleId: params.CycleId, StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}}, function (err, reviews) {
                if (err) {
                    return callback(HgError.Enums.Perform.ErrorLoadingReviews);
                }
                reviews.forEach(function (review) {
                    review.StatusByAdminView = PerformanceEnums.ReviewStatus.Archived;
                    review.ReviewArchiveDate = Date.now();
                    review.Peoples.forEach(function (people) {
                        peoples.push({
                            MemberFullname: people.MemberFullname,
                            MemberId: people.MemberId,
                            DueDate: people.DueDate,
                            CycleId: review.CycleId,
                            ReviewId: review.hgId,
                            UserId: people.UserId,
                            PeopleType: people.PeopleType,
                            CycleName: review.CycleName,
                            StatusInCurrentReview: people.StatusInCurrentReview,
                            Review: review
                        });
                        if ([PerformanceEnums.ParticipantStatus.NA,
                                PerformanceEnums.ReviewStatus.Submitted,
                                PerformanceEnums.ReviewStatus.PendingDelivery,
                                PerformanceEnums.ReviewStatus.Closed].indexOf(people.StatusInCurrentReview) === -1) {
                            deliveries.push({
                                MemberFullname: people.MemberFullname,
                                MemberId: people.MemberId,
                                DueDate: people.DueDate,
                                CycleId: review.CycleId,
                                ReviewId: review.hgId,
                                UserId: people.UserId,
                                PeopleType: people.PeopleType,
                                CycleName: review.CycleName,
                                Review: review
                            });
                        }
                    });
                    review.save(function (err) {
                        if (err) {
                            HgLog.error({methodName: 'ArchiveAllReviewsInCycle', error: err});
                        }
                    });
                });
                // set the flag to mark all reviews as archived in each card
                PerformanceCycle.findOne({hgId: params.CycleId}, function (err, cycle) {
                    if (err) {
                        return callback(HgError.Enums.Perform.ErrorLoadingReviews);
                    }
                    cycle.Cards.forEach(function (card) {
                        card.AllReviewsArchived = true;
                    });
                    cycle.save(function (err) {
                        if (err) {
                            return callback(HgError.Enums.Perform.ErrorLoadingReviews);
                        }
                        callback(null, {
                            deliveries: deliveries,
                            peoples: peoples
                        });
                    });
                });
            });
        };

        this.GetPerformCards = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                $or: [
                    {RestrictUsers: {$size: 0}},
                    {'RestrictUsers.MemberId': {$in: [null, params.MemberId]}}
                ]
            };
            if (params.Type) {
                query.Type = params.Type;
            }
            if (params.Status) {
                query.Status = params.Status;
            }
            if (params.SearchTerm) {
                query.$or = [
                    {Title: {$regex: params.SearchTerm, $options: 'i'}},
                    {Description: {$regex: params.SearchTerm, $options: 'i'}}
                ];
            }
            EntityCache.PerformanceCard.find(query)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({Title: 1})
                .exec(callback);
        };
        this.GetCards = function (params, callback) {
            var hgQuery = EntityCache.PerformanceCard.find({});
            if (params.Status === 'All') {
                hgQuery.where({GroupId: params.GroupId});
            } else if (!params.Status) {
                hgQuery.where({GroupId: params.GroupId, Status: {$ne: PerformanceEnums.ReviewStatus.Archived}});
            } else {
                hgQuery.where({GroupId: params.GroupId, Status: params.Status});
            }
            hgQuery.exec(function (error, cards) {
                var checkRole = 'HGAdmin|Admin';
                if (error) {
                    return callback(error);
                }
                // filter cards if restricted users exists, except for HGAmin and Admin
                callback(null, cards.filter(function (card) {
                    if (card.RestrictUsers && card.RestrictUsers.length && checkRole.indexOf(params.RoleInGroup) === -1) {
                        if (card.RestrictUsers.some(function (ru) {
                                return ru.MemberId === params.MemberId;
                            })) {
                            return true;
                        }
                        return false;
                    }
                    return true;
                }));
            });
        };

        this.GetQuestionLibrary =  function (params) {
            QuestionTemplate.find({Archived: false}, function (err, questionTemplates) {
                EventResponder.RespondGeneric(EventEmitterCache, params, err, questionTemplates);
            });
        };
        this.GetAnswerLibrary =  function (params) {
            AnswerTemplate.find({Archived: false}, function (err, answerTemplates) {
                EventResponder.RespondGeneric(EventEmitterCache, params, err, answerTemplates);
            });
        };

        this.SaveGivenCard = function (params) {
            var card = params.Card;
            resolvePeopleTypesHaveQuestionsInCard(card);
            card.DetectableRolesOnly = isDetectableRolesOnly(card);
            card.save(function (err) {
                EventResponder.RespondGeneric(EventEmitterCache, params, err, card);
            });
        };

        this.SaveGivenReview = function (params, callback) {
            var review = params.Review;
            review.save(function (err) {
                if (callback) {
                    callback(err, review);
                } else {
                    EventResponder.RespondGeneric(EventEmitterCache, params, err, review);
                }
            });
        };

        this.UpdateCycleCardsArchiveFlag = function (params, callback) {
            var review = params.Review;
            PerformanceCycle.findOne({hgId: review.CycleId}, function (err, cycle) {
                var theCard;
                if (err) {
                    if (callback) {
                        return callback(err);
                    }
                } else {
                    PerformanceReview.find({CycleId: cycle.hgId, "Card.hgId": review.Card.hgId, StatusByAdminView: {$in: activeStatus}}, function (err, reviews) {
                        if (err) {
                            return EventResponder.RespondGeneric(EventEmitterCache, params, err, review);
                        }
                        if (!reviews.length) {
                            theCard = cycle.Cards.filter(function (card) {
                                return card.hgId === review.Card.hgId;
                            })[0];
                            if (theCard) {
                                theCard.AllReviewsArchived = true;
                                cycle.save(function (err) {
                                    if (callback) {
                                        if (err) {
                                            return callback(err);
                                        }
                                    } else {
                                        return EventResponder.RespondGeneric(EventEmitterCache, params, err, review);
                                    }
                                });
                            }
                        }
                        EventResponder.RespondGeneric(EventEmitterCache, params, err, review);
                    });
                }
            });
        };

        this.UpdatePeopleStatusChangesInReview = function (review) {
            review.markModified('Peoples');
            review.save();
        };

        this.GetDuplicateCount = function (params) {
            PerformanceCard.count({OriginalId: params.OriginalId}, function (err, count) {
                EventResponder.RespondGeneric(EventEmitterCache, params, err, count + 1);
            });
        };

        this.DuplicateGivenCard = function (params) {
            var card = params.Card,
                newCard;
            card.isNew = true;
            newCard = EntityCache.PerformanceCard(card);
            newCard.markModified('Sections');
            resolvePeopleTypesHaveQuestionsInCard(newCard);
            newCard.DetectableRolesOnly = isDetectableRolesOnly(newCard);
            newCard.save(function (err) {
                EventResponder.RespondGeneric(EventEmitterCache, params, err, card);
            });
        };

        this.GetPastOverDueReviewsPendingCompletion = function (params) {
            var dueDate = DailyHourRangeType.ConvertToPlainDay(new Date().getTime());
            PerformanceReview.find({
                'Peoples.StatusInCurrentReview': PerformanceEnums.ReviewStatus.Overdue,
                'Peoples.DueDate': {$lt: dueDate},
                StatusByAdminView: {$in: [
                    PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Submitted,
                    PerformanceEnums.ReviewStatus.Overdue]},
                'Card.GroupId': {$in: params.GroupIds}
            }).exec(function (err, reviews) {
                var OversDueReviews = [],
                    i,
                    lenReview,
                    lenReviewPeople,
                    j;
                if (reviews) {
                    lenReview = reviews.length;
                    for (i = 0; i < lenReview; i += 1) {
                        lenReviewPeople = reviews[i].Peoples.length;
                        for (j = 0; j < lenReviewPeople; j += 1) {
                            if (reviews[i].Peoples[j].DueDate && reviews[i].Peoples[j].DueDate < dueDate &&
                                    [PerformanceEnums.ReviewStatus.Submitted,
                                        PerformanceEnums.ParticipantStatus.NA,
                                        PerformanceEnums.ParticipantStatus.Closed,
                                        PerformanceEnums.ParticipantStatus.SignedOff,
                                        PerformanceEnums.ReviewStatus.PendingDelivery].indexOf(reviews[i].Peoples[j].StatusInCurrentReview) === -1) {
                                OversDueReviews.push({
                                    MemberFullname: reviews[i].Peoples[j].MemberFullname,
                                    MemberId: reviews[i].Peoples[j].MemberId,
                                    GroupId: reviews[i].Card.GroupId,
                                    UserId: reviews[i].Peoples[j].UserId,
                                    PeopleType: reviews[i].Peoples[j].PeopleType,
                                    DueDate: reviews[i].Peoples[j].DueDate,
                                    CycleId: reviews[i].CycleId,
                                    CycleName: reviews[i].CycleName,
                                    ReviewId: reviews[i].hgId,
                                    Review: reviews[i]
                                });
                            }
                        }
                    }
                }
                EventResponder.RespondGeneric(EventEmitterCache, params, err, OversDueReviews);
            });
        };

        this.GetTotalOverdueReviews = function (params, callback) {
            PerformanceReview.count({
                Peoples: {
                    $elemMatch: {
                        StatusInCurrentReview: {$in: [
                            PerformanceEnums.ParticipantStatus.NotStarted,
                            PerformanceEnums.ParticipantStatus.InProgress,
                            PerformanceEnums.ParticipantStatus.ReadyToSubmit
                        ]},
                        DueDate: {$lt: DailyHourRangeType.ConvertToPlainDay(Date.now())}
                    }
                },
                StatusByAdminView: {$in: [
                    PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Submitted,
                    PerformanceEnums.ReviewStatus.Overdue]}
            }, callback);
        };
        this.GetNextBatchOverDueReviews = function (params, callback) {
            PerformanceReview.find({
                Peoples: {
                    $elemMatch: {
                        StatusInCurrentReview: {$in: [
                            PerformanceEnums.ParticipantStatus.NotStarted,
                            PerformanceEnums.ParticipantStatus.InProgress,
                            PerformanceEnums.ParticipantStatus.ReadyToSubmit
                        ]},
                        DueDate: {$lt: DailyHourRangeType.ConvertToPlainDay(Date.now())}
                    }
                },
                StatusByAdminView: {$in: [
                    PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Submitted,
                    PerformanceEnums.ReviewStatus.Overdue]}
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.UpdateOverDueReviewStatusBatch = function (params, callback) {
            var updateOneOverDueReviewStatus = function (review, asyncCallback) {
                    review.Peoples.forEach(function (people) {
                        if (people.DueDate && people.DueDate < DailyHourRangeType.ConvertToPlainDay(Date.now()) &&
                                [PerformanceEnums.ParticipantStatus.Submitted,
                                    PerformanceEnums.ParticipantStatus.NA,
                                    PerformanceEnums.ParticipantStatus.PendingDelivery,
                                    PerformanceEnums.ParticipantStatus.Overdue,
                                    PerformanceEnums.ParticipantStatus.Closed,
                                    PerformanceEnums.ParticipantStatus.Submitted].indexOf(people.StatusInCurrentReview) === -1) {
                            people.StatusInCurrentReview = PerformanceEnums.ParticipantStatus.Overdue;
                            review.ModifiedDate = Date.now();
                        }
                    });
                    review.save(asyncCallback);
                };
            Async.each(params.Reviews, updateOneOverDueReviewStatus, function (error) {
                callback(error, HgMessage.Enums.Performance.OverdueReviewsUpdated);
            });
        };

        this.GetPreOverDueReviews = function (params) {
            var OversDueReviews = [],
                today = DailyHourRangeType.ConvertToPlainDay(new Date().getTime()),
                overDueDateRequirement = 2,
                aheadDate = today + overDueDateRequirement * 3600 * 24 * 1000,
                i,
                j,
                iLen,
                jLen;
            PerformanceReview.find({
                Peoples: {$elemMatch: {
                    StatusInCurrentReview: {$in: [
                        PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress]},
                    DueDate: {$lte: aheadDate}
                }},
                StatusByAdminView: {$in: [
                    PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Overdue]},
                'Card.GroupId': {$in: params.GroupIds}
            }, function (error, reviews) {
                if (reviews) {
                    for (i = 0, iLen = reviews.length; i < iLen; i += 1) {
                        for (j = 0, jLen = reviews[i].Peoples.length; j < jLen; j += 1) {
                            if (reviews[i].Peoples[j].DueDate && reviews[i].Peoples[j].DueDate < aheadDate &&
                                    [PerformanceEnums.ReviewStatus.Submitted,
                                        PerformanceEnums.ReviewStatus.Overdue,
                                        PerformanceEnums.ReviewStatus.PendingDelivery,
                                        PerformanceEnums.ParticipantStatus.NA].indexOf(reviews[i].Peoples[j].StatusInCurrentReview) === -1) {
                                OversDueReviews.push({
                                    MemberFullname: reviews[i].Peoples[j].MemberFullname,
                                    MemberId: reviews[i].Peoples[j].MemberId,
                                    GroupId: reviews[i].Card.GroupId,
                                    UserId: reviews[i].Peoples[j].UserId,
                                    DueDate: reviews[i].Peoples[j].DueDate,
                                    PeopleType: reviews[i].Peoples[j].PeopleType,
                                    CycleName: reviews[i].CycleName,
                                    CycleId: reviews[i].CycleId,
                                    ReviewId: reviews[i].hgId,
                                    Review: reviews[i]
                                });
                            }
                        }
                    }
                }
                EventResponder.RespondGeneric(EventEmitterCache, params, error, OversDueReviews);
            });
        };

        this.GetUnCompletedReviewsByCycleId = function (params) {
            PerformanceReview.find({
                CycleId: params.CycleId,
                GroupId: params.GroupId,
                StatusByAdminView: {$in:
                    [PerformanceEnums.ReviewStatus.PendingDelivery,
                        PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress,
                        PerformanceEnums.ReviewStatus.Submitted,
                        PerformanceEnums.ReviewStatus.Overdue]}
            }).exec(function (err, reviews) {
                var i,
                    iLen,
                    j,
                    jLen,
                    OversDueReviews = [];
                if (reviews) {
                    for (i = 0, iLen = reviews.length; i < iLen; i += 1) {
                        for (j = 0, jLen = reviews[i].Peoples.length; j < jLen; j += 1) {
                            if ([PerformanceEnums.ReviewStatus.Submitted,
                                    PerformanceEnums.ParticipantStatus.NA,
                                    PerformanceEnums.ReviewStatus.Closed,
                                    PerformanceEnums.ReviewStatus.PendingDelivery].indexOf(reviews[i].Peoples[j].StatusInCurrentReview) === -1) {
                                OversDueReviews.push({
                                    MemberFullname: reviews[i].Peoples[j].MemberFullname,
                                    MemberId: reviews[i].Peoples[j].MemberId,
                                    GroupId: reviews[i].Card.GroupId,
                                    DueDate: reviews[i].Peoples[j].DueDate,
                                    CycleId: reviews[i].CycleId,
                                    ReviewId: reviews[i].hgId,
                                    UserId: reviews[i].Peoples[j].UserId,
                                    PeopleType: reviews[i].Peoples[j].PeopleType,
                                    CycleName: reviews[i].CycleName,
                                    Review: reviews[i]
                                });
                            }
                        }
                    }
                }
                EventResponder.RespondGeneric(EventEmitterCache, params, err, OversDueReviews);
            });
        };

        this.GetUnCompletedReviewByMemberId = function (params, callback) {
            var memberId = params.MemberIdToNotify;
            PerformanceReview.findOne({
                hgId: params.ReviewId,
                'Peoples.MemberId': memberId,
                'Card.GroupId': params.GroupId,
                StatusByAdminView: {$in: [
                    PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Submitted,
                    PerformanceEnums.ReviewStatus.Overdue]}
            }).exec(function (err, review) {
                if (err || !review) {
                    return callback('err.per.ers');
                }
                var i,
                    len,
                    OverDueReviews = [];
                for (i = 0, len = review.Peoples.length; i < len; i += 1) {
                    if (review.Peoples[i].StatusInCurrentReview !== PerformanceEnums.ReviewStatus.Submitted && review.Peoples[i].MemberId === memberId) {
                        OverDueReviews.push({
                            MemberFullname: review.Peoples[i].MemberFullname,
                            MemberId: review.Peoples[i].MemberId,
                            GroupId: review.Card.GroupId,
                            DueDate: review.Peoples[i].DueDate,
                            CycleId: review.CycleId,
                            ReviewId: review.hgId,
                            UserId: review.Peoples[i].UserId,
                            PeopleType: review.Peoples[i].PeopleType,
                            CycleName: review.CycleName,
                            Review: review
                        });
                    }
                }
                callback(null, OverDueReviews);
            });
        };

        this.CreateOrUpdateCard = function (params) {
            var card = EntityCache.PerformanceCard(params.CardRequest),
                i,
                len;
            if (card.hgId && card.hgId.length > 0) {//update place holder
                PerformanceCard.findOne({hgId: card.hgId}, function (err, existingCard) {
                    if (err || !existingCard) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.per.cne');
                    } else {
                        if (existingCard.IsTemplate && !params.SaveTemplateAllowed) {
                            EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Perform.CantEditTemplate);
                        } else {
                            existingCard.Title = card.Title;
                            existingCard.PeopleTypes = card.PeopleTypes;
                            existingCard.Level = card.Level;
                            existingCard.Description = card.Description;
                            existingCard.IsTemplate = card.IsTemplate || false;
                            existingCard.Type = card.Type;
                            populateQuestionId(card);
                            existingCard.Sections = card.Sections;
                            existingCard.ModifiedBy = params.UserId;
                            existingCard.ModifiedDate = new Date().getTime();
                            resolvePeopleTypesHaveQuestionsInCard(existingCard);
                            existingCard.DetectableRolesOnly = isDetectableRolesOnly(existingCard);
                            existingCard.Status = card.Status;
                            existingCard.RestrictUsers = params.CardBuild.RestrictUsers;
                            existingCard.markModified('PeopleTypes');
                            existingCard.markModified('Sections');
                            existingCard.markModified('Sections.Questions');
                            existingCard.save(function (err) {
                                if (err) {
                                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                                } else {
                                    EventResponder.RespondWithData(EventEmitterCache, params, existingCard);
                                }
                            });
                        }
                    }
                });
            } else {
                card.hgId = guid.v1();
                card.GroupId = params.GroupId;
                card.GroupName = params.GroupName;
                card.CreatedBy = params.UserId;
                card.ModifiedBy = params.UserId;
                card.ExpireDate = params.ExpireDate || new Date().getTime() + 365 * 24 * 3600 * 1000;//default to 1 year
                populateQuestionId(card);
                for (i = 0, len = card.Sections.length; i < len; i += 1) {
                    card.Sections[i].CreatedBy = params.UserId;
                    card.Sections[i].ModifiedBy = params.UserId;
                }
                resolvePeopleTypesHaveQuestionsInCard(card);
                card.DetectableRolesOnly = isDetectableRolesOnly(card);
                card.RestrictUsers = params.CardBuild.RestrictUsers;
                card.save(function (err) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, err);
                    } else {
                        EventResponder.RespondWithData(EventEmitterCache, params, card);
                    }
                });
            }
        };

        this.GetPerformanceReviewsByGroupId = function (params, callback) {
            var  cycleIdFromPerformances = [];
            EntityCache.PerformanceCycle.find({GroupId: params.GroupId}, function (error, performanceCycles) {
                if (error) {
                    return callback(error);
                }
                performanceCycles.forEach(function (performanceCycle) {
                    cycleIdFromPerformances.push(performanceCycle.hgId);
                });
                EntityCache.PerformanceReview.find({CycleId: {$in: cycleIdFromPerformances}}, function (err, performanceReviews) {
                    if (!err) {
                        return callback(null, performanceReviews);
                    }
                    callback(err);
                });
            });
        };
        this.GetPerformanceCyclesByGroupId = function (params, callback) {
            EntityCache.PerformanceCycle.find({GroupId: params.GroupId}, function (err, performanceCycles) {
                if (!err) {
                    return callback(null, performanceCycles);
                }
                callback(err);
            });
        };
        this.GetPerformanceCardsByGroupId = function (params, callback) {
            EntityCache.PerformanceCard.find({GroupId: params.GroupId}, function (err, performanceCards) {
                if (!err) {
                    return callback(null, performanceCards);
                }
                callback(err);
            });
        };
        this.TransferManagerReview = function (params, callback) {
            var isPeopleItemAManager = function (peopleItem) {
                    return (peopleItem.PeopleType === PerformanceEnums.DefaultPeopleTypes.Manager &&
                        peopleItem.MemberId === params.OldManager.hgId &&
                        [PerformanceEnums.ReviewStatus.PendingDelivery,
                            PerformanceEnums.ParticipantStatus.NA,
                            PerformanceEnums.ReviewStatus.NotStarted,
                            PerformanceEnums.ReviewStatus.InProgress,
                            PerformanceEnums.ReviewStatus.Overdue].indexOf(peopleItem.StatusInCurrentReview) > -1);
                },
                isReviewNewManagerOnTheReview = function (review) {
                    var item = review.Peoples.filter(function (peopleItem) {
                            return (peopleItem.MemberId === params.NewManager.hgId &&
                                peopleItem.PeopleType !== PerformanceEnums.DefaultPeopleTypes.Manager);
                        });
                    return (item.length > 0);
                },
                isParticipantADirectReport = function (participants) {
                    var result = participants.filter(function (allParticipants) {
                        return params.DirectReports.filter(function (directReport) {
                            return directReport === allParticipants.EntityId;
                        }).length > 0;
                    });
                    return result.length > 0;
                },
                query = {
                    'Card.GroupId': params.GroupId,
                    StatusByAdminView: { $in: [PerformanceEnums.ReviewStatus.WaitingForSignOff,
                        PerformanceEnums.ReviewStatus.PendingDelivery,
                        PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress,
                        PerformanceEnums.ReviewStatus.Overdue]},
                    'Peoples.MemberId': params.OldManager.hgId
                },
                archivedReviewsQuery = {
                    'Card.GroupId': params.GroupId,
                    StatusByAdminView: { $in: [PerformanceEnums.ReviewStatus.Submitted,
                        PerformanceEnums.ReviewStatus.Archived,
                        PerformanceEnums.ReviewStatus.Closed]},
                    'Peoples.MemberId': params.OldManager.hgId
                };
            if (params.DirectReports.length > 0) {
                query.Peoples = { $elemMatch: {
                    MemberId: { $in: params.DirectReports},
                    PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject
                }};
                archivedReviewsQuery.Peoples = { $elemMatch: {
                    MemberId: { $in: params.DirectReports},
                    PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject
                }};
            }
            function syncReviewCycle(cylceIds, sCallback) {
                var cycleQuery = {
                    hgId: {$in: cylceIds},
                    Cards: {$elemMatch: {
                        'Assignments.Participants.PeopleType': PerformanceEnums.DefaultPeopleTypes.Manager,
                        'Assignments.Participants.EntityId': params.OldManager.hgId
                    }}
                };
                EntityCache.PerformanceCycle.find(cycleQuery, function (error, cycles) {
                    if (error) {
                        return sCallback(error);
                    }
                    Async.each(cycles, function (cycle, cycleCallback) {
                        HGActivityLog.Archive({
                            Collection: ArchiveRecordEnums.Collection.PerformanceCycle,
                            Content: cycle,
                            Note: ArchiveRecordEnums.Reason.ChangeDueToManagerTransfer,
                            CreatedBy: params.UserId
                        }, function (error) {
                            if (error) {
                                return cycleCallback(error);
                            }
                            cycle.Cards.forEach(function (card) {
                                card.Assignments.forEach(function (assignment) {
                                    if (isParticipantADirectReport(assignment.Participants)) {
                                        assignment.Participants.forEach(function (participant) {
                                            if (participant.EntityId === params.OldManager.hgId &&
                                                    participant.PeopleType === PerformanceEnums.DefaultPeopleTypes.Manager) {
                                                participant.EntityId = params.NewManager.hgId;
                                                participant.EntityName = params.NewManager.FullName;
                                                participant.AvatarId = params.NewManager.UserId;
                                                participant.Department = params.NewManager.Department;
                                            }
                                        });
                                    }
                                });
                            });
                            cycle.save(cycleCallback);
                        });
                    }, sCallback);
                });
            }
            Async.parallel({
                currentReviews: function (fcallback) {
                    var reviewIds = [], cycleIds = [];
                    EntityCache.PerformanceReview.find(query, function (error, reviews) {
                        if (error) {
                            return fcallback(error);
                        }
                        Async.each(reviews, function (reviewItem, rCallback) {
                            if (!(reviewItem.Peoples && !isReviewNewManagerOnTheReview(reviewItem))) {
                                return rCallback();
                            }
                            reviewItem.Peoples.forEach(function (peopleItem) {
                                if (isPeopleItemAManager(peopleItem)) {
                                    peopleItem.MemberId = params.NewManager.hgId;
                                    peopleItem.UserId = params.NewManager.UserId;
                                    peopleItem.MemberFullname = params.NewManager.FullName;
                                    peopleItem.EmployeeId = params.NewManager.EmployeeId;
                                    peopleItem.Position = params.NewManager.Position;
                                    reviewIds.push(reviewItem.hgId);
                                    cycleIds.push(reviewItem.CycleId);
                                }
                            });
                            reviewItem.save(rCallback);
                        }, function (error) {
                            if (error) {
                                return fcallback(error);
                            }
                            if (cycleIds.length === 0) {
                                return fcallback(null, reviewIds);
                            }
                            syncReviewCycle(cycleIds, function (error) {
                                if (error) {
                                    return fcallback(error);
                                }
                                fcallback(null, reviewIds);
                            });
                        });
                    });
                },
                pastReviews: function (fcallback) {
                    EntityCache.PerformanceReview.find(archivedReviewsQuery, function (error, reviews) {
                        if (error) {
                            return fcallback(error);
                        }
                        Async.each(reviews, function (reviewItem, rCallback) {
                            if (!reviewItem.Peoples) {
                                return rCallback();
                            }
                            reviewItem.Peoples.forEach(function (peopleItem) {
                                if (peopleItem.PeopleType === PerformanceEnums.DefaultPeopleTypes.Manager && peopleItem.MemberId === params.OldManager.hgId) {
                                    reviewItem.ManagerCanSeePastReview =  params.NewManager.hgId;
                                }
                            });
                            reviewItem.save(rCallback);
                        }, fcallback);
                    });
                }
            }, function (error, result) {
                callback(error, result.currentReviews);
            });
        };

        this.GetOutstandingMemberReviewsAsManager = function (params, callback) {
            var today = new Date(),
                curentDate = DailyHourRangeType.ConvertToPlainDay(new Date(today.setDate(today.getDate() + 1)).getTime()),
                condition = {
                    Peoples: {
                        $elemMatch: {
                            MemberId: { $in: params.MemberIds},
                            StatusInCurrentReview: {$in: [PerformanceEnums.ReviewStatus.NotStarted,
                                PerformanceEnums.ReviewStatus.InProgress,
                                PerformanceEnums.ParticipantStatus.ReadyToSubmit,
                                PerformanceEnums.ReviewStatus.Overdue]},
                            PeopleType: PerformanceEnums.DefaultPeopleTypes.Manager
                        }
                    },
                    StatusByAdminView: {$in: [PerformanceEnums.ReviewStatus.PendingDelivery,
                        PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress,
                        PerformanceEnums.ReviewStatus.WaitingForSignOff,
                        PerformanceEnums.ReviewStatus.Overdue]},
                    $or: [{MeetingDate: null}, {MeetingDate: {$lt: curentDate}}]
                };
            EntityCache.PerformanceReview.find(condition, callback);
        };

        this.GetGroupMembersAggregatedInProgressReviews = function (params, callback) {
            var filter = {
                    'Card.GroupId': params.EntityId,
                    StatusByAdminView: { $in: [PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress,
                        PerformanceEnums.ReviewStatus.Overdue]},
                    Peoples: {
                        $elemMatch: {$and:
                            [{
                                PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject,
                                StatusInCurrentReview: { $in:
                                    [PerformanceEnums.ReviewStatus.NotStarted,
                                        PerformanceEnums.ReviewStatus.InProgress,
                                        PerformanceEnums.ParticipantStatus.ReadyToSubmit,
                                        PerformanceEnums.ReviewStatus.Overdue] }
                            }]}
                    }
                },
                mReview = {},
                count = 0,
                subject;
            EntityCache.PerformanceReview.find(filter, function (error, data) {
                if (error) { return callback(error); }
                data.forEach(function (item) {
                    subject = item.Peoples.filter(function (pItem) {
                        return pItem.PeopleType === PerformanceEnums.DefaultPeopleTypes.Subject;
                    });
                    if (mReview[subject[0].MemberId]) {
                        mReview[subject[0].MemberId] += 1;
                    } else {
                        count += 1;
                        mReview[subject[0].MemberId] = 1;
                    }
                });
                callback(null, {data: mReview, length: count });
            });
        };

        this.GetGroupMemberInProgressReviews = function (params, callback) {
            var filter = {
                    'Card.GroupId': params.GroupId,
                    StatusByAdminView: { $in: [
                        PerformanceEnums.ReviewStatus.NotStarted,
                        PerformanceEnums.ReviewStatus.InProgress,
                        PerformanceEnums.ReviewStatus.Overdue]
                        },
                    Peoples: {
                        $elemMatch: { $and: [{
                            MemberId: params.RevieweeMemberId,
                            PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject,
                            StatusInCurrentReview: { $in: [
                                PerformanceEnums.ReviewStatus.NotStarted,
                                PerformanceEnums.ReviewStatus.InProgress,
                                PerformanceEnums.ParticipantStatus.ReadyToSubmit,
                                PerformanceEnums.ReviewStatus.Overdue
                            ]}
                        }]}
                    }
                },
                project = {
                    hgId: 1,
                    CycleId: 1,
                    CreatedDate: 1,
                    CycleName: 1,
                    'Card.Title': 1,
                    'Peoples.PeopleType': 1,
                    'Peoples.MemberId': 1,
                    'Peoples.MemberFullname': 1,
                    'Peoples.SubmitDate': 1,
                    'Peoples.Anonymous': 1
                };
            EntityCache.PerformanceReview.find(filter, project, function (error, data) {
                if (error) { return callback(error); }
                callback(null, data);
            });
        };

        this.GetMemberSubmittedReviewDetails = function (params, callback) {
            var query = {
                'Card.GroupId': params.GroupId,
                Peoples: {
                    $elemMatch: {
                        $and: [ {
                            MemberId: params.RevieweeMemberId,
                            StatusInCurrentReview: PerformanceEnums.ReviewStatus.Submitted,
                            SubmitDate: { $gte: new Date(params.StartDate).getTime(), $lte: new Date(params.EndDate).getTime() }
                        }]
                    }
                },
                StatusByAdminView: { $in: [PerformanceEnums.ReviewStatus.Submitted, PerformanceEnums.ReviewStatus.Closed] }
            }, project = {
                hgId: 1,
                CreatedDate: 1,
                CycleName: 1,
                CycleId: 1,
                'Card.Title': 1,
                'Peoples.PeopleType': 1,
                'Peoples.MemberId': 1,
                'Peoples.MemberFullname': 1,
                'Peoples.SubmitDate': 1,
                'Peoples.Anonymous': 1
            };
            EntityCache.PerformanceReview.find(query, project, function (error, data) {
                if (error) { return callback(error); }
                callback(null, data);
            });
        };
        this.GetMemberReviewDetails = function (params, callback) {
            var query = {
                'Card.GroupId': params.GroupId,
                Peoples: {
                    $elemMatch: {
                        $and: [ {
                            MemberId: params.RevieweeMemberId,
                            PeopleType: PerformanceEnums.DefaultPeopleTypes.Subject,
                            SubmitDate: { $gte: new Date(params.StartDate).getTime(), $lte: new Date(params.EndDate).getTime() }
                        }]
                    }
                },
                StatusByAdminView: { $in: [PerformanceEnums.ReviewStatus.Submitted, PerformanceEnums.ReviewStatus.Closed] }
            }, project = {
                hgId: 1,
                CycleId: 1,
                CreatedDate: 1,
                CycleName: 1,
                'Card.Title': 1,
                'Peoples.PeopleType': 1,
                'Peoples.MemberId': 1,
                'Peoples.MemberFullname': 1,
                'Peoples.SubmitDate': 1,
                'Peoples.Anonymous': 1
            };
            EntityCache.PerformanceReview.find(query, project, function (error, data) {
                if (error) { return callback(error); }
                callback(null, data);
            });
        };

        this.GetGroupCycleSummaryCount = function (params, callback) {
            var cycleStatusCount = {
                    NotStarted: 0,
                    InProgress: 0,
                    Submitted: 0
                };
            getCycleQuery(params, function (error, data) {
                if (error) { return callback(error); }
                var mAggregateFilterQuery = {
                        CycleId: {$in: data.CycleIds},
                        StatusByAdminView: {$ne: PerformanceEnums.ReviewStatus.Archived}
                    };
                PerformanceReview.aggregate([
                    {$match: mAggregateFilterQuery},
                    {$group: { _id: { CycleId: '$CycleId' }, Total: { $sum: 1 } }}
                ], function (error, result) {
                    if (error) {
                        return callback(error);
                    }
                    if (!result.length) {
                        return callback(null, cycleStatusCount);
                    }
                    var meaningfulCycleIds = result.map(function (r) {
                        return r._id.CycleId;
                    });
                    meaningfulCycleIds.forEach(function (cycleId) {
                        var cycle = data.ReturnedCycleIndex[cycleId];
                        if (cycle) {
                            if (cycle.PercentCompletion === 0) {
                                if (cycle.PercentPreInProgess === 100) {
                                    cycleStatusCount.NotStarted += 1;
                                } else {
                                    cycleStatusCount.InProgress += 1;
                                }
                            } else if (cycle.PercentCompletion === 100) {
                                cycleStatusCount.Submitted += 1;
                            } else {
                                cycleStatusCount.InProgress += 1;
                            }
                        }
                    });
                    callback(null, cycleStatusCount);
                });
            });
        };
        this.UpdateCycleMemberName = function (params, fcallback) {
            var updateCycleMemberName = function (cycle, callback) {
                if (cycle && cycle.Cards) {
                    cycle.Cards.forEach(function (cards) {
                        cards.Assignments.forEach(function (assignment) {
                            assignment.Participants.forEach(function (participant) {
                                if (participant.EntityType === EntityEnums.AutoCompleteEntityType.Member && participant.EntityId === params.MemberId) {
                                    participant.EntityName = params.FullName;
                                }
                            });
                        });
                    });
                    cycle.markModified('Cards');
                    cycle.save(function (error) {
                        if (error) {
                            callback(error);
                        } else {
                            callback();
                        }
                    });
                }
            };
            EntityCache.PerformanceCycle.find({ GroupId: params.GroupId, 'Cards.Assignments.Participants.EntityId': params.MemberId}, function (error, cycles) {
                if (error) {
                    return fcallback(error);
                }
                Async.each(cycles, updateCycleMemberName, fcallback);
            });
        };
        this.UpdateReviewMemberName = function (params, fcallback) {
            var updateReviewMemberName = function (review, callback) {
                review.Card.Sections.forEach(function (section) {
                    section.Questions.forEach(function (question) {
                        question.Answers.forEach(function (answer) {
                            if (answer.MemberId === params.MemberId) {
                                answer.MemberName = params.FullName;
                            }
                        });
                    });
                });
                review.Peoples.forEach(function (peopleItem) {
                    if (peopleItem.MemberId === params.MemberId) {
                        peopleItem.MemberFullname = params.FullName;
                    }
                });
                review.markModified('Card');
                review.save(function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback();
                });
            };
            EntityCache.PerformanceReview.find({'Card.GroupId': params.GroupId,
                StatusByAdminView: { $in: [PerformanceEnums.ReviewStatus.PendingDelivery,
                    PerformanceEnums.ReviewStatus.NotStarted,
                    PerformanceEnums.ReviewStatus.InProgress,
                    PerformanceEnums.ReviewStatus.Submitted,
                    PerformanceEnums.ReviewStatus.WaitingForSignOff,
                    PerformanceEnums.ReviewStatus.Overdue] },
                'Peoples.MemberId': params.MemberId}, function (error, reviews) {
                if (error) {
                    return fcallback(error);
                }
                Async.each(reviews, updateReviewMemberName, fcallback);
            });
        };
        this.PerformReviewCycleName = function (params, callback) {
            PerformanceReview.update(
                {CycleId: params.hgId},
                {$set: {
                    CycleName: params.Title,
                    ModifiedBy: params.UserId,
                    ModifiedDate: Date.now()
                }},
                {multi: true},
                callback
            );
        };
        this.PerformCycleTitle = function (params, callback) {
            PerformanceCycle.update(
                {hgId: params.hgId},
                {$set: {
                    Title: params.Title,
                    ModifiedBy: params.UserId,
                    ModifiedDate: Date.now()
                }},
                {multi: true},
                callback
            );
        };
        this.GetCycleByCycleId = function (params, callback) {
            PerformanceCycle.findOne({hgId: params.hgId}, callback);
        };
        this.ReopenPerformanceReview = function (params, cb) {
            var cycleId;
            PerformanceReview.findOne({
                hgId: params.ReviewId,
                'Card.GroupId': params.GroupId
            }, function (err, review) {
                if (err) {
                    return cb(err);
                }
                cycleId = review.CycleId;
                review.StatusByAdminView = PerformanceEnums.ReviewStatus.InProgress;
                review.Peoples.forEach(function (p) {
                    if (p.StatusInCurrentReview !== PerformanceEnums.ParticipantStatus.NA) {
                        p.StatusInCurrentReview = PerformanceEnums.ParticipantStatus.InProgress;
                    }
                });
                review.save(function (err) {
                    if (err) {
                        return cb(err);
                    }
                    self.UpdateCyclePercentCompletion({
                        CycleId: cycleId
                    }, function () { return; });
                    cb();
                });
            });
        };
    };

module.exports = PerformanceProcessor;
