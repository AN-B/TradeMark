/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    CreditAccountProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EventEmitterCache = this.EventEmitterCache,
            EntityCache = require('../framework/EntityCache.js'),
            HgLog = require('../framework/HgLog.js'),
            EventData = require('../common/EventData.js'),
            HgError = require('../common/HgError.js'),
            PusherManager = require('../util/PusherManager'),
            EventResponder = require('../util/EventResponder.js'),
            ParamsUtil = require('../util/params.js'),
            AccountType = require('../enums/AccountType.js'),
            RecognitionEnums = require('../enums/RecognitionEnums.js'),
            Async = require('async'),
            guid = require('node-uuid'),
            self = this,
            getNewCreditAccounts = function (membersList) {
                return membersList.map(function (member) {
                    return {
                        hgId: guid.v1(),
                        OwnerId: member.RecipientOwnerId,
                        AccountType: member.AccountType,
                        Balance: member.Recipient.credits,
                        CreateBy: member.OwnerId,
                        ModifidedBy: member.OwnerId,
                        GroupId: [member.GroupId]
                    };
                });
            },
            transferCreditForOneRecipient = function (params, callback) {
                EntityCache.CreditAccount.findOne({OwnerId: params.RecipientOwnerId, AccountType: params.AccountType}, function (err, toAccount) {
                    if (err) {
                        return callback(err);
                    }
                    toAccount.Balance += params.Recipient.credits;
                    toAccount.save();
                    callback();
                });
            },
            createBatchCreditAccounts = function (params, callback) {
                if (!params.Accounts || !params.Accounts.length) {
                    return callback(null, 'No Accounts to Create');
                }
                EntityCache.CreditAccount.create(params.Accounts, callback);
            },
            createCreditAccountIfNonExistent = function (params, callback) {
                EntityCache.CreditAccount.findOne({OwnerId: params.OwnerId, AccountType: params.AccountType}, function (error, foundAccount) {
                    if (error) {
                        return callback(error);
                    }
                    if (foundAccount) {
                        return callback(null, foundAccount);
                    }
                    HgLog.debug('Creating non-existent \'' + params.AccountType + '\' account for OwnerId: ' + params.OwnerId);
                    var newAccount = EntityCache.CreditAccount({
                            hgId: guid.v1(),
                            OwnerId: params.OwnerId,
                            AccountType: params.AccountType,
                            Balance: 0,
                            GroupId: [params.GroupId]
                        });
                    newAccount.save(callback);
                });
            };
        this.DefaultEntityName = 'CreditAccount';

        this.GetEconomyTimelineInDateRange = function (params, callback) {
            EntityCache.PointSnapshot.find({
                GroupId: params.GroupId,
                CreatedDate: {
                    $gt: params.StartDate,
                    $lt: params.EndDate
                }
            }).sort({CreatedDate: 1}).exec(function (error, data) {
                callback(error, data);
            });
        };

        this.GetSnapshotByTimestamp = function (params, callback) {
            EntityCache.PointSnapshot.findOne({
                GroupId: params.GroupId,
                CreatedDate: {
                    $lte: params.Timestamp
                }
            }).sort({CreatedDate: -1}).exec(function (error, snapshot) {
                callback(error, snapshot);
            });
        };

        this.SaveGroupPointSnapshot = function (params) {
            var snapshot = new EntityCache.PointSnapshot(params);
            snapshot.hgId = guid.v1();
            snapshot.save();
        };

        this.ClearPointAccount = function (params, callback) {
            var balance;
            EntityCache.CreditAccount.findOne({OwnerId: params.OwnerId, AccountType: params.AccountType}, function (error, account) {
                if (error || !account) {
                    callback(null, 0);
                } else {
                    balance = account.Balance;
                    account.Balance = 0;
                    account.save(function (error) {
                        callback(error, balance);
                    });
                }
            });
        };

        this.DistributePointsToMembers = function (params, callback) {
            var membersWithoutAccount = [],
                newAccounts = [],
                filterQuery = { OwnerId: { $in: params.PointsToMemberIds}, AccountType: 'PointTransfer' },
                updateQuery = { $inc: { Balance: params.Points } },
                options = { multi: true },
                getNewPointAccounts = function (membersList, points) {
                    var newAccountList = [];
                    membersList.forEach(function (memberId) {
                        newAccountList.push({
                            hgId: guid.v1(),
                            OwnerId: memberId,
                            AccountType: 'PointTransfer',
                            Balance: points,
                            GroupId: [params.GroupId]
                        });
                    });
                    return newAccountList;
                };

            if (!ParamsUtil.checkForRequiredParameters(['Points', 'PointsToMemberIds', 'FromAccountMemberId'], params)) {
                return callback('server.hge.gnr.spa');
            }
            EntityCache.CreditAccount.find(filterQuery, function (error, existingAccounts) {
                if (error) { return callback(error); }
                membersWithoutAccount = params.PointsToMemberIds.filter(function (allMemberItem) {
                    return existingAccounts.filter(function (membersThatExist) {
                        return membersThatExist.OwnerId === allMemberItem;
                    }).length === 0;
                });
                //get accounts that do not exist and create them
                newAccounts = getNewPointAccounts(membersWithoutAccount, params.Points);
                createBatchCreditAccounts({Accounts: newAccounts }, function (error, data) {
                    if (error) { return callback('Error creating new accounts : ' + error); }
                    // update accounts that do exist
                    EntityCache.CreditAccount.update(filterQuery, updateQuery, options, function (error, result) {
                        if (error) { return callback('Error updating existing accounts ' + error); }
                        // decrease points from PointAdminAccount
                        filterQuery = { OwnerId: params.FromAccountMemberId, AccountType: 'PointTransfer'};
                        updateQuery = { $inc: { Balance: -(params.Points * params.PointsToMemberIds.length)}};
                        EntityCache.CreditAccount.update(filterQuery, updateQuery, function (error, result) {
                            if (error) { return callback('Error decreasing value from Points from Point Admin' + error); }
                            callback(null, newAccounts.concat(existingAccounts));
                        });
                    });
                });
            });
        };
        this.DeductWithCapCredit = function (params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['OwnerId', 'AccountType', 'Credits'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            createCreditAccountIfNonExistent({OwnerId: params.OwnerId, AccountType: params.AccountType, GroupId: params.GroupId}, function (findAccountError, account) {
                if (findAccountError || !account) {
                    return callback(JSON.stringify(['business.cre.acc.pro.fcna', {err: findAccountError}]));
                }
                EntityCache.CreditAccount.findOne({OwnerId: params.OwnerId, AccountType: params.AccountType}, function (error, account) {
                    var amount = params.Credits;
                    if (error) {
                        return callback(error);
                    }
                    if (account.Balance < -params.Credits) {
                        amount = -account.Balance;
                    }
                    EntityCache.CreditAccount.update({OwnerId: params.OwnerId, AccountType: params.AccountType}, {$inc: {Balance: amount}}, function (error) {
                        callback(error, {Amount: amount, Account: account});
                    });
                });
            });
        };
        this.DeductWithCapPoint = function (params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['OwnerId', 'AccountType', 'Points'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            createCreditAccountIfNonExistent({OwnerId: params.OwnerId, AccountType: params.AccountType, GroupId: params.GroupId}, function (findAccountError, account) {
                if (findAccountError || !account) {
                    return callback(JSON.stringify(['business.cre.acc.pro.fcna', {err: findAccountError}]));
                }
                EntityCache.CreditAccount.findOne({OwnerId: params.OwnerId, AccountType: params.AccountType}, function (error, account) {
                    var amount = params.Points;
                    if (error) {
                        return callback(error);
                    }
                    if (account.Balance < -params.Points) {
                        amount = -account.Balance;
                    }
                    EntityCache.CreditAccount.update({OwnerId: params.OwnerId, AccountType: params.AccountType}, {$inc: {Balance: amount}}, function (error) {
                        callback(error, {Amount: amount, Account: account});
                    });
                });
            });
        };

        this.VerifyAndUpdateCredit = function (params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['OwnerId', 'AccountType', 'Credits'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            createCreditAccountIfNonExistent({OwnerId: params.OwnerId, AccountType: params.AccountType, GroupId: params.GroupId}, function (findAccountError, account) {
                if (findAccountError || !account) {
                    return callback(JSON.stringify(['business.cre.acc.pro.fcna', {err: findAccountError}]));
                }
                EntityCache.CreditAccount.findOneAndUpdate({
                    OwnerId: params.OwnerId,
                    AccountType: params.AccountType,
                    Balance: {$gte: -params.Credits}
                }, {
                    $inc: {Balance: params.Credits}
                }, {
                    new: true
                }, function (error, account) {
                    if (error) {
                        callback(error);
                    } else if (!account) {
                        callback(JSON.stringify(['business.cre.acc.pro.youc', {OperationType: params.OperationType} ]));
                    } else {
                        callback(null, account);
                    }
                });
            });
        };
        this.VerifyAndUpdatePoint = function (params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['OwnerId', 'AccountType', 'Points'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            createCreditAccountIfNonExistent({OwnerId: params.OwnerId, AccountType: params.AccountType, GroupId: params.GroupId}, function (findAccountError, account) {
                if (findAccountError || !account) {
                    return callback(JSON.stringify(['business.cre.acc.pro.fcna', {err: findAccountError}]));
                }
                EntityCache.CreditAccount.findOneAndUpdate({
                    OwnerId: params.OwnerId,
                    AccountType: params.AccountType,
                    Balance: {$gte: -params.Points}
                }, {
                    $inc: {Balance: params.Points}
                }, {
                    new: true
                }, function (error, account) {
                    if (error) {
                        callback(error);
                    } else if (!account) {
                        callback(JSON.stringify(['business.cre.acc.pro.youp', {OperationType: params.OperationType} ]));
                    } else {
                        callback(null, account);
                    }
                });
            });
        };

        this.GetCreditAccountsByOwnerIds = function (params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['OwnerIds', 'AccountTypes'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }
            EntityCache.CreditAccount.find({OwnerId: {$in: params.OwnerIds}, AccountType: {$in: params.AccountTypes}}, callback);
        };

        this.GetPointQuartile = function (params, callback) {
            var quartile = {};
            //Note to comeback to optimize after db upgrade to 3.2.9
            EntityCache.CreditAccount.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    AccountType: {$in: params.AccountTypes},
                    IsActive: true
                }},
                {$sort: {Balance: 1}},
                {$group: {
                    _id: "$AccountType",
                    Max: {$max: "$Balance"},
                    Min: {$min: "$Balance"},
                    Balance: {$push: "$Balance"}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    if (!quartile[item._id]) {
                        quartile[item._id] = item.Balance.length ? [
                            item.Min,
                            ParamsUtil.CalculateQuartile(0.25, item.Balance),
                            ParamsUtil.CalculateQuartile(0.50, item.Balance),
                            ParamsUtil.CalculateQuartile(0.75, item.Balance),
                            item.Max
                        ] : [0, 0, 0, 0, 0];
                    }
                });
                callback(null, quartile);
            });
        };

        this.GetCreditAccountByOwnerId = function (params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['OwnerId', 'AccountType'], params)) {
                if (callback) {
                    return callback(HgError.Enums.Generic.MissingParameters);
                }
            }
            EntityCache.CreditAccount.findOne({
                OwnerId: params.OwnerId,
                AccountType: params.AccountType
            }, function (errorFindingAccount, creditAccount) {
                if (errorFindingAccount) {
                    return callback(errorFindingAccount);
                }
                if (!creditAccount) {
                    createCreditAccountIfNonExistent({
                        OwnerId: params.OwnerId,
                        AccountType: params.AccountType,
                        GroupId: params.GroupId
                    }, callback);
                } else {
                    callback(null, creditAccount);
                }
            });
        };

        this.GetPointAccounts = function (params, callback) {
            var returnAccounts = {};
            self.GetCreditAccountByOwnerId({OwnerId: params.MemberIdInGroup, AccountType: AccountType.PointSpend, GroupId: params.GroupId}, function (err, pointSpend) {
                if (err) {
                    return callback(err);
                }
                returnAccounts.pointSpend = pointSpend;
                self.GetCreditAccountByOwnerId({OwnerId: params.MemberIdInGroup, AccountType: AccountType.PointTransfer, GroupId: params.GroupId}, function (err, pointTransfer) {
                    if (err) {
                        return callback(err);
                    }
                    returnAccounts.pointTransfer = pointTransfer;
                    callback(null, returnAccounts);
                });
            });
        };

        this.TransferCreditsBetweenAMemberAndAUser = function (params, callback) {
            var creditsToTransfer = params.creditsForUser,
                issuerMemberId = params.issuerMemberId,
                recipientUserId = params.recipientUserId,
                fromAccountType = params.fromAccountType,
                toAccountType = params.toAccountType;
            if (creditsToTransfer > 0) {
                // Janky as hell... --Demetri
                createCreditAccountIfNonExistent({OwnerId: issuerMemberId, AccountType: fromAccountType, GroupId: params.GroupId}, function (error, account1) {
                    createCreditAccountIfNonExistent({OwnerId: recipientUserId, AccountType: toAccountType, GroupId: params.GroupId}, function (error, account2) {
                        EntityCache.CreditAccount.findOneAndUpdate({
                            OwnerId: issuerMemberId,
                            AccountType: fromAccountType
                        }, {
                            $inc: {Balance: -creditsToTransfer}
                        }, {
                            new: true
                        }, function (errDeduct, issuerAccount) {
                            if (errDeduct === null && issuerAccount !== null) {
                                EntityCache.CreditAccount.findOneAndUpdate({
                                    OwnerId: recipientUserId,
                                    AccountType: toAccountType
                                }, {
                                    $inc: {Balance: creditsToTransfer}
                                }, {
                                    new: true
                                }, function (errAdd, recipientAccount) {
                                    if (errAdd === null && recipientAccount !== null) {
                                        if (callback) {
                                            callback(null, {success: true, issuerAccount: issuerAccount, recipientAccount: recipientAccount});
                                        } else {
                                            EventResponder.RespondWithData(EventEmitterCache, params, {success: true, issuerAccount: issuerAccount, recipientAccount: recipientAccount});
                                        }
                                    } else {
                                        EntityCache.CreditAccount.update({OwnerId: issuerMemberId, AccountType: fromAccountType}, {$inc: {Balance: creditsToTransfer}}, function (errDeduct) {
                                            if (errDeduct) {
                                                HgLog.error('Error deducting credits', errDeduct);
                                            }
                                        });
                                        if (callback) {
                                            callback(HgError.Enums.CreditAccount.ErrorDistributingCredit);
                                        } else {
                                            EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CreditAccount.ErrorDistributingCredit);
                                        }
                                    }
                                });
                            } else {
                                if (callback) {
                                    callback(HgError.Enums.CreditAccount.ErrorDistributingCredit);
                                } else {
                                    EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CreditAccount.ErrorDistributingCredit);
                                }
                            }
                        });
                    });
                });
            } else {
                EventResponder.RespondWithData(EventEmitterCache, params, {success: true});
            }
        };

        this.VerifyGroupTransferSetting = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                var recipients = params.Recipients,
                    i,
                    len;
                if (err) {
                    return callback('business.gro.pro.elg');
                }
                for (i = 0, len = recipients.length; i < len; i += 1) {
                    if (recipients[i].credits < group.CreditSetting.MinTransfer || recipients[i].credits > group.CreditSetting.MaxTransfer) {
                        callback(JSON.stringify(['business.cre.acc.pro.tra', {MinTransfer: group.CreditSetting.MinTransfer, MaxTransfer: group.CreditSetting.MaxTransfer}]));
                        return;
                    }
                }
                callback(null, true);
            });
        };

        this.TransferCredit = function (params, callback) {
            var len,
                requests = params.Requests,
                TotalCredit = params.TotalCredit,
                accountType = params.AccountType, // This value MUST be used for the giving account and any recipient accounts!,
                processCreditTransferAsync = function (existingAccounts, callback) {
                    len = existingAccounts.length;
                    if (len === 0) {
                        return callback();
                    }
                    Async.whilst(
                        function () {
                            len -= 1;
                            return len > -1;
                        },
                        function (callback) {
                            transferCreditForOneRecipient(existingAccounts[len], callback);
                        },
                        function (err) {
                            if (err) {
                                callback(err + ' error happened in transferCreditForOneRecipient');
                            } else {
                                callback();
                            }
                        }
                    );
                };

            EntityCache.CreditAccount.findOneAndUpdate({
                OwnerId: params.OwnerId,
                AccountType: accountType,
                Balance: {$gte: TotalCredit}
            }, {
                $inc: {Balance: -TotalCredit}
            }, {
                new: true
            }, function (error, account) {
                var membersWithoutAccount = [],
                    membersWithAccount = [],
                    summaryData = {};

                if (error) {
                    callback(error);
                } else if (!account) {
                    callback(JSON.stringify(['business.cre.acc.pro.youc', {OperationType: params.OperationType} ]));
                } else {
                    summaryData.requests = requests;
                    summaryData.FromAccountId = account.hgId;
                    EntityCache.CreditAccount.find({ OwnerId: { $in: params.RecipientIds}, AccountType: accountType }, function (error, existingAccounts) {
                        if (error) {
                            return callback(error);
                        }
                        membersWithoutAccount = requests.filter(function (request) {
                            return existingAccounts.filter(function (membersThatExist) {
                                return membersThatExist.OwnerId === request.RecipientOwnerId;
                            }).length === 0;
                        });
                        if (membersWithoutAccount && membersWithoutAccount.length) {
                            createBatchCreditAccounts({Accounts: getNewCreditAccounts(membersWithoutAccount) }, function (error, data) {
                                if (error) {
                                    return callback('Error creating new accounts : ' + error);
                                }
                                membersWithAccount = requests.filter(function (request) {
                                    return existingAccounts.filter(function (membersThatExist) {
                                        return membersThatExist.OwnerId === request.RecipientOwnerId;
                                    }).length > 0;
                                });

                                processCreditTransferAsync(membersWithAccount, function (err) {
                                    if (err) {
                                        return callback(err);
                                    }
                                    callback(null, summaryData);
                                });
                            });
                        } else {
                            processCreditTransferAsync(requests, function (err) {
                                if (err) {
                                    return callback(err);
                                }
                                callback(null, summaryData);
                            });
                        }
                    });
                }
            });
        };

        this.LoadPackTemplate = function (params) {
            EntityCache.CreditPurchaseTemplate.findOne({hgId: params.PackTemplateId}, function (err, template) {
                EventResponder.RespondGeneric(EventEmitterCache, params, err, template);
            });
        };

        this.OffBoardMemberCreditTransferWithCallback = function (params, callback) {
            var fromAccountBalance;
            EntityCache.CreditAccount.findOne({OwnerId: params.FromAccountOwnerId,
                AccountType: AccountType.Transfer}, function (error, fromAccount) {
                if (error) {
                    callback('server.hge.cac.elc');
                } else {
                    if (!fromAccount || fromAccount.Balance === 0) { // this member does not have a transfer account
                        callback(null, 'successful');
                    } else {
                        fromAccountBalance = fromAccount.Balance;
                        fromAccount.Balance = 0;
                        fromAccount.save(function (error) {
                            if (error) {
                                callback(HgError.Enums.CreditAccount.ErrorUpdatingCreditAccount);
                            } else {
                                EntityCache.CreditAccount.findOneAndUpdate({OwnerId: params.ToAccountOwnerId, AccountType: AccountType.Transfer}, {$inc: {Balance: fromAccountBalance}}, {new: true}, function (error, toAccount) {
                                    PusherManager.CreditsUpdated({ CreditAmount: fromAccountBalance, AccountType: 'transfer', UserId: params.ToAccountOwnerId.UserId});
                                    callback(null, {
                                        success: true,
                                        AccountId: toAccount.hgId,
                                        CreditQuantity: fromAccountBalance,
                                        ToAccountOwner: params.ToAccountOwner,
                                        OffBoardedMember: params.OffBoardedMember
                                    });
                                });
                            }
                        });
                    }
                }
            });
        };

        this.OffBoardMemberCreditTransfer = function (params) {
            var fromAccountBalance;
            EntityCache.CreditAccount.findOne({OwnerId: params.FromAccountOwnerId, AccountType: AccountType.Transfer}, function (err, fromAccount) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CreditAccount.ErrorLoadingCreditAccount));
                    return;
                }
                if (!fromAccount || fromAccount.Balance === 0) { // this member does not have a transfer account
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, 'successful'));
                    return;
                }
                fromAccountBalance = fromAccount.Balance;
                fromAccount.Balance = 0;
                fromAccount.save(function (err) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.CreditAccount.ErrorUpdatingCreditAccount));
                        return;
                    }
                    EntityCache.CreditAccount.findOneAndUpdate({OwnerId: params.ToAccountOwnerId, AccountType: AccountType.Transfer}, {$inc: {Balance: fromAccountBalance}}, {new: true}, function (err, toAccount) {
                        PusherManager.CreditsUpdated({
                            CreditAmount: fromAccountBalance,
                            AccountType: 'transfer',
                            UserId: params.ToAccountOwnerId.UserId
                        });
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {success: true, AccountId: toAccount.hgId,
                                CreditQuantity: fromAccountBalance, ToAccountOwner: params.ToAccountOwner}));
                    });
                });
            });
        };

        this.UpdateCreditForRedeem = function (params, callback) {
            EntityCache.CreditAccount.findOneAndUpdate({
                OwnerId: params.UserId,
                AccountType: AccountType.Spend,
                Balance: {$gte: params.CreditQuantity}
            }, {
                $inc: {Balance: -params.CreditQuantity}
            }, {
                new: true
            }, function (error, account) {
                if (error) {
                    callback(error, null);
                } else if (!account) {
                    callback('You do not have sufficient credits to perform this request: ' + params.OperationType, null);
                } else {
                    callback(null, {success: true, accountId: account.hgId});
                }
            });
        };

        this.UpdateCreditForPurchase = function (params) {
            var query = {OwnerId: params.MemberId, AccountType: AccountType.Transfer};
            if (params.WhomToBuy === 'Myself') {
                query = {OwnerId: params.UserId, AccountType: AccountType.Spend};
            }
            EntityCache.CreditAccount.findOneAndUpdate(query, {$inc: {Balance: params.CreditQuantity}}, {new: true}, function (err, account) {
                if (!err && !account) {
                    err = 'failed';
                }
                EventResponder.RespondGeneric(EventEmitterCache, params, err, {AccountId: account.hgId});
            });
        };

        this.VerifyCreditBalance = function (params, callback) {
            if (!params.OwnerId || !params.AccountType) {
                if (callback) {
                    callback('OwnerId or AccountType was not specified.');
                } else {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'OwnerId or AccountType was not specified.');
                }
            } else {
                if (params.TotalCredit <= 0) {
                    if (callback) {
                        callback(null, true);
                    } else {
                        EventResponder.RespondWithData(EventEmitterCache, params, true);
                    }
                } else {
                    createCreditAccountIfNonExistent({OwnerId: params.OwnerId, AccountType: params.AccountType, GroupId: params.GroupId}, function (findAccountError, account) {
                        if (findAccountError) {
                            if (callback) {
                                callback(findAccountError, null);
                            } else {
                                EventResponder.RespondWithError(EventEmitterCache, params, findAccountError);
                            }
                        } else {
                            if (account.Balance < params.TotalCredit) {
                                if (params.OperationType === 'RedeemGiftcard') {
                                    if (callback) {
                                        callback(HgError.Enums.Credit.InsufficientFundsToRedeem, null);
                                    } else {
                                        EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Credit.InsufficientFundsToRedeem);
                                    }
                                } else if (params.OperationType === 'GiveRecognition') {
                                    if (callback) {
                                        callback(HgError.Enums.Credit.InsufficientFundsForRecognition, null);
                                    } else {
                                        EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Credit.InsufficientFundsForRecognition);
                                    }
                                } else if (params.OperationType === 'TransferCredit') {
                                    if (callback) {
                                        callback(HgError.Enums.Credit.InsufficientFundsToTransferCredits, null);
                                    } else {
                                        EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Credit.InsufficientFundsToTransferCredits);
                                    }
                                }
                            } else {
                                if (callback) {
                                    callback(null, true);
                                } else {
                                    EventResponder.RespondWithData(EventEmitterCache, params, true);
                                }
                            }
                        }
                    });
                }
            }
        };
        this.VerifyPointBalance = function (params, callback) {
            if (!params.OwnerId || !params.AccountType) {
                if (callback) {
                    callback('business.cre.acc.pro.oans');
                } else {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'OwnerId or AccountType was not specified.');
                }
            } else {
                if (params.TotalPoint <= 0) {
                    return callback(null, true);
                }
                createCreditAccountIfNonExistent({OwnerId: params.OwnerId, AccountType: params.AccountType, GroupId: params.GroupId}, function (findAccountError, account) {
                    if (findAccountError) {
                        return callback(findAccountError);
                    }
                    if (account.Balance >= params.TotalPoint) {
                        return callback(null, true);
                    }
                    if (params.OperationType === RecognitionEnums.OperationType.RedeemGiftcard) {
                        callback(HgError.Enums.Credit.InsufficientFundsToRedeem);
                    } else if (params.OperationType === RecognitionEnums.OperationType.GiveRecognition ||
                            params.OperationType === RecognitionEnums.OperationType.AddPoints) {
                        self.VerifyTotalPointBalance(params, callback);
                    } else if (params.OperationType === RecognitionEnums.OperationType.TransferCredit) {
                        callback(HgError.Enums.Credit.InsufficientFundsToRedeem);
                    }
                });
            }
        };
        this.VerifyTotalPointBalance = function (params, callback) {
            self.GetPointAccounts({
                MemberIdInGroup: params.OwnerId
            }, function (findAccountError, pointAccounts) {
                var totalPointBalance = pointAccounts.pointSpend.Balance || 0;
                totalPointBalance += pointAccounts.pointTransfer.Balance || 0;
                if (findAccountError) {
                    callback(findAccountError);
                } else {
                    if (totalPointBalance < params.TotalPoint) {
                        if (params.OperationType === RecognitionEnums.OperationType.GiveRecognition) {
                            return callback(HgError.Enums.Points.InsufficientPointsForRecognition);
                        }
                        return callback(HgError.Enums.Points.InsufficientFundsAddPoints);
                    }
                    callback(null, true);
                }
            });
        };
        this.EarmarkCredit = function (params, callback) {
            var memberId = params.MemberId,
                TotalCredit = params.TotalCredit;
            //Revisit this later... -Demetri
            createCreditAccountIfNonExistent({OwnerId: memberId, AccountType: AccountType.Transfer, GroupId: params.GroupId}, function (error, account1) {
                createCreditAccountIfNonExistent({OwnerId: memberId, AccountType: AccountType.EarmarkTransfer, GroupId: params.GroupId}, function (error, account2) {
                    EntityCache.CreditAccount.findOneAndUpdate({
                        OwnerId: memberId,
                        AccountType: AccountType.Transfer
                    }, {
                        $inc: {Balance: -TotalCredit}
                    }, {
                        new: true
                    }, function (errDeduct, transferAccount) {
                        if (!errDeduct && transferAccount !== null) {
                            EntityCache.CreditAccount.findOneAndUpdate({
                                OwnerId: memberId,
                                AccountType: AccountType.EarmarkTransfer
                            }, {
                                $inc: {Balance: TotalCredit}
                            }, {
                                new: true
                            }, function (errAdd, earmarkAccount) {
                                if (!errAdd && earmarkAccount !== null) {
                                    if (callback) {
                                        callback(null, {EarmarkAccountId: earmarkAccount.hgId, TransferAccountId: transferAccount.hgId});
                                    } else {
                                        EventResponder.RespondWithData(EventEmitterCache, params, {EarmarkAccountId: earmarkAccount.hgId, TransferAccountId: transferAccount.hgId});
                                    }
                                } else {
                                    if (callback) {
                                        callback(HgError.Enums.CreditAccount.ErrorEarmarking);
                                    } else {
                                        EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CreditAccount.ErrorEarmarking);
                                    }
                                }
                            });
                        } else {
                            if (callback) {
                                callback(HgError.Enums.CreditAccount.ErrorEarmarking);
                            } else {
                                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CreditAccount.ErrorEarmarking);
                            }
                        }
                    });
                });
            });
        };

        function verifyCreditBalanceByAccountId(params, callback) {
            if (ParamsUtil.checkForRequiredParameters(['AccountId', 'Credits'], params)) {
                EntityCache.CreditAccount.findOne({hgId: params.AccountId}, function (accountError, creditAccount) {
                    if (!accountError) {
                        if (creditAccount) {
                            if (creditAccount.Balance >= params.Credits) {
                                callback(null, true);
                            } else {
                                callback(null, false);
                            }
                        } else {
                            callback(HgError.Enums.CreditAccount.SourceAcccountNotFound);
                        }
                    } else {
                        callback(accountError);
                    }
                });
            } else {
                callback(HgError.Enums.Generic.MissingParameters);
            }
        }

        function getSourceAccountByEarmarkAccount(sourceCreditAccount, groupId, callback) {
            var DestinationAccountType = '';
            switch (sourceCreditAccount.AccountType) {
            case AccountType.EarmarkSpend:
                DestinationAccountType = AccountType.Spend;
                break;
            case AccountType.EarmarkTransfer:
                DestinationAccountType = AccountType.Transfer;
                break;
            default:
                DestinationAccountType = null;
                break;
            }
            if (DestinationAccountType !== null && DestinationAccountType !== '') {
                EntityCache.CreditAccount.findOne({OwnerId: sourceCreditAccount.OwnerId, AccountType: DestinationAccountType}, function (errorGettingAccount, account) {
                    if (errorGettingAccount) {
                        return callback(errorGettingAccount);
                    }
                    if (account) {
                        return callback(null, account);
                    }
                    createCreditAccountIfNonExistent({OwnerId: sourceCreditAccount.OwnerId, AccountType: DestinationAccountType, GroupId: groupId}, callback);
                });
            } else {
                callback(new Error('Unknown source account type: ' + sourceCreditAccount.AccountType));
            }
        }

        function getEarmarkAccountBySourceAccount(sourceCreditAccount, groupId, callback) {
            var DestinationAccountType = '';
            switch (sourceCreditAccount.AccountType) {
            case AccountType.Spend:
                DestinationAccountType = AccountType.EarmarkSpend;
                break;
            case AccountType.Transfer:
                DestinationAccountType = AccountType.EarmarkTransfer;
                break;
            default:
                DestinationAccountType = null;
                break;
            }
            if (DestinationAccountType !== null && DestinationAccountType !== '') {
                EntityCache.CreditAccount.findOne({OwnerId: sourceCreditAccount.OwnerId, AccountType: DestinationAccountType}, function (errorGettingAccount, account) {
                    if (errorGettingAccount) {
                        return callback(errorGettingAccount);
                    }
                    if (account) {
                        return callback(null, account);
                    }
                    createCreditAccountIfNonExistent({OwnerId: sourceCreditAccount.OwnerId, AccountType: DestinationAccountType, GroupId: groupId}, callback);
                });
            } else {
                callback(new Error('Unknown source account type: ' + sourceCreditAccount.AccountType));
            }
        }

        function transferCreditsBetweenAccounts(params, callback) {
            if (ParamsUtil.checkForRequiredParameters(['SourceAccountId', 'DestinationAccountId', 'Credits'], params)) {
                verifyCreditBalanceByAccountId({AccountId: params.SourceAccountId, Credits: params.Credits}, function (balanceCheckError, balanceCheckResult) {
                    if (!balanceCheckError) {
                        if (balanceCheckResult === true) {
                            EntityCache.CreditAccount.findOneAndUpdate({
                                hgId: params.SourceAccountId
                            }, {
                                $inc: {Balance: -params.Credits}
                            }, {
                                new: true
                            }, function (errDeduct, sourceAccount) {
                                if (!errDeduct && sourceAccount !== null) {
                                    EntityCache.CreditAccount.findOneAndUpdate({
                                        hgId: params.DestinationAccountId
                                    }, {
                                        $inc: {Balance: params.Credits}
                                    }, {
                                        new: true
                                    }, function (errAdd, destinationAccount) {
                                        if (!errAdd && destinationAccount !== null) {
                                            callback(null, {
                                                SourceAccountId: params.SourceAccountId,
                                                SourceAccountType: sourceAccount.AccountType,
                                                DestinationAccountId: params.DestinationAccountId,
                                                DestinationAccountType: destinationAccount.AccountType,
                                                Credits: params.Credits
                                            });
                                        } else {
                                            EntityCache.CreditAccount.findOneAndUpdate({
                                                hgId: params.SourceAccountId
                                            }, {
                                                $inc: {Balance: params.Credits}
                                            }, {
                                                new: true
                                            }, function (errAddToDeduct, sourceAddAccount) {
                                                callback(HgError.Enums.CreditAccount.ErrorTransferringFundsBetweenAccounts);
                                            });
                                        }
                                    });
                                } else {
                                    callback(HgError.Enums.CreditAccount.ErrorTransferringFundsBetweenAccounts);
                                }
                            });
                        } else {
                            callback(HgError.Enums.CreditAccount.InsufficientFunds);
                        }
                    } else {
                        callback(balanceCheckError);
                    }
                });
            } else {
                callback(HgError.Enums.Generic.MissingParameters);
            }
        }

        function earmarkCreditsBySourceAccount(params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['SourceAccount', 'Credits'], params)) {
                return callback(new Error(HgError.Enums.Generic.MissingParameters));
            }
            getEarmarkAccountBySourceAccount(params.SourceAccount, params.GroupId, function (errorDestinationAccount, destinationAccount) {
                if (errorDestinationAccount) {
                    return callback(new Error(errorDestinationAccount));
                }
                if (!destinationAccount) {
                    return callback(new Error(HgError.Enums.CreditAccount.DestinationAccountNotFound));
                }
                transferCreditsBetweenAccounts({SourceAccountId: params.SourceAccount.hgId, DestinationAccountId: destinationAccount.hgId, Credits: params.Credits}, callback);
            });
        }

        function reverseEarmarkCreditsBySourceAccount(params, callback) {
            if (!ParamsUtil.checkForRequiredParameters(['SourceAccount', 'Credits'], params)) {
                return callback(new Error(HgError.Enums.Generic.MissingParameters));
            }
            getSourceAccountByEarmarkAccount(params.SourceAccount, params.GroupId, function (errorDestinationAccount, destinationAccount) {
                if (errorDestinationAccount) {
                    return callback(new Error(errorDestinationAccount));
                }
                if (destinationAccount) {
                    return transferCreditsBetweenAccounts({ SourceAccountId: params.SourceAccount.hgId, DestinationAccountId: destinationAccount.hgId, Credits: params.Credits}, callback);
                }
                return callback(new Error(HgError.Enums.CreditAccount.DestinationAccountNotFound));
            });
        }

        this.AddCreditsByAccountId = function (params, callback) {
            if (ParamsUtil.checkForRequiredParameters(['AccountId', 'Credits'], params)) {
                EntityCache.CreditAccount.findOneAndUpdate({hgId: params.AccountId}, {$inc: {Balance: params.Credits}}, {new: true}, function (creditUpdateError, creditAccount) {
                    if (callback) {
                        callback(creditUpdateError, creditAccount);
                    } else {
                        EventResponder.RespondGeneric(EventEmitterCache, params, creditUpdateError, creditAccount);
                    }
                });
            } else {
                if (callback) {
                    callback(HgError.Enums.Generic.MissingParameters);
                } else {
                    EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
                }
            }
        };

        this.DeductCreditsByAccountId = function (params, callback) {
            if (ParamsUtil.checkForRequiredParameters(['AccountId', 'Credits'], params)) {
                verifyCreditBalanceByAccountId(params, function (balanceCheckError, balanceCheckResult) {
                    if (!balanceCheckError) {
                        if (balanceCheckResult === true) {
                            EntityCache.CreditAccount.findOneAndUpdate({hgId: params.AccountId}, {$inc: {Balance: -params.Credits}}, {new: true}, function (creditUpdateError, creditAccount) {
                                if (callback) {
                                    callback(null, creditAccount);
                                } else {
                                    EventResponder.RespondGeneric(EventEmitterCache, params, creditUpdateError, creditAccount);
                                }
                            });
                        } else {
                            if (callback) {
                                callback(HgError.Enums.CreditAccount.InsufficientFunds);
                            } else {
                                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CreditAccount.InsufficientFunds);
                            }
                        }
                    } else {
                        if (callback) {
                            callback(balanceCheckError);
                        } else {
                            EventResponder.RespondWithError(EventEmitterCache, params, balanceCheckError);
                        }
                    }
                });
            } else {
                if (callback) {
                    callback(HgError.Enums.Generic.MissingParameters);
                } else {
                    EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
                }
            }
        };

        this.DeductCreditsByAccountIdNoBalanceCheck = function (params) {
            if (ParamsUtil.checkForRequiredParameters(['AccountId', 'Credits'], params)) {
                EntityCache.CreditAccount.findOneAndUpdate({hgId: params.AccountId}, {$inc: {Balance: -params.Credits}}, {new: true}, function (creditUpdateError, creditAccount) {
                    EventResponder.RespondGeneric(EventEmitterCache, params, creditUpdateError, creditAccount);
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
            }
        };

        this.EarmarkCreditsByOwnerIdAndAccountType = function (params) {
            if (ParamsUtil.checkForRequiredParameters(['OwnerId', 'AccountType', 'Credits'], params)) {
                EntityCache.CreditAccount.findOne({OwnerId: params.OwnerId, AccountType: params.AccountType}, function (sourceAccountError, sourceAccount) {
                    if (!sourceAccountError) {
                        if (sourceAccount) {
                            earmarkCreditsBySourceAccount({SourceAccount: sourceAccount, Credits: params.Credits, GroupId: params.GroupId}, function (earmarkError, earmarkResults) {
                                EventResponder.RespondGeneric(EventEmitterCache, params, earmarkError, earmarkResults);
                            });
                        } else {
                            EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CreditAccount.SourceAcccountNotFound);
                        }
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, sourceAccountError);
                    }
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.gnr.spa');
            }
        };

        this.ReverseEarmarkCreditsByOwnerIdAndAccountType = function (params) {
            if (ParamsUtil.checkForRequiredParameters(['OwnerId', 'AccountType', 'Credits'], params)) {
                EntityCache.CreditAccount.findOne({OwnerId: params.OwnerId, AccountType: params.AccountType}, function (sourceAccountError, sourceAccount) {
                    if (!sourceAccountError) {
                        if (sourceAccount) {
                            reverseEarmarkCreditsBySourceAccount({SourceAccount: sourceAccount, Credits: params.Credits, GroupId: params.GroupId}, function (earmarkError, earmarkResults) {
                                EventResponder.RespondGeneric(EventEmitterCache, params, earmarkError, earmarkResults);
                            });
                        } else {
                            EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.CreditAccount.SourceAcccountNotFound);
                        }
                    } else {
                        EventResponder.RespondWithError(EventEmitterCache, params, sourceAccountError);
                    }
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Generic.MissingParameters);
            }
        };

        this.VerifyCreditBalanceByAccountId = function (params) {
            verifyCreditBalanceByAccountId(params, function (balanceCheckError, balanceCheckResult) {
                EventResponder.RespondGeneric(EventEmitterCache, params, balanceCheckError, balanceCheckResult);
            });
        };

        this.UpdateCreditByQuatity = function (params, callback) {
            EntityCache.CreditAccount.findOne({OwnerId: params.UserId, AccountType: AccountType.Spend}, function (getError, account) {
                if (getError) {
                    callback(HgError.Enums.Credit.ErrorLoading);
                } else {
                    if (!account || (account.Balance < -params.Quantity && params.Quantity < 0)) {
                        callback('The account does not have sufficient funds to support the transaction');
                    } else {
                        account.Balance += params.Quantity;
                        account.save(function (saveError) {
                            if (saveError) {
                                return callback('business.cre.erru');
                            }
                            callback(null, {success: true, accountId: account.hgId, quantity: params.Quantity});
                        });
                    }
                }
            });
        };
        this.GetPointsBalanceSnapshot = function (params, callback) {
            var snapshot = {
                SpendTotal: 0,
                TransferTotal: 0
            };
            EntityCache.CreditAccount.aggregate([
                {$match: {
                    IsActive: true,
                    GroupId: {$in: [params.GroupId]},
                    AccountType: {$in: [AccountType.PointSpend, AccountType.PointTransfer] }
                }},
                {$group: {
                    _id: "$AccountType",
                    Total: {$sum: "$Balance"}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    if (item._id === AccountType.PointSpend) {
                        snapshot.SpendTotal = item.Total;
                    } else if (item._id === AccountType.PointTransfer) {
                        snapshot.TransferTotal = item.Total;
                    }
                });
                callback(null, snapshot);
            });
        };

        this.UpdateCreditAccountStatus = function (params, callback) {
            EntityCache.CreditAccount.update({
                OwnerId: {$in: params.OwnerIds},
                GroupId: params.GroupId,
                IsActive: params.OldStatus
            }, {
                $set: {
                    IsActive:  params.NewStatus,
                    ModifidedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };
    };

module.exports = CreditAccountProcessor;
