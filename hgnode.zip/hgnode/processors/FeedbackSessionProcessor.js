/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    FeedbackSessionProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            FeedbackEnums = require('../enums/FeedbackEnums.js'),
            ConstantEnums = require('../enums/ConstantEnums.js'),
            Enums = require('../enums/EntityEnums.js'),
            async = require('async'),
            guid = require('node-uuid'),
            HgLog = require('../framework/HgLog');
        function findQuestionInCard(session, questionInPayload) {
            var i,
                j,
                sLen = session.Card.Sections.length,
                qlen;
            for (i = 0; i < sLen; i += 1) {
                qlen = session.Card.Sections[i].Questions.length;
                for (j = 0; j < qlen; j += 1) {
                    if (session.Card.Sections[i].Questions[j].hgId === questionInPayload.hgId) {
                        return session.Card.Sections[i].Questions[j];
                    }
                }
            }
        }
        function getAboutOthersCompletedQuery(params) {
            return {$or: [
                {
                    GroupId: params.GroupId,
                    CycleType: {$in: [
                        FeedbackEnums.CycleType.Request,
                        FeedbackEnums.CycleType.Give,
                        FeedbackEnums.CycleType.EvaluateOthers
                    ]},
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.Declined,
                        FeedbackEnums.SessionStatus.Expired,
                        FeedbackEnums.SessionStatus.SubjectRated,
                        FeedbackEnums.SessionStatus.Submitted,
                        FeedbackEnums.SessionStatus.Completed,
                        FeedbackEnums.SessionStatus.Closed]},
                    Participants: {
                        $elemMatch: {
                            ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                            MemberId: params.MemberId
                        }
                    }
                }, {
                    GroupId: params.GroupId,
                    CycleType: {$in: [
                        FeedbackEnums.CycleType.EvaluateOthers
                    ]},
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.Declined,
                        FeedbackEnums.SessionStatus.Expired,
                        FeedbackEnums.SessionStatus.SubjectRated,
                        FeedbackEnums.SessionStatus.Completed,
                        FeedbackEnums.SessionStatus.Closed]},
                    Participants: {
                        $elemMatch: {
                            ParticipantType: FeedbackEnums.SessionParticipantType.Requester,
                            MemberId: params.MemberId
                        }
                    }
                }
            ]};
        }
        function getAboutOthersInboxQuery(params) {
            return {
                $or: [
                    {
                        GroupId: params.GroupId,
                        CycleType: {$in: [
                            FeedbackEnums.CycleType.Request,
                            FeedbackEnums.CycleType.Give,
                            FeedbackEnums.CycleType.EvaluateOthers
                        ]},
                        Status: {$in: [
                            FeedbackEnums.SessionStatus.Requesting,
                            FeedbackEnums.SessionStatus.NotStarted,
                            FeedbackEnums.SessionStatus.InProgress]},
                        Participants: {
                            $elemMatch: {
                                ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                                MemberId: params.MemberId
                            }
                        }
                    }, {
                        GroupId: params.GroupId,
                        CycleType: FeedbackEnums.CycleType.EvaluateOthers,
                        Status: {$in: [
                            FeedbackEnums.SessionStatus.Requesting,
                            FeedbackEnums.SessionStatus.NotStarted,
                            FeedbackEnums.SessionStatus.Submitted,
                            FeedbackEnums.SessionStatus.InProgress]},
                        Participants: {
                            $elemMatch: {
                                ParticipantType: FeedbackEnums.SessionParticipantType.Requester,
                                MemberId: params.MemberId
                            }
                        }
                    }
                ]
            };
        }
        function buildCheckinDashboardQuery(params) {
            var statusMap = {
                Completed: [FeedbackEnums.SessionStatus.Completed],
                NeedsYourAction: [FeedbackEnums.SessionStatus.Submitted, FeedbackEnums.SessionStatus.PendingSignOff],
                WaitingOnEmployee: [
                    FeedbackEnums.SessionStatus.NotStarted,
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Overdue,
                    FeedbackEnums.SessionStatus.PendingSignOff],
                Archived: [FeedbackEnums.SessionStatus.Archived, FeedbackEnums.SessionStatus.Expired]
            },
                statusList = [
                    FeedbackEnums.SessionStatus.Completed,
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.NotStarted,
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Overdue,
                    FeedbackEnums.SessionStatus.PendingSignOff,
                    FeedbackEnums.SessionStatus.Archived,
                    FeedbackEnums.SessionStatus.Expired
                ],
                query = {
                    GroupId: params.GroupId,
                    CycleType: FeedbackEnums.CycleType.SelfEvaluation,
                    Status: {$in: statusMap[params.Status] || statusList},
                    $and: [
                        {Participants: {
                            $elemMatch: {
                                ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                                MemberId: { $in: params.MemberIds},
                                DepartmentId: params.DepartmentId || {$exists: true}
                            }
                        }},
                        {Participants: {
                            $elemMatch: {
                                ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                                MemberId: params.MemberId
                            }
                        }}
                    ]
                };
            if (params.CycleId) {
                query.CycleId = params.CycleId;
            }
            return query;
        }
        this.CreateSessionForInitiator = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                InitiatorId: params.Initiator.hgId,
                Participants: {
                    $elemMatch: {
                        MemberId: params.Initiator.MemberId,
                        ParticipantType: {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]}
                    }
                },
                Status: {$in: [FeedbackEnums.SessionStatus.Requesting, FeedbackEnums.SessionStatus.NotStarted, FeedbackEnums.SessionStatus.InProgress, FeedbackEnums.SessionStatus.Overdue, FeedbackEnums.SessionStatus.Submitted, FeedbackEnums.SessionStatus.PendingSignOff]}
            }, function (error, exitingSession) {
                if (error) {
                    return callback(error);
                }
                if (exitingSession) {
                    return callback("fbs.int.sae");
                }
                var session = new EntityCache.FeedbackSession({
                        hgId: guid.v1(),
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId,
                        CycleId: params.Initiator.CycleId,
                        InitiatorId: params.Initiator.hgId,
                        ClusterId: params.Initiator.ClusterId,
                        CycleTitle: params.Initiator.CycleTitle,
                        CycleDescription: params.Cycle.Description,
                        CycleType: params.Cycle.Type,
                        Card: params.Card,
                        Note: params.Cycle.Note,
                        GroupId: params.GroupId,
                        Participants: params.Participants,
                        Status: FeedbackEnums.SessionStatus.NotStarted,
                        ShowManagerNotes: params.Cycle.ShowManagerNotes
                    });
                session.save(callback);
            });
        };
        this.PushGoalInOneSession = function (params, callback) {
            var goal = params.Goal,
                session = params.Session,
                card = session.Card,
                updatedSections = [],
                i,
                len = card.Sections.length - 1,
                curSection,
                nextSection,
                pushGoal = function () {
                    var newQuestion;
                    if (nextSection && curSection.OriginalId === nextSection.OriginalId) {
                        updatedSections.push(curSection);
                        return;
                    }
                    //now curSection is the for the last goal of the cycle
                    if (!curSection.GoalId) {//there is no existing goal for the cycle
                        curSection.GoalId = goal.hgId;
                        updatedSections.push(curSection);
                        return;
                    }
                    updatedSections.push(curSection);
                    //there has been existing goal in the cycle, create a new section and push to updatedSections
                    updatedSections.push({
                        OriginalId: curSection.hgId,
                        QuestionForEachGoal: curSection.QuestionForEachGoal,
                        hgId: guid.v1(),
                        Description: curSection.Description,
                        Type: curSection.Type,
                        Title: curSection.Title,
                        GoalCycleId: curSection.GoalCycleId,
                        GoalId: goal.hgId,
                        AllowSkipGoals: curSection.AllowSkipGoals,
                        StartDate: curSection.StartDate,
                        EndDate: curSection.EndDate,
                        Questions: curSection.Questions.map(function (q) {
                            newQuestion = new EntityCache.FeedbackQuestionAnswer(q);
                            newQuestion.OriginalId = q.hgId;
                            newQuestion.hgId = guid.v1();
                            newQuestion.Comment = "";
                            newQuestion.Answers = [];
                            newQuestion.ManagerNotes = [];
                            return newQuestion;
                        })
                    });
                },
                processGoal = function () {
                    if ((curSection.Type === FeedbackEnums.SectionType.CycleGoal && goal.CycleId !== curSection.GoalCycleId) ||
                            (curSection.Type === FeedbackEnums.SectionType.AdhocGoal && (goal.CycleId || goal.CreatedDate < curSection.StartDate || goal.CreatedDate > curSection.EndDate))) {
                        return updatedSections.push(curSection);
                    }
                    pushGoal();
                },
                processCurNextSection = function () {
                    if ([FeedbackEnums.SectionType.Generic, FeedbackEnums.SectionType.Recognition].indexOf(curSection.Type) > -1 ||
                            !curSection.QuestionForEachGoal) {
                        updatedSections.push(curSection);
                    } else {
                        processGoal();
                    }
                };
            for (i = 0; i <= len; i += 1) {
                curSection = card.Sections[i];
                nextSection = card.Sections[i + 1] || null;
                processCurNextSection();
            }
            if (updatedSections.length < card.Sections.length) {
                return callback();
            }
            card.Sections = updatedSections;
            session.markModified('Card.Sections');
            session.save(callback);
        };
        this.GetLastCheckInDates = function (params, callback) {
            var subjectCheckInDate = {};
            EntityCache.FeedbackSession.find({
                CycleType: FeedbackEnums.CycleType.ManagerCheckIn,
                GroupId: params.GroupId,
                Status: {$in: [
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.Completed
                ]},
                Participants: {
                    $elemMatch: {
                        MemberId: {$in: params.MemberIds},
                        ParticipantType: FeedbackEnums.SessionParticipantType.Subject
                    }
                }
            }, function (error, sessions) {
                if (error) {
                    return callback(error);
                }
                sessions.forEach(function (session) {
                    var subject = session.Participants.find(function (p) {
                            return p.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
                        }),
                        getSessionCreatedDate = function (value) {
                            return value > session.CreatedDate ? value : session.CreatedDate;
                        };
                    if (subject) {
                        subjectCheckInDate[subject.MemberId] = !subjectCheckInDate[subject.MemberId] ? session.CreatedDate : getSessionCreatedDate(subjectCheckInDate[subject.MemberId]);
                    }
                });
                callback(null, subjectCheckInDate);
            });
        };

        this.ManagerCheckIn = function (params, callback) {
            var session = new EntityCache.FeedbackSession({
                    hgId: guid.v1(),
                    CreatedBy: params.UserId,
                    ModifiedBy: params.UserId,
                    CycleId: params.CycleId,
                    InitiatorId: params.Initiator.hgId,
                    ClusterId: params.Initiator.ClusterId,
                    RequestNote: params.RequestNote,
                    CycleTitle: params.CycleTitle,
                    CycleType: params.CycleType,
                    CycleDescription: params.CycleDescription,
                    Card: params.Card,
                    GroupId: params.GroupId,
                    Status: FeedbackEnums.SessionStatus.Submitted
                });
            session.Participants.push({
                ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                MemberId: params.CheckedMember.hgId,
                UserId: params.CheckedMember.UserId,
                FullName: params.CheckedMember.FullName,
                Status: FeedbackEnums.SessionParticipantStatus.Closed,
                Role: params.CheckedMember.RolesInGroup[0],
                EmployeeId: params.CheckedMember.EmployeeId,
                DepartmentName: params.CheckedMember.GroupDepartmentName,
                DepartmentId: params.CheckedMember.GroupDepartmentId,
                LocationName: params.CheckedMember.Location && params.CheckedMember.Location.Name ? params.CheckedMember.Location.Name : '',
                LocationId: params.CheckedMember.Location && params.CheckedMember.Location.hgId ? params.CheckedMember.Location.hgId : ''
            });
            session.Participants.push({
                ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                MemberId: params.Initiator.MemberId,
                UserId: params.Initiator.AvatarId,
                FullName: params.Initiator.Name,
                Status: FeedbackEnums.SessionParticipantStatus.Submitted,
                Role: params.Initiator.Role,
                DepartmentName: params.Initiator.DepartmentName,
                DepartmentId: params.Initiator.DepartmentId,
                LocationName: params.Initiator.LocationName,
                LocationId: params.Initiator.LocationId,
                EmployeeId: params.Initiator.EmployeeId
            });
            session.save(callback);
        };

        this.RequestSession = function (params, callback) {
            var session = new EntityCache.FeedbackSession({
                RequestId: params.RequestId,
                hgId: guid.v1(),
                CreatedBy: params.UserId,
                ModifiedBy: params.UserId,
                CycleId: params.CycleId,
                InitiatorId: params.Initiator.hgId,
                ClusterId: params.Initiator.ClusterId,
                RequestNote: params.RequestNote,
                CycleTitle: params.CycleTitle,
                CycleType: params.CycleType,
                CycleDescription: params.CycleDescription,
                ExpirationDate: Date.now() + params.ExpireRequestDays * ConstantEnums.MILLI_SECONDS_PER_DAY,
                Card: params.Card,
                GroupId: params.GroupId
            });
            if (session.CycleType === FeedbackEnums.CardType.EvaluateOthers) {
                session.Participants.push({
                    ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                    MemberId: params.ReviewSubject.hgId,
                    UserId: params.ReviewSubject.UserId,
                    FullName: params.ReviewSubject.FullName,
                    Status: FeedbackEnums.SessionParticipantStatus.NotApplicable,
                    Role: params.ReviewSubject.RolesInGroup,
                    DepartmentName: params.ReviewSubject.GroupDepartmentName,
                    DepartmentId: params.ReviewSubject.GroupDepartmentId,
                    LocationName: params.ReviewSubject.Location ? params.ReviewSubject.Location.Name : '',
                    LocationId: params.ReviewSubject.Location ? params.ReviewSubject.Location.hgId : '',
                    EmployeeId: params.ReviewSubject.EmployeeId
                });
            }
            session.Participants.push({
                ParticipantType: session.CycleType === FeedbackEnums.CardType.Request ? FeedbackEnums.SessionParticipantType.Subject : FeedbackEnums.SessionParticipantType.Requester,
                MemberId: params.Initiator.MemberId,
                UserId: params.Initiator.AvatarId,
                FullName: params.Initiator.Name,
                Status: FeedbackEnums.SessionParticipantStatus.Requesting,
                Role: params.Initiator.Role,
                DepartmentName: params.Initiator.DepartmentName,
                DepartmentId: params.Initiator.DepartmentId,
                LocationName: params.Initiator.LocationName,
                LocationId: params.Initiator.LocationId,
                EmployeeId: params.Initiator.EmployeeId
            });
            session.Participants.push({
                ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                MemberId: params.ReviewerMember.hgId,
                UserId: params.ReviewerMember.UserId,
                FullName: params.ReviewerMember.FullName,
                Status: FeedbackEnums.SessionParticipantStatus.RequestPending,
                Role: params.ReviewerMember.RolesInGroup[0],
                DepartmentName: params.ReviewerMember.GroupDepartmentName,
                DepartmentId: params.ReviewerMember.GroupDepartmentId,
                LocationName: params.ReviewerMember.Location && params.ReviewerMember.Location.Name ? params.ReviewerMember.Location.Name : '',
                LocationId: params.ReviewerMember.Location && params.ReviewerMember.Location.hgId ? params.ReviewerMember.Location.hgId : '',
                EmployeeId: params.ReviewerMember.EmployeeId
            });
            session.save(callback);
        };

        this.LoadRequestsToExpire = function (params, callback) {
            EntityCache.FeedbackSession.find({
                Status: FeedbackEnums.SessionStatus.Requesting,
                ExpirationDate: {$lt: Date.now()}
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.ExpireRequest = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                session.Status = FeedbackEnums.SessionStatus.Expired;
                session.Participants.filter(function (p) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                })[0].Status = FeedbackEnums.SessionParticipantStatus.Expired;
                session.save(callback);
            });
        };

        this.LoadExpiringRequestsGroupByReviewer = function (params, callback) {
            EntityCache.FeedbackSession.find({
                Status: FeedbackEnums.SessionStatus.Requesting,
                ExpirationDate: {
                    $gt: Date.now() + 2 * ConstantEnums.MILLI_SECONDS_PER_DAY,
                    $lt: Date.now() + 3 * ConstantEnums.MILLI_SECONDS_PER_DAY
                }
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.ImportCardToSession = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                session.Card = params.Card;
                session.save(callback);
            });
        };

        this.AcceptRequest = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                if (session.Status !== FeedbackEnums.SessionStatus.Requesting) {
                    return callback("fbs.int.sno");
                }
                var meAsReviewer = session.Participants.filter(function (participant) {
                        return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer && participant.MemberId === params.MemberId;
                    });
                if (!meAsReviewer.length) {
                    return callback("fbs.int.nrt");
                }
                session.Status = FeedbackEnums.SessionStatus.InProgress;
                meAsReviewer[0].Status = FeedbackEnums.SessionParticipantStatus.Accepted;
                session.save(callback);
            });
        };

        this.SignOffCheckIn = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId,
                CycleType: FeedbackEnums.CycleType.SelfEvaluation,
                Status: FeedbackEnums.SessionStatus.PendingSignOff
            }, function (error, session) {
                var meParticipant,
                    otherReviewers = [];
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                meParticipant = session.Participants.find(function (participant) {
                    return participant.MemberId === params.MemberId;
                });
                if (!meParticipant || !meParticipant.NeedsSignOff) {
                    return callback("fbs.int.srt");
                }
                if (meParticipant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer) {
                    otherReviewers = session.Participants.filter(function (participant) {
                        return participant.MemberId !== params.MemberId &&
                                participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer &&
                                participant.NeedsSignOff;
                    });
                }
                otherReviewers.forEach(function (otherReviewer) {
                    otherReviewer.Status = FeedbackEnums.SessionParticipantStatus.SignedOff;
                });
                meParticipant.Status = FeedbackEnums.SessionParticipantStatus.SignedOff;
                if (!session.Participants.some(function (participant) {
                        return participant.NeedsSignOff && participant.Status !== FeedbackEnums.SessionParticipantStatus.SignedOff;
                    })) {
                    session.Status = FeedbackEnums.SessionStatus.Completed;
                    session.CompletedDate = Date.now();
                }
                session.ModifiedBy = params.UserId;
                session.save(callback);
            });
        };

        this.ArchiveSession = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                var participant = session.Participants.find(function (participant) {
                        return participant.MemberId === params.MemberId;
                    });
                if (participant && participant.ParticipantType !== FeedbackEnums.SessionParticipantType.Subject && session.CycleType !== FeedbackEnums.CycleType.Give) {
                    return callback("fbs.int.srt");
                }
                if (participant && participant.ParticipantType !== FeedbackEnums.SessionParticipantType.Reviewer && session.CycleType === FeedbackEnums.CycleType.Give) {
                    return callback("fbs.int.srt");
                }
                session.ModifiedBy = params.UserId;
                session.PrevStatus = session.Status;
                session.ArchiveDate = Date.now();
                session.Status = FeedbackEnums.SessionStatus.Archived;
                session.save(callback);
            });
        };

        this.UnarchiveSession = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId,
                Status: FeedbackEnums.SessionStatus.Archived
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                var participant = session.Participants.find(function (participant) {
                        return participant.MemberId === params.MemberId;
                    });
                if (participant && participant.ParticipantType !== FeedbackEnums.SessionParticipantType.Subject && session.CycleType !== FeedbackEnums.CycleType.Give) {
                    return callback("fbs.int.srt");
                }
                if (participant && participant.ParticipantType !== FeedbackEnums.SessionParticipantType.Reviewer && session.CycleType === FeedbackEnums.CycleType.Give) {
                    return callback("fbs.int.srt");
                }
                session.ModifiedBy = params.UserId;
                session.Status = FeedbackEnums.SessionStatus.InProgress;
                session.save(callback);
            });
        };

        this.DeclineRequest = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                if (session.Status !== FeedbackEnums.SessionStatus.Requesting) {
                    return callback("fbs.int.rgo");
                }
                var meAsReviewer = session.Participants.filter(function (participant) {
                    return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer && participant.MemberId === params.MemberId;
                });
                if (!meAsReviewer.length) {
                    return callback("fbs.int.nrt");
                }
                session.DeclinedDate = Date.now();
                session.DeclineNote = params.DeclineNote;
                session.Status = FeedbackEnums.SessionStatus.Declined;
                meAsReviewer[0].Status = FeedbackEnums.SessionParticipantStatus.Declined;
                session.save(callback);
            });
        };

        this.SeeSubjectRating = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }

                var meAsReviewer = session.Participants.filter(function (participant) {
                        return participant.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer && participant.MemberId === params.MemberId;
                    });
                if (!meAsReviewer.length) {
                    return callback("fbs.int.nrt");
                }
                session.Status = FeedbackEnums.SessionStatus.Completed;
                session.ModifiedBy = params.UserId;
                session.save(callback);
            });
        };

        this.RateReceivedSession = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                if (session.Status !== FeedbackEnums.SessionStatus.Submitted) {
                    return callback("fbs.int.sbt");
                }
                var meAsSubject = session.Participants.filter(function (participant) {
                        return FeedbackEnums.SessionParticipantType.Subject === participant.ParticipantType && participant.MemberId === params.MemberId;
                    });
                if (!meAsSubject.length) {
                    return callback("fbs.int.srt");
                }
                if (Object.keys(FeedbackEnums.SubjectRating).indexOf(params.SubjectRating) === -1) {
                    return callback("fbs.int.rvi");
                }
                session.SubjectRating = params.SubjectRating;
                if (params.Rate) {
                    session.Status = FeedbackEnums.SessionStatus.Completed;
                    session.CompletedDate = Date.now();
                }
                session.RatingNote = params.RatingNote;
                session.ModifiedBy = params.UserId;
                session.save(callback);
            });
        };

        this.UpdateSessionStatus = function (params, callback) {
            EntityCache.FeedbackSession.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, callback);
        };

        this.CompletedSessionsStatusByIds = function (params, callback) {
            EntityCache.FeedbackSession.update({
                CycleId: params.CycleId,
                GroupId: params.GroupId,
                hgId: {$in: params.SessionIds}
            }, {
                $set: {
                    Status: FeedbackEnums.SessionStatus.Completed,
                    CompletedDate: Date.now(),
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };

        this.UpdateSessionsStatusByIds = function (params, callback) {
            EntityCache.FeedbackSession.update({
                CycleId: params.CycleId,
                GroupId: params.GroupId,
                hgId: {$in: params.SessionIds}
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };

        this.GetSessionById = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                hgId: params.SessionId,
                GroupId: params.GroupId
            }, callback);
        };

        this.SaveManagerQuestionNotes = function (params, callback) {
            var populateManagerNotesForQuestion = function (params) {
                var currentNoteItem;
                params.QuestionInDb.ManagerNotes = params.QuestionInDb.ManagerNotes || [];
                if (!params.Notes) {
                    params.QuestionInDb.ManagerNotes = params.QuestionInDb.ManagerNotes.filter(function (item) {
                        return item.MemberId !== params.MemberId;
                    });
                } else {
                    currentNoteItem = params.QuestionInDb.ManagerNotes.filter(function (item) {
                        return item.MemberId === params.MemberId;
                    });
                    if (currentNoteItem.length) {
                        currentNoteItem[0].Notes = params.Notes;
                    } else {
                        params.QuestionInDb.ManagerNotes.push({
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            Notes: params.Notes,
                            FullName: params.FullName
                        });
                    }
                }
            };
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                params.Questions.forEach(function (questionInPayload) {
                    var questionInDb = findQuestionInCard(session, questionInPayload);
                    if (questionInDb) {
                        populateManagerNotesForQuestion({
                            QuestionInDb: questionInDb,
                            Notes: questionInPayload.Notes,
                            MemberId: params.MemberId,
                            UserId: params.UserId,
                            FullName: params.FullName
                        });
                    }
                });
                session.ModifiedBy = params.UserId;
                session.markModified('Card.Sections');
                session.markModified('Card.Sections.Questions');
                session.markModified('Card.Sections.Questions.ManagerNotes');
                session.save(callback);
            });
        };

        this.SubmitSession = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId
            }, function (error, session) {
                var reviewer,
                    subject;
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                reviewer = session.Participants.filter(function (p) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer
                        && p.MemberId === params.MemberId;
                });
                subject = session.Participants.filter(function (p) {
                    return [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(p.ParticipantType) !== -1
                        && p.MemberId === params.MemberId;
                });
                if ([FeedbackEnums.CycleType.EvaluateOthers, FeedbackEnums.CycleType.Request, FeedbackEnums.CycleType.Give].indexOf(params.CycleType) !== -1 && !reviewer.length) {//fo request feedback, you need to be reviwer to answer questions
                    return callback("fbs.int.naf");
                }
                if (params.CycleType === FeedbackEnums.CycleType.SelfEvaluation && !subject.length) {//for self evaluation, you need to be subject to answer questions
                    return callback("fbs.int.naf");
                }
                if (subject.length) {
                    subject[0].Status = FeedbackEnums.SessionParticipantStatus.Submitted;
                    subject[0].SubmittedDate = Date.now();
                }
                if (reviewer.length) {
                    reviewer[0].Status = FeedbackEnums.SessionParticipantStatus.Submitted;
                    reviewer[0].SubmittedDate = Date.now();
                }
                session.Status = FeedbackEnums.SessionStatus.Submitted;
                session.ModifiedBy = params.UserId;
                session.save(callback);
            });
        };

        this.AnswerAndSave = function (params, callback) {
            EntityCache.FeedbackSession.findOne({
                hgId: params.SessionId,
                GroupId: params.GroupId
            }, function (error, session) {
                var populateAnswerForQuestion = function (pParams) {
                        var existAnswer = pParams.QuestionInDb.Answers.filter(function (answer) {
                            return answer.MemberId === params.MemberId;
                        });
                        if (existAnswer.length) {
                            existAnswer[0].Text = pParams.Answer.Text;
                            existAnswer[0].SelectedValues = pParams.Answer.SelectedValues;
                        } else {
                            pParams.QuestionInDb.Answers.push({
                                MemberId: params.MemberId,
                                UserId: params.UserId,
                                MemberName: params.FullName,
                                PeopleType: FeedbackEnums.SessionParticipantType.Reviewer,
                                Text: pParams.Answer.Text,
                                SelectedValues: pParams.Answer.SelectedValues
                            });
                        }
                    },
                    reviewer,
                    subject,
                    section;
                if (error || !session) {
                    return callback("fbs.int.els");
                }
                if (session.CycleType !== params.CycleType) {
                    return callback("fbs.int.ict");
                }
                if ([FeedbackEnums.CycleType.TalentInsight, FeedbackEnums.CycleType.Give].indexOf(session.CycleType) === -1 &&
                        [FeedbackEnums.SessionStatus.NotStarted, FeedbackEnums.SessionStatus.InProgress].indexOf(session.Status) === -1) {
                    return callback("fbs.int.ipt");
                }
                reviewer = session.Participants.filter(function (p) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer
                        && p.MemberId === params.MemberId;
                });
                subject = session.Participants.filter(function (p) {
                    return [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(p.ParticipantType) !== -1
                        && p.MemberId === params.MemberId;
                });
                //for request and succession feedback, you need to be reviwer to answer questions
                if ([FeedbackEnums.CycleType.Request, FeedbackEnums.CycleType.TalentInsight].indexOf(params.CycleType) > -1 && !reviewer.length) {
                    return callback("fbs.int.naf");
                }
                if (params.CycleType === FeedbackEnums.CycleType.SelfEvaluation && !subject.length) {//for self evaluation, you need to be subject to answer questions
                    return callback("fbs.int.naf");
                }
                if (subject.length) {
                    subject[0].Status = FeedbackEnums.SessionParticipantStatus.InProgress;
                }
                if (reviewer.length) {
                    reviewer[0].Status = FeedbackEnums.SessionParticipantStatus.InProgress;
                }
                if (params.SectionId) {
                    section = session.Card.Sections.filter(function (section) {
                        return section.hgId === params.SectionId;
                    });
                    if (section.length) {
                        section[0].AllowSectionToBeSkipped = params.SkipSection;
                    }
                }
                params.Questions.forEach(function (questionInPayload) {
                    var questionInDb = findQuestionInCard(session, questionInPayload);
                    if (questionInDb) {
                        //note: may need to add validation by answer type and value
                        populateAnswerForQuestion({
                            QuestionInDb: questionInDb,
                            Answer: questionInPayload.Answer
                        });
                        // questionInDb.Answer = questionInPayload.Answer;
                    }
                });
                session.Status = FeedbackEnums.SessionStatus.InProgress;
                session.ModifiedBy = params.UserId;
                session.markModified('Card.Sections');
                session.markModified('Card.Sections.Questions');
                session.markModified('Card.Sections.Questions.Answers');
                session.save(callback);
            });
        };

        this.ArchivePendingRequestsBySubjectMemberId = function (params, callback) {
            EntityCache.FeedbackSession.find({
                GroupId: params.GroupId,
                Status: FeedbackEnums.SessionStatus.Requesting,
                Participants: {
                    $elemMatch: {
                        ParticipantType: {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]},
                        MemberId: params.MemberId
                    }
                }
            }, function (error, sessions) {
                if (error) {
                    return callback(error);
                }
                async.each(sessions, function (session, aCallback) {
                    session.Status = FeedbackEnums.SessionStatus.Archived;
                    session.Participants.filter(function (p) {
                        return [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(p.ParticipantType) !== -1
                            && p.MemberId === params.MemberId;
                    })[0].Status = FeedbackEnums.SessionParticipantStatus.Archived;
                    session.save(aCallback);
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, sessions);
                });
            });
        };

        this.CloseSessionsBySubjectMemberId = function (params, callback) {
            EntityCache.FeedbackSession.find({
                GroupId: params.GroupId,
                Status: {$in: [
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.Completed
                ]},
                Participants: {
                    $elemMatch: {
                        ParticipantType: {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]},
                        MemberId: params.MemberId
                    }
                }
            }, function (error, sessions) {
                if (error) {
                    return callback(error);
                }
                async.each(sessions, function (session, aCallback) {
                    session.Status = FeedbackEnums.SessionStatus.Closed;
                    session.Participants.filter(function (p) {
                        return [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester].indexOf(p.ParticipantType) !== -1
                            && p.MemberId === params.MemberId;
                    })[0].Status = FeedbackEnums.SessionParticipantStatus.Closed;
                    session.save(aCallback);
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, sessions);
                });
            });
        };

        this.ArchivePendingRequestsByReviewerMemberId = function (params, callback) {
            EntityCache.FeedbackSession.find({
                Status: FeedbackEnums.SessionStatus.Requesting,
                Participants: {
                    $elemMatch: {
                        ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                        MemberId: params.MemberId
                    }
                }
            }, function (error, sessions) {
                if (error) {
                    return callback(error);
                }
                async.each(sessions, function (session, aCallback) {
                    session.Status = FeedbackEnums.SessionStatus.Archived;
                    session.Participants.filter(function (p) {
                        return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer
                            && p.MemberId === params.MemberId;
                    })[0].Status = FeedbackEnums.SessionParticipantStatus.Archived;
                    session.save(aCallback);
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, sessions);
                });
            });
        };


        this.CloseSessionsByReviewerMemberId = function (params, callback) {
            EntityCache.FeedbackSession.find({
                Status: {$in: [
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.Completed
                ]},
                Participants: {
                    $elemMatch: {
                        ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                        MemberId: params.MemberId
                    }
                }
            }, function (error, sessions) {
                if (error) {
                    return callback(error);
                }
                async.each(sessions, function (session, aCallback) {
                    session.Status = FeedbackEnums.SessionStatus.Closed;
                    session.Participants.filter(function (p) {
                        return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer
                            && p.MemberId === params.MemberId;
                    })[0].Status = FeedbackEnums.SessionParticipantStatus.Closed;
                    session.save(aCallback);
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, sessions);
                });
            });
        };

        this.GetCheckInHistory = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                CycleType: FeedbackEnums.CycleType.ManagerCheckIn,
                Status: {$in: [
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.Completed,
                    FeedbackEnums.SessionStatus.Closed
                ]},
                Participants: {
                    $elemMatch: {
                        ParticipantType: {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]},
                        MemberId: params.ViewedMemberId
                    }
                }
            };
            if (params.SearchTerm) {
                condition["Participants.FullName"] = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.FeedbackSession.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };

        this.GetSessionsByIds = function (params, callback) {
            EntityCache.FeedbackSession.find({
                GroupId: params.GroupId,
                hgId: {
                    $in: params.SessionIds
                }
            }, {}, {
                lean: true
            }, callback);
        };

        this.GetSessionsByCycleIdToArchiveBatch = function (params, callback) {
            EntityCache.FeedbackSession.find({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: [
                    FeedbackEnums.SessionStatus.Requesting,
                    FeedbackEnums.SessionStatus.Declined,
                    FeedbackEnums.SessionStatus.Expired,
                    FeedbackEnums.SessionStatus.NotStarted,
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.Completed,
                    FeedbackEnums.SessionStatus.Closed
                ]}
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };

        this.GetSessionsByCycleIdToCloseBatch = function (params, callback) {
            EntityCache.FeedbackSession.find({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: [
                    FeedbackEnums.SessionStatus.Requesting,
                    FeedbackEnums.SessionStatus.NotStarted,
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.Completed
                ]}
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };

        this.GetPendingTalentInsightIdCount = function (params, callback) {
            EntityCache.FeedbackSession.count({
                Status: {
                    $in: [
                        FeedbackEnums.SessionStatus.NotStarted,
                        FeedbackEnums.SessionStatus.InProgress
                    ]
                },
                InitiatorId: params.InitiatorId,
                GroupId: params.GroupId
            }, callback);
        };
        this.GetTalentInsightSession = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                InitiatorId: params.InitiatorId
            };
            if (params.Status) {
                query.Status = {$in: params.Status};
            }
            EntityCache.FeedbackSession.find(query)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };

        this.GetFeedbackForPDF = function (params, callback) {
            var feedbackQuery = {
                    CycleType: {$in: [FeedbackEnums.CycleType.Request, FeedbackEnums.CycleType.Give]},
                    Participants: {
                        $elemMatch: {
                            ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                            MemberId: params.MemberId
                        }
                    }
                },
                mainQuery = {
                    GroupId: params.GroupId,
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.SubjectRated,
                        FeedbackEnums.SessionStatus.Completed
                    ]},
                    ModifiedDate: {$gte: params.StartDate, $lte: params.EndDate}
                },
                condition,
                reviewer,
                aboutOthersQuery = {};

            if (params.AccessMode === Enums.ProfileAccess.User) {
                condition = Object.assign(mainQuery, feedbackQuery);
            } else if ([Enums.ProfileAccess.Admin, Enums.ProfileAccess.Manager].indexOf(params.AccessMode) > -1) {
                aboutOthersQuery = {
                    CycleType: FeedbackEnums.CycleType.EvaluateOthers,
                    Participants: {
                        $elemMatch: {
                            ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                            MemberId: params.MemberId
                        }
                    }
                };
                condition = Object.assign(mainQuery, {$or: [feedbackQuery, aboutOthersQuery]});
            }

            EntityCache.FeedbackSession.find(condition, params.Fields || {}, {
                lean: true,
                sort: {ModifiedDate: -1},
                skip: parseInt(params.Skip, 10) || 0,
                limit: parseInt(params.Take, 10) || 10
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data.filter(function (item) {
                    reviewer = item.Participants.find(function (p) {
                        return item.CycleType === FeedbackEnums.CycleType.EvaluateOthers ?
                                p.ParticipantType === FeedbackEnums.SessionParticipantType.Requester : p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                    });
                    return !item.Card.IsPrivate ||
                        params.AccessMode === Enums.ProfileAccess.Admin ||
                        (item.Card.IsPrivate &&
                            ((reviewer && reviewer.MemberId === params.ViewedMemberId && params.AccessMode === Enums.ProfileAccess.Manager) ||  params.AccessMode === Enums.ProfileAccess.User));
                }));
            });
        };
        this.GetCheckInInbox = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                CycleType: FeedbackEnums.CycleType.SelfEvaluation,
                $or: [{
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.NotStarted,
                        FeedbackEnums.SessionStatus.InProgress,
                        FeedbackEnums.SessionStatus.Overdue,
                        FeedbackEnums.SessionStatus.Submitted,
                        FeedbackEnums.SessionStatus.PendingSignOff]},
                    Participants: {
                        $elemMatch: {
                            ParticipantType: {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]},
                            MemberId: params.MemberId
                        }
                    }
                }, {
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.Submitted,
                        FeedbackEnums.SessionStatus.PendingSignOff]},
                    Participants: {
                        $elemMatch: {
                            ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                            MemberId: params.MemberId
                        }
                    }
                }]
            };
            if (params.SearchTerm) {
                condition = {
                    $and: [condition]
                };
                condition.$and.push({$or: [
                    { "Participants.FullName": {$regex: params.SearchTerm, $options: 'i'} },
                    { CycleTitle: {$regex: params.SearchTerm, $options: 'i'} }
                ]});
            }
            EntityCache.FeedbackSession.find(condition)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({ModifiedDate: -1})
                .exec(callback);
        };

        this.GetOutstandingCheckIns = function (params, callback) {
            EntityCache.FeedbackSession.find({
                GroupId: params.GroupId,
                CycleType: FeedbackEnums.CycleType.SelfEvaluation,
                Status: {$in: [
                    FeedbackEnums.SessionStatus.NotStarted,
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Overdue]},
                Participants: {
                    $elemMatch: {
                        ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                        MemberId: params.MemberId
                    }
                }
            }, callback);
        };

        this.GetDashboardCheckins = function (params, callback) {
            var columnsMap = {
                    OwnerName: 'Participants.FullName',
                    CycleTitle: 'CycleTitle',
                    Department: 'Participants.DepartmentName',
                    CreatedDate: 'CreatedDate',
                    Completed: 'Participants.SubmittedDate',
                    Submitted: 'Participants.SubmittedDate',
                    Due: 'Participants.DueDate',
                    Archived: 'ArchiveDate'
                },
                sort = {};
            sort[columnsMap[params.SortCol || columnsMap.CreatedDate]] = params.SortDir || -1;
            EntityCache.FeedbackSession
                .find(buildCheckinDashboardQuery(params))
                .skip(params.Skip || 0)
                .limit(params.Take || 0)
                .sort(sort)
                .exec(callback);
        };
        this.GetDashboardCheckinsCount = function (params, callback) {
            EntityCache.FeedbackSession.count(buildCheckinDashboardQuery(params), callback);
        };
        this.GetDashboardCheckinsStats = function (params, callback) {
            EntityCache.FeedbackSession.aggregate([
                {$match: buildCheckinDashboardQuery(params)},
                {$group: {
                    _id: {status: '$Status'},
                    p: { $push: {
                        memberId: '$Participants.MemberId',
                        participantType: '$Participants.ParticipantType',
                        participantStatus: '$Participants.Status',
                        signedOff: '$Participants.NeedsSignOff'
                    }},
                    count: {$sum: 1}
                }}
            ], callback);
        };
        this.GetCheckInCompleted = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    CycleType: FeedbackEnums.CycleType.SelfEvaluation,
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.Completed,
                        FeedbackEnums.SessionStatus.Closed,
                        FeedbackEnums.SessionStatus.Archived]},
                    Participants: {
                        $elemMatch: {
                            MemberId: params.MemberId
                        }
                    }
                };
            if (params.SearchTerm) {
                condition.$or = [
                    { "Participants.FullName": {$regex: params.SearchTerm, $options: 'i'} },
                    { CycleTitle: {$regex: params.SearchTerm, $options: 'i'} }
                ];
            }
            EntityCache.FeedbackSession.find(condition, params.Fields || {}, {lean: true})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({ModifiedDate: -1})
                .exec(callback);
        };

        this.GetCheckInForPDF = function (params, callback) {
            var condition = {
                    GroupId: params.GroupId,
                    CycleType: FeedbackEnums.CycleType.SelfEvaluation,
                    Status: FeedbackEnums.SessionStatus.Completed,
                    ModifiedDate: {$gte: params.StartDate, $lte: params.EndDate},
                    Participants: {
                        $elemMatch: {
                            ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                            MemberId: params.MemberId
                        }
                    }
                };
            EntityCache.FeedbackSession.find(condition, params.Fields || {}, {lean: true})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({ModifiedDate: -1})
                .exec(callback);
        };

        this.OverviewRequestComplete = function (params, callback) {
            async.parallel({
                aboutMe: function (fcallback) {
                    EntityCache.FeedbackSession.count({
                        GroupId: params.GroupId,
                        CycleType: {$in: [
                            FeedbackEnums.CycleType.Request,
                            FeedbackEnums.CycleType.Give
                        ]},
                        Status: {$in: [
                            FeedbackEnums.SessionStatus.Declined,
                            FeedbackEnums.SessionStatus.Expired,
                            FeedbackEnums.SessionStatus.Completed,
                            FeedbackEnums.SessionStatus.Closed]},
                        Participants: {
                            $elemMatch: {
                                ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                                MemberId: params.MemberId
                            }
                        }
                    }, fcallback);
                },
                aboutOthers: function (fcallback) {
                    EntityCache.FeedbackSession.count(getAboutOthersCompletedQuery(params), fcallback);
                }
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    ByMeCompleted: result.aboutMe,
                    ByOthersCompleted: result.aboutOthers
                });
            });
        };
        this.OverviewRequestInbox = function (params, callback) {
            async.parallel({
                aboutMe: function (fcallback) {
                    EntityCache.FeedbackSession.count({
                        GroupId: params.GroupId,
                        CycleType: {$in: [
                            FeedbackEnums.CycleType.Request,
                            FeedbackEnums.CycleType.Give
                        ]},
                        Participants: {
                            $elemMatch: {
                                ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                                MemberId: params.MemberId
                            }
                        },
                        $or: [{
                            CycleType: FeedbackEnums.CycleType.Request,
                            Status: {$in: [
                                FeedbackEnums.SessionStatus.Requesting,
                                FeedbackEnums.SessionStatus.NotStarted,
                                FeedbackEnums.SessionStatus.InProgress,
                                FeedbackEnums.SessionStatus.Submitted]}
                        }, {
                            CycleType: FeedbackEnums.CycleType.Give,
                            Status: {$in: [
                                FeedbackEnums.SessionStatus.Requesting,
                                FeedbackEnums.SessionStatus.NotStarted,
                                FeedbackEnums.SessionStatus.Submitted]}
                        }]
                    }, fcallback);
                },
                aboutOthers: function (fcallback) {
                    EntityCache.FeedbackSession.count(getAboutOthersInboxQuery(params), fcallback);
                }
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    ByMeInbox: result.aboutMe,
                    ByOthersInbox: result.aboutOthers
                });
            });
        };
        this.GetOverview = function (params, callback) {
            EntityCache.FeedbackSession.find({
                GroupId: params.GroupId,
                CycleType: {$in: [
                    FeedbackEnums.CycleType.Request,
                    FeedbackEnums.CycleType.SelfEvaluation,
                    FeedbackEnums.CycleType.Give
                ]},
                Status: {$in: [
                    FeedbackEnums.SessionStatus.Requesting,
                    FeedbackEnums.SessionStatus.Declined,
                    FeedbackEnums.SessionStatus.Expired,
                    FeedbackEnums.SessionStatus.NotStarted,
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Submitted,
                    FeedbackEnums.SessionStatus.Completed,
                    FeedbackEnums.SessionStatus.Closed]},
                'Participants.MemberId': params.MemberId
            }, function (error, sessions) {
                if (error) {
                    return callback(error);
                }
                var overview = {
                        ToReceive: 0,
                        Received: 0,
                        ArchivedReceive: 0,
                        ToGive: 0,
                        Gave: 0,
                        ArchivedGive: 0
                    },
                    bucketStatusMap = {
                        Request: {
                            Subject: {
                                Requesting: 'ToReceive',
                                InProgress: 'ToReceive',
                                Submitted: 'ToReceive',
                                Completed: 'Received',
                                Closed: 'Received',
                                Declined: 'ArchivedReceive',
                                Expired: 'ArchivedReceive'
                            },
                            Reviewer: {
                                InProgress: 'ToGive',
                                Requesting: 'ToGive',
                                Submitted: 'Gave',
                                Completed: 'Gave',
                                Closed: 'Gave',
                                Declined: 'ArchivedGive',
                                Expired: 'ArchivedGive'
                            }
                        },
                        SelfEvaluation: {
                            Subject: {
                                NotStarted: 'ToReceive',
                                InProgress: 'ToReceive',
                                Submitted: 'Received',
                                Completed: 'Received',
                                Closed: 'Received',
                                Declined: 'ArchivedReceive',
                                Expired: 'ArchivedReceive'
                            },
                            Reviewer: {
                                Declined: 'ArchivedGive',
                                Expired: 'ArchivedGive'
                            }
                        }
                    },
                    resolveSessionBucket = function (session) {
                        var participant = session.Participants.find(function (p) {
                                return p.MemberId === params.MemberId;
                            });
                        if (!participant) {
                            return;
                        }
                        if (bucketStatusMap[session.CycleType] && bucketStatusMap[session.CycleType][participant.ParticipantType]) {
                            return bucketStatusMap[session.CycleType][participant.ParticipantType][session.Status];
                        }
                    };
                sessions.forEach(function (session) {
                    var bucket = resolveSessionBucket(session);
                    if (bucket) {
                        overview[bucket] += 1;
                    }
                });
                callback(null, overview);
            });
        };

        this.GetActiveSessionParticipantsByCycleId = function (params, callback) {
            EntityCache.FeedbackSession.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    CycleId: params.CycleId,
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.Requesting,
                        FeedbackEnums.SessionStatus.InProgress,
                        FeedbackEnums.SessionStatus.NotStarted,
                        FeedbackEnums.SessionStatus.Submitted
                    ]}
                }},
                {$unwind: "$Participants"},
                {$match: {
                    $or: [{
                        "Participants.ParticipantType": FeedbackEnums.SessionParticipantType.Reviewer,
                        "Participants.Status": FeedbackEnums.SessionParticipantStatus.RequestPending,
                        Status: FeedbackEnums.SessionStatus.Requesting
                    }, {
                        "Participants.ParticipantType": {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]},
                        "Participants.Status": FeedbackEnums.SessionParticipantStatus.Requesting,
                        Status: FeedbackEnums.SessionStatus.Submitted
                    }, {
                        "Participants.ParticipantType": FeedbackEnums.SessionParticipantType.Reviewer,
                        "Participants.Status": FeedbackEnums.SessionParticipantStatus.Accepted,
                        Status: FeedbackEnums.SessionStatus.InProgress
                    }, {//Self Eval
                        "Participants.ParticipantType": {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]},
                        "Participants.Status": FeedbackEnums.SessionParticipantStatus.NotStarted,
                        Status: FeedbackEnums.SessionStatus.NotStarted
                    },  {//Self Eval
                        "Participants.ParticipantType": {$in: [FeedbackEnums.SessionParticipantType.Subject, FeedbackEnums.SessionParticipantType.Requester]},
                        "Participants.Status": FeedbackEnums.SessionParticipantStatus.NotStarted,
                        Status: FeedbackEnums.SessionStatus.InProgress
                    }]
                }},
                {$group: {
                    _id: null,
                    p: { $push: {
                        hgId: "$hgId",
                        UserId: "$Participants.UserId"
                    }}
                }}
            ], callback);
        };

        this.GetActiveSessionUserIdsByCycleId = function (params, callback) {
            EntityCache.FeedbackSession.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    CycleId: params.CycleId,
                    Status: {$in: [
                        FeedbackEnums.SessionStatus.NotStarted,
                        FeedbackEnums.SessionStatus.Requesting,
                        FeedbackEnums.SessionStatus.InProgress
                    ]}
                }},
                {$unwind: "$Participants"},
                {$match: { "Participants.Status": {$in: [
                    FeedbackEnums.SessionStatus.Requesting,
                    FeedbackEnums.SessionStatus.RequestPending,
                    FeedbackEnums.SessionStatus.Accepted,
                    FeedbackEnums.SessionStatus.Submitted
                ]}}},
                {$group: {
                    _id: "$Participants.UserId"
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data.map(function (item) {
                    return item._id;
                }));
            });
        };
        this.CloseActiveSessionsByCycleId = function (params, callback) {
            EntityCache.FeedbackSession.update({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                Status: {$in: [
                    FeedbackEnums.SessionStatus.InProgress,
                    FeedbackEnums.SessionStatus.Requesting]}
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };
        this.ArchiveSessionsByCycleId = function (params, callback) {
            EntityCache.FeedbackSession.update({
                GroupId: params.GroupId,
                CycleId: params.CycleId
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };

        this.GetDeclinedSessionsByRequestId = function (params, callback) {

            EntityCache.FeedbackSession.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    RequestId: params.RequestId,
                    Status: FeedbackEnums.SessionStatus.Declined
                }},
                {$unwind: "$Participants"},
                {$match: { "Participants.ParticipantType": FeedbackEnums.SessionParticipantType.Reviewer}},
                {$project: {
                    _id: false,
                    DeclineNote: "$DeclineNote",
                    FullName: "$Participants.FullName"
                }}
            ], callback);
        };

        this.UpdateManagerViewDate = function (params) {
            EntityCache.FeedbackSession.findOne({
                GroupId: params.GroupId,
                hgId: params.SessionId,
                'Participants': {
                    $elemMatch: {
                        MemberId: params.MemberId,
                        Status: {
                            $nin: FeedbackEnums.SessionParticipantStatus.Viewed
                        }
                    }
                }
            }, function (err, data) {
                if (err || !data) {
                    return;
                }
                var participant = data.Participants.find(function (participant) {
                    return participant.MemberId === params.MemberId;
                });
                if (participant.Status !== FeedbackEnums.SessionParticipantStatus.Viewed) {
                    participant.Status = FeedbackEnums.SessionParticipantStatus.Viewed;
                    participant.ViewedDate = Date.now();
                    data.save(function (err) {
                        if (err) {
                            HgLog.warn('Unable to save manager view date.');
                            HgLog.warn(err);
                        }
                    });
                }
            });
        };

        this.StartGiveSession = function (params, callback) {
            var session = new EntityCache.FeedbackSession({
                hgId: guid.v1(),
                RequestId: params.RequestId,
                CreatedBy: params.Reviewer.AvatarId,
                ModifiedBy: params.Reviewer.AvatarId,
                CycleId: params.CycleId,
                InitiatorId: params.Reviewer.AvatarId,
                ClusterId: params.Reviewer.ClusterId,
                RequestNote: params.RequestNote,
                Status: FeedbackEnums.SessionStatus.InProgress,
                CycleTitle: params.CycleTitle,
                Participants: [{
                    ParticipantType: FeedbackEnums.SessionParticipantType.Subject,
                    MemberId: params.Subject.hgId,
                    UserId: params.Subject.UserId,
                    FullName: params.Subject.FullName,
                    Status: FeedbackEnums.SessionParticipantStatus.InProgress,
                    Role: params.Subject.RolesInGroup[0],
                    DepartmentName: params.Subject.GroupDepartmentName,
                    DepartmentId: params.Subject.GroupDepartmentId,
                    LocationName: params.Subject.Location && params.Subject.Location.Name ? params.Subject.Location.Name : '',
                    LocationId: params.Subject.Location && params.Subject.Location.hgId ? params.Subject.Location.hgId : '',
                    EmployeeId: params.Subject.EmployeeId
                }, {
                    ParticipantType: FeedbackEnums.SessionParticipantType.Reviewer,
                    MemberId: params.Reviewer.MemberId,
                    UserId: params.Reviewer.AvatarId,
                    FullName: params.Reviewer.Name,
                    Status: FeedbackEnums.SessionParticipantStatus.InProgress,
                    Role: params.Reviewer.Role,
                    DepartmentName: params.Reviewer.DepartmentName,
                    DepartmentId: params.Reviewer.DepartmentId,
                    LocationName: params.Reviewer.LocationName,
                    LocationId: params.Reviewer.LocationId,
                    EmployeeId: params.Reviewer.EmployeeId
                }],
                CycleType: params.CycleType,
                CycleDescription: params.CycleDescription,
                ExpirationDate: Date.now() + params.ExpireRequestDays * ConstantEnums.MILLI_SECONDS_PER_DAY,
                Card: params.Card,
                GroupId: params.GroupId
            });
            session.save(callback);
        };
    };

module.exports = FeedbackSessionProcessor;
