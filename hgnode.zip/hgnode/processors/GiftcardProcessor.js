/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    GiftcardProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid'),
            Async = require('async'),
            HgError = require('../common/HgError.js'),
            HgLog = require('../framework/HgLog.js'),
            GiftcardStatusEnum = require('../schemas/GiftcardSchema.js').GiftcardStatusEnum,
            GiftcardOrderRequest = require('../schemas/GiftcardSchema.js').GiftcardOrderRequest,
            GiftcardOrderRequestArchive = require('../schemas/GiftcardSchema.js').GiftcardOrderRequestArchive,
            OrderLineItemStatusEnum = require('../schemas/OrderLineItemSchema.js').OrderLineItemStatusEnum,
            orderGiftcardAsync = function (request, callback) {
                var lineItem = request.LineItem,
                    orderLineItem = EntityCache.OrderLineItem({
                        hgId: guid.v1(),
                        Type: 'Giftcard',
                        Category: 'Code',
                        CardType: lineItem.CardType,
                        TangoSKU: lineItem.TangoSKU,
                        Denomination: lineItem.Denomination,
                        IssuerId: lineItem.IssuerId,
                        RedeemerId: request.UserId,
                        RecipientId: request.UserId,
                        RequestId: request.RequestId
                    });
                EntityCache.TangoCard.findOne({'Denominations.SKU': orderLineItem.TangoSKU }, function (error, tangoCard) {
                    if (error || !tangoCard) {
                        return callback("services.red.efc");
                    }
                    orderLineItem.Status = OrderLineItemStatusEnum.Filfilled;
                    orderLineItem.Category = 'Code';
                    request.TangoCard = tangoCard;
                    orderLineItem.save(callback);
                });
            },
            reserveAndReturnGiftcardAsync = function (request, callback) {
                if (request.RequestedDenomination.CardType === 'HighGround') {
                    var mquery = EntityCache.Giftcard.find({Status: GiftcardStatusEnum.Available, 'Issuer.IssuerId': request.RequestedDenomination.IssuerId, Category: request.RequestedDenomination.Category, Denomination: request.RequestedDenomination.Denomination}),
                        i,
                        len;
                    mquery.limit(request.RequestedDenomination.RequestedNumber).exec(function (err, giftcards) {
                        if (err) {
                            HgLog.error('Error when loading giftcards: ' + err);
                            callback(err);
                        } else {
                            if (giftcards) {
                                for (i = 0, len = giftcards.length; i < len; i += 1) {
                                    giftcards[i].Status = GiftcardStatusEnum.Reserved;
                                    giftcards[i].RedeemerId = request.UserId;
                                    giftcards[i].RecipientId = request.UserId;
                                    giftcards[i].RequestId = request.RequestId;
                                    giftcards[i].ReserveDate = new Date().now();
                                    giftcards[i].save();
                                    request.ReservedGiftcards.push(giftcards[i].hgId);
                                }
                            }
                            callback();
                        }
                    });
                } else {
                    callback();
                }
            },
            buildLineItems = function (requests) {
                var i,
                    ilen,
                    j,
                    lineItem,
                    lineItems = [],
                    requestedNumber,
                    reservedItemNumber;
                for (i = 0, ilen = requests.length; i < ilen; i += 1) {
                    reservedItemNumber = requests[i].ReservedGiftcards.length;
                    requestedNumber = requests[i].RequestedDenomination.RequestedNumber;
                    for (j = 0; j < requestedNumber; j += 1) {
                        if (j < reservedItemNumber) {
                            lineItem = {
                                IssuerId: requests[i].RequestedDenomination.IssuerId,
                                Category: requests[i].RequestedDenomination.Category,
                                Denomination: requests[i].RequestedDenomination.Denomination,
                                CreditCost: requests[i].RequestedDenomination.CreditCost,
                                CardId: requests[i].ReservedGiftcards[j],
                                CardType: requests[i].RequestedDenomination.CardType,
                                Status: 'Reserved'
                            };
                        } else if (requests[i].RequestedDenomination.CardType === 'TangoCharity' || requests[i].RequestedDenomination.CardType === 'TangoGiftCard') {
                            lineItem = {
                                IssuerId: requests[i].RequestedDenomination.IssuerId,
                                Category: requests[i].RequestedDenomination.Category,
                                Denomination: requests[i].RequestedDenomination.Denomination,
                                CreditCost: requests[i].RequestedDenomination.CreditCost,
                                TangoSKU: requests[i].RequestedDenomination.TangoSKU,
                                CardId: '',
                                CardType: requests[i].RequestedDenomination.CardType,
                                Status: 'Reserved'
                            };
                        } else {
                            lineItem = {
                                IssuerId: requests[i].RequestedDenomination.IssuerId,
                                Category: requests[i].RequestedDenomination.Category,
                                Denomination: requests[i].RequestedDenomination.Denomination,
                                CreditCost: requests[i].RequestedDenomination.CreditCost,
                                CardId: '',
                                CardType: requests[i].RequestedDenomination.CardType,
                                Status: 'BackOrdered'
                            };
                        }
                        lineItems.push(lineItem);
                    }
                }
                return lineItems;
            };

        this.ReserveAndReturnGiftcards = function (params, callback) {
            var giftcardOrderRequest = params.GiftcardOrderRequest,
                i,
                len,
                requests = [],
                lineItems = [];
            for (i = 0, len = giftcardOrderRequest.RequestedDenominations.length; i < len; i += 1) {
                requests.push({
                    RequestId: giftcardOrderRequest.hgId,
                    RequestedDenomination: giftcardOrderRequest.RequestedDenominations[i],
                    UserId: params.UserId,
                    ReservedGiftcards: []
                });
            }
            len = requests.length;
            Async.whilst(
                function () {
                    len -= 1;
                    return len > -1;
                },
                function (callback) {
                    reserveAndReturnGiftcardAsync(requests[len], callback);
                },
                function (err) {
                    if (err) {
                        callback(err, null);
                    } else {
                        lineItems = buildLineItems(requests);
                        callback(null, lineItems);
                    }
                }
            );
        };

        this.OrderGiftcards = function (params, callback) {
            var lineItems = params.LineItems,
                giftcardOrderRequest = params.GiftcardOrderRequest,
                requests = [],
                i,
                len,
                giftcardOrderRequestArchive;
            for (i = 0, len = lineItems.length; i < len; i += 1) {
                requests.push({
                    RequestId: giftcardOrderRequest.hgId,
                    LineItem: lineItems[i],
                    UserId: params.UserId
                });
            }
            len = requests.length;
            Async.whilst(
                function () {
                    len -= 1;
                    return len > -1;
                },
                function (callback) {
                    orderGiftcardAsync(requests[len], callback);
                },
                function (err) {
                    if (err) {
                        HgLog.error({methodName: 'OrderGiftcards', error: err});
                        return callback(err + ' todo: error happened, need to reverse');
                    }

                    giftcardOrderRequest.Status = 'Fulfilled';
                    giftcardOrderRequestArchive = new GiftcardOrderRequestArchive(giftcardOrderRequest);
                    giftcardOrderRequest.remove();
                    giftcardOrderRequestArchive.save();
                    callback(null, requests);
                }
            );
        };

        this.GetGiftcardOrderForUser = function (params, callback) {
            GiftcardOrderRequest.findOne({UserId: params.UserId, Status: 'Active'}, function (error, giftcardOrderRequest) {
                if (error) {
                    callback(HgError.Enums.Giftcard.ErrorLoadingGiftcard);
                } else {
                    callback(null, giftcardOrderRequest);
                }
            });
        };

        this.ClearGiftcardOrderForUser = function (params, callback) {
            GiftcardOrderRequest.findOne({UserId: params.UserId, Status: 'Active'}, function (err, giftcardOrderRequest) {
                if (err) {
                    callback(HgError.Enums.Giftcard.ErrorLoadingGiftcard);
                    return;
                }
                if (!giftcardOrderRequest) {
                    callback(null, 'User order cleared');
                    return;
                }
                EntityCache.Giftcard.update(
                    {RequestId: giftcardOrderRequest.hgId},
                    {$set: {
                        Status: GiftcardStatusEnum.Available,
                        RedeemerId: '',
                        RecipientId: '',
                        RequestId: ''
                    }},
                    {upsert: false, multi: true},
                    function (err, numAffected, raw) {
                        if (err) {
                            callback(HgError.Enums.Giftcard.ErrorUpdatingGiftcard);
                        } else {
                            giftcardOrderRequest.remove(function (error) {
                                if (error) {
                                    callback(error);
                                } else {
                                    callback(null, 'User order cleared');
                                }
                            });
                        }
                    }
                );
            });
        };

        this.SaveGiftcardOrder = function (params, callback) {
            GiftcardOrderRequest.findOne({UserId: params.UserId, Status: 'Active'}, function (getError, giftcardOrderRequest) {
                if (getError) {
                    callback(getError, null);
                } else {
                    if (!giftcardOrderRequest) {
                        giftcardOrderRequest = new GiftcardOrderRequest(params.GiftcardOrderRequest);
                        giftcardOrderRequest.UserId = params.UserId;
                        giftcardOrderRequest.CreatedBy = params.UserId;
                        giftcardOrderRequest.hgId = guid.v1();
                    }
                    giftcardOrderRequest.ModifiedBy = params.UserId;
                    giftcardOrderRequest.RequestedDenominations = params.GiftcardOrderRequest.RequestedDenominations;
                    giftcardOrderRequest.save(function (saveError) {
                        if (saveError) {
                            callback(saveError, null);
                        } else {
                            //we should release any reserved giftcard for this order request
                            EntityCache.Giftcard.update(
                                {RequestId: giftcardOrderRequest.hgId, Status: GiftcardStatusEnum.Reserved},
                                {$set: {
                                    Status: GiftcardStatusEnum.Available,
                                    RedeemerId: '',
                                    RecipientId: '',
                                    RequestId: ''
                                }},
                                {upsert: false, multi: true},
                                function () {
                                    callback(null, giftcardOrderRequest);
                                }
                            );
                        }
                    });
                }
            });
        };
    };

module.exports = GiftcardProcessor;