/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ProductOrderProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            guid = require('node-uuid');

        this.DefaultEntityName = 'ProductOrder';
        this.CreateOrder = function (params, callback) {
            var order = new EntityCache.ProductOrder();
            order.hgId = guid.v1();
            order.CreatedBy = params.UserId;
            order.ModifiedBy = params.UserId;
            order.FriendlyId = params.FriendlyId;
            order.ProductItem = params.ProductItem;
            order.Quantity = params.Quantity;
            order.Status = EntityEnums.ProductOrderStatus.Ordered;
            order.AccountType = params.AccountType;
            if (params.RequesterMember) {
                order.Requester = {
                    MemberId: params.RequesterMember.hgId,
                    UserId: params.RequesterMember.UserId,
                    FullName: params.RequesterMember.FullName
                };
            }
            if (params.RecipientMember) {
                order.Recipient = {
                    MemberId : params.RecipientMember.hgId,
                    UserId : params.RecipientMember.UserId,
                    FullName : params.RecipientMember.FullName
                };
            }
            order.save(function (error) {
                callback(error, order);
            });
        };
        this.FulfillOrder = function (params, callback) {
            EntityCache.ProductOrder.findOneAndUpdate({
                hgId: params.OrderId,
                Status: {$in: [EntityEnums.ProductOrderStatus.Ordered, EntityEnums.ProductOrderStatus.PendingAdminApprove]}
            }, {
                $set: {
                    Status: EntityEnums.ProductOrderStatus.Fulfilled,
                    FulfillNote: params.Note,
                    FulillDate: Date.now(),
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, function (error, order) {
                if (error || !order) {
                    callback('prod.ord.fof');
                } else {
                    callback(null, order);
                }
            });
        };
        this.CancelOrder = function (params, callback) {
            EntityCache.ProductOrder.findOneAndUpdate({
                hgId: params.OrderId,
                Status: {$in: [EntityEnums.ProductOrderStatus.Ordered, EntityEnums.ProductOrderStatus.PendingAdminApprove]}
            }, {
                $set: {
                    Status: EntityEnums.ProductOrderStatus.Cancelled,
                    CancelNote: params.Note,
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, function (error, order) {
                if (error || !order) {
                    callback('prod.ord.cof');
                } else {
                    callback(null, order);
                }
            });
        };
        this.GetTopProducts = function (params, callback) {
            var filter = { $match: {
                    'ProductItem.GroupId': params.GroupId,
                    CreatedDate: { $gte: params.StartDate, $lte: params.EndDate},
                    Status: EntityEnums.ProductOrderStatus.Fulfilled
                }},
                group = { $group: {
                    _id: {ProductId: '$ProductItem.hgId'},
                    Total: {$sum: '$ProductItem.PointCost'},
                    Quantity: {$sum: 1}
                }},
                sort = { $sort: { Total: -1} },
                limit = { $limit: 10 };
            EntityCache.ProductOrder.aggregate([filter, group, sort, limit], function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data);
            });
        };
    };

module.exports = ProductOrderProcessor;
