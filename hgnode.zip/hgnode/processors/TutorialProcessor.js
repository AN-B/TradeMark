/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    fs = require('fs'),
    hgLog = require('../framework/HgLog.js'),
    fsUtil = require('../helpers/fileSystemUtil.js'),
    Async = require('async'),
    TutorialProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid');

        this.DefaultEntityName = 'Tutorial';

        function getTutorialIds(callback) {
            EntityCache.Tutorial.find({}, {hgId: 1}, function (err, items) {
                callback(items.map(function (item) {
                    return item.hgId;
                }));
            });
        }

        function getTemplateUrl(params) {
            var feature = params.ItemRequest.feature ? params.ItemRequest.feature + '-' : '';
            return '/' + params.ItemRequest.primaryCategory + '/' + params.ItemRequest.secondaryCategory + '-' + feature + params.ItemRequest.stepNumber + '.html';
        }

        this.InitMemberTutorials = function (memberId, callback) {
            var itemArray = [],
                item,
                i,
                len;
            getTutorialIds(function (tutorialsIds) {
                for (i = 0, len = memberId.length; i < len; i += 1) {
                    item = new EntityCache.MemberTutorial();
                    item.MemberId = memberId[i];
                    item.TutorialIds = tutorialsIds;
                    itemArray.push(item);
                }
                EntityCache.MemberTutorial.create(itemArray, function (err, data) {
                    if (err) {
                        return callback(err);
                    }
                    callback(null, data);
                });
            });
        };

        this.AddMemberTutorialsByTutorialNumber = function (itemRequest, callback) {
            EntityCache.Tutorial.find({TutorialNumber : itemRequest.tutorialNumber}, function (err, items) {
                if (err) {
                    return callback(err);
                }

                EntityCache.MemberTutorial.update({ MemberId: itemRequest.memberId }, { $pushAll: { TutorialIds: items.map(function (item) {return item.hgId; }) }}, function (err, memberTutorial) {
                    if (err) { return callback(err); }
                    callback(null, memberTutorial);
                });
            });
        };

        this.ResetTutorialsAll = function (callback) {
            getTutorialIds(function (tutorialsIds) {
                EntityCache.MemberTutorial.update({}, {$set: {TutorialIds: tutorialsIds}}, { multi: true }, function (err, numberUpdated) {
                    if (err) {
                        return callback(err);
                    }
                    callback(null, JSON.stringify(['business.tut.pro.ares']));
                });
            });
        };

        this.GetTutorialsAll = function (params, callback) {
            EntityCache.Tutorial.distinct('FullCategory', function (err, items) {
                if (err) {
                    return callback(err);
                }
                callback(null, items);
            });
        };

        this.GetTutorialStepsAll = function (params, callback) {
            EntityCache.Tutorial.find({}, function (err, items) {
                if (err) {
                    return callback(err);
                }
                callback(null, items);
            });
        };

        this.ResetTutorialsByMember = function (params, callback) {
            var memberId,
                message,
                query = {};

            if (params.ItemRequest) {
                memberId = params.ItemRequest.MemberId || params.MemberId;
                message = params.ItemRequest.MemberId ? 'business.tut.pro.sres' : 'business.tut.pro.str';
                if (params.ItemRequest.TutorialIds && params.ItemRequest.TutorialIds.length && !params.ItemRequest.ResetAll) {
                    query = {FullCategory: { $in: params.ItemRequest.TutorialIds }};
                }
            } else {
                memberId = params.MemberId;
                message = 'business.tut.pro.mres';
            }

            EntityCache.Tutorial.find(query, function (err, items) {
                EntityCache.MemberTutorial.findOne({MemberId: memberId}, function (err, member) {
                    if (err) {
                        return callback(err);
                    }
                    if (!member) {
                        getTutorialIds(function (tutorialsIds) {
                            var item = new EntityCache.MemberTutorial();
                            item.MemberId = memberId;
                            item.TutorialIds = tutorialsIds;
                            item.save(function (err) {
                                if (err) {
                                    return callback(err);
                                }
                                callback(null, JSON.stringify([message]));
                            });
                        });
                    } else {
                        EntityCache.MemberTutorial.update({ MemberId: memberId },
                            {$set: {TutorialIds: items.map(function (item) {
                                return item.hgId;
                            })}}, function (err, numberUpdated) {
                                if (err) {
                                    return callback(err);
                                }
                                callback(null, JSON.stringify([message]));
                            });
                    }
                });
            });
        };

        this.CompleteMemberTutorials = function (params, callback) {
            var completedTutorialNumber = params.ItemRequest.tutorialNumber;
            EntityCache.Tutorial.find({TutorialNumber : completedTutorialNumber}, function (err, tutorials) {
                if (err) {
                    return callback(err);
                }
                EntityCache.MemberTutorial.update({ MemberId: params.MemberId }, { $pullAll: { TutorialIds: tutorials.map(function (tutorial) {return tutorial.hgId; }) }}, function (err, memberTutorial) {
                    if (err) { return callback(err); }
                    EntityCache.Tutorial.findOne({$and : [{ExitURL : {$ne : ''}}, {TutorialNumber : completedTutorialNumber}]}, function (err, tutorial) {
                        if (err || !tutorial) {
                            return callback(err);
                        }
                        return callback(null, {
                            exitURL: tutorial.ExitURL,
                            tutorialNumberCompleted: completedTutorialNumber
                        });
                    });
                });
            });
        };

        this.CreateTutorialStep = function (params, callback) {
            var item = new EntityCache.Tutorial(),
                feature = params.ItemRequest.feature || '',
                fullCategoryString = params.ItemRequest.primaryCategory + ':' + params.ItemRequest.secondaryCategory + feature,
                templateUrl = getTemplateUrl(params);

            item.FullCategory = fullCategoryString.replace(/\s+/g, '');
            item.PrimaryCategory = params.ItemRequest.primaryCategory;
            item.SecondaryCategory = params.ItemRequest.secondaryCategory;
            item.Feature = feature;
            item.TutorialNumber = params.ItemRequest.number;
            item.Step = params.ItemRequest.stepNumber;
            item.RouteURL = params.ItemRequest.routeUrl || '';
            item.TemplateURL = templateUrl;
            item.ExitURL = params.ItemRequest.exitUrl || '';
            item.TargetSelector = params.ItemRequest.targetSelector || '';
            item.Permissions = params.ItemRequest.permissions;
            item.hgId = guid.v1();
            item.CreatedBy = params.UserId;
            item.ModifiedBy = params.UserId;
            item.save(function (err) {
                callback(err, item);
            });
        };

        this.UpdateSuiteStepOrder = function (params, callback) {
            var templateDir = params.appDir + '/static/templates/Tutorial/en',
                tempDir = params.appDir + '/static/templates/Tutorial/tmp',
                newTemplateName,
                tempTemplateName,
                filesMoved = [],
                processStepOrderUpdate = function (step, asyncCallback) {
                    EntityCache.Tutorial.findOne({hgId: step.stepId}, function (err, originalItem) {
                        var feature = originalItem.Feature ? originalItem.Feature + '-' : '',
                            templateUrl = '/' + originalItem.PrimaryCategory + '/' + originalItem.SecondaryCategory + '-' + feature + step.stepNumber + '.html',
                            originalTemplateName = templateDir + originalItem.TemplateURL;

                        fsUtil.createDirPath(tempDir + '/' + originalItem.PrimaryCategory, function (err, data) {
                            newTemplateName = templateDir + templateUrl;
                            tempTemplateName = tempDir + templateUrl;
                            filesMoved.push({
                                tempTemplateName: tempTemplateName,
                                newTemplateName: newTemplateName
                            });
                            if (err) { asyncCallback(err); }
                            fs.rename(originalTemplateName, tempTemplateName, function (err) {
                                if (err) { asyncCallback(err); }
                                EntityCache.Tutorial.findOneAndUpdate({
                                    hgId: step.stepId
                                }, {
                                    $set: {
                                        Step: step.stepNumber,
                                        TemplateURL: templateUrl
                                    }
                                }, {
                                    new: true
                                }, function (err, item) {
                                    asyncCallback(err);
                                });
                            });
                        });
                    });
                },
                moveNewTemplates = function (fileObject, asyncCallback) {
                    fs.rename(fileObject.tempTemplateName, fileObject.newTemplateName, function (err) {
                        if (err) {
                            asyncCallback(err);
                        }
                        asyncCallback(null);
                    });
                };
            fsUtil.createDirPath(tempDir, function (err, data) {
                if (err) {
                    return callback(err);
                }
                Async.each(params.ItemRequest, processStepOrderUpdate, function (err) {
                    if (err) {
                        return callback(err);
                    }
                    Async.each(filesMoved, moveNewTemplates, function (err) {
                        if (err) {
                            return callback(err);
                        }
                        callback(err, {message: 'OK'});
                    });
                });
            });
        };

        this.UpdateTutorialStep = function (params, callback) {
            var feature = params.ItemRequest.feature ? ':' + params.ItemRequest.feature : '',
                fullCategoryString = params.ItemRequest.primaryCategory + ':' + params.ItemRequest.secondaryCategory + feature,
                templateUrl = getTemplateUrl(params);

            EntityCache.Tutorial.findOne({hgId: params.ItemRequest.stepId}, function (err, item) {
                if (err || !item) {
                    callback('Cannot find the item');
                } else {
                    EntityCache.Tutorial.findOneAndUpdate({
                        hgId: params.ItemRequest.stepId
                    }, {
                        $set: {
                            FullCategory: fullCategoryString.replace(/\s+/g, ''),
                            PrimaryCategory: params.ItemRequest.primaryCategory || '',
                            SecondaryCategory: params.ItemRequest.secondaryCategory || '',
                            Feature: params.ItemRequest.feature || '',
                            TutorialNumber: params.ItemRequest.number,
                            Step: params.ItemRequest.stepNumber,
                            RouteURL: params.ItemRequest.routeUrl || '',
                            TemplateURL: templateUrl,
                            ExitURL: params.ItemRequest.exitUrl || '',
                            TargetSelector: params.ItemRequest.targetSelector || '',
                            Permissions: params.ItemRequest.permissions || ''
                        }
                    }, {
                        new: true
                    }, callback);
                }
            });
        };

        this.DeleteTutorialStep = function (params, callback) {
            var tutorialStepId = params.ItemRequest.stepId,
                message = 'Tutorial step successfully deleted.';
            EntityCache.Tutorial.remove({hgId: tutorialStepId}, function (err, item) {
                if (err) {
                    return callback(err);
                }
                callback(null, message);
            });
        };

        this.GetTutorialStep = function (params, callback) {
            var tutorialStepId = params.ItemRequest.stepId;
            EntityCache.Tutorial.findOne({hgId: tutorialStepId}, function (err, item) {
                if (err || !item) {
                    return callback(err);
                }
                fs.readFile(params.appDir + '/static/templates/Tutorial/en' + item.TemplateURL, function (err, data) {
                    if (err) {
                        callback(err);
                    } else {
                        item.Template = data || '';
                        callback(null, item);
                    }
                });
            });
        };

        this.GetTutorialsByMember = function (params, callback) {
            var take = 50;

            EntityCache.MemberTutorial.findOne({MemberId: params.memberId}, function (err, memberTutorial) {
                if (err) {
                    return callback(err);
                }
                if (memberTutorial !== null) {
                    EntityCache.Tutorial.find({ $and: [ {hgId: { $in: memberTutorial.TutorialIds }}, {Permissions: { $in: params.permissions }} ]})
                        .limit(take)
                        .sort({Step : 1, TutorialNumber : 1})
                        .exec(function (err, tutorials) {
                            if (err) {
                                return callback(err);
                            }
                            return callback(err, tutorials);
                        });
                } else {
                    return callback(err, []);
                }
            });
        };

        this.CreateTutorial = function (itemRequest, callback) {
            var item = new EntityCache.Tutorial();

            item.PrimaryCategory = itemRequest.PrimaryCategory;
            item.SecondaryCategory = itemRequest.SecondaryCategory;
            item.Feature = itemRequest.Feature;
            item.TutorialNumber = itemRequest.TutorialNumber;
            item.Step = itemRequest.Step;
            item.RouteURL = itemRequest.RouteURL;
            item.TemplateURL = itemRequest.TemplateURL;
            item.ExitURL = itemRequest.ExitURL;
            item.Permissions = itemRequest.Permissions;
            item.hgId = itemRequest.hgId;
            item.CreatedBy = itemRequest.CreatedBy;
            item.ModifiedBy = itemRequest.ModifiedBy;
            item.CreatedDate = itemRequest.CreatedDate;
            item.ModifiedDate = itemRequest.ModifiedDate;

            item.save(function (err) {
                callback(err, item);
            });
        };
    };

module.exports = TutorialProcessor;