/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    TemplateProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            TemplateHelper = require('../services/Helper/TemplateHelper.js'),
            TemplateEnums = require('../enums/TemplateEnums.js'),
            guid = require('node-uuid');

        this.AddTemplate = function (params, callback) {
            var template = EntityCache.Template(params);
            template.hgId = guid.v1();
            template.CreatedBy = params.UserId;
            template.ModifiedBy = params.UserId;
            template.Status = params.Status || TemplateEnums.Status.Active;
            if (params.UberQuestion) {
                template.UberQuestion = TemplateHelper.GetQuestion(params.UberQuestion, params.UserId);
            }
            if (params.DriverQuestions) {
                template.DriverQuestions = params.DriverQuestions.map(function (item) {
                    return TemplateHelper.GetQuestion(item, params.UserId);
                });
            }
            if (params.PulseQuestions) {
                template.PulseQuestions = params.PulseQuestions.map(function (item) {
                    return TemplateHelper.GetQuestion(item, params.UserId);
                });
            }
            template.save(callback);
        };
        this.UpdateTemplate = function (params, callback) {
            EntityCache.Template.findOne({hgId: params.hgId}, function (error, template) {
                if (error) {
                    callback(error);
                } else if (!template) {
                    callback('business.tpl.pro.elt');
                } else {
                    template.ModifiedBy = params.UserId;
                    template.Title = params.Title;
                    template.Description = params.Description;
                    template.Type = params.Type;
                    template.Status = params.Status || TemplateEnums.Status.Active;
                    if (params.UberQuestion) {
                        template.UberQuestion = TemplateHelper.GetQuestion(params.UberQuestion, params.UserId);
                    }
                    if (params.DriverQuestions) {
                        template.DriverQuestions = params.DriverQuestions.map(function (item) {
                            return TemplateHelper.GetQuestion(item, params.UserId);
                        });
                    }
                    if (params.PulseQuestions) {
                        template.PulseQuestions = params.PulseQuestions.map(function (item) {
                            return TemplateHelper.GetQuestion(item, params.UserId);
                        });
                    }
                    template.save(callback);
                }
            });
        };
        this.GetTemplateByType = function (params, callback) {
            EntityCache.Template.findOne({Type: params.Type, Status: TemplateEnums.Status.Active}, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, (!data) ? null : data.toJSON());
            });
        };
    };

module.exports = TemplateProcessor;