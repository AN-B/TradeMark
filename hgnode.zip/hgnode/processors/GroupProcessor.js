/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    GroupProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js'),
            self = this,
            guid = require('node-uuid'),
            HgError = require('../common/HgError.js'),
            HgLog = require('../framework/HgLog'),
            ValueSettingHelper = require('../helpers/ValueSettingHelper'),
            ProcessorHelper = require('../util/ProcessorHelper.js'),
            Async = require('async'),
            PusherManager = require('../util/PusherManager'),
            Enums = require('../enums/EntityEnums.js'),
            FeatureFlagEnums = require('../enums/FeatureFlagEnums.js'),
            ConstantEnums = require('../enums/ConstantEnums'),
            time = require('time'),
            DefaultValueLevelEnums = require('../enums/DefaultValueLevelEnums.js');

        this.GetRulesEngineEventTypeNames = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (error, group) {
                if (error || !group || !group.RulesEngineEventTypes) {
                    callback(null, []);
                } else {
                    callback(null, group.RulesEngineEventTypes);
                }
            });
        };

        this.GetAllGroups = function (params, callback) {
            EntityCache.Group.find({}, function (err, groups) {
                callback(err, groups);
            });
        };

        this.SaveImpersonateActivity = function (params) {
            var activity = new EntityCache.ImpersonateActivity(params);
            activity.hgId = guid.v1();
            activity.CreatedBy = params.ImpersonatorUserId;
            activity.ModifiedBy = params.ImpersonatorUserId;
            activity.save();
        };

        this.CloseImpersonateActivity = function (params, callback) {
            EntityCache.ImpersonateActivity.update({
                ActAsUserToken: params.ActAsUserToken
            }, {$set: {
                EndTime: new Date().getTime(),
                ModifiedBy: params.UserId,
                ModifiedDate: new Date().getTime()
            }}, {
                upsert: false
            }).exec(callback);
        };

        this.GetValueLevelSetting = function (params, callback) {
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, {
                ValueLevelSetting: true,
                FriendlyGroupId: true,
                _id: false
            }, function (err, group) {
                if (err) {
                    return callback('business.gro.pro.evls');
                }

                var friendlyGroupId = group.FriendlyGroupId,
                    hasDefault;
                if (group.ValueLevelSetting && group.ValueLevelSetting.Levels && group.ValueLevelSetting.Levels.length > 0) {
                    hasDefault = group.ValueLevelSetting.Levels.some(function (level) {
                        return level.Name === 'Default';
                    });
                    if (!hasDefault) {
                        group.ValueLevelSetting.Levels.unshift({
                            Name: 'Default',
                            PointValue: 10,
                            CreditValue: 0,
                            LimitPeriod: 'NoLimit',
                            AvailabilityToRoles: [],
                            LimitNumber: 0
                        });

                        group.ValueLevelSetting.Levels.forEach(function (level) {
                            if (level.AvailabilityToRoles.length > 0) {
                                level.LimitNumber = level.AvailabilityToRoles[0].LimitNumber;
                            }
                        });
                    }
                }
                return callback(null, {
                    Enabled: group.ValueLevelSetting && group.ValueLevelSetting.Enabled,
                    Levels: (group.ValueLevelSetting && group.ValueLevelSetting.Levels) || DefaultValueLevelEnums.GetAllLevels(),
                    FriendlyGroupId: friendlyGroupId
                });
            });
        };

        this.SaveValueLevelSetting = function (params, callback) {
            var requests = [],
                request;
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, {
                FriendlyGroupId: true
            }, function (err, group) {
                if (err || !group) {
                    return callback('server.hge.grp.elg');
                }
                params.ValueLevelSetting.Levels.forEach(function (level) {
                    if (level.BadgeId) {
                        level.ImageId = guid.v1();
                        request = {
                            BadgeId: level.BadgeId,
                            FriendlyGroupId: group.FriendlyGroupId,
                            TemplateId: level.ImageId
                        };
                        requests.push(request);
                    }
                    if (level.AvailabilityToRoles && level.AvailabilityToRoles.length && level.LimitNumber) {
                        level.AvailabilityToRoles.forEach(function (e) {
                            e.LimitNumber = level.LimitNumber;
                        });
                    }
                });
                Async.each(requests, ValueSettingHelper.processValueSetting, function (err) {
                    if (err) {
                        return callback('business.gro.pro.ecb');
                    }
                    EntityCache.Group.update({
                        hgId: params.GroupId
                    }, {
                        $set: {
                            ValueLevelSetting: params.ValueLevelSetting
                        }
                    }, function (err) {
                        if (err) {
                            return callback('business.gro.pro.esvls');
                        }
                        callback(null, {
                            Enabled: params.ValueLevelSetting.Enabled,
                            Levels: params.ValueLevelSetting.Levels,
                            FriendlyGroupId: group.FriendlyGroupId,
                            Group: group
                        });
                    });
                });
            });
        };

        this.LoadRefrenceNumberTypes = function (params, callback) {
            var types = [];
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                if (err || !group) {
                    callback('server.hge.grp.elg');
                } else {
                    if (group.Preference) {
                        types = group.Preference.ReferenceNumberTypes;
                    }
                    if (params.EntityName) {
                        types = types.filter(function (type) {
                            return type.EntityName === params.EntityName;
                        });
                    }
                    callback(null, types);
                }
            });
        };

        this.SetRolesAndPermissionsForMembers = function (params, callback) {
            EntityCache.Member.update({hgId: {$in: params.MemberIds}}, {$set: {
                AddedPermissions: params.AddedPermissions,
                RemovedPermissions: params.RemovedPermissions
            }}, {multi: true}, function (error, updated) {
                if (error || !updated) {
                    return callback((error && 'group.int.msg.fums') ||
                                    (!updated && 'group.int.msg.nums'));
                }
                callback(null, 'group.int.msg.ums');
            });
        };

        this.GetRolesWithAddedPermission = function (params, callback) {
            EntityCache.GroupRolePermissions.find({
                GroupId: params.GroupId,
                AddedPermissions: params.Permission
            }, callback);
        };

        this.AddRolePermission = function (params, callback) {
            EntityCache.GroupRolePermissions.findOne({GroupId: params.GroupId, RoleName: params.Role}, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    var newRolePermission = EntityCache.GroupRolePermissions({
                        hgId: guid.v1(),
                        RoleName: params.Role,
                        AddedPermissions: params.AddedPermissions,
                        GroupId: params.GroupId,
                        CreatedBy: params.UserId,
                        CreatedDate: new Date().getTime(),
                        ModifiedDate: Date.now(),
                        ModifiedBy: params.UserId
                    });
                    newRolePermission.save(function (error) {
                        if (error) {
                            callback(error);
                        } else {
                            callback(null, 'business.gro.pro.gpfra');
                        }
                    });
                } else {
                    EntityCache.GroupRolePermissions.update({GroupId: params.GroupId, RoleName: params.Role}, {$set: {
                        RoleName: params.Role,
                        AddedPermissions: params.AddedPermissions,
                        GroupId: params.GroupId,
                        ModifiedDate: Date.now(),
                        ModifiedBy: params.UserId
                    }}, function (error) {
                        if (error) {
                            callback('business.gro.pro.eaptr');
                        } else {
                            callback(null, 'business.gro.pro.pfrc');
                        }
                    });
                }
            });
        };

        this.GetAllRolesPermissions = function (params, callback) {
            EntityCache.GroupRolePermissions.find({
                GroupId: params.GroupId
            }, callback);
        };

        this.GetGroupById = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, params.Fields || {}, function (err, group) {
                if (err) {
                    return callback('server.hge.grp.elg');
                }
                callback(null, group);
            });
        };

        this.GetPointCreditMasterMemberIds = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                if (err) {
                    return callback(err);
                }
                callback(null, {
                    CreditMasterMemberId: group.CreditMasterMemberId || 0,
                    PointMasterMemberId: group.PointMasterMemberId || 0
                });
            });
        };

        this.GetCreditMasterMember = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                if (err || !group) {
                    return callback(HgError.Enums.Group.ErrorLoadingGroup);
                }
                EntityCache.Member.findOne({hgId: group.CreditMasterMemberId}, function (err, member) {
                    if (err) {
                        return callback(err);
                    }
                    if (!member) {
                        return callback(null, "services.int.gro.cas");
                    }
                    callback(null, member);
                });
            });
        };

        this.GetTeamTabSettings = function (params, callback) {
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, {
                TeamTabSetting: 1
            }, function (error, groupTeamTabSettings) {
                if (error) {
                    return callback(error);
                }
                if (!groupTeamTabSettings) {
                    return callback('server.hge.grp.elg');
                }
                callback(null, groupTeamTabSettings);
            });
        };

        this.SetRecapTimes = function (params, callback) {
            EntityCache.Group.findOneAndUpdate({
                hgId: params.GroupId
            }, {
                $set: {
                    'Preference.WeeklyRecapTime': params.WeeklyRecapTime,
                    'Preference.DailyRecapTime': params.DailyRecapTime
                }
            }, function (error, group) {
                if (error || !group) {
                    callback(error);
                } else {
                    callback(null, group);
                }
            });
        };

        this.GetPasswordPolicyByGroupId = function (params, callback) {
            if (!params.GroupId) {
                return callback('group.int.msg.gnv');
            }
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, { PasswordPolicy: 1 }, {lean: true},
                function (err, group) {
                    if (err || !group) {
                        return callback(err || 'server.hge.grp.elg');
                    }
                    callback(null, group.PasswordPolicy);
                });
        };

        this.GetPasswordPolicyByUserName = function (params, callback) {
            var username = params.UserName;
            if (!username) {
                return callback('server.hge.usr.elu');
            }
            EntityCache.UserInfo.findOne({LowercaseUserName: username.toLowerCase()}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('server.hge.usr.elu');
                }
                self.GetPasswordPolicyByGroupId({
                    GroupId: userInfo.Preference.DefaultGroupId
                }, callback);
            });
        };

        this.GetPasswordPolicyByUserId = function (params, callback) {
            var userId = params.UserId;
            if (!userId) {
                return callback('server.hge.usr.elu');
            }
            EntityCache.UserInfo.findOne({hgId: userId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('server.hge.usr.elu');
                }
                self.GetPasswordPolicyByGroupId({
                    GroupId: userInfo.Preference.DefaultGroupId
                }, callback);
            });
        };

        this.UpdatePasswordPolicy = function (params, callback) {
            EntityCache.Group.findOneAndUpdate({
                hgId: params.GroupId
            }, {
                $set: {
                    PasswordPolicy: params.policy
                }
            }, function (error, group) {
                if (error || !group) {
                    return callback('server.hge.grp.elg');
                }
                callback(null, group);
            });
        };

        this.UpdateTeamTabSettings = function (params, callback) {
            EntityCache.Group.update({
                hgId: params.GroupId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    TeamTabSetting: params.TeamTabSettings
                }
            }, callback);
        };

        this.GetFederatedGroups = function (params, callback) {
            EntityCache.Group.find({
                Status: Enums.GroupStatus.Active,
                Federated: true
            }, {
                hgId: true,
                GroupName: true
            }, callback);
        };

        this.GetWeeklyRecapGroups = function (params, callback) {
            var condition = {
                'Preference.WeeklyRecapEnabled': true,
                Status: 'Active'
            };
            if (params.GroupId) {
                condition.hgId = params.GroupId;
            }

            EntityCache.Group.find(condition, function (error, groups) {
                var today,// = new Date().getDay(),
                    sendRecapDay,
                    todayGroups,
                    weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                if (error) {
                    return callback(error);
                }
                if (!groups.length) {
                    return callback(null, groups);
                }
                todayGroups = groups.filter(function (group) {
                    time.tzset(group.TimeZone);
                    today = new time.Date().getDay();
                    if (!group.Preference || !group.Preference.WeeklyRecapDay) {
                        sendRecapDay = 1;
                    } else {
                        sendRecapDay = weekDays.indexOf(group.Preference.WeeklyRecapDay) + 1;
                    }
                    return sendRecapDay === today;
                });
                if (!params.GroupId) {
                    todayGroups = todayGroups.filter(function (group) {
                        return !group.Preference.FeatureFlags.some(function (ff) {
                            return ff.FeatureName === FeatureFlagEnums.SelectRecapTime && ff.FeatureEnabled;
                        });
                    });
                }
                callback(null, todayGroups);
            });
        };

        this.GetDailyRecapGroups = function (params, callback) {
            EntityCache.Group.find(params.GroupId ? {
                hgId: params.GroupId,
                'Preference.DailyRecapEnabled': true,
                Status: 'Active'
            } : {
                'Preference.DailyRecapEnabled': true,
                Status: 'Active'
            }, function (error, groups) {
                if (error) {
                    return callback(error);
                }
                if (!groups.length) {
                    return callback(null, groups);
                }
                if (!params.GroupId) {
                    groups = groups.filter(function (group) {
                        return !group.Preference.FeatureFlags.some(function (ff) {
                            return ff.FeatureName === FeatureFlagEnums.SelectRecapTime && ff.FeatureEnabled;
                        });
                    });
                }
                callback(null, groups);
            });
        };

        this.SaveCreditSetting = function (params, callback) {
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, function (err, group) {
                if (err) {
                    return callback('server.hge.grp.elg');
                }
                if (!group) {
                    return callback('err.grp.gne');
                }
                var Setting = params.Setting;
                group.CreditSetting.MinTransfer = Setting.MinTransfer || group.CreditSetting.MinTransfer;
                group.CreditSetting.MaxTransfer = Setting.MaxTransfer || group.CreditSetting.MaxTransfer;
                group.CreditSetting.DefaultTransferAmount = Setting.DefaultTransferAmount || group.CreditSetting.DefaultTransferAmount;
                group.CreditSetting.MinRecognition = Setting.MinRecognition || group.CreditSetting.MinRecognition;
                group.CreditSetting.MaxRecognition = Setting.MaxRecognition || group.CreditSetting.MaxRecognition;
                group.CreditSetting.MinSpendAmount = Setting.MinSpendAmount || group.CreditSetting.MinSpendAmount;
                group.CreditSetting.MaxSpendAmount = Setting.MaxSpendAmount || undefined; //allow no value for unlimited max;
                if (group.CreditSetting.MinTransfer > Setting.MaxTransfer) {
                    group.CreditSetting.MinTransfer = Setting.MaxTransfer;
                }
                if (group.CreditSetting.MinRecognition > group.CreditSetting.MaxRecognition) {
                    group.CreditSetting.MinRecognition = group.CreditSetting.MaxRecognition;
                }
                if (group.CreditSetting.MinSpendAmount > group.CreditSetting.MaxSpendAmount) {
                    group.CreditSetting.MinSpendAmount = group.CreditSetting.MaxSpendAmount;
                }
                if (group.CreditSetting.DefaultTransferAmount < Setting.MinTransfer) {
                    group.CreditSetting.DefaultTransferAmount = Setting.MinTransfer;
                }
                if (group.CreditSetting.DefaultTransferAmount > Setting.MaxTransfer) {
                    group.CreditSetting.DefaultTransferAmount = Setting.MaxTransfer;
                }
                group.ModifiedBy = params.UserId;
                group.save(function (err) {
                    if (err) {
                        return callback('server.hge.grp.eug');
                    }
                    PusherManager.CreditLimitsUpdated({GroupId: params.GroupId});
                    callback(null, 'services.cre.ser.clu');
                });
            });
        };

        this.SetCustomerFinance = function (params, callback) {
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, function (err, group) {
                if (err || !group) {
                    return callback('server.hge.grp.elg');
                }
                group.BillMeAllowed = params.BillMeAllowed;
                group.CreditLimit = params.CreditLimit;
                group.RatePerPerson = params.RatePerPerson;
                group.StartBillingDate = params.StartBillingDate;
                group.ModifiedBy = params.UserId;
                group.save(function (err) {
                    if (err) {
                        return callback('business.gro.pro.eugcf');
                    }
                    callback(null, {
                        BillMeAllowed: group.BillMeAllowed,
                        CreditMasterMemberId: group.CreditMasterMemberId
                    });
                });
            });
        };

        this.SetPointMasterMember = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                if (err) {
                    return callback('server.hge.grp.elg');
                }
                if (!group) {
                    return callback('err.grp.gne');
                }
                group.PointMasterMemberId = params.PointMasterMemberId;
                group.ModifiedBy = params.UserId;
                group.save(function (err) {
                    if (err) {
                        return callback('server.hge.grp.espm');
                    }
                    callback(null, true);
                });
            });
        };

        this.SetCreditMasterMember = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                if (err) {
                    return callback(err);
                }
                if (!group) {
                    return callback(err, 'err.grp.gne');
                }

                var prevCreditMasterMemberId = group.CreditMasterMemberId;
                group.CreditMasterMemberId = params.CreditMasterMemberId;
                group.ModifiedBy = params.UserId;
                group.save(function (err) {
                    if (err) {
                        callback('business.gro.pro.esc', null);
                    }
                    callback(null, {
                        PrevCreditMasterMemberId: prevCreditMasterMemberId,
                        BillMeAllowed: group.BillMeAllowed
                    });
                });
            });
        };

        this.ModifyTotalFloatCredit = function (params, callback) {
            EntityCache.Group.findOneAndUpdate({
                hgId: params.GroupId
            }, {
                $inc: {
                    TotalFloatCredit: params.Credits
                }
            }, {
                new: true
            }, function (error, group) {
                if (error) {
                    return callback('business.gro.pro.eumtfc');
                }
                if (!group) {
                    return callback('business.gro.pro.gdne');
                }
                callback(null, group);
            });
        };

        // this will choke the DB eventually if enough companies sign on
        this.GetGroups = function (params, callback) {
            EntityCache.Group.find({}, callback);
        };

        this.GetActiveGroups = function (params, callback) {
            EntityCache.Group.find({
                Status: Enums.GroupStatus.Active
            }, callback);
        };

        this.GetLastFiveCreatedGroups = function (params, callback) {
            EntityCache.Group.find({
                Status: {$in: [Enums.GroupStatus.Active, Enums.GroupStatus.Disabled]}
            })
                .sort({_id: -1})
                .limit(5)
                .exec(callback);
        };

        this.UpdateClusterCache = function (groupId) {
            var ClusterCache = require('../framework/ClusterCache');
            // rebuild the cache
            ClusterCache.init(EntityCache, groupId, function (cc) {
                var timestamp = Date.now(),
                    ClusterMessageEnums = require('../enums/ClusterMessageEnums.js'),
                    HgCache = require('../framework/RedisConnectionCache');
                // push the new cache into memcache
                HgCache.GlobalSet(ClusterMessageEnums.UpdateClusterCache, cc, function (err) {
                    if (err) {
                        return HgLog.info('*** Unable to set value in Redis: ' + err.toString() + ' ***');
                    }
                    // add additional timestamp parameters here
                    HgCache.GlobalSet(ClusterMessageEnums.UpdateCacheTimestamp, {
                        GroupPreferencesTimestamp: timestamp
                    }, function (err) {
                        if (err) {
                            HgLog.info('*** Unable to set value in Redis: ' + err.toString() + ' ***');
                        }
                        // send a message to the cluster master
                        if (process.send) {
                            process.send({
                                cmd: ClusterMessageEnums.UpdateClusterCache,
                                payload: cc,
                                pid: process.pid
                            });
                            process.send({
                                cmd: ClusterMessageEnums.UpdateCacheTimestamp,
                                timestamp: timestamp
                            });
                        }
                    }, ConstantEnums.SECONDS_IN_TWENTY_FOUR_HOURS);
                }, ConstantEnums.SECONDS_IN_TWENTY_FOUR_HOURS);
            });
        };

        this.AddGroup = function (params, callback) {
            EntityCache.Group.findOne({
                HGAccountId: params.HGAccountId
            }, function (error, data) {
                if (error || data) {
                    return callback(error || 'Error Adding a Group that Already Exist:' + data.hgId);
                }
                var group = EntityCache.Group({
                    hgId: guid.v1(),
                    GroupName: params.Name,
                    FriendlyGroupId: params.FriendlyGroupId,
                    CreatedBy: params.CreatedBy,
                    ModifiedBy: params.ModifiedBy,
                    MainAddress: {
                        Address1: params.Address1,
                        Address2: params.Address2,
                        City: params.City,
                        State: params.State,
                        Zip: params.Zip
                    },
                    BillingAddress: {
                        Address1: params.BillingAddress1,
                        Address2: params.BillingAddress2,
                        City: params.BillingCity,
                        State: params.BillingState,
                        Zip: params.BillingZip
                    },
                    HGAccountId: params.HGAccountId,
                    BillingPhone: params.BillingPhone,
                    BillingEmail: params.BillingEmail,
                    BillingRep: params.BillingRep,
                    MainPhone: params.MainPhone,
                    MainFax: params.MainFax,
                    CreditLimit: params.CreditLimit,
                    ValueLevelSetting: {
                        Enabled: false,
                        Levels: DefaultValueLevelEnums.GetAllLevels()
                    },
                    Preference: {
                        SuppressWelcomeBadge: params.HideWelcomeBadge && params.HideWelcomeBadge.toLowerCase() === 'true',
                        FeatureFlags: [
                            {
                                FeatureName: FeatureFlagEnums.MobileAccess,
                                FeatureEnabled: true
                            },
                            {
                                FeatureName: FeatureFlagEnums.EnableTutorials,
                                FeatureEnabled: params.DisableTutorial ? params.DisableTutorial.toLowerCase() === 'false' : true
                            }
                        ]
                    }
                });
                if (params.MultiManager) {
                    group.Preference.FeatureFlags.push({
                        FeatureName: FeatureFlagEnums.MultiManager,
                        FeatureEnabled: true
                    });
                }
                group.BillMeAllowed = params.BillMeAllowed === 'Yes';
                group.save(function (error) {
                    if (error) {
                        return callback(HgError.Enums.Group.ErrorSavingGroup + ': ' + error);
                    }
                    callback(null, group);
                });
            });
        };

        this.GetGroupByName = function (params, callback) {
            EntityCache.Group.findOne({ GroupName:  new RegExp(["^", params.GroupName, "$"].join(""), "i")}, function (error, group) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, group);
                }
            });
        };

        this.UpdateGroup = function (params, callback) {
            var fieldsToUpdate = ProcessorHelper.GetUpdateJson(params.Fields, params.Group, params.UserId);
            EntityCache.Group.update({hgId: params.Group.hgId}, {$set: fieldsToUpdate}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'business.gro.pro.gu');
                }
            });
        };

        //this is a special method used to mass update group name across the whole collections
        this.UpdateGroupName = function (params) {
            EntityCache.Member.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.News.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.Team.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.Invoice.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.Transaction.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.PerformanceCard.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.PerformanceCycle.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.PerformanceReview.update({'Card.GroupId': params.hgId}, {$set: {'Card.GroupName': params.GroupName}}, {multi: true}).exec();
            EntityCache.Congrat.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.CostCenter.update({GroupId: params.hgId}, {$set: {GroupName: params.GroupName}}, {multi: true}).exec();
            EntityCache.UserInfoWithToken.update({'UserContext.CurrentGroupId': params.hgId}, {$set: {'UserContext.CurrentGroupName': params.GroupName}}, {multi: true}).exec();
            //CareerTrack has too many nested objects
            //Potential Performance Issue, CareerTrack has large dataset as each document size is quiet large
            EntityCache.CareerTrack.update({'CreatorMember.GroupId': params.hgId},
                {$set: { 'AssignedMember.GroupName': params.GroupName,
                    'CreatorMember.GroupName': params.GroupName,
                    'CareerTrackTemplate.GroupName': params.GroupName,
                    'CareerTrackTemplate.Goal.RecognitionTemplate.GroupName': params.GroupName}}, {multi: true}).exec();
            EntityCache.CareerTrack.update({'CareerTrackTemplate.MileStones.RecognitionTemplate.GroupId': params.hgId},
                {$set: { 'CareerTrackTemplate.MileStones.$.RecognitionTemplate.GroupName': params.GroupName}}, {$multi: true}).exec();
            EntityCache.CareerTrackTemplate.update({GroupId: params.hgId},
                    {$set: {GroupName: params.GroupName,
                        'Goal.RecognitionTemplate.GroupName': params.GroupName}}, {multi: true}).exec();
            EntityCache.CareerTrackTemplate.update({'MileStones.RecognitionTemplate.GroupId': params.hgId},
                {$set: { 'MileStones.$.RecognitionTemplate.GroupName': params.GroupName}}, {$multi: true}).exec();
            EntityCache.RecognitionTemplate.update({'GroupId': params.hgId},
                    {$set: {'GroupName': params.GroupName}}, {multi: true}).exec();
            EntityCache.Recognition.update({'RecipientMember.GroupId': params.hgId},
                    {$set: {'RecipientMember.GroupName': params.GroupName,
                    'CreatorMember.GroupName': params.GroupName,
                    'Template.GroupName': params.GroupName}}, {multi: true}).exec();
        };

        this.GetCostCentersById = function (params, callback) {
            EntityCache.CostCenter.find({'GroupId': params.GroupId}, function (err, costCenters) {
                if (!err) {
                    callback(null, costCenters);
                } else {
                    callback(err);
                }
            });
        };

        this.SetBannerProps = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                var BannerUrl = (params.BannerUrl === null) ? group.BannerUrl : params.BannerUrl;
                if (err) {
                    callback(err);
                } else {
                    group.BannerUrl = BannerUrl;
                    group.BannerColor = params.BannerColor;
                    group.BannerMotif = params.BannerMotif;
                    group.ModifiedBy = params.UserId;
                    group.save(function (error) {
                        if (error) {
                            callback(HgError.Enums.Group.ErrorSavingGroup + ': ' + error);
                        } else {
                            callback(null, group);
                        }
                    });
                }
            });
        };

        this.SetPubRec = function (params, callback) {
            EntityCache.Group.findOne({hgId: params.GroupId}, function (err, group) {
                var version = '?v=' + Date.now();
                if (err) {
                    callback(err);
                } else {
                    if (params.PubRec.Short) {
                        group.PubRec.Short = params.PubRec.Short + version;
                    }
                    if (params.PubRec.Medium) {
                        group.PubRec.Medium = params.PubRec.Medium + version;
                    }
                    if (params.PubRec.Long) {
                        group.PubRec.Long = params.PubRec.Long + version;
                    }
                    group.ModifiedBy = params.UserId;
                    group.save(function (error) {
                        if (error) {
                            callback(HgError.Enums.Group.ErrorSavingGroup + ': ' + error);
                        } else {
                            callback(null, group);
                        }
                    });
                }
            });
        };

        this.EditCommentInterval = function (params, callback) {
            EntityCache.Group.update({hgId: params.GroupId}, {$set: {
                ModifiedBy: params.UserId,
                'Preference.CommentEditInterval': params.CommentEditInterval
            }}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'business.gro.pro.com');
                }
            });
        };

        this.IsGroupNameUnique = function (params, callback) {
            EntityCache.Group.findOne({
                hgId: { $ne: params.hgId},
                GroupName: params.GroupName
            }, callback);
        };

        this.GetGroupsWithAnniversaryEnabled = function (params, callback) {
            EntityCache.Group.find({'Preference.AnniversaryEmailEnabled': true}, callback);
        };

        this.SaveLanguageSettings = function (params, callback) {
            EntityCache.Group.update({
                hgId: params.GroupId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    ModifiedDate: Date.now(),
                    'Preference.DefaultLanguage': params.DefaultLanguage,
                    'Preference.SupportedLanguages': params.SupportedLanguages
                }
            }, callback);
        };

        this.GetGroupBySFTPFolderName = function (params, callback) {
            EntityCache.Group.findOne({SFTPFolderName: params.SFTPFolderName}, callback);
        };

        this.GetActiveGroupIdsByFeature = function (params, callback) {
            EntityCache.Group.find({
                'Preference.FeatureFlags.FeatureName': params.FeatureName,
                Status: params.Status
            }, params.Fields || null)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.SaveGroupDemoType = function (params, callback) {
            EntityCache.Group.update({
                hgId: params.GroupId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    DemoType: params.DemoType,
                    'Preference.FeatureFlags': params.FeatureFlags
                }
            }, callback);
        };

        this.CheckIfGroupPresent = function (params, callback) {
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, function (error, group) {
                callback(error ? 'server.hge.grp.elg' : null, !!group);
            });
        };

        this.GetBySlug = function (params, callback) {
            EntityCache.Group.findOne({Slug: params.slug}, callback);
        };

        this.UpdateGroupSuppressWelcomeBadgeFlag = function (params, callback) {
            EntityCache.Group.findOneAndUpdate({
                hgId: params.GroupId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    'Preference.SuppressWelcomeBadge': params.SuppressWelcomeMessage
                }
            }, {
                new: true
            }, callback);
        };

        this.DisableKioskSurvey = function (params, callback) {
            EntityCache.Group.update({
                hgId: params.GroupId
            }, {
                $set: {
                    KioskSurveyInProgress: false
                }
            }, callback);
        };
        this.EnableKioskSurvey = function (params, callback) {
            EntityCache.Group.update({
                hgId: params.GroupId
            }, {
                $set: {
                    KioskSurveyInProgress: true
                }
            }, callback);
        };
    };

module.exports = GroupProcessor;
