/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    MemberBookmarkProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid');

        function addMemberBookMark(params, callback) {
            var bookmark = new EntityCache.MemberBookmark(params);
            bookmark.save(callback);
        }
        this.GetMemberBookmarkByMemberId = function (params, callback) {
            EntityCache.MemberBookmark.findOne({MemberId: params.MemberId}, callback);
        };
        this.BookmarkLocation = function (params, callback) {
            EntityCache.MemberBookmark.findOne({MemberId: params.MemberId}, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!data) {
                    return addMemberBookMark({
                        hgId: guid.v1(),
                        MemberId: params.MemberId,
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId,
                        PinnedLocationIds: [params.PinnedLocationId]
                    }, callback);
                }
                EntityCache.MemberBookmark.update({
                    MemberId: params.MemberId
                }, {
                    $set: {
                        ModifiedBy: params.UserId
                    },
                    $addToSet: {
                        PinnedLocationIds: params.PinnedLocationId
                    },
                    $pull: { UnpinnedLocationIds: params.PinnedLocationId }
                }, callback);
            });
        };
        this.UnBookmarkLocation = function (params, callback) {
            EntityCache.MemberBookmark.update({
                MemberId: params.MemberId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                },
                $addToSet: {UnpinnedLocationIds: params.UnpinnedLocationId},
                $pull: {PinnedLocationIds: params.UnpinnedLocationId}
            }, callback);
        };
        this.BookmarkDepartment = function (params, callback) {
            EntityCache.MemberBookmark.findOne({MemberId: params.MemberId}, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    addMemberBookMark({
                        hgId: guid.v1(),
                        MemberId: params.MemberId,
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId,
                        PinnedTeamIds: [params.PinnedTeamId]
                    }, callback);
                } else {
                    EntityCache.MemberBookmark.update({
                        MemberId: params.MemberId
                    }, {
                        $set: {
                            ModifiedBy: params.UserId
                        },
                        $addToSet: {
                            PinnedTeamIds: params.PinnedTeamId
                        },
                        $pull: { UnpinnedTeamIds: params.PinnedTeamId }
                    }, callback);
                }
            });
        };
        this.UnBookmarkDepartment = function (params, callback) {
            EntityCache.MemberBookmark.update({
                MemberId: params.MemberId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                },
                $addToSet: {UnpinnedTeamIds: params.UnpinnedTeamId},
                $pull: {PinnedTeamIds: params.UnpinnedTeamId}
            }, callback);
        };
        this.BookmarkMember = function (params, callback) {
            EntityCache.MemberBookmark.findOne({MemberId: params.MemberId}, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    addMemberBookMark({
                        hgId: guid.v1(),
                        MemberId: params.MemberId,
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId,
                        PinnedMemberIds: [params.PinnedMemberId]
                    }, callback);
                } else {
                    EntityCache.MemberBookmark.update({
                        MemberId: params.MemberId
                    }, {
                        $set: {
                            ModifiedBy: params.UserId
                        },
                        $addToSet: { PinnedMemberIds: params.PinnedMemberId},
                        $pull: { UnpinnedMemberIds: params.PinnedMemberId }
                    }, callback);
                }
            });
        };
        this.UnBookmarkMember = function (params, callback) {
            EntityCache.MemberBookmark.update({
                MemberId: params.MemberId
            }, {
                $set: {
                    ModifiedBy: params.UserId
                },
                $addToSet: {UnpinnedMemberIds: params.UnpinnedMemberId},
                $pull: {PinnedMemberIds: params.UnpinnedMemberId}
            }, callback);
        };
        this.BookmarkFollowedTrackMembers = function (params, callback) {
            EntityCache.MemberBookmark.findOne({MemberId: params.MemberId}, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    addMemberBookMark({
                        hgId: guid.v1(),
                        MemberId: params.MemberId,
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId,
                        FollowedTrackMemberIds: params.FollowedMemberIds
                    }, callback);
                } else {
                    EntityCache.MemberBookmark.update({
                        MemberId: params.MemberId
                    }, {
                        $set: {
                            ModifiedBy: params.UserId,
                            FollowedTrackMemberIds: params.FollowedMemberIds
                        }
                    }, callback);
                }
            });
        };
    };

module.exports = MemberBookmarkProcessor;
