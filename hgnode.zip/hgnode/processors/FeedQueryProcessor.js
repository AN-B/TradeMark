/*jslint node:true es5:true*/
'use strict';
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    EntityCache = require('../framework/EntityCache.js'),
    Enums = require('../enums/EntityEnums.js');


/////WORK INPROGRESS /////
// Isolate core feed queries
// Notes
// 1) Push a lot of processing to mongodb
// 2) remove exccessive loops
// 3)  Schema clean up of Recognition
// 4) Create new feed schema (phase 2)
function getIssuer(obj) {
    var hgId,
        userId,
        fullName,
        companyName,
        email;
    if (obj.PublicCreatorInfo && obj.PublicCreatorInfo.FullName) {
        hgId = '';
        userId = '';
        fullName = obj.PublicCreatorInfo.FullName;
        companyName = obj.PublicCreatorInfo.CompanyName;
        email = obj.PublicCreatorInfo.Email;
    } else if (obj.CreatorMemberId) {
        hgId = obj.CreatorMemberId;
        userId = obj.CreatorMemberUserId;
        fullName = obj.CreatorMemberFullName;
        companyName = obj.CreatorMemberGroupName;
    } else if (obj.TriggerInfo) {
        hgId = obj.GroupId;
        userId = '';
        fullName = 'Rules Engine';
        companyName = obj.TriggerInfo.GroupName;
    }
    return {
        hgId: hgId,
        userId: userId,
        fullName: fullName,
        companyName: companyName,
        email: email
    };
}

function getLevelAchieved(category, levels, name) {
    var levelAchieved = -1;
    if (category === 'Achievement' && levels) {
        levels.forEach(function (obj, ind) {
            if (obj.Name === name) {
                levelAchieved = ind;
                return false;
            }
        });
    }
    return levelAchieved;
}
function recipientIsThe(id, gift) {
    gift.RecipientIds = gift.RecipientIds || [];
    return gift.RecipientIds.indexOf(id) !== -1;
}
function filterGifts(recognition, gift, params) {
    var groupGift = gift.Type === Enums.GiftType.Group,
        senderViewingRecipientRecognition,
        viewerOwnsRecognition,
        senderViewingFromOwnFeed = gift.SenderId === params.ViewerMemberId && params.ViewerMemberId === params.VieweeMemberId;
    senderViewingRecipientRecognition = gift.SenderId === params.ViewerMemberId && recipientIsThe(params.VieweeMemberId, gift);
    viewerOwnsRecognition =  params.ViewerMemberId === params.VieweeMemberId && recipientIsThe(params.ViewerMemberId, gift);
    return recognition.recipients.length === 1 || groupGift || senderViewingFromOwnFeed || senderViewingRecipientRecognition || viewerOwnsRecognition;
}

function isUserTiedToRecognition(userId, feed) {
    var issuerMatch = feed.issuer.userId === userId,
        recipientMatch,
        i;
    for (i = 0; i < feed.recipients.length; i += 1) {
        if (feed.recipients[i].userId === userId) {
            recipientMatch = true;
            break;
        }
    }
    return (recipientMatch || issuerMatch);
}

function processQuery(params, callback) {
    var recipientIds = [],
        group,
        matchCondition = params.Query || {},
        aggregatedQueryParam;
    if (params.MemberVisibilityCondtion) {
        matchCondition.$and = [{$or: params.MemberVisibilityCondtion}];
    }
    if (params.LocCondition) {
        if (!matchCondition.$and) {
            matchCondition.$and = [];
        }
        matchCondition.$and.push({$or: params.LocCondition});
    }
    if (params.RelevantMemberIds && params.RelevantMemberIds.length) {
        matchCondition.RandCId = {$in: params.RelevantMemberIds};
    }
    aggregatedQueryParam = [
        {$match: matchCondition},
        {$group: {
            _id: '$BatchId',
            max: {$max: '$ModifiedDate'}
        }},
        {$sort: {max: -1}},
        {$skip: parseInt(params.Skip, 10) || 0},
        {$limit: parseInt(params.Take, 10) || 10},
        {$project: { _id: 0, BatchId: "$_id"}}
    ];
    EntityCache.Recognition.aggregate(aggregatedQueryParam, function (error, batchIdResult) {
        if (error) {
            return callback('server.hge.rec.elr');
        }
        if (!batchIdResult || !batchIdResult.length) {
            return callback(null, {feeds: []});
        }
        group = {
            _id: {
                BatchId: "$BatchId"
            },
            hgId:  {$addToSet: '$hgId'},
            batchId: {$first: '$BatchId'},
            GroupId: {$first: '$Template.GroupId'},
            PublicCreatorInfo: {$first: '$PublicCreatorInfo'},
            CreatorMemberId: {$first: '$CreatorMember.hgId'},
            CreatorMemberFullName: {$first: '$CreatorMember.FullName'},
            CreatorMemberStatus: {$first: '$CreatorMember.MembershipStatus'},
            CreatorMemberUserId: {$first: '$CreatorMember.UserId'},
            CreatorMemberGroupName: {$first:  '$CreatorMember.GroupName'},
            TriggerInfo: {$first: '$TriggerInfo'},
            TemplateId:  { $first: '$Template.hgId' },
            FriendlyGroupId:  { $first: '$Template.FriendlyGroupId' },
            BadgeFileName:  { $first: '$BadgeFilename' },
            recipientIds: {$addToSet: '$RecipientMember.hgId'},
            recipients: {$addToSet: {
                hgId: '$RecipientMember.hgId',
                status: '$RecipientMember.MembershipStatus',
                userId: '$RecipientMember.UserId',
                fullName: '$RecipientMember.FullName',
                manager: '$RecipientMember.MyManagers',
                role: '$RecipientMember.RolesInGroup',
                dpt: '$RecipientMember.GroupDepartmentName'
            }},
            createdDate: {$first: '$CreatedDate'},
            modifiedDate: {$max: '$ModifiedDate'},
            suppressInFeed: { $first: '$SuppressInFeed' },
            message: { $first: '$Message' },
            messageEdited: { $first: '$MessageEdited' },
            description: { $first: '$Template.Description' },
            title: { $first: '$Template.Title' },
            type: { $first: '$Template.Type' },
            congratMemberIds:  { $first: '$CongratMemberIds' },
            dismissMemberIds:  { $first: '$DismissMemberIds' },
            ShareCount: { $max: "$ShareCount" },
            shareCount: { $max: "$ShareCount" },
            commentCount: { $max: "$CommentCount" },
            congratsCount: { $max: "$CongratsCount" },
            actualPointValue: { $max: "$ActualPointValue" },
            actualCreditValue: { $max: "$ActualCreditValue" },
            category: { $first: '$Template.Category' },
            levels: { $first: '$Template.Levels' },
            SubValue: { $first: '$SubValue' },
            subValues: { $first: '$Template.SubValues' },
            sticky: { $first: '$Sticky' },
            levelName: { $first: '$LevelName' },
            gifts: { $first: '$Gifts' },
            visibilityMemberIds: { $first: '$VisibilityMemberIds'},
            visibilityLocations: { $first: '$VisibilityLocations'},
            itemId: {$first: '$ItemId'},
            krUpdates: {$first: '$KrUpdates'},
            pollResult: {$first: '$PollResult'}
        };
        EntityCache.Recognition.aggregate([
            {$match: {BatchId: { $in: batchIdResult.map(function (item) { return item.BatchId; })}}},
            {$group: group},
            {$sort: {modifiedDate: -1}}
        ], function (error, recognitionResult) {
            if (error) {
                return callback('server.hge.rec.elr');
            }
            recognitionResult.forEach(function (item) {
                recipientIds = recipientIds.concat(item.recipientIds);
                if (item.congratMemberIds.length) {
                    recipientIds = recipientIds.concat(item.congratMemberIds);
                }
                if (item.CreatorMemberId) {
                    recipientIds.push(item.CreatorMemberId);
                }
            });
            recognitionResult.forEach(function (item) {
                item.recipients = item.recipients.map(function (rItem) {
                    rItem.managerId = rItem.manager && rItem.manager.length ? rItem.manager[0].UserId : null;
                    rItem.role = rItem.role.length ? rItem.role[0] : '';
                    delete rItem.manager;
                    return rItem;
                });
                item.dismissMemberIds = item.dismissMemberIds || [];
                item.congratMemberIds = item.congratMemberIds || [];
                item.teamRecognition = item.recipients.length > 1;
                item.comments = [];
                item.issuer = getIssuer(item);
                if (item.CreatorMemberId) {
                    item.issuer.status = item.CreatorMemberStatus;
                }
                item.isPublic = item.PublicCreatorInfo && item.PublicCreatorInfo.FullName && item.PublicCreatorInfo.FullName.length;
                item.creditValue = 0;
                item.pointValue = 0;
                item.onTop = item.sticky && !item.meDismissed;
                item.levelAchieved = -1;
                item.title = item.SubValue ? [item.SubValue, ' (', item.title, ')'].join('') : item.title;
                item.levelAchieved = getLevelAchieved(item.category, item.levels, item.levelName);
                item.badgeUrl = ['/badges/group/', item.FriendlyGroupId, '/', item.BadgeFileName].join('');
                item.actualCreditValue = !isUserTiedToRecognition(params.UserId, item) ? 0 : item.actualCreditValue;
                item.actualPointValue = !params.ShowPointsInFeed && !isUserTiedToRecognition(params.UserId, item) ? 0 : item.actualPointValue;
                if (params.ApplymarkRecognitionsCongratByMe) {
                    if (item.congratMemberIds.length) {
                        item.MeCongrated = item.congratMemberIds.indexOf(params.VieweeMemberId) > -1 ||
                            item.congratMemberIds.indexOf(params.ViewerMemberId) > -1;
                    }
                    item.MeDismissed = item.dismissMemberIds.length ? item.dismissMemberIds.indexOf(params.ViewerMemberId) > -1 : false;
                }
                item.gifts = item.gifts || [];

                item.gifts = item.gifts.filter(function (gift) {
                    return filterGifts(item, gift, {
                        ViewerMemberId: params.ViewerMemberId,
                        VieweeMemberId: params.VieweeMemberId
                    });
                });
                if (!item.pollResult) {
                    delete item.pollResult;
                }
                if (!item.itemId) {
                    delete item.itemId;
                }
                delete item.PublicCreatorInfo;
                delete item.CreatorMemberId;
                delete item.CreatorMemberFullName;
                delete item.CreatorMemberUserId;
                delete item.CreatorMemberGroupName;
                delete item.TriggerInfo;
                delete item.BadgeFileName;
                delete item.FriendlyGroupId;
                delete item.GroupId;
                delete item.recipientIds;
                delete item.congratMemberIds;
            });
            callback(null, {feeds: recognitionResult});
        });
    });
}
module.exports = {
    processQuery: processQuery
};