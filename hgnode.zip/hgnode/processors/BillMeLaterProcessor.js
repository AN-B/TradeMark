/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    BillMeLaterProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventResponder = require('../util/EventResponder.js');

        this.BillMePayment = function (params) {
            var creditQuantity = params.CreditQuantity;
            if (params.WhomToBuy !== 'MyGroup') {
                EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.pay.pmna');
            } else {
                EntityCache.Group.findOne({'hgId' : params.GroupId}, function (err, group) {
                    if (err || !group) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.grp.elg');
                    } else {
                        if (group.BillMeAllowed !== true || group.CreditMasterMemberId !== params.MemberId) {
                            EventResponder.RespondWithError(EventEmitterCache, params, 'server.hge.pay.pmna');
                        } else {
                            if (creditQuantity + group.TotalFloatCredit > group.CreditLimit && group.CreditLimit !== -1) {
                                EventResponder.RespondWithError(EventEmitterCache, params,  'server.hge.pay.ecl');
                            } else {
                                group.ModifiedBy = params.UserId;
                                group.TotalFloatCredit += creditQuantity;
                                group.save();
                                EventResponder.RespondWithData(EventEmitterCache, params, {
                                    TransactionResult : 'Approved',
                                    TransactionId : 'BillMePayment'
                                });
                            }
                        }
                    }
                });
            }
        };
    };

module.exports = BillMeLaterProcessor;
