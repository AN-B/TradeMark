/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    FeedbackCardProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            EntityEnums = require('../enums/EntityEnums.js'),
            FeedbackEnums = require('../enums/FeedbackEnums.js'),
            ConstantEnums = require('../enums/ConstantEnums.js'),
            MemberEnums = require('../enums/MemberEnums.js'),
            guid = require('node-uuid'),
            async = require('async'),
            activeInitiatorStatus = [
                FeedbackEnums.CycleInitiatorStatus.NotStarted,
                FeedbackEnums.CycleInitiatorStatus.Requesting,
                FeedbackEnums.CycleInitiatorStatus.InProgress
            ];

        this.SaveCycle = function (params, callback) {
            EntityCache.FeedbackCycle.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.CycleRequest.hgId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Title: params.CycleRequest.Title,
                    Type: params.CycleRequest.Type,
                    Description: params.CycleRequest.Description || '',
                    CardId: params.CycleRequest.CardId,
                    CardTitle: params.CycleRequest.CardTitle,
                    AdminNote: params.CycleRequest.AdminNote || '',
                    Note: params.CycleRequest.Note || '',
                    IsPrivate: params.CycleRequest.IsPrivate
                },
                $setOnInsert: {
                    hgId: guid.v1(),
                    GroupId: params.GroupId,
                    GroupName: params.GroupName,
                    CreatedBy: params.UserId,
                    CreatedDate: Date.now(),
                    Status: FeedbackEnums.CycleStatus.Draft,
                    TriggerType: FeedbackEnums.TriggerType.RequestAnytime,
                    Workflow: FeedbackEnums.Workflow.Direct,
                    CycleOwner: {
                        MemberId: params.MemberId,
                        UserId: params.UserId,
                        FullName: params.FullName
                    }
                }
            }, {
                upsert: true,
                setDefaultsOnInsert: true,
                new: true
            }, callback);
        };

        this.GetStagedInitiatorsByClusterId = function (params, callback) {
            EntityCache.StagedInitiator.find({
                ClusterId: params.ClusterId,
                GroupId: params.GroupId
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.RemoveStagedInitiators = function (params, callback) {
            EntityCache.StagedInitiator.remove({
                hgId: {$in: params.StagedInitiatorIds}
            }, callback);
        };

        this.StageInitiators = function (params, callback) {
            var stagedInitiators = Object.keys(params.MemberIdsHash).map(function (memberId) {
                return {
                    ClusterId: params.ClusterId,
                    GroupId: params.GroupId,
                    MemberId: memberId,
                    hgId: guid.v1(),
                    CreatedBy: params.UserId,
                    ModifiedBy: params.UserId
                };
            });
            EntityCache.StagedInitiator.create(stagedInitiators, callback);
        };

        this.GetTotalDeliveryDueInitiatoryCycleId = function (params, callback) {
            EntityCache.FeedbackCycle.findOne({
                GroupId: params.GroupId,
                hgId: params.CycleId,
                Status: {$in: [
                    FeedbackEnums.CycleStatus.Pending,
                    FeedbackEnums.CycleStatus.InProgress,
                    FeedbackEnums.CycleStatus.Scheduled
                ]}
            }, function (error, cycle) {
                if (error || !cycle) {
                    return callback('Error loading the cycle, or it has been deleted: ' + params.CycleId);
                }
                EntityCache.FeedbackCycleInitiator.count({
                    CycleId: params.CycleId,
                    DeliveryDate: {$lte: Date.now()},
                    Status: FeedbackEnums.CycleInitiatorStatus.PendingDelivery
                }, callback);
            });
        };

        this.LoadDeliveryDueInitiatorsByCycleIdBatch = function (params, callback) {
            EntityCache.FeedbackCycle.findOne({
                GroupId: params.GroupId,
                hgId: params.CycleId,
                Status: {$in: [
                    FeedbackEnums.CycleStatus.Pending,
                    FeedbackEnums.CycleStatus.InProgress,
                    FeedbackEnums.CycleStatus.Scheduled
                ]}
            }, function (error, cycle) {
                if (error || !cycle) {
                    return callback(error);
                }
                if (!cycle) {
                    return callback("Error loading cycle");//ESB, no loc
                }
                EntityCache.FeedbackCycleInitiator.find({
                    CycleId: params.CycleId,
                    DeliveryDate: {$lte: Date.now()},
                    Status: FeedbackEnums.CycleInitiatorStatus.PendingDelivery
                })
                    .skip(parseInt(params.Skip, 10) || 0)
                    .limit(parseInt(params.Take, 10) || 0)
                    .exec(function (error, initiators) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, initiators.map(function (initiator) {
                            return {
                                CycleId: cycle.hgId,
                                CycleTitle: cycle.Title,
                                GroupId: cycle.GroupId,
                                Notes: cycle.Notes,
                                Initiator: initiator,
                                AdminUserId: cycle.CycleOwner.UserId,
                                Note: cycle.Note
                            };
                        }));
                    });
            });
        };

        this.UpdateIntiatorStatus = function (params, callback) {
            var updateObject = {
                Status: params.NewStatus,
                ModifiedBy: params.UserId
            };
            if (params.ClosedDate) {
                updateObject.ClosedDate = params.ClosedDate;
            }
            if (params.LastAnsweredSessionId) {
                updateObject.LastAnsweredSessionId = params.LastAnsweredSessionId;
            }
            EntityCache.FeedbackCycleInitiator.update({
                hgId: params.InitiatorId,
                GroupId: params.GroupId
            }, {
                $set: updateObject
            }, callback);
        };

        this.UpdateTalentInsightInitiatorStatus = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.findOne({
                hgId: params.InitiatorId,
                GroupId: params.GroupId
            }, function (error, data) {
                if (error || !data) {
                    return callback('tal.err.emc');
                }
                if (data.Status !== FeedbackEnums.CycleInitiatorStatus.Closed) {
                    data.Status = params.NewStatus;
                    data.ClosedDate = params.ClosedDate;
                }
                if (params.LastAnsweredSessionId) {
                    data.LastAnsweredSessionId = params.LastAnsweredSessionId;
                }
                data.ModifiedBy = params.UserId;
                data.save(callback);
            });
        };
        this.UpdateInitiatorByManagerCheckIn = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.update({
                hgId: params.InitiatorId,
                GroupId: params.GroupId
            }, {
                $set: {
                    Status: FeedbackEnums.CycleInitiatorStatus.InProgress,
                    LastInitiateDate: Date.now(),
                    ModifiedBy: params.UserId
                }
            }, callback);
        };

        this.UpdateInitiatorByRequest = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.update({
                hgId: params.InitiatorId,
                GroupId: params.GroupId
            }, {
                $set: {
                    Status: FeedbackEnums.CycleInitiatorStatus.InProgress,
                    LastInitiateDate: Date.now(),
                    ModifiedBy: params.UserId
                }
            }, callback);
        };
        this.SearchLibrary = function (params, callback) {
            var query = {
                GroupId: params.GroupId
            },
                secondQuery = {};
            if (params.SearchTerm) {
                query.$or = [
                    {Title: {$regex: params.SearchTerm, $options: 'i'}},
                    {Description: {$regex: params.SearchTerm, $options: 'i'}}
                ];
            }
            if (params.Types && params.Types.length) {
                query.CycleType = {$in: params.Types};
            }
            if (params.DepartmentId) {
                query['Criteria.DepartmentId'] = { $in: [ EntityEnums.All, params.DepartmentId]};
            }
            if (params.LocationId) {
                query['Criteria.LocationId'] = { $in: [ EntityEnums.All, params.LocationId]};
            }
            if (params.LevelId) {
                query['Criteria.Level'] = { $in: [ EntityEnums.All, params.LevelId]};
            }
            EntityCache.FeedbackCycleCluster.find(query)
                .exec(function (error, data) {
                    if (error) {
                        return callback(error);
                    }
                    if (!data.length) {
                        return callback(null, []);
                    }
                    secondQuery = {
                        Status: {$in: params.Status},
                        hgId: { $in: data.map(function (item) { return item.CycleId; })}
                    };
                    if (params.Types && params.Types.length) {
                        secondQuery.Type = {$in: params.Types};
                    }
                    EntityCache.FeedbackCycle.find(secondQuery)
                        .sort({_id: -1})
                        .skip(parseInt(params.Skip, 10) || 0)
                        .limit(parseInt(params.Take, 10) || 0)
                        .exec(callback);
                });
        };
        this.GetSuccessionPlanningResults = function (params, callback) {
            EntityCache.FeedbackCycle.find({
                GroupId: params.GroupId,
                Type: FeedbackEnums.CycleType.SuccessionPlanning,
                Status: {$in: [
                    FeedbackEnums.CycleStatus.InProgress,
                    FeedbackEnums.CycleStatus.Closed
                ]}
            })
                .sort({_id: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetReviewerCandidate = function (params, callback) {
            var excludeMemberIds = [params.MemberId],
                condition = {
                    GroupId: params.GroupId,
                    MembershipStatus: MemberEnums.Status.Active,
                    Name: {$regex: params.SearchTerm, $options: 'i'}
                };
            if (params.Selected && params.Selected.length) {
                excludeMemberIds = excludeMemberIds.concat(params.Selected.map(function (s) {
                    return s.Id;
                }));
            }
            condition.MemberId = {$nin: excludeMemberIds};
            EntityCache.FeedbackCycleInitiator.find(condition)
                .sort({Name: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 10)
                .exec(callback);
        };
        this.GetCycles = function (params, callback) {
            var query = {
                GroupId: params.GroupId
            },
                fields = params.Fields || {};
            if (params.Status) {
                query.Status = {$in: params.Status};
            }
            EntityCache.FeedbackCycle.find(query, fields)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetSuccessionPlanningOverview = function (params, callback) {
            var overview = {
                NewSuccessionPlanning: 0,
                ArchivedSuccessionPlanning: 0
            };
            EntityCache.FeedbackCycleInitiator.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    MemberId: params.MemberId,
                    CycleType: FeedbackEnums.CycleType.SuccessionPlanning
                }},
                {$group: {
                    _id: {s: "$Status"},
                    count: {$sum: 1}
                }},
                {$project: {
                    _id: 0,
                    NotStarted: {$cond: { if: { $eq: [ "$_id.s", 'NotStarted' ] }, then: "$count", else: 0 }},
                    InProgress: {$cond: { if: { $eq: [ "$_id.s", 'InProgress' ] }, then: "$count", else: 0 }},
                    Closed: {$cond: { if: { $eq: [ "$_id.s", 'Closed' ] }, then: "$count", else: 0 }}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    overview.NewSuccessionPlanning += item.NotStarted + item.InProgress;
                    overview.ArchivedSuccessionPlanning += item.Closed;
                });
                callback(null, overview);
            });
        };
        //TODO: Delete
        this.GetNewSuccessionPlanning = function (params, callback) {
            var query = {
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                CycleType: FeedbackEnums.CycleType.SuccessionPlanning,
                Status: {$in: [
                    FeedbackEnums.CycleInitiatorStatus.NotStarted,
                    FeedbackEnums.CycleInitiatorStatus.InProgress
                ]}
            };
            if (params.SearchTerm) {
                query.CycleTitle = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.FeedbackCycleInitiator.find(query)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };
        this.CloseSuccessionCycle = function (params, callback) {
            async.parallel({
                cycle: function (fcallback) {
                    EntityCache.FeedbackCycle.update({
                        GroupId: params.GroupId,
                        hgId: params.CycleId
                    }, {
                        $set: {
                            Status: FeedbackEnums.CycleStatus.Closed
                        }
                    }, fcallback);
                },
                cycleIntiator: function (fcallback) {
                    EntityCache.FeedbackCycleInitiator.update({
                        GroupId: params.GroupId,
                        CycleId: params.CycleId,
                        Status: {$in: [
                            FeedbackEnums.CycleInitiatorStatus.NotStarted,
                            FeedbackEnums.CycleInitiatorStatus.InProgress
                        ]}
                    }, {
                        $set: {
                            Status: FeedbackEnums.CycleInitiatorStatus.Closed
                        }
                    }, {
                        multi: true
                    }, fcallback);
                }
            }, callback);
        };
        //ToDo Delete
        this.GetArchivedSuccessionPlanning = function (params, callback) {
            var query = {
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                CycleType: FeedbackEnums.CycleType.SuccessionPlanning,
                Status: FeedbackEnums.CycleInitiatorStatus.Closed
            };
            if (params.SearchTerm) {
                query.CycleTitle = {$regex: params.SearchTerm, $options: 'i'};
            }
            EntityCache.FeedbackCycleInitiator.find(query)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };
        this.GetCycleInitiatorsByMemberId = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.find({
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                CycleType: {$in: params.CycleType || [FeedbackEnums.CycleType.Request, FeedbackEnums.CycleType.EvaluateOthers]},
                Status: {$in: activeInitiatorStatus}
            }).skip(parseInt(params.Skip, 10) || 0)
                  .limit(parseInt(params.Take, 10) || 0)
                  .exec(callback);
        };
        this.GetCycleInitiatorsNumberByMemberId = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.count({
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                CycleType: params.CycleType,
                Status: {$in: activeInitiatorStatus}
            }, callback);
        };

        this.GetCycleInitiatorsByMemberIdCycleIds = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.find({
                CycleId: {$in: params.CycleIds},
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                Status: {$in: activeInitiatorStatus}
            }, callback);
        };

        this.GetCycleInitiatorByMemberIdCycleId = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.findOne({
                CycleId: params.CycleId,
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                Status: {$in: activeInitiatorStatus}
            }, callback);
        };

        this.GetCycleInitiatorByInitiatorId = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.findOne({
                hgId: params.InitiatorId,
                GroupId: params.GroupId,
                MemberId: params.MemberId
            }, callback);
        };

        this.SetSkipGiveInstruction = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.findOneAndUpdate({
                CycleId: params.CycleId,
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                Status: {$in: activeInitiatorStatus}
            }, {
                $set: {SkipGiveInstruction: params.Dst}
            }, {
                new: true
            }, callback);
        };

        this.UnsetTipGivePending = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.findOneAndUpdate({
                CycleId: params.CycleId,
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                Status: {$in: activeInitiatorStatus}
            }, {
                $set: {TipGivePending: false}
            }, {
                new: true
            }, callback);
        };

        this.AddBatchCycleInitiators = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.create(params, callback);
        };

        this.AddSingleCycleInitiator = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.findOne({
                GroupId: params.GroupId,
                CycleId: params.CycleId,
                MemberId: params.MemberId
            }, function (error, cycleIntiator) {
                if (error) {
                    return callback(error);
                }
                if (cycleIntiator) {
                    return callback(null, cycleIntiator);
                }
                cycleIntiator = new EntityCache.FeedbackCycleInitiator(params);
                cycleIntiator.save(callback);
            });
        };

        this.SaveCycleCluster = function (params, callback) {
            EntityCache.FeedbackCycleCluster.findOneAndUpdate({
                GroupId: params.GroupId,
                CycleId: params.CycleId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Criteria: params.Criteria
                },
                $setOnInsert: {
                    hgId: guid.v1(),
                    GroupId: params.GroupId,
                    CycleId: params.CycleId,
                    Title: params.Title,
                    Description: params.Description,
                    CreatedBy: params.UserId,
                    CreatedDate: Date.now(),
                    Status: FeedbackEnums.ClusterStatus.Pending,
                    CycleType: params.CycleType
                }
            }, {
                upsert: true,
                new: true
            }, callback);
        };

        this.GetCycleById = function (params, callback) {
            var query = {
                hgId: params.CycleId,
                GroupId: params.GroupId
            };
            if (params.Status) {
                query.Status = {$in: params.Status};
            }
            EntityCache.FeedbackCycle.findOne(query).lean().exec(callback);
        };

        this.GetCycleClusterById = function (params, callback) {
            EntityCache.FeedbackCycleCluster.findOne({hgId: params.CycleClusterId, GroupId: params.GroupId}, callback);
        };

        this.GetClustersByCycleId = function (params, callback) {
            var condition = {
                    CycleId: params.CycleId,
                    GroupId: params.GroupId
                };
            if (params.Status) {
                condition.Status = params.Status;
            }
            EntityCache.FeedbackCycleCluster.findOne(condition, callback);
        };
        this.UpdateCycleClusterStatus = function (params, callback) {
            EntityCache.FeedbackCycleCluster.update({
                hgId: params.CycleClusterId,
                GroupId: params.GroupId
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, callback);
        };
        this.UpdateCycleStatus = function (params, callback) {
            var updateObject = {
                Status: params.NewStatus,
                ModifiedBy: params.UserId
            };
            if (params.ClosedDate) {
                updateObject.ClosedDate = params.ClosedDate;
            }
            if (params.ArchivedDate) {
                updateObject.ArchivedDate = params.ArchivedDate;
            }
            EntityCache.FeedbackCycle.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.CycleId
            }, {
                $set: updateObject
            }, {
                new: true
            }, callback);
        };
        this.UpdateCycleClusterByCycleId = function (params, callback) {
            EntityCache.FeedbackCycleCluster.update({
                CycleId: params.CycleId,
                GroupId: params.GroupId
            }, {
                $set: {
                    Title: params.Title,
                    Description: params.Description,
                    CycleType: params.CycleType
                }
            }, callback);
        };
        this.UpdateCycleTips = function (params, callback) {
            var update = {
                ModifiedBy: params.UserId
            };
            update[params.Type] = params.TrainingPDFType;
            update[params.Type + 'FileName'] = params.FileName || '';
            EntityCache.FeedbackCycle.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.CycleId
            }, {
                $set: update
            }, callback);
        };
        this.UpdateCycleDeliverySettings = function (params, callback) {
            var updateObject = {};
            if (FeedbackEnums.CycleType.SelfEvaluation === params.Type) {
                updateObject.InitiatorSetting = params.InitiatorSetting;
                updateObject.SubjectSignOff = params.SubjectSignOff;
                updateObject.ReviewerSignOff = params.ReviewerSignOff;
                updateObject.ShowManagerNotes = params.ShowManagerNotes;
            } else {
                updateObject.NotifyInitiator = params.NotifyInitiator;
                updateObject.ExpireRequestDays = params.ExpireRequestDays || FeedbackEnums.Default.ExpireRequestDays;
            }
            EntityCache.FeedbackCycle.findOneAndUpdate({
                GroupId: params.GroupId,
                hgId: params.CycleId
            }, {
                $set: updateObject
            }, callback);
        };
        this.ArchiveCycleClusterByCycleId = function (params, callback) {
            EntityCache.FeedbackCycleCluster.update({
                CycleId: params.CycleId,
                GroupId: params.GroupId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Status: FeedbackEnums.ClusterStatus.Archived
                }
            }, callback);
        };
        this.ArchiveOrCloseCycleInitiators = function (params, callback) {
            EntityCache.FeedbackCycleInitiator.update({
                CycleId: params.CycleId,
                GroupId: params.GroupId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    Status: params.NewStatus
                }
            }, {
                multi: true
            }, callback);
        };
        this.GetInactiveUsers = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                LastInitiateDate: {$lte: Date.now() - ConstantEnums.NINETY_DAYS}
            }, aggregateParam;
            if (params.CycleId) {
                query.CycleId = params.CycleId;
            }
            if (params.DepartmentId) {
                query.DepartmentId = params.DepartmentId;
            }
            if (params.LocationId) {
                query.LocationId = params.LocationId;
            }
            if (params.LevelId) {
                query.Role = params.LevelId;
            }
            aggregateParam = [
                {$match: query},
                {$group: {
                    _id: {
                        hgId: "$MemberId",
                        Name: "$Name",
                        DepartmentName: "$DepartmentName"
                    },
                    Data: {$addToSet: "$Status"},
                    LastRequestedDate: {$max: "$LastInitiateDate"}
                }},
                {$project: {
                    _id: 0,
                    hgId: "$_id.hgId",
                    Name: "$_id.Name",
                    DepartmentName: "$_id.DepartmentName",
                    LastRequestedDate: "$LastRequestedDate",
                    Detail: "$Data"
                }},
                {$sort: { LastRequestedDate: 1}}
            ];
            if (params.Take) {
                aggregateParam.push({$skip: parseInt(params.Skip, 10) || 0});
                aggregateParam.push({$limit: parseInt(params.Take, 10) || 10});
            }
            EntityCache.FeedbackCycleInitiator.aggregate(aggregateParam, callback);
        };
        this.GetFeedbackGuide = function (params, callback) {
            EntityCache.FeedbackGuide.findOne({
                GroupId: params.GroupId,
                Type: params.Type
            }, callback);
        };

        this.ScheduleTalentCycle = function (params, callback) {
            var feedCycle = EntityCache.FeedbackCycle(params);
            feedCycle.save(callback);
        };

        this.GetTalentCycles = function (params, callback) {
            EntityCache.FeedbackCycle.find({
                GroupId: params.GroupId,
                Type: FeedbackEnums.CycleType.TalentInsight,
                Status: {$in: [
                    FeedbackEnums.CycleStatus.Scheduled,
                    FeedbackEnums.CycleStatus.InProgress
                ]}
            })
                .sort({_id: -1})
                .skip(parseInt(params.Skip || 0, 10))
                .limit(parseInt(params.Take || 10, 10))
                .exec(callback);
        };

        this.DeleteTalentCycle = function (params, callback) {
            async.parallel({
                cycle: function (fcallback) {
                    EntityCache.FeedbackCycle.update({
                        GroupId: params.GroupId,
                        hgId: params.CycleId
                    }, {
                        $set: {
                            Status: FeedbackEnums.CycleStatus.Archived,
                            ModifiedBy: params.UserId
                        }
                    }, fcallback);
                },
                initiator: function (fcallback) {
                    EntityCache.FeedbackCycleInitiator.update({
                        GroupId: params.GroupId,
                        CycleId: params.CycleId
                    }, {
                        $set: {
                            Status: FeedbackEnums.CycleInitiatorStatus.Archived,
                            ModifiedBy: params.UserId
                        }
                    }, {
                        multi: true
                    }, fcallback);
                },
                session: function (fcallback) {
                    EntityCache.FeedbackSession.update({
                        GroupId: params.GroupId,
                        CycleId: params.CycleId
                    }, {
                        $set: {
                            Status: FeedbackEnums.SessionStatus.Archived,
                            ModifiedBy: params.UserId
                        }
                    }, fcallback);
                }
            }, callback);
        };

        this.LockTalentCycle = function (params, callback) {
            EntityCache.FeedbackCycle.update({
                hgId: params.CycleId
            }, {
                $set: {
                    Locked: true,
                    UserId: params.UserId
                }
            }, callback);
        };

        this.UnLockTalentCycle = function (params, callback) {
            EntityCache.FeedbackCycle.update({
                hgId: params.CycleId
            }, {
                $set: {
                    Locked: false,
                    UserId: params.UserId
                }
            }, callback);
        };

        this.UpdateTalentCycle = function (params, callback) {
            EntityCache.FeedbackCycle.update({
                hgId: params.CycleId
            }, {
                $set: {
                    Title: params.Title,
                    'InitiatorSetting.DeliveryDate': params.StartDate,
                    ModifiedBy: params.UserId
                }
            }, callback);
        };

        this.GetManagerTalentCycles = function (params, callback) {
            var cyclesIndex = {};
            EntityCache.FeedbackCycleInitiator.find({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                CycleType: FeedbackEnums.CycleType.TalentInsight,
                Status: {$in: [
                    FeedbackEnums.CycleInitiatorStatus.NotStarted,
                    FeedbackEnums.CycleInitiatorStatus.InProgress,
                    FeedbackEnums.CycleInitiatorStatus.Closed
                ]}
            }).sort({_id: -1}).exec(function (error, initiators) {
                if (error) {
                    return callback('tal.err.rmc');
                }
                if (!initiators.length) {
                    return callback();
                }
                EntityCache.FeedbackCycle.find({ hgId: {$in: initiators.map(function (item) { return item.CycleId; })} }, { hgId: 1, Locked: 1}, function (error, cycles) {
                    if (error) {
                        return callback(error);
                    }
                    cycles.forEach(function (cycle) {
                        cyclesIndex[cycle.hgId] = cycle.Locked;
                    });
                    callback(null, {
                        ManagerCycles: initiators,
                        Cycles: cyclesIndex
                    });
                });
            });
        };
    };

module.exports = FeedbackCardProcessor;
