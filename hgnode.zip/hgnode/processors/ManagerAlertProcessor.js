/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ManagerAlert = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var guid = require('node-uuid'),
            Async = require('async'),
            EntityEnums = require('../enums/EntityEnums.js'),
            EntityCache = require('../framework/EntityCache.js'),
            HgLog = require('../framework/HgLog.js'),
            DateField = {
                Birthdate: 'Birthdate',
                StartingDate: 'StartingDate'
            },
            THIRTY_DAYS = 2592000000,
            self = this;

        function getManagerId(reportMemberId, memberManagers) {
            if (!memberManagers) {
                return '';
            }
            var data = memberManagers.find(function (item) {
                return reportMemberId === item.hgId;
            });
            return (data &&
                    data.MyManagers &&
                    data.MyManagers.length) ? data.MyManagers[0].MemberId : '';
        }
        function addUpdateManagerAlert(params, callback) {
            EntityCache.ManagerAlert.findOne(params.Query, function (error, managerAlertRecord) {
                if (error) {
                    return callback(error);
                }
                if (!managerAlertRecord) {
                    managerAlertRecord = new EntityCache.ManagerAlert();
                    managerAlertRecord.hgId = guid.v1();
                }
                managerAlertRecord.GroupId = params.GroupId;
                managerAlertRecord.Status = params.Status || EntityEnums.ManagerAlertStatus.Active;
                managerAlertRecord.ManagerMemberId = getManagerId(params.ReportMemberId, params.MemberManagers);
                managerAlertRecord.ReportMemberId = params.ReportMemberId;
                managerAlertRecord.Category = params.Category;
                managerAlertRecord.AlertType = params.AlertType;
                managerAlertRecord.Severity = params.Severity;
                managerAlertRecord.Data = params.Data;
                managerAlertRecord.save(function (error) {
                    if (callback) {
                        callback(error, 'saved');
                    }
                });
            });
        }
        function addUpdateMultiManagerAlerts(params) {
            Async.each(params.MemberManagers, function (manager, eCb) {
                (new EntityCache.ManagerAlert({
                    hgId: guid.v1(),
                    GroupId: params.GroupId,
                    Status: params.Status || EntityEnums.ManagerAlertStatus.Active,
                    ManagerMemberId: manager,
                    ReportMemberId: params.ReportMemberId,
                    Category: params.Category,
                    AlertType: params.AlertType,
                    Severity: params.Severity,
                    Data: params.Data
                })).save(eCb);
            }, function (err) {
                if (err) {
                    HgLog.warn('Unable to create manager alerts');
                    HgLog.warn(err);
                }
            });
        }
        this.GetProfileAlerts = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                ManagerMemberId: params.MemberId,
                ReportMemberId: { $in: params.ReportMemberIds},
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                AlertType: { $in: [
                    EntityEnums.ManagerAlertType.ProfileUpcomingBirthday,
                    EntityEnums.ManagerAlertType.ProfileUpcomingAnniversary
                ]}
            },
                selectedAlerts = [],
                tmpDate,
                diff,
                duration,
                today = new Date();
            EntityCache.ManagerAlert.find(query, function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    tmpDate = (item.AlertType === EntityEnums.ManagerAlertType.ProfileUpcomingBirthday) ? new Date(item.Data.Birthday) : new Date(item.Data.Startdate);
                    tmpDate = new Date(today.getUTCFullYear(), tmpDate.getUTCMonth(), tmpDate.getUTCDate());
                    duration = (item.AlertType === EntityEnums.ManagerAlertType.ProfileUpcomingBirthday) ? params.TeamTabSettings.Birthday : params.TeamTabSettings.Anniversary;
                    diff = Math.ceil((tmpDate - today) / 86400000);
                    if (diff > 0 && diff <= duration) {
                        item.Data.Days = diff;
                        selectedAlerts.push(item);
                    }
                });
                callback(null, selectedAlerts);
            });
        };
        this.GetAlerts = function (params, fcallback) {
            var cycleAlerts, adhocAlerts;
            Async.parallel({
                cycleGoals: function (callback) {
                    self.GetGoalsAlerts(params, function (error, data) {
                        if (error) {
                            return callback(error);
                        }
                        if (data.length) {
                            cycleAlerts = data.map(function (row) {
                                return row.alert;
                            });
                        }
                        callback(null, cycleAlerts || []);
                    });
                },
                adhocGoals: function (callback) {
                    self.GetAdhocGoalsAlerts(params, function (error, data) {
                        if (error) {
                            return callback(error);
                        }
                        if (data.length) {
                            adhocAlerts = data.map(function (row) {
                                return row.alert;
                            });
                        }
                        callback(null, adhocAlerts || []);
                    });
                },
                performance: function (callback) {
                    self.GetPerformanceAlerts(params, callback);
                },
                profile: function (callback) {
                    self.GetProfileAlerts(params, callback);
                }
            }, function (error, result) {
                if (error) {
                    return fcallback(error);
                }
                fcallback(null, Array.prototype.concat(result.cycleGoals, result.adhocGoals, result.performance, result.profile));
            });
        };
        this.GetGoalsAlerts = function (params, callback) {
            if (params.AggregatedSecuredTabs.profileTabs && params.AggregatedSecuredTabs.profileTabs.indexOf('goalCycle') > -1) {
                EntityCache.ManagerAlert.aggregate([
                    {$match: {
                        GroupId: params.GroupId,
                        ManagerMemberId: params.MemberId,
                        ReportMemberId: { $in: params.ReportMemberIds},
                        'Data.CycleId': {$exists: true},
                        Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                        AlertType: {$in: [
                            EntityEnums.ManagerAlertType.GoalCreationOverdue,
                            EntityEnums.ManagerAlertType.GoalPendingCreationApproval,
                            EntityEnums.ManagerAlertType.GoalCloseOverdue,
                            EntityEnums.ManagerAlertType.GoalPendingCloseApproval
                        ]}
                    }},
                    {$group: {
                        _id: {cycleId: '$Data.CycleId', type: '$AlertType', reportId: '$ReportMemberId'},
                        alert: {$last: '$$ROOT'}
                    }}], callback);
            } else {
                callback(null, []);
            }
        };
        this.GetAdhocGoalsAlerts = function (params, callback) {
            if (params.AggregatedSecuredTabs.profileTabs && params.AggregatedSecuredTabs.profileTabs.indexOf('goalCycle') > -1) {
                EntityCache.ManagerAlert.aggregate([
                    {$match: {
                        GroupId: params.GroupId,
                        ManagerMemberId: params.MemberId,
                        ReportMemberId: { $in: params.ReportMemberIds},
                        'Data.CycleId': {$exists: false},
                        Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                        AlertType: {$in: [
                            EntityEnums.ManagerAlertType.GoalCreationOverdue,
                            EntityEnums.ManagerAlertType.GoalPendingCreationApproval,
                            EntityEnums.ManagerAlertType.GoalCloseOverdue,
                            EntityEnums.ManagerAlertType.GoalPendingCloseApproval
                        ]}
                    }},
                    {$group: {
                        _id: {goalId: '$Data.GoalId', type: '$AlertType'},
                        alert: {$last: '$$ROOT'}
                    }}], callback);
            } else {
                callback(null, []);
            }
        };
        this.GetPerformanceAlerts = function (params, callback) {
            var query = {
                    GroupId: params.GroupId,
                    ManagerMemberId: params.MemberId,
                    ReportMemberId: { $in: params.ReportMemberIds},
                    Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]}
                },
                alertTypes = [];
            if (params.AggregatedSecuredTabs.profileTabs && params.AggregatedSecuredTabs.profileTabs.indexOf('perform') > -1) {
                alertTypes = [
                    EntityEnums.ManagerAlertType.PerformPendingReview,
                    EntityEnums.ManagerAlertType.PerformOverDueReview
                ];
            }
            if (params.AggregatedSecuredTabs.profileTabs && params.AggregatedSecuredTabs.profileTabs.indexOf('feedbackSession') > -1) {
                alertTypes.push(EntityEnums.ManagerAlertType.FeedbackCheckInDue);
            }
            if (!alertTypes || !alertTypes.length) {
                return callback(null, []);
            }
            query.AlertType = {$in: alertTypes};
            EntityCache.ManagerAlert.find(query, callback);
        };
        this.UpdatedProfile = function (params, fcallback) {
            function getMemberId(userId) {
                var result = params.MemberUserIdMapping.filter(function (item) {
                    return item.UserId === userId;
                });
                return (result.length === 0) ? '' : result[0].MemberId;
            }
            function getFieldData(userId, field) {
                var memberId = getMemberId(userId),
                    result = params.MembersInfo.filter(function (item) {
                        return item.hgId === memberId;
                    });
                return !result.length ? '' : result[0][field];
            }
            function updateProfile(record, scallback) {
                var memberId = getMemberId(record.hgId);
                Async.parallel({
                    birthday: function (callback) {
                        addUpdateManagerAlert({
                            GroupId: params.GroupId,
                            ReportMemberId: memberId,
                            Query: {
                                GroupId: params.GroupId,
                                ReportMemberId: memberId,
                                AlertType: EntityEnums.ManagerAlertType.ProfileUpcomingBirthday
                            },
                            Status: !record.Preference.SuppressBirthday ? EntityEnums.ManagerAlertStatus.Active : EntityEnums.ManagerAlertStatus.Deleted,
                            Category: EntityEnums.ManagerAlertCategory.Profile,
                            AlertType: EntityEnums.ManagerAlertType.ProfileUpcomingBirthday,
                            Severity: EntityEnums.ManagerAlertSeverity.Upcoming,
                            Data: {
                                FullName: record.UserPersonal.FullName,
                                Birthday: getFieldData(record.hgId, DateField.Birthdate)
                            },
                            MemberManagers: params.MemberManagers
                        }, callback);
                    },
                    anniversary: function (callback) {
                        addUpdateManagerAlert({
                            GroupId: params.GroupId,
                            ReportMemberId: memberId,
                            Query: {
                                GroupId: params.GroupId,
                                ReportMemberId: memberId,
                                AlertType: EntityEnums.ManagerAlertType.ProfileUpcomingAnniversary
                            },
                            Status: !record.Preference.SuppressAnniversary ? EntityEnums.ManagerAlertStatus.Active : EntityEnums.ManagerAlertStatus.Deleted,
                            Category: EntityEnums.ManagerAlertCategory.Profile,
                            AlertType: EntityEnums.ManagerAlertType.ProfileUpcomingAnniversary,
                            Severity: EntityEnums.ManagerAlertSeverity.Upcoming,
                            Data: {
                                FullName: record.UserPersonal.FullName,
                                Startdate: getFieldData(record.hgId, DateField.StartingDate)
                            },
                            MemberManagers: params.MemberManagers
                        }, callback);
                    },
                    manager: function (callback) {
                        EntityCache.ManagerAlert.update({
                            GroupId: params.GroupId,
                            ReportMemberId: memberId
                        }, {
                            $set: {
                                ManagerMemberId: getManagerId(memberId, params.MemberManagers)
                            }
                        }, {
                            multi: true
                        }, callback);
                    }
                }, scallback);
            }
            Async.each(params.UserInfos, updateProfile, fcallback);
        };
        this.UpdateMemberOffboarded = function (params, callback) {
            var query = {
                    ReportMemberId: params.OffboardedMemberId,
                    Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]}
                },
                update = {
                    $set: {
                        Status: EntityEnums.ManagerAlertStatus.Deleted
                    }
                };
            EntityCache.ManagerAlert.update(query, update, callback);
        };
        this.ReviewsOverdue = function (params, fcallback) {
            function addUpdateOverdueReview(overdueReview, callback) {
                addUpdateManagerAlert({
                    GroupId: overdueReview.GroupId,
                    ReportMemberId: overdueReview.MemberId,
                    Query: {
                        GroupId: overdueReview.GroupId,
                        ReportMemberId: overdueReview.MemberId,
                        AlertType: EntityEnums.ManagerAlertType.PerformOverDueReview,
                        'Data.ReviewId': overdueReview.ReviewId
                    },
                    Category: EntityEnums.ManagerAlertCategory.Perform,
                    AlertType: EntityEnums.ManagerAlertType.PerformOverDueReview,
                    Severity: EntityEnums.ManagerAlertSeverity.Warning,
                    Data: {
                        CycleName: overdueReview.CycleName,
                        ReviewId: overdueReview.ReviewId
                    },
                    MemberManagers: params.MemberManagers
                }, callback);
            }
            Async.each(params.OverdueReviews, addUpdateOverdueReview, fcallback);
        };
        this.ReviewsDeleted = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                'Data.ReviewId': { $in: params.ReviewIds}
            }, update = {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Deleted
                }
            };
            EntityCache.ManagerAlert.update(query, update, {multi: true}, callback);
        };
        this.UpdateOverDueReview = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                ReportMemberId: params.MemberId,
                Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                AlertType: EntityEnums.ManagerAlertType.PerformOverDueReview,
                'Data.ReviewId': params.ReviewId
            }, update = {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Completed
                }
            };
            EntityCache.ManagerAlert.update(query, update, callback);
        };
        this.UpdateCompletedReview = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Status: EntityEnums.ManagerAlertStatus.Completed,
                AlertType: EntityEnums.ManagerAlertType.PerformPendingReview,
                ReportMemberId: params.Subject,
                ManagerMemberId: params.Manager,
                'Data.ReviewId': params.ReviewId
            }, update = {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Active
                }
            };
            EntityCache.ManagerAlert.update(query, update, callback);
        };
        this.UpdatePendingReview = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                AlertType: EntityEnums.ManagerAlertType.PerformPendingReview,
                ReportMemberId: params.Subject,
                ManagerMemberId: params.Manager,
                'Data.ReviewId': params.ReviewId
            }, update = {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Completed
                }
            };
            EntityCache.ManagerAlert.update(query, update, callback);
        };
        this.TransferGoals = function (params) {
            var query = {
                ManagerMemberId: params.OldManagerMemberId,
                AlertType: {'$in': [
                    EntityEnums.ManagerAlertType.GoalPendingCreationApproval,
                    EntityEnums.ManagerAlertType.GoalCreationOverdue,
                    EntityEnums.ManagerAlertType.GoalCloseOverdue,
                    EntityEnums.ManagerAlertType.GoalPendingCloseApproval]},
                Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]}
            };
            if (params.DirectReports && params.DirectReports.length) {
                query.ReportMemberId = {$in: params.DirectReports};
            }
            EntityCache.ManagerAlert.update(query, {$set: {
                ManagerMemberId: params.NewManagerMemberId
            }}, {multi: true}, function (error) {
                if (error) {
                    HgLog.error({methodName: 'TransferGoals', error: error});
                }
            });
        };
        this.TransferManager = function (params) {
            var condition = {
                    ManagerMemberId: params.OldManagerMemberId,
                    ReportMemberId: {$in: params.DirectReportMemberIds},
                    Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]}
                },
                update = {
                    ManagerMemberId: params.NewManagerMemberId
                };
            if (params.TransferItems.Perform === 'Yes' && params.TransferItems.Profile === 'No') {
                condition.AlertType = {'$in': [EntityEnums.ManagerAlertType.PerformPendingReview, EntityEnums.ManagerAlertType.PerformOverDueReview]};
            }
            if (params.TransferItems.Perform === 'No' && params.TransferItems.Profile === 'Yes') {
                condition.AlertType = {'$in': [EntityEnums.ManagerAlertType.ProfileUpcomingBirthday, EntityEnums.ManagerAlertType.ProfileUpcomingAnniversary]};
            }
            EntityCache.ManagerAlert.update(condition, {$set: update}, {multi: true}, function (error) {
                if (error) {
                    HgLog.error({methodName: 'TransferManager', error: error});
                }
            });
        };
        this.ReviewDelivered = function (params, fcallback) {
            var managerAlert = new EntityCache.ManagerAlert({
                hgId: guid.v1(),
                GroupId: params.GroupId,
                Status: EntityEnums.ManagerAlertStatus.Active,
                ReportMemberId: params.Subject,
                ManagerMemberId: params.Manager,
                Category: EntityEnums.ManagerAlertCategory.Perform,
                AlertType: EntityEnums.ManagerAlertType.PerformPendingReview,
                Severity: EntityEnums.ManagerAlertSeverity.Urgent,
                Data: {
                    CycleName: params.CycleName,
                    ReviewId: params.ReviewId
                }
            });
            managerAlert.save(fcallback);
        };
        this.RemoveGoalSetPendingAlert = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                ReportMemberId: params.ParticipantId,
                AlertType: EntityEnums.ManagerAlertType.GoalPendingCreationApproval,
                Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                'Data.GoalId': params.GoalId,
            };
            if (params.CycleId) {
                query['Data.CycleId'] = params.CycleId;
            }
            EntityCache.ManagerAlert.findOneAndUpdate(query, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Completed
                }
            }, {new: true}, callback);
        };
        this.AdhocGoalSubmitted = function (params, callback) {
            var managerId = getManagerId(params.MemberId, params.MemberManagers);
            Async.parallel({
                removeCloseOverdue: function (fcallback) {
                    EntityCache.ManagerAlert.update({
                        GroupId: params.GroupId,
                        ReportMemberId: params.MemberId,
                        ManagerMemberId: managerId,
                        Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                        AlertType: EntityEnums.ManagerAlertType.GoalCloseOverdue,
                        'Data.GoalId': params.GoalId
                    }, {
                        $set: {
                            Status: EntityEnums.ManagerAlertStatus.Deleted
                        }
                    }, fcallback);
                },
                addGoalPendingAprroval: function (fcallback) {
                    EntityCache.ManagerAlert.findOne({
                        'Data.GoalId': params.GoalId,
                        GroupId: params.GroupId,
                        ReportMemberId: params.MemberId,
                        ManagerMemberId: managerId,
                        Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                    }, function (error, data) {
                        if (error) {
                            return fcallback(error);
                        }
                        if (data) {
                            HgLog.debug('Goal: ' + params.GoalId + ' already exist');
                            return fcallback();
                        }
                        var managerAlert = new EntityCache.ManagerAlert({
                            hgId: guid.v1(),
                            GroupId: params.GroupId,
                            Status: EntityEnums.ManagerAlertStatus.Active,
                            ReportMemberId: params.MemberId,
                            ManagerMemberId: getManagerId(params.MemberId, params.MemberManagers),
                            Category: EntityEnums.ManagerAlertCategory.Goals,
                            AlertType: (params.CloseRequest) ? EntityEnums.ManagerAlertType.GoalPendingCloseApproval : EntityEnums.ManagerAlertType.GoalPendingCreationApproval,
                            Severity: EntityEnums.ManagerAlertSeverity.Urgent,
                            Data: {
                                GoalTitle: params.GoalTitle,
                                GoalId: params.GoalId
                            }
                        });
                        managerAlert.save(fcallback);
                    });
                }
            }, callback);
        };
        this.GoalSubmittedForApproval = function (params, callback) {
            Async.parallel({
                updateOverdue: function (fcallback) {
                    var query = {
                        GroupId: params.GroupId,
                        ReportMemberId: params.ParticipantId,
                        AlertType: EntityEnums.ManagerAlertType.GoalCreationOverdue,
                        Status: {$in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                        'Data.CycleId': params.CycleId
                    };
                    EntityCache.ManagerAlert.update(query, {
                        $set: {
                            Status: EntityEnums.ManagerAlertStatus.Completed
                        }
                    }, fcallback);
                },
                addGoalPending: function (fcallback) {
                    var managerAlert = new EntityCache.ManagerAlert({
                        hgId: guid.v1(),
                        GroupId: params.GroupId,
                        Status: EntityEnums.ManagerAlertStatus.Active,
                        ReportMemberId: params.ParticipantId,
                        ManagerMemberId: params.ManagerId,
                        Category: EntityEnums.ManagerAlertCategory.Goals,
                        AlertType: EntityEnums.ManagerAlertType.GoalPendingCreationApproval,
                        Severity: EntityEnums.ManagerAlertSeverity.Urgent,
                        Data: {
                            GoalTitle: params.GoalTitle,
                            CycleId: params.CycleId,
                            CycleName: params.CycleName,
                            GoalId: params.GoalId
                        }
                    });
                    managerAlert.save(fcallback);
                }
            }, callback);
        };
        this.CompleteFeedbackCheckIn = function (params, callback) {
            EntityCache.ManagerAlert.update({
                GroupId: params.GroupId,
                ManagerMemberId: params.MemberId,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                AlertType: EntityEnums.ManagerAlertType.FeedbackCheckInDue,
                'Data.SessionId': params.SessionId
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Completed
                }
            }, {multi: true}, callback);
        };
        this.RemoveGoalPendingCloseApproval = function (params, callback) {
            EntityCache.ManagerAlert.findOneAndUpdate({
                GroupId: params.GroupId,
                ReportMemberId: params.MemberId,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                AlertType: EntityEnums.ManagerAlertType.GoalPendingCloseApproval,
                'Data.GoalId': params.GoalId
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Deleted
                }
            }, {new: true}, callback);
        };
        this.GoalCloseRejected = function (params, callback) {
            Async.parallel({
                addCloseOverdueAlert: function (fcallback) {
                    if (params.SetDueDate > Date.now() - 24 * 3600 * 1000) {
                        return fcallback();
                    }
                    var managerAlert = new EntityCache.ManagerAlert({
                        hgId: guid.v1(),
                        GroupId: params.GroupId,
                        ReportMemberId: params.MemberId,
                        ManagerMemberId: getManagerId(params.MemberId, params.MemberManagers),
                        Status: EntityEnums.ManagerAlertStatus.Active,
                        Category: EntityEnums.ManagerAlertCategory.Goals,
                        AlertType: EntityEnums.ManagerAlertType.GoalCloseOverdue,
                        Severity: EntityEnums.ManagerAlertSeverity.Warning,
                        Data: {
                            GoalTitle: params.GoalTitle,
                            CycleId: params.CycleId,
                            CycleName: params.CycleName,
                            GoalId: params.GoalId,
                            SetDueDate: params.SetDueDate,
                            ParticipantHgId: params.ParticipantHgId
                        }
                    });
                    managerAlert.save(fcallback);
                },
                removeClosePendingApproval: function (fcallback) {
                    self.RemoveGoalPendingCloseApproval(params, fcallback);
                }
            }, callback);
        };
        this.RequestCloseGoal = function (params, callback) {
            Async.parallel({
                removeCloseOverdue: function (fcallback) {
                    EntityCache.ManagerAlert.update({
                        GroupId: params.GroupId,
                        ReportMemberId: params.MemberId,
                        Status: EntityEnums.ManagerAlertStatus.Active,
                        AlertType: EntityEnums.ManagerAlertType.GoalCloseOverdue,
                        'Data.CycleId': params.CycleId
                    }, {
                        $set: {
                            Status: EntityEnums.ManagerAlertStatus.Deleted
                        }
                    }, fcallback);
                },
                addPendingCloseApproval: function (fcallback) {
                    var managerAlert = new EntityCache.ManagerAlert({
                        hgId: guid.v1(),
                        GroupId: params.GroupId,
                        ReportMemberId: params.MemberId,
                        ManagerMemberId: getManagerId(params.MemberId, params.MemberManagers),
                        Status: EntityEnums.ManagerAlertStatus.Active,
                        Category: EntityEnums.ManagerAlertCategory.Goals,
                        AlertType: EntityEnums.ManagerAlertType.GoalPendingCloseApproval,
                        Severity: EntityEnums.ManagerAlertSeverity.Urgent,
                        Data: {
                            GoalTitle: params.GoalTitle,
                            CycleId: params.CycleId,
                            CycleName: params.CycleName,
                            GoalId: params.GoalId
                        }
                    });
                    managerAlert.save(fcallback);
                }
            }, callback);
        };
        this.CreateCloseOverDueAdhocGoalAlerts = function (params, callback) {
            var managerId = getManagerId(params.MemberId, params.MemberManagers);
            EntityCache.ManagerAlert.findOne({
                GroupId: params.GroupId,
                ReportMemberId: params.MemberId,
                ManagerMemberId: managerId,
                AlertType: EntityEnums.ManagerAlertType.GoalCloseOverdue,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                'Data.GoalId': params.GoalId
            }, function (error, data) {
                if (error || data) {
                    return callback(error);
                }
                var managerAlert = new EntityCache.ManagerAlert({
                    hgId: guid.v1(),
                    GroupId: params.GroupId,
                    ReportMemberId: params.MemberId,
                    ManagerMemberId: managerId,
                    Status: EntityEnums.ManagerAlertStatus.Active,
                    Category: EntityEnums.ManagerAlertCategory.Goals,
                    AlertType: EntityEnums.ManagerAlertType.GoalCloseOverdue,
                    Severity: EntityEnums.ManagerAlertSeverity.Warning,
                    Data: {
                        GoalTitle: params.GoalTitle,
                        GoalId: params.GoalId,
                        CycleName: params.CycleName
                    }
                });
                managerAlert.save(callback);
            });
        };
        this.CreateCloseOverDueGoalAlerts = function (params, callback) {
            EntityCache.ManagerAlert.findOne({
                GroupId: params.GroupId,
                ReportMemberId: params.MemberId,
                AlertType: EntityEnums.ManagerAlertType.GoalCloseOverdue,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                'Data.ParticipantHgId': params.ParticipantHgId
            }, function (error, data) {
                if (error || data) {
                    return callback(error);
                }
                var managerAlert = new EntityCache.ManagerAlert({
                    hgId: guid.v1(),
                    GroupId: params.GroupId,
                    ReportMemberId: params.MemberId,
                    ManagerMemberId: getManagerId(params.MemberId, params.MemberManagers),
                    Status: EntityEnums.ManagerAlertStatus.Active,
                    Category: EntityEnums.ManagerAlertCategory.Goals,
                    AlertType: EntityEnums.ManagerAlertType.GoalCloseOverdue,
                    Severity: EntityEnums.ManagerAlertSeverity.Warning,
                    Data: {
                        CycleName: params.CycleName,
                        CycleId: params.CycleId,
                        ParticipantHgId: params.ParticipantHgId,
                        SetDueDate: params.SetDueDate
                    }
                });
                managerAlert.save(callback);
            });
        };
        this.CloseCycleGoals = function (params, callback) {
            EntityCache.ManagerAlert.update({
                GroupId: params.GroupId,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                'Data.GoalId': { $in: params.GoalIds}
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Completed
                }
            }, {
                multi: true
            }, callback);
        };
        this.FeedbackCheckInDue = function (params) {
            addUpdateMultiManagerAlerts({
                GroupId: params.GroupId,
                ReportMemberId: params.MemberId,
                Category: EntityEnums.ManagerAlertCategory.Feedback,
                AlertType: EntityEnums.ManagerAlertType.FeedbackCheckInDue,
                Severity: EntityEnums.ManagerAlertSeverity.Urgent,
                Data: {
                    SessionId: params.SessionId,
                    CycleTitle: params.CycleTitle,
                    CycleId: params.CycleId
                },
                MemberManagers: params.MemberManagers.reduce(function (memo, manager) {
                    if (manager.MemberId) {
                        memo.push(manager.MemberId);
                    }
                    return memo;
                }, [])
            });
        };
        this.GoalsSetOverDue = function (params, callback) {
            EntityCache.ManagerAlert.findOne({
                GroupId: params.GroupId,
                ReportMemberId: params.MemberId,
                AlertType: EntityEnums.ManagerAlertType.GoalCreationOverdue,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]},
                'Data.CycleId': params.CycleId
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (data) {
                    return callback(null, data);
                }
                var managerAlert = new EntityCache.ManagerAlert({
                    hgId: guid.v1(),
                    GroupId: params.GroupId,
                    ReportMemberId: params.MemberId,
                    ManagerMemberId: getManagerId(params.MemberId, params.MemberManagers),
                    Status: EntityEnums.ManagerAlertStatus.Active,
                    Category: EntityEnums.ManagerAlertCategory.Goals,
                    AlertType: EntityEnums.ManagerAlertType.GoalCreationOverdue,
                    Severity: EntityEnums.ManagerAlertSeverity.Warning,
                    Data: {
                        CycleName: params.CycleName,
                        CycleId: params.CycleId,
                        ParticipantHgId: params.ParticipantHgId,
                        SetDueDate: params.SetDueDate
                    }
                });
                managerAlert.save(callback);
            });
        };
        this.FeedbackCycleArchivedOrClosed = function (params, callback) {
            EntityCache.ManagerAlert.update({
                GroupId: params.GroupId,
                'Data.CycleId': params.CycleId,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]}
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Deleted
                }
            }, {
                multi: true
            }, callback);
        };
        this.GoalCycleDeleted = function (params, callback) {
            EntityCache.ManagerAlert.update({
                GroupId: params.GroupId,
                'Data.CycleId': params.CycleId,
                Status: { $in: [EntityEnums.ManagerAlertStatus.Active, EntityEnums.ManagerAlertStatus.Processing]}
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Deleted
                }
            }, {
                multi: true
            }, callback);
        };
        this.UpdateReviewTitle = function (params, callback) {
            EntityCache.ManagerAlert.update({
                GroupId: params.GroupId,
                'Data.ReviewId': {$in: params.ReviewIds}
            }, {
                $set: {
                    'Data.CycleName': params.Title,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };
        this.StartAlertProcessing = function (params, callback) {
            EntityCache.ManagerAlert.findOneAndUpdate({
                hgId: params.AlertId,
                Status: EntityEnums.ManagerAlertStatus.Active
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Processing
                }
            }, {
                new: true
            }, callback);
        };
        this.UpdateManagerAlerts = function (params, callback) {
            EntityCache.ManagerAlert.update({
                Status: EntityEnums.ManagerAlertStatus.Processing
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Active
                }
            }, {
                multi: true
            }, callback);
        };
        this.ArchiveAlertsByReportMemberIdsAndTypes = function (params, callback) {
            EntityCache.ManagerAlert.update({
                ReportMemberId: {$in: params.ReportMemberIds},
                AlertType: {$in: params.Types}
            }, {
                $set: {
                    Status: EntityEnums.ManagerAlertStatus.Deleted
                }
            }, {
                multi: true
            }, callback);
        };
        this.RemoveCompletedManagerAlerts = function (params, callback) {
            EntityCache.ManagerAlert.remove({
                Status: {$in: [
                    EntityEnums.ManagerAlertStatus.Deleted,
                    EntityEnums.ManagerAlertStatus.Completed
                ]},
                ModifiedDate: {$lte: Date.now() - THIRTY_DAYS}
            }).exec();
            callback(null, 'Deleted and Completed Manager Alerts removed');
        };
        this.UpdateOverDueGoal = function (params, callback) {
            var dataUpdate = {
                CycleName: params.CycleName,
                CycleId: params.CycleId
            };
            if (params.SetDueDate) {
                dataUpdate.DueDate = params.SetDueDate;
            }
            if (params.ParticipantHgId) {
                dataUpdate.ParticipantHgId = params.ParticipantHgId;
            }
            if (params.GoalId) {
                dataUpdate.GoalId = params.GoalId;
            }
            if (params.GoalTitle) {
                dataUpdate.GoalTitle = params.GoalTitle;
            }
            addUpdateManagerAlert({
                GroupId: params.GroupId,
                ReportMemberId: params.ParticipantId,
                Query: {
                    GroupId: params.GroupId,
                    ReportMemberId: params.ParticipantId,
                    AlertType: params.AlertType,
                    Status: EntityEnums.ManagerAlertStatus.Active,
                    'Data.CycleId': params.CycleId
                },
                Status: params.Status,
                Category: EntityEnums.ManagerAlertCategory.Goals,
                AlertType: params.AlertType,
                Severity: params.Severity,
                Data: dataUpdate,
                MemberManagers: params.MemberManagers
            }, callback);
        };
    };

module.exports = ManagerAlert;
