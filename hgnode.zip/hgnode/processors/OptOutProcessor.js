/*jslint node:true es5:true*/
'use strict';

var HgBaseProcessor = require('../framework/HgProcessor'),
    OptOutProcessor = function () {
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache'),
            guid = require('node-uuid');

        this.CreateOptOut = function (params, callback) {
            if (!params.EntityId) {
                return callback('optout.prc.eidnp');
            }
            if (!params.MemberIds) {
                return callback('optout.prc.midnp');
            }
            var optOut = new EntityCache.OptOut({
                hgId: guid.v1(),
                MemberIds: params.MemberIds,
                EntityId: params.EntityId,
                EntityType: params.EntityType,
                PropertyName: params.PropertyName,
                CreatedBy: params.CreatedBy
            });
            optOut.save(callback);
        };

        this.UpdateOptOutMembersByEntityId = function (params, callback) {
            var query = {};
            if (!params.EntityId) {
                return callback('optout.prc.eidnp');
            }
            if (!params.MemberIds) {
                return callback('optout.prc.midnp');
            }
            if (params.EntityId) {
                query.EntityId = params.EntityId;
            }
            EntityCache.OptOut.update(query, {
                $set: {
                    ModifiedBy: params.ModifiedBy
                },
                $addToSet: {
                    MemberIds: {
                        $each: params.MemberIds || []
                    }
                }
            }, callback);
        };

        this.FindOptOutByEntityId = function (params, callback) {
            var query = {};
            if (!params.EntityId) {
                return callback('optout.prc.eidnp');
            }
            if (params.EntityId) {
                query.EntityId = params.EntityId;
            }
            EntityCache.OptOut.findOne(query, callback);
        };
    };
module.exports = OptOutProcessor;