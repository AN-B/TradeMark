/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    EntityActivityEnums = require('../enums/EntityActivityEnums'),
    ProvisionProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventData = require('../common/EventData.js'),
            HgError = require('../common/HgError.js'),
            EventResponder = require('../util/EventResponder.js'),
            ProcessorHelper = require('../util/ProcessorHelper.js'),
            paramUtil = require('../util/params.js'),
            ProvisionEnums = require('../enums/ProvisionEnums.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            CountryEnums = require('../enums/CountryEnums.js'),
            StateEnum = require('../enums/StatesEnum.js'),
            i18nHelper = require('../helpers/i18nHelper.js'),
            TimeZoneHelper = require('../enums/TimeZone.js'),
            PusherManager = require('../util/PusherManager'),
            guid = require('node-uuid'),
            Async = require('async'),
            HgLog = require('../framework/HgLog.js'),
            mongoose = require('mongoose'),
            self = this;

        this.CreateBatch = function (params, callback) {
            var provisionBatch = EntityCache.ProvisionBatch({
                hgId: params.BatchId,
                FileName: params.FileName,
                Type: params.Type,
                CreatedBy: params.UserId,
                ModifiedBy: params.UserId
            });
            provisionBatch.save(callback);
        };

        this.GetProvisionGroupIdByBatchId = function (params, callback) {
            EntityCache.ProvisionActivity.findOne({
                BatchId: params.BatchId,
                EntityName : 'Group'
            }, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    callback('Error Loading Batch with supplied BatchId:' + params.BatchId);
                } else {
                    callback(null, {GroupId : data.EntityValue});
                }
            });
        };

        this.GetProvisionBatchById = function (params, callback) {
            EntityCache.ProvisionBatch.findOne({hgId: params.BatchId}, callback);
        };

        this.GetTotalMemberAddedActivities = function (params, callback) {
            EntityCache.ProvisionActivity.count({BatchId: params.EntityId, Type: ProvisionEnums.ProvisionActivityType.MemberAdded}, callback);
        };
        this.GetMemberAddedActivitiesBatch = function (params, callback) {
            EntityCache.ProvisionActivity.find({BatchId: params.EntityId, Type: ProvisionEnums.ProvisionActivityType.MemberAdded})
                .sort({_id: 1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };

        this.GetActivitiesByBatchId = function (params, callback) {
            var hgQuery = EntityCache.ProvisionActivity.find({BatchId: params.BatchId});
            if (params.Type) {
                hgQuery.where({Type: params.Type});
            }
            if (params.Notification) {
                hgQuery.where({Notification: params.Notification});
            }
            EntityCache.ProvisionBatch.findOne({hgId: params.BatchId}, function (error, batch) {
                if (error) {
                    callback(error);
                } else if (!batch) {
                    callback('Error Loading Batch with supplied BatchId:' + params.BatchId);
                } else {
                    hgQuery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(callback);
                }
            });
        };

        this.AddBatchActivity = function (params, callback) {
            if (!params.Activities || !params.Activities.length) {
                return callback();
            }
            EntityCache.ProvisionActivity.insertMany(params.Activities, callback);
        };

        this.GetStagedOnboardMemberCountByType = function (params, callback) {
            var result = {};
            EntityCache.ProvisionStagedMember.aggregate([
                {$match: {
                    AuditId: params.AuditId,
                    GroupId: params.GroupId
                }},
                {$group: {
                    _id: "$ProcessType",
                    count: {$sum: 1}
                }}
            ], function (error, data) {
                if (error || !data || !data.length) {
                    return callback(error, result);
                }
                data.forEach(function (m) {
                    result[m._id] = m.count;
                });
                callback(null, result);
            });
        };
        this.ArchiveMemberOffboardActivity = function (params) {
            EntityCache.ProvisionActivity.update({
                Status: ProvisionEnums.ProvisionActivityStatus.Pending,
                'EntityValue.MemberId': params.MemberId,
                Type: ProvisionEnums.ProvisionActivityType.MemberOffboardScheduled
            }, {
                $set: {
                    Status: ProvisionEnums.ProvisionActivityStatus.Archived,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }).exec();
        };
        this.UpdateProvisionActivity = function (params, callback) {
            var fieldsToUpdate = ProcessorHelper.GetUpdateJson(params.Fields, params.Activity, params.UserId);
            EntityCache.ProvisionActivity.update({hgId : params.Activity.hgId}, {$set: fieldsToUpdate}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'Activity Updated');
                }
            });
        };

        this.UpdateProvisionBatchActivities = function (params, callback) {
            function updateProvisionActivity(provisionActivity, callback) {
                self.UpdateProvisionActivity({Fields : params.Fields, Activity : provisionActivity, UserId : params.UserId}, function (error, data) {
                    if (!error) {
                        callback();
                    }
                });
            }
            if (params.Activities && params.Activities.length > 0) {
                Async.each(params.Activities, updateProvisionActivity, function (error) {
                    callback(null, 'Provision Activities Updated');
                });
            } else {
                callback(null, 'Provision Activities Updated');
            }
        };

        this.GetScheduledOffBoardMemberActivity = function (params, callback) {
            var dateNow = new Date(Date.now()),
                dateYesterday = new Date(Date.now() - 86400000);
            EntityCache.ProvisionActivity.find({
                'EntityValue.OffBoardDate': {
                    $gte: dateYesterday,
                    $lte: dateNow
                },
                Type: ProvisionEnums.ProvisionActivityType.MemberOffboardScheduled,
                Status: ProvisionEnums.ProvisionActivityNotificationType.Pending
            }, callback);
        };

        this.SetGroupIdForStagedRecords = function (params, callback) {
            Async.parallel({
                members: function (fcallback) {
                    EntityCache.ProvisionStagedMember.update({
                        AuditId: params.AuditId
                    }, {
                        $set: {
                            GroupId: params.GroupId
                        }
                    }, {
                        multi: true
                    }, fcallback);
                },
                location: function (fcallback) {
                    EntityCache.ProvisionStagedLocation.update({
                        AuditId: params.AuditId
                    }, {
                        $set: {
                            GroupId: params.GroupId
                        }
                    }, {
                        multi: true
                    }, fcallback);
                },
                department: function (fcallback) {
                    EntityCache.ProvisionStagedDepartment.update({
                        AuditId: params.AuditId
                    }, {
                        $set: {
                            GroupId: params.GroupId
                        }
                    }, {
                        multi: true
                    }, fcallback);
                }
            }, callback);
        };

        this.GetScheduledOnBoardMemberActivity = function (params) {
            var today = new Date(),
                searchDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                mquery = EntityCache.ProvisionActivity.find({'EntityValue.OnBoardNotificationDate' : { $gte: searchDate, $lte: searchDate  }, 'Type' : 'MemberAddedNotificationPending', 'Notification' : 'Pending'});
            mquery.exec(function (err, activity) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, new EventData(params.correlationId, activity));
            });
        };

        this.UpdateMemberOnBoardActivity = function (params) {
            EntityCache.ProvisionActivity.findOne({'BatchId' : params.BatchId, 'EntityValue.MemberId' : params.MemberId, 'Type' : 'MemberAddedNotificationPending', 'Notification' : 'Pending'}, function (err, activity) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                    return;
                }
                if (activity) {
                    activity.ModifiedDate = new Date().getTime();
                    activity.ModifiedBy = params.UserId;
                    activity.Status = 'Successful';
                    activity.Notification = 'Sent';
                    activity.save();
                    EventResponder.RespondWithData(EventEmitterCache, params, new EventData(params.correlationId, { message: activity.Summary }));
                }
            });
        };

        this.CreateAndGetActivity = function (params) {
            var provisionActivity = EntityCache.ProvisionActivity({
                    hgId : params.ActivityId,
                    BatchId : params.BatchId,
                    Type : params.Type,
                    EntityName : params.EntityName,
                    EntityValue : params.EntityValue,
                    Summary : params.Summary,
                    Status : params.Status,
                    CreatedBy : params.UserId,
                    ModifiedBy : params.UserId
                });
            provisionActivity.save(function (err) {
                if (err) {
                    HgLog.error({methodName: 'CreateAndGetActivity', error: err});
                    return;
                }
                EntityCache.ProvisionActivity.findOne({hgId: params.ActivityId}, function (err, activity) {
                    if (err) {
                        HgLog.error({methodName: 'CreateAndGetActivity', error: err});
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                        return;
                    }
                    if (!activity) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                        return;
                    }
                    EventResponder.RespondWithData(EventEmitterCache, params, activity);
                });
            });
        };

        this.GetBatches = function (params) {
            var Type = params.Type,
                mquery = EntityCache.ProvisionBatch.find({});
            if (Type) {
                mquery = EntityCache.ProvisionBatch.find({'Type' : Type});
            }
            mquery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, batches) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                    return;
                }
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, batches));
            });
        };

        this.GetBatchesByFilter = function (params, callback) {
            var Type = params.Type,
                StartDate = params.StartDate,
                EndDate = params.EndDate,
                BatchIds = params.BatchIds,
                hgQuery = EntityCache.ProvisionBatch.find({});
            if (Type) {
                hgQuery.where({'Type' : Type});
            }
            if (StartDate && EndDate) {
                hgQuery.where({'CreatedDate' : { $gte: StartDate, $lte: EndDate }});
            }
            if (params.BatchIds) {
                hgQuery.where({'hgId' : { $in : BatchIds }});
            }
            hgQuery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, batches) {
                if (err) {
                    callback(err);
                } else {
                    callback(null, batches);
                }
            });
        };

        this.AddOffBoardMemberActivity = function (params, callback) {
            var summary, filterQuery = {'EntityValue.MemberId' : params.EntityValue.MemberId, 'Type' : 'MemberOffboardScheduled', 'Status' : 'Pending'};
            EntityCache.ProvisionActivity.findOne(filterQuery, function (error, activity) {
                if (error) { return callback(error); }
                summary = 'Member ' + params.Member.FullName + ' scheduled to be Off Boarded: ' + params.EntityValue.OffBoardDate;
                if (activity) {
                    activity.EntityValue = params.EntityValue;
                    activity.ModifiedDate = new Date().getTime();
                    activity.ModifiedBy = params.UserId;
                    activity.Summary = summary;
                } else {
                    activity = EntityCache.ProvisionActivity({
                        hgId : params.hgId,
                        BatchId : params.BatchId,
                        EntityValue : params.EntityValue,
                        Summary : summary,
                        Type : 'MemberOffboardScheduled',
                        EntityName : 'Member',
                        Status : 'Pending',
                        CreatedBy : params.UserId,
                        ModifiedBy : params.UserId
                    });
                }
                activity.save(function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, params.Member.FullName + ' Off-board Scheduled!');
                    }
                });
            });
        };

        this.GetBatchById = function (params) {
            var mquery = EntityCache.ProvisionActivity.find({'BatchId' : params.BatchId});
            EntityCache.ProvisionBatch.findOne({'hgId' : params.BatchId}, function (err, batch) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                    return;
                }
                if (!batch) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, 'Could not load batch. Did you pass the right batch Id?'));
                    return;
                }
                mquery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, activities) {
                    if (err) {
                        EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                        return;
                    }
                    batch.Activities = activities;
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, batch));
                });
            });
        };

        this.GetActivityByFilter = function (params, callback) {
            var mquery = EntityCache.ProvisionActivity.find({});
            if (params.EntityValue) {
                mquery.where({'EntityValue' : params.EntityValue});
            }
            if (params.EntityName) {
                mquery.where({'EntityName' : params.EntityName});
            }
            if (params.StartDate && params.EndDate) {
                mquery.where({'CreatedDate' : { $gte: params.StartDate, $lte: params.EndDate }});
            }
            if (params.Notification) {
                mquery.where({'Notification' : params.Notification});
            }
            if (params.Type) {
                mquery.where({'Type' : params.Type});
            }
            if (params.Status) {
                mquery.where({'Status' : params.Status});
            }
            mquery.exec(callback);
        };

        this.GetActivityById = function (params) {
            EntityCache.ProvisionActivity.findOne({'hgId' : params.ActivityId}, function (err, activity) {
                if (err) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                    return;
                }
                if (!activity) {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, null, HgError.Enums.Provision.ErrorLoading));
                    return;
                }
                EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, activity));
            });
        };

        this.GenerateGuids = function (params, callback) {
            var guids = [];
            if (isNaN(params.numberOfGuids) || params.numberOfGuids < 1 || params.numberOfGuids > 100) {
                callback(HgError.Enums.Provision.ErrorGeneratingGuids);
            } else {
                while (params.numberOfGuids > 0) {
                    guids.push(guid.v1());
                    params.numberOfGuids -= 1;
                }
                callback(null, guids);
            }
        };
        this.GetProvisionAuditById = function (params, callback) {
            EntityCache.ProvisionAudit.findOne({_id: params.Id}, params.Fields || {}, {lean: true}, callback);
        };
        this.FileUploaded = function (params, callback) {
            var provisionAudit = EntityCache.ProvisionAudit(params);
            provisionAudit.save(callback);
        };
        this.LogProvisionActivity = function (params) {
            EntityCache.ProvisionAudit.update({
                _id: params.Id
            }, {
                $push: {
                    Notes: params.Note
                }
            }).exec();
        };
        this.ProvisionStageLocations = function (params, callback) {
            var countryList = CountryEnums.ReturnValues(),
                tzValueIndex = TimeZoneHelper.getTZIndex().tzValueIndex,
                supportedLanguages = Object.keys(i18nHelper.supportedLanguages).map(function (item) {
                    return i18nHelper.supportedLanguages[item];
                }),
                locations = [];
            if (!params.Content.Locations || !params.Content.Locations.length) {
                return callback();
            }
            params.Content.Locations.forEach(function (location) {
                location.GroupId = params.GroupId;
                location.GroupName = params.Content.Company.Name;
                location.BatchId = params.BatchId;
                location.AuditId = params.Id;
                location.InvalidCountry = !location.Country || !countryList.some(function (c) {
                    return c.toLowerCase() === location.Country.toLowerCase();
                });
                if (location.Country && location.Country === CountryEnums.US) {
                    location.InvalidState = !location.State || !StateEnum.filter(function (state) {
                        return state.abbr.toLowerCase() === location.State.toLowerCase() ||
                            state.name.toLowerCase() === location.State.toLowerCase();
                    }).length;
                    location.InvalidZipCode = !location.ZipCode;
                }
                location.InvalidLanguage = !location.Language || !supportedLanguages.filter(function (item) {
                    return item.toLowerCase() === location.Language.toLowerCase();
                }).length;
                location.InvalidTimeZone = !location.TimeZone || !tzValueIndex[location.TimeZone.toLowerCase()];
                if (params.Type === ProvisionEnums.Type.Onboard) {
                    location.ProcessType = ProvisionEnums.ProcessType.New;
                }
                locations.push(location);
            });
            if (!locations.length) {
                return callback();
            }
            EntityCache.ProvisionStagedLocation.insertMany(locations, callback);
        };
        this.ProvisionStageMember = function (params, callback) {
            var managerUserNames;
            Async.eachLimit(params.Content.Employees, 250, function (member, memberCallback) {
                member.FileType = params.Type;
                member.GroupId = params.GroupId;
                member.GroupName = params.Content.Company.Name;
                member.BatchId = params.BatchId;
                member.AuditId = params.Id;

                if (params.Type !== ProvisionEnums.Type.OffBoard) {
                    member.InvalidStartDate = !member.StartDate || !paramUtil.IsValidDate(member.StartDate);
                    member.InvalidBirthDate = !member.BirthDate || !paramUtil.IsValidDate(member.BirthDate);
                    member.UserName = member.UserName ? member.UserName.toLowerCase().trim() : '';
                    member.ManagerUserName = member.ManagerUserName ? member.ManagerUserName.toLowerCase().trim() : '';
                    if (member.ManagerUserName) {
                        member.USM = member.ManagerUserName.toLowerCase() === member.UserName.toLowerCase();
                    }
                    if (member.ManagerEmpID) {
                        member.ManagerEmpIdSameAsReportEmpId = member.ManagerEmpID.toLowerCase() === member.EmpID.toLowerCase();
                    }
                    member.InvalidRole = !member.Role || Object.keys(EntityEnums.MembersRoleInGroup).filter(function (systemRoles) {
                        return systemRoles !== EntityEnums.MembersRoleInGroup.HGAdmin;
                    }).map(function (item) {
                        return item.toLowerCase();
                    }).indexOf(member.Role.toLowerCase()) === -1;
                    member.InvalidSuppressBirthday = member.SuppressBirthday && ['false', 'true'].indexOf(member.SuppressBirthday.toLowerCase()) === -1;
                    member.InvalidSuppressAnniversary = member.SuppressAnniversary && ['false', 'true'].indexOf(member.SuppressAnniversary.toLowerCase()) === -1;
                    if (member.NewUserName) {
                        member.NewUserName = member.NewUserName.toLowerCase();
                        member.InvalidNewUserName = member.NewUserName.toLowerCase().trim() === member.UserName.toLowerCase().trim();
                        member.InvalidNewUserNameValue = !new RegExp(paramUtil.USERNAME_REGEXP).test(member.NewUserName);
                    }
                    if (member.ManagerUserName) {
                        managerUserNames = member.ManagerUserName.split(',').map(Function.prototype.call, String.prototype.trim);
                        managerUserNames.forEach(function (manager) {
                            if (!member.InvalidManagerUserName) {
                                member.InvalidManagerUserName = !new RegExp(paramUtil.USERNAME_REGEXP).test(manager);
                            }
                        });
                        if (!params.MultiManagerSupported && !member.InvalidManagerUserName && managerUserNames.length > 1) {
                            member.InvalidMultipleFlagNotEnabled = true;
                        }
                    }
                    member.InvalidEmail = !member.Email || !new RegExp(paramUtil.EMAIL_REGEXP).test(member.Email);
                } else {
                    member.ProcessStep = ProvisionEnums.ProcessMemberStep.OffBoard;
                    member.InvalidNotificationEmail = member.NotificationEmail && !new RegExp(paramUtil.EMAIL_REGEXP).test(member.NotificationEmail);
                }
                if (member.OffBoardDate) {
                    member.InvalidOffBoardDate = !paramUtil.IsValidDate(member.OffBoardDate);
                }
                member.InvalidUserName = !member.UserName || !new RegExp(paramUtil.USERNAME_REGEXP).test(member.UserName);
                if (member.OffBoardType) {
                    member.InvalidOffBoardType = ['voluntary', 'involuntary'].indexOf(member.OffBoardType.toLowerCase().trim()) === -1;
                }
                if (member.Department && !params.Departments[member.Department]) {
                    params.Departments[member.Department] = {
                        Name: member.Department,
                        Code: member.DepartmentCode,
                        GroupId: params.GroupId,
                        GroupName: member.GroupName,
                        AuditId: member.AuditId,
                        BatchId: member.BatchId
                    };
                }
                if (params.Type === ProvisionEnums.Type.HRIS && member.Location && !params.Locations[member.Location]) {
                    params.Locations[member.Location] = {
                        Name: member.Location,
                        Code: member.LocationCode,
                        GroupId: params.GroupId,
                        GroupName: member.GroupName,
                        AuditId: member.AuditId,
                        BatchId: member.BatchId
                    };
                }
                EntityCache.ProvisionStagedMember.insertMany([member], memberCallback);
            }, callback);
        };
        this.StageFileContent = function (params, callback) {
            params.Departments = {};
            params.Locations = {};
            EntityCache.ProvisionAudit.update({
                _id: params.Id
            }, {
                $set: {
                    Content: params.Content
                },
                $push: {
                    Notes: params.Note
                }
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                self.ProvisionStageMember(params, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    if (params.Type === ProvisionEnums.Type.OffBoard) {
                        return callback();
                    }
                    Async.parallel({
                        departments: function (fcallback) {
                            var departments = [];
                            Object.keys(params.Departments).forEach(function (item) {
                                departments.push(params.Departments[item]);
                            });
                            if (!departments.length) {
                                return fcallback();
                            }
                            EntityCache.ProvisionStagedDepartment.insertMany(departments, fcallback);
                        },
                        locations: function (fcallback) {
                            var locations = [];
                            if (params.Type === ProvisionEnums.Type.HRIS) {
                                Object.keys(params.Locations).forEach(function (item) {
                                    locations.push(params.Locations[item]);
                                });
                                if (!locations.length) {
                                    return fcallback();
                                }
                                return EntityCache.ProvisionStagedLocation.insertMany(locations, fcallback);
                            }
                            self.ProvisionStageLocations(params, fcallback);
                        }
                    }, function (error) {
                        if (global && global.gc) {
                            global.gc();
                        }
                        callback(error);
                    });
                });
            });
        };
        this.UpdateProvisionAudit = function (params, callback) {
            var update = {};
            if (params.Content) {
                update.Content = params.Content;
            }
            if (params.Status) {
                update.Status = params.Status;
            }
            if (params.GroupStatus) {
                update.GroupStatus = params.GroupStatus;
            }
            if (params.NewGroupId) {
                update.GroupId = params.NewGroupId;
            }
            if (params.LocationStatus) {
                update.LocationStatus = params.LocationStatus;
            }
            if (params.MemberStatus) {
                update.MemberStatus = params.MemberStatus;
            }
            EntityCache.ProvisionAudit.update({
                _id: params.Id
            }, {
                $set: update,
                $push: {
                    Notes: params.Note
                }
            }, callback);
        };
        this.GetProvisionAggregateData = function (params, callback) {
            EntityCache.ProvisionAudit.aggregate(params.Query, callback);
        };
        this.GetStagedMemberList = function (params, callback) {
            EntityCache.ProvisionStagedMember.find(params.Query, params.Fields || {}, {lean: true})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetStagedMemberAggregated = function (params, callback) {
            EntityCache.ProvisionStagedMember.aggregate(params, callback);
        };
        this.GetStagedLocationList = function (params, callback) {
            EntityCache.ProvisionStagedLocation.find(params.Query, params.Fields || {}, {lean: true})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(function (error, data) {
                    callback(error, data);
                });
        };
        this.GetStagedLocationAggregation = function (params, callback) {
            EntityCache.ProvisionStagedLocation.aggregate(params, callback);
        };
        this.GetUniqueUserNames = function (params, callback) {
            self.GetStagedMemberAggregated([
                {$match: {
                    AuditId: params.Id.toString(),
                    UserName: {$exists: true, $ne: ""}
                }},
                {$group: {
                    _id: null,
                    UserNames: {$addToSet: "$UserName"}
                }}
            ], callback);
        };
        this.GetUniqueEmpIds = function (params, callback) {
            self.GetStagedMemberAggregated([
                {$match: {
                    AuditId: params.Id.toString(),
                    EmpID: {$exists: true, $ne: ""}
                }},
                {$group: {
                    _id: null,
                    EmpIDs: {$addToSet: "$EmpID"}
                }}
            ], callback);
        };
        this.GetQueueNextStep = function (params, callback) {
            EntityCache.ProvisionAudit.findOne({
                _id: params.Id
            }, {
                CurrentStep: 1,
                Type: 1
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.CurrentStep += 1;
                var nextStep = ProvisionEnums.QueueSteps[data.Type].Steps.filter(function (item) {
                    return item.Value === data.CurrentStep;
                });
                if (!nextStep.length) {
                    return callback();
                }
                EntityCache.ProvisionAudit.update({
                    _id: params.Id
                }, {
                    $inc: {
                        CurrentStep: 1
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    return callback(null, nextStep[0].Step);
                });
            });
        };
        this.GetProvisionRecordByStatus = function (params, callback) {
            var query = {
                _id: params.Id
            };
            if (params.Status) {
                query.Status = params.Status;
            }
            EntityCache.ProvisionAudit.findOne(query, params.Fields || {}, callback);
        };
        this.UpdateValidatedFile = function (params, callback) {
            EntityCache.ProvisionAudit.update({
                _id: params.Id,
                Status: ProvisionEnums.Status.FileValidated
            }, {
                $set: {
                    Status: params.Status,
                    ModifiedBy: params.UserId
                },
                $push: {
                    Notes: params.Note
                }
            }, callback);
        };
        this.CreateQueue = function (params, callback) {
            EntityCache.ProvisionQueue.insertMany(params, callback);
        };
        this.GetAndLockQueue = function (params, callback) {
            EntityCache.ProvisionQueue.findOneAndUpdate({
                AuditId: params.AuditId,
                Status: ProvisionEnums.QueueStatus.New
            }, {
                $set: {
                    StartTime: Date.now(),
                    Status: ProvisionEnums.QueueStatus.Processing
                }
            }, {
                sort: {
                    _id: 1
                },
                new: true
            }, callback);
        };
        this.QueueItemProcessed = function (params, callback) {
            EntityCache.ProvisionQueue.update({
                _id: params.Id
            }, {
                $set: {
                    EndTime: Date.now(),
                    Status: ProvisionEnums.QueueStatus.Processed
                }
            }, callback);
        };
        //TODO METHOD NEEDS TO DEPRECATED after createWelcomeEmailQueue is changed
        this.GetProvisionEmployeesWithMemberId = function (params, callback) {
            var aggregateParam = [
                {$match: {_id: params.Id}},
                {$unwind: "$Content.Employees"},
                {$match: {"Content.Employees.MemberId": {$ne: ""}}},
                {$project: {
                    "Content.Employees.MemberId" : 1
                }},
                {$skip: parseInt(params.Skip, 10) || 0},
                {$limit: parseInt(params.Take, 10) || 10}
            ];
            EntityCache.ProvisionAudit.aggregate(aggregateParam, callback);
        };
        this.GetFilteredMemberEntityActivities = function (params, callback) {
            var query = ProcessorHelper.SetCommonMemberAuditLogParams(params),
                $or;
            if (query.length && query.substr && query.substring) {
                return callback(query);
            }
            if (!params.EntityId) {
                return callback('provision.filter.emp');
            }
            query.EntityId = params.EntityId;
            $or = ProcessorHelper.BuildSearchTermQueryForMemberAuditLogs(params.EntityType, params.SearchTerm);
            if ($or.length) {
                query.$or = $or;
            }
            EntityCache.EntityActivity.find(query, ProcessorHelper.BuildProjectionForMemberAuditLog(params.EntityType))
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 100)
                .sort({CreatedDate: -1})
                .exec(callback);
        };
        this.GetFilteredMemberBucketEntityActivities = function (params, callback) {
            var query = ProcessorHelper.SetCommonMemberAuditLogParams(params),
                $or;
            if (query.length && query.substr && query.substring) {
                return callback(query);
            }
            if (params.EntityType !== EntityActivityEnums.EntityType.MemberPermission) {
                return callback('provision.filter.wetp');
            }
            if (params.ActivityType !== EntityActivityEnums.ActivityType.MemberPermissionChanged) {
                return callback('provision.filter.watp');
            }
            if (!params.EntityId) {
                return callback('provision.filter.emps');
            }
            query.Entities = {
                $in: [params.EntityId]
            };
            $or = ProcessorHelper.BuildSearchTermQueryForMemberBucketAuditLogs(params.EntityType, params.SearchTerm);
            if ($or.length) {
                query.$or = $or;
            }
            EntityCache.EntityActivity.find(query, ProcessorHelper.BuildProjectionForMemberBucketAuditLog(params.EntityType))
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 100)
                .sort({_id: -1})
                .exec(callback);
        };
        this.GetFiles = function (params, callback) {
            var query = {},
                fields = {
                    MemberId: 1,
                    FullName: 1,
                    FileName: 1,
                    Status: 1,
                    Type: 1,
                    CreatedDate: 1,
                    ModifiedDate: 1,
                    Content: 1
                };
            if (params.FileId) {
                query._id = mongoose.Types.ObjectId(params.FileId);
                fields.Notes = 1;
            }
            EntityCache.ProvisionAudit.find(query, fields, {lean: true})
                .sort({_id: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 25)
                .exec(function (error, data) {
                    if (error) {
                        return callback(error);
                    }
                    data.forEach(function (item) {
                        item.Id = item._id;
                        item.GroupName = item.Content && item.Content.Company && item.Content.Company.Name ? item.Content.Company.Name : '';
                    });
                    callback(null, data);
                });
        };
        this.GetNextPendingGroup = function (params, callback) {
            EntityCache.ProvisionAudit.findOne({
                Status: ProvisionEnums.Status.FileConfirmed,
                GroupStatus: ProvisionEnums.ProcessStepStatus.NotStarted
            }, {
                _id: 1,
                BatchId: 1,
                GroupId: 1,
                Type: 1,
                CreatedBy: 1
            }, {lean: true}, function (error, data) {
                if (error || !data) {
                    return callback(error);
                }
                EntityCache.ProvisionAudit.update({
                    _id: data._id
                }, {
                    $set: {
                        GroupStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, data);
                });
            });
        };
        this.GetNextPendingLocation = function (params, callback) {
            EntityCache.ProvisionAudit.findOne({
                Status: ProvisionEnums.Status.ProcessingFile,
                Type: {$in: [
                    ProvisionEnums.Type.Onboard,
                    ProvisionEnums.Type.Update,
                    ProvisionEnums.Type.HRIS,
                    ProvisionEnums.Type.APIOnboard,
                    ProvisionEnums.Type.APIUpdate
                ]},
                GroupStatus: ProvisionEnums.ProcessStepStatus.Processed,
                LocationStatus: ProvisionEnums.ProcessStepStatus.NotStarted
            }, {
                _id: 1,
                BatchId: 1,
                GroupId: 1,
                Type: 1,
                CreatedBy: 1
            }, {lean: true}, function (error, data) {
                if (error || !data) {
                    return callback(error);
                }
                EntityCache.ProvisionAudit.update({
                    _id: data._id
                }, {
                    $set: {
                        LocationStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, data);
                });
            });
        };
        this.GetLocationCount = function (params, callback) {
            var query = {
                AuditId: params.AuditId
            };
            if (params.ProcessType) {
                query.ProcessType = params.ProcessType;
            }
            EntityCache.ProvisionStagedLocation.count(query, callback);
        };
        this.GetUnProcessedMemberCount = function (params, callback) {
            var query = {
                AuditId: params.AuditId
            };
            if (params.ProcessType) {
                query.ProcessType = params.ProcessType;
            }
            EntityCache.ProvisionStagedMember.count(query, callback);
        };
        this.GetDepartmentCount = function (params, callback) {
            EntityCache.ProvisionStagedDepartment.count({
                AuditId: params.AuditId
            }, callback);
        };
        this.GetNextUnProcessedDepartments = function (params, callback) {
            EntityCache.ProvisionStagedDepartment.find({
                AuditId: params.AuditId,
                Status: ProvisionEnums.ProcessStepStatus.NotStarted
            }, {
                Name: 1,
                Code: 1,
                GroupName: 1
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 100)
                .exec(callback);
        };
        this.UpdateStagedDepartments = function (params, callback) {
            Async.each(params.Departments, function (department, departmentCallback) {
                EntityCache.ProvisionStagedDepartment.update({
                    GroupId: params.GroupId,
                    AuditId: params.AuditId,
                    Name: department.Name
                }, {
                    $set: {
                        hgId: department.hgId,
                        ProcessType: department.ProcessType,
                        Status: ProvisionEnums.ProcessStepStatus.Processed
                    }
                }, departmentCallback);
            }, callback);
        };
        this.GetNextPendingDepartment = function (params, callback) {
            EntityCache.ProvisionAudit.findOne({
                Status: ProvisionEnums.Status.ProcessingFile,
                Type: {$in: [
                    ProvisionEnums.Type.Onboard,
                    ProvisionEnums.Type.Update,
                    ProvisionEnums.Type.HRIS,
                    ProvisionEnums.Type.APIOnboard,
                    ProvisionEnums.Type.APIUpdate
                ]},
                GroupStatus: ProvisionEnums.ProcessStepStatus.Processed,
                DepartmentStatus: ProvisionEnums.ProcessStepStatus.NotStarted
            }, {
                _id: 1,
                BatchId: 1,
                GroupId: 1,
                Type: 1,
                CreatedBy: 1
            }, {lean: true}, function (error, data) {
                if (error || !data) {
                    return callback(error);
                }
                EntityCache.ProvisionAudit.update({
                    _id: data._id
                }, {
                    $set: {
                        DepartmentStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, data);
                });
            });
        };
        this.GetTotalNewUsersCreated = function (params, callback) {
            EntityCache.ProvisionStagedMember.count({
                AuditId: params.AuditId,
                ProcessType: ProvisionEnums.ProcessType.New,
                CStatus: null
            }, callback);
        };
        this.GetNextNewUsersCreated = function (params, callback) {
            EntityCache.ProvisionStagedMember.find({
                AuditId: params.AuditId,
                ProcessType: ProvisionEnums.ProcessType.New,
                CStatus: null
            }, {}, {lean: true})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 10)
                .exec(callback);
        };
        this.SetPostProvisionCompletedEventCreated = function (params, callback) {
            EntityCache.ProvisionStagedMember.update({
                AuditId: params.AuditId,
                ProcessType: ProvisionEnums.ProcessType.New,
                MemberId: {$in: params.MemberIds},
                CStatus: null
            }, {
                $set: {
                    CStatus: ProvisionEnums.ProcessStepStatus.Processed
                }
            }, {multi: true}, callback);
        };
        this.GetNextUserCreationAndUpdate = function (params, callback) {
            EntityCache.ProvisionStagedMember.find({
                AuditId: params.AuditId,
                ProcessStep: ProvisionEnums.ProcessMemberStep.UserCreationAndUpdate,
                ProcessType: null,
                UCStatus: null
            }, {}, {lean: true})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 10)
                .exec(callback);
        };
        this.GetTotalUserCreationAndUpdate = function (params, callback) {
            EntityCache.ProvisionStagedMember.count({
                AuditId: params.AuditId,
                ProcessStep: ProvisionEnums.ProcessMemberStep.UserCreationAndUpdate,
                ProcessType: null,
                UCStatus: null
            }, callback);
        };

        this.BeginProvisionMemberBatch = function (params, callback) {
            EntityCache.ProvisionAudit.findOneAndUpdate({
                Status: ProvisionEnums.Status.ProcessingFile,
                GroupStatus: ProvisionEnums.ProcessStepStatus.Processed,
                DepartmentStatus: ProvisionEnums.ProcessStepStatus.Processed,
                LocationStatus: ProvisionEnums.ProcessStepStatus.Processed,
                MemberStatus: ProvisionEnums.ProcessStepStatus.NotStarted,
                MemberProcessStep: ProvisionEnums.ProcessMemberStep.NotStarted
            }, {
                $set: {
                    MemberStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing,
                    MemberProcessStep: ProvisionEnums.ProcessMemberStep.UserCreationAndUpdate,
                }
            }, {
                new: true
            }, function (error, data) {
                if (error || !data) {
                    return callback(error);
                }
                var updateParams = {};
                if ([ ProvisionEnums.Type.Onboard,
                        ProvisionEnums.Type.Update,
                        ProvisionEnums.Type.HRIS,
                        ProvisionEnums.Type.APIOnboard,
                        ProvisionEnums.Type.APIUpdate].indexOf(data.Type) > -1) {
                    updateParams.ProcessStep = ProvisionEnums.ProcessMemberStep.UserCreationAndUpdate;
                } else {
                    //change this later for offboard
                    updateParams.ProcessStep = ProvisionEnums.ProcessMemberStep.UserCreationAndUpdate;
                }
                EntityCache.ProvisionStagedMember.update({
                    AuditId: data._id.toString()
                }, {
                    $set: updateParams
                }, {
                    multi: true
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        AuditId: data._id.toString(),
                        GroupId: data.GroupId,
                        BatchId: data.BatchId,
                        CreatedBy: data.CreatedBy
                    });
                });
            });
        };
        this.GetNextPendingLocations = function (params, callback) {
            var query = {
                AuditId: params.AuditId,
                Status: ProvisionEnums.ProcessStepStatus.NotStarted,
            };
            if (params.ProcessType) {
                query.ProcessType = params.ProcessType;
            }
            EntityCache.ProvisionStagedLocation.find(query)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 100)
                .exec(callback);
        };
        this.GetNextUnProcessedMembers = function (params, callback) {
            var query = {
                AuditId: params.AuditId,
                UCStatus: ProvisionEnums.ProcessStepStatus.NotStarted,
            };
            if (params.ProcessType) {
                query.ProcessType = params.ProcessType;
            }
            EntityCache.ProvisionStagedMember.find(query, {}, {lean: true})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 100)
                .exec(callback);
        };
        this.SetDepartmentStatusToProcessing = function (params, callback) {
            EntityCache.ProvisionAudit.findOne({
                _id: params.AuditId,
                DepartmentStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
            }, function (error, data) {
                if (error || !data) {
                    return callback(error);
                }
                data.DepartmentStatus = ProvisionEnums.ProcessStepStatus.Processing;
                data.save(callback);
            });
        };
        this.UpdateStagedLocationProcessType = function (params, callback) {
            Async.each(params.Locations, function (location, locationCallback) {
                var updateParams = {
                    ProcessType: location.ProcessType
                };
                if (location.ProcessType === ProvisionEnums.ProcessType.Update) {
                    updateParams.hgId = location.hgId;
                }
                if (location.Status === ProvisionEnums.ProcessStepStatus.Processed) {
                    updateParams.Status = ProvisionEnums.ProcessStepStatus.Processed;
                }
                EntityCache.ProvisionStagedLocation.update({
                    GroupId: params.GroupId,
                    AuditId: params.AuditId,
                    Name: location.Name
                }, {
                    $set: updateParams
                }, locationCallback);
            }, callback);
        };
        this.UpdateStagedMemberProcessType = function (params, callback) {
            Async.each(params.Members, function (member, memberCallback) {
                var updateParams = {
                    ProcessType: member.ProcessType,
                    LocationId: member.LocationId || '',
                    DepartmentId: member.DepartmentId,
                    UCStatus: ProvisionEnums.ProcessStepStatus.NotStarted
                };
                if (member.ProcessType === ProvisionEnums.ProcessType.Update) {
                    updateParams.MemberId = member.MemberId;
                    updateParams.UserId = member.UserId;
                }
                EntityCache.ProvisionStagedMember.update({
                    AuditId: member.AuditId,
                    UserName: member.UserName
                }, {
                    $set: updateParams
                }, memberCallback);
            }, callback);
        };
        this.UpdateLocationStatus = function (params, callback) {
            Async.each(params.Locations, function (location, locationCallback) {
                EntityCache.ProvisionStagedLocation.update({
                    AuditId: params.AuditId,
                    Name: location.Name
                }, {
                    $set: {
                        hgId: location.hgId,
                        Status: ProvisionEnums.ProcessStepStatus.Processed
                    }
                }, locationCallback);
            }, callback);
        };
        this.UpdateStagedMemberManagerStatus = function (params, callback) {
            EntityCache.ProvisionStagedMember.update({
                GroupId: params.GroupId,
                AuditId: params.AuditId,
                ManagerUserName: params.ManagerUserName,
                UserName: {$in: params.DirectReports}
            }, {
                $set: {
                    MUStatus: ProvisionEnums.ProcessStepStatus.Processed
                }
            }, {
                multi: true
            }, callback);
        };
        this.UpdateStagedMemberOffBoardStatus = function (params, callback) {
            EntityCache.ProvisionStagedMember.update({
                GroupId: params.GroupId,
                AuditId: params.AuditId,
                UserName: params.UserName
            }, {
                $set: {
                    OBStatus: ProvisionEnums.ProcessStepStatus.Processed
                }
            }, callback);
        };
        this.UpdateStagedMemberNewUserNameStatus = function (params, callback) {
            EntityCache.ProvisionStagedMember.update({
                GroupId: params.GroupId,
                AuditId: params.AuditId,
                NewUserName: {$in: params.NewUserNames}
            }, {
                $set: {
                    NUStatus: ProvisionEnums.ProcessStepStatus.Processed
                }
            }, {
                multi: true
            }, callback);
        };
        this.UpdateStagedMemberStatus = function (params, callback) {
            Async.each(params.StagedMembers, function (data, memberCallback) {
                EntityCache.ProvisionStagedMember.update({
                    AuditId: params.AuditId,
                    UserName: data.UserName
                }, {
                    $set: {
                        UserId: data.UserId,
                        MemberId: data.MemberId,
                        UCStatus: ProvisionEnums.ProcessStepStatus.Processed
                    }
                }, memberCallback);
            }, callback);
        };
        this.SetProceessedLocationStatus = function (params) {
            EntityCache.ProvisionStagedLocation.count({
                AuditId: params.AuditId,
                Status: ProvisionEnums.ProcessStepStatus.NotStarted
            }, function (error, count) {
                if (error) {
                    return HgLog.error(error);
                }
                if (!count) {
                    EntityCache.ProvisionAudit.update({
                        _id: mongoose.Types.ObjectId(params.AuditId),
                    }, {
                        $set: {
                            LocationStatus: ProvisionEnums.ProcessStepStatus.Processed
                        }
                    }).exec();
                }
            });
        };
        this.SetProcessedManagerUpdatedStatus = function (params, callback) {
            if ([ProvisionEnums.Type.Onboard,
                    ProvisionEnums.Type.APIOnboard,
                    ProvisionEnums.Type.APIUpdate].indexOf(params.Type) > -1) {
                EntityCache.ProvisionAudit.update({
                    _id: mongoose.Types.ObjectId(params.AuditId)
                }, {
                    $set: {
                        MemberStatus: ProvisionEnums.ProcessStepStatus.Processed
                    }
                }).exec(callback);
            } else {
                Async.parallel({
                    audit: function (fcallback) {
                        EntityCache.ProvisionAudit.update({
                            _id: mongoose.Types.ObjectId(params.AuditId)
                        }, {
                            $set: {
                                MemberProcessStep: ProvisionEnums.ProcessMemberStep.NewUserName,
                                MemberStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
                            }
                        }).exec(fcallback);
                    },
                    members: function (fcallback) {
                        EntityCache.ProvisionStagedMember.update({
                            AuditId: params.AuditId,
                            NewUserName: {$exists: true, $ne: ""}
                        }, {
                            $set: {
                                ProcessStep: ProvisionEnums.ProcessMemberStep.NewUserName,
                                NUStatus: ProvisionEnums.ProcessStepStatus.NotStarted
                            }
                        }, {
                            multi: true
                        }).exec(fcallback);
                    }
                }, callback);
            }
        };
        this.SetProcessedMemberUserNameStatus = function (params, callback) {
            Async.parallel({
                audit: function (fcallback) {
                    EntityCache.ProvisionAudit.update({
                        _id: mongoose.Types.ObjectId(params.AuditId)
                    }, {
                        $set: {
                            MemberProcessStep: ProvisionEnums.ProcessMemberStep.OffBoard,
                            MemberStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
                        }
                    }).exec(fcallback);
                },
                members: function (fcallback) {
                    EntityCache.ProvisionStagedMember.update({
                        AuditId: params.AuditId,
                        OffBoardType: {$exists: true, $ne: ""}
                    }, {
                        $set: {
                            ProcessStep: ProvisionEnums.ProcessMemberStep.OffBoard,
                            OBStatus: ProvisionEnums.ProcessStepStatus.NotStarted
                        }
                    }, {
                        multi: true
                    }).exec(fcallback);
                }
            }, callback);
        };
        this.SetProceessedMemberStatus = function (params, callback) {
            EntityCache.ProvisionStagedMember.count({
                AuditId: params.AuditId,
                ProcessStep: ProvisionEnums.ProcessMemberStep.UserCreationAndUpdate,
                UCStatus: ProvisionEnums.ProcessStepStatus.NotStarted
            }, function (error, count) {
                if (error || count) {
                    return callback(error, count);
                }
                Async.parallel({
                    audit: function (fcallback) {
                        EntityCache.ProvisionAudit.update({
                            _id: mongoose.Types.ObjectId(params.AuditId),
                        }, {
                            $set: {
                                MemberProcessStep: ProvisionEnums.ProcessMemberStep.ManagerUpdate,
                                MemberStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
                            }
                        }).exec(fcallback);
                    },
                    members: function (fcallback) {
                        EntityCache.ProvisionStagedMember.update({
                            AuditId: params.AuditId,
                            ManagerUserName: {$exists: true, $ne: ""}
                        }, {
                            $set: {
                                ProcessStep: ProvisionEnums.ProcessMemberStep.ManagerUpdate,
                                MUStatus: ProvisionEnums.ProcessStepStatus.NotStarted
                            }
                        }, {
                            multi: true
                        }).exec(fcallback);
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    return callback(null, count);
                });
            });
        };
        this.SetProceessedDepartmentStatus = function (params) {
            EntityCache.ProvisionAudit.update({
                _id: mongoose.Types.ObjectId(params.AuditId)
            }, {
                $set: {
                    DepartmentStatus: ProvisionEnums.ProcessStepStatus.Processed
                }
            }).exec();
        };
        this.SetLocationStatusToProcessing = function (params, callback) {
            EntityCache.ProvisionAudit.findOne({
                _id: params.AuditId,
                LocationStatus: ProvisionEnums.ProcessStepStatus.BeginProcessing
            }, function (error, data) {
                if (error || !data) {
                    return callback(error);
                }
                data.LocationStatus = ProvisionEnums.ProcessStepStatus.Processing;
                data.save(callback);
            });
        };
        this.UpdateManagerUsernameByEmployeeId = function (params, callback) {
            Async.eachLimit(Object.keys(params.Data), 250, function (employeeData, eCallback) {
                if (!params.Data[employeeData] || !params.Data[employeeData].UserName) {
                    return eCallback();
                }
                EntityCache.ProvisionStagedMember.update({
                    ManagerEmpID: employeeData
                }, {
                    $set: {
                        ManagerUserName: params.Data[employeeData].UserName,
                        MemberStatus: ProvisionEnums.ProcessStepStatus.Processed
                    }
                }, {
                    multi: true
                }, eCallback);
            }, callback);
        };
        this.SetMemberStatusToProcessing = function (params) {
            var query = {
                _id: mongoose.Types.ObjectId(params.AuditId),
                MemberProcessStep: ProvisionEnums.ProcessMemberStep.NotStarted
            }, update = {
                MemberStatus: ProvisionEnums.ProcessStepStatus.Processing
            };
            if (params.Type === ProvisionEnums.Type.OffBoard) {
                update.MemberProcessStep = ProvisionEnums.ProcessMemberStep.OffBoard;
                update.GroupStatus = ProvisionEnums.ProcessStepStatus.Processed;
            } else {
                query.MemberStatus = ProvisionEnums.ProcessStepStatus.BeginProcessing;
            }
            EntityCache.ProvisionAudit.update(query, {$set: update}).exec();
        };
        this.GetOnboardedMemberDepartments = function (params, callback) {
            EntityCache.ProvisionStagedMember.aggregate([
                {$match: {
                    AuditId: params.AuditId
                }},
                {$group: {
                    _id:  {
                        DepartmentId: "$DepartmentId",
                        DepartmentName: "$Department",
                    },
                    teamMembers: { $addToSet: {
                        MemberFullName: "$FullName",
                        MemberId: "$MemberId",
                        TeamId: "$DepartmentId"
                    }}
                }}
            ], callback);
        };
        this.UpdateProvisionLog = function (params, callback) {
            var updateParams = {
                Id: params.AuditId,
                Note: {
                    Time: Date.now(),
                    Text: params.Note
                }
            };
            if (params.Status) {
                updateParams.Status = params.Status;
            }
            if (params.GroupStatus) {
                updateParams.GroupStatus = params.GroupStatus;
            }
            if (params.NewGroupId) {
                updateParams.NewGroupId = params.NewGroupId;
            }
            if (params.LocationStatus) {
                updateParams.LocationStatus = params.LocationStatus;
            }
            self.UpdateProvisionAudit(updateParams, function (error) {
                if (error) {
                    return HgLog.error(error);
                }
                PusherManager.ProvisionFileUpdated({
                    Data: {
                        Id: params.AuditId,
                        Status: ProvisionEnums.Status.ProcessingFile,
                        ModifiedDate: Date.now()
                    }
                });
                if (callback) {
                    return callback();
                }
            });
        };
        this.GetProvisionMapFile = function (params, callback) {
            EntityCache.ProvisionFileMap.findOne({GroupId: params.GroupId}, {}, {lean: true}, callback);
        };
        this.RemoveOffBoardManagerUserNames = function (params, callback) {
            EntityCache.ProvisionStagedMember.update({
                AuditId: params.AuditId,
                ManagerUserName: {$in: params.ManagerUserNames}
            }, {
                $set: {
                    Manager: '',
                    ManagerUserName: ''
                }
            }, {
                multi: true
            }, callback);
        };
        this.SetNewUserName = function (params, callback) {
            Async.eachSeries(params.UserNameChanges, function (changeRecord, cCallback) {
                EntityCache.ProvisionStagedMember.update({
                    AuditId: params.AuditId,
                    EmpID: changeRecord.EmployeeId
                }, {
                    $set: {
                        UserName: changeRecord.CurrentUserName,
                        NewUserName: changeRecord.NewUserName,
                        UserNameChangeType: changeRecord.UserNameChangeType
                    }
                }, cCallback);
            }, callback);
        };
        this.StageDirectReportsWithNewManager = function (params, callback) {
            if (!params.Data || !params.Data.length) {
                return callback();
            }
            EntityCache.ProvisionStagedMember.insertMany(params.Data, callback);
        };
        this.IsUserBeenOffboarded = function (params, callback) {
            EntityCache.ProvisionStagedMember.count({
                AuditId: params.AuditId,
                GroupId: params.GroupId,
                UserName: params.UserName,
                OffBoardType: {$exists: true, $ne: "", $in: [/^voluntary$/i, /^involuntary$/i]}
            }, callback);
        };
        this.UpdateStageDirectReportsWithNewManager = function (params, callback) {
            if (!params.UserNames.length) {
                return callback();
            }
            EntityCache.ProvisionStagedMember.update({
                AuditId: params.AuditId,
                UserName: {$in: params.UserNames},
                ManagerEmpID: params.OldManagerEmpID
            }, {
                $set: {
                    SpecialNote: params.SpecialNote,
                    ManagerUserName: params.ManagerUserName,
                    Manager: params.Manager,
                    ManagerEmpID: params.ManagerEmpID
                }
            }, {
                multi: true
            }, callback);
        };
    };

module.exports = ProvisionProcessor;