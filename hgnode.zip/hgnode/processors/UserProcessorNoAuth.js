/*jslint node:true es5:true nomen:true */
/*
    This entire business layer exists for the sole purpose of the Authorize and Login methods.
    DO NOT ADD SECURITY-SENSTIVE METHODS TO THIS BUSINESS LAYER.
*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    UserProcessorNoAuth = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EventEmitterCache = this.EventEmitterCache,
            self = this,
            HGActivityLog = require('../framework/HGActivityLog.js'),
            Async = require('async'),
            cloneextend = require('cloneextend'),
            EventData = require('../common/EventData.js'),
            HgError = require('../common/HgError.js'),
            Services = require('../security/Services.js'),
            Roles = require('../security/Roles.js'),
            Permissions = require('../security/Permissions.js'),
            EntityCache = require('../framework/EntityCache.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            AuthEnums = require('../enums/AuthEnums.js'),
            AccountTypeEnums = require('../enums/AccountType'),
            HgLog = require('../framework/HgLog.js'),
            MemberEnums = require('../enums/MemberEnums.js'),
            FeatureFlagEnums = require('../enums/FeatureFlagEnums.js'),
            EventResponder = require('../util/EventResponder.js'),
            uuid = require('node-uuid'),
            UserSecurityStatus = require('../enums/UserSecurityStatus.js'),
            cryptoHelper = require('../helpers/cryptoHelper'),
            i18nHelper = require('../helpers/i18nHelper'),
            config = require('../configurations/config');

        function roleFilter(m) {
            return m.Name === 'Roles';
        }

        function permissionFilter(m) {
            return m.Name === 'Permissions';
        }

        function getRequiredPermissionInGroup(ServiceName, MethodName) {
            var permissions = [];
            if (Services[ServiceName] && Services[ServiceName].SecuredMethods && Services[ServiceName].SecuredMethods[MethodName]) {
                permissions = Services[ServiceName].SecuredMethods[MethodName];
            }
            return permissions;
        }

        function doesUserHavePermissionInGroup(userInfoWithToken, ServiceName, MethodName) {
            var requiredPermissionsInGroup = getRequiredPermissionInGroup(ServiceName, MethodName),
                permissionsInGroupOfCurrentUser,
                i,
                len,
                matchingPermissionFound = false;
            if (!userInfoWithToken || !userInfoWithToken.UserContext) {
                return false;
            }
            permissionsInGroupOfCurrentUser = userInfoWithToken.UserContext.PermissionsInGroup || '';
            if (!requiredPermissionsInGroup.length) { // the method is not secured
                matchingPermissionFound = true;
            } else {
                for (i = 0, len = requiredPermissionsInGroup.length; i < len; i += 1) {
                    matchingPermissionFound = permissionsInGroupOfCurrentUser.indexOf(requiredPermissionsInGroup[i]) > -1;
                    if (matchingPermissionFound) {
                        break;
                    }
                }
            }
            return matchingPermissionFound;
        }

        function loadUserAccountBalances(params, callback) {
            var userInfoWithToken = params.UserInfoWithToken;
            EntityCache.CreditAccount.find({OwnerId: {$in: [userInfoWithToken.UserContext.MemberIdInGroup, userInfoWithToken.hgId] }}, function (err, accounts) {
                var i,
                    len,
                    accMap = {},
                    newAcctArray = [];
                if (err) {
                    return callback(err);
                }
                accMap[AccountTypeEnums.PointSpend] = ['PointSpendingBalance', {
                    OwnerId: userInfoWithToken.UserContext.MemberIdInGroup,
                    CreatedBy: userInfoWithToken.UserContext.MemberIdInGroup,
                    ModifiedBy: userInfoWithToken.UserContext.MemberIdInGroup
                }];
                accMap[AccountTypeEnums.PointTransfer] = ['PointTransferBalance', {
                    OwnerId: userInfoWithToken.UserContext.MemberIdInGroup,
                    CreatedBy: userInfoWithToken.UserContext.MemberIdInGroup,
                    ModifiedBy: userInfoWithToken.UserContext.MemberIdInGroup
                }];
                accMap[AccountTypeEnums.Spend] = ['SpendingAccountBalance', {
                    OwnerId: userInfoWithToken.hgId,
                    CreatedBy: userInfoWithToken.hgId,
                    ModifiedBy: userInfoWithToken.hgId
                }];
                accMap[AccountTypeEnums.Transfer] = ['TransferAccountBalanceInGroup', {
                    OwnerId: userInfoWithToken.UserContext.MemberIdInGroup,
                    CreatedBy: userInfoWithToken.hgId,
                    ModifiedBy: userInfoWithToken.hgId
                }];
                for (i = 0, len = accounts.length; i < len; i += 1) {
                    if (accMap[accounts[i].AccountType]) {
                        accMap[accounts[i].AccountType].push(accounts[i].Balance);
                    }
                }
                Object.keys(accMap).forEach(function (key) {
                    if (accMap[key].length === 2) {
                        // this is intentionally pusing a zero into the array, so the 3rd element has a value of zero to be assigned below
                        accMap[key].push(0);
                        accMap[key][1].hgId = uuid.v1();
                        accMap[key][1].AccountType = key;
                        newAcctArray.push(accMap[key][1]);
                    }
                    userInfoWithToken.UserFinance[accMap[key][0]] = accMap[key][2];
                });
                if (newAcctArray.length) {
                    EntityCache.CreditAccount.create(newAcctArray, function (err) {
                        if (err) {
                            HgLog.error(HgError.Enums.Credit.ErrorUpdating);
                        }
                    });
                }
                callback(null, userInfoWithToken);
            });
        }

        function loadByUserToken(params, callback) {
            var mquery = EntityCache.UserInfoWithToken.findOne({ActAsUserToken: params.token}),
                newParams = {
                    correlationId: params.correlationId
                };
            if (params.type === 'UserToken') {
                mquery = EntityCache.UserInfoWithToken.findOne({UserToken: params.token});
            }
            if (params.token) {
                mquery.exec(function (err, userInfoWithToken) {
                    if (err) {
                        return callback('business.user.noauth.eluiwt');
                    }
                    if (!userInfoWithToken) {
                        //Enum Used in request Manger and is needed by mobile team
                        return callback(HgError.Enums.User.InvalidUserToken);
                    }
                    newParams.UserInfoWithToken = userInfoWithToken;
                    loadUserAccountBalances(newParams, function (error, userInfoWithToken) {
                        if (error) {
                            return callback(error);
                        }
                        EntityCache.Member.findOne({hgId: userInfoWithToken.UserContext.MemberIdInGroup}, function (err, member) {
                            if (err) {
                                return callback(err);
                            }
                            if (member && member.hgId) {
                                userInfoWithToken.UserContext.ExperiencePoint = member.ExperiencePoint;
                                userInfoWithToken.UserContext.MyManagers = member.MyManagers;
                                userInfoWithToken.UserContext.GravatarEmail = member.GravatarEmail;
                            }
                            callback(null, userInfoWithToken);
                        });
                    });
                });
            } else {
                callback('business.user.noauth.vl');
            }
        }

        function verifyUserHasPermission(eventData, callback) {
            var userSecurityWithToken = eventData.payload,
                token = eventData.ActAsUserToken || eventData.UserToken,
                type = 'ActAsUserToken';
            if (!eventData.ActAsUserToken) {
                type = 'UserToken';
            }
            if (userSecurityWithToken.AvailableServiceArray.indexOf(eventData.ServiceName) === -1) { //user's security set not contains the service
                return callback(JSON.stringify(['server.hge.ath.usc', {ServiceName:  eventData.ServiceName}]));
            }
            loadByUserToken({token: token, type: type}, function (error, userInfoWithToken) {
                var accessGranted = doesUserHavePermissionInGroup(userInfoWithToken, eventData.ServiceName, eventData.MethodName);
                if (error) {
                    return callback(error);
                }
                HGActivityLog.SaveActivity({
                    CorrelationId: eventData.correlationId,
                    UserId: userInfoWithToken.hgId,
                    GroupId: userInfoWithToken.UserContext.CurrentGroupId,
                    GroupName: userInfoWithToken.UserContext.CurrentGroupName,
                    MemberId: userInfoWithToken.UserContext.MemberIdInGroup,
                    FullName: userInfoWithToken.UserPersonal.FullName,
                    ServiceName: eventData.ServiceName,
                    MethodName: eventData.MethodName,
                    IPAddress: eventData.IPAddress,
                    AccessGranted: accessGranted,
                    BrowserFingerPrint: eventData.BrowserFingerPrint,
                    Source: eventData.Source,
                    UserAgent: eventData.UserAgent
                });
                if (accessGranted) {
                    eventData.payload = userInfoWithToken;
                    return callback(null, eventData);
                }
                callback('server.hge.ath.usp');
            });
        }

        function array_unique(oldArray) {
            var newArray = [],
                i,
                len;
            for (i = 0, len = oldArray.length; i < len; i += 1) {
                if (newArray.indexOf(oldArray[i]) === -1) {
                    newArray.push(oldArray[i]);
                }
            }
            return newArray;
        }

        function mergeSecuredTabs(mergedSecuredTabs, securedTabs) {
            var mtabfields = Object.keys(mergedSecuredTabs),
                stabfields = Object.keys(securedTabs),
                i,
                len;
            for (i = 0, len = mtabfields.length; i < len; i += 1) {
                if (securedTabs[mtabfields[i]]) {
                    mergedSecuredTabs[mtabfields[i]] = mergedSecuredTabs[mtabfields[i]].concat(securedTabs[mtabfields[i]]);
                    mergedSecuredTabs[mtabfields[i]] = array_unique(mergedSecuredTabs[mtabfields[i]]);
                }
            }
            for (i = 0, len = stabfields.length; i < len; i += 1) {
                if (!mergedSecuredTabs[stabfields[i]]) {
                    mergedSecuredTabs[stabfields[i]] = securedTabs[stabfields[i]];
                }
            }
        }

        function getFeatureFlags(group) {
            var featureFlags = {};
            featureFlags[FeatureFlagEnums.DisableFeatureByRole] = [];
            if (group && group.Preference && group.Preference.FeatureFlags) {
                group.Preference.FeatureFlags.forEach(function (featureFlag) {
                    if (featureFlag.FeatureEnabled) {
                        if (featureFlag.FeatureName === FeatureFlagEnums.DisableFeatureByRole) {
                            featureFlags[FeatureFlagEnums.DisableFeatureByRole].push(featureFlag);
                        } else {
                            featureFlags[featureFlag.FeatureName] = true;
                        }
                    }
                });
            }
            return featureFlags;
        }

        function removeTab(tabs, tabname) {
            if (tabs) {
                var idx = tabs.indexOf(tabname);
                if (idx > -1) {
                    tabs.splice(idx, 1);
                }
            }
        }

        function addTab(tabs, tabname) {
            tabs = tabs || [];
            if (tabs.indexOf(tabname) === -1) {
                tabs.push(tabname);
            }
        }

        function getPermissionSecuredTabsDSS(params,featuremapping) {
            var secureTabs = {},
                secureTabsDSS = {},
                secureTabsDSS1 = {},
                featureFlags,
                roles,
                features,
                permissions,
                d,
                dlen,
                p,
                plen,
                permParts,
                idx,
                permFilter = function (m) {
                    return m.Name === 'Permissions';
                };

            function typePermissionFilter(m) {
                return m.Type === 'Tab';
            }

            function filterMemberPermission(j,m) {
                return j.filter(function(obj) {
                    return obj.Permission ===  m ;
                });
            }


            function populatingPermission(featureProcess){

                featureProcess.filter(typePermissionFilter).forEach(function(successCondition){
                    var condTabs = ""

                    var customLogic = true;
                    if (successCondition.CustomLogic && successCondition.CustomLogic !== "")
                    {
                        try {
                            customLogic = eval(successCondition.CustomLogic)
                        } catch(e) {
                            customLogic = true;
                        }
                    }


                    if (successCondition && customLogic) {
                        if (successCondition.Action === "Add") {
                            var tabsValue = successCondition.PermissionName.split(".")
                            if (tabsValue.length === 2) {
                                condTabs = eval("secureTabs." + tabsValue[0]);
                                addTab(condTabs, tabsValue[1])
                            }
                        }
                        else {

                            var tabsValue = successCondition.PermissionName.split(".")
                            if (tabsValue.length === 2) {
                                condTabs = eval("secureTabs." + tabsValue[0]);
                                removeTab(condTabs, tabsValue[1]);

                            }
                            else {
                                condTabs = eval("secureTabs." + tabsValue[0] + " = []");
                            }
                        }
                    }
                })
            }

            if (MemberEnums.MemberPermission[params.permissionName]) {
                secureTabs = cloneextend.clone(MemberEnums.MemberPermission[params.permissionName].SecuredTabs);
            }

            //secureTabsDSS = filterMemberPermission(memberPermissions,params.permissionName)[0]

            featureFlags = getFeatureFlags(params.group);

            //if (secureTabsDSS && secureTabsDSS.SecuredTabs) {
            //if (secureTabs) {

                //secureTabs = secureTabsDSS.SecuredTabs[0]

                if (featuremapping) {
                    featuremapping.forEach(function (feature) {
                        var valueFeature = feature.Feature;
                        //console.log(valueFeature)
                        var checkCond = featureFlags[valueFeature];
                        var customLogic = true;
                        if (feature.CustomLogic && feature.CustomLogic !== "") {
                            try {
                                customLogic = eval(feature.CustomLogic)
                            } catch (e) {
                                customLogic = true;

                            }
                        }


                        if (checkCond && customLogic) {

                            if (feature.TrueCondition) {
                                populatingPermission(feature.TrueCondition)
                            }
                        }
                        else {
                            if (feature.FalseCondition) {
                                populatingPermission(feature.FalseCondition)
                            }
                        }
                    });
                }
            //}

            // remove disabled feature by role
            for (d = 0, dlen = featureFlags[FeatureFlagEnums.DisableFeatureByRole].length; d < dlen; d += 1) {
                roles = featureFlags[FeatureFlagEnums.DisableFeatureByRole][d].FeatureMeta.filter(roleFilter);
                features = featureFlags[FeatureFlagEnums.DisableFeatureByRole][d].FeatureMeta.filter(permFilter);
                if (roles.length === 1 && features.length === 1) {
                    // disable Admin feature if HGAdmin feature is disabled as well
                    if (roles[0].Value.indexOf(params.userRole) > -1) {
                        permissions = features[0].Value.split(',');
                        for (p = 0, plen = permissions.length; p < plen; p += 1) {
                            permParts = permissions[p].split('.');
                            if (permParts.length === 2) {
                                idx = secureTabs[permParts[0].trim()];
                                if (idx) {
                                    idx = idx.indexOf(permParts[1].trim());
                                    if (idx > -1) {
                                        secureTabs[permParts[0].trim()].splice(idx, 1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return secureTabs;
        }

        function getPermissionSecuredTabs(params) {
            var secureTabs = {},
                featureFlags,
                roles,
                features,
                permissions,
                d,
                dlen,
                p,
                plen,
                permParts,
                idx,
                permFilter = function (m) {
                    return m.Name === 'Permissions';
                };
            if (MemberEnums.MemberPermission[params.permissionName]) {
                secureTabs = cloneextend.clone(MemberEnums.MemberPermission[params.permissionName].SecuredTabs);
            }
            // this is temporary code to remove perform from everyone except companies that have the EnablePerform flag turned on
            // we will replace this with the feature package code when completed
            featureFlags = getFeatureFlags(params.group);
            // this is temporary code to add the share link permission to everyone that has the ShareLink flag turned on
            // it does not look at the individual social media meta data yet
            if (featureFlags[FeatureFlagEnums.ShareLink] && secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('shareLink') === -1) {
                secureTabs.recognizeTabs.push('shareLink');
            }
            // allow the group to see perform tab
            if (featureFlags[FeatureFlagEnums.EnablePerform]) {
                if (secureTabs.profileTabs && secureTabs.profileTabs.length) {
                    secureTabs.profileTabs.push('perform');
                }
            } else {
                removeTab(secureTabs.adminTabs, 'cardLibrary');
                removeTab(secureTabs.adminTabs, 'cycleSubTab');
                removeTab(secureTabs.adminTabs, 'recurringCycle');
                removeTab(secureTabs.profileTabs, 'perform');
            }
            // allow the group to see coaching tab
            if (featureFlags[FeatureFlagEnums.EnableCoaching] && secureTabs.profileTabs && secureTabs.profileTabs.length) {
                secureTabs.profileTabs.push('coaching');
            }
            if (featureFlags[FeatureFlagEnums.EnableFeedback] && secureTabs.profileTabs && secureTabs.profileTabs.length) {
                secureTabs.profileTabs.push('feedback');
            }
            if (!featureFlags[FeatureFlagEnums.EnableTeamTab]) {
                secureTabs.teamTabs = [];
            }
            if (!featureFlags[FeatureFlagEnums.EnableDisplay]) {
                removeTab(secureTabs.adminTabs, 'manageDisplay');
            }
            if (featureFlags[FeatureFlagEnums.SuggestRewardIdea] && secureTabs.motivateTabs && secureTabs.motivateTabs.length) {
                secureTabs.motivateTabs.push('suggestRewardIdea');
            }
            if (featureFlags[FeatureFlagEnums.TrackObjectiveWeight] && secureTabs.trackTabs && secureTabs.trackTabs.length) {
                secureTabs.trackTabs.push('trackObjectiveWeight');
            }
            if (featureFlags[FeatureFlagEnums.AnswerLibrary] && secureTabs.profileTabs && secureTabs.profileTabs.length) {
                secureTabs.profileTabs.push('answerLibrary');
            }
            if (featureFlags[FeatureFlagEnums.EnableAddPoints] && secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('addPoints') === -1) {
                secureTabs.recognizeTabs.push('addPoints');
            }
            // this is temporary for MileagePlus
            if (featureFlags[FeatureFlagEnums.MileagePlus]) {
                addTab(secureTabs.motivateTabs, 'mileagePlus');
            }
            if (featureFlags[FeatureFlagEnums.DemoSettings]) {
                addTab(secureTabs.adminTabs, 'demoSettings');
            }
            if (featureFlags[FeatureFlagEnums.DemoStaticData]) {
                addTab(secureTabs.teamTabs, 'demoStaticData');
            }
            if (featureFlags[FeatureFlagEnums.RelevancyFilter]) {
                addTab(secureTabs.userTabs, 'relevancyFilter');
            }
            // add all permissions for sales demo
            if (featureFlags[FeatureFlagEnums.ForSalesDemo]) {
                addTab(secureTabs.motivateTabs, 'pointStore');
                addTab(secureTabs.userTabs, 'forSalesDemo');
                addTab(secureTabs.adminTabs, 'reports');
                if (!secureTabs.companyTabs) {
                    secureTabs.companyTabs = [];
                }
                addTab(secureTabs.adminTabs, MemberEnums.MemberPermission.ViewAnalytics.SecuredTabs.adminTabs[0]);
                // add demo team tabs
                addTab(secureTabs.teamTabs, 'recognizedemo');
                addTab(secureTabs.teamTabs, 'goalsdemo');
                addTab(secureTabs.teamTabs, 'coachingdemo');
                addTab(secureTabs.teamTabs, 'performdemo');
                addTab(secureTabs.teamTabs, 'actiondemo');
            } else {
                removeTab(secureTabs.teamTabs, 'actiondemo');
            }
            // check for disabled tracks
            if (featureFlags[FeatureFlagEnums.DisableTracks]) {
                secureTabs.trackTabs = [];
            }
            // check for disabled motivate
            if (featureFlags[FeatureFlagEnums.DisableMotivate]) {
                secureTabs.motivateTabs = [];
                // turn off other features related to motivate
                removeTab(secureTabs.userTabs, 'paymentInfo');
                removeTab(secureTabs.userTabs, 'credits');
                removeTab(secureTabs.adminTabs, 'credits');
                removeTab(secureTabs.recognizeTabs, 'sendCredits');
                removeTab(secureTabs.userTabs, 'points');
                removeTab(secureTabs.adminTabs, 'points');
            } else {
                if (!featureFlags[FeatureFlagEnums.EnablePoints] && secureTabs.motivateTabs && secureTabs.motivateTabs.length) {
                    removeTab(secureTabs.motivateTabs, 'pointStore');
                    removeTab(secureTabs.userTabs, 'points');
                    removeTab(secureTabs.adminTabs, 'points');
                }
            }
            //switch for recognition 2.0
            if (featureFlags[FeatureFlagEnums.Recognition2]) {
                if (secureTabs.recognizeTabs) {
                    if (secureTabs.recognizeTabs.indexOf('recognition2') === -1 && secureTabs.recognizeTabs.indexOf('giveRecognition') > -1) {
                        secureTabs.recognizeTabs.push('recognition2');
                    }
                    if (featureFlags[FeatureFlagEnums.DisableValues]) {
                        secureTabs.recognizeTabs = secureTabs.recognizeTabs.filter(function (tab) {
                            return tab !== 'valuesRecognition';
                        });
                    }
                }
                if (secureTabs.profileTabs && secureTabs.profileTabs.indexOf('profile') === -1) {
                    secureTabs.profileTabs.push('profile');
                }
                if (secureTabs.profileTabs && secureTabs.profileTabs.indexOf('recognition') === -1) {
                    secureTabs.profileTabs.push('recognition');
                }
            } else {
                // remove anything related to recognize in the other areas
                secureTabs.recognizeTabs = [];
                // remove company and profile links
                secureTabs.companyTabs = [];
                removeTab(secureTabs.profileTabs, 'profile');
                removeTab(secureTabs.profileTabs, 'recognition');
                removeTab(secureTabs.userTabs, 'recognizeMeLinks');
                removeTab(secureTabs.adminTabs, 'recognitions');
                removeTab(secureTabs.trackTabs, 'addCredits');
            }
            //switch for points
            if (!featureFlags[FeatureFlagEnums.EnablePoints] || featureFlags[FeatureFlagEnums.DisableMotivate]) {
                removeTab(secureTabs.adminTabs, 'points');
                removeTab(secureTabs.motivateTabs, 'pointStore');
                removeTab(secureTabs.motivateTabs, 'givePointGift');
                removeTab(secureTabs.recognizeTabs, 'sendPoints');
                removeTab(secureTabs.recognizeTabs, 'addPoints');
                removeTab(secureTabs.recognizeTabs, 'showPointsInFeed');
                removeTab(secureTabs.trackTabs, 'addPoints');
                removeTab(secureTabs.motivateTabs, 'addGiftNew');
                removeTab(secureTabs.motivateTabs, 'addGiftOld');
                removeTab(secureTabs.motivateTabs, 'grsStorefront');
            }
            if (featureFlags[FeatureFlagEnums.SpendCreditTransfer]) {
                addTab(secureTabs.userTabs, 'transferSpendCredits');
            } else {
                removeTab(secureTabs.userTabs, 'transferSpendCredits');
            }
            //switch for yammer integration
            if (!featureFlags[FeatureFlagEnums.YammerIntegration]) {
                removeTab(secureTabs.adminTabs, 'yammerIntegration');
            }
            //switch for GRS, disable if GRS or Points or Motivate are turned off
            if (!featureFlags[FeatureFlagEnums.GRSStorefront] || !featureFlags[FeatureFlagEnums.EnablePoints] || featureFlags[FeatureFlagEnums.DisableMotivate]) {
                removeTab(secureTabs.motivateTabs, 'grsStorefront');
            }
            if (featureFlags[FeatureFlagEnums.HideAdminDepartment]) {
                removeTab(secureTabs.adminTabs, 'manageDepartment');
            }
            //switch for rules engine
            if (!featureFlags[FeatureFlagEnums.RulesEngine]) {
                removeTab(secureTabs.adminTabs, 'rules');
            }
            if (!featureFlags[FeatureFlagEnums.RecurringCycle]) {
                removeTab(secureTabs.adminTabs, 'recurringCycle');
            }
            if (!featureFlags[FeatureFlagEnums.EnablePolling]) {
                removeTab(secureTabs.profileTabs, 'poll');
                removeTab(secureTabs.profileTabs, 'rpoll');
            }
            //switch for public API
            if (!featureFlags[FeatureFlagEnums.PublicAPI]) {
                removeTab(secureTabs.adminTabs, 'manageAPI');
            }
            if (!featureFlags[FeatureFlagEnums.EnableBenchmarkSurvey]) {
                removeTab(secureTabs.userTabs, 'userBenchmarkSurvey');
            }
            if (!featureFlags[FeatureFlagEnums.EnablePulseSurvey]) {
                removeTab(secureTabs.userTabs, 'userPulseSurvey');
            }
            if (!featureFlags[FeatureFlagEnums.EnableBenchmarkSurvey] && !featureFlags[FeatureFlagEnums.EnablePulseSurvey]) {
                removeTab(secureTabs.adminTabs, 'adminSurveys');
            }
            if (featureFlags[FeatureFlagEnums.HidePasswordLogins]) {
                //hide password fields if HidePasswordLogins enabled
                addTab(secureTabs.userTabs, 'hidePasswordField');
            }
            if (featureFlags[FeatureFlagEnums.EnableNineBox]) {
                addTab(secureTabs.userTabs, 'enableNineBox');
            }
            if (featureFlags[FeatureFlagEnums.MultiManager]) {
                addTab(secureTabs.userTabs, 'multiManager');
            }
            // remove disabled feature by role
            for (d = 0, dlen = featureFlags[FeatureFlagEnums.DisableFeatureByRole].length; d < dlen; d += 1) {
                roles = featureFlags[FeatureFlagEnums.DisableFeatureByRole][d].FeatureMeta.filter(roleFilter);
                features = featureFlags[FeatureFlagEnums.DisableFeatureByRole][d].FeatureMeta.filter(permFilter);
                if (roles.length === 1 && features.length === 1) {
                    // disable Admin feature if HGAdmin feature is disabled as well
                    if (roles[0].Value.indexOf(params.userRole) > -1) {
                        permissions = features[0].Value.split(',');
                        for (p = 0, plen = permissions.length; p < plen; p += 1) {
                            permParts = permissions[p].split('.');
                            if (permParts.length === 2) {
                                idx = secureTabs[permParts[0].trim()];
                                if (idx) {
                                    idx = idx.indexOf(permParts[1].trim());
                                    if (idx > -1) {
                                        secureTabs[permParts[0].trim()].splice(idx, 1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return secureTabs;
        }

        function aggregateSecuredTabsInGroupDSS(params,featuremapping) {
            var i, len,
                memberJSON = params.member.toJSON(),
                securedTabsInPermission = {},
                creditSubTabs = ['transferCredits', 'purchaseCredits', 'creditTransactions'],
                mergedSecuredTabs = getPermissionSecuredTabsDSS({
                    permissionName: params.user.UserContext.PermissionsInGroup[0],
                    group: params.group,
                    userRole: params.member.RolesInGroup[0]
                },featuremapping);
            for (i = 1, len = params.user.UserContext.PermissionsInGroup.length; i < len; i += 1) {
                securedTabsInPermission = getPermissionSecuredTabsDSS({
                    permissionName: params.user.UserContext.PermissionsInGroup[i],
                    group: params.group,
                    userRole: params.member.RolesInGroup[0]
                },featuremapping);
                mergeSecuredTabs(mergedSecuredTabs, securedTabsInPermission);
            }
            // determine if all credit sub-tabs are disabled and remove the main credits tab
            // note: the data structure should be refactored to include a parent/child relationship between main and
            //      subtabs, which would allow a less hacky way and more of a generic way of disabling a main tab when
            //      all subtabs are disabled
            if (mergedSecuredTabs.userTabs && mergedSecuredTabs.userTabs.length) {
                if (!mergedSecuredTabs.userTabs.filter(function (perm) {
                        return creditSubTabs.indexOf(perm) > -1;
                    }).length) {
                    removeTab(mergedSecuredTabs.userTabs, 'credits');
                }
            }
            // look at member-level permissions and include those
            if (memberJSON.AddedPermissions) {
                memberJSON.AddedPermissions.forEach(function (perm) {
                    var mperm = MemberEnums.MemberPermission[perm];
                    if (mperm) {
                        Object.keys(mperm.SecuredTabs).forEach(function (area) {
                            if (mperm.SecuredTabs[area]) {
                                mperm.SecuredTabs[area].forEach(function (permId) {
                                    addTab(mergedSecuredTabs[area], permId);
                                });
                            }
                        });
                    }
                });
            }
            if (memberJSON.RemovedPermissions) {
                memberJSON.RemovedPermissions.forEach(function (perm) {
                    var mperm = MemberEnums.MemberPermission[perm];
                    if (mperm) {
                        Object.keys(mperm.SecuredTabs).forEach(function (area) {
                            if (mperm.SecuredTabs[area]) {
                                mperm.SecuredTabs[area].forEach(function (permId) {
                                    removeTab(mergedSecuredTabs[area], permId);
                                });
                            }
                        });
                    }
                });
            }
            return mergedSecuredTabs;
        }

        function aggregateSecuredTabsInGroup(params) {
            var i, len,
                memberJSON = params.member.toJSON(),
                securedTabsInPermission = {},
                creditSubTabs = ['transferCredits', 'purchaseCredits', 'creditTransactions'],
                mergedSecuredTabs = getPermissionSecuredTabs({
                    permissionName: params.user.UserContext.PermissionsInGroup[0],
                    group: params.group,
                    userRole: params.member.RolesInGroup[0]
                });

            for (i = 1, len = params.user.UserContext.PermissionsInGroup.length; i < len; i += 1) {
                securedTabsInPermission = getPermissionSecuredTabs({
                    permissionName: params.user.UserContext.PermissionsInGroup[i],
                    group: params.group,
                    userRole: params.member.RolesInGroup[0]
                });
                mergeSecuredTabs(mergedSecuredTabs, securedTabsInPermission);
            }
            // determine if all credit sub-tabs are disabled and remove the main credits tab
            // note: the data structure should be refactored to include a parent/child relationship between main and
            //      subtabs, which would allow a less hacky way and more of a generic way of disabling a main tab when
            //      all subtabs are disabled
            if (mergedSecuredTabs.userTabs && mergedSecuredTabs.userTabs.length) {
                if (!mergedSecuredTabs.userTabs.filter(function (perm) {
                        return creditSubTabs.indexOf(perm) > -1;
                    }).length) {
                    removeTab(mergedSecuredTabs.userTabs, 'credits');
                }
            }
            // look at member-level permissions and include those
            if (memberJSON.AddedPermissions) {
                memberJSON.AddedPermissions.forEach(function (perm) {
                    var mperm = MemberEnums.MemberPermission[perm];
                    if (mperm) {
                        Object.keys(mperm.SecuredTabs).forEach(function (area) {
                            if (mperm.SecuredTabs[area]) {
                                mperm.SecuredTabs[area].forEach(function (permId) {
                                    addTab(mergedSecuredTabs[area], permId);
                                });
                            }
                        });
                    }
                });
            }
            if (memberJSON.RemovedPermissions) {
                memberJSON.RemovedPermissions.forEach(function (perm) {
                    var mperm = MemberEnums.MemberPermission[perm];
                    if (mperm) {
                        Object.keys(mperm.SecuredTabs).forEach(function (area) {
                            if (mperm.SecuredTabs[area]) {
                                mperm.SecuredTabs[area].forEach(function (permId) {
                                    removeTab(mergedSecuredTabs[area], permId);
                                });
                            }
                        });
                    }
                });
            }

            return mergedSecuredTabs;
        }

        function refreshUserSecurity(userSecurityWithToken, userSecurity) {
            var allpermissions = [],
                allServices = [],
                i,
                len,
                RoleName,
                permissions,
                PermissionName,
                services;
            for (i = 0, len = userSecurity.Roles.length; i < len; i += 1) {
                RoleName = userSecurity.Roles[i].RoleName;
                if (!RoleName) {
                    RoleName = userSecurity.Roles[i];
                }
                permissions = Roles[RoleName].Permissions;
                allpermissions = allpermissions.concat(permissions);
            }
            for (i = 0, len = allpermissions.length; i < len; i += 1) {
                PermissionName = allpermissions[i];
                services = Permissions[PermissionName].AvailableServices;
                allServices = allServices.concat(services);
            }
            userSecurityWithToken.AvailableServiceArray = allServices;
        }

        function disablePermissions(disableFeatures, memberRoleInGroup) {
            var i,
                len,
                roles,
                p,
                plen,
                features,
                permissions,
                permissionParts,
                disablePermissionsArray = [];
            for (i = 0, len = disableFeatures.length; i < len; i += 1) {
                roles = disableFeatures[i].FeatureMeta.filter(roleFilter);
                features = disableFeatures[i].FeatureMeta.filter(permissionFilter);
                if (roles.length === 1 && features.length === 1 && roles[0].Value.indexOf(memberRoleInGroup) > -1) {
                    permissions = features[0].Value.split(',');
                    for (p = 0, plen = permissions.length; p < plen; p += 1) {
                        permissionParts = permissions[p].split('.');
                        if (permissionParts.length === 2) {
                            disablePermissionsArray.push(permissionParts[1].trim());
                        }
                    }
                }
            }
            return disablePermissionsArray;
        }

        function aggregatePermissionsInGroupDSS(member, group, role,featuremapping) {
            var RoleName,
                permissionsInRole,
                permissionsInRoleDSS,
                allpermissions = [],
                i,
                len,
                index,
                featureFlags,
                permissionsToDisable;
            RoleName = member.RolesInGroup[0];
            //console.log(RoleName)
            //console.log("%%%%%")

            function filterMemberRole(j,m) {
                return j.filter(function(obj) {
                    return obj.Role ===  m ;
                });
            }

            permissionsInRole = MemberEnums.GetPermissionsInRole(RoleName);

            //permissionsInRole = filterMemberRole(memberRole,RoleName)[0].MemberPermissions

            allpermissions = allpermissions.concat(permissionsInRole);
            featureFlags = getFeatureFlags(group);

            function typePermissionFilter(m) {
                return m.Type === 'Permission';
            }

            function populatingPermission(featureProcess){

                featureProcess.filter(typePermissionFilter).forEach(function(successCondition){
                    if (successCondition.Action === "Add"){
                        member.AddedPermissions.push(successCondition.PermissionName)
                    }
                    else{
                        member.RemovedPermissions.push(successCondition.PermissionName)
                    }
                })
            }

            if (featuremapping ) {
                featuremapping.forEach(function (feature){
                    var valueFeature = feature.Feature;
                    var checkCond = featureFlags[valueFeature];
                    if (checkCond)
                    {
                        if (feature.TrueCondition) {
                            populatingPermission(feature.TrueCondition)
                        }
                    }
                    else
                    {
                        if (feature.FalseCondition) {
                            populatingPermission(feature.FalseCondition)
                        }
                    }
                });

                for (i = 0; i < member.AddedPermissions.length; i += 1) {
                    index = permissionsInRole.indexOf(member.AddedPermissions[i]);
                    if (index === -1) {
                        allpermissions.push(member.AddedPermissions[i]);
                    }
                }

                for (i = 0; i < member.RemovedPermissions.length; i += 1) {
                    index = allpermissions.indexOf(member.RemovedPermissions[i]);
                    if (index > -1) {
                        allpermissions.splice(index, 1);
                    }
                }
                if (role) {
                    for (i = 0; i < role.AddedPermissions.length; i += 1) {
                        index = member.RemovedPermissions.indexOf(role.AddedPermissions[i]);
                        if (index === -1) {
                            allpermissions.push(role.AddedPermissions[i]);
                        }
                    }
                }
                permissionsToDisable = disablePermissions(featureFlags[FeatureFlagEnums.DisableFeatureByRole], member.RolesInGroup[0]);
                if (permissionsToDisable.length) {
                    for (i = 0, len = permissionsToDisable.length; i < len; i += 1) {
                        index = allpermissions.indexOf(permissionsToDisable[i].charAt(0).toUpperCase() + permissionsToDisable[i].slice(1));
                        if (index > -1 && member.AddedPermissions.indexOf(permissionsToDisable[i]) === -1) {
                            allpermissions.splice(index, 1);
                        }
                    }
                }
            }
            return allpermissions;
        }

        function aggregatePermissionsInGroupQuery(member, group, role,callback){

            var allpermissions = [],
                //RoleName = [ "$RoleName", "$RolesInGroup" ] ;
                RoleName = [ "$RoleName", member.RolesInGroup[0] ] ;

            var query = {
                hgId: member.hgId
            };

            console.log(RoleName)

            EntityCache.Member.aggregate([
                {$match: query},
                {$project : {AddedPermissions : 1,RemovedPermissions : 1,RolesInGroup : 1,GroupId : 1}},
                {$unwind : "$RolesInGroup" },
                {
                    $lookup: {
                        from: "Role",
                        localField: "RolesInGroup",
                        foreignField: "Role",
                        as: "roleInfoData"
                    }
                },
                {"$unwind" : {path: "$roleInfoData", preserveNullAndEmptyArrays: true}},
                {
                    "$lookup" : {
                        from: "GroupRolePermissions",
                        localField: "GroupId",
                        foreignField: "GroupId",
                        as: "GroupRole"
                    }
                },
                //{$project : {"RoleName" : "$RolesInGroup","AddedPermissions" : 1,"RemovedPermissions" : 1,"RolesInGroup" : 1,"roleInfoData.Permissions" : 1,"GroupRole.AddedPermissions":1,"GroupRole.GroupId":1,"GroupRole.RoleName" : 1}},
                {$project : { "_id" : 0,"RoleName" : "$RolesInGroup", "roleInfoData.RoleName" : "$RolesInGroup", "roleInfoData.Role" : 1,"AddedPermissions" : 1,"RemovedPermissions" : 1,"RolesInGroup" : 1,"roleInfoData.Permissions" : 1,"GroupRole.AddedPermissions":1,"GroupRole.GroupId":1,"GroupRole.RoleName" : 1}},
                { "$redact":
                    {
                        "$cond": [
                            { "$eq": RoleName },
                            "$$DESCEND",
                            "$$PRUNE"
                        ]
                    }
                },
                {"$unwind" : {path: "$GroupRole", preserveNullAndEmptyArrays: true}},
                {$project : {"AddedPermissions" : 1,
                    //"RemovedPermissions" : 1,
                    "RemovedPermissions" : {"$ifNull" : [ "$RemovedPermissions", [] ]},
                    "RolesInGroup" : 1,"roleInfoData.Permissions" : 1,
                    "GroupRole" : {"$ifNull" : [ "$GroupRole.AddedPermissions", [] ]}}},
                //{$project : { allValues: { $setUnion: [ "$AddedPermissions", "$roleInfoData.Permissions", "$GroupRole.AddedPermissions" ] },RemovedPermissions : 1 }},
                {$project : { allValues: { $setUnion: [ "$AddedPermissions", "$roleInfoData.Permissions", "$GroupRole" ] },RemovedPermissions : 1 }},
                {$project : { _id : 0,Permission: { $setDifference: [ "$allValues","$RemovedPermissions" ] } } }
                //{$project : {"AddedPermissions" : 1,"RemovedPermissions" : 1,"RolesInGroup" : 1,"roleInfoData.Permissions" : 1,"GroupRole.AddedPermissions":1}},

            ], function (error, permissionRole) {
                if (error) {
                    return callback(error);
                }
                allpermissions = permissionRole[0].Permission;
                //console.log("DSSRole");
                //console.log(permissionRole);

                return callback(null,allpermissions);

            })

            //return allpermissions;

        }

        function aggregatePermissionsInGroup(member, group, role) {
            var RoleName,
                permissionsInRole,
                allpermissions = [],
                i,
                len,
                index,
                featureFlags,
                permissionsToDisable;
            RoleName = member.RolesInGroup[0];
            permissionsInRole = MemberEnums.GetPermissionsInRole(RoleName);
            allpermissions = allpermissions.concat(permissionsInRole);
            featureFlags = getFeatureFlags(group);
            // this is temporary code to add the share link permission to everyone that has the ShareLink flag turned on
            // it does not look at the individual social media meta data yet
            if (featureFlags[FeatureFlagEnums.ShareLink]) {
                member.AddedPermissions.push('ShareLink');
            }
            if (featureFlags[FeatureFlagEnums.EnableLanguages] && (member.RolesInGroup.indexOf('HGAdmin') > -1 || member.RolesInGroup.indexOf('Admin') > -1)) {
                member.AddedPermissions.push('EnableLanguages');
            }
            if (featureFlags[FeatureFlagEnums.RestrictAvatarSetting]) {
                member.RemovedPermissions.push('AllowAvatarUpload');
            }
            if (featureFlags[FeatureFlagEnums.HideSeeAllNotification]) {
                member.RemovedPermissions.push('AllImportantNotifications');
            }
            if (featureFlags[FeatureFlagEnums.TurnOffTeam]) {
                member.RemovedPermissions.push('AdhocTeam');
                member.RemovedPermissions.push('TeamManagement');
                member.RemovedPermissions.push('TeamAdmin');
            }
            if (featureFlags[FeatureFlagEnums.PreventProfileInfoEditing]) {
                member.RemovedPermissions.push('AllowProfileInfoEditing');
            }
            if (!featureFlags[FeatureFlagEnums.CustomProfanityFilter]) {
                member.RemovedPermissions.push('ManageProfanity');
            }
            if (featureFlags[FeatureFlagEnums.DisableValues]) {
                member.RemovedPermissions.push('ValuesRecognition');
            }
            if (featureFlags[FeatureFlagEnums.DisableMotivate]) {
                member.RemovedPermissions.push('SendCreditsInRecognition');
            }
            if (!featureFlags[FeatureFlagEnums.EnableTeamTab]) {
                member.RemovedPermissions.push('TeamTabManagement');
            }
            if (!featureFlags[FeatureFlagEnums.EnableLocation]) {
                member.RemovedPermissions.push('ManageLocation');
                member.RemovedPermissions.push('SeeLocation');
            }
            if (!featureFlags[FeatureFlagEnums.EnableDisplay]) {
                member.RemovedPermissions.push('ManageDisplay');
            }
            if (featureFlags[FeatureFlagEnums.SpendCreditTransfer] && member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) === -1) {
                member.AddedPermissions.push(MemberEnums.MemberPermission.TransferSpendCredits.Name);
            } else {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.TransferSpendCredits.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnablePoints] || member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AddGiftToNewRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AddGiftToOldRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ShowPointsInPublicFeed.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.GivePointGift.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.PointStore.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManagePointEconomy.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageProductOrder.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageProductItem.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.SendPointsInRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AddPointsInRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.MemberPoint.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnableAddPoints]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AddPointsInRecognition.Name);
            }
            // to-do: remove all permissions for recognitions and tracks here
            if (!featureFlags[FeatureFlagEnums.Recognition2]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.GiveRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.CustomizedRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.EverydayRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ValuesRecognition.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.GiveRecognitionToDepartment.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.GiveRecognitionToLocation.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AllowSelectAllWhenGivingRecognition.Name);
            }
            if (featureFlags[FeatureFlagEnums.HideRecognitionByLocation]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.GiveRecognitionToLocation.Name);
            }
            if (featureFlags[FeatureFlagEnums.HideRecognitionByDepartment]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.GiveRecognitionToDepartment.Name);
            }
            if (featureFlags[FeatureFlagEnums.HideSelectAllWhenGivingRecognition]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AllowSelectAllWhenGivingRecognition.Name);
            }
            if (featureFlags[FeatureFlagEnums.DisableTracks]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.CreateTrack.Name);
            }
            if (!featureFlags[FeatureFlagEnums.GoalWeighting]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.GoalWeighting.Name);
            }
            if (!featureFlags[FeatureFlagEnums.SkipGoalApproval]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.SkipGoalApproval.Name);
            }
            if (!featureFlags[FeatureFlagEnums.RecurringGoalCycle]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.RecurringGoalCycle.Name);
            }
            if (!featureFlags[FeatureFlagEnums.GoalLibrary]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageGoalLibrary.Name);
            }
            if (!featureFlags[FeatureFlagEnums.OpenClosedGoal]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.OpenClosedGoal.Name);
            }
            if (!featureFlags[FeatureFlagEnums.UploadGoalCycleParticipants]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.UploadGoalCycleParticipants.Name);
            }
            if (!featureFlags[FeatureFlagEnums.ContinuousFeedback]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ContinuousFeedback.Name);
            }
            if (!featureFlags[FeatureFlagEnums.ContinuousFeedback] ||
                    !(featureFlags[FeatureFlagEnums.FeedbackCheckin] || featureFlags[FeatureFlagEnums.RequestFeedback] || featureFlags[FeatureFlagEnums.GiveFeedback])) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageFeedback.Name);
            }
            if (!featureFlags[FeatureFlagEnums.UserNotificationPreference]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.UserNotificationPreference.Name);
            }
            if (featureFlags[FeatureFlagEnums.RestrictChatWidget] &&
                    (!role || !role.AddedPermissions || role.AddedPermissions.indexOf(MemberEnums.MemberPermission.AllowChatWidget.Name) === -1) &&
                    (!member.AddedPermissions || member.AddedPermissions.indexOf(MemberEnums.MemberPermission.AllowChatWidget.Name) === -1)) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AllowChatWidget.Name);
            }
            if (featureFlags[FeatureFlagEnums.DontPersistCookies]) {
                member.AddedPermissions.push(FeatureFlagEnums.DontPersistCookies);
            }
            if (featureFlags[FeatureFlagEnums.ForSalesDemo]) {
                member.AddedPermissions.push(MemberEnums.MemberPermission.FeedbackDemo.Name);
            }
            if (featureFlags[FeatureFlagEnums.EnableConversationGuide] && featureFlags[FeatureFlagEnums.FeedbackCheckin]) {
                member.AddedPermissions.push(MemberEnums.MemberPermission.EnableConversationGuide.Name);
            }
            if (featureFlags[FeatureFlagEnums.HideHelpLink]) {
                member.AddedPermissions.push(MemberEnums.MemberPermission.HideHelpLink.Name);
            }
            if (!featureFlags[FeatureFlagEnums.ManagerCheckin]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManagerCheckin.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnableGoals]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.TeamGoals.Name);
            }
            if (!featureFlags[FeatureFlagEnums.FeedbackCheckin]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.TeamCheckin.Name);
            }
            if (!featureFlags[FeatureFlagEnums.FeedbackCheckin]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.FeedbackCheckin.Name);
            }
            if (!featureFlags[FeatureFlagEnums.RequestFeedback]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.RequestFeedback.Name);
            }
            if (featureFlags[FeatureFlagEnums.GiveFeedback]) {
                member.AddedPermissions.push(MemberEnums.MemberPermission.GiveFeedback.Name);
            }
            if (!featureFlags[FeatureFlagEnums.TalentInsights]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.TalentInsight.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageTalentInsight.Name);
            }
            if (!featureFlags[FeatureFlagEnums.PerformGoal]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.PerformGoal.Name);
            }
            if (!featureFlags[FeatureFlagEnums.NumericPercentageTarget]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.NumericPercentageTarget.Name);
            }
            if (!featureFlags[FeatureFlagEnums.SelectRecapTime]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.SelectRecapTime.Name);
            }
            if (!featureFlags[FeatureFlagEnums.AdhocGoal]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.AdhocGoal.Name);
            }
            if (!featureFlags[FeatureFlagEnums.MobileAllowCompanyGoalMod]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.MobileAllowCompanyGoalMod.Name);
            }
            if (!featureFlags[FeatureFlagEnums.MobileAllowTeamGoalMod]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.MobileAllowTeamGoalMod.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnableGoals]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.Goal.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageGoalCycle.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnableBenchmarkSurvey]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.BenchmarkSurvey.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageBenchmarkSurvey.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnablePulseSurvey]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.PulseSurvey.Name);
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManagePulseSurvey.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnableBenchmarkSurvey] && !featureFlags[FeatureFlagEnums.EnablePulseSurvey]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ManageAllSurveys.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnableTutorials]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.Tutorials.Name);
            }
            if (!featureFlags[FeatureFlagEnums.ReqFeedbackAboutOthers]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.ReqFeedbackAboutOthers.Name);
            }
            if (!featureFlags[FeatureFlagEnums.EnableOptOutPublicRec]) {
                member.RemovedPermissions.push(MemberEnums.MemberPermission.EnableOptOutPublicRec.Name);
            }
            if (featureFlags[FeatureFlagEnums.AllowSurveyKiosk]) {
                member.AddedPermissions.push(MemberEnums.MemberPermission.AllowSurveyKiosk.Name);
            }
            if (featureFlags[FeatureFlagEnums.SuggSuggestRewardIdeaestRewardIdea]) {
                member.AddedPermissions.push(MemberEnums.MemberPermission.SuggestRewardIdea.Name);
            }
            if (featureFlags[FeatureFlagEnums.RestrictToSingleSession]) {
                member.AddedPermissions.push(FeatureFlagEnums.RestrictToSingleSession);
            }
            for (i = 0; i < member.AddedPermissions.length; i += 1) {
                index = permissionsInRole.indexOf(member.AddedPermissions[i]);
                if (index === -1) {
                    allpermissions.push(member.AddedPermissions[i]);
                }
            }
            for (i = 0; i < member.RemovedPermissions.length; i += 1) {
                index = allpermissions.indexOf(member.RemovedPermissions[i]);
                if (index > -1) {
                    allpermissions.splice(index, 1);
                }
            }
            if (role) {
                for (i = 0; i < role.AddedPermissions.length; i += 1) {
                    index = member.RemovedPermissions.indexOf(role.AddedPermissions[i]);
                    if (index === -1) {
                        allpermissions.push(role.AddedPermissions[i]);
                    }
                }
            }
            permissionsToDisable = disablePermissions(featureFlags[FeatureFlagEnums.DisableFeatureByRole], member.RolesInGroup[0]);
            if (permissionsToDisable.length) {
                for (i = 0, len = permissionsToDisable.length; i < len; i += 1) {
                    index = allpermissions.indexOf(permissionsToDisable[i].charAt(0).toUpperCase() + permissionsToDisable[i].slice(1));
                    if (index > -1 && member.AddedPermissions.indexOf(permissionsToDisable[i]) === -1) {
                        allpermissions.splice(index, 1);
                    }
                }
            }
            return allpermissions;
        }

        function validateActionToken(actionToken, callback) {
            if (!actionToken) {
                return callback('server.hge.usr.adne');
            }
            if (actionToken.Status !== 'Pending' ||
                    actionToken.Type !== 'PasswordReset' ||
                    actionToken.ExpireDate < new Date().getTime()) {
                return callback('server.hge.usr.ati');
            }
            callback();
        }

        function populateLocation(member, userInfo) {
            if (member.Location && member.Location.hgId) {
                userInfo.UserContext.CurrentLocationId = member.Location.hgId;
                userInfo.UserContext.CurrentLocationName = member.Location.Name;
            } else {
                userInfo.UserContext.CurrentLocationId = null;
                userInfo.UserContext.CurrentLocationName = null;
            }
        }

        function getApprovedAuthTypesByUsername(userName, callback) {
            var authTypes = [AuthEnums.AuthType.AuthCode],
                featureFlags;
            EntityCache.UserInfo.findOne({LowercaseUserName : userName.toLowerCase()}, function (error, userInfo) {
                if (error) {
                    return callback('business.user.noauth.elup');
                }
                if (!userInfo) {
                    return callback('business.user.noauth.uidne');
                }
                EntityCache.Group.findOne({hgId: userInfo.Preference.DefaultGroupId}, function (err, group) {
                    if (err || !group) {
                        HgLog.error('Error retrieving groupId: ' + err);
                        return callback('business.gro.pro.gdne');
                    }
                    featureFlags = getFeatureFlags(group);
                    if (!featureFlags || !featureFlags[FeatureFlagEnums.HidePasswordLogins]) {
                        authTypes.push(AuthEnums.AuthType.Password);
                    }
                    callback(null, {
                        isMobileDisabled: !featureFlags || !featureFlags[FeatureFlagEnums.MobileAccess],
                        AuthTypes: authTypes
                    });
                });
            });
        }

        function createUserSecurityContext(userSecurity, callback, isImpersonating, overrideGroupId, deviceInfo) {
            var logLoginDevice = function (userInfo) {
                userInfo.FirstLogin = userInfo.FirstLogin || [];
                if (!deviceInfo && !(userInfo.FirstLogin.some(function (item) { //for web
                        return item.Source === EntityEnums.Source.Web;
                    }))) {
                    userInfo.FirstLogin.push({
                        Source: EntityEnums.Source.Web,
                        LoginTime: Date.now()
                    });
                } else if (deviceInfo && !(userInfo.FirstLogin.some(function (item) {// mobile
                        return item.Source === deviceInfo.DeviceModel && item.DeviceUuid === deviceInfo.DeviceUuid;
                    }))) {
                    userInfo.FirstLogin.push({
                        Source: deviceInfo.DeviceModel,
                        LoginTime: Date.now(),
                        DeviceUuid: deviceInfo.DeviceUuid
                    });
                }
            };

            var featureMapping;
            EntityCache.FeaturePermissionMapping.find({},function(err,featuremapping){
                if (err) {
                    return callback('business.gro.pro.elg');
                }
                featureMapping = featuremapping;
            })

            userSecurity = self.UserSecurity_AggregatePermissionsAndServices(userSecurity);
            EntityCache.UserInfo.findOne({hgId: userSecurity.hgId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('business.user.noauth.elup');
                }
                var groupId = userInfo.Preference.DefaultGroupId;
                if (isImpersonating && overrideGroupId) {
                    groupId = overrideGroupId;
                }
                if (!isImpersonating) {
                    logLoginDevice(userInfo);
                    userInfo.LastCheckInTime = userInfo.LastLoginTime = Date.now();
                    EntityCache.Member.update({
                        MembershipStatus: MemberEnums.Status.Active,
                        UserId: userInfo.hgId
                    }, {
                        $set: {
                            LastLoginTime: Date.now()
                        }
                    }, {
                        multi: true
                    }).exec();//update fire and forget
                }
                userInfo.save(function (err) {
                    if (err) {
                        return callback('business.user.noauth.esui');
                    }
                });
                EntityCache.Member.findOne({GroupId: groupId, UserId: userInfo.hgId}, function (err, defaultMember) {
                    var messageElm = 'business.user.noauth.elm',
                        messageIma = 'business.user.noauth.ima',
                        lang = userInfo.i18n || 'en';
                    if (err) {
                        return callback(i18nHelper.translate(groupId + '/' + lang, messageElm));
                    }
                    if (!defaultMember) {
                        HgLog.error("Couldn't load Member in createUserSecurityContext()", {GroupId: groupId, UserId: userInfo.hgId});
                        return callback(i18nHelper.translate(groupId + '/' + lang, messageElm));
                    }
                    if (MemberEnums.Status.InActive === defaultMember.MembershipStatus) {
                        return callback(messageIma);
                    }
                    userInfo.UserContext.CurrentGroupId = defaultMember.GroupId;
                    populateLocation(defaultMember, userInfo);
                    userInfo.UserContext.ExperiencePoint = defaultMember.ExperiencePoint;
                    userInfo.UserContext.CurrentGroupName = defaultMember.GroupName;
                    userInfo.UserContext.CurrentGroupBannerUrl = defaultMember.BannerUrl;
                    userInfo.UserContext.CurrentGroupDepartmentName = defaultMember.GroupDepartmentName;
                    userInfo.UserContext.CurrentGroupDepartmentId = defaultMember.GroupDepartmentId;
                    userInfo.UserContext.StartingDateInGroup = defaultMember.StartingDate;
                    userInfo.UserContext.BirthdateInGroup = defaultMember.Birthdate;
                    userInfo.UserContext.MemberIdInGroup = defaultMember.hgId;
                    userInfo.UserContext.MyManagers = defaultMember.MyManagers;
                    userInfo.UserContext.GravatarEmail = defaultMember.GravatarEmail;
                    userInfo.UserContext.MemberTitleInGroup = defaultMember.Position;
                    userInfo.UserContext.RolesInGroup = defaultMember.RolesInGroup;
                    userInfo.UserContext.FriendlyId = defaultMember.FriendlyId;
                    userInfo.UserContext.MembershipStatus = defaultMember.MembershipStatus;
                    EntityCache.Group.findOne({hgId: groupId}, function (err, group) {
                        if (err) {
                            return callback('business.gro.pro.elg');
                        }
                        if (group.Status !== EntityEnums.GroupStatus.Active) {
                            return callback('business.user.noauth.dgl');
                        }
                        if (group.KioskSurveyInProgress && userInfo.UserContext.RolesInGroup.some(function (role) {return EntityEnums.MembersRoleInGroup.Admin !== role; })) {
                            return callback('login.kcm');
                        }
                        userInfo.UserContext.CurrentGroupName = group.GroupName;
                        userInfo.UserContext.CurrentGroupBannerUrl = group.BannerUrl;
                        userInfo.UserContext.CurrentProgramName = group.ProgramName;
                        userInfo.UserContext.CurrentGroupBannerMotif = group.BannerMotif;
                        userInfo.UserContext.CurrentGroupBannerColor = group.BannerColor;
                        EntityCache.GroupRolePermissions.findOne({GroupId: defaultMember.GroupId, RoleName: defaultMember.RolesInGroup[0]}, function (err, role) {
                            if (err) {
                                return callback('business.grouprole.permissions.elrp');
                            }
                            EntityCache.Member.count({
                                GroupId: defaultMember.GroupId,
                                'MyManagers.MemberId': defaultMember.hgId,
                                MembershipStatus: MemberEnums.Status.Active
                            }, function (err, drCount) {
                                var featureFlags = getFeatureFlags(group);
                                if (err) {
                                    return callback('business.mem.pro.eldr');
                                }
                                if (featureFlags[FeatureFlagEnums.EnableTeamTab] && drCount) {
                                    defaultMember.AddedPermissions.push(MemberEnums.MemberPermission.TeamAction.Name);
                                    if (featureFlags[FeatureFlagEnums.Recognition2]) {
                                        defaultMember.AddedPermissions.push(MemberEnums.MemberPermission.TeamRecognize.Name);
                                    }
                                    if (featureFlags[FeatureFlagEnums.EnableCoaching]) {
                                        defaultMember.AddedPermissions.push(MemberEnums.MemberPermission.TeamCoaching.Name);
                                    }
                                    if (featureFlags[FeatureFlagEnums.EnablePerform]) {
                                        defaultMember.AddedPermissions.push(MemberEnums.MemberPermission.TeamPerform.Name);
                                    }
                                    if (featureFlags[FeatureFlagEnums.TalentInsights]) {
                                        defaultMember.AddedPermissions.push(MemberEnums.MemberPermission.TeamTalent.Name);
                                    }
                                    if (featureFlags[FeatureFlagEnums.ManagerTeamTabLearning]) {
                                        defaultMember.AddedPermissions.push(MemberEnums.MemberPermission.ManagerTeamLearning.Name);
                                    }
                                } else {
                                    defaultMember.RemovedPermissions.push(MemberEnums.MemberPermission.TeamGoals.Name);
                                    defaultMember.RemovedPermissions.push(MemberEnums.MemberPermission.TeamCheckin.Name);
                                }
                                //userInfo.UserContext.PermissionsInGroup = aggregatePermissionsInGroup(defaultMember, group, role);
                                //userInfo.UserContext.PermissionsInGroup = aggregatePermissionsInGroupQuery(defaultMember, group, role, function (err,permission) {
                                aggregatePermissionsInGroupQuery(defaultMember, group, role, function (err,permission) {

                                    //console.log("DSS");
                                    userInfo.UserContext.PermissionsInGroup = permission;
                                    //console.log(userInfo.UserContext.PermissionsInGroup);
                                    //userInfo.UserContext.PermissionsInGroup = aggregatePermissionsInGroupDSS(defaultMember, group, role, featureMapping);
                                    userInfo.UserContext.PermissionsInGroup = aggregatePermissionsInGroup(defaultMember, group, role);
                                    //console.log("DSS1")
                                    //console.log(userInfo.UserContext.PermissionsInGroup);
                                    userInfo.Flags.FirstTimeLogin = userInfo.Flags.WelcomeBadgePending;
                                    if (userInfo.Flags.WelcomeBadgePending) {
                                        userInfo.Flags.WelcomeBadgePending = !!featureFlags[FeatureFlagEnums.Recognition2];
                                    }
                                    userInfo.save(function (err) {
                                        if (err) {
                                            return callback('business.user.noauth.esui');
                                        }
                                    });
                                    userInfo.UserContext.AggregatedSecuredTabs = aggregateSecuredTabsInGroup({member: defaultMember, group: group, user: userInfo});
                                    //userInfo.UserContext.AggregatedSecuredTabs = aggregateSecuredTabsInGroupDSS({
                                    //    member: defaultMember,
                                    //    group: group,
                                    //    user: userInfo
                                    //}, featureMapping);

                                    EntityCache.Member.find({UserId: userInfo.hgId}, function (err, memberships) {
                                        if (err) {
                                            return callback('business.user.noauth.elut');
                                        }
                                        userInfo.MyMemberships = memberships.map(function (mem) {
                                            return {
                                                GroupId: mem.GroupId,
                                                GroupName: mem.GroupName,
                                                GroupDepartmentName: mem.GroupDepartmentName,
                                                GravatarEmail: mem.GravatarEmail,
                                                BannerUrl: mem.BannerUrl,
                                                ExperiencePoint: mem.ExperiencePoint,
                                                StartingDateInGroup: mem.StartingDate,
                                                BirthdateInGroup: mem.Birthdate,
                                                MyManagers: mem.MyManagers,
                                                MemberIdInGroup: mem.hgId,
                                                MemberTitleInGroup: mem.Position,
                                                RolesInGroup: mem.RolesInGroup,
                                                FriendlyId: mem.FriendlyId,
                                                MembershipStatus: mem.MembershipStatus,
                                                AggregatedSecuredTabs: {}
                                            };
                                        });
                                        // this can run in parallel with the next step to populate the banner urls
                                        EntityCache.Group.find({
                                            hgId: {
                                                $in: userInfo.MyMemberships.map(function (mem) {
                                                    return mem.GroupId;
                                                })
                                            }
                                        }, function (err, groups) {
                                            if (err) {
                                                return callback('business.gro.pro.elg');
                                            }
                                            groups.forEach(function (group) {
                                                userInfo.MyMemberships.filter(function (mem) {
                                                    return mem.GroupId === group.hgId;
                                                })[0].BannerUrl = group.BannerUrl;
                                            });
                                        });
                                        loadUserAccountBalances({
                                            UserInfoWithToken: userInfo
                                        }, function (err) {
                                            if (err) {
                                                return callback('business.user.noauth.eluc');
                                            }
                                            var UserToken,
                                                newUserInfo,
                                                newuserSecurity,
                                                userInfoWithToken,
                                                userSecurityWithToken;
                                            UserToken = uuid.v1();
                                            newUserInfo = userInfo.toObject();
                                            newuserSecurity = userSecurity.toObject();
                                            delete newUserInfo._id;
                                            delete newuserSecurity._id;
                                            userInfoWithToken = EntityCache.UserInfoWithToken(newUserInfo);
                                            if (isImpersonating) {
                                                userInfoWithToken.ActAsUserToken = UserToken;
                                            } else {
                                                userInfoWithToken.UserToken = UserToken;
                                            }
                                            userInfoWithToken.Source = deviceInfo ? EntityEnums.Source.Mobile : EntityEnums.Source.Web;
                                            userInfoWithToken.save(function (err) {
                                                if (err) {
                                                    HgLog.error('Error saving userInfoWithToken:' + err);
                                                    return callback(err);
                                                }
                                                userSecurityWithToken = EntityCache.UserSecurityWithToken(newuserSecurity);
                                                if (isImpersonating) {
                                                    userSecurityWithToken.ActAsUserToken = UserToken;
                                                } else {
                                                    userSecurityWithToken.UserToken = UserToken;
                                                }
                                                userSecurityWithToken.Source = deviceInfo ? EntityEnums.Source.Mobile : EntityEnums.Source.Web;
                                                userSecurityWithToken.save(function (err) {
                                                    if (err) {
                                                        HgLog.error('Error saving userSecurityWithToken: ' + err);
                                                        return callback(err);
                                                    }
                                                    callback(null, userInfoWithToken);
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });

                    });
                });
            });
        }

        function impersonateUserSecurityContext(userSecurity, overrideGroupId, callback) {
            createUserSecurityContext(userSecurity, callback, true, overrideGroupId);
        }

        this.CheckThrottle = function (params, callback) {
            var cutoffTimestamp = new Date().getTime() - 1000 * 60 * 5;//5 minutes
            EntityCache.Throttle.find({
                ServiceName: params.ServiceName,
                MethodName: params.MethodName,
                RequestTime: {$gt: cutoffTimestamp}
            }, function (error, throttle) {
                if (error) {
                    return callback('business.user.noauth.tcf');
                }
                if (throttle && throttle.length > 0) {
                    return callback(i18nHelper.translate(params.Lang, 'business.user.noauth.tai', {ThrottleLength: throttle.length}), false);
                }
                var newThrottle = new EntityCache.Throttle({
                        hgId: uuid.v1(),
                        correlationId: params.correlationId,
                        ServiceName: params.ServiceName,
                        MethodName: params.MethodName,
                        RequestTime: new Date().getTime()
                    });
                newThrottle.save(function (error) {
                    if (error) {
                        callback('business.user.noauth.tcf');
                    } else {
                        callback(null, true);
                    }
                });
            });
        };

        this.CreateLead = function (params, callback) {
            var lead = new EntityCache.Lead(params);
            lead.hgId = uuid.v1();
            lead.save(function (error) {
                callback(error, lead);
            });
        };

        this.UserSecurity_LoadByActAsUserToken = function (params, callback) {
            EntityCache.UserSecurityWithToken.findOne({ActAsUserToken: params.ActAsUserToken}, function (err, user) {
                var eventData = {};
                if (err) {
                    callback('server.hge.usr.eluwt');
                } else if (!user) {
                    //HgError.Enums.User.InvalidUserToken is an enum that mobile expects
                    EntityCache.UserInfoWithToken.findOne({ActAsUserToken: params.ActAsUserToken}).remove();
                    callback(HgError.Enums.User.InvalidUserToken);
                } else {
                    eventData = new EventData(params.correlationId, user);
                    eventData.servicecallback = params.servicecallback;
                    eventData.MethodAuthLevel = params.MethodAuthLevel;
                    eventData.ServiceName = params.ServiceName;
                    eventData.MethodName = params.MethodName;
                    eventData.ActAsUserToken = params.ActAsUserToken;
                    eventData.UserToken = params.UserToken;
                    eventData.IPAddress = params.IPAddress;
                    eventData.BrowserFingerPrint = params.BrowserFingerPrint;
                    eventData.Source = params.Source;
                    eventData.UserAgent = params.UserAgent;
                    verifyUserHasPermission(eventData, callback);
                }
            });
        };

        this.UserSecurity_LoadByUserToken = function (params, callback) {
            EntityCache.UserSecurityWithToken.findOne({UserToken: params.UserToken}, function (err, user) {
                var eventData;
                if (err) {
                    return callback('server.hge.usr.eluwt');
                }
                if (!user) {
                    return callback(HgError.Enums.User.InvalidUserToken);
                }
                eventData = new EventData(params.correlationId, user);
                eventData.servicecallback = params.servicecallback;
                eventData.MethodAuthLevel = params.MethodAuthLevel;
                eventData.ServiceName = params.ServiceName;
                eventData.MethodName = params.MethodName;
                eventData.UserToken = params.UserToken;
                eventData.IPAddress = params.IPAddress;
                eventData.BrowserFingerPrint = params.BrowserFingerPrint;
                eventData.Source = params.Source;
                eventData.UserAgent = params.UserAgent;
                verifyUserHasPermission(eventData, callback);
            });
        };

        this.SetWelcomeBadgePendingFalse = function (userId) {
            EntityCache.UserInfoWithToken.update(
                {hgId: userId},
                {$set: {'Flags.WelcomeBadgePending': false}},
                {upsert: false, multi: true},
                function (err) {
                    if (err) {
                        HgLog.error('SetWelcomeBadgePendingFalse: ' + err);
                    } else {
                        EntityCache.UserInfo.update(
                            {hgId: userId},
                            {$set: {'Flags.WelcomeBadgePending': false}},
                            {upsert: false, multi: true},
                            function (err) {
                                if (err) {
                                    HgLog.error({methodName: 'SetWelcomeBadgePendingFalse', error: err});
                                }
                            }
                        );
                    }
                }
            );
        };

        this.UserSecurity_AggregatePermissionsAndServices = function (user) {
            var allpermissions = [],
                allServices = [],
                i,
                len,
                RoleName,
                permissions,
                PermissionName;
            for (i = 0, len = user.Roles.length; i < len; i += 1) {
                RoleName = user.Roles[i].RoleName;
                if (!RoleName) {
                    RoleName = user.Roles[i];
                }
                permissions = Roles[RoleName].Permissions;
                allpermissions = allpermissions.concat(permissions);
            }
            for (i = 0, len = allpermissions.length; i < len; i += 1) {
                PermissionName = allpermissions[i];
                allServices = allServices.concat(Permissions[PermissionName].AvailableServices);
            }
            user.AvailableServiceArray = allServices;
            return user;
        };

        this.Authorize = function (params, callback) {
            if (params.ActAsUserToken) {
                this.UserSecurity_LoadByActAsUserToken(params, callback);
            } else if (params.UserToken) {
                this.UserSecurity_LoadByUserToken(params, callback);
            }
        };

        this.Logout = function (params) {
            if (params.UserToken) {
                EntityCache.UserSecurityWithToken.remove({UserToken: params.UserToken}, function (err) {
                    if (err) {
                        HgLog.error({methodName: 'Logout.UserSecurityWithToken', error: err});
                    }
                    EntityCache.UserInfoWithToken.remove({UserToken: params.UserToken}, function (err) {
                        if (err) {
                            HgLog.error({methodName: 'Logout.UserInfoWithToken', error: err});
                        }
                    });
                });
                EventResponder.RespondWithData(EventEmitterCache, params, 'successfully logout');
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, 'business.user.noauth.ualo');
            }
        };

        this.LogoutUsersById = function (params, fcallback) {
            if (!params.UserId) {
                return fcallback('server.hge.pay.hpm');
            }
            var userIdArr = !Array.isArray(params.UserId) ? [params.UserId] : params.UserId;
            // logout these users from all devices
            Async.parallel([
                function (callback) {
                    EntityCache.UserInfoWithToken.remove({
                        hgId: { $in: userIdArr }
                    }, function (err) {
                        if (err) {
                            HgLog.error({methodName: 'ChangePassword.userinfo', error: err});
                            return callback('Error removing user info with hgId ' + params.UserId);
                        }
                        callback();
                    });
                },
                function (callback) {
                    EntityCache.UserSecurityWithToken.remove({
                        hgId: { $in: userIdArr }
                    }, function (err) {
                        if (err) {
                            HgLog.error({methodName: 'ChangePassword.userSecurity', error: err});
                            return callback('Error removing user security with hgId ' + params.UserId);
                        }
                        callback();
                    });
                }
            ], fcallback);
        };

        this.RefreshUserInfoToken = function (params, callback) {
            var refreshUserInfoToken = function (searchQuery) {
                EntityCache.UserInfoWithToken.findOne(searchQuery, function (err, userInfoWithToken) {
                    if (err || !userInfoWithToken) {
                        return callback(err);
                    }

                    var featureMapping;
                    EntityCache.FeaturePermissionMapping.find({},function(err,featuremapping){
                        if (err) {
                            return callback('business.gro.pro.elg');
                        }
                        featureMapping = featuremapping;
                    })

                    EntityCache.UserInfo.findOne({hgId: userInfoWithToken.hgId}, function (error, userInfo) {
                        if (error) {
                            return callback(error);
                        }
                        userInfoWithToken.UserFinance = userInfo.UserFinance;
                        EntityCache.Member.findOne({hgId: userInfoWithToken.UserContext.MemberIdInGroup}, function (err, member) {
                            if (err) {
                                return callback(err);
                            }
                            EntityCache.Group.findOne({hgId: member.GroupId}, function (err, group) {
                                if (err) {
                                    return callback(err);
                                }
                                if (group.Status !== EntityEnums.GroupStatus.Active) {
                                    return callback('business.user.noauth.dgl');
                                }
                                EntityCache.GroupRolePermissions.findOne({GroupId: member.GroupId, RoleName: member.RolesInGroup[0]}, function (err, role) {
                                    if (err) {
                                        return EventResponder.RespondWithError(EventEmitterCache, params, 'business.grouprole.permissions.elrp');
                                    }
                                    EntityCache.Member.count({
                                        GroupId: member.GroupId,
                                        'MyManagers.MemberId': member.hgId,
                                        MembershipStatus: 'Active'
                                    }, function (err, drCount) {
                                        var featureFlags;
                                        if (err) {
                                            return callback('business.mem.pro.eldr');
                                        }
                                        featureFlags = getFeatureFlags(group);
                                        if (featureFlags[FeatureFlagEnums.EnableTeamTab] && drCount) {
                                            member.AddedPermissions.push(MemberEnums.MemberPermission.TeamAction.Name);
                                            if (featureFlags[FeatureFlagEnums.Recognition2]) {
                                                member.AddedPermissions.push(MemberEnums.MemberPermission.TeamRecognize.Name);
                                            }
                                            if (featureFlags[FeatureFlagEnums.EnableCoaching]) {
                                                member.AddedPermissions.push(MemberEnums.MemberPermission.TeamCoaching.Name);
                                            }
                                            if (featureFlags[FeatureFlagEnums.EnablePerform]) {
                                                member.AddedPermissions.push(MemberEnums.MemberPermission.TeamPerform.Name);
                                            }
                                            if (featureFlags[FeatureFlagEnums.TalentInsights]) {
                                                member.AddedPermissions.push(MemberEnums.MemberPermission.TeamTalent.Name);
                                            }
                                            if (featureFlags[FeatureFlagEnums.ManagerTeamTabLearning]) {
                                                member.AddedPermissions.push(MemberEnums.MemberPermission.ManagerTeamLearning.Name);
                                            }
                                        } else {
                                            member.RemovedPermissions.push(MemberEnums.MemberPermission.TeamGoals.Name);
                                            member.RemovedPermissions.push(MemberEnums.MemberPermission.TeamCheckin.Name);
                                        }
                                        populateLocation(member, userInfoWithToken);
                                        //userInfoWithToken.UserContext.PermissionsInGroup = aggregatePermissionsInGroup(member, group, role);
                                        aggregatePermissionsInGroupQuery(member, group, role, function (err,permission) {

                                            console.log("DSS_NEW");
                                            userInfoWithToken.UserContext.PermissionsInGroup = permission;
                                            console.log(userInfoWithToken.UserContext.PermissionsInGroup);

                                            //userInfoWithToken.UserContext.PermissionsInGroup = aggregatePermissionsInGroupDSS(member, group, role, featureMapping);
                                            userInfoWithToken.UserContext.PermissionsInGroup = aggregatePermissionsInGroup(member, group, role);
                                            console.log("DSS_OLD");
                                            console.log(userInfoWithToken.UserContext.PermissionsInGroup);

                                            userInfoWithToken.UserContext.AggregatedSecuredTabs = aggregateSecuredTabsInGroup({member: member, group: group, user: userInfoWithToken});
                                            //userInfoWithToken.UserContext.AggregatedSecuredTabs = aggregateSecuredTabsInGroupDSS({
                                            //    member: member,
                                            //    group: group,
                                            //    user: userInfoWithToken
                                            //}, featureMapping);

                                            userInfoWithToken.UserContext.CurrentGroupBannerMotif = group.BannerMotif;
                                            userInfoWithToken.UserContext.CurrentGroupBannerColor = group.BannerColor;
                                            userInfoWithToken.markModified('UserContext');
                                            userInfoWithToken.save(function (err) {
                                                if (err) {
                                                    return callback(err);
                                                }
                                                callback(null, true);
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            };
            if (params.ActAsUserToken) {
                refreshUserInfoToken({ActAsUserToken: params.ActAsUserToken});
            } else if (params.UserToken) {
                refreshUserInfoToken({UserToken: params.UserToken});
            } else {
                EventResponder.RespondWithData(EventEmitterCache, params, false);
            }
        };

        this.RefreshUserSecurityToken = function (params) {
            var refreshUserSecurityToken = function (searchQuery) {
                EntityCache.UserSecurityWithToken.findOne(searchQuery, function (err, userSecurityWithToken) {
                    if (err || !userSecurityWithToken) {
                        return EventResponder.RespondWithError(EventEmitterCache, params, 'error loading userSecurityWithToken', true);
                    }
                    EntityCache.UserSecurity.findOne({hgId: userSecurityWithToken.hgId}, function (err, userSecurity) {
                        if (err || !userSecurity) {
                            return EventResponder.RespondWithError(EventEmitterCache, params, 'error loading original userSecurity', true);
                        }
                        refreshUserSecurity(userSecurityWithToken, userSecurity);
                        userSecurityWithToken.save(function (err) {
                            if (err) {
                                EventResponder.RespondWithError(EventEmitterCache, params, err);
                            } else {
                                EventResponder.RespondWithData(EventEmitterCache, params, true);
                            }
                        });
                    });
                });
            };
            if (params.ActAsUserToken) {
                refreshUserSecurityToken({ActAsUserToken: params.ActAsUserToken});
            } else if (params.UserToken) {
                refreshUserSecurityToken({UserToken: params.UserToken});
            } else {
                EventResponder.RespondWithData(EventEmitterCache, params, false);
            }
        };

        this.LoginWithUserToken = function (params, callback) {
            var lparam = params.ActAsUserToken ? {token: params.ActAsUserToken, type: 'ActAsUserToken'} :
                        {token: params.UserToken, type: 'UserToken'};
            loadByUserToken(lparam, callback);
        };

        this.ImpersonateByUserId = function (params, callback) {
            if (params.UserId) {
                return EntityCache.UserSecurity.findOne({hgId: params.UserId}, function (err, userSecurity) {
                    if (err) {
                        return callback('business.user.noauth.elup');
                    }
                    if (userSecurity) {
                        userSecurity.Status = UserSecurityStatus.Active;
                        userSecurity.FailLoginAttempts = 0; //reset FailLoginAttempts if login successful
                        userSecurity.save(function (err) {
                            if (err) {
                                return callback('business.user.noauth.esus');
                            }
                        });
                        impersonateUserSecurityContext(userSecurity, params.OverrideGroupId, function (error, userInfoWithToken) {
                            if (error) {
                                return callback(error);
                            }
                            return callback(null, userInfoWithToken);
                        });
                    } else {
                        return callback('services.int.user.pnm');
                    }
                });
            }
            callback('business.user.noauth.vl');
        };

        this.LoadUserSecurityByUserName = function (params, callback) {
            function checkMemberStatus(userSecurityRecord) {
                // in case there are multiple members attached to this single login
                // if any of the members are offboarded, then don't allow
                var query = {
                    UserId: userSecurityRecord.hgId
                };
                if (params.GroupId) {
                    query.GroupId = params.GroupId;
                }
                EntityCache.Member.find(query, {_id: 0, MembershipStatus: 1, GroupId: 1}, function (err, member) {
                    if (err || !member.length) {
                        return callback('business.user.noauth.elut');
                    }
                    if (member.some(function (m) {
                            return m.MembershipStatus === MemberEnums.Status.OffBoarded;
                        })) {
                        return callback('business.user.noauth.elut');
                    }
                    if (member.some(function (m) {
                            return m.MembershipStatus === MemberEnums.Status.InActive;
                        })) {
                        return callback('business.user.noauth.ima');
                    }
                    return callback(null, userSecurityRecord);
                });
            }
            if (!params.UserName) {
                return callback('business.user.noauth.nun');
            }
            EntityCache.UserSecurity.find({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userSecurity) {
                if (err) {
                    return callback(err);
                }
                if (!userSecurity || !userSecurity.length) {
                    return callback('business.user.noauth.elup');
                }
                if (userSecurity.length === 1) {
                    return checkMemberStatus(userSecurity[0]);
                }
                HgLog.error('SSO error duplicate username:', params.UserName);
                return callback('business.user.noauth.elut');
            });
        };

        this.SuccessfulLogin = function (params, callback) {
            var createUserSecurityCtxCallback = function (err, userInfoWithToken) {
                if (err) {
                    return callback(err);
                }
                if (params.DeviceInfo) {
                    userInfoWithToken.DevicePlatform = params.DeviceInfo.DevicePlatform;
                    userInfoWithToken.DeviceUuid = params.DeviceInfo.DeviceUuid;
                    userInfoWithToken.DeviceVersion = params.DeviceInfo.DeviceVersion;
                    userInfoWithToken.DeviceToken = params.DeviceInfo.DeviceToken;
                    userInfoWithToken.RegistrationId = params.DeviceInfo.RegistrationId;
                    userInfoWithToken.DeviceModel = params.DeviceInfo.DeviceModel;
                    userInfoWithToken.save(callback);
                } else {
                    callback(null, userInfoWithToken);
                }
            };
            EntityCache.UserSecurity.findOne({hgId: params.UserSecurityId}, function (err, userSecurity) {
                if (err) {
                    return callback(err);
                }
                if (!userSecurity) {
                    return callback('business.user.noauth.elup');
                }

                userSecurity.Status = UserSecurityStatus.Active;
                userSecurity.FailLoginAttempts = 0;     //reset FailLoginAttempts if login successful
                userSecurity.save(function (err) {
                    if (err) {
                        HgLog.error('Error saving userSecurity', err);
                        return callback('business.user.noauth.esus');
                    }
                    createUserSecurityContext(userSecurity, createUserSecurityCtxCallback, false, null, params.DeviceInfo);
                });
            });
        };

        this.UnsuccessfulLogin = function (params, callback) {
            EntityCache.UserSecurity.findOne({'hgId': params.UserSecurityId}, function (err, userSecurity) {
                if (err) {
                    return callback(err);
                }
                if (!userSecurity) {
                    return callback('business.user.noauth.elup');
                }

                userSecurity.FailLoginAttempts += 1;
                if (userSecurity.FailLoginAttempts >= 5) {
                    userSecurity.Status = UserSecurityStatus.LockedOut;
                    userSecurity.LockedOutTime = Date.now();
                }
                userSecurity.save(function (err) {
                    if (err) {
                        HgLog.error('Error saving userSecurity', err);
                        return callback('business.user.noauth.esus');
                    }
                    callback();
                });
            });
        };
        function isMobileEnable(params, callback) {
            EntityCache.UserInfo.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userInfo) {
                if (err || !userInfo) {
                    HgLog.error('Error retrieving userInfo: ' + err);
                    return callback('business.user.noauth.uidne');
                }
                EntityCache.Group.findOne({hgId: userInfo.Preference.DefaultGroupId}, function (err, group) {
                    var featureFlags;
                    if (err || !group) {
                        HgLog.error('Error retrieving groupId: ' + err);
                        return callback('business.gro.pro.gdne');
                    }
                    featureFlags = getFeatureFlags(group);
                    callback(null, featureFlags && featureFlags[FeatureFlagEnums.MobileAccess]);
                });
            });
        }
        this.LoginWithUserNameAndPassword = function (params, callback) {
            var createUserSecurityCtxCallback = function (error, userInfoWithToken) {
                if (error) {
                    return callback({message: error});
                }
                return callback(null, userInfoWithToken);
            };
            function successfulLogin(userSecurity, callback) {
                // change status if PasswordExpiration exists, is greater than zero (does not expire), and today's date is greater than PasswordExpiration
                if (userSecurity.PasswordExpiration && Date.now() > userSecurity.PasswordExpiration) {
                    userSecurity.Status = UserSecurityStatus.PasswordChangeRequired;
                } else {
                    userSecurity.Status = UserSecurityStatus.Active;
                }
                userSecurity.FailLoginAttempts = 0; //reset FailLoginAttempts if login succesful
                userSecurity.save(function (err) {
                    if (err) {
                        HgLog.error('Error saving userSecurity: ' + err);
                        return callback({message: 'business.user.noauth.esus'});
                    }
                    if (userSecurity.Status === UserSecurityStatus.PasswordChangeRequired) {
                        return callback(null, {changePasswordLink: [config.protocol, config.baseUrl, 'public/#/ChangePassword/', userSecurity.hgId].join('')});
                    }
                    createUserSecurityContext(userSecurity, createUserSecurityCtxCallback, false, null, params.DeviceInfo);
                });
            }
            function unsuccessfulLogin(userSecurity, callback) {
                userSecurity.FailLoginAttempts += 1;
                if (userSecurity.FailLoginAttempts >= 5) {
                    var actionToken = EntityCache.ActionToken({
                        hgId: uuid.v1(),
                        Status: 'Pending',
                        Type: 'PasswordReset',
                        EntityName: 'UserSecurity',
                        EntityId: userSecurity.hgId,
                        ExpireDate: Date.now() + 3600 * 1000 //expires within 1 hour
                    });
                    actionToken.save(function (err) {
                        if (err) {
                            return callback(err);
                        }
                    });
                    userSecurity.Status = UserSecurityStatus.LockedOut;
                    userSecurity.LockedOutTime = Date.now();
                    userSecurity.save(function (err) {
                        if (err) {
                            HgLog.error('Error saving userSecurity: ' + err);
                            return callback({message: 'business.user.noauth.esus'});
                        }
                        callback({message: 'err.usr.ulo', userSecurity: userSecurity});
                    });
                } else {
                    userSecurity.save(function (err) {
                        if (err) {
                            HgLog.error('Error saving userSecurity: ' + err);
                            return callback({message: 'business.user.noauth.esus'});
                        }
                        callback({userSecurity: userSecurity, message: 'services.int.user.pnm'});
                    });
                }
            }

            function processMobileLogin(params, userSecurity, callback) {
                isMobileEnable(params, function (error, IsEnable) {
                    if (error) {
                        return unsuccessfulLogin(userSecurity, callback);
                    }
                    return IsEnable ? successfulLogin(userSecurity, callback) : callback({message: 'users.pr.gp.md'});
                });
            }

            if (!params.UserName || !params.Password) {
                return callback({message: 'business.user.noauth.vl'});
            }
            EntityCache.UserSecurity.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userSecurity) {
                var lockedOutTime = Date.now() - 3600 * 1000;
                if (err) {
                    return callback({message: 'business.user.noauth.elup'});
                }
                if (!userSecurity) {
                    return callback({message: 'services.int.user.pnm'});
                }
                if (userSecurity.Status === UserSecurityStatus.LockedOut && userSecurity.LockedOutTime > lockedOutTime) {
                    return callback({userSecurity: userSecurity, message: 'err.usr.ulo'});
                }
                // if user hasn't generated a pbkdf2 password yet, we log them in the old way
                // this first part of the if statement will be removed once all users are migrated over to a stronger password
                if (!userSecurity.Password_PBKDF2) {
                    HgLog.debug('logging in with md5 password');
                    //log in the old way
                    if (userSecurity.Password === cryptoHelper.md5(params.Password)) {
                        HgLog.debug('generating new pbkdf2 password');
                        //generate new password after success
                        cryptoHelper.generatePasswordHash({password: params.Password}, function (err, data) {
                            if (err) {
                                return callback(err);
                            }
                            userSecurity.Password_PBKDF2 = data.passwordHash;
                            userSecurity.PasswordSalt = data.salt;
                            userSecurity.PasswordIterations = data.iterations;
                            userSecurity.Password = '';
                            if (params.IsMobile) {
                                return processMobileLogin(params, userSecurity, callback);
                            }
                            successfulLogin(userSecurity, callback);
                        });
                    } else {
                        unsuccessfulLogin(userSecurity, callback);
                    }
                } else {
                    HgLog.debug('logging in with new pbkdf2 password');
                    //log in with new pbkdf2 key
                    cryptoHelper.generatePasswordHash({
                        password: params.Password,
                        salt: userSecurity.PasswordSalt,
                        iterations: userSecurity.PasswordIterations
                    }, function (err, data) {
                        if (userSecurity.Password_PBKDF2 === data.passwordHash) {
                            if (params.IsMobile) {
                                return processMobileLogin(params, userSecurity, callback);
                            }
                            successfulLogin(userSecurity, callback);
                        } else {
                            unsuccessfulLogin(userSecurity, callback);
                        }
                    });
                }
            });
        };

        this.RequestResetPassword = function (params, callback) {
            EntityCache.UserSecurity.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userSecurity) {
                var actionToken;
                if (err || !userSecurity) {
                    return callback('server.hge.usr.uad');
                }
                actionToken = EntityCache.ActionToken({
                    hgId: uuid.v1(),
                    Status: 'Pending',
                    Type: 'PasswordReset',
                    EntityName: 'UserSecurity',
                    EntityId: userSecurity.hgId,
                    ExpireDate: Date.now() + 3600 * 1000//expires within 1 hours
                });
                actionToken.save(function (err) {
                    if (err) {
                        return callback(err);
                    }
                    EntityCache.UserInfo.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userInfo) {
                        if (err || !userInfo) {
                            return callback('server.hge.usr.elu');
                        }
                        callback(null, {ActionToken: actionToken, DefaultGroupId: userInfo.Preference ? userInfo.Preference.DefaultGroupId : null});
                    });
                });
            });
        };

        this.CheckCurrentPassword = function (params, callback) {
            var userSecurity = params.UserSecurity;
            if (!userSecurity) {
                return callback({message: 'services.int.user.pnm'});
            }
            if (!userSecurity.Password_PBKDF2) {
                if (userSecurity.Password === cryptoHelper.md5(params.Password)) {
                    return callback(null, true);
                }
            } else {
                cryptoHelper.generatePasswordHash({
                    password: params.Password,
                    salt: userSecurity.PasswordSalt,
                    iterations: userSecurity.PasswordIterations
                }, function (err, data) {
                    if (err || !data) {
                        callback(err || '');
                    }
                    if (userSecurity.Password_PBKDF2 !== data.passwordHash) {
                        return callback('server.hge.usr.cpi');
                    }
                    return callback(null, true);
                });
            }
        };

        this.ValidatePasswordResetToken = function (params, callback) {
            EntityCache.ActionToken.findOne({hgId: params.ActionToken}, function (err, actionToken) {
                if (err) {
                    return callback('server.hge.usr.elat');
                }
                validateActionToken(actionToken, function (err) {
                    if (err) {
                        return callback(err);
                    }
                    EntityCache.UserSecurity.findOne({hgId: actionToken.EntityId}, function (err, userSecurity) {
                        if (err) {
                            return callback('server.hge.usr.elus');
                        }
                        if (!userSecurity) {
                            return callback('server.hge.usr.usdne');
                        }
                        callback(null, userSecurity.UserName);
                    });
                });
            });
        };

        this.ResetPassword = function (params, callback) {
            EntityCache.ActionToken.findOne({hgId: params.ActionToken}, function (err, actionToken) {
                if (err) {
                    return callback(HgError.Enums.User.ErrorLoadingActionToken);
                }
                validateActionToken(actionToken, function (err) {
                    if (err) {
                        return callback('business.user.noauth.elat');
                    }
                    actionToken.Status = 'Fullfilled';
                    actionToken.save(function (err) {
                        if (err) {
                            return callback('server.hge.usr.elat');
                        }
                        EntityCache.UserSecurity.findOne({hgId: actionToken.EntityId}, function (err, userSecurity) {
                            if (err) {
                                return callback('server.hge.usr.elus');
                            }
                            if (!userSecurity) {
                                return callback('server.hge.usr.usdne');
                            }
                            cryptoHelper.generatePasswordHash({password: params.Password}, function (err, data) {
                                if (err) {
                                    HgLog.error({methodName: 'ResetPassword', error: err});
                                    return callback(err);
                                }
                                userSecurity.Password_PBKDF2 = data.passwordHash;
                                userSecurity.PasswordIterations = data.iterations;
                                userSecurity.PasswordSalt = data.salt;
                                userSecurity.Password = '';
                                userSecurity.Status = MemberEnums.Status.Active;
                                userSecurity.FailLoginAttempts = 0;
                                userSecurity.save(function (err) {
                                    if (err) {
                                        HgLog.error('Error saving userSecurity', err);
                                        return callback('Error saving userSecurity');
                                    }
                                    // logout this user from all devices
                                    EntityCache.UserInfoWithToken.remove({hgId: userSecurity.hgId}, function (err) {
                                        if (err) {
                                            HgLog.error({methodName: 'ResetPassword.userinfo', error: err});
                                            return callback('Error removing user info with token');
                                        }
                                        // logout this user from all devices
                                        EntityCache.UserSecurityWithToken.remove({hgId: userSecurity.hgId}, function (err) {
                                            if (err) {
                                                HgLog.error({methodName: 'ResetPassword.userSecurity', error: err});
                                                return callback('Error removing user security with token');
                                            }
                                            callback(null, actionToken.EntityId);
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        };

        this.ChangePassword = function (params, fcallback) {
            Async.waterfall([
                function (callback) {
                    EntityCache.UserSecurity.findOne({
                        hgId: params.UserId
                    }, function (err, userSecurity) {
                        if (err) {
                            return callback({message: 'business.user.noauth.elup'});
                        }
                        if (!userSecurity) {
                            return callback({message: 'services.int.user.pnm'});
                        }
                        if (userSecurity.Status !== UserSecurityStatus.PasswordChangeRequired) {
                            return callback({required: false});
                        }
                        callback(null, userSecurity);
                    });
                },
                function (userSecurity, callback) {
                    self.CheckCurrentPassword({
                        UserSecurity: userSecurity,
                        Password: params.OldPassword
                    }, function (err, matches) {
                        if (err || !matches) {
                            return callback(err || 'server.hge.usr.opi');
                        }
                        if (params.OldPassword === params.NewPassword) {
                            return callback('common.pwr.oan');
                        }
                        callback(null, userSecurity);
                    });
                },
                function (userSecurity, callback) {
                    // set new password
                    cryptoHelper.generatePasswordHash({
                        password: params.Password
                    }, function (err, data) {
                        if (err) {
                            HgLog.error({methodName: 'ChangePassword', error: err});
                            return callback(err);
                        }
                        userSecurity.Password_PBKDF2 = data.passwordHash;
                        userSecurity.PasswordIterations = data.iterations;
                        userSecurity.PasswordSalt = data.salt;
                        userSecurity.Password = '';
                        userSecurity.Status = MemberEnums.Status.Active;
                        userSecurity.save(function (err) {
                            if (err) {
                                HgLog.error('services.int.user.esu', err);
                                return callback('services.int.user.esu');
                            }
                            callback(null, userSecurity);
                        });
                    });
                },
                function (userSecurity, callback) {
                    self.LogoutUsersById({
                        UserId: userSecurity.hgId
                    }, function (error) {
                        if (error) {
                            return callback();
                        }
                        callback(null, userSecurity.hgId);
                    });
                }
            ], fcallback);
        };

        this.GetPublicUserInfoByMemberId = function (params, callback) {
            EntityCache.Member.findOne({hgId: params.MemberId}, function (err, member) {
                if (err) {
                    return callback('server.hge.usr.elm');
                }
                if (!member) {
                    return callback(HgError.Enums.User.MemberDoesNotExist);
                }
                if (member.MembershipStatus !== 'Active') {
                    return callback('server.hge.usr.uoc');
                }
                EntityCache.UserInfo.findOne({hgId: member.UserId}, function (err, user) {
                    if (err) {
                        return callback('server.hge.usr.elm');
                    }
                    EntityCache.Group.findOne({hgId: member.GroupId}, function (err, group) {
                        var groupName = member.GroupName,
                            showRecognitions = false,
                            freeFormComments = false;
                        if (!err && group && group.PublicDisplayName) {
                            groupName = group.PublicDisplayName;
                        }
                        // determine to show recognitions
                        if (group.Preference && group.Preference.FeatureFlags) {
                            group.Preference.FeatureFlags.forEach(function (flag) {
                                if (flag.FeatureName === FeatureFlagEnums.ShowPublicRecognitions && flag.FeatureEnabled) {
                                    showRecognitions = true;
                                }
                                if (flag.FeatureName === FeatureFlagEnums.PublicRecFreeformComments && flag.FeatureEnabled) {
                                    freeFormComments = true;
                                }
                            });
                        }
                        callback(null, {
                            FullName: member.FullName,
                            PublicDisplayName: groupName,
                            FirstName: member.FirstName,
                            UserId: member.UserId,
                            GroupDepartmentName: member.GroupDepartmentName,
                            GroupId: member.GroupId,
                            hgId: member.hgId,
                            ShowPublicRecognitions: showRecognitions,
                            AvatarVersion: user.AvatarVersion,
                            FreeformComments: freeFormComments
                        });
                    });
                });
            });
        };

        this.RequestExportGroupDataActionToken = function (params, callback) {
            var actionToken;
            EntityCache.UserSecurity.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userSecurity) {
                if (err || !userSecurity) {
                    return callback('business.user.noauth.elus');
                }
                actionToken = EntityCache.ActionToken({
                    hgId: uuid.v1(),
                    Status: 'Pending',
                    Type: 'ExportGroupData',
                    EntityName: 'Group',
                    CreatedBy: params.CreatedBy,
                    ModifiedBy: params.ModifiedBy,
                    EntityId: userSecurity.hgId,
                    ExpireDate: new Date().getTime() + 3600 * 1000//expires within 1 hours
                });
                actionToken.save(function (err) {
                    if (err) {
                        callback(err);
                    }
                });
                EntityCache.UserInfo.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userInfo) {
                    if (err || !userInfo) {
                        callback('business.user.noauth.elup');
                    } else {
                        callback(null, {ActionToken: actionToken});
                    }
                });
            });
        };

        this.ValidateExportGroupDataToken = function (params, callback) {
            EntityCache.ActionToken.findOne({hgId: params.ActionToken}, function (error, actionToken) {
                if (error) {
                    return callback('business.user.noauth.elat');
                }
                if (!actionToken) {
                    callback('business.user.noauth.atdneegd');
                } else if (actionToken.CreatedBy !== params.UserId) {
                    callback('business.user.noauth.atad');
                } else if (actionToken.Status !== 'Pending' ||  actionToken.Type !== 'ExportGroupData' || actionToken.ExpireDate < new Date().getTime()) {
                    callback('business.user.noauth.atifd');
                } else {
                    callback(null, 'Valid Token');
                }
            });
        };

        this.GetApprovedAuthTypesByUsername = function (params, callback) {
            if (!params.UserName) {
                return callback('business.user.noauth.vun');
            }
            getApprovedAuthTypesByUsername(params.UserName, callback);
        };

        this.RequestAuthCode = function (params, callback) {
            if (!params.UserName) {
                return callback('business.user.noauth.vun');
            }
            //think this should be changed to get approved auth types by group
            getApprovedAuthTypesByUsername(params.UserName, function (error, authTypes) {
                if (error) {
                    return callback(error);
                }
                if (authTypes.isMobileDisabled) {
                    return callback('users.pr.gp.md');
                }
                if (authTypes.AuthTypes.indexOf(AuthEnums.AuthType.AuthCode) < 0) {
                    return callback('business.user.noauth.acn');
                }
                EntityCache.UserSecurity.findOne({LowercaseUserName: params.UserName.toLowerCase()}, function (err, userSecurity) {
                    var actionToken;
                    if (err || !userSecurity) {
                        return callback('server.hge.usr.uad');
                    }
                    actionToken = EntityCache.ActionToken({
                        hgId: uuid.v1(),
                        Status: EntityEnums.ActionTokenStatus.Pending,
                        Type: EntityEnums.ActionTokenType.MobileAuth,
                        EntityName: 'UserSecurity',
                        EntityId: userSecurity.hgId,
                        ExpireDate: Date.now() + 3600 * 1000, //expires within 1 hours
                        AuthCode: Math.floor(Math.random() * 899999 + 100000) //generates a random 6 digit pin
                    });
                    actionToken.save(function (error) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, actionToken);
                    });
                });
            });
        };
        this.GetActionTokenById = function (params, callback) {
            EntityCache.ActionToken.findOne({hgId: params.ActionTokenId}, function (err, actionToken) {
                if (err || !actionToken) {
                    if (err) {
                        HgLog.error('Error loading action token', err);
                    }
                    //error loading action token
                    return callback('business.user.noauth.ela');
                }
                if (actionToken.Status !== EntityEnums.ActionTokenStatus.Pending || actionToken.ExpireDate < Date.now()) {
                    return callback('business.user.noauth.ate');
                }

                callback(null, actionToken);
            });
        };
        this.ValidateUserPassword = function (params, callback) {
            EntityCache.UserSecurity.findOne({
                hgId: params.UserId
            }, function (err, userSecurity) {
                if (err || !userSecurity) {
                    return callback(err || 'admin.tet.psr');
                }
                cryptoHelper.generatePasswordHash({
                    password: params.Pwd,
                    salt: userSecurity.PasswordSalt,
                    iterations: userSecurity.PasswordIterations
                }, function (err, data) {
                    if (err) {
                        return callback(err);
                    }
                    callback(null, userSecurity.Password_PBKDF2 === data.passwordHash);
                });
            });
        };
        this.IsPasswordChangeRequired = function (params, callback) {
            EntityCache.UserSecurity.findOne({
                hgId: params.UserId
            }, function (error, userSecurity) {
                if (error || !userSecurity) {
                    return callback(error || 'services.int.user.elu');
                }
                callback(null, userSecurity.Status === UserSecurityStatus.PasswordChangeRequired);
            });
        };
        this.LogAuthCodeRequest = function (params, callback) {
            EntityCache.AuthCodeRequest.create({
                UserName: params.UserName,
                IPAddress: params.IPAddress,
                CreatedDate: Date.now()
            }, callback);
        };
        // this is a fire-and-forget call to remove all other user/security tokens
        this.DetermineRestrictToSingleSession = function (params) {
            var source = params.isMobile ? EntityEnums.Source.Mobile : EntityEnums.Source.Web;
            if (params.userInfo && params.userInfo.hgId &&
                    params.userInfo.UserContext.PermissionsInGroup.indexOf(FeatureFlagEnums.RestrictToSingleSession) > -1) {
                Async.parallel([
                    function (apcb) {
                        EntityCache.UserInfoWithToken.remove({
                            hgId: params.userInfo.hgId,
                            UserToken: {$ne: params.userInfo.UserToken},
                            $and: [
                                {
                                    $or: [
                                        {ActAsUserToken: ""},
                                        {ActAsUserToken: {$exists: false}},
                                        {ActAsUserToken: null}
                                    ]
                                },
                                {
                                    $or: [
                                        {Source: source},
                                        {Source: {$exists: false}}
                                    ]
                                }
                            ]
                        }, function (err) {
                            if (err) {
                                return apcb(err);
                            }
                            apcb();
                        });
                    },
                    function (apcb) {
                        EntityCache.UserSecurityWithToken.remove({
                            hgId: params.userInfo.hgId,
                            UserToken: {$ne: params.userInfo.UserToken},
                            $and: [
                                {
                                    $or: [
                                        {ActAsUserToken: ""},
                                        {ActAsUserToken: {$exists: false}},
                                        {ActAsUserToken: null}
                                    ]
                                },
                                {
                                    $or: [
                                        {Source: source},
                                        {Source: {$exists: false}}
                                    ]
                                }
                            ]
                        }, function (err) {
                            if (err) {
                                return apcb(err);
                            }
                            apcb();
                        });
                    }
                ], function (err) {
                    if (err) {
                        HgLog.error('Error while deleting tokens for single session restriction: ' + err);
                    }
                });
            }
        };
    };

module.exports = UserProcessorNoAuth;
