/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    FeedProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js');

        function updateDefaultSearch(params, callback) {
            var query = {
                MemberId: params.MemberId,
                hgId: {$ne: params.hgId}
            }, update = {
                $set: {
                    ModifiedBy: params.ModifiedBy,
                    DefaultSearch: false
                }
            };
            EntityCache.FeedSearch.update(query, update, {multi: true}, callback);
        }

        this.GetMemberDefaultFeedSearch = function (params, callback) {
            EntityCache.FeedSearch.findOne({
                MemberId: params.MemberId,
                DefaultSearch: true
            }, callback);
        };

        this.GetMemberFeedSearchByName = function (params, callback) {
            var query = {
                MemberId: params.MemberId,
                Name: params.Name
            };
            EntityCache.FeedSearch.findOne(query, callback);
        };

        this.GetMemberFeedSearch = function (params, callback) {
            var query = {
                MemberId: params.MemberId,
                Status: 'Active'
            };
            EntityCache.FeedSearch.find(query, callback);
        };

        this.AddFeedSearch = function (params, callback) {
            var feedSearch = new EntityCache.FeedSearch(params);
            feedSearch.save(function (error) {
                if (error) {
                    return callback(error);
                }
                if (!params.DefaultSearch) {
                    return callback(null, 'business.feed.pro.fss');
                }
                updateDefaultSearch(params, function (error, data) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, 'business.feed.pro.fss');
                });
            });
        };

        this.UpdateFeedSearch = function (params, callback) {
            EntityCache.FeedSearch.update({hgId: params.hgId}, {
                $set: {
                    Name: params.Name,
                    DefaultSearch: params.DefaultSearch,
                    ModifiedBy: params.ModifiedBy,
                    RecognitionSource: params.RecognitionSource,
                    Status: params.Status,
                    ManagerIds: params.ManagerIds,
                    DepartmentIds: params.DepartmentIds,
                    LocationIds: params.LocationIds,
                    TeamIds: params.TeamIds,
                    UserIds: params.UserIds,
                    SearchTerm: params.SearchTerm,
                    RelevancyFilter: params.RelevancyFilter
                }
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!params.DefaultSearch) {
                    return callback(null, 'business.feed.pro.fss');
                }
                updateDefaultSearch(params, function (error, data) {
                    callback(error, 'business.feed.pro.fss');
                });
            });
        };
    };

module.exports = FeedProcessor;
