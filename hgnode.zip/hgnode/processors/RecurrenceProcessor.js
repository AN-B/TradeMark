/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    RecurrenceProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid'),
            RecurrenceEnums = require('../enums/RecurrenceEnums.js'),
            ProcessorHelper = require('../util/ProcessorHelper.js'),
            checkDuplicate = function (params, callback) {
                if (!params.CheckDupe) {
                    return callback();
                }
                EntityCache.Recurrence.findOne({
                    RecurrenceType: params.RecurrenceType,
                    EntityId: params.EntityId,
                    Status: RecurrenceEnums.Status.Active
                }, callback);
            };

        this.UpdateFrequencyByEntityIds = function (params, callback) {
            EntityCache.Recurrence.update({
                EntityId: {$in: params.EntityIds},
                RecurrenceType: params.RecurrenceType
            }, {
                $set: {PeriodType: params.PeriodType, NumPeriod: params.NumPeriod}
            }, {
                multi: true
            }, callback);
        };

        this.CreateRecurrence = function (params, callback) {
            checkDuplicate(params, function (error, existingRecurrence) {
                var recurrence = new EntityCache.Recurrence(params);
                if (error) {
                    return callback(error);
                }
                if (existingRecurrence) {
                    return callback(null, existingRecurrence);
                }
                recurrence.hgId = guid.v1();
                recurrence.save(function (error) {
                    callback(error, recurrence);
                });
            });
        };

        this.GetPendingRecurrences = function (params, callback) {
            EntityCache.Recurrence.find({
                Status: RecurrenceEnums.Status.Active,
                NextTriggerDate: {$lte: params.NowStamp}
            }).limit(10).exec(callback);
        };
        this.UpdateRecurrenceNextTriggerDateByEntityId = function (params, callback) {
            var update = {
                    $set: {
                        NextTriggerDate: params.NextTriggerDate
                    }
                };
            if (params.FirstTriggerDate) {
                update.$set.FirstTriggerDate = params.FirstTriggerDate;
            }
            EntityCache.Recurrence.update({
                EntityId: params.EntityId,
                Status: RecurrenceEnums.Status.Active
            }, update, callback);
        };
        this.StopRecurrence = function (params, callback) {
            EntityCache.Recurrence.update({
                EntityId: params.EntityId,
                Status: RecurrenceEnums.Status.Active
            }, {
                $set: {
                    Status: RecurrenceEnums.Status.Archived,
                    ModifiedBy: params.UserId
                }
            }, function (error) {
                callback(error, 'The recurrence has been stopped');
            });
        };
        this.ArchiveRecurrenceByEntityIdAndType = function (params, callback) {
            EntityCache.Recurrence.update({
                EntityId: params.EntityId,
                Status: RecurrenceEnums.Status.Active,
                RecurrenceType: params.RecurrenceType
            }, {
                $set: {
                    Status: RecurrenceEnums.Status.Archived,
                    ModifiedBy: params.UserId,
                    ModifiedDate: new Date().getTime()
                }
            }, {
                multi: true
            }, function (error) {
                callback(error, 'The recurrence has been stopped');
            });
        };
        this.GetRecurrenceByEntityId = function (params, callback) {
            EntityCache.Recurrence.findOne({EntityId: params.EntityId, Status: RecurrenceEnums.Status.Active}, function (error, recurrence) {
                callback(error, recurrence);
            });
        };
        this.GetRecurrenceByEntityIdAndType = function (params, callback) {
            EntityCache.Recurrence.findOne({
                EntityId: params.EntityId,
                Status: RecurrenceEnums.Status.Active,
                RecurrenceType: params.RecurrenceType
            }, function (error, recurrence) {
                callback(error, recurrence);
            });
        };
        this.SetInProgresss = function (params, callback) {
            EntityCache.Recurrence.update({
                hgId: params.hgId
            }, {
                $set: {
                    Status: RecurrenceEnums.Status.InProgress
                }
            }, callback);
        };
        this.UpdateRecurrence = function (params, callback) {
            EntityCache.Recurrence.update({
                hgId: params.Recurrence.hgId
            }, {
                $set: ProcessorHelper.GetUpdateJson(params.Fields, params.Recurrence, params.UserId)
            }, callback);
        };
        this.GetRecurrecenceById = function (params, callback) {
            EntityCache.Recurrence.findOne({hgId: params.RecurrenceId, Status: RecurrenceEnums.Status.Active}, callback);
        };
    };

module.exports = RecurrenceProcessor;
