/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    JobProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            time = require('time');

        this.GetDueJobs = function (params, callback) {
            var now, hour, dayOfMonth, dayOfWeek,
                curTimestamp = new Date().getTime(),
                offset = 3600 * 1000 * 12,//have to make sure the job wasn't run in past 12 hours
                cutoffTime = curTimestamp - offset;
            time.tzset('America/Chicago');
            now = new time.Date();
            hour = now.getHours();
            dayOfMonth = new Date().getUTCDate();
            dayOfWeek = new Date().getDay();
            EntityCache.Job.find({$or : [
                {PeriodType : 'Daily', Hour : hour, LatestTriggerDate : {$lt : cutoffTime}},
                {PeriodType : 'Weekly', Hour : hour, Day : dayOfWeek, LatestTriggerDate : {$lt : cutoffTime}},
                {PeriodType : 'Monthly', Hour : hour, Day : dayOfMonth, LatestTriggerDate : {$lt : cutoffTime}}
            ]}, function (error, jobs) {
                if (error) {
                    return callback(error);
                }
                if (jobs.length === 0) {
                    return callback(null, []);
                }
                EntityCache.Job.update(
                    {
                        JobName : {$in : jobs.map(function (item) { return item.JobName; })}
                    },
                    {
                        $set: { LatestTriggerDate : new Date().getTime() }
                    },
                    {multi : true},
                    function (error, result) {
                        callback(error, jobs);
                    }
                );
            });
        };

        this.GetDailyJobs = function (params, callback) {
            EntityCache.Job.find({PeriodType : 'Daily'}).sort({Hour : 1}).exec(function (error, jobs) {
                callback(error, jobs);
            });
        };
    };

module.exports = JobProcessor;