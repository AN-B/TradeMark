/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    RewardProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            guid = require('node-uuid'),
            EventResponder = require('../util/EventResponder.js'),
            FileHelper = require('../util/FileHelper.js'),
            Enums = require('../enums/EntityEnums.js'),
            getWeekStart = function () {
                var curDate = new Date();
                curDate.setHours(0);
                curDate.setDate(curDate.getDate() - curDate.getDay());
                return curDate;
            },
            getMonthStart = function () {
                var curDate = new Date();
                return new Date(curDate.getUTCFullYear(), curDate.getUTCMonth(), 1);
            },
            getQuarterStart = function () {
                var curDate = new Date(),
                    year = curDate.getUTCFullYear(),
                    month = curDate.getUTCMonth();
                if (month <= 2) {
                    month = 0;
                } else if (month <= 5) {
                    month = 2;
                } else if (month <= 8) {
                    month = 5;
                } else {
                    month = 8;
                }
                return new Date(year, month, 1);
            },
            getYearStart = function () {
                var curDate = new Date(),
                    year = curDate.getUTCFullYear();
                return new Date(year, 0, 1);
            },
            resolveStartDate = function (rewardItem) {
                var curDate = new Date(),
                    year = curDate.getUTCFullYear(),
                    month = curDate.getUTCMonth(),
                    day = curDate.getUTCDate(),
                    startDate;
                switch (rewardItem.Period) {
                case Enums.RewardItemPeriod.Daily:
                    startDate = new Date(year, month, day);
                    break;
                case Enums.RewardItemPeriod.Weekly:
                    startDate = getWeekStart();
                    break;
                case Enums.RewardItemPeriod.Monthly:
                    startDate = getMonthStart();
                    break;
                case Enums.RewardItemPeriod.Quarterly:
                    startDate = getQuarterStart();
                    break;
                case Enums.RewardItemPeriod.Annual:
                    startDate = getYearStart();
                    break;
                default:
                    startDate = curDate;
                }
                return startDate.getTime();
            };
        this.ValidateEligibility = function (params) {
            var rewardItem = params.RewardItem,
                requestMember = params.RequestMember,
                startDate;
            if (rewardItem.Limit === -1) {
                EventResponder.RespondWithData(EventEmitterCache, params, true);
                return;
            }
            startDate = resolveStartDate(rewardItem);
            EntityCache.Reward.find({'RewardItem.hgId' : rewardItem.hgId, 'RequestMember.hgId' : requestMember.hgId, 'CreatedDate' : {$gt : startDate}}, function (err, rewards) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                    return;
                }
                if (rewards && rewards.length >= rewardItem.Limit) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'You have exceeded the limit of the reward item');
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, true);
            });
        };

        this.CreateRewardItem = function (params) {
            var item = EntityCache.RewardItem(params.ItemRequest);
            item.hgId = guid.v1();
            item.CreatedBy = params.UserId;
            item.ModifiedBy = params.UserId;
            EntityCache.Group.findOne({'hgId' : item.GroupId}, function (err, group) {
                if (err || !group) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'Error loading group');
                    return;
                }
                item.FriendlyGroupId = group.FriendlyGroupId;
                item.save(function (err) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, err);
                        return;
                    }
                    FileHelper.CopyBadgeImage({
                        BadgeId : params.ItemRequest.BadgeId,
                        FriendlyGroupId : group.FriendlyGroupId,
                        ItemId : item.hgId
                    });
                    EventResponder.RespondWithData(EventEmitterCache, params, item);
                });
            });
        };

        this.DeleteRewardItem = function (params) {
            EntityCache.RewardItem.findOne({'hgId' : params.ItemId}).remove();
            EventResponder.RespondWithData(EventEmitterCache, params, 'RewardItem deleted');
        };

        this.GetRewardItems = function (params) {
            EntityCache.Team.find({$or : [{'TeamMembers.MemberId': params.MemberId}, {'IsPublic' : true}], 'Status' : {$ne : 'Deleted'}}, function (err, teams) {
                var mquery,
                    i,
                    len,
                    teamIds = [];
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                    return;
                }
                for (i = 0, len = teams.length; i < len; i += 1) {
                    teamIds.push(teams[i].hgId);
                }
                mquery = EntityCache.RewardItem.find({'GroupId' : params.GroupId, $or : [{'TeamId' : {$in : teamIds}}, {'AccessLevel' : 'WithinGroup'}, {'CreatedBy' : params.UserId}]});
                mquery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, items) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, err);
                        return;
                    }
                    EventResponder.RespondWithData(EventEmitterCache, params, items);
                });
            });
        };

        this.GetAllRewardItemsForGroup = function (params) {
            var mquery = EntityCache.RewardItem.find({'GroupId' : params.GroupId});
            mquery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, items) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, items);
            });
        };

        this.GetRewardsForMember = function (params) {
            var mquery = EntityCache.Reward.find({'RequestMember.hgId' : params.MemberId, 'Status' : params.Status});
            mquery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, items) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, items);
            });
        };

        this.GetRewardsInGroup = function (params) {
            var mquery = EntityCache.Reward.find({'RequestMember.GroupId' : params.GroupId, 'Status' : params.Status});
            mquery.skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (err, items) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, items);
            });
        };

        this.GetRewardItemById = function (params) {
            EntityCache.RewardItem.findOne({'hgId' : params.ItemId}, function (err, item) {
                if (err || !item) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'Error loading reward item');
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, item);
            });
        };

        this.GetRewardById = function (params) {
            EntityCache.Reward.findOne({'hgId' : params.RewardId}, function (err, reward) {
                if (err || !reward) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'Error loading reward');
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, reward);
            });
        };

        this.VerifyAndUpdateMemberExperiencePoint = function (params) {
            var rewardItem = params.RewardItem,
                requestMember = params.RequestMember,
                OperationType = params.OperationType;
            if (OperationType === 'RequestReward') {
                if (rewardItem.XPCost > requestMember.ExperiencePoint) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'You do not have sufficient XP to request the item');
                    return;
                }
                requestMember.ExperiencePoint -= rewardItem.XPCost;
            } else if (OperationType === 'CancelReward') {
                requestMember.ExperiencePoint += rewardItem.XPCost;
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, 'Invalid operation type');
                return;
            }
            requestMember.ModifiedBy = params.UserId;
            requestMember.save();
            EventResponder.RespondWithData(EventEmitterCache, params, requestMember);
        };

        this.CreateReward = function (params) {
            var reward = EntityCache.Reward(params);
            reward.hgId = guid.v1();
            reward.CreatedBy = params.UserId;
            reward.ModifiedBy = params.UserId;
            reward.Status = 'Ordered';
            reward.save();
            EventResponder.RespondWithData(EventEmitterCache, params, reward);
        };

        this.UpdateRewardStatus = function (params) {
            var reward = params.Reward;
            reward.ModifiedBy = params.UserId;
            reward.ModifiedDate = Date.now;
            reward.Status = params.NewStatus;
            reward.save();
            EventResponder.RespondWithData(EventEmitterCache, params, reward);
        };

        this.GetRewardItemsByGroupId = function (params, callback) {
            EntityCache.RewardItem.find({'GroupId' : params.GroupId}, function (err, rewardItems) {
                if (!err) {
                    callback(null, rewardItems);
                } else {
                    callback(err);
                }
            });
        };
    };

module.exports = RewardProcessor;
