/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    EntityActivityProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            guid = require('node-uuid');

        this.CreateActivity = function (params, callback) {
            var activity = new EntityCache.EntityActivity(params);
            activity.hgId = guid.v1();
            activity.CreatedBy = params.UserId;
            activity.ModifiedBy = params.UserId;
            activity.save(function (error) {
                if (callback) {//need to check if callback exists because lots of time this is fire and forget
                    callback(error, activity);
                }
            });
        };

        this.CreateActivities = function (params, callback) {
            EntityCache.EntityActivity.create(params.Activities, callback);
        };

        this.GetActivitiesByBatchIds = function (params, callback) {
            EntityCache.EntityActivity.find({BatchId: {$in: params.BatchIds}})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 50)
                .sort({_id: -1})
                .exec(callback);
        };

        this.GetActivitiesByMemberId = function (params, callback) {
            EntityCache.EntityActivity.find({MemberId: params.MemberId})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 50)
                .sort({_id: -1})
                .exec(callback);
        };

        this.RemoveActivity = function (params, callback) {
            if (!params.hgId) {
                return callback('entityactivity.processor.nhgid');
            }
            EntityCache.EntityActivity.remove(params, callback);
        };

        this.GetBucketActivitiesByEntityIds = function (params, callback) {
            var query = {};
            if (params.BatchIds && params.BatchIds.length) {
                query.BatchId = {$in: []};
                params.BatchIds.forEach(function (batchId) {
                    query.BatchId.$in.push(batchId);
                });
            }
            query.Entities = params.EntityIds;
            EntityCache.EntityActivity.find(query)
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 50)
                .sort({_id: -1})
                .exec(callback);
        };
    };

module.exports = EntityActivityProcessor;
