/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ActivityProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../framework/EntityCache.js');

        this.SaveMassAvatarUploadActivity = function (params, callback) {
            if (process.env.PRUNE_HGLOG) {
                return callback();
            }
            EntityCache.UserActivityAudit.create(params.Members.map(function (item) {
                return {
                    CreatedDate: new Date(),
                    GroupId: params.GroupId,
                    UserId: item.UserId,
                    MemberId: item.hgId,
                    ServiceName: 'Provision',
                    MethodName: 'UploadMassMemberAvatars'
                };
            }), callback);
        };
    };

module.exports = ActivityProcessor;