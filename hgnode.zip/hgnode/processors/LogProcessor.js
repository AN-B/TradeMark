/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    LogProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            EventResponder = require('../util/EventResponder.js'),
            defaultDaysToGoBack = 7;

        this.GetLogs = function (params) {
            var startDate = params.StartDate;
            if (startDate === undefined) {
                startDate = new Date().getTime() - defaultDaysToGoBack * 24 * 60 * 60 * 1000;
            }
            EntityCache.Log.find({timestamp: {$gte: startDate}}, {lean: true}).sort('timestamp').exec(function (error, logs) {
                EventResponder.RespondGeneric(EventEmitterCache, params, error, logs);
            });
        };
    };

module.exports = LogProcessor;