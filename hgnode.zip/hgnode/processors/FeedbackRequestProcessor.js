/*jslint node:true es5:true*/
var HgProcessorV2 = require('../framework/HgProcessorV2.js'),
    FeedbackRequestProcessor = function () {
        'use strict';
        HgProcessorV2.apply(this, arguments);

        var EntityCache = this.EntityCache,
            async = require('async'),
            FeedbackEnums = require('../enums/FeedbackEnums.js'),
            getAboutMeCompletedCondition = function (params) {
                return {
                    GroupId: params.GroupId,
                    SubjectMemberId: params.MemberId,
                    CycleType: {$in: [
                        FeedbackEnums.CycleType.Request,
                        FeedbackEnums.CycleType.Give
                    ]},
                    Status: {$in: [
                        FeedbackEnums.RequestStatus.Declined,
                        FeedbackEnums.RequestStatus.Expired,
                        FeedbackEnums.RequestStatus.Completed
                    ]}
                };
            },
            getAboutOthersCompletedCondition = function (params) {
                return {
                    GroupId: params.GroupId,
                    Status: {$in: [
                        FeedbackEnums.RequestStatus.Requesting,
                        FeedbackEnums.RequestStatus.InProgress,
                        FeedbackEnums.RequestStatus.ReadyToComplete,
                        FeedbackEnums.RequestStatus.Declined,
                        FeedbackEnums.RequestStatus.Expired,
                        FeedbackEnums.RequestStatus.Completed
                    ]},
                    $or: [{
                        RequesterMemberId: params.MemberId,
                        CycleType: FeedbackEnums.CycleType.EvaluateOthers,
                        Status: {$in: [
                            FeedbackEnums.RequestStatus.Declined,
                            FeedbackEnums.RequestStatus.Expired,
                            FeedbackEnums.RequestStatus.Completed
                        ]}
                    }, {
                        RequesterMemberId: params.MemberId,
                        CycleType: FeedbackEnums.CycleType.Give,
                        Status: {$in: [
                            FeedbackEnums.RequestStatus.Declined,
                            FeedbackEnums.RequestStatus.ReadyToComplete,
                            FeedbackEnums.RequestStatus.Expired,
                            FeedbackEnums.RequestStatus.Completed
                        ]}
                    }, {
                        CycleType: {$in: [
                            FeedbackEnums.CycleType.Request,
                            FeedbackEnums.CycleType.EvaluateOthers
                        ]},
                        Sessions: {
                            $elemMatch: {
                                ReviewerMemberId: params.MemberId,
                                SessionStatus: {$in: [
                                    FeedbackEnums.SessionStatus.Completed,
                                    FeedbackEnums.SessionStatus.Expired,
                                    FeedbackEnums.SessionStatus.Declined,
                                    FeedbackEnums.SessionStatus.Submitted
                                ]}
                            }
                        }
                    }]
                };
            },
            getAboutMeInboxCondition = function (params) {
                return {
                    GroupId: params.GroupId,
                    SubjectMemberId: params.MemberId,
                    Status: {$in: [
                        FeedbackEnums.RequestStatus.Requesting,
                        FeedbackEnums.RequestStatus.InProgress,
                        FeedbackEnums.RequestStatus.ReadyToComplete,
                        FeedbackEnums.RequestStatus.Declined,
                        FeedbackEnums.RequestStatus.Expired,
                        FeedbackEnums.RequestStatus.Completed
                    ]},
                    $or: [{
                        CycleType: FeedbackEnums.CycleType.Request,
                        Status: {$in: [
                            FeedbackEnums.RequestStatus.Requesting,
                            FeedbackEnums.RequestStatus.InProgress,
                            FeedbackEnums.RequestStatus.ReadyToComplete
                        ]}
                    }, {
                        CycleType: FeedbackEnums.CycleType.Give,
                        Sessions: {
                            $elemMatch: {
                                SessionStatus: FeedbackEnums.SessionStatus.Submitted
                            }
                        }
                    }]
                };
            },
            getAboutOthersInboxCondition = function (params) {
                return {
                    GroupId: params.GroupId,
                    Status: {$in: [
                        FeedbackEnums.RequestStatus.Requesting,
                        FeedbackEnums.RequestStatus.InProgress,
                        FeedbackEnums.RequestStatus.ReadyToComplete,
                        FeedbackEnums.RequestStatus.Declined,
                        FeedbackEnums.RequestStatus.Expired,
                        FeedbackEnums.RequestStatus.Completed
                    ]},
                    $or: [{
                        CycleType: FeedbackEnums.CycleType.EvaluateOthers,
                        Status: {$in: [
                            FeedbackEnums.RequestStatus.Requesting,
                            FeedbackEnums.RequestStatus.ReadyToComplete,
                            FeedbackEnums.RequestStatus.InProgress]},
                        RequesterMemberId: params.MemberId
                    }, {
                        CycleType: FeedbackEnums.CycleType.Give,
                        Status: FeedbackEnums.RequestStatus.Requesting,
                        RequesterMemberId: params.MemberId
                    }, {
                        CycleType: {$in: [
                            FeedbackEnums.CycleType.EvaluateOthers,
                            FeedbackEnums.CycleType.Request
                        ]},
                        Sessions: {
                            $elemMatch: {
                                SessionStatus: {$in: [
                                    FeedbackEnums.SessionStatus.Requesting,
                                    FeedbackEnums.SessionStatus.InProgress
                                ]},
                                ReviewerMemberId: params.MemberId
                            }
                        }
                    }]
                };
            },
            getQueryCondition = function (aboutMe, aboutOthers, searchTerm, filterType, accessMode) {
                var searchCondition = {"$or": [
                        { "RequesterFullName": {$regex: searchTerm, $options: 'i'} },
                        { "SubjectFullName": {$regex: searchTerm, $options: 'i'} },
                        { CycleTitle: {$regex: searchTerm, $options: 'i'} }
                    ]},
                    condition;
                if (searchTerm && filterType === FeedbackEnums.RequestFilter.All) {
                    condition = {$and: [{$or: [aboutMe, aboutOthers]}, searchCondition]};
                }
                if (searchTerm) {
                    aboutMe = {$and: [aboutMe, searchCondition]};
                    aboutOthers = {$and: [aboutOthers, searchCondition]};
                }
                if ([FeedbackEnums.RequestFilter.ByMeCompleted, FeedbackEnums.RequestFilter.ByMeInbox].indexOf(filterType) > -1) {
                    condition = aboutMe;
                } else if ([FeedbackEnums.RequestFilter.ByOthersCompleted, FeedbackEnums.RequestFilter.ByOthersInbox].indexOf(filterType) > -1) {
                    condition = aboutOthers;
                } else {
                    condition = {$or: [aboutMe, aboutOthers]};
                }
                if (accessMode === FeedbackEnums.ProfileAccessMode.Manager) {
                    condition.IsPrivate = {$in: [null, false]};
                }
                return condition;
            },
            resolveRequestStatusBySessions = function (sessions) {
                var numbers = {
                        Requesting: 0,
                        InProgress: 0,
                        Declined: 0,
                        Expired: 0,
                        Submitted: 0,
                        Completed: 0,
                        Closed: 0,
                        Archived: 0
                    },
                    total = sessions.length;
                sessions.forEach(function (session) {
                    if (!numbers[session.Status]) {
                        numbers[session.Status] = 1;
                    } else {
                        numbers[session.Status] += 1;
                    }
                });
                if (numbers.Requesting === total) {
                    return FeedbackEnums.RequestStatus.Requesting;
                }
                if (numbers.InProgress > 0) {
                    return FeedbackEnums.RequestStatus.InProgress;
                }
                if (numbers.Requesting > 0 && numbers.Declined + numbers.Expired + numbers.Submitted + numbers.Completed + numbers.Closed + numbers.Archived === 0) {
                    return FeedbackEnums.RequestStatus.Requesting;
                }
                if (numbers.Requesting > 0 && numbers.Declined + numbers.Expired + numbers.Submitted + numbers.Completed + numbers.Closed + numbers.Archived > 0) {
                    return FeedbackEnums.RequestStatus.InProgress;
                }
                if (numbers.Declined + numbers.Expired + numbers.Submitted + numbers.Completed + numbers.Closed + numbers.Archived === total &&
                        numbers.Submitted > 0) {
                    return FeedbackEnums.RequestStatus.ReadyToComplete;
                }
                if (total === numbers.Declined) {
                    return FeedbackEnums.RequestStatus.Declined;
                }
                if (total === numbers.Expired + numbers.Declined) {
                    return FeedbackEnums.RequestStatus.Expired;
                }
                if (numbers.Declined + numbers.Expired + numbers.Completed + numbers.Closed + numbers.Archived === total &&
                        numbers.Completed  > 0) {
                    return FeedbackEnums.RequestStatus.Completed;
                }
                if (numbers.Declined + numbers.Expired + numbers.Closed === total &&
                        numbers.Closed > 0) {
                    return FeedbackEnums.RequestStatus.Closed;
                }
                if (numbers.Declined + numbers.Expired + numbers.Archived === total &&
                        numbers.Archived > 0) {
                    return FeedbackEnums.RequestStatus.Archived;
                }
                return FeedbackEnums.RequestStatus.Completed;
            };

        this.CreateRequest = function (params, callback) {
            var firstSession = params.Sessions[0],
                request = new EntityCache.FeedbackRequest({
                    hgId: params.RequestId,
                    CycleTitle: firstSession.CycleTitle,
                    CycleId: firstSession.CycleId,
                    RequestNote: params.RequestNote,
                    IsPrivate: params.IsPrivate,
                    GroupId: params.GroupId,
                    Status: FeedbackEnums.RequestStatus.Requesting,
                    CycleType: firstSession.CycleType,
                    ExpirationDate: firstSession.ExpirationDate,
                    RequesterMemberId: params.MemberId,
                    RequesterUserId: params.UserId,
                    RequesterFullName: params.FullName,
                    CreatedBy: params.UserId,
                    ModifiedBy: params.UserId,
                    UnreadInfo: firstSession.CycleType === FeedbackEnums.CycleType.Give,
                    Sessions: params.Sessions.map(function (session) {
                        var reviewer = session.Participants.find(function (p) {
                            return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                        });
                        return {
                            SessionId: session.hgId,
                            ReviewerMemberId: reviewer.MemberId,
                            ReviewerUserId: reviewer.UserId,
                            ReviewerFullName: reviewer.FullName,
                            UnreadInfo: firstSession.CycleType !== FeedbackEnums.CycleType.Give,
                            SessionStatus: session.Status
                        };
                    })
                }),
                subjectInFirstSession = firstSession.Participants.find(function (p) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
                });
            if (firstSession.CycleType === FeedbackEnums.CycleType.Request) {
                request.SubjectMemberId = params.MemberId;
                request.SubjectUserId = params.UserId;
                request.SubjectFullName = params.FullName;

                request.RequesterMemberId = params.MemberId;
                request.RequesterUserId = params.UserId;
                request.RequesterFullName = params.FullName;
            }
            if (firstSession.CycleType === FeedbackEnums.CycleType.EvaluateOthers) {
                request.SubjectMemberId = subjectInFirstSession.MemberId;
                request.SubjectUserId = subjectInFirstSession.UserId;
                request.SubjectFullName = subjectInFirstSession.FullName;

                request.RequesterMemberId = params.MemberId;
                request.RequesterUserId = params.UserId;
                request.RequesterFullName = params.FullName;
            }
            if (firstSession.CycleType === FeedbackEnums.CycleType.Give) {
                request.SubjectMemberId = subjectInFirstSession.MemberId;
                request.SubjectUserId = subjectInFirstSession.UserId;
                request.SubjectFullName = subjectInFirstSession.FullName;

                request.RequesterMemberId = params.MemberId;
                request.RequesterUserId = params.UserId;
                request.RequesterFullName = params.FullName;
            }
            request.save(callback);
        };

        this.CompleteRequest = function (params, callback) {
            EntityCache.FeedbackRequest.findOne({
                GroupId: params.GroupId,
                hgId: params.RequestId
            }, function (error, request) {
                if (error || !request) {
                    return callback("fbs.int.els");
                }
                if (request.Status !== FeedbackEnums.RequestStatus.ReadyToComplete) {
                    return callback("fbs.int.sbt");
                }
                if (request.CycleType !== FeedbackEnums.CycleType.Give && request.RequesterMemberId !== params.MemberId) {
                    return callback("fbs.int.srt");
                }
                request.Sessions.forEach(function (session) {
                    if (session.SessionStatus === FeedbackEnums.SessionStatus.Submitted) {
                        session.SessionStatus = FeedbackEnums.SessionStatus.Completed;
                    }
                });
                request.Status = FeedbackEnums.RequestStatus.Completed;
                request.CompletedDate = Date.now();
                request.ModifiedBy = params.UserId;
                request.save(callback);
            });
        };

        this.ClearUnreadInfoBySessionId = function (params) {
            if (params.AccessMode === FeedbackEnums.SessionAccessMode.Reviewer) {
                EntityCache.FeedbackRequest.update({
                    "Sessions.SessionId": params.SessionId,
                    GroupId: params.GroupId,
                    "Sessions.ReviewerUserId": params.UserId
                }, {
                    $set: {
                        "Sessions.$.UnreadInfo": false,
                        ModifiedBy: params.UserId
                    }
                }).exec();
            }
        };

        this.ClearUnreadInfoFlag = function (params) {
            if (params.AccessMode === FeedbackEnums.SessionAccessMode.Requester) {
                EntityCache.FeedbackRequest.update({
                    hgId: params.RequestId,
                    GroupId: params.GroupId
                }, {
                    $set: {
                        UnreadInfo: false,
                        ModifiedBy: params.UserId
                    }
                }).exec();
            } else {
                EntityCache.FeedbackRequest.update({
                    hgId: params.RequestId,
                    GroupId: params.GroupId,
                    "Sessions.ReviewerUserId": params.UserId
                }, {
                    $set: {
                        "Sessions.$.UnreadInfo": false,
                        ModifiedBy: params.UserId
                    }
                }).exec();
            }
        };

        this.SyncRequest = function (params, callback) {
            var sessionsInRequest;
            EntityCache.FeedbackRequest.findOne({
                hgId: params.RequestId,
                GroupId: params.GroupId
            }, {Sessions: 1}, {
                lean: true
            }, function (error, request) {
                var requestStatus;
                if (error) {
                    return callback(error);
                }
                sessionsInRequest = params.Sessions.map(function (session) {
                    var reviewer = session.Participants.find(function (p) {
                            return p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer;
                        }),
                        sessionInRequest = request.Sessions.find(function (s) {
                            return s.ReviewerUserId === reviewer.UserId;
                        });
                    return {
                        SessionId: session.hgId,
                        ReviewerMemberId: reviewer.MemberId,
                        ReviewerUserId: reviewer.UserId,
                        ReviewerFullName: reviewer.FullName,
                        SessionStatus: session.Status,
                        SubmittedDate: reviewer.SubmittedDate,
                        DeclinedDate: session.DeclinedDate,
                        UnreadInfo: reviewer.UserId === params.UserId ? !!params.UnreadInfoReviewer : sessionInRequest.UnreadInfo
                    };
                });
                requestStatus = resolveRequestStatusBySessions(params.Sessions);
                EntityCache.FeedbackRequest.update({
                    hgId: params.RequestId,
                    GroupId: params.GroupId
                }, {
                    $set: {
                        Status: requestStatus,
                        Sessions: sessionsInRequest,
                        ModifiedBy: params.UserId,
                        UnreadInfo: !!params.UnreadInfoRequester
                    }
                }, callback);
            });
        };

        this.OverviewRequestComplete = function (params, callback) {
            async.parallel({
                aboutMe: function (fcallback) {
                    var condition = getAboutMeCompletedCondition(params);
                    if ([FeedbackEnums.ProfileAccessMode.Manager].indexOf(params.AccessMode) > -1) {
                        condition.IsPrivate = {$in: [null, false]};
                    }
                    EntityCache.FeedbackRequest.count(condition, fcallback);
                },
                aboutOthers: function (fcallback) {
                    var condition = getAboutOthersCompletedCondition(params);
                    if ([FeedbackEnums.ProfileAccessMode.Manager].indexOf(params.AccessMode) > -1) {
                        condition.IsPrivate = {$in: [null, false]};
                    }
                    EntityCache.FeedbackRequest.count(condition, fcallback);
                }
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    ByMeCompleted: result.aboutMe,
                    ByOthersCompleted: result.aboutOthers
                });
            });
        };

        this.OverviewRequestInbox = function (params, callback) {
            async.parallel({
                aboutMe: function (fcallback) {
                    var condition = getAboutMeInboxCondition(params);
                    if ([FeedbackEnums.ProfileAccessMode.Manager].indexOf(params.AccessMode) > -1) {
                        condition.IsPrivate = {$in: [null, false]};
                    }
                    EntityCache.FeedbackRequest.count(condition, fcallback);
                },
                aboutOthers: function (fcallback) {
                    var condition = getAboutOthersInboxCondition(params);
                    if ([FeedbackEnums.ProfileAccessMode.Manager].indexOf(params.AccessMode) > -1) {
                        condition.IsPrivate = {$in: [null, false]};
                    }
                    EntityCache.FeedbackRequest.count(condition, fcallback);
                }
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    ByMeInbox: result.aboutMe,
                    ByOthersInbox: result.aboutOthers
                });
            });
        };
        this.GetRequestInbox = function (params, callback) {
            var aboutMeCondition = getAboutMeInboxCondition(params),
                aboutOthersCondition = getAboutOthersInboxCondition(params);
            EntityCache.FeedbackRequest.find(getQueryCondition(aboutMeCondition, aboutOthersCondition, params.SearchTerm, params.Filter, params.AccessMode))
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };


        this.GetRequestCompleted = function (params, callback) {
            var aboutMeCondition = getAboutMeCompletedCondition(params),
                aboutOthersCondition = getAboutOthersCompletedCondition(params);
            EntityCache.FeedbackRequest.find(getQueryCondition(aboutMeCondition, aboutOthersCondition, params.SearchTerm, params.Filter, params.AccessMode))
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .sort({_id: -1})
                .exec(callback);
        };

        this.GetRequestById = function (params, callback) {
            EntityCache.FeedbackRequest.findOne({
                GroupId: params.GroupId,
                hgId: params.RequestId
            }, callback);
        };

        this.ArchiveRequest = function (params, callback) {
            EntityCache.FeedbackRequest.findOne({
                GroupId: params.GroupId,
                hgId: params.RequestId
            }, function (error, request) {
                if (error || !request) {
                    return callback("fbs.int.els");
                }
                // currently only support archive give draft
                if (request.Status !== FeedbackEnums.RequestStatus.Requesting && request.CycleType !== FeedbackEnums.CycleType.Give) {
                    return callback("fbs.int.srt");
                }
                request.ModifiedBy = params.UserId;
                request.Status = FeedbackEnums.RequestStatus.Archived;
                request.save(callback);
            });
        };

        this.UnarchiveRequest = function (params, callback) {
            EntityCache.FeedbackRequest.findOne({
                GroupId: params.GroupId,
                hgId: params.RequestId,
                Status: FeedbackEnums.RequestStatus.Archived
            }, function (error, request) {
                if (error || !request) {
                    return callback("fbs.int.els");
                }
                // only support give type feedback for now
                if (request.CycleType !== FeedbackEnums.CycleType.Give) {
                    return callback("fbs.int.srt");
                }
                request.ModifiedBy = params.UserId;
                request.Status = FeedbackEnums.RequestStatus.Requesting;
                request.save(callback);
            });
        };

        this.ArchiveOrCloseRequestByCycleId = function (params, callback) {
            EntityCache.FeedbackRequest.update({
                GroupId: params.GroupId,
                CycleId: params.CycleId
            }, {
                $set: {
                    Status: params.NewStatus,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, callback);
        };
    };

module.exports = FeedbackRequestProcessor;
