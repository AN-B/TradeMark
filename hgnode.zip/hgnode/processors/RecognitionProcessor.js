/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    RecognitionProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            FeedMember = require('../schemas/FeedMemberSchema.js').FeedMember,
            EventEmitterCache = this.EventEmitterCache,
            PusherManager = require('../util/PusherManager'),
            guid = require('node-uuid'),
            HgError = require('../common/HgError.js'),
            HgMessage = require('../common/HgMessage.js'),
            MemberEnums = require('../enums/MemberEnums.js'),
            recognitionHelper = require('../util/RecognitionHelper.js'),
            RecognitionEnums = require('../enums/RecognitionEnums.js'),
            EntityEnums =  require('../enums/EntityEnums.js'),
            Async = require('async'),
            config = require('../configurations/config.js'),
            FileHelper = require('../util/FileHelper.js'),
            EventResponder = require('../util/EventResponder.js'),
            Extend = require('../lib/extend.js'),
            feedQueryProcessor = require('./FeedQueryProcessor.js'),
            templateTypes = {
                MineOnly: RecognitionEnums.GetTypesExceptExcluded([
                    RecognitionEnums.Type.Newsfeed,
                    RecognitionEnums.Type.ProductItem,
                    RecognitionEnums.Type.PollResult,
                    RecognitionEnums.Type.GoalKeyResultUpdate,
                    RecognitionEnums.Type.Skill
                ]),
                CurrentGroup:  RecognitionEnums.GetTypesExceptExcluded([
                    RecognitionEnums.Type.Skill
                ]),
                Team: RecognitionEnums.GetTypesExceptExcluded([
                    RecognitionEnums.Type.Skill
                ]),
                AdvancedSearch: RecognitionEnums.GetTypesExceptExcluded([
                    RecognitionEnums.Type.Skill
                ]),
                External: RecognitionEnums.GetTypesExceptExcluded([
                    RecognitionEnums.Type.Newsfeed,
                    RecognitionEnums.Type.ProductItem,
                    RecognitionEnums.Type.GoalKeyResultUpdate,
                    RecognitionEnums.Type.PollResult
                ]),
                AllExceptNewsProductPoll: RecognitionEnums.GetTypesExceptExcluded([
                    RecognitionEnums.Type.Newsfeed,
                    RecognitionEnums.Type.ProductItem,
                    RecognitionEnums.Type.GoalKeyResultUpdate,
                    RecognitionEnums.Type.PollResult
                ])
            },
            getRecognitionFeed = function (obj) {
                var getIssuer = function () {
                        var hgId,
                            userId,
                            fullName,
                            companyName,
                            email,
                            issuer;
                        if (obj.PublicCreatorInfo && obj.PublicCreatorInfo.FullName) {
                            hgId = '';
                            userId = '';
                            fullName = obj.PublicCreatorInfo.FullName;
                            companyName = obj.PublicCreatorInfo.CompanyName;
                            email = obj.PublicCreatorInfo.Email;
                        } else if (obj.CreatorMember && obj.CreatorMember.hgId) {
                            hgId = obj.CreatorMember.hgId;
                            userId = obj.CreatorMember.UserId;
                            fullName = obj.CreatorMember.FullName;
                            companyName = obj.CreatorMember.GroupName;
                        } else if (obj.TriggerInfo) {
                            hgId = obj.Template.GroupId;
                            userId = '';
                            fullName = 'Rules Engine';
                            companyName = obj.TriggerInfo.GroupName;
                        }
                        issuer = {
                            hgId : hgId,
                            userId : userId,
                            fullName : fullName,
                            companyName : companyName,
                            email : email
                        };
                        return issuer;
                    },
                    shouldStickOnTop = function () {
                        if (obj.Sticky && !obj.MeDismissed) {
                            return true;
                        }
                        return false;
                    },
                    getTitle = function (templateTitle, subValue) {
                        if (subValue) {
                            return subValue + ' (' + templateTitle + ')';
                        }
                        return templateTitle;
                    },
                    getLevelAchieved = function (category, levels, name) {
                        var levelAchieved = -1;
                        if (category === 'Achievement' && levels) {
                            levels.forEach(function (obj, ind) {
                                if (obj.Name === name) {
                                    levelAchieved = ind;
                                    return false;
                                }
                            });
                        }
                        return levelAchieved;
                    };
                return {
                    hgId: [obj.hgId],
                    batchId: obj.BatchId,
                    badgeUrl: ['/badges/group/', obj.Template.FriendlyGroupId, '/', obj.BadgeFilename].join(''),
                    teamRecognition: false,
                    isPublic: (obj.PublicCreatorInfo && obj.PublicCreatorInfo.FullName && obj.PublicCreatorInfo.FullName.length > 0),
                    recipients: [{
                        hgId: obj.RecipientMember.hgId,
                        userId: obj.RecipientMember.UserId,
                        fullName: obj.RecipientMember.FullName || [obj.RecipientMember.FirstName, ' ', obj.RecipientMember.LastName ].join('')
                    }],
                    issuer: getIssuer(),
                    comments: [],
                    ShareCount: obj.ShareCount,
                    commentCount: obj.CommentCount,
                    congratsCount: obj.CongratsCount,
                    message: obj.Message,
                    messageEdited: obj.MessageEdited,
                    congratMemberIds: Extend.extend([], obj.CongratMemberIds),
                    isCongrats: obj.MeCongrated,
                    creditValue: obj.Template.CreditValue,
                    pointValue: obj.Template.PointValue,
                    gifts: obj.Gifts,
                    actualCreditValue: obj.ActualCreditValue,
                    actualPointValue: obj.ActualPointValue,
                    type: obj.Template.Type,
                    title: getTitle(obj.Template.Title, obj.SubValue),
                    description: obj.Template.Description,
                    createdDate: obj.CreatedDate,
                    modifiedDate: obj.ModifiedDate,
                    suppressInFeed: obj.SuppressInFeed,
                    sticky : obj.Sticky || false,
                    onTop : shouldStickOnTop(),
                    category: obj.Template.Category,
                    levels : obj.Template.Levels || [],
                    levelAchieved: getLevelAchieved(obj.Template.Category, obj.Template.Levels, obj.LevelName)
                };
            },
            getStartDate = function (limitPeriod) {
                var curDate = new Date(),
                    monthNum,
                    sDate;
                switch (limitPeriod) {
                case 'Day':
                    sDate = new Date(curDate.getUTCFullYear(), curDate.getUTCMonth(), curDate.getUTCDate()).getTime();
                    break;
                case 'Week':
                    sDate = new Date(curDate.setDate(curDate.getDate() - curDate.getDay())).getTime();
                    break;
                case 'Month':
                    sDate = new Date(curDate.getUTCFullYear(), curDate.getUTCMonth(), 1).getTime();
                    break;
                case 'Quarter':
                    monthNum = Math.floor(curDate.getMonth() / 3) * 3;
                    sDate = new Date(curDate.getUTCFullYear(), monthNum, 1).getTime();
                    break;
                case 'Year':
                    sDate = new Date(curDate.getUTCFullYear(), 0, 1).getTime();
                    break;
                default:
                    sDate = new Date(curDate.getUTCFullYear(), curDate.getUTCMonth(), curDate.getUTCDate()).getTime();
                    break;
                }
                return sDate;
            },
            changeProtocol = function (msg) {
                if (config.protocol === 'http:') {
                    msg = msg.replace(/https:/g, config.protocol);
                } else {
                    msg = msg.replace(/http:/g, config.protocol);
                }
                return msg;
            };

        this.DefaultEntityName = 'Recognition';

        this.SaveRecognitionRequest = function (params, callback) {
            var recognitionRequest = new EntityCache.RecognitionRequest(params.RecognitionRequest);
            recognitionRequest.hgId = guid.v1();
            recognitionRequest.CreatedBy = params.UserId;
            recognitionRequest.ModifiedBy = params.UserId;
            recognitionRequest.RequesterRole = params.RoleInGroup;
            recognitionRequest.save(callback);
        };

        this.GetRecognitionRequestById = function (params, callback) {
            EntityCache.RecognitionRequest.findOne({
                hgId: params.RequestId
            }, callback);
        };

        this.GetReceivedRecognitions = function (params, callback) {
            var memberId = params.MemberId,
                mquery,
                Types = params.Types,
                recognitionFeeds = [],
                filteredRecognitions;
            function executeQuery(query) {
                EntityCache.Recognition.find(query, null, { sort: { ModifiedDate: -1} }, function (err, recognitions) {
                    if (err) {
                        callback(HgError.Enums.Recognition.ErrorLoading);
                    } else {
                        filteredRecognitions = recognitions.filter(function (recognition) {
                            var title = recognition.Template.Title.toLowerCase();
                            return title.indexOf('welcome') === -1 && title.indexOf('birthday') === -1 && title.indexOf('anniversary') === -1;
                        });
                        recognitionHelper.getUniqueTemplates(filteredRecognitions, Types, function (data) {
                            recognitionFeeds = data;
                            callback(null, { feedCount : recognitionFeeds.length, feeds : recognitionFeeds});
                        });
                    }
                });
            }
            mquery = EntityCache.Recognition.find({});
            mquery.where('Status').equals(RecognitionEnums.Status.Active);
            mquery.where('RecipientMember.hgId').equals(memberId);
            mquery.where('Template.Publicity').in(['Public', 'Both']);
            mquery.where('PublicCreatorInfo.FullName').ne('HighGround').ne('');
            mquery.where('CreatorMember.hgId').equals('');
            mquery.where('Template.Type').in(Types);
            executeQuery(mquery._conditions);
        };
        this.ResolveLevelAvailability = function (params) {
            var level = params.Level,
                userId = params.UserId,
                roleInGroup = params.RoleInGroup,
                limitNumber = 0,
                callback = params.Callback,
                startDate,
                i,
                condition = {CreatedBy : userId, 'Template.Category' : 'Values'};
            if (level.Name === "Default") {
                limitNumber = level.LimitNumber;
                condition.LevelName = {$in : ['', 'Default']};
            } else {
                for (i = 0; i < level.AvailabilityToRoles.length; i += 1) {
                    if (level.AvailabilityToRoles[i].RoleName === roleInGroup && level.AvailabilityToRoles[i].Allowed === true) {
                        limitNumber = level.AvailabilityToRoles[i].LimitNumber;
                    }
                }
                condition.LevelName = level.Name;
            }
            startDate = getStartDate(level.LimitPeriod);
            condition.CreatedDate = {$gt : startDate};

            EntityCache.Recognition.count(condition, function (err, count) {
                if (err) {
                    callback(err);
                    return;
                }
                level.RemainingToMe = limitNumber - count;
                if (level.RemainingToMe < 0) {
                    level.RemainingToMe = 0;
                }

                callback(null);
            });
        };
        this.IsLevelAvailable = function (params) {
            var level = params.Level,
                userId = params.UserId,
                roleInGroup = params.RoleInGroup,
                limitNumber = 0,
                callback = params.Callback,
                startDate,
                i,
                condition = {CreatedBy : userId, 'Template.Category' : 'Values'};
            if (level.Name === "Default") {
                limitNumber = level.LimitNumber;
                condition.LevelName = {$in : ['', 'Default']};
            } else {
                for (i = 0; i < level.AvailabilityToRoles.length; i += 1) {
                    if (level.AvailabilityToRoles[i].RoleName === roleInGroup && level.AvailabilityToRoles[i].Allowed === true) {
                        limitNumber = level.AvailabilityToRoles[i].LimitNumber;
                    }
                }
                condition.LevelName = level.Name;
            }
            startDate = getStartDate(level.LimitPeriod);
            condition.CreatedDate = {$gt : startDate};
            EntityCache.Recognition.count(condition, function (err, count) {
                var errorMessage = 'There aren\'t enough recognitions to go around! You selected more people than available recognitions at the level you chose ';
                if (err) {
                    callback(err);
                    return;
                }
                level.RemainingToMe = limitNumber - count;
                if (level.RemainingToMe < 0) {
                    level.RemainingToMe = 0;
                }
                if (level.RemainingToMe >= params.RequestedNumber) {
                    callback(null, true);
                } else {
                    errorMessage += 'for the ' + level.LimitPeriod;
                    callback(errorMessage, false);
                }
            });
        };

        this.RemoveVisibilityByGoalIdAndMember = function (params, callback) {
            EntityCache.Recognition.update({
                GoalId: params.GoalId
            }, {
                $pull: {
                    VisibilityMemberIds: params.MemberId
                }
            }, {
                multi: true
            }, callback);
        };

        this.Congrat = function (params, callback) {
            Async.parallel({
                updateRecongnition: function (fcallback) {
                    EntityCache.Recognition.update({
                        hgId: {$in: params.RecognitionIds},
                        CongratMemberIds: {$nin: [params.MemberId]},
                    }, {
                        $inc: {CongratsCount: 1},
                        $push: {CongratMemberIds: params.MemberId}
                    }, {
                        multi: true
                    }, function (error) {
                        if (error) {
                            return fcallback('business.rec.pro.erc');
                        }
                        fcallback();
                    });
                },
                createCongrats: function (fcallback) {
                    EntityCache.Recognition.find({
                        hgId: {$in: params.RecognitionIds}
                    }, function (error, recognitions) {
                        if (error || !recognitions.length) {
                            return fcallback('business.rec.pro.elr');
                        }
                        var congrat = EntityCache.Congrat({
                            hgId: guid.v1(),
                            RecognitionIds: params.RecognitionIds,
                            MemberId: params.MemberId,
                            GroupId: recognitions[0].Template.GroupId,
                            CreatedBy: params.UserId,
                            ModifiedBy: params.UserId,
                            GroupName: recognitions[0].Template.GroupName,
                            Source: params.Source
                        });
                        congrat.save();
                        fcallback(null, recognitions);
                    });
                }
            }, function (error, results) {
                if (error) {
                    return callback(error);
                }
                callback(null, results.createCongrats);
            });
        };
        this.DismissRecognition = function (params, callback) {
            EntityCache.Recognition.update({
                hgId: params.RecognitionId,
                DismissMemberIds: {$nin: [params.MemberI]}
            }, {
                $addToSet: {DismissMemberIds: params.MemberId}
            }, {
                multi: true
            }, function (err) {
                if (err) {
                    return callback('business.rec.pro.eur');
                }
                callback(null, 'business.rec.pro.idf');
            });
        };
        this.BatchCongrat = function (params, callback) {
            EntityCache.Recognition.update({
                BatchId: params.BatchId,
                CongratMemberIds: {$nin: [params.MemberId]}
            }, {
                $inc: {CongratsCount: 1},
                $push: {CongratMemberIds: params.MemberId}
            }, {
                multi: true
            }, function (err) {
                if (err) {
                    return callback('business.rec.pro.erc');
                }
                EntityCache.Recognition.find({BatchId: params.BatchId}, function (error, recognitions) {
                    if (error || !recognitions.length) {
                        return callback('business.rec.pro.elr');
                    }
                    var congrat = EntityCache.Congrat({
                        hgId: guid.v1(),
                        RecognitionIds: recognitions.map(function (item) { return item.hgId; }),
                        MemberId: params.MemberId,
                        GroupId: recognitions[0].Template.GroupId,
                        CreatedBy: params.UserId,
                        ModifiedBy: params.UserId,
                        GroupName: recognitions[0].Template.GroupName,
                        Source: params.Source
                    });
                    congrat.save(function (error) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, recognitions);
                    });
                });
            });
        };
        this.GetStickies = function (params, callback) {
            EntityCache.Recognition.find({
                'Template.GroupId': params.GroupId,
                'Template.Type': RecognitionEnums.Type.Newsfeed,
                Sticky: true,
                Status: RecognitionEnums.Status.Active,
                DismissMemberIds: {$ne: params.MemberId}
            }, null, {
                sort: {
                    CreatedDate: -1
                }
            }, function (error, recognitions) {
                if (error) {
                    return callback(error);
                }
                callback(null, recognitions.map(function (item) {
                    return getRecognitionFeed(item);
                }));
            });
        };

        this.GetRecognitionsReceivedByMemberId = function (params, callback) {
            var query = {
                'RecipientMember.hgId': params.MemberId,
                'RecipientMember.GroupId': params.GroupId,
                'Template.Type': { $in: templateTypes.MineOnly},
                Status: RecognitionEnums.Status.Active
            };
            if (params.StartDate && params.EndDate) {
                query.CreatedDate = {$gte: params.StartDate, $lte: params.EndDate};
            }
            feedQueryProcessor.processQuery({
                Query: query,
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0,
                UserId: params.UserId
            }, callback);
        };
        this.GetRecognitions = function (params, callback) {
            var Skip = parseInt(params.Skip, 10) || 0,
                Take = parseInt(params.Take, 10) || 0,
                memberId = params.MemberId,
                viewerMemberId = params.ViewerMemberId || memberId,
                groupId = params.GroupId,
                mquery,
                MembershipStatus = params.MembershipStatus,
                searchTerm = params.SearchTerm || "",
                Types = params.Types,
                showPointsInFeed = (params.ShowPointsInFeed === undefined) ? true : params.ShowPointsInFeed,
                regex = new RegExp(searchTerm.replace(/([.*?=+&#!:${}()|\[\]\/\\\^\+])/g, "\\$1"), "i"),
                locCondition,
                memberVisibilityCondtion = [
                    {VisibilityMemberIds: null},
                    {VisibilityMemberIds: {$in: [viewerMemberId]}}
                ];
            if (params.LocationId) {
                locCondition = [
                    {"VisibilityLocations.hgId": null},
                    {"VisibilityLocations.hgId": {$in: [params.LocationId]}}
                ];
            }
            mquery = EntityCache.Recognition.find({Status: RecognitionEnums.Status.Active});
            if (searchTerm) {
                mquery.or([
                    {Message: regex},
                    {'Template.Title': regex},
                    {'PublicCreatorInfo.FullName': regex},
                    {'PublicCreatorInfo.CompanyName': regex},
                    {'RecipientMember.FullName': regex},
                    {'PublicCreatorInfo.Email': regex}
                ]);
            }
            switch (params.GetType) {
            case 'MineOnly':
                mquery.where('RandCId').in([memberId]);
                mquery.where('Template.Type').in(templateTypes.MineOnly);
                if (memberId !== params.CurrentUserMemberId && !params.ICanSeePrivateBadge) {
                    mquery.where('SuppressInFeed', false);
                    mquery.where('Template.AccessLevel').in([
                        RecognitionEnums.AccessLevel.WithinTeam,
                        RecognitionEnums.AccessLevel.WithinGroup
                    ]);
                }
                feedQueryProcessor.processQuery({
                    Query: mquery._conditions,
                    Skip: Skip,
                    Take: Take,
                    ViewerMemberId: viewerMemberId,
                    ApplymarkRecognitionsCongratByMe: true,
                    ShowPointsInFeed: showPointsInFeed,
                    VieweeMemberId: params.VieweeMemberId,
                    UserId: params.UserId
                }, callback);
                break;
            case 'CurrentGroup':
                mquery.where('SuppressInFeed', false);
                mquery.where('Template.Type').in(templateTypes.CurrentGroup);
                if (MembershipStatus === MemberEnums.Status.Active) {
                    mquery.where('Template.GroupId').equals(groupId);
                } else {
                    mquery.where('RecipientMember.hgId').equals(memberId);
                }
                feedQueryProcessor.processQuery({
                    Query: mquery._conditions,
                    RelevantMemberIds: params.RelevantMemberIds,
                    LocCondition: locCondition,
                    MemberVisibilityCondtion: memberVisibilityCondtion,
                    Skip: Skip,
                    Take: Take,
                    ViewerMemberId: viewerMemberId,
                    ApplymarkRecognitionsCongratByMe : true,
                    ShowPointsInFeed: showPointsInFeed,
                    VieweeMemberId: params.VieweeMemberId,
                    UserId: params.UserId
                }, callback);
                break;
            case 'Team':
                EntityCache.Recognition.aggregate(
                    [
                        {$match: {'RecipientMember.GroupDepartmentId': {$in: params.DepartmentIds}}},
                        {$group: { _id: "$BatchId", count: { $sum: 1 }}}
                    ],
                    function (err, recognitions) {
                        var i, batchIds = [];
                        for (i = 0; i < recognitions.length; i += 1) {
                            batchIds.push(recognitions[i]._id);
                        }
                        mquery.where('BatchId').in(batchIds);
                        mquery.where('Template.Type').in(templateTypes.Team);
                        mquery.where('SuppressInFeed', false);
                        feedQueryProcessor.processQuery({
                            Query: mquery._conditions,
                            Skip: Skip,
                            Take: Take,
                            ViewerMemberId: viewerMemberId,
                            ShowPointsInFeed: showPointsInFeed,
                            ApplymarkRecognitionsCongratByMe: true,
                            VieweeMemberId: params.VieweeMemberId,
                            UserId: params.UserId
                        }, callback);
                    }
                );
                break;
            case 'Location': // This is for bookmarkedTeam.Type === 'Location'
                mquery.where('Template.Type').in(templateTypes.Team);
                mquery.where('SuppressInFeed', false);
                mquery.where('RecipientMember.Location.hgId').equals(params.TeamLocationId);
                feedQueryProcessor.processQuery({
                    Query: mquery._conditions,
                    Skip: Skip,
                    Take: Take,
                    ViewerMemberId: viewerMemberId,
                    ShowPointsInFeed: showPointsInFeed,
                    ApplymarkRecognitionsCongratByMe: true,
                    VieweeMemberId: params.VieweeMemberId,
                    UserId: params.UserId
                }, callback);
                break;
            case 'Public':
                mquery.where('RecipientMember.hgId').equals(memberId);
                mquery.where('Template.Publicity').in(['Public', 'Both']);
                mquery.where('PublicCreatorInfo.FullName').ne('HighGround').ne('');
                mquery.where('CreatorMember.hgId').equals('');
                mquery.where('Template.Type').in(Types);
                feedQueryProcessor.processQuery({
                    Query: mquery._conditions,
                    Skip: Skip,
                    Take: Take,
                    ViewerMemberId: viewerMemberId,
                    ApplymarkRecognitionsCongratByMe: false,
                    VieweeMemberId: params.VieweeMemberId,
                    UserId: params.UserId
                }, callback);
                break;
            case 'AdvancedSearch':
                mquery.where('Template.GroupId', groupId);
                mquery.where('SuppressInFeed', false);
                //Note to Review Template.Type filter, in most cases we are only filtering 1 item from the list
                //Need to go back and look at why. I think the  extra filter can be removed and only needed in a few cases.
                if (params.RecognitionSource === 'External') {
                    mquery.exists('PublicCreatorInfo.FullName', true);
                    mquery.where('Template.Type').in(templateTypes.External);
                    mquery.where('Template.Category').in([
                        RecognitionEnums.RecognitionCategory.Everyday,
                        RecognitionEnums.RecognitionCategory.Achievement,
                        RecognitionEnums.RecognitionCategory.Values
                    ]);
                } else if (params.RecognitionSource === 'Internal') {
                    mquery.exists('PublicCreatorInfo.FullName', false);
                }
                if (params.SearchMemberIds.length) {
                    mquery.where('RecipientMember.hgId').in(params.SearchMemberIds);
                }
                if (params.DepartmentIds.length) {
                    mquery.where('RecipientMember.GroupDepartmentId').in(params.DepartmentIds);
                }
                if (params.LocationIds.length) {
                    mquery.where('RecipientMember.Location.hgId').in(params.LocationIds);
                }
                if (!params.TeamOrDepartmentMembers.length) {
                    feedQueryProcessor.processQuery({
                        Query: mquery._conditions,
                        RelevantMemberIds: params.RelevantMemberIds,
                        LocCondition: locCondition,
                        MemberVisibilityCondtion: memberVisibilityCondtion,
                        Skip: Skip,
                        Take: Take,
                        ViewerMemberId: viewerMemberId,
                        ShowPointsInFeed: showPointsInFeed,
                        ApplymarkRecognitionsCongratByMe: true,
                        VieweeMemberId: params.VieweeMemberId,
                        UserId: params.UserId
                    }, callback);
                } else {
                    EntityCache.Recognition.aggregate(
                        [
                            {$match: {'RecipientMember.hgId': {$in: params.TeamOrDepartmentMembers}}},
                            {$group: { _id: "$BatchId", count: { $sum: 1 }}}
                        ],
                        function (err, recognitions) {
                            var i, len = recognitions.length, batchIds = [];
                            for (i = 0; i < len; i += 1) {
                                batchIds.push(recognitions[i]._id);
                            }
                            mquery.where('BatchId').in(batchIds);
                            feedQueryProcessor.processQuery({
                                Query: mquery._conditions,
                                Skip: Skip,
                                Take: Take,
                                ViewerMemberId: viewerMemberId,
                                ShowPointsInFeed: showPointsInFeed,
                                ApplymarkRecognitionsCongratByMe: true,
                                VieweeMemberId: params.VieweeMemberId,
                                UserId: params.UserId
                            }, callback);
                        }
                    );
                }
                break;
            }
        };

        this.GetRecognitionsByDateRangeAndFilter = function (params, callback) {
            var queryObject = {
                    Status: RecognitionEnums.Status.Active,
                    'RecipientMember.hgId': params.RecipientMemberId,
                    'Template.Type': {
                        $in: templateTypes.AllExceptNewsProductPoll
                    },
                    Message: {
                        $ne: "This track has been completed."
                    },
                    CreatedDate: {
                        $gt: params.StartDate,
                        $lt: params.EndDate
                    }
                },
                categoryArray = [];
            if (params.Filter.indexOf('EverydayInternal') > -1 || params.Filter.indexOf('EverydayExternal') > -1) {
                categoryArray.push('Everyday');
                if (params.Filter.indexOf('EverydayInternal') === -1) {
                    queryObject['PublicCreatorInfo.FullName'] = {$nin : ['', 'HighGround']};
                }
                if (params.Filter.indexOf('EverydayExternal') === -1) {
                    queryObject.PublicCreatorInfo = {$exists: false};
                }
            }
            if (params.Filter.indexOf('Values') > -1) {
                categoryArray.push('Values');
            }
            if (params.Filter.indexOf('Achievement') > -1) {
                categoryArray.push('Achievement');
            }
            queryObject['Template.Category'] = {$in: categoryArray};
            EntityCache.Recognition.find(queryObject, null,  { sort: { ModifiedDate: -1} }, callback);
        };

        this.AddGiftToRecognition = function (params, callback) {
            var query = !params.RecognitionId ? {BatchId: params.BatchId} : {hgId: params.RecognitionId};
            EntityCache.Recognition.update(query, {
                $push: {Gifts: params.gift}
            }, {multi: true}, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, 'msg.rec.gadd');
            });
        };
        this.AddPointsToRecognitions = function (params, callback) {
            EntityCache.Recognition.update(
                {hgId: {$in: params.RecognitionIds}},
                {$inc: {ActualPointValue: params.Points}},
                {multi: true},
                function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, 'msg.rec.padd');
                }
            );
        };
        this.DeleteGift = function (params, callback) {
            EntityCache.Recognition.update({
                'Template.GroupId': params.GroupId,
                $or: [{hgId: params.RecognitionId}, {BatchId: params.RecognitionId}],
                'Gifts.OrderIds': { $in: params.OrderIds }
            }, {
                $pull: {Gifts: { OrderIds: { $in: params.OrderIds }}}
            }, {
                multi: true
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, 'msg.rec.gdel');
            });
        };
        this.DeleteGiftByCancelOrder = function (params, callback) {
            var query = {
                'Template.GroupId': params.GroupId,
                'RecipientMember.hgId': params.RecipientId,
                'Gifts.OrderIds': { $in: [params.OrderId] }
            };
            EntityCache.Recognition.findOne(query, function (error, recognition) {
                if (error) {
                    return callback(error);
                }
                if (!recognition) {
                    return callback(null, 'msg.rec.nfd');
                }
                EntityCache.Recognition.update(query, {
                    $pull: {Gifts: { OrderIds: { $in: [params.OrderId] }}}
                }, function (updateErr) {
                    if (updateErr) {
                        return callback(updateErr);
                    }
                    callback(null, 'msg.rec.gdel');
                });
            });
        };
        this.SaveRecognitionAsync = function (recognition, callback) {
            var onRecognitionSave = function (err) {
                //need to update careertrack here.
                // also, need to increment the counter. when counter === params.Templates.length; * params.RecipientMemberIds.length, emit the event
                if (err) {
                    callback(err);
                } else {
                    callback(null);
                }
            };
            recognition.CreatorMember = new FeedMember(recognition.CreatorMember);
            recognition.RecipientMember = new FeedMember(recognition.RecipientMember);
            recognition.RandCId = [recognition.RecipientMember.hgId];
            if (recognition.CreatorMember && recognition.CreatorMember.hgId) {
                recognition.RandCId.push(recognition.CreatorMember.hgId);
            }
            recognition.save(onRecognitionSave);
        };

        this.UpdateAutoRecognition = function (params, callback) {
            EntityCache.Recognition.findOneAndUpdate({
                ItemId: params.ItemId,
                'Template.GroupId': params.GroupId
            }, {
                $set: {
                    Message: params.Message,
                    'Template.Title': params.Title,
                    'Template.Description': params.Title
                }
            }, {
                new: true
            }, callback);
        };

        this.CreateAutoRecognition = function (params, callback) {
            var RecognitionTemplate = EntityCache.RecognitionTemplate,
                recipientMember = params.RecipientMember,
                group = params.Group,
                badge = params.Badge,
                recognition = EntityCache.Recognition();
            if (!params.Template) {
                params.Template = new RecognitionTemplate({
                    hgId: params.DefaultBadge ? params.DefaultBadge.Id : guid.v1(),
                    Publicity: RecognitionEnums.Publicity.Public,
                    Type: params.Type || RecognitionEnums.Type.Recognition,
                    GroupId: recipientMember.GroupId,
                    GroupName: recipientMember.GroupName,
                    FriendlyGroupId: group.FriendlyGroupId,
                    Description: params.Description || params.Title,
                    Title: params.Title,
                    Category: params.Category || RecognitionEnums.RecognitionCategory.Everyday,
                    SubCategory: params.SubCategory || RecognitionEnums.RecognitionSubCategory.Default,
                    Message: params.Message
                });
                if (!params.DefaultBadge && badge) {
                    FileHelper.CopyBadgeImage({
                        BadgeId: badge.hgId,
                        FriendlyGroupId: group.FriendlyGroupId,
                        TemplateId: params.Template.hgId
                    });
                }
            } else {
                params.Template.Type = params.Type || RecognitionEnums.Type.Recognition;
                if (params.Title) {
                    params.Template.Title = params.Title;
                }
                if (params.Description) {
                    params.Template.Description = params.Description;
                }
                if (params.Category) {
                    params.Template.Category = params.Category;
                }
                if (params.SubCategory) {
                    params.Template.SubCategory = params.SubCategory;
                }
                if (params.Message) {
                    params.Template.Message = params.Message;
                }
            }
            recognition.hgId = guid.v1();
            recognition.SuppressInFeed = (params.SuppressInFeed !== undefined) ? params.SuppressInFeed : false;
            recognition.BatchId = guid.v1();
            recognition.Template = params.Template;
            recognition.BadgeFilename = params.Template.hgId;
            recognition.ItemId = params.ItemId;
            recognition.CreatedBy = config.HighgroundGlobalUserId;
            recognition.ModifiedBy = config.HighgroundGlobalUserId;
            recognition.Message = params.Template.Message ? changeProtocol(params.Template.Message) : '';
            recognition.RecipientMember = new FeedMember(recipientMember);
            recognition.RandCId = [recognition.RecipientMember.hgId];
            recognition.PublicCreatorInfo.FullName = group.ProgramName || group.GroupName;
            recognition.PublicCreatorInfo.Email = '';
            recognition.PublicCreatorInfo.CompanyName = '';
            recognition.NewsId = params.NewsId;
            recognition.Sticky = params.Sticky;
            recognition.GoalId = params.GoalId;
            recognition.KrUpdates = params.KrUpdates;
            recognition.PollQuestionId = params.PollQuestionId;
            recognition.ExpireDate = params.ExpireDate;
            if (params.PollResult) {
                recognition.PollResult = params.PollResult;
            }
            if (params.Visibility) {
                if (params.Visibility.RestrictByLocation) {
                    recognition.VisibilityLocations = params.Visibility.Locations;
                }
                if (params.Visibility.RestrictByMember) {
                    recognition.VisibilityMemberIds = params.Visibility.MemberIds;
                }
            }
            recognition.save(function (error) {
                callback(error, [recognition]);
            });
        };
        this.EnforceStickyLimit = function (params, callback) {
            var mquery = EntityCache.Recognition.find({'Template.Type' : 'Newsfeed', Sticky : true, 'Template.GroupId' : params.GroupId}),
                unpinningIds = [],
                i;
            mquery.sort({CreatedDate : -1}).exec(function (error, stickies) {
                if (error) {
                    callback(error, null);
                } else if (!stickies || stickies.length <= 3) {
                    callback(null, unpinningIds);
                } else {
                    for (i = 3; i < stickies.length; i += 1) {
                        unpinningIds.push(stickies[i].hgId);
                    }
                    EntityCache.Recognition.update({hgId : {$in : unpinningIds}}, {$set : {Sticky : false}}, {multi : true}, function (error) {
                        callback(error, unpinningIds);
                    });
                }
            });
        };

        this.CreatePublicRecognitions = function (params, callback) {
            var recognitions = [],
                i,
                j,
                pusherParams,
                template = params.Templates[i],
                memberId = params.RecipientMemberIds[j],
                userId = params.RecipientUserIds[j],
                recipientMembers = params.RecipientMembers,
                recognition,
                batchId,
                ilen = params.Templates.length,
                jlen = params.RecipientMemberIds.length;

            for (i = 0; i < ilen; i += 1) {
                batchId = guid.v1();
                for (j = 0; j < jlen; j += 1) {
                    template = params.Templates[i];
                    memberId = params.RecipientMemberIds[j];
                    userId = params.RecipientUserIds[j];
                    recognition = EntityCache.Recognition();
                    recognition.hgId = guid.v1();
                    recognition.BatchId = batchId;
                    recognition.Template = template || {};
                    recognition.BadgeFilename = template ? template.hgId : '';
                    recognition.CreatedBy = params.UserId;
                    recognition.Gifts = [];
                    recognition.ModifiedBy = params.UserId;
                    recognition.Message = params.Message;
                    recognition.CannedMessage = params.CannedMessage;
                    recognition.CompanyRating = params.CompanyRating;
                    recognition.MemberRating = params.MemberRating;
                    recognition.RecipientMember = recipientMembers[j];
                    recognition.PublicCreatorInfo.FullName = params.FullName;
                    recognition.PublicCreatorInfo.Email = params.Email;
                    recognition.PublicCreatorInfo.CompanyName = params.CompanyName;
                    recognition.ExpireDate = params.ExpireDate;
                    recognition.SuppressInFeed = params.SuppressInFeed;
                    recognitions.push(recognition);

                    //This pusher code should be moved into the SaveRecognitionAsync function. -Demetri
                    pusherParams = {
                        correlationId: params.correlationId,
                        GroupId: recipientMembers[j].GroupId,
                        UserId: userId,
                        MemberId: memberId,
                        Recognition: recognition,
                        Channel: 'Private'
                    };
                    PusherManager.RecognitionCreated(pusherParams);
                }
            }
            if (recipientMembers && recipientMembers.length > 0 && recognition.MemberRating > 6) {
                pusherParams = {
                    correlationId: params.correlationId,
                    GroupId: recipientMembers[0].GroupId,
                    UserId: userId,
                    MemberId: memberId,
                    Recognition: recognition,
                    Channel:  params.SuppressInFeed ? 'Private' : 'Public'
                };
                PusherManager.RecognitionCreated(pusherParams);
            }

            Async.each(recognitions, this.SaveRecognitionAsync, function (err) {
                if (err) {
                    return callback(err);
                }
                callback(null, recognitions);
            });
        };

        this.CreateRecognitions = function (params, callback) {
            var SaveRecognitionAsync = this.SaveRecognitionAsync;
            function saveRecognitions(recognitions, pusherCallback) {
                Async.each(recognitions, SaveRecognitionAsync, function (err) {
                    if (err) {
                        if (callback) {
                            callback(err, null);
                        } else {
                            EventResponder.RespondWithError(EventEmitterCache, params, err);
                        }
                    } else {
                        if (pusherCallback) {
                            pusherCallback();
                        }
                        if (callback) {
                            callback(null, recognitions);
                        } else {
                            EventResponder.RespondWithData(EventEmitterCache, params, recognitions);
                        }
                    }
                });
            }

            function createTemplates() {
                var i,
                    j,
                    template,
                    memberId,
                    userId,
                    recognitions = [],
                    recipientMembers = params.RecipientMembers,
                    IssuerMember = params.IssuerMember,
                    recognition,
                    templateCount = 0,
                    expectedCount = params.Templates.length * params.RecipientMembers.length,
                    batchId,
                    ilen,
                    jlen;

                function sendPusherMessage() {
                    PusherManager.RecognitionCreated({
                        correlationId: params.correlationId,
                        GroupId: params.GroupId,
                        UserId: userId,
                        MemberId: memberId,
                        Recognition: recognition,
                        Channel: 'Private'
                    });
                    if (recognitions.length && !recognitions[0].SuppressInFeed && recognitions[0].Template.SubCategory !== 'TrackCompletion') {
                        PusherManager.RecognitionCreated({
                            correlationId: params.correlationId,
                            GroupId: params.GroupId,
                            UserId: recognition.RecipientMember.UserId,
                            MemberId: recognition.RecipientMember.hgId,
                            Recognition: recognition,
                            Channel: 'Public'
                        });
                    }
                }

                for (i = 0, ilen = params.Templates.length; i < ilen; i += 1) {
                    batchId = guid.v1();
                    for (j = 0, jlen = params.RecipientMembers.length; j < jlen; j += 1) {
                        template = params.Templates[i];
                        memberId = params.RecipientMembers[j].hgId;
                        userId = params.RecipientMembers[j].UserId;
                        recognition = EntityCache.Recognition();
                        recognition.hgId = guid.v1();
                        recognition.BatchId = batchId;
                        recognition.Template = template;
                        recognition.BadgeFilename = template.hgId;
                        if (recognition.Template.Category === 'Values' && params.RecognitionRequest) {
                            recognition.LevelName = params.RecognitionRequest.Level;
                            recognition.SubValue = params.RecognitionRequest.SubValue || '';
                            if (params.RecognitionRequest.ImageId) {
                                recognition.BadgeFilename = params.RecognitionRequest.ImageId;
                            }
                            if (recognition.LevelName && recognition.LevelName !== 'Default') {
                                recognition.BadgeFilename += '_' + recognition.LevelName;
                            } else if (recognition.Template.BackgroundBadgeId && recognition.Template.SubValues && recognition.Template.SubValues.length > 0) {
                                recognition.BadgeFilename += '_' + recognition.Template.BackgroundBadgeId;
                            }
                        }
                        if (recognition.Template.Category === 'Achievement' && params.RecognitionRequest) {
                            recognition.LevelName = params.RecognitionRequest.Level;
                        }
                        recognition.CreatedBy = params.UserId;
                        recognition.ModifiedBy = params.UserId;
                        recognition.Message = params.Message;
                        recognition.RecipientMember = recipientMembers[j];
                        recognition.CreatorMember = IssuerMember;
                        recognition.SuppressInFeed = params.SuppressInFeed;
                        recognition.ActualCreditValue =
                            params.RecipientMembers[j].RolesInGroup[0] === EntityEnums.MembersRoleInGroup.Consultant ? 0 : params.ActualCreditValue;
                        recognition.ActualPointValue =
                            params.RecipientMembers[j].RolesInGroup[0] === EntityEnums.MembersRoleInGroup.Consultant ? 0 : params.ActualPointValue;
                        recognition.Source = params.RecognitionRequest ? params.RecognitionRequest.Source : 'Web';
                        recognition.ExpireDate = params.ExpireData;
                        if (params.Rule) {
                            recognition.TriggerInfo = {
                                GroupName: params.Group.ProgramName || params.Group.GroupName,
                                AvatarId: params.Group.hgId,
                                RuleName: params.Rule.RuleName,
                                RuleId: params.Rule.hgId
                            };
                        }
                        templateCount += 1;
                        recognitions.push(recognition);
                        if (expectedCount === templateCount) {
                            saveRecognitions(recognitions, sendPusherMessage);
                        }
                    }
                }
            }
            if (!params.AdditionalCreditValue) {
                params.AdditionalCreditValue = 0;
            }
            if (!params.AdditionalPointValue) {
                params.AdditionalPointValue = 0;
            }
            createTemplates();
        };

        this.GetRecognitionByOrderNumber = function (params, callback) {
            var mquery = EntityCache.Recognition.find({
                Status: RecognitionEnums.Status.Active,
                'Template.Type': {$in: templateTypes.AllExceptNewsProductPoll}
            });
            mquery.sort({_id: 1}).skip(parseInt(params.OrderNumber - 1, 10) || 0).limit(1).exec(function (error, recognitions) {
                if (error || !recognitions || !recognitions.length) {
                    return callback(error);
                }
                callback(null, recognitions[0]);
            });
        };

        this.GetRecognitionByIdCallback = function (params, callback) {
            EntityCache.Recognition.findOne({hgId: params.RecognitionId}, function (error, recognition) {
                if (error || !recognition) {
                    callback('business.rec.pro.utr');
                } else if (recognition.Template.GroupId !== params.GroupId) {
                    callback(HgError.Enums.Recognition.NotAuthorizedToView);
                } else {
                    callback(null, recognition);
                }
            });
        };

        this.GetRecognitionsByBatchId = function (params, callback) {
            EntityCache.Recognition.find({
                BatchId: params.BatchId,
                "Template.GroupId": params.GroupId
            }, function (error, recognitions) {
                if (error || !recognitions.length) {
                    callback('business.rec.pro.utr');
                } else {
                    callback(null, recognitions);
                }
            });
        };

        //returns an array with one recognition or a message indicating the recognition has been deleted
        this.GetRecognitionById = function (params, callback) {
            var query;
            params.ShowPointsInFeed = (params.ShowPointsInFeed !== undefined) ? params.ShowPointsInFeed : true;
            if (params.MemberId) {
                query =  {
                    'RecipientMember.hgId': params.MemberId,
                    'Template.hgId': params.RecognitionId, // <--- does not make sense
                    Status: RecognitionEnums.Status.Active
                };
            } else {
                query = {
                    BatchId: params.RecognitionId,
                    Status: RecognitionEnums.Status.Active
                };
            }
            query['Template.GroupId'] = params.GroupId;
            feedQueryProcessor.processQuery({
                Query: query,
                Skip: 0,
                Take: 1,
                ViewerMemberId: params.ViewerMemberId,
                ApplymarkRecognitionsCongratByMe: true,
                ShowPointsInFeed: params.ShowPointsInFeed,
                VieweeMemberId: params.VieweeMemberId,
                UserId: params.UserId
            }, function (error, recognitions) {
                if (error) {
                    return callback(error);
                }
                recognitions = recognitions.feeds;
                if (recognitions && recognitions.length) {
                    return callback(null, recognitions[0]);
                }
                feedQueryProcessor.processQuery({
                    Query: {
                        hgId: params.RecognitionId,
                        Status: RecognitionEnums.Status.Active
                    },
                    Skip: 0,
                    Take: 1,
                    ViewerMemberId: params.ViewerMemberId,
                    ApplymarkRecognitionsCongratByMe: true,
                    ShowPointsInFeed: params.ShowPointsInFeed,
                    VieweeMemberId: params.VieweeMemberId,
                    UserId: params.UserId
                }, function (error, recognitions) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, recognitions.feeds[0]);
                });
            });
        };

        this.GetRecognitionsByBatchIds = function (params, callback) {
            EntityCache.Recognition.find({BatchId: params.BatchId}, callback);
        };

        this.GetRecognitionByBatchIdsAndMemberID = function (params, callback) {
            EntityCache.Recognition.findOne({
                BatchId: params.BatchId,
                "RecipientMember.hgId": params.RecipientMemberId,
                Status: RecognitionEnums.Status.Active,
                'Template.Type': RecognitionEnums.Type.Recognition
            }, callback);
        };

        this.LogSharing = function (params, callback) {
            EntityCache.Recognition.findOne({hgId: params.RecognitionId}, function (err, recognition) {
                if (recognition) {
                    recognition.ModifiedBy = params.UserId;
                    if (recognition.Shares) {
                        recognition.Shares.push(params.Share);
                    } else {
                        recognition.Shares = params.Share;
                    }
                    recognition.ShareCount = recognition.Shares.length;
                    recognition.save();
                }
                callback(null, params.Share);
            });
        };

        this.DeleteRecognition = function (params, callback) {
            var mquery;
            if (params.RecognitionId.length > 1) {
                mquery = {hgId: {$in: params.RecognitionId}, 'Template.GroupId': params.GroupId };
            } else {
                mquery = {hgId: params.RecognitionId[0], 'Template.GroupId': params.GroupId };
            }
            EntityCache.Recognition.update(mquery, {
                $set: {
                    Status: RecognitionEnums.Status.Deleted,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, 'msg.rec.del');
            });
        };

        this.DeleteSingleRecognition = function (params, callback) {
            // determine if recognition is not already deleted
            EntityCache.Recognition.findOne({
                BatchId: params.BatchId,
                "RecipientMember.hgId": params.RecipientMemberId,
                "Template.GroupId": params.GroupId,
                Status: {$ne: RecognitionEnums.Status.Deleted}
            }, function (error, rec) {
                if (error || !rec || !rec.hgId) {
                    return callback(error || 'err.rec.rda');
                }
                EntityCache.Recognition.update({
                    hgId: rec.hgId
                }, {
                    $set: {
                        BatchId: params.RecipientMemberId,
                        Status: RecognitionEnums.Status.Deleted,
                        ModifiedBy: params.UserId
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, 'msg.rec.del');
                });
            });
        };

        this.GetRecognitionsCountByBatchID = function (params, callback) {
            EntityCache.Recognition.count({
                BatchId: params.BatchId,
                Status: RecognitionEnums.Status.Active,
                'Template.Type': RecognitionEnums.Type.Recognition
            }, function (error, count) {
                if (error) {
                    return callback(error);
                }
                callback(null, count);
            });
        };

        this.DeleteCongrat = function (params, callback) {
            EntityCache.Congrat.update({
                RecognitionIds: {$in: params.RecognitionId}
            }, {
                $set: {
                    Status: RecognitionEnums.Status.Deleted,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, HgMessage.Enums.Congrat.SuccessDeleted);
            });
        };

        this.ExpireStickyNews = function (params, callback) {
            var query = {
                    Sticky: true,
                    ExpireDate: {$lte: Date.now()}
                };
            if (params.GroupId && params.GroupId.length) {
                query['Template.GroupId'] = params.GroupId;
            }
            EntityCache.Recognition.update(query, {
                $set: {
                    Sticky: false,
                    ExpireDate: null
                }
            }, {
                multi: true
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, HgMessage.Enums.Recognition.SuccessUnstick);
            });
        };

        this.UnstickRecognition = function (params, callback) {
            var mquery;
            if (params.RecognitionId.length) {
                mquery = {hgId: {$in: params.RecognitionId}, 'Template.GroupId': params.GroupId};
            } else {
                mquery = {hgId: params.RecognitionId[0], 'Template.GroupId': params.GroupId};
            }
            EntityCache.Recognition.update(mquery, {
                $set: {
                    Sticky: false,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, function (error) {
                if (error) {
                    return callback('server.hge.rec.ehr');
                }
                callback(null, HgMessage.Enums.Recognition.SuccessHidden);
            });
        };
        this.HideRecognition = function (params, callback) {
            var mquery;
            if (params.RecognitionId.length) {
                mquery = {hgId: {$in : params.RecognitionId}, 'Template.GroupId': params.GroupId };
            } else {
                mquery = {hgId: params.RecognitionId[0], 'Template.GroupId': params.GroupId };
            }
            EntityCache.Recognition.update(mquery, {
                $set: {
                    SuppressInFeed: true,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }, function (err) {
                if (err) {
                    return callback('server.hge.rec.ehr');
                }
                callback(null, HgMessage.Enums.Recognition.SuccessHidden);
            });
        };
        this.EditRecognitionMessage = function (params, callback) {
            EntityCache.Recognition.update({
                BatchId: params.BatchId,
                'Template.GroupId': params.GroupId
            }, {
                $set: {
                    Message: params.Message,
                    MessageEdited: true,
                    ModifiedBy: params.UserId
                }
            }, {
                multi: true
            }).exec(callback);
        };
        this.DeleteRecognitionsByNewsId = function (params, callback) {
            EntityCache.Recognition.findOne({NewsId: params.NewsId}, function (error, recognition) {
                if (error || !recognition) {
                    return callback(HgError.Enums.Recognition.ErrorLoading);
                }
                EntityCache.Recognition.remove({NewsId: params.NewsId}, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, recognition.BatchId);
                });
            });
        };
        this.GetCongratsByRecognitionId = function (params, callback) {
            EntityCache.Congrat.find({RecognitionIds: {$in: params.RecognitionId}}, callback);
        };
        this.RecognitionCommentAdded = function (params) {
            EntityCache.Recognition.update({
                BatchId: params.BatchId,
                'RecipientMember.GroupId': params.GroupId
            }, {
                $set: {
                    ModifiedDate: Date.now(),
                    ModifiedBy: params.UserId
                },
                $inc: {CommentCount: 1}
            }, {
                multi: true
            }).exec();
        };
        this.RecognitionCommentDeleted = function (params) {
            EntityCache.Recognition.update({
                'RecipientMember.GroupId': params.GroupId,
                BatchId: params.BatchId,
                CommentCount: {$gt: 0}
            }, {
                $set: {
                    ModifiedBy: params.UserId
                },
                $inc: {CommentCount: -1}
            }, {
                multi: true
            }).exec();
        };
        this.GetCongratsByGroupId = function (params, callback) {
            EntityCache.Congrat.find({GroupId: params.GroupId}, callback);
        };

        this.GetRecognitionsByGroupId = function (params, callback) {
            EntityCache.Recognition.find({'RecipientMember.GroupId': params.GroupId}, callback);
        };
        this.GetMemberRegonitionsByCategory = function (params, callback) {
            var query = {
                    'RecipientMember.hgId': params.MemberId,
                    'Template.Category': {$in: params.Category},
                    'Template.Type': RecognitionEnums.TemplateType.Recognition,
                    Status: RecognitionEnums.Status.Active
                },
                orCondition = [{
                    RandCId: params.CurrentUserMemberId
                }, {
                    SuppressInFeed: false
                }];
            if (params.IsPublic) {
                query.PublicCreatorInfo = {$exists: true};
                query['PublicCreatorInfo.FullName'] = {$ne: ''};
                if (!params.ICanSeePrivateBadge) {
                    query.$or = orCondition;
                }
            } else if (params.Category.indexOf(RecognitionEnums.RecognitionCategory.Everyday) > -1) {
                query.$and = [
                    { $or: [
                        {PublicCreatorInfo: {$exists: false}},
                        {'PublicCreatorInfo.FullName': {$eq: ''}}
                    ]}];
                if (!params.ICanSeePrivateBadge) {
                    query.$and.push({ $or: orCondition});
                }
            } else {
                if (!params.ICanSeePrivateBadge) {
                    query.$or = orCondition;
                }
            }
            EntityCache.Recognition.find(query, {
                _id: 0,
                BatchId: 1,
                hgId: 1,
                BadgeFilename: 1,
                CreatedDate: 1,
                LevelName: 1,
                CongratsCount: 1,
                SubValue: 1,
                Message: 1,
                PublicCreatorInfo: 1,
                'Template.hgId': 1,
                'Template.Title': 1,
                'Template.Description': 1,
                'Template.FriendlyGroupId': 1,
                'Template.Category': 1,
                'Template.SubValues': 1,
                'Template.Levels': 1,
                'CreatorMember.FullName': 1,
                'CreatorMember.hgId': 1,
                'CreatorMember.UserId': 1
            })
                .sort({_id: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0).exec(function (err, data) {
                    if (err) {
                        return callback(err);
                    }
                    callback(null, data.map(function (item) { return item.toObject(); }));
                });
        };
        this.GetAggrigatedRegonitionsByCategory = function (params, callback) {
            var search = {
                    'RecipientMember.hgId': params.MemberId,
                    'Status': 'Active',
                    'Template.Category': params.Category,
                    'Template.Type': 'Recognition',
                    $or: [{
                        'CreatorMember.UserId': params.UserId
                    }, {
                        'RecipientMember.UserId': params.UserId
                    }, {
                        'SuppressInFeed': false
                    }]
                };

            EntityCache.Recognition.aggregate([
                {
                    $match : search
                }, {
                    $group: {
                        _id : {
                            'hgId': '$Template.hgId',
                            'IsPublic': {
                                $cond: [ { $ifNull: [ "$PublicCreatorInfo.FullName", false ] }, true, false ]
                            }
                        },
                        'hgId': {
                            $last: '$Template.hgId'
                        },
                        Title: {
                            $last: '$Template.Title'
                        },
                        FriendlyGroupId: {
                            $last: '$Template.FriendlyGroupId'
                        },
                        'Description': {
                            $last: '$Template.Description'
                        },
                        BadgeFilename: {
                            $last: '$BadgeFilename'
                        },
                        SubValues: {
                            $last: '$Template.SubValues'
                        },
                        Levels: {
                            $last: '$Template.Levels'
                        },
                        Category: {
                            $last: '$Template.Category'
                        },
                        BadgeCount : {
                            $sum: 1
                        },
                        SubValue: {
                            $last : '$SubValue'
                        },
                        LevelNames: {
                            $push: '$LevelName'
                        },
                        LastReceived: {
                            $last: '$CreatedDate'
                        },
                        CongratsCount: {
                            $last: '$CongratsCount'
                        },
                        BatchId: {
                            $last: '$BatchId'
                        }
                    }
                }, {
                    $sort: {
                        'Template.ModifyDate': -1
                    }
                }
            ]).exec(function (err, data) {
                callback(err, data);
            });
        };
        this.GetSingleRecognitionById = function (params, callback) {
            EntityCache.Recognition.findOne({hgId: params.RecognitionId, 'Template.GroupId': params.GroupId}, callback);
        };
        this.GetMetricsRecognitionCount = function (params, callback) {
            EntityCache.Recognition.count({
                'RecipientMember.hgId': params.MemberId,
                'Template.Type': RecognitionEnums.TemplateType.Recognition,
                Status: RecognitionEnums.Status.Active,
                $or: [{
                    RandCId: params.ViewerMemberId
                }, {
                    SuppressInFeed: false
                }]
            }, callback);
        };
        this.GetMemberRecognitionCount = function (params, callback) {
            var match = {
                    'RecipientMember.hgId': params.MemberId,
                    Status: RecognitionEnums.Status.Active,
                    'Template.Category': {$in : params.Category},
                    'Template.Type': RecognitionEnums.TemplateType.Recognition
                };
            if (!params.ICanSeePrivateBadge) {
                match.$or = [{
                    RandCId: params.CurrentUserMemberId
                }, {
                    SuppressInFeed: false
                }];
            }
            EntityCache.Recognition.aggregate([
                {
                    $match : match
                }, {
                    $group: {
                        _id : {
                            Category: '$Template.Category',
                            IsPublic: {
                                $cond: [ {$and: [
                                    {$ne: ['$PublicCreatorInfo.FullName', '']},
                                    {$ifNull: ['$PublicCreatorInfo', false]},
                                ]}, true, false ]
                            }
                        },
                        Count : {
                            $sum: 1
                        }
                    }
                }, {
                    $sort: {
                        max: -1
                    }
                }
            ]).exec(callback);
        };
        this.GetGroupedRegonitions = function (params, callback) {
            var search = {
                'RecipientMember.hgId': params.MemberId,
                Status: RecognitionEnums.Status.Active,
                'Template.Category': params.Category,
                'Template.Type': 'Recognition',
                $or: [{
                    'CreatorMember.UserId': params.UserId
                }, {
                    'RecipientMember.UserId': params.UserId
                }, {
                    SuppressInFeed: false
                }]
            };

            EntityCache.Recognition.aggregate([
                {
                    $match : search
                }, {
                    $group: {
                        _id : {
                            'hgId': '$Template.hgId',
                            'IsPublic': {
                                $cond: [ { $ifNull: [ "$PublicCreatorInfo.FullName", false ] }, true, false ]
                            }
                        },
                        'hgId': {
                            $last: '$Template.hgId'
                        },
                        Title: {
                            $last: '$Template.Title'
                        },
                        FriendlyGroupId: {
                            $last: '$Template.FriendlyGroupId'
                        },
                        'Description': {
                            $last: '$Template.Description'
                        },
                        BadgeFilename: {
                            $last: '$BadgeFilename'
                        },
                        SubValues: {
                            $last: '$Template.SubValues'
                        },
                        Levels: {
                            $last: '$Template.Levels'
                        },
                        Category: {
                            $last: '$Template.Category'
                        },
                        BadgeCount : {
                            $sum: 1
                        },
                        'LevelName': {
                            $last: '$LevelName'
                        }
                    }
                }, {
                    $sort: {
                        max: -1
                    }
                }
            ]).exec(function (err, data) {
                callback(err, data);
            });
        };
        this.GetRecognitionByTemplateId = function (params, callback) {
            var query = {
                    'RecipientMember.hgId' : params.MemberId,
                    'Template.hgId' : {
                        $in : params.TemplateId
                    },
                    Status: RecognitionEnums.Status.Active,
                    $or: [{
                        'CreatorMember.UserId': params.UserId
                    }, {
                        'RecipientMember.UserId': params.UserId
                    }, {
                        SuppressInFeed: false
                    }]
                };
            // Not sure why this bit is here. Was it meant for filtering Highground system recognitions.
            // The Name Highground is not even used, Mercury is what is used in prod
            // This needs to be revisted
            if (params.Public) {
                query['PublicCreatorInfo.FullName'] = {
                    $nin: ['', 'HighGround']
                };
            }
            EntityCache.Recognition.find(query, {
                '_id': 0,
                'BatchId': 1,
                'hgId': 1,
                'BadgeFilename': 1,
                'ModifiedDate': 1,
                'CreatedDate': 1,
                'LevelName': 1,
                'CongratsCount': 1,
                'CongratMemberIds': 1,
                'ActualPointValue': 1,
                'ActualCreditValue': 1,
                'SubValue' : 1,
                'Message': 1,
                'PublicCreatorInfo': 1,
                'Template.hgId' : 1,
                'Template.Title' : 1,
                'Template.Description' : 1,
                'Template.FriendlyGroupId' : 1,
                'Template.Category': 1,
                'Template.SubValues': 1,
                'Template.Levels': 1,
                'Template.Type': 1,
                'Template.CreditValue': 1,
                'Template.PointValue': 1,
                'RecipientMember.UserId': 1,
                'RecipientMember.FullName': 1,
                'RecipientMember.hgId': 1,
                'CreatorMember.UserId': 1,
                'CreatorMember.FullName': 1,
                'CreatorMember.hgId': 1
            }, function (err, data) {
                callback(err, data);
            });
        };
        this.GetRecognitionFeed = function (params, callback) {
            var query = {
                'RecipientMember.GroupId': params.GroupId,
                'Template.Type': { $in: templateTypes.AllExceptNewsProductPoll},
                Status: RecognitionEnums.Status.Active,
                SuppressInFeed: false
            };
            EntityCache.Recognition.find(query, callback);
        };
        this.GetDisplayRecognitions = function (params, callback) {
            var query = {
                'RecipientMember.GroupId': params.GroupId,
                'Template.Type': {
                    $in: templateTypes.AllExceptNewsProductPoll
                },
                Status: RecognitionEnums.Status.Active,
                SuppressInFeed: false
            },  group = {
                _id: { BatchId: '$BatchId'},
                rows: { '$push': {
                    PublicCreatorInfo: '$PublicCreatorInfo',
                    GiverFullName: '$CreatorMember.FullName',
                    GiverUserId: '$CreatorMember.UserId',
                    ReceiverFullName: '$RecipientMember.FullName',
                    ReceiverUserId: '$RecipientMember.UserId',
                    TemplateId: '$Template.hgId',
                    BadgeFilename: '$BadgeFilename',
                    Title: '$Template.Title',
                    Description: '$Template.Description',
                    FriendlyGroupId: '$Template.FriendlyGroupId',
                    GroupId: '$Template.GroupId',
                    Message: '$Message',
                    CreatedDate: '$CreatedDate',
                    LikeCount: "$CongratsCount",
                    GiftCount: '$Gifts',
                    SubValue: '$SubValue',
                }   }
            };
            EntityCache.Recognition.aggregate([
                {$match: query},
                {$group: group },
                {$sort: {"rows.CreatedDate": -1}},
                {$limit: params.Take || 50}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data);
            });
        };
        this.GetAPIRecognitions = function (params, callback) {
            var query = {
                'RecipientMember.GroupId': params.GroupId,
                'Template.Type': {
                    $in: templateTypes.AllExceptNewsProductPoll
                },
                Status: RecognitionEnums.Status.Active, //suppress deleted recognitions
                SuppressInFeed: false //suppress private recognitions
            },  group = {
                _id: { BatchId: '$BatchId'},
                rows: { '$push': {
                    Id: '$BatchId',
                    PublicCreatorInfo: '$PublicCreatorInfo',
                    TriggerInfo: '$TriggerInfo',
                    GiverFullName: '$CreatorMember.FullName',
                    GiverDepartment: '$CreatorMember.GroupDepartmentName',
                    GiverPosition: '$CreatorMember.Position',
                    GiverUserId: '$CreatorMember.UserId',
                    ReceiverFullName: '$RecipientMember.FullName',
                    ReceiverDepartment: '$RecipientMember.GroupDepartmentName',
                    ReceiverPosition: '$RecipientMember.Position',
                    ReceiverUserId: '$RecipientMember.UserId',
                    TemplateId: '$Template.hgId',
                    Title: '$Template.Title',
                    Description: '$Template.Description',
                    FriendlyGroupId: '$Template.FriendlyGroupId',
                    Message: '$Message',
                    CreatedDate: '$CreatedDate',
                    NumberOfLikes: '$CongratsCount',
                    NumberOfComments: '$CommentCount',
                    NumberOfGifts: '$NumberOfGifts',
                    SubValue: '$SubValue',
                    SubValues: '$Template.SubValues'
                }}
            },
                recipientMemberId = 'RecipientMember.hgId',
                creatorMemberId = 'CreatorMember.hgId',
                createdDate = 'CreatedDate';
            if (params.Filters) {
                if (params.Filters.ReceiverMemberId) {
                    query[recipientMemberId] = params.Filters.ReceiverMemberId;
                }
                if (params.Filters.GiverMemberId) {
                    query[creatorMemberId] = params.Filters.GiverMemberId;
                }
                if (params.Filters.StartDate && params.Filters.EndDate) {
                    query[createdDate] = { $gte: params.Filters.StartDate, $lte: params.Filters.EndDate };
                } else if (params.Filters.StartDate && !params.Filters.EndDate) {
                    query[createdDate] = { $gte: params.Filters.StartDate };
                } else if (!params.Filters.StartDate && params.Filters.EndDate) {
                    query[createdDate] = { $lte: params.Filters.EndDate };
                }
            }
            EntityCache.Recognition.aggregate([
                {$match: query},
                {$sort: {CreatedDate: -1}},
                {$limit: 100},
                {$group: group },
                {$sort: {'rows.CreatedDate': -1}},
                {$skip: parseInt(params.Skip, 10) || 0},
                {$limit: parseInt(params.Take, 10) || RecognitionEnums.DEFAULT_API_TAKE}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data);
            });
        };
        this.UpdateMemberRecognitionStatus = function (params, callback) {
            Async.parallel({
                RecognitionGiven: function (fcallback) {
                    EntityCache.Recognition.update({
                        'CreatorMember.hgId': params.MemberId,
                        'CreatorMember.GroupId': params.GroupId
                    }, {
                        $set: {
                            'CreatorMember.MembershipStatus': params.Status,
                            'CreatorMember.RolesInGroup': params.Role
                        }
                    }, {
                        multi: true
                    }, fcallback);
                },
                RecognitionReceived: function (fcallback) {
                    EntityCache.Recognition.update({
                        'RecipientMember.hgId': params.MemberId,
                        'RecipientMember.GroupId': params.GroupId
                    }, {
                        $set: {
                            'RecipientMember.MembershipStatus': params.Status,
                            'RecipientMember.RolesInGroup': params.Role
                        }
                    }, {
                        multi: true
                    }, fcallback);
                }
            }, callback);
        };
    };
module.exports = RecognitionProcessor;
