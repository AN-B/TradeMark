var HgBaseProcessor = require('../framework/HgProcessorV2'),
    GroupTerminologyProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache'),
            i18nHelper = require('../helpers/i18nHelper.js'),
            ClusterMessageEnums = require('../enums/ClusterMessageEnums.js'),
            HgCache = require('../framework/RedisConnectionCache'),
            HgLog = require('../framework/HgLog'),
            ConstantEnums = require('../enums/ConstantEnums'),
            self = this;

        this.UpdateCustomTerminology = function (params, callback) {
            var theTimestamp = Date.now();
            if (params.GroupId && params.cmd) {
                if (params.cmd === ClusterMessageEnums.UpdateCustomTerminology) {
                    i18nHelper.setAllCustomTerminologyFiles({
                        EntityCache: EntityCache,
                        query: {GroupId: params.GroupId}
                    });
                }
                if (params.cmd === ClusterMessageEnums.RemoveCustomTerminology) {
                    i18nHelper.removeCustomTerminology(params.GroupId);
                }
                if (process.send) {
                    process.send({
                        cmd: params.cmd,
                        payload: params.GroupId,
                        pid: process.pid
                    });
                }
                HgCache.GlobalSet(ClusterMessageEnums.CustomTerminologyTimestamp, {
                    timestamp: theTimestamp,
                    GroupId: params.GroupId,
                    cmd: params.cmd
                }, function (err) {
                    if (err) {
                        HgLog.info('*** Unable to set value to Redis: ' + err.toString() + ' ***');
                    }
                    callback();
                }, ConstantEnums.SECONDS_IN_TWENTY_FOUR_HOURS);
            }
        };

        this.GetGroupTerminology = function (params, callback) {
            EntityCache.GroupTerminology.findOne({GroupId: params.GroupId}, function (err, terms) {
                if (err) {
                    return callback(err);
                }
                if (!terms || !terms.Languages) {
                    terms = new EntityCache.GroupTerminology({
                        GroupId: params.GroupId,
                        Languages: [
                            {
                                i18n: 'en',
                                Definitions: {
                                    none: 'none'
                                }
                            }
                        ]
                    });
                }
                callback(null, terms.toObject());
            });
        };

        this.SaveGroupTerminology = function (params, callback) {
            var newParams,
                isNew = false;
            if (params.req && params.req.body) {
                newParams = params.req.body;
                EntityCache.GroupTerminology.findOne({GroupId: newParams.GroupId}, function (err, terms) {
                    var term;
                    if (err) {
                        return callback(err);
                    }
                    if (!terms || !terms.Languages) {
                        terms = new EntityCache.GroupTerminology({
                            GroupId: newParams.GroupId,
                            Languages: [
                                {
                                    i18n: 'en',
                                    Definitions: {
                                        none: 'none'
                                    }
                                }
                            ]
                        });
                        isNew = true;
                    }
                    if (terms.Languages) {
                        term = terms.Languages.filter(function (lang) {
                            return lang.i18n === newParams.i18n;
                        });
                        if (term && term.length) {
                            try {
                                if (!newParams.Definitions) {
                                    newParams.Definitions = JSON.stringify({
                                        none: 'none'
                                    });
                                }
                                term[0].Definitions = JSON.parse(newParams.Definitions);
                                if (Object.keys(term[0].Definitions).length === 1 && term[0].Definitions.hasOwnProperty('none')) {
                                    if (isNew) {
                                        return callback("Nothing to save.");
                                    }
                                    // delete the row from the database
                                    terms.remove(function (err) {
                                        if (err) {
                                            return callback(err);
                                        }
                                        self.UpdateCustomTerminology({GroupId: newParams.GroupId, cmd: ClusterMessageEnums.RemoveCustomTerminology}, function (err) {
                                            callback(err);
                                        });
                                    });
                                } else {
                                    terms.save(function (err) {
                                        if (err) {
                                            return callback(err);
                                        }
                                        self.UpdateCustomTerminology({GroupId: newParams.GroupId, cmd: ClusterMessageEnums.UpdateCustomTerminology}, function (err) {
                                            callback(err);
                                        });
                                    });
                                }
                            } catch (e) {
                                return callback(e.message.split(':')[0] + ': Malformed JSON - look for missing comma(s) or extra comma at the end?');
                            }
                        }
                    }
                });
            }
        };

    };

module.exports = GroupTerminologyProcessor;