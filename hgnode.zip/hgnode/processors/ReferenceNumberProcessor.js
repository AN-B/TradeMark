/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ReferenceNumberProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js');

        this.GetGLAccount = function (params) {
            var callback = params.Callback;
            EntityCache.Member.findOne({'GroupId' : params.GroupId, 'UserId' : params.UserId}, function (err, member) {
                if (err || !member) {
                    callback(null);
                    return;
                }
                EntityCache.Team.findOne({'GroupId' : params.GroupId, 'Type' : 'Department', 'TeamMembers.MemberId' : member.hgId}, function (err, team) {
                    if (err || !team) {
                        callback(null);
                        return;
                    }
                    EntityCache.CostCenter.findOne({'TeamId' : team.hgId}, function (err, costCenter) {
                        if (err || !costCenter) {
                            callback(null);
                            return;
                        }
                        params.ReferenceNumber = {
                            TypeName : 'GLAccount',
                            Value : costCenter.GLAccount
                        };
                        callback(null);
                    });
                });
            });
        };
    };


module.exports = ReferenceNumberProcessor;
