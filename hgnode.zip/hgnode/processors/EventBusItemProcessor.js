/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    EventBusItemProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            HgLog = require('../framework/HgLog'),
            EventBusEnums = require('../enums/EventBusEnums.js'),
            guid = require('node-uuid');

        this.CreateBatchEvents = function (params, callback) {
            if (!params.length) {
                if (callback) {
                    callback(null, []);
                }
                return;
            }
            params.forEach(function (item) {
                item.hgId = guid.v1();
            });
            EntityCache.EventBusItem(params[0].GroupId).create(params, function (error, data) {
                if (error) {
                    HgLog.error('Error creating EventBus event: ' + error);
                }
                if (callback) {
                    callback(error, data);
                }
            });
        };

        this.CreateEvent = function (params, callback) {
            var eventItem = new EntityCache.EventBusItem(params.GroupId)(params);
            eventItem.CreatedBy = params.UserId;
            eventItem.ModifiedBy = params.UserId;
            eventItem.hgId = guid.v1();
            eventItem.save(function (error) {
                if (callback) {
                    callback(error, eventItem);
                }
                if (error) {
                    HgLog.error('Error creating EventBus event: ' + error);
                }
            });
        };

        this.UnlockItems = function (params, callback) {
            EntityCache.EventBusItem(params.GroupId).update({
                CreatedDate: {$lte: Date.now() - 300 * 1000},
                Status: EventBusEnums.ItemStatus.Locked
            }, {
                $set: {Status: EventBusEnums.ItemStatus.New}
            }, {
                multi: true
            }, function (error, count) {
                if (error) {
                    HgLog.error(error);
                    return callback(error);
                }
                if (count) {
                    HgLog.debug(count + ' item(s) unlocked');//worker, no need for localization
                }
                return callback(null, 'UnlockItems complete');
            });
        };

        this.GetAndArchiveEventItemsToTurk = function (params, callback) {
            EntityCache.EventBusItem(params.GroupId).update({
                Status: EventBusEnums.ItemStatus.New,
                $isolated : 1
            }, {
                $set: {
                    Status: EventBusEnums.ItemStatus.Locked,
                    TurkId: params.correlationId
                }
            }, {
                multi: true
            }, function (error, count) {
                if (error) {
                    return callback(error + ' ' + params.correlationId);
                }
                if (!count) {
                    return callback(null, []);
                }
                EntityCache.EventBusItem(params.GroupId).find({
                    Status: EventBusEnums.ItemStatus.Locked,
                    TurkId: params.correlationId
                })
                    .limit(20)
                    .exec(function (error, items) {
                        if (error) {
                            return callback(error);
                        }
                        var itemIds = items.map(function (item) {
                            return item.hgId;
                        });
                        EntityCache.EventBusItem(params.GroupId).update({hgId: {$in : itemIds}, $isolated : 1}, {
                            $set: {Status: EventBusEnums.ItemStatus.Processing}
                        }, {multi: true}, function (error) {
                            if (error) {
                                return callback(error);
                            }
                            EntityCache.EventBusItem(params.GroupId).update({
                                Status: EventBusEnums.ItemStatus.Locked,
                                TurkId: params.correlationId,
                                $isolated : 1
                            }, {
                                $set: {Status: EventBusEnums.ItemStatus.New}
                            }, {multi: true}, function (error) {
                                if (error) {
                                    return callback(error);
                                }
                                callback(null, items);
                            });
                            //archive the items that are selected to process
                            items.forEach(function (item) {
                                item.isNew = true;
                                item.Status = EventBusEnums.ItemStatus.Processing;
                                delete item._id;
                            });
                            EntityCache.EventBusItemArchive.create(items, function (error, result) {
                                if (error) {
                                    return HgLog.error('Error archiving: ' + error + result);
                                }
                                EntityCache.EventBusItem(params.GroupId).remove({hgId: {$in : itemIds}}, function (error) {
                                    if (error) {
                                        return HgLog.error('Error removing: ' + error);
                                    }
                                });
                            });
                        });
                    });
            });
        };
        this.GetItemsToRetryOrReport = function (params, callback) {
            var mquery = EntityCache.SubscriberAudit.find({
                    Status: 'Failed',
                    ActionPending: true,
                    Action: {$in : ['Report', 'Retry', 'ReportFailedRetries']}
                }),
                itemIds = [],
                auditIds = [];
            mquery.sort({CreatedDate : 1}).limit(10).exec(function (error, audits) {
                if (error) {
                    callback(error + ' ' + params.correlationId);
                } else if (audits.length === 0) {
                    callback(null, {Items : [], Audits : []});
                } else {
                    audits.forEach(function (audit) {
                        itemIds.push(audit.EventId);
                        auditIds.push(audit.hgId);
                    });
                    EntityCache.EventBusItemArchive.find({hgId : {$in : itemIds}}, function (error, items) {
                        if (error) {
                            return callback(error);
                        }
                        EntityCache.SubscriberAudit.update({hgId: {$in : auditIds}}, {$set : {ActionPending : false}}, {multi : true}, function (error) {
                            if (error) {
                                callback(error);
                            } else {
                                callback(null, {Items : items, Audits : audits});
                            }
                        });
                    });
                }
            });
        };

        this.MarkItemsAsProcessed = function (params, callback) {
            EntityCache.EventBusItemArchive.update({hgId : {$in : params.ItemIds}}, {$set : {Status : 'Processed'}}, {multi : true}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(error, 'All items have been marked as Processed');
                }
            });
        };

        this.CheckUniqueness = function (params, callback) {
            var item = params.Item,
                eventTypeInEnum = EventBusEnums.EventTypes[item.EventType];
            if (!eventTypeInEnum.CheckUniqueness) {
                return callback();
            }
            EntityCache.EventBusItemArchive.count({
                EventType: item.EventType,
                EntityId: item.EntityId,
                EntityType: item.EntityType
            }, function (error, count) {
                if (error) {
                    return callback(error);
                }
                if (count > 1) {
                    return callback("Duplicate item found, skipping: " + item.hgId);
                }
                callback();
            });
        };

        this.CreateSubscriberAudit = function (params, callback) {
            var log = new EntityCache.SubscriberAudit({
                hgId : guid.v1(),
                EventId : params.EventBusItem.hgId,
                ServiceName : params.ServiceName,
                MethodName : params.MethodName,
                Status : params.Status,
                Message : params.Message,
                Action : params.Action
            });
            log.save(function (error) {
                if (callback) {
                    callback(error, log);
                }
            });
        };
        this.GetRetryTimes = function (params, callback) {
            EntityCache.SubscriberAudit.find({
                EventId : params.EventBusItem.hgId,
                ServiceName : params.ServiceName,
                MethodName : params.MethodName,
                Action : 'Retry',
                Status : 'Failed'
            }, function (error, logs) {
                callback(error, logs.length);
            });
        };

        this.GetEventBusItemArchivedByEntityIdGroupId = function (params, callback) {
            EntityCache.EventBusItemArchive.findOne({
                hgId: params.EntityId,
                'Payload.GroupId': params.GroupId
            }, callback);
        };
    };

module.exports = EventBusItemProcessor;
