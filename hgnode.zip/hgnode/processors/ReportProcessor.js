/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    ReportProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EventEmitterCache = this.EventEmitterCache,
            EntityCache = require('../framework/EntityCache.js'),
            EventResponder = require('../util/EventResponder.js'),
            HgError = require('../common/HgError.js'),
            MemberEnums = require('../enums/MemberEnums.js'),
            FeedbackEnums = require('../enums/FeedbackEnums.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            GoalEnums = require('../enums/GoalEnums.js'),
            RecognitionEnums = require('../enums/RecognitionEnums.js'),
            SurveyEnums = require('../enums/SurveyEnums.js'),
            ReportEnums = require('../enums/ReportEnums.js'),
            HgLog = require('../framework/HgLog.js'),
            DateHelper = require('../util/DateHelper.js'),
            Iconv  = require('iconv').Iconv,
            guid = require('node-uuid'),
            self = this,
            async = require('async'),
            UNPROCESSED_REPORT_INTERVAL = 3600000,
            jschardet = require("jschardet"),
            fields = {
                delivered_at : 'delivered_at',
                GroupId : 'GroupId'
            },
            getFilterQuery = function (params) {
                var filter = {};
                if (params.StartDate && params.EndDate) {
                    filter[fields.delivered_at] = { $gte : DateHelper.getJustDate(params.StartDate), $lte : DateHelper.getJustDate(params.EndDate)};
                }
                if (params.GroupId && params.GroupId !== '') {
                    filter[fields.GroupId] = params.GroupId;
                }
                return filter;
            },
            getDistinctData = function (params, callback) {
                var entity = params.Entity;
                EntityCache[entity].distinct(params.DistinctField, params.FilterQuery, function (err, results) {
                    if (err) {
                        HgLog.error({methodName: 'getDistinctData', error: err});
                        callback(err);
                    } else {
                        callback(null, results);
                    }
                });
            },
            getDataAggregration = function (params, callback) {
                var entity = params.Entity;
                EntityCache[entity].aggregate([{$match : params.FilterQuery || {}}, {$group : params.GroupQuery}], function (err, results) {
                    if (err) {
                        HgLog.error({methodName: 'getDataAggregration', error: err});
                        callback(err);
                    } else {
                        callback(null, results);
                    }
                });
            },
            getMatchQuery = function (params, callback) {
                var entity = params.Entity,
                    projection = (params.Projection === '') ? {} : params.Projection,
                    sort = (params.Sort === undefined || params.Sort === null  || params.Sort === '') ? {} : params.Sort,
                    limit = (params.Limit === undefined || params.Limit === null || params.Limit === '') ? 0 : params.Limit,
                    filterQuery = (params.FilterQuery === '') ? {} : params.FilterQuery;
                EntityCache[entity].find(filterQuery, projection, {sort : sort, limit : limit}, function (err, results) {
                    if (err) {
                        HgLog.error({methodName: 'getMatchQuery', error: err});
                        callback(err);
                    } else {
                        callback(null, results);
                    }
                });
            },
            getGroupPreformRevivews = function (params, callback) {
                var query = {
                        'Card.GroupId' : params.GroupId
                    },
                    project = {
                        StatusByAdminView : 1,
                        hgId : 1,
                        CycleId : 1,
                        CycleName : 1,
                        MeetingDate : 1,
                        'Card.Title' : 1,
                        'Card.GroupName' : 1,
                        'Peoples.PeopleType' : 1,
                        'Peoples.Anonymous' : 1,
                        'Peoples.SubmitDate' : 1,
                        'Peoples.StatusInCurrentReview' : 1,
                        'Peoples.UserId' : 1,
                        'Peoples.MemberId' : 1,
                        'Peoples.MemberFullname' : 1,
                        'Peoples.DeliveryDate' : 1,
                        'Peoples.EmployeeId' : 1
                    };
                EntityCache.PerformanceReview.find(query, project, null, function (error, data) {
                    if (error) { return callback(error); }
                    callback(error, data);
                });
            },
            transformResultData = function (result) {
                var data = {};
                function getProperty(obj) {
                    Object.getOwnPropertyNames(obj).forEach(function (val) {
                        if ((typeof obj[val] !== 'object') && (typeof obj[val] !== 'function') && (obj[val] !== null)) {
                            data[val] = obj[val];
                        } else if (obj[val] !== null) {
                            getProperty(obj[val]);
                        }
                    });
                }
                getProperty(result);
                return data;
            },
            executeMultipleQueries = function (params, callback) {
                function addDataToArrayResult(params) {
                    var queryHeaderExist;
                    params.data.forEach(function (item) {
                        if (item.Title === params.Title) {
                            item.Data.push(params.newData);
                            queryHeaderExist = true;
                        }
                    });
                    if (!queryHeaderExist) {
                        params.data.push({Title : params.Title, Data : [params.newData]});
                    }
                    return params.data;
                }
                function executeQuery(queryRecord) {
                    if (queryRecord) {
                        if (queryRecord.type === 'aggregate') {
                            getDataAggregration({FilterQuery : queryRecord.filterQuery, GroupQuery : queryRecord.groupQuery, Entity : queryRecord.entity }, function (err, results) {
                                if (err) {
                                    callback(err);
                                } else {
                                    if (results.length > 0) {
                                        results.forEach(function (item) {
                                            item.Title = queryRecord.Title;
                                            params.results = addDataToArrayResult({data : params.results,  Title : queryRecord.Title, newData : transformResultData(item)});
                                        });
                                    } else {
                                        params.results = addDataToArrayResult({data : params.results,  Title : queryRecord.Title, newData : []});
                                    }
                                    executeQuery(params.query.shift());
                                }
                            });
                        } else if (queryRecord.type === 'distinct') {
                            getDistinctData({DistinctField : queryRecord.distinctField, FilterQuery : queryRecord.filterQuery, Entity : queryRecord.entity }, function (err, results) {
                                if (err) {
                                    callback(err);
                                } else {
                                    if (results.length > 0) {
                                        results.forEach(function (item) {
                                            params.results = addDataToArrayResult({data : params.results,  Title : queryRecord.Title, newData : item});
                                        });
                                    } else {
                                        params.results = addDataToArrayResult({data : params.results,  Title : queryRecord.Title, newData : []});
                                    }
                                    executeQuery(params.query.shift());
                                }
                            });
                        } else if (queryRecord.type === 'find') {
                            getMatchQuery({FilterQuery : queryRecord.filterQuery, Sort : queryRecord.sortQuery, Projection : queryRecord.projectQuery, Entity : queryRecord.entity, Limit : queryRecord.limitQuery }, function (err, results) {
                                if (err) {
                                    callback(err);
                                } else {
                                    if (results.length > 0) {
                                        results.forEach(function (item) {
                                            params.results = addDataToArrayResult({data : params.results,  Title : queryRecord.Title, newData : item});
                                        });
                                    } else {
                                        params.results = addDataToArrayResult({data : params.results,  Title : queryRecord.Title, newData : []});
                                    }
                                    executeQuery(params.query.shift());
                                }
                            });
                        }
                    } else {
                        callback(null, params.results);
                    }
                }
                executeQuery(params.query.shift());
            },
            getRedeemptionData = function (params, callback) {
                EntityCache.TangoCardOrder.aggregate([params.query, params.group], function (error, data) {
                    if (error) { return callback(error); }
                    callback(null, data);
                });
            };
        this.GetExpiringReports = function (params, callback) {
            EntityCache.Report.find({
                Status: ReportEnums.Status.Ready,
                ExpireDate: {$lte : Date.now()}
            }, callback);
        };
        this.GetReportsByMemberId = function (params, callback) {
            var condition = {
                    RequesterUserId: params.UserId
                };
            if (params.Status) {
                condition.Status = params.Status;
            }
            if (params.Search && params.Search.length) {
                condition.$or = [{'ReportTypeName': new RegExp(params.Search, "i")}];
            }
            async.parallel({
                total: function (fcallback) {
                    EntityCache.Report.count(condition, fcallback);
                },
                reports: function (fcallback) {
                    EntityCache.Report.find(condition)
                        .skip(parseInt(params.Skip, 10) || 0)
                        .limit(parseInt(params.Take, 10) || 0)
                        .sort({CreatedDate: -1})
                        .exec(fcallback);
                }
            }, function (error, results) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    Reports: results.reports,
                    Total: results.total
                });
            });
        };
        this.SubmitRequest = function (params, callback) {
            var report = EntityCache.Report(params);
            report.hgId = guid.v1();
            report.CreatedBy = params.RequesterUserId;
            report.ModifiedBy = params.RequesterUserId;
            report.ReportTypeId = params.Report;
            report.ReportGroupId = params.GroupId;
            report.save(function (error) {
                if (error) {
                    HgLog.error({methodName: 'SubmitRequest', error: error});
                }
                callback(error, report);
            });
        };
        this.UpdateRequestStatus = function (params, callback) {
            var updateObj = {
                Status: params.NewStatus
            };
            if (params.NewStatus === ReportEnums.Status.Ready) {
                updateObj.ReadyDate = Date.now();
                updateObj.ExpireDate = Date.now() + 24 * 3600 * 1000;
            }
            if (params.NewStatus === ReportEnums.Status.Downloaded) {
                updateObj.DownloadDate = Date.now();
            }
            EntityCache.Report.findOneAndUpdate({
                hgId: params.RequestId
            }, {
                $set: updateObj
            }, {
                new: true
            }, callback);
        };
        this.GetReportById = function (params, callback) {
            EntityCache.Report.findOne({hgId: params.ReportId}, callback);
        };
        this.GetRequestByIdForProcessing = function (params, callback) {
            EntityCache.Report.findOneAndUpdate({
                hgId: params.RequestId,
                Status: ReportEnums.Status.Pending
            }, {
                $set: {
                    Status: ReportEnums.Status.Processing
                }
            }, {
                new: true
            }, callback);
        };
        this.ExecuteQuery = function (params) {
            getMatchQuery(params, function (err, results) {
                if (err) {
                    HgLog.error({methodName: 'ExecuteQuery', error: err});
                    EventResponder.RespondWithError(EventEmitterCache, params, HgError.Enums.Report.ErrorComputingDataAggregation);
                } else {
                    EventResponder.RespondWithData(EventEmitterCache, params, results);
                }
            });
        };
        this.ExecuteMultipleQueries = function (params, callback) {
            params.results = [];
            executeMultipleQueries(params, function (err, data) {
                if (err) {
                    callback('Error Executing Queries', data);
                } else {
                    callback(null, { data : params.results});
                }
            });
        };

        this.GetTrackActivityBatch = function (params, callback) {
            EntityCache.CareerTrack.find({
                'CareerTrackTemplate.GroupId' : params.GroupId,
                CreatedDate : {$gte : params.StartDate, $lte : params.EndDate}
            }).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(callback);
        };

        this.GetTrackActivityNumber = function (params, callback) {
            EntityCache.CareerTrack.count({
                'CareerTrackTemplate.GroupId' : params.GroupId,
                CreatedDate : {$gte : params.StartDate, $lte : params.EndDate}
            }, callback);
        };

        this.GetGroupActivitySummary = function (params, callback) {
            params.results = [];
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, {}, {
                lean: true
            }, function (error, group) {
                if (error || !group) {
                    return callback("Error loading group");//ESb, no localization
                }
                EntityCache.Member.find({
                    GroupId: params.GroupId,
                    MembershipStatus: {
                        $in: [MemberEnums.Status.Active, MemberEnums.Status.PendingAdminApprove, MemberEnums.Status.OffBoarded]
                    }
                }, {
                    _id: -1,
                    hgId: 1,
                    FullName: 1,
                    MembershipStatus: 1,
                    UserId: 1,
                    RolesInGroup: 1,
                    MyManagers: 1,
                    Location: 1,
                    EmployeeId: 1,
                    GroupDepartmentName: 1
                }, {
                    lean: true
                }, function (error, members) {
                    if (error) {
                        return callback(error);
                    }
                    EntityCache.UserInfo.find({
                        "Preference.DefaultGroupId": params.GroupId,
                        hgId: {
                            $in: members.map(function (member) {
                                return member.UserId;
                            })
                        }
                    }, {
                        _id: -1,
                        'UserPersonal.FullName': 1,
                        hgId: 1,
                        'Preference.DefaultGroupId': 1,
                        'UserPersonal.PrimaryEmail': 1,
                        CreatedDate: 1,
                        AvatarVersion: 1,
                        LastLoginTime: 1
                    }, {
                        lean: true
                    }, function (error, users) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, {
                            data : [{
                                Title: 'MembersList',
                                Data: members
                            }, {
                                Title: 'UserInfoList',
                                Data: users
                            }],
                            group : group
                        });
                    });
                });
            });
        };
        this.GetGroupName = function (params, callback) {
            var query = { hgId : params.GroupId},
                project = {GroupName : 1};
            EntityCache.Group.findOne(query, project, function (error, results) {
                if (error) { return callback(error); }
                callback(null, results.GroupName);
            });
        };
        this.GetGroups = function (params, callback) {
            var data = [];
            EntityCache.Group.find({}, function (err, results) {
                if (err) {
                    callback('business.gro.pro.elg');
                } else {
                    if (results) {
                        results.forEach(function (item) {
                            data.push({GroupId : item.hgId, GroupName : item.GroupName, hgId : item.hgId});
                        });
                        data = data.sort(function (a, b) {
                            return a.GroupName.toLowerCase() > b.GroupName.toLowerCase() ? 1 : -1;
                        });
                    }
                    callback(null, data);
                }
            });
        };
        this.GetBadgeActivityNumber = function (params, callback) {
            var groupIdField = 'Template.GroupId',
                createdDateField = 'CreatedDate',
                statusField = 'Status',
                filterQuery = { 'Template.Type' : { $nin : ['Newsfeed', 'ProductItem', 'PollResult'] } };
            if (params.GroupId) {
                filterQuery[groupIdField] = params.GroupId;
            }
            if (params.StartDate && params.EndDate) {
                filterQuery[createdDateField] = { $gte : params.StartDate, $lte : params.EndDate };
            }
            if (params.ClientView) {
                filterQuery[statusField]  = 'Active';
            }
            EntityCache.Recognition.count(filterQuery, callback);
        };
        this.GetBadgeActivityReport = function (params, callback) {
            var reports = [],
                groupIdField = 'RecipientMember.GroupId',
                createdDateField = 'CreatedDate',
                statusField = 'Status',
                filterQuery = { 'Template.Type' : { $nin : ['Newsfeed', 'ProductItem', 'PollResult', 'GoalKeyResultUpdate'] } },
                projection,
                cursor,
                skip = parseInt(params.Skip, 10) || 0,
                take = parseInt(params.Take, 10) || 0;

            if (params.GroupId) {
                filterQuery[groupIdField] = params.GroupId;
            }
            if (params.StartDate && params.EndDate) {
                filterQuery[createdDateField] = { $gte : params.StartDate, $lte : params.EndDate };
            }
            if (params.ClientView) {
                filterQuery[statusField]  = 'Active';
            }
            function formatDate(date) {
                return [date.getMonth() + 1, "/", date.getDate(), "/", date.getFullYear()].join('');
            }
            function getRecognitionType(record) {
                var type;
                if (record.SuppressInFeed) {
                    type = 'Private';
                } else if ((record.PublicCreatorInfo && !record.PublicCreatorInfo.FullName) || (record.Template && record.Template.Category === 'System')) {
                    type = 'Internal';
                } else {
                    type = 'External';
                }
                return type;
            }
            function getRecognitionCompany(record) {
                return ((record.PublicCreatorInfo && !record.PublicCreatorInfo.FullName) || (record.Template && record.Template.Category === 'System')) ? '' : record.PublicCreatorInfo.CompanyName;
            }
            function getRecognitionGivenBy(record) {
                var type = getRecognitionType(record),
                    value;
                if (type === 'Private') {
                    if (!record.CreatorMember && !record.PublicCreatorInfo) {
                        value = 'System';
                    } else {
                        value = (record.CreatorMember && record.CreatorMember.FullName) ? record.CreatorMember.FullName : record.PublicCreatorInfo.FullName;
                    }
                } else if (type === 'Internal') {
                    value = (record.CreatorMember && record.CreatorMember.FullName) ? record.CreatorMember.FullName : 'System';
                } else { //External
                    value = record.PublicCreatorInfo.FullName || 'System';
                }
                return value;
            }
            function getMemberRole(member) {
                var role = member.LastRole || '';
                if (member.MembershipStatus !== MemberEnums.Status.OffBoarded) {
                    role = (member.RolesInGroup && member.RolesInGroup.length === 1) ? member.RolesInGroup[0] : '';
                }
                return role;
            }
            function getComment(record) {
                var comment, enc, iconv;
                if (getRecognitionType(record) === 'Private') {
                    comment = '';
                } else if (getRecognitionType(record) === 'Internal') {
                    comment = record.Message;
                } else {
                    comment = record.CannedMessage;
                }
                if (comment) {
                    enc = jschardet.detect(comment).encoding;
                    iconv = new Iconv(enc, 'UTF-8//TRANSLIT//IGNORE');
                    comment = iconv.convert(comment).toString("utf8");
                }
                return comment;
            }
            function getRecognitionTitle(record) {
                var title = '';
                if (record.MemberRating && record.MemberRating < 6) {
                    title = 'External Recognition';
                } else {
                    title = (record.Template && record.Template.Title) || '';
                    if (record.SubValue) {
                        title += ' : ' + record.SubValue;
                    }
                }
                return title;
            }
            EntityCache.Group.findOne({hgId : params.GroupId}, function (error, group) {
                if (error) {
                    return callback('Error Loading Group');
                }
                projection = {
                    hgId: 1,
                    SuppressInFeed: 1,
                    Message: 1,
                    CannedMessage: 1,
                    SubValue: 1,
                    'Template.Title': 1,
                    'Template.GroupId': 1,
                    'Template.GroupName': 1,
                    'Template.Category': 1,
                    PublicCreatorInfo: 1,
                    'CreatorMember.hgId': 1,
                    'CreatorMember.UserId': 1,
                    'CreatorMember.EmployeeId': 1,
                    'CreatorMember.FullName': 1,
                    'CreatorMember.LastRole': 1,
                    'CreatorMember.RolesInGroup': 1,
                    'CreatorMember.GroupDepartmentName': 1,
                    'CreatorMember.Location': 1,
                    'CreatorMember.Position': 1,
                    'RecipientMember.GroupId': 1,
                    'RecipientMember.GroupName': 1,
                    'RecipientMember.hgId': 1,
                    'RecipientMember.FullName': 1,
                    'RecipientMember.EmployeeId': 1,
                    'RecipientMember.LastRole': 1,
                    'RecipientMember.RolesInGroup': 1,
                    'RecipientMember.GroupDepartmentName': 1,
                    'RecipientMember.Location': 1,
                    'RecipientMember.UserId': 1,
                    'RecipientMember.Position': 1,
                    CreatedDate: 1,
                    ActualCreditValue: 1,
                    Status: 1,
                    CompanyRating: 1,
                    MemberRating: 1,
                    CommentCount: 1,
                    CongratsCount: 1,
                    Source: 1,
                    ActualPointValue: 1
                };
                self.GetStreamedMemberData({GroupId: params.GroupId}, function (error, memberIndex) {
                    if (error) {
                        return callback(error);
                    }
                    cursor = EntityCache.Recognition.find(filterQuery, projection)
                        .skip(skip)
                        .limit(take)
                        .cursor({batchSize: 250});
                    cursor.eachAsync(function (record) {
                        if (!record.CreatorMember) {
                            record.CreatorMember = {};
                        }
                        if (!record.RecipientMember) {
                            record.RecipientMember = {};
                        }
                        if (record.RecipientMember.UserId && memberIndex[record.RecipientMember.UserId] && memberIndex[record.RecipientMember.UserId].User_Member_Record.length) {
                            record.RecipientMember.FullName = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].FullName;
                            record.RecipientMember.EmployeeId = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].EmployeeId;
                            record.RecipientMember.JobCode = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].JobCode || '';
                            record.RecipientMember.JobLevel = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].JobLevel || '';
                            record.RecipientMember.UnionCode = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].UnionCode || '';
                            record.RecipientMember.CostCenter = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].CostCenter || '';
                            record.RecipientMember.MailCD = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].MailCD || '';
                            record.RecipientMember.HomeCountry = memberIndex[record.RecipientMember.UserId].User_Member_Record[0].HomeCountry || '';
                        }
                        if (record.CreatorMember.UserId && memberIndex[record.CreatorMember.UserId] && memberIndex[record.CreatorMember.UserId].User_Member_Record.length) {
                            record.CreatorMember.FullName = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].FullName;
                            record.CreatorMember.EmployeeId = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].EmployeeId;
                            record.CreatorMember.JobCode = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].JobCode || '';
                            record.CreatorMember.JobLevel = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].JobLevel || '';
                            record.CreatorMember.UnionCode = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].UnionCode || '';
                            record.CreatorMember.CostCenter = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].CostCenter || '';
                            record.CreatorMember.MailCD = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].MailCD || '';
                            record.CreatorMember.HomeCountry = memberIndex[record.CreatorMember.UserId].User_Member_Record[0].HomeCountry || '';
                        }
                        reports.push({
                            Date: formatDate(new Date(record.CreatedDate)),
                            GroupId: record.RecipientMember.GroupId,
                            GroupName: record.RecipientMember.GroupName,
                            GivenByFullName: getRecognitionGivenBy(record),
                            GivenByMemberId: record.CreatorMember.hgId,
                            GiverDepartment: record.CreatorMember.GroupDepartmentName || '',
                            GiverRole: getMemberRole(record.CreatorMember),
                            GiverLocation: record.CreatorMember.Location && record.CreatorMember.Location.Name ? record.CreatorMember.Location.Name : '',
                            ReceiverLocation: record.RecipientMember.Location && record.RecipientMember.Location.Name ? record.RecipientMember.Location.Name : '',
                            ReceiverRole: getMemberRole(record.RecipientMember),
                            ReceiverDepartment: record.RecipientMember.GroupDepartmentName || '',
                            ReceivedByFullName: record.RecipientMember.FullName,
                            ReceivedByMemberId: record.RecipientMember.hgId,
                            RecognitionTitle: getRecognitionTitle(record),
                            RecognitionCategory: record.Template && record.Template.Category ? record.Template.Category : '',
                            Comment: getComment(record),
                            RecognitionType: getRecognitionType(record),
                            CreditValue: record.ActualCreditValue || 0,
                            Status: record.Status,
                            Company: getRecognitionCompany(record),
                            CompanyRating: record.CompanyRating,
                            MemberRating: record.MemberRating,
                            NumComments: record.CommentCount,
                            NumLikes: record.CongratsCount,
                            EmployeeId: record.CreatorMember.EmployeeId,
                            TimeCreated: new Date(record.CreatedDate).toLocaleTimeString(),
                            Source: !record.Source || [RecognitionEnums.Source.Web, RecognitionEnums.Source.RulesEngine].indexOf(record.Source) > -1 ? RecognitionEnums.Source.Web : RecognitionEnums.Source.Mobile,
                            ActualPointValue: record.ActualPointValue,
                            ReceiverEmployeeId: record.RecipientMember.EmployeeId || '',
                            ReceiverJobCode: record.RecipientMember.JobCode || '',
                            ReceiverJobLevel: record.RecipientMember.JobLevel || '',
                            ReceiverUnionCode: record.RecipientMember.UnionCode || '',
                            ReceiverCostCenter: record.RecipientMember.CostCenter || '',
                            ReceiverMailCD: record.RecipientMember.MailCD || '',
                            ReceiverHomeCountry: record.RecipientMember.HomeCountry || '',
                            ReceiverPosition: record.RecipientMember.Position || '',
                            GiverEmployeeId: record.CreatorMember.EmployeeId || '',
                            GiverJobCode: record.CreatorMember.JobCode || '',
                            GiverJobLevel: record.CreatorMember.JobLevel || '',
                            GiverUnionCode: record.CreatorMember.UnionCode || '',
                            GiverCostCenter: record.CreatorMember.CostCenter || '',
                            GiverMailCD: record.CreatorMember.MailCD || '',
                            GiverHomeCountry: record.CreatorMember.HomeCountry || '',
                            GiverPosition: record.CreatorMember.Position || ''
                        });
                    }).then(function () {
                        callback(null, {GroupName: group.GroupName, Recognition: reports});
                    });
                });
            });
        };
        this.GetCreditActivityNumber = function (params, callback) {
            var userIds,
                memberIds,
                ownerIds,
                mQuery = EntityCache.Member.find({});
            mQuery.where('GroupId', params.GroupId);
            mQuery.exec(function (error, members) {
                if (error) { return callback(error); }
                memberIds = members.map(function (item) { return item.hgId; });
                userIds = members.map(function (item) { return item.UserId; });
                ownerIds = memberIds.concat(userIds);
                EntityCache.CreditAccount.count({OwnerId : {$in : ownerIds}}, function (error, accountNumber) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, {MemberNumber : members.length, AccountNumber : accountNumber});
                    }
                });
            });
        };
        this.GetCreditActivityReport = function (params, callback) {
            var userIds,
                memberIds,
                ownerIds,
                mQuery = EntityCache.Member.find({});
            mQuery.where('GroupId', params.GroupId);
            mQuery.sort({FirstName : 1}).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (error, members) {
                if (error) { return callback(error); }
                memberIds = members.map(function (item) { return item.hgId; });
                userIds = members.map(function (item) { return item.UserId; });
                ownerIds = memberIds.concat(userIds);
                EntityCache.CreditAccount.find({OwnerId : {$in : ownerIds}}, function (error, creditAccounts) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, {Members : members, CreditAccounts : creditAccounts});
                    }
                });
            });
        };
        this.GetActiveMemberCount = function (params, callback) {
            var query = {
                    CreatedDate : { $lte : params.EndDate },
                    $or : [ {EndingDate : { $gt : params.EndDate }},  {EndingDate : { $exists : false }}]
                },
                project = { FullName : 1, EndingDate : 1, MembershipStatus : 1};
            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            EntityCache.Member.find(query, project,  function (error, result) {
                if (error) {
                    callback(error);
                } else {
                    if (result) {
                        result = result.filter(function (item) {
                            return ((item.MembershipStatus === 'Active') || (item.EndingDate && item.EndingDate > params.EndDate));
                        });
                    }
                    callback(null, result.length);
                }
            });
        };
        this.GetCardRedemptionActivity = function (params, callback) {
            var month = [],
                dataRecords = {},
                group = {
                    $group: {
                        _id: {
                            year: {'$year': '$delivered_at'},
                            month: {'$month': '$delivered_at'},
                            CardName :  '$CardName'
                        },
                        TotalCards: {$sum: 1},
                        TotalAmount: {$sum: '$amount'}
                    }
                };
            month = DateHelper.getCategoryDateRange('Monthly', new Date(params.StartDate), new Date(params.EndDate), true).Category;
            getRedeemptionData({query : { $match: getFilterQuery(params) || {}}, group : group}, function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    dataRecords[item._id.CardName + '.' + item._id.year + '.' + item._id.month] = {
                        TotalCards : item.TotalCards,
                        TotalAmount : (item.TotalAmount / 100)
                    };
                });
                callback(null, {
                    Month : month,
                    data : dataRecords,
                    length : data.length
                });
            });
        };
        this.GetMemberRedemptionActivity = function (params, callback) {
            var query = {
                    GroupId : params.GroupId
                },
                sort = { sort: { delivered_at : 1} };
            if (params.StartDate && params.EndDate) {
                query.CreatedDate = { $gte : params.StartDate, $lte : params.EndDate};
            }
            EntityCache.TangoCardOrder.find(query, null, sort, function (error, data) {
                if (error) { return callback(error); }
                callback(null, data);
            });
        };
        this.GetPreformRevivewFeedBackDump = function (params, callback) {
            var flattenResult = function (data, fal) {
                    var feedback = [], i, j, len, jLen, feedBackRecord = {}, key;
                    for (i = 0, len = data.length; i < len; i += 1) {
                        for (j = 0, jLen = data[i].Peoples.length; j < jLen; j += 1) {
                            if (data[i].Peoples[j].PeopleType !== 'Subject' && data[i].Peoples[j].StatusInCurrentReview === 'Submitted') {
                                if (!feedBackRecord[data[i].Peoples[j].MemberId]) {
                                    feedBackRecord[data[i].Peoples[j].MemberId] = {
                                        Name : data[i].Peoples[j].MemberFullname,
                                        Count : 1
                                    };
                                } else {
                                    feedBackRecord[data[i].Peoples[j].MemberId].Count += 1;
                                }
                            }
                        }
                    }
                    for (key in feedBackRecord) {
                        if (feedBackRecord.hasOwnProperty(key)) {
                            feedback.push({
                                MemberId : key,
                                Name : feedBackRecord[key].Name,
                                FeedBackCount : feedBackRecord[key].Count
                            });
                        }
                    }
                    fal(null, feedback);
                };
            getGroupPreformRevivews(params, function (error, data) {
                if (error) { return callback(error); }
                flattenResult(data, function (error, result) {
                    callback(error, result);
                });
            });
        };
        function formatGoalData(params, record) {
            var participantType = {
                    Team: ReportEnums.GoalActivityReport.Team,
                    Member: ReportEnums.GoalActivityReport.Member,
                    Company: ReportEnums.GoalActivityReport.Company
                },
                progressStatusType = {
                    AtRisk: ReportEnums.ProgressStatus.AtRisk,
                    OnTrack: ReportEnums.ProgressStatus.OnTrack,
                    Behind: ReportEnums.ProgressStatus.Behind,
                },
                getKeyResultType = function (data) {
                    var keyType = {
                        Binary: 'Type: Checkbox',
                        Numeric: 'Type: Target ' + data.Target,
                        Percentage: 'Type: Percent'
                    };
                    return keyType[data.Measure];
                };
            if (params.type === ReportEnums.GoalActivityReport.Goal) {
                return [
                    new Date(record.CreatedDate),
                    !record.CycleId ? ReportEnums.GoalActivityReport.PersonalGoal : ReportEnums.GoalActivityReport.Cycle,
                    participantType[record.Participant.ParticipantType],
                    record.Name.replace("..", "-"),
                    record.ClosePromptDate ? new Date(record.ClosePromptDate) : record.CycleId && params.cycleIndex[record.CycleId] ? new Date(params.cycleIndex[record.CycleId].DueDate) : '',
                    record.CycleTitle || '',
                    !record.LastCheckInDate ? '' : new Date(record.LastCheckInDate),
                    params.completeMemberIndex[record.Owner.UserId].LowercaseUserName,
                    new Date(params.completeMemberIndex[record.Owner.UserId].User_Member_Record[0].CreatedDate),
                    record.Owner.FullName,
                    params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Status : '',
                    params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Manager : '',
                    params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Department : '',
                    params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].EmployeeId : '',
                    params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Position : '',
                    params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Role : '',
                    params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Location : '',
                    !record.Approver ? '' : record.Approver.FullName,
                    record.Status,
                    !record.ProgressStatus ? '' : progressStatusType[record.ProgressStatus],
                    record.KeyResults.map(function (item) {
                        return [
                            'Name: ' + item.Name,
                            'Description: ' + (item.Description || ''),
                            'Due Date: ' +  (!item.DueDate ? 'N/A' : new Date(item.DueDate)),
                            getKeyResultType(item),
                            'Weight: ' + (item.Weight || 'N/A'),
                            'Progress: ' + item.Progress
                        ].join(', ');
                    }).join('|'),
                    record.CheckInFrequency || '',
                    record.IsPublic ? ReportEnums.GoalActivityReport.Public : ReportEnums.GoalActivityReport.Private,
                    Math.round(record.PercentCompletion)
                ];
            }
            return [
                'N/A',
                ReportEnums.GoalActivityReport.Cycle,
                participantType[record.ParticipantType],
                '',
                params.cycleIndex[record.CycleId] && params.cycleIndex[record.CycleId].DueDate ? new Date(params.cycleIndex[record.CycleId].DueDate) : '',
                params.cycleIndex[record.CycleId] && params.cycleIndex[record.CycleId].Title ? params.cycleIndex[record.CycleId].Title : '',
                '',
                params.completeMemberIndex[record.Owner.UserId].LowercaseUserName,
                new Date(params.completeMemberIndex[record.Owner.UserId].User_Member_Record[0].CreatedDate),
                record.Owner.FullName,
                params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Status : '',
                params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Manager : '',
                params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Department : '',
                params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].EmployeeId : '',
                params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Position : '',
                params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Role : '',
                params.memberIndex[record.Owner.MemberId] ? params.memberIndex[record.Owner.MemberId].Location : '',
                '',
                record.Status,
                '',
                '',
                record.CheckInFrequency || '',
                '',
                ''
            ];
        }
        this.GetGoalDataByType = function (params, callback) {
            var data = [];
            if (!params.stream.readable) {
                return callback(null, []);
            }
            params.stream.on('data', function (record) {
                data.push(formatGoalData(params, record));
            });
            params.stream.on('close', function (error) {
                if (error) {
                    return callback(error);
                }
                return callback(null, data);
            });
            params.stream.on('error', function (error) {
                callback(error);
            });
        };
        this.ExportFeedbackRequestReport = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                CycleType: {
                    $in: [
                        FeedbackEnums.CycleType.Request,
                        FeedbackEnums.CycleType.EvaluateOthers,
                        FeedbackEnums.CycleType.Give
                    ]
                }
            };
            if (params.Payload && params.Payload.CycleId) {
                query.CycleId = params.Payload.CycleId;
            }
            return EntityCache.FeedbackSession.find(query, {}, {lean: true}).cursor({batchSize: 250});
        };
        this.ExportCheckInReport = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                CycleType: FeedbackEnums.CycleType.SelfEvaluation
            };
            if (params.Payload && params.Payload.CycleId) {
                query.CycleId = params.Payload.CycleId;
            }
            if (params.StartDate && params.EndDate) {
                query.CreatedDate = {$gte: params.StartDate, $lte: params.EndDate};
            }
            return EntityCache.FeedbackSession.find(query, {}, {lean: true}).cursor({batchSize: 250});
        };
        this.ExportSurveyKioskAccessCode = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                CurrentRoundId: params.CurrentRoundId,
                RecurrenceId: params.RecurrenceId
            };
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            return EntityCache.SurveyAnswer.find(query, params.Fields || {}, {lean: true, sort: {LocationName: 1, DepartmentName: 1}}).cursor({batchSize: 250});
        };
        this.ExportSurveyActivityReport = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId
            }, dataIndex = {},
                key;
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            EntityCache.SurveyAnswer.aggregate([
                {$match: query},
                {$group: {
                    _id: {
                        LocationId: "$LocationId",
                        LocationName: "$LocationName",
                        DepartmentId: "$DepartmentId",
                        DepartmentName: "$DepartmentName",
                        Status: "$Status"
                    },
                    Total: {$sum: 1}
                }},
                {$project: {
                    _id: 0,
                    LocationId: "$_id.LocationId",
                    LocationName: "$_id.LocationName",
                    DepartmentName: "$_id.DepartmentName",
                    DepartmentId: "$_id.DepartmentId",
                    Status: "$_id.Status",
                    Total: "$Total"
                }},
                {$sort: {LocationName: 1}}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    key = item.LocationId + '.' + item.DepartmentId;
                    if (!dataIndex[key]) {
                        dataIndex[key] = {
                            DepartmentName: item.DepartmentName,
                            LocationName: item.LocationName,
                            Completed: 0,
                            Total: 0
                        };
                    }
                    if (item.Status === SurveyEnums.SurveyAnswerStatus.Completed) {
                        dataIndex[key].Completed = item.Total;
                    }
                    dataIndex[key].Total += item.Total;
                });
                callback(null, dataIndex);
            });
        };
        this.GetStreamedMemberData = function (params, callback) {
            var dataIndex = {},
                cursor = EntityCache.UserInfo.aggregate([
                    {$match: {
                        "Preference.DefaultGroupId": params.GroupId
                    }},
                    {$lookup: {
                        from: 'Member',
                        localField: 'hgId',
                        foreignField: 'UserId',
                        as: 'User_Member_Record'
                    }}
                ]).cursor({batchSize: 250}).exec();
            cursor.on('data', function (item) {
                dataIndex[item.hgId] = item;
            });
            cursor.on('end', function () {
                return callback(null, dataIndex);
            });
        };
        this.ExportGoalActivity = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                IsTemplate: {$in: [false, null]}
            },  cycleQuery = {
                GroupId: params.GroupId
            },  notStartedQuery = {
                GroupId: params.GroupId,
                Status: GoalEnums.ParticipantStatus.NotStarted
            };
            if (params.Payload && params.Payload.CycleId) {
                cycleQuery.hgId = params.Payload.CycleId;
                query.CycleId = params.Payload.CycleId;
                notStartedQuery.CycleId = params.Payload.CycleId;
            }
            async.parallel({
                completeMemberIndex: function (fcallback) {
                    self.GetStreamedMemberData({
                        GroupId: params.GroupId
                    }, fcallback);
                },
                memberIndex: function (fcallback) {
                    self.GetMembersIndex({
                        GroupId: params.GroupId,
                        Status: Object.keys(EntityEnums.MembershipStatus)
                    }, fcallback);
                },
                cycleIndex: function (fcallback) {
                    var cycleKey = {};
                    EntityCache.GoalCycle.find(cycleQuery, {hgId: 1, Title: 1, ClosePromptDate: 1}, function (error, cycle) {
                        if (error) {
                            return fcallback(error);
                        }
                        cycle.forEach(function (item) {
                            cycleKey[item.hgId] = {
                                Title: item.Title,
                                DueDate: item.ClosePromptDate
                            };
                        });
                        fcallback(null, cycleKey);
                    });
                }
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                self.GetGoalDataByType({
                    stream: EntityCache.GoalCycleParticipant.find(notStartedQuery).stream(),
                    cycleIndex: result.cycleIndex,
                    memberIndex: result.memberIndex,
                    completeMemberIndex: result.completeMemberIndex,
                    type: ReportEnums.GoalActivityReport.GoalCycleParticipant
                }, function (error, goalsNotStartedData) {
                    if (error) {
                        return callback(error);
                    }
                    self.GetGoalDataByType({
                        stream: EntityCache.Goal.find(query).stream(),
                        cycleIndex: result.cycleIndex,
                        memberIndex: result.memberIndex,
                        completeMemberIndex: result.completeMemberIndex,
                        type: ReportEnums.GoalActivityReport.Goal,
                    }, function (error, goalData) {
                        if (error) {
                            return callback(error);
                        }
                        goalData = goalData.concat(goalsNotStartedData);
                        callback(null, goalData);
                    });
                });
            });
        };
        this.ExportMembers = function (params, callback) {
            var query = {
                GroupId: params.GroupId
            };
            if (!params.Payload.IncludeOffBoard) {
                query.MembershipStatus = MemberEnums.Status.Active;
            }
            self.ExportMembersUserInfo(params, function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    memberCursor: EntityCache.Member.find(query, {
                        _id: 0,
                        CreatedBy: 1,
                        ModifiedBy: 1,
                        CreatedDate: 1,
                        ModifiedDate: 1,
                        hgId: 1,
                        UserId: 1,
                        EmployeeId: 1,
                        MyManagers: 1,
                        MembershipStatus: 1,
                        StartingDate: 1,
                        Birthdate: 1,
                        Position: 1,
                        RolesInGroup: 1,
                        LastName: 1,
                        FirstName: 1,
                        FullName: 1,
                        GroupDepartmentName: 1,
                        Location: 1,
                        EndingDate: 1,
                        JobCode: 1,
                        JobLevel: 1,
                        UnionCode: 1,
                        BenefitStatus: 1,
                        MileagePlus: 1,
                        MailCD: 1,
                        HomeCountry: 1
                    }, {
                        lean: true,
                        sort: {
                            GroupId: 1,
                            MembershipStatus: 1,
                            LastName: 1
                        }
                    }).cursor({batchSize: 250}),
                    userInfoKey: result
                });
            });
        };
        this.ExportMembersUserInfo = function (params, callback) {
            var userInfoKey = {},
                cursor = EntityCache.UserInfo.find({
                    'Preference.DefaultGroupId' : params.GroupId
                }, {
                    _id: 0,
                    hgId: 1,
                    'UserPersonal.FullName': 1,
                    LowercaseUserName: 1,
                    'UserPersonal.PrimaryEmail': 1,
                    'Preference.HomeZip': 1,
                    'Preference.WorkZip': 1,
                    'Preference.SuppressBirthday': 1,
                    'Preference.SuppressAnniversary': 1,
                    FirstLogin: 1
                }, {
                    lean: true
                }).cursor({batchSize: 250});
            cursor.eachAsync(function (record) {
                userInfoKey[record.hgId] = {
                    FullName: record.UserPersonal.FullName,
                    UserName: record.LowercaseUserName,
                    Email: record.UserPersonal.PrimaryEmail,
                    HomeZip: record.Preference.HomeZip,
                    WorkZip: record.Preference.WorkZip,
                    SuppressBirthday: record.Preference.SuppressBirthday,
                    SuppressAnniversary: record.Preference.SuppressAnniversary,
                    FirstLogin: !record.FirstLogin || !record.FirstLogin.length ? '' : new Date(record.FirstLogin.sort(function (a, b) {
                        return a.LoginTime - b.LoginTime;
                    })[0].LoginTime)
                };
            }).then(function () {
                return callback(null, userInfoKey);
            });
        };
        this.GetMembersIndex = function (params, callback) {
            var memberKey = {},
                cursor = EntityCache.Member.find({
                    GroupId: params.GroupId,
                    MembershipStatus: {$in: params.Status || [EntityEnums.MembershipStatus.Active]}
                }, {
                    _id: 0,
                    hgId: 1,
                    GroupDepartmentName: 1,
                    'Location.Name': 1,
                    Position: 1,
                    FullName: 1,
                    MyManagers: 1,
                    RolesInGroup: 1,
                    MembershipStatus: 1,
                    EmployeeId: 1
                }, {sort: {FullName: 1}, lean: true}).cursor({batchSize: 250});
            cursor.eachAsync(function (record) {
                memberKey[record.hgId] = {
                    Status: record.MembershipStatus,
                    FullName: record.FullName,
                    Department: record.GroupDepartmentName,
                    Location: (record.Location && record.Location.Name) ? record.Location.Name : '',
                    Position: record.Position,
                    Manager: (record.MyManagers && record.MyManagers.length) ? record.MyManagers[0].FullName : '',
                    Role: record.RolesInGroup[0],
                    EmployeeId: record.EmployeeId
                };
            }).then(function () {
                return callback(null, memberKey);
            });
        };
        this.GetPreformRevivewDump = function (params) {
            var query = {
                    'Card.GroupId' : params.GroupId
                },
                project = {
                    StatusByAdminView : 1,
                    hgId : 1,
                    CycleId : 1,
                    CycleName : 1,
                    MeetingDate : 1,
                    'Card.Title' : 1,
                    'Card.GroupName' : 1,
                    'Peoples.PeopleType' : 1,
                    'Peoples.Anonymous' : 1,
                    'Peoples.SubmitDate' : 1,
                    'Peoples.StatusInCurrentReview' : 1,
                    'Peoples.UserId' : 1,
                    'Peoples.MemberId' : 1,
                    'Peoples.MemberFullname' : 1,
                    'Peoples.DeliveryDate' : 1,
                    'Peoples.EmployeeId' : 1,
                    'Peoples.Signature' : 1,
                    'Peoples.Department' : 1
                };
            return EntityCache.PerformanceReview.find(query, project, {lean: true, sort : {'Peoples.MemberFullname' : 1}}).cursor({batchSize: 250});
        };
        this.GetCreditCardTransactionReport = function (params, callback) {
            var query = {
                    Type : "CreditCard",
                    Status : "Complete",
                    CreatedDate : { $gte : params.StartDate, $lte : params.EndDate }
                };
            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            EntityCache.Transaction.find(query, function (error, data) {
                if (error) { return callback(error); }
                if (!data || data.length === 0) { return callback(null, []); }
                callback(null, data);
            });
        };
        this.GetCoachingComment = function (params, callback) {
            var entityIdKey = {},
                getCommenterName = function (key) {
                    var result = '';
                    if (params.MemberIndex[key]) {
                        result = params.MemberIndex[key].FullName;
                    }
                    return result;
                },
                coachingCommentStream = EntityCache.Comment.find({
                    CreatedDate: {$gte: params.StartDate, $lte: params.EndDate},
                    Status: 'Active',
                    EntityType: 'Coaching'
                }, {
                    EntityId: 1,
                    MemberId: 1,
                    CommenterLastName: 1,
                    CommenterFirstName: 1,
                    Comment: 1
                }).stream();
            coachingCommentStream.on('data', function (record) {
                if (!entityIdKey[record.EntityId]) {
                    entityIdKey[record.EntityId] = [];
                }
                entityIdKey[record.EntityId].push([getCommenterName(record.MemberId), ': ', record.Comment].join(''));
            });
            coachingCommentStream.on('close', function () {
                callback(null, entityIdKey);
            });
        };
        this.GetCoachingReport = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Type: 'Coaching',
                Status: { $in: ['Active', 'Draft']},
                CreatedDate: {$gte: params.StartDate, $lte: params.EndDate}
            };
            self.GetMembersIndex(params, function (error, memberIndex) {
                if (error) {
                    return callback(error);
                }
                params.MemberIndex = memberIndex;
                self.GetCoachingComment(params, function (error, result) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        MemberIndex: memberIndex,
                        CommentEntityHash: result,
                        coachingStream: EntityCache.Comment.find(query, {
                            hgId: 1,
                            MemberId: 1,
                            CommenterLastName: 1,
                            CommenterFirstName: 1,
                            'Recipient.MemberId': 1,
                            'Recipient.FullName': 1,
                            Header: 1,
                            Status: 1,
                            Comment: 1,
                            CreatedDate: 1
                        }, {
                            sort: {
                                CommenterLastName: 1
                            }
                        }).stream()
                    });
                });
            });
        };
        this.GetRedemptionActivity = function (params, callback) {
            var month = [],
                dataRecords = {},
                group = {
                    $group: {
                        _id: {
                            year: {'$year': '$delivered_at'},
                            month: {'$month': '$delivered_at'}
                        },
                        TotalCards: {$sum: 1},
                        TotalAmount: {$sum: '$amount'}
                    }
                };
            month = DateHelper.getCategoryDateRange('Monthly', new Date(params.StartDate), new Date(params.EndDate), true).Category;
            getRedeemptionData({ query : { $match: getFilterQuery(params) || {} }, group : group}, function (error, data) {
                if (error) { return callback(error); }
                data.map(function (item) {
                    dataRecords[item._id.year + '.' + item._id.month] = {
                        TotalCards : item.TotalCards,
                        TotalAmount : (item.TotalAmount / 100)
                    };
                });
                callback(null, {
                    Month : month,
                    data : dataRecords,
                    length : data.length
                });
            });
        };
        this.GetUserGroupPreferenceReport = function (params, callback) {
            // get all active members
            var query,
                activeUserIds = [],
                project = {
                    _id : 0,
                    UserId : 1
                },
                executeQuery = function (filter, iCallback) {
                    var groupQuery = {
                        $group : {
                            _id : { GroupId: "$Preference.DefaultGroupId"},
                            Total : { $sum :  1}
                        }
                    };
                    EntityCache.UserInfo.aggregate([{ $match : filter || {}}, groupQuery], function (error, result) {
                        return iCallback(error, result);
                    });
                };
            EntityCache.Group.find({Status : 'Active'}, {_id : 0, hgId : 1, GroupName: 1}, { sort: { GroupName : 1} }, function (error, groups) {
                if (error) { return callback(error); }
                EntityCache.Member.find({MembershipStatus : 'Active'}, project, function (error, memberIds) {
                    if (error) { return callback(error); }
                    activeUserIds = memberIds.map(function (item) { return item.UserId; });
                    query = { hgId : { $in : activeUserIds} };
                    //Get User Count
                    executeQuery(query, function (error, userCount) {
                        if (error) { return callback(error); }
                        // suppressed Birthdays
                        query = {
                            hgId : { $in : activeUserIds},
                            $or : [
                                { 'Preference.SuppressBirthday'  : {$exists : false}},
                                { 'Preference.SuppressBirthday'  : true}
                            ]
                        };
                        // Run Aggregation for Suppressed Birthdays
                        executeQuery(query, function (error, suppressedBirthdays) {
                            if (error) { return callback(error); }
                            //Suppressed Anniversary
                            query = {
                                hgId : { $in : activeUserIds},
                                $and : [
                                    { 'Preference.SuppressAnniversary'  : {$exists : true}},
                                    { 'Preference.SuppressAnniversary'  : true}
                                ]
                            };
                            executeQuery(query, function (error, suppressedAnniversary) {
                                if (error) { return callback(error); }
                                //Suppressed Both
                                query = {
                                    hgId : { $in : activeUserIds},
                                    $and : [{ 'Preference.SuppressAnniversary'  : {$exists : true}},
                                            { 'Preference.SuppressAnniversary'  : true},
                                            { 'Preference.SuppressBirthday'  : {$exists : true}},
                                            { 'Preference.SuppressBirthday'  : true}]
                                };
                                executeQuery(query, function (error, suppressedBoth) {
                                    if (error) { return callback(error); }
                                    // now compile results
                                    callback(null, {
                                        Group : groups,
                                        MemberCount : userCount,
                                        SuppressedBirthdays : suppressedBirthdays,
                                        SuppressedAnniversary : suppressedAnniversary,
                                        SuppressedBoth : suppressedBoth
                                    });
                                });
                            });
                        });
                    });
                });
            });
        };
        this.GetUnProcessedReports = function (params, callback) {
            EntityCache.Report.aggregate([
                {$match: {
                    Status: ReportEnums.Status.Processing
                }},
                {$group: {
                    _id: {
                        hgId: "$hgId",
                        RequesterMemberId: '$RequesterMemberId',
                        ReportName: '$ReportTypeName',
                        Diff:  {"$subtract": [Date.now(),  "$CreatedDate" ]}
                    }
                }},
                { $match: { '_id.Diff': { $gte: UNPROCESSED_REPORT_INTERVAL}}} // 1 hour
            ], callback);
        };
        this.ExpireUnProcessedReports = function (params, callback) {
            EntityCache.Report.update({
                hgId: params.hgId
            }, {
                $set: {
                    Status: ReportEnums.Status.Expired
                }
            }, callback);
        };
        this.GetOrdersByGroupIdStream = function (params) {
            return EntityCache.ProductOrder.find({
                'ProductItem.GroupId' : params.GroupId
            }, {}, {sort: {CreatedDate: -1}}).stream();
        };
        this.GetLocationsByGroupIdStream = function (params) {
            return EntityCache.Team.find({
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Location,
                Status: EntityEnums.TeamStatus.Active
            }, {}, {sort: {Name: -1}}).stream();
        };
        this.ExportHRISActivity = function (params) {
            var query = {
                'Content.Company.Name': {$exists: true},
                CreatedDate: {$gte: params.StartDate, $lte: params.EndDate}
            };
            if (params.GroupId) {
                query.GroupId = params.GroupId;
            }
            return EntityCache.ProvisionAudit.find(query, {
                'Content.Company.Name': 1,
                CreatedDate: 1,
                FullName: 1,
                FileName: 1,
                Type: 1
            }).stream();
        };
    };
module.exports = ReportProcessor;