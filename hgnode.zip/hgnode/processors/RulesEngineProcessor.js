/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    RulesEngineProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            RuleEnums = require('../enums/RuleEnums'),
            guid = require('node-uuid');

        this.DefaultEntityName = 'Rule';

        this.CreateRule = function (params, callback) {
            var rule = new EntityCache.Rule(params);
            rule.hgId = guid.v1();
            rule.CreatedBy = params.UserId;
            rule.ModifiedBy = params.UserId;
            rule.save(function (error) {
                callback(error, rule);
            });
        };
        this.GetRuleCountByEventType = function (params, callback) {
            EntityCache.Rule.count({
                EventType: params.EventType,
                Status: RuleEnums.Status.Active,
                GroupId: params.GroupId,
                TriggerConditions: {
                    $elemMatch: {
                        Min: params.Min,
                        Max: params.Max
                    }
                }
            }, callback);
        };
        this.GetRuleByEventType = function (params, callback) {
            EntityCache.Rule.findOne({
                GroupId : params.GroupId,
                Status : RuleEnums.Status.Active,
                EventType: params.EventType
            }, callback);
        };
        this.UpdateRule = function (params, callback) {
            EntityCache.Rule.findOneAndUpdate({
                hgId: params.RuleId
            }, {
                $set: {
                    RuleName: params.RuleName,
                    Description: params.Description,
                    DeltaType: params.DeltaType,
                    DeltaValue: params.DeltaValue,
                    ResetInterval: params.ResetInterval,
                    AllowedInterval: params.AllowedInterval,
                    FriendlyGroupId: params.FriendlyGroupId,
                    EventType: params.EventType,
                    SubjectType: params.SubjectType,
                    TriggerConditions: params.TriggerConditions,
                    TriggerTiming: params.TriggerTiming,
                    ResetAfterTrigger: params.ResetAfterTrigger,
                    TriggerConditionType: params.TriggerConditionType,
                    Scope: params.Scope
                }
            }, {
                new: true
            }, function (error, rule) {
                if (error) {
                    callback(error);
                } else if (!rule) {
                    callback('Rule does not exst. please verify the rule id is valid', null);
                } else {
                    EntityCache.MemberRule.update({'Rule.hgId' : params.RuleId}, {$set : {
                        'Rule.RuleName' : params.RuleName,
                        'Rule.Description' : params.Description,
                        'Rule.DeltaType' : params.DeltaType,
                        'Rule.DeltaValue' : params.DeltaValue,
                        'Rule.ResetInterval' : params.ResetInterval,
                        'Rule.AllowedInterval' : params.AllowedInterval,
                        'Rule.FriendlyGroupId' : params.FriendlyGroupId,
                        'Rule.EventType' : params.EventType,
                        'Rule.SubjectType' : params.SubjectType,
                        'Rule.TriggerConditions' : params.TriggerConditions,
                        'Rule.TriggerTiming' : params.TriggerTiming,
                        'Rule.ResetAfterTrigger' : params.ResetAfterTrigger,
                        'Rule.TriggerConditionType' : params.TriggerConditionType
                    }}, {multi : true}, function (error) {
                        callback(error, rule);
                    });
                }
            });
        };
        this.ArchiveRule = function (params, callback) {
            EntityCache.Rule.findOneAndUpdate({
                hgId: params.RuleId
            }, {
                $set: {
                    Status: RuleEnums.Status.Archived
                }
            }, {
                new: true
            }, function (error, rule) {
                if (error) {
                    callback(error, null);
                } else if (!rule) {
                    callback('Rule does not exst. please verify the rule id is valid', null);
                } else {
                    EntityCache.MemberRule.update({'Rule.hgId' : params.Rule}, {$set : {Status : RuleEnums.Status.Archived}}, {multi : true}, function (error) {
                        callback(error, rule);
                    });
                }
            });
        };
        this.GetRules = function (params, callback) {
            // service award is excluded from the list of rules due to having its own screen 
            EntityCache.Rule.find({GroupId : params.GroupId, Status : RuleEnums.Status.Active, EventType: {$ne: 'ServiceAward'}}, function (error, rules) {
                callback(error, rules);
            });
        };
        this.GetApplicableRules = function (params, callback) {
            var mainCondition = {
                    $and : [{
                        GroupId : params.GroupId,
                        EventType : params.EventType,
                        Status : RuleEnums.Status.Active
                    }]
                },
                locationCondition = {
                    $or : [
                        {'Scope.RestrictByLocation' : false},
                        {'Scope.Locations.hgId' : params.LocationId}
                    ]
                },
                deptCondition = {
                    $or : [
                        {'Scope.RestrictByDept' : false},
                        {'Scope.Departments.hgId' : params.DepartmentId}
                    ]
                };
            mainCondition.$and.push(locationCondition);
            mainCondition.$and.push(deptCondition);
            EntityCache.Rule.find(mainCondition, callback);
        };

        this.GetMemberRulesForReset = function (params, callback) {
            EntityCache.MemberRule.find({Status : RuleEnums.Status.Active, 'Rule.ResetInterval' : {$in : params.ResetTypes}}, function (error, memberRules) {
                callback(error, memberRules);
            });
        };

        this.GetOrCreateMemberRule = function (params, callback) {
            EntityCache.MemberRule.findOne({'Rule.hgId' : params.Rule.hgId, MemberId : params.Member.hgId}, function (error, memberRule) {
                if (!error && memberRule) {
                    callback(null, memberRule);
                } else {
                    var newMemberRule = new EntityCache.MemberRule({
                            hgId : guid.v1(),
                            Rule : params.Rule,
                            MemberId : params.Member.hgId,
                            UserId : params.Member.UserId,
                            MemberFullname : params.Member.FullName
                        });
                    if (params.CreatedBy) {
                        newMemberRule.CreatedBy = params.CreatedBy;
                    }
                    newMemberRule.save(function (error) {
                        if (error) {
                            callback('error saving newMemberRule', null);
                        } else {
                            callback(null, newMemberRule);
                        }
                    });
                }
            });
        };
        this.UpdateMemberRuleValue = function (params, callback) {
            EntityCache.MemberRule.update({hgId : params.MemberRuleId}, {$set : {CurrentValue : params.Value, ModifiedDate : new Date().getTime()}}, function (error) {
                callback(error, 'MemberRule value updated');
            });
        };
        this.UpdateMemberRuleForTrigger = function (params, callback) {//this is called only when the rule is triggered
            var history = {
                    Time : new Date().getTime(),
                    Value : params.CurrentValue,
                    ConditionId : params.ConditionId
                };
            EntityCache.MemberRule.update({hgId : params.MemberRuleId}, {$set : {CurrentValue : params.CurrentValue, ModifiedDate : new Date().getTime()}, $addToSet : {TriggerHistory : history}}, function (error) {
                callback(error, 'MemberRule value updated and trigger history logged');
            });
        };
        this.ResetMemberRuleForTrigger = function (params, callback) {//this is called only when the rule is triggered
            var history = {
                    Time : new Date().getTime(),
                    Value : params.CurrentValue,
                    ConditionId : params.ConditionId
                };
            EntityCache.MemberRule.update({hgId : params.MemberRuleId}, {$set : {CurrentValue : 0, ModifiedDate : new Date().getTime()}, $addToSet : {TriggerHistory : history}}, function (error) {
                callback(error, 'MemberRule value reset to 0 and trigger history logged');
            });
        };
        this.ResetMemberRuleByInterval = function (params, callback) {
            EntityCache.MemberRule.findOne({hgId : params.MemberRuleId}, function (error, memberRule) {
                if (error || !memberRule) {
                    callback('error loading memberRule', null);
                } else {
                    var history = {
                            Time : new Date().getTime(),
                            Value : memberRule.CurrentValue
                        };
                    EntityCache.MemberRule.update({hgId : params.MemberRuleId}, {$set : {CurrentValue : 0, ModifiedDate : new Date().getTime()}, $addToSet : {ResetHistory : history}}, function (error) {
                        callback(error, 'MemberRule value reset');
                    });
                }
            });
        };
    };

module.exports = RulesEngineProcessor;
