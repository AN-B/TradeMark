/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    MobileContentBuilder = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var NotificationsEnums = require('../../enums/NotificationsEnums.js'),
            supportedEvents = [
                NotificationsEnums.Event.RecognitionCommentReceived.Name,
                NotificationsEnums.Event.RecognitionReceived.Name,
                NotificationsEnums.Event.Birthday.Name,
                NotificationsEnums.Event.ConversationStarted.Name,
                NotificationsEnums.Event.ConversationComment.Name,
                NotificationsEnums.Event.FeedbackReceived.Name,
                NotificationsEnums.Event.FeedbackRequested.Name,
                NotificationsEnums.Event.GroupNewsPublished.Name,
                NotificationsEnums.Event.SurveyDelivered.Name,
                NotificationsEnums.Event.SurveyDueSoon.Name
            ],
            recognitionCommentReceived = function (params, callback) {
                var getMessage = function () {
                        var giverName = params.Data.Comment.CommenterFirstName,
                            text;
                        if (params.Data.RecognitionTitle) {
                            text = giverName + ' commented on your ' + params.Data.RecognitionTitle + ' badge.';
                        } else {
                            text = giverName + ' commented on your badge.';
                        }
                        return text;
                    },
                    content = {
                        ios: {
                            t: 'Comment',
                            e: params.Data.Comment.EntityId,
                            m: getMessage()
                        },
                        android: {
                            message: getMessage(),
                            title: 'Comment Received',
                            msgcnt: 1,
                            soundname: 'beep.wav',
                            t: 'Comment',
                            e: params.Data.Comment.EntityId
                        }
                    };
                callback(null, content);
            },
            birthdayNotification = function (params, callback) {
                var getMessage = function () {
                        return params.Data.user.UserContext.CurrentGroupName +
                            ' wants to wish you a Happy Birthday!';
                    },
                    content = {
                        ios: {
                            t: 'Birthday',
                            e: params.Data.recognition.BatchId,
                            m: getMessage()
                        },
                        android: {
                            message: getMessage(),
                            title: 'Birthday',
                            msgcnt: 1,
                            soundname: 'beep.wav',
                            t: 'Birthday',
                            e: params.Data.recognition.BatchId
                        }
                    };
                callback(null, content);
            },
            recognitionRecieved = function (params, callback) {
                var getMessage = function () {
                        var giverName,
                            text;
                        if (params.Data.Recognition.PublicCreatorInfo && params.Data.Recognition.PublicCreatorInfo.FullName) {
                            giverName = params.Data.Recognition.PublicCreatorInfo.FullName;
                        } else if (params.Data.Recognition.CreatorMember && params.Data.Recognition.CreatorMember.FullName) {
                            giverName = params.Data.Recognition.CreatorMember.FullName;
                        } else if (params.Data.Recognition.TriggerInfo && params.Data.Recognition.TriggerInfo.RuleName) {
                            giverName = params.Data.Recognition.TriggerInfo.RuleName;
                        } else {
                            giverName = '';
                        }
                        text = giverName + ' gave you ' + params.Data.Recognition.Template.Title + ' badge.';
                        return text;
                    },
                    content = {
                        ios: {
                            t: 'Recognition',
                            e: params.Data.Recognition.BatchId,
                            m: getMessage()
                        },
                        android: {
                            message: getMessage(),
                            title: 'Recognition Received',
                            msgcnt: 1,
                            soundname: 'beep.wav',
                            t: 'Recognition',
                            e: params.Data.Recognition.BatchId
                        }
                    };
                callback(null, content);
            },
            conversationNotification = function (params) {
                var type = params.NotificationEvent === NotificationsEnums.Event.ConversationStarted.Name ? 'Conversation' : 'ConversationMsg';
                return {
                    ios: {
                        t: type,
                        e: params.Data.Id,
                        m: params.Data.Message
                    },
                    android: {
                        message: params.Data.Message,
                        title: 'Message Received',
                        msgcnt: 1,
                        soundname: 'beep.wav',
                        t: type,
                        e: params.Data.Id
                    }
                };
            },
            newsNotification = function (params) {
                var type = 'News';
                return {
                    ios: {
                        t: type,
                        e: params.Data.BatchId,
                        m: params.Data.Title
                    },
                    android: {
                        message: params.Data.Title,
                        title: "Company News",
                        msgcnt: 1,
                        soundname: 'beep.wav',
                        t: type,
                        e: params.Data.BatchId
                    }
                };
            },
            surveyNotification = function (params) {
                var type = 'Survey';
                return {
                    ios: {
                        t: type,
                        e: params.Data.SurveyId,
                        m: 'Engagement Survey!'
                    },
                    android: {
                        message: "Engagement Survey!",
                        title: 'Company Survey',
                        msgcnt: 1,
                        soundname: 'beep.wav',
                        t: type,
                        e: params.Data.SurveyId
                    }
                };
            };

        this.SupportsContentBuild = function (params) {
            return (supportedEvents.indexOf(params.NotificationEvent) >= 0);
        };

        this.BuildContent = function (params, callback) {
            switch (params.NotificationEvent) {
            case NotificationsEnums.Event.RecognitionCommentReceived.Name:
                recognitionCommentReceived(params, callback);
                break;
            case NotificationsEnums.Event.Birthday.Name:
                birthdayNotification(params, callback);
                break;
            case NotificationsEnums.Event.RecognitionReceived.Name:
                recognitionRecieved(params, callback);
                break;
            case NotificationsEnums.Event.ConversationStarted.Name:
            case NotificationsEnums.Event.ConversationComment.Name:
            case NotificationsEnums.Event.FeedbackReceived.Name:
            case NotificationsEnums.Event.FeedbackRequested.Name:
                callback(null, conversationNotification(params));
                break;
            case NotificationsEnums.Event.GroupNewsPublished.Name:
                callback(null, newsNotification(params));
                break;
            case NotificationsEnums.Event.SurveyDelivered.Name:
            case NotificationsEnums.Event.SurveyDueSoon.Name:
                callback(null, surveyNotification(params));
                break;
            default:
                callback(null, '');
            }
        };
    };

module.exports = MobileContentBuilder;
