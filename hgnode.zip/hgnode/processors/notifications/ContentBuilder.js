/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    GeneralBuilder = require('./builders/GeneralBuilder.js'),
    GoalBuilder = require('./builders/GoalBuilder.js'),
    FeedbackBuilder = require('./builders/FeedbackBuilder.js'),
    GroupBuilder = require('./builders/GroupBuilder.js'),
    MotivateBuilder = require('./builders/MotivateBuilder.js'),
    PerformBuilder = require('./builders/PerformBuilder.js'),
    PrecompileBuilder = require('./builders/PrecompileBuilder.js'),
    RecapBuilder = require('./builders/RecapBuilder.js'),
    RecognizeBuilder = require('./builders/RecognizeBuilder.js'),
    TrackBuilder = require('./builders/TrackBuilder.js'),
    UserBuilder = require('./builders/UserBuilder.js'),
    VirtualCurrencyBuilder = require('./builders/VirtualCurrencyBuilder.js'),
    ProductBuilder = require('./builders/ProductBuilder.js'),
    ConversationBuilder = require('./builders/ConversationBuilder.js'),
    SurveyBuilder = require('./builders/SurveyBuilder.js'),
    ProvisionBuilder = require('./builders/ProvisionBuilder.js'),
    ContentBuilder = function () {
        'use strict';

        HgBaseProcessor.apply(this, arguments);

        var NotificationsEnums = require('../../enums/NotificationsEnums'),
            categories = NotificationsEnums.Category,
            HgLog = require('../../framework/HgLog'),
            EventEmitterCache = this.EventEmitterCache,
            BuilderModules = {},
            precompileBuilder = new PrecompileBuilder();    //not a notification enum type builder, so doesn't need to be in BuilderModules

        BuilderModules[categories.General] = new GeneralBuilder();
        BuilderModules[categories.Goal] = new GoalBuilder();
        BuilderModules[categories.Feedback] = new FeedbackBuilder();
        BuilderModules[categories.Group] = new GroupBuilder();
        BuilderModules[categories.Motivate] = new MotivateBuilder();
        BuilderModules[categories.Perform] = new PerformBuilder();
        BuilderModules[categories.Recap] = new RecapBuilder();
        BuilderModules[categories.Recognize] = new RecognizeBuilder();
        BuilderModules[categories.Track] = new TrackBuilder();
        BuilderModules[categories.User] = new UserBuilder();
        BuilderModules[categories.VirtualCurrency] = new VirtualCurrencyBuilder(EventEmitterCache);
        BuilderModules[categories.Survey] = new SurveyBuilder();
        BuilderModules[categories.Conversation] = ConversationBuilder;
        BuilderModules[categories.Product] = new ProductBuilder(EventEmitterCache);
        BuilderModules[categories.Provision] = new ProvisionBuilder();

        this.BuildContent = function (params, callback) {
            var notificationEnum = NotificationsEnums.Event[params.NotificationEvent],
                newParams = {
                    correlationId: params.correlationId,
                    Data: params.Data,
                    NotificationEvent: params.NotificationEvent,
                    EventName: params.EventName,
                    NotificationQueueItem: params.NotificationQueueItem,
                    NotificationQueueItems: params.NotificationQueueItems,
                    DispatchOption: params.DispatchOption,
                    CompleteCallback: params.CompleteCallback
                };

            if (BuilderModules[notificationEnum.Category]) {
                if (BuilderModules[notificationEnum.Category][notificationEnum.Name]) {
                    //call the builder function
                    BuilderModules[notificationEnum.Category][notificationEnum.Name](newParams, callback);
                } else {
                    HgLog.error('ContentBuilderV2: Did not find ' + notificationEnum.Category + '.' + notificationEnum.Name + ' method');
                    if (callback) {
                        callback(params.NotificationEvent + ' --- Notification ContentBuilder: Entity type not supported for email.', null);
                    }
                }
            } else {
                HgLog.error('ContentBuilderV2: Did not find ' + notificationEnum.Category + ' builder');
                throw new Error('ContentBuilder did not find ' + notificationEnum.Category + ' builder');
            }
        };

        this.PrecompileWeeklyGroupContent = function (params, callback) {
            precompileBuilder.PrecompileWeeklyGroupContent(params, callback);
        };

        this.PrecompileGroupContent = function (params, callback) {
            precompileBuilder.PrecompileGroupContent(params, callback);
        };
    };

module.exports = ContentBuilder;
