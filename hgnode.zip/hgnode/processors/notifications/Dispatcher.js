/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    Dispatcher = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var config = require('../../configurations/config.js'),
            KeyStore = require('../../configurations/keystore.js'),
            HgLog = require('../../framework/HgLog'),
            request = require('request'),
            EntityCache = require('../../framework/EntityCache.js'),
            exceptionNotifyer = require('../../framework/ExceptionNotifier.js'),
            NotificationsEnums = require('../../enums/NotificationsEnums.js'),
            MemberEnums = require('../../enums/MemberEnums.js'),
            Async = require('async'),
            self = this,
            apn = require('apn'),
            gcm = require('node-gcm'),
            getActualAddress = function (originalAddress) {
                var actualAddress = originalAddress;
                if (process.env.BUILD_ENV !== 'prod') {
                    actualAddress = process.env.REDIRECT_ADDRESS || config.email.FromAddress;
                }
                return actualAddress;
            },
            sanitizeRecipientByEnvironment = function (emailRequest) {
                var originalAddress = emailRequest.to;
                if (process.env.BUILD_ENV !== 'prod') {
                    emailRequest.to = getActualAddress(originalAddress);
                    HgLog.debug(originalAddress + ' is changed to ' +  emailRequest.to);
                }
            },
            resolveAction = function (serverResponse) {
                var jsonObj;
                if (serverResponse && serverResponse.indexOf('email queued') > -1 && serverResponse.indexOf('success') > -1) {
                    return NotificationsEnums.Action.SuccessfulAndRemove;
                }
                if (serverResponse && serverResponse.indexOf('413 Request Entity Too Large') > -1) {
                    return NotificationsEnums.Action.RequestEntityTooLarge;
                }
                if (!serverResponse || (serverResponse.indexOf('503') > -1 && serverResponse.indexOf('html') > -1)) {//server returned undefined/null response, should retry
                    return NotificationsEnums.Action.Retry;
                }
                if (serverResponse.code === 503) {
                    return NotificationsEnums.Action.Retry;
                }
                try {
                    jsonObj = JSON.parse(serverResponse);
                    if (jsonObj.code === 503) {
                        return NotificationsEnums.Action.Retry;
                    }
                } catch (e) {
                    HgLog.debug("Not json: ", serverResponse);
                    return NotificationsEnums.Action.FailedAndRemove;
                }
                if (serverResponse && serverResponse.indexOf('missing value for:') > -1) {
                    return NotificationsEnums.Action.ModifyPayload;
                }
                return NotificationsEnums.Action.FailedAndRemove;
            },
            modifyPayload = function (notificationQueueItem, serverResponse) {
                var indicatorString = 'missing value for:',
                    start = serverResponse.indexOf(indicatorString),
                    remaining,
                    fields;
                start += indicatorString.length;
                remaining = serverResponse.substring(start, serverResponse.length);
                remaining = remaining.replace('"}', '');
                remaining = remaining.replace(new RegExp('\'', 'g'), '');
                fields = remaining.split(', ');
                fields.forEach(function (field) {
                    notificationQueueItem.MergeFields[field] = '';
                });
            };

        this.DispatchMobile = function (params, callback) {
            var apnConnection = new apn.Connection({
                    gateway: config.device.ios.gateway,
                    cert: config.device.ios.cert,
                    key: config.device.ios.key,
                    passphrase: config.device.ios.passphrase,
                    connectionRetryLimit: process.env.APN_CONNECT_RETRY_LIMIT || 10
                }),
                gcmSender = new gcm.Sender(config.device.android.APIKey),
                apnNotification,
                gcmMessage;
            // Trapping error to prevent server crash on connection timeouts, etc
            apnConnection.on("error", function (err) {
                if (err && err.message && err.message.indexOf('time') > -1) {
                    HgLog.debug('APNConnection timeout: ' + err);
                } else {
                    HgLog.error('APNConnection error: ' + err);
                }
            });
            params.Recipients.forEach(function (recipient) {
                if (recipient.DevicePlatform === 'iOS' && recipient.DeviceToken) {
                    apnNotification = new apn.Notification();
                    if (params.Content.ios.m) {
                        apnNotification.sound = "ping.aiff";
                    }
                    apnNotification.payload = params.Content.ios;
                    apnNotification.setAlertText(params.Content.ios.m);
                    apnNotification.badge = recipient.UnreadMessageNumber + 1;
                    apnConnection.pushNotification(apnNotification, recipient.DeviceToken);
                } else if (recipient.DevicePlatform === 'Android' && recipient.RegistrationId && recipient.RegistrationId.length > 20) {
                    gcmMessage = new gcm.Message({
                        collapseKey: params.correlationId,
                        delayWhileIdle: true,
                        timeToLive: 3,
                        data: params.Content.android
                    });
                    gcmSender.send(gcmMessage, [recipient.RegistrationId], 3, function (err) {
                        if (err) {
                            HgLog.error({methodName: 'DispatchMobile', error: err});
                        }
                    });
                }
            });
            callback(null, 'DispatchMobile done');
        };

        this.DispatchEmails = function (params) {
            var notificationQueueItems = params.NotificationQueueItems,
                len = notificationQueueItems ? notificationQueueItems.length : 0;
            Async.whilst(
                function () {
                    len -= 1;
                    return len > -1;
                },
                function (callback) {
                    self.DispatchEmail({
                        NotificationQueueItem : notificationQueueItems[len],
                        AsyncCallback: callback
                    });
                },
                function (err) {
                    if (global && global.gc) {
                        global.gc();
                    } else {
                        HgLog.debug('Garbage collector not exposed.');
                    }
                    if (err) {
                        HgLog.error({methodName: 'DispatchEmails', error: err});
                    } else {
                        HgLog.debug('Sent ' + notificationQueueItems.length + ' emails');
                    }
                }

            );
        };

        this.DispatchEmail = function (params) {
            var notificationQueueItem = params.NotificationQueueItem,
                len = (notificationQueueItem && notificationQueueItem.RecipientList) ? notificationQueueItem.RecipientList.length : 0,
                body,
                recipient,
                notificationAudit,
                emailCallback = function (error, response, epbody) {
                    notificationQueueItem.AttemptNumber += 1;
                    notificationAudit = new EntityCache.NotificationAudit(notificationQueueItem);
                    notificationAudit = notificationAudit.toObject();
                    notificationAudit.Environment = process.env.BUILD_ENV;
                    notificationAudit.ActualAddress = body.to;
                    notificationAudit.ServerResponse = epbody;
                    notificationAudit.Action = resolveAction(epbody);
                    EntityCache.NotificationAudit.create(notificationAudit);
                    if (notificationAudit.Action === 'ModifyPayload') {
                        modifyPayload(notificationQueueItem, epbody);
                        notificationQueueItem.LockedForDispatching = false;
                        notificationQueueItem.markModified('LockedForDispatching');
                        notificationQueueItem.markModified('MergeFields');
                        notificationQueueItem.save();
                    } else if (notificationAudit.Action === 'Retry') {
                        notificationQueueItem.LockedForDispatching = false;
                        notificationQueueItem.markModified('LockedForDispatching');
                        notificationQueueItem.save();
                    } else if (notificationAudit.Action === 'RequestEntityTooLarge') {
                        exceptionNotifyer(new Error('Request Entity Too Large for EP, hgId: ' + notificationAudit.hgId));
                        notificationQueueItem.remove();
                    } else {
                        notificationQueueItem.remove();
                    }
                },
                resolveClickTrackingAndSanitizing = function (email, callback) {
                    var sendRealEmails = process.env.BUILD_ENV === 'prod',
                        exclusionList = [
                            "alerts@highground.com",
                            "operations@highground.com",
                            "refund@highground.com",
                            "qaerrors@highground.com",
                            "billing@highground.com"
                        ];
                    if (exclusionList.indexOf(email.toLowerCase()) > -1) {
                        return callback({
                            clickTracking: false,
                            sendRealEmails: sendRealEmails,
                            groupIsActive: true,
                            userDisabledEmail: false,
                            memberIsActive: true
                        });
                    }
                    EntityCache.UserInfo.findOne({'UserPersonal.PrimaryEmail': email}, function (error, userInfo) {
                        if (error || !userInfo || !userInfo.Preference || !userInfo.Preference.DefaultGroupId) {
                            return callback({
                                clickTracking: false,
                                sendRealEmails: sendRealEmails,
                                groupIsActive: true,
                                userDisabledEmail: false,
                                memberIsActive: false
                            });
                        }
                        EntityCache.Member.findOne({
                            UserId: userInfo.hgId,
                            GroupId: userInfo.Preference.DefaultGroupId
                        }, function (error, member) {
                            if (error || !member || member.MembershipStatus === MemberEnums.Status.InActive) {
                                return callback({
                                    clickTracking: false,
                                    sendRealEmails: sendRealEmails,
                                    groupIsActive: true,
                                    userDisabledEmail: false,
                                    memberIsActive: false
                                });
                            }
                            EntityCache.NotificationPreference.aggregate([
                                {$match: {
                                    UserId: userInfo.hgId,
                                    GroupId: userInfo.Preference.DefaultGroupId
                                }},
                                {$unwind: "$Categories"},
                                {$match: {
                                    'Categories.Category': params.NotificationQueueItem.Category,
                                    'Categories.Name': params.NotificationQueueItem.Name,
                                    'Categories.Delivery.Email': false
                                }}
                            ], function (error, userDisabledEmail) {
                                if (error || userDisabledEmail.length) {
                                    return callback({
                                        clickTracking: false,
                                        sendRealEmails: sendRealEmails,
                                        groupIsActive: true,
                                        userDisabledEmail: true,
                                        memberIsActive: true
                                    });
                                }
                                EntityCache.Group.findOne({hgId: userInfo.Preference.DefaultGroupId}, function (error, group) {
                                    var i;
                                    if (error || !group || !group.Preference || !group.Preference.FeatureFlags) {
                                        callback({
                                            clickTracking: false,
                                            sendRealEmails: sendRealEmails,
                                            groupIsActive: true,
                                            memberIsActive: true,
                                            userDisabledEmail: !!userDisabledEmail.length
                                        });
                                    } else if (group.Status !== 'Active') {
                                        callback({
                                            clickTracking: false,
                                            sendRealEmails: sendRealEmails,
                                            groupIsActive: false,
                                            memberIsActive: true,
                                            fromName: (group.ProgramName || group.GroupName) + ' ' + config.email.FromName,
                                            userDisabledEmail: !!userDisabledEmail.length
                                        });
                                    } else {
                                        for (i = 0; i < group.Preference.FeatureFlags.length; i += 1) {
                                            //  only allow demo to set the sendRealEmails flag
                                            if (group.Preference.FeatureFlags[i].FeatureName === 'SendRealEmails' &&
                                                    group.Preference.FeatureFlags[i].FeatureEnabled && process.env.BUILD_ENV === 'demo') {
                                                sendRealEmails = true;
                                            }
                                        }
                                        callback({
                                            clickTracking: false,
                                            sendRealEmails: sendRealEmails,
                                            groupIsActive: true,
                                            memberIsActive: true,
                                            fromName: (group.ProgramName || group.GroupName) + ' ' + config.email.FromName,
                                            userDisabledEmail: !!userDisabledEmail.length
                                        });
                                    }
                                });
                            });
                        });
                    });
                };
            if (len < 1) {
                notificationQueueItem.remove();
                if (params.AsyncCallback) {
                    params.AsyncCallback();
                }
                return;
            }
            recipient = notificationQueueItem.RecipientList[0].Address;
            if (!notificationQueueItem.MergeFields.first_name || notificationQueueItem.MergeFields.first_name.trim().length < 1) {
                notificationQueueItem.MergeFields.first_name = notificationQueueItem.RecipientList[0].Name;
            }
            resolveClickTrackingAndSanitizing(recipient, function (resolvedData) {
                var sendRealEmails = resolvedData.sendRealEmails || false,
                    groupIsActive = resolvedData.groupIsActive || false,
                    userDisabledEmail = resolvedData.userDisabledEmail || false,
                    memberIsActive = resolvedData.memberIsActive || false,
                    fromName = notificationQueueItem.MergeFields.sender_program_name || ('HighGround ' + config.email.FromName);
                if (process.env.SUPPRESS_EMAIL_DISPATCHING === 'yes') {
                    notificationAudit = new EntityCache.NotificationAudit(notificationQueueItem);
                    notificationAudit = notificationAudit.toObject();
                    notificationAudit.Environment = process.env.BUILD_ENV;
                    notificationAudit.ActualAddress = '';
                    notificationAudit.ServerResponse = 'Email is suppressed on this server';
                    notificationAudit.Action = NotificationsEnums.Action.FailedAndRemove;
                    EntityCache.NotificationAudit.create(notificationAudit);
                    notificationQueueItem.remove();
                    if (params.AsyncCallback) {
                        setTimeout(function () {
                            params.AsyncCallback();
                        }, config.DispatchEmailInterval);
                    }
                    HgLog.debug('Not sent to server because Email is suppressed on this server');
                } else if (!memberIsActive) {
                    notificationAudit = new EntityCache.NotificationAudit(notificationQueueItem);
                    notificationAudit = notificationAudit.toObject();
                    notificationAudit.Environment = process.env.BUILD_ENV;
                    notificationAudit.ActualAddress = '';
                    notificationAudit.ServerResponse = 'Not sent to server because member is not active';
                    notificationAudit.Action = NotificationsEnums.Action.FailedAndRemove;
                    EntityCache.NotificationAudit.create(notificationAudit);
                    notificationQueueItem.remove();
                    if (params.AsyncCallback) {
                        setTimeout(function () {
                            params.AsyncCallback();
                        }, config.DispatchEmailInterval);
                    }
                    HgLog.debug('Not sent to server because member is not active');
                } else if (!groupIsActive) {
                    notificationAudit = new EntityCache.NotificationAudit(notificationQueueItem);
                    notificationAudit = notificationAudit.toObject();
                    notificationAudit.Environment = process.env.BUILD_ENV;
                    notificationAudit.ActualAddress = '';
                    notificationAudit.ServerResponse = 'Not sent to server because this is a disabled group';
                    notificationAudit.Action = NotificationsEnums.Action.FailedAndRemove;
                    EntityCache.NotificationAudit.create(notificationAudit);
                    notificationQueueItem.remove();
                    if (params.AsyncCallback) {
                        setTimeout(function () {
                            params.AsyncCallback();
                        }, config.DispatchEmailInterval);
                    }
                    HgLog.debug('Not sent to server because this is a disabled group');
                } else if (userDisabledEmail) {
                    notificationAudit = new EntityCache.NotificationAudit(notificationQueueItem);
                    notificationAudit = notificationAudit.toObject();
                    notificationAudit.Environment = process.env.BUILD_ENV;
                    notificationAudit.ActualAddress = '';
                    notificationAudit.ServerResponse = 'Not sent to server because user disabled email notification';
                    notificationAudit.Action = NotificationsEnums.Action.FailedAndRemove;
                    EntityCache.NotificationAudit.create(notificationAudit);
                    notificationQueueItem.remove();
                    if (params.AsyncCallback) {
                        setTimeout(function () {
                            params.AsyncCallback();
                        }, config.DispatchEmailInterval);
                    }
                    HgLog.debug('Not sent to server because user disabled email notification');
                } else {
                    body = {
                        template_id: notificationQueueItem.TemplateId,
                        reply_to: notificationQueueItem.ReplyTo || config.email.FromAddress,
                        from: fromName,
                        to: recipient,
                        subject: notificationQueueItem.Subject,
                        merge_fields: notificationQueueItem.MergeFields,
                        click_tracking: false,
                        suppress_address: true
                    };
                    if (!sendRealEmails) {
                        sanitizeRecipientByEnvironment(body);
                    }
                    EntityCache.NotificationAudit.count({
                        hgId: notificationQueueItem.hgId,
                        Action: 'SuccessfulAndRemove'
                    }, function (error, count) {
                        if (!error || !count) {
                            if (!KeyStore.expresspigeon_api) {
                                notificationQueueItem.remove();
                                process.nextTick(emailCallback);
                            } else {
                                request.post({
                                    headers: {
                                        'X-auth-key' : KeyStore.expresspigeon_api,
                                        'content-type' : 'application/json'
                                    },
                                    url: 'https://api.expresspigeon.com/messages',
                                    body: JSON.stringify(body)
                                }, emailCallback);
                            }
                        } else {
                            notificationQueueItem.remove();
                            HgLog.debug('Not sent to server because this is a duplicate');
                        }
                        if (params.AsyncCallback) {
                            setTimeout(function () {
                                params.AsyncCallback();
                            }, config.DispatchEmailInterval);
                        }
                    });
                }
            });
        };
    };

module.exports = Dispatcher;
