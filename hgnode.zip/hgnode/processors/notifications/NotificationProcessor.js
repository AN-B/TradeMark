/*jslint node:true es5:true*/
'use strict';
var EntityCache = require('../../framework/EntityCache.js'),
    guid = require('node-uuid'),
    config = require('../../configurations/config.js'),
    NotificationsEnums = require('../../enums/NotificationsEnums.js'),
    HgError = require('../../common/HgError.js'),
    Async = require('async');

function UpdateAlertTitleByEventTypeNameAndEntityId(params) {
    EntityCache.Notification.update({
        EntityId: params.EntityId,
        'Event.Name': params.EventTypeName
    }, {
        $set: {Title: params.AlertTitle}
    }, {
        multi: true
    }).exec();
}
function Remove(params, callback) {
    EntityCache.Notification.update({
        RecipientId: params.RecipientId,
        hgId: params.hgId
    }, {
        $set: {
            Show: false,
            Deleted: true
        }
    }, callback);
}

function RemoveAll(params, callback) {
    var query = {
        RecipientId: params.RecipientId
    };
    if (params.Type && params.Type !== 'All') {
        query.Type = params.Type;
    }
    EntityCache.Notification.update(query, {$set: {
        Show: false,
        Deleted: true
    }}, { multi: true }, function (error) {
        if (error) {
            callback(HgError.Enums.Notification.ErrorUpdating);
        } else {
            callback(null, 'business.not.pro.nrd');
        }
    });
}

function RemoveImportantNotificationsAll(params, callback) {
    var query = {
        RecipientId: params.RecipientId,
        Important: true
    };
    if (params.Type && params.Type !== 'All') {
        query.Type = params.Type;
    }
    EntityCache.Notification.update(query, {$set: {
        Show: false,
        Deleted: true
    }}, { multi: true }, function (error) {
        if (error) {
            callback(HgError.Enums.Notification.ErrorUpdating);
        } else {
            callback(null, 'business.not.pro.nrd');
        }
    });
}

function GetByRecipientId(params, callback) {
    var query = {
            RecipientId: params.RecipientId,
            Deleted: false
        },
        aggregationQuery = [
            {$match: query},
            {$sort: {CreatedDate: -1}},
            {$group: {
                _id: {
                    year: {$year: '$Date'},
                    month: { $month: '$Date'},
                    day: { $dayOfMonth: '$Date'}
                },
                rows : {$push: {
                    Date: '$Date',
                    CreatedDate: '$CreatedDate',
                    Event: '$Event',
                    IssuerFillName: '$IssuerFillName',
                    Type: '$Type',
                    hgId: '$hgId',
                    ActionUrl: '$ActionUrl',
                    Title: '$Title',
                    Notes: '$Notes'
                }},
                hgIds: { $push: {
                    hgId: '$hgId'
                }}
            }},
            {$sort: {'rows.CreatedDate': -1}},
            {$skip: parseInt(params.Skip, 10) || 0},
            {$limit: parseInt(params.Take, 10) || 10}
        ];
    if (params.Type && params.Type !== 'All') {
        query.Type = params.Type;
    }
    EntityCache.Notification.aggregate(aggregationQuery, function (error, data) {
        var hgIdArray = [];
        if (error) {
            return callback(error);
        }
        data.forEach(function (item) {
            item.hgIds.forEach(function (rItem) {
                hgIdArray.push(rItem.hgId);
            });
        });
        EntityCache.Notification.update({
            hgId: {$in: hgIdArray},
            RecipientId: params.RecipientId,
            Viewed: false
        }, {$set: {
            Viewed: true
        }}, {multi: true}, function (err) {
            if (err) {
                return callback(err);
            }
            callback(null, data);
        });
    });
}

function GetUnViewedRecognitionNotifications(params, callback) {
    var query = {
        RecipientId: params.RecipientId,
        'Event.Name': 'RecognitionReceived',
        Viewed: false,
        Deleted: false
    };
    EntityCache.Notification.find(query, null, {limit: 10, sort: {CreatedDate : -1}}, function (error, notifications) {
        if (error) {
            return callback(error);
        }
        if (notifications.length === 0 || !params.UpdateViewedNotifications) {
            return callback(null, notifications);
        }
        query = {
            RecipientId: params.RecipientId,
            'Event.Name': 'RecognitionReceived'
        };
        EntityCache.Notification.update(query, {
            $set: {
                Viewed: true,
                ModifiedBy: params.UserId
            }
        }, {multi: true}, function (error) {
            callback(error, notifications);
        });
    });
}

function TransferManagerNotification(params, fcallback) {
    var pusherArray = [];
    function findMember(reviewId, scallback) {
        EntityCache.Notification.update({
            RecipientGroupId: params.params.GroupId,
            RecipientId: params.params.OldManager.hgId,
            Deleted: false,
            ActionUrl: '#/Profile/Perform/' + params.params.OldManager.hgId + '/' + reviewId
        }, {$set: {
            RecipientId: params.params.NewManager.hgId,
            ActionUrl: '#/Profile/Perform/' + params.params.NewManager.hgId + '/' + reviewId,
            Viewed: false
        }}, {multi: true}, function (error, count) {
            if (error) {
                return scallback(error);
            }
            if (count) {
                pusherArray.push({
                    UserId: params.params.OldManager.UserId,
                    DeltaCount: -count
                });
                pusherArray.push({
                    UserId: params.params.NewManager.UserId,
                    DeltaCount: count
                });
            }
            scallback();
        });
    }
    if (!params.ReviewIds || params.ReviewIds.length === 0) {
        return fcallback(null, pusherArray);
    }
    Async.each(params.ReviewIds, findMember, function (error) {
        fcallback(error, pusherArray);
    });
}


function ViewNotification(params, callback) {
    EntityCache.Notification.update({
        hgId: params.hgId,
        Viewed: false
    }, {$set: {
        Viewed: true
    }}, {multi: true}, function (err) {
        if (err) {
            callback(HgError.Enums.Notification.ErrorLoading);
        } else {
            callback(null, params.hgId);
        }
    });
}

function CountByImportantNotifications(params, callback) {
    EntityCache.Notification.count({
        RecipientId: params.RecipientId,
        Deleted: false,
        Important: true
    }, function (error, count) {
        if (error) {
            return callback(HgError.Enums.Notification.ErrorLoading);
        }
        callback(null, count);
    });
}

function CreateBatch(params, callback) {
    EntityCache.Notification.create(params.NotificationItems, function (error) {
        if (error) {
            callback(error);
        } else {
            callback(null, 'Notifications Added');
        }
    });
}

function Create(params, callback) {
    var notification = EntityCache.Notification({
        hgId: guid.v1(),
        Title: params.Title,
        Type: params.Type,
        EntityId: params.EntityId,
        Event: params.NotificationEvent,
        IssuerId: params.IssuerId,
        IssuerFillName: params.IssuerFillName,
        RecipientId: params.RecipientId,
        RecipientGroupId: params.RecipientGroupId,
        ActionUrl: params.ActionUrl,
        Notes: params.Notes,
        Important: params.Important
    });
    notification.save(function (err) {
        if (err) {
            callback(HgError.Enums.Notification.ErrorCreating);
        } else {
            notification.RecipientUserId = params.RecipientUserId;
            callback(null, notification);
        }
    });
}

function SaveMobileNotificationItems(params) {
    EntityCache.MobileNotificationItem.create(params.UserIds.map(function (userId) {
        return {
            hgId: guid.v1(),
            UserId: userId,
            Content: params.Content
        };
    }));
}

function GetUnreadMobileNotifications(params, callback) {
    EntityCache.MobileNotificationItem.find({ UserId: params.UserId, Viewed: false})
        .limit(parseInt(params.Take || 0, 10))
        .skip(parseInt(params.Skip || 0, 10))
        .exec(function (error, items) {
            if (error) {
                return callback(error);
            }
            if (!items.length) {
                return callback(null, []);
            }
            EntityCache.MobileNotificationItem.update({hgId: {
                $in: items.map(function (item) {
                    return item.hgId;
                })
            }}, {
                $set: {
                    Viewed: true
                }
            }, {multi: true}, function (error) {
                callback(error, items);
            });
        });
}

function GetNotificationAuditById(params, callback) {
    EntityCache.NotificationAudit.findOne({hgId: params.hgId}, callback);
}

function GetNotificationAudit(params, callback) {
    var mquery = EntityCache.NotificationAudit.find({'RecipientList.Address': {$regex: params.Email, $options: 'i'}}),
        sort = {CreatedDate: -1};
    if (params.StartDate && params.EndDate) {
        mquery.where({ CreatedDate: { $gte: params.StartDate, $lte: params.EndDate }});
    }
    if (params.Subject) {
        mquery.where({Subject: {$regex: '.*' + params.Subject + '.*', $options: 'i'}});
    }
    if (params.TemplateId) {
        mquery.where({TemplateId: params.TemplateId});
    }
    mquery.limit(params.Take).skip(params.Skip).sort(sort).exec(function (error, data) {
        if (error) {
            callback(error);
        } else {
            callback(null, data);
        }
    });
}

function AddNotificationQueueItem(params, callback) {
    var notificationQueueItem = EntityCache.NotificationQueueItem(params);
    notificationQueueItem.save(function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, 'Notification Queue Item');
    });
}

function DeleteNotificationByEventTypeNameAndRecipientId(params, callback) {
    EntityCache.Notification.update({
        EntityId: params.EntityId,
        'Event.Name': params.EventTypeName,
        Deleted: false,
        RecipientId: params.RecipientId
    }, {$set: {
        Show: false,
        Deleted: true
    }}, {multi: true}).exec(callback);
}

function DeleteNotificationByEventTypeNameAndEntityId(params, callback) {
    EntityCache.Notification.update({
        EntityId: params.EntityId,
        'Event.Name': params.EventTypeName,
        Deleted: false,
        RecipientUserId: params.UserId
    }, {$set: {
        Show: false,
        Deleted: true
    }}, {multi: true}).exec(callback);
}

function DeleteNotificationByEventTypeNameAndEntityIds(params, callback) {
    EntityCache.Notification.update({
        EntityId: {$in: params.EntityIds},
        'Event.Name': params.EventTypeName,
        Deleted: false,
        RecipientUserId: params.UserId
    }, {$set: {
        Show: false,
        Deleted: true
    }}, {multi: true}).exec(callback);
}

function DeleteNotificationByEntityId(params, callback) {
    EntityCache.Notification.update({
        EntityId: { $in: params.EntityIds || [params.EntityId] },
        Deleted: false,
        RecipientUserId: params.UserId
    }, {$set: {
        Show: false,
        Deleted: true
    }}, {multi: true}).exec(callback);
}

function ReplaceRecipientByEntityId(params, callback) {
    var updateObject = {
            RecipientUserId: params.NewUserId,
            RecipientId: params.NewMemberId
        };
    if (params.NewActionUrl) {
        updateObject.ActionUrl = params.NewActionUrl;
    }
    EntityCache.Notification.update({
        EntityId: params.EntityId,
        Deleted: false,
        RecipientUserId: params.OldUserId
    }, {$set: updateObject}, {multi: true}).exec(callback);
}

function RestoreNotificationByEventTypeNameAndEntityId(params, callback) {
    EntityCache.Notification.update({
        EntityId: params.EntityId,
        'Event.Name': params.EventTypeName,
        Deleted: true,
        RecipientUserId: params.UserId
    }, {$set: {
        Show: true,
        Deleted: false
    }}, {multi: true}).exec(callback);
}

function RemoveNotificationByActionUrl(params, callback) {
    EntityCache.Notification.update({
        ActionUrl: params.ActionUrl,
        IssuerId: params.IssuerId
    }, {$set: {
        Show: false,
        Deleted: true
    }}, {multi: true}, function (err, res) {
        if (callback) {
            callback(err, res);
        }
    });
}
function GetImportantNotificationsByLimits(params, fcallback) {
    var query = {
        RecipientId: params.RecipientId,
        Deleted: false,
        Important: true
    };
    Async.parallel({
        count: function (callback) {
            EntityCache.Notification.count(query, callback);
        },
        notifications: function (callback) {
            EntityCache.Notification.aggregate([
                {$match: query},
                {$sort: {_id: -1}},
                {$limit: params.Take}
            ], function (error, notifications) {
                if (error) {
                    return callback(error);
                }
                if (!notifications.length) {
                    return callback(null, []);
                }
                EntityCache.Notification.update({
                    hgId: {
                        $in: notifications.map(function (notification) {
                            return notification.hgId;
                        })
                    },
                    RecipientId: params.RecipientId,
                    Viewed: false
                }, {
                    $set: {
                        Viewed: true
                    }
                }, {multi: true}, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, notifications);
                });
            });
        }
    }, function (error, result) {
        if (error) {
            return fcallback(error);
        }
        fcallback(null, {
            totalCount: result.count,
            data: result.notifications
        });
    });
}

function GetNotificationsByRecipientId(params, callback) {
    EntityCache.Notification.aggregate([{
        $match: {
            RecipientId: params.RecipientId,
            Deleted: false,
            Important: true
        }
    },
        {$sort: {CreatedDate: -1}},
        {
            $group: {
                _id: {
                    year: {$year: '$Date'},
                    month: {$month: '$Date'},
                    day: {$dayOfMonth: '$Date'}
                },
                rows: {
                    $push: {
                        Date: '$Date',
                        CreatedDate: '$CreatedDate',
                        Event: '$Event',
                        IssuerFillName: '$IssuerFillName',
                        IsMultiManager: '$IsMultiManager',
                        IsReviewee: '$IsReviewee',
                        Type: '$Type',
                        hgId: '$hgId',
                        ActionUrl: '$ActionUrl',
                        EntityId: '$EntityId',
                        Title: '$Title',
                        Notes: '$Notes',
                        RecipientId: '$RecipientId'
                    }
                },
                hgIds: {
                    $push: {
                        hgId: '$hgId'
                    }
                }
            }
        },
        {$sort: {'rows.CreatedDate': -1}}],
        function (readError, notifications) {
            var hgIds = [];
            if (readError) {
                return callback(readError);
            }
            notifications.forEach(function (notification) {
                hgIds = hgIds.concat(notification.hgIds.map(function (hgIds) {
                    return hgIds.hgId;
                }));
            });
            EntityCache.Notification.update({
                hgId: {$in: hgIds},
                RecipientId: params.RecipientId,
                Viewed: false
            }, {$set: {
                Viewed: true
            }}, {multi: true}, function (updateError) {
                if (updateError) {
                    return callback(updateError);
                }
                callback(null, notifications);
            });
        });
}

function RemoveImportantNotificationByActionUrl(params, callback) {
    EntityCache.Notification.update({
        RecipientId: params.MemberId,
        Deleted: false,
        ActionUrl: params.ActionUrl
    }, {$set: {
        Deleted: true
    }}, {multi: true}, callback);
}

function UpdateNotificationCycleTitle(params, callback) {
    EntityCache.Notification.update({
        RecipientGroupId: params.GroupId,
        EntityId: {$in: params.ReviewIds}
    }, {
        $set: {
            ModifiedDate: Date.now(),
            Title: "A review in the '" + params.NewTitle + "' cycle requires your completion."
        }
    }, {
        multi: true
    }, callback);
}

function SaveNotificationPreference(params, callback) {
    EntityCache.NotificationPreference.findOne({MemberId: params.MemberId, GroupId: params.GroupId}, function (error, userPreference) {
        if (error) {
            return callback(error);
        }
        if (!userPreference) {
            userPreference = new EntityCache.NotificationPreference({
                hgId: guid.v1(),
                UserId: params.UserId,
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                CreatedBy: params.UserId
            });
        }
        userPreference.Categories = [];
        Object.keys(params.Preferences).forEach(function (category) {
            userPreference.Categories = userPreference.Categories.concat(params.Preferences[category].map(function (item) {
                return {
                    Category: category,
                    Name: item.Name,
                    Delivery: item.Delivery
                };
            }));
        });
        userPreference.ModifiedBy = params.UserId;
        userPreference.save(callback);
    });
}

function GetNotificationPreference(params, callback) {
    var preferences = {};
    EntityCache.NotificationPreference.findOne({MemberId: params.MemberId, GroupId: params.GroupId}, function (error, userPreference) {
        if (error) {
            return callback(error);
        }
        if (!userPreference) {
            return callback(null, preferences);
        }
        userPreference.Categories.forEach(function (item) {
            if (!preferences[item.Category]) {
                preferences[item.Category] = {};
            }
            preferences[item.Category][item.Name] = item;
        });
        callback(null, preferences);
    });
}

function UnlockItems(params, callback) {
    EntityCache.NotificationQueueItem.update({
        CreatedDate: {
            $lte: Date.now() - config.UnlockNotificationInterval * 1000,
            $gt: Date.now() - 86400000
        },
        LockedForDispatching: true
    }, {
        $set: {LockedForDispatching: false}
    }, {
        multi: true
    }, function (error, count) {
        if (error) {
            return callback(error);
        }
        return callback(null, count + ' Unlock notificationQueueItem complete');
    });
}

module.exports = {
    ReplaceRecipientByEntityId: ReplaceRecipientByEntityId,
    UpdateAlertTitleByEventTypeNameAndEntityId: UpdateAlertTitleByEventTypeNameAndEntityId,
    Create: Create,
    CreateBatch: CreateBatch,
    Remove: Remove,
    GetByRecipientId: GetByRecipientId,
    CountByImportantNotifications: CountByImportantNotifications,
    RemoveAll: RemoveAll,
    ViewNotification: ViewNotification,
    SaveMobileNotificationItems: SaveMobileNotificationItems,
    GetUnreadMobileNotifications: GetUnreadMobileNotifications,
    GetNotificationAudit: GetNotificationAudit,
    GetNotificationAuditById: GetNotificationAuditById,
    AddNotificationQueueItem: AddNotificationQueueItem,
    RestoreNotificationByEventTypeNameAndEntityId: RestoreNotificationByEventTypeNameAndEntityId,
    GetNotificationsByRecipientId: GetNotificationsByRecipientId,
    RemoveNotificationByActionUrl: RemoveNotificationByActionUrl,
    RemoveImportantNotificationByActionUrl: RemoveImportantNotificationByActionUrl,
    RemoveImportantNotificationsAll: RemoveImportantNotificationsAll,
    TransferManagerNotification: TransferManagerNotification,
    GetImportantNotificationsByLimits: GetImportantNotificationsByLimits,
    GetUnViewedRecognitionNotifications: GetUnViewedRecognitionNotifications,
    DeleteNotificationByEventTypeNameAndEntityId: DeleteNotificationByEventTypeNameAndEntityId,
    DeleteNotificationByEntityId: DeleteNotificationByEntityId,
    DeleteNotificationByEventTypeNameAndEntityIds: DeleteNotificationByEventTypeNameAndEntityIds,
    UpdateNotificationCycleTitle: UpdateNotificationCycleTitle,
    SaveNotificationPreference: SaveNotificationPreference,
    GetNotificationPreference: GetNotificationPreference,
    UnlockItems: UnlockItems,
    DeleteNotificationByEventTypeNameAndRecipientId: DeleteNotificationByEventTypeNameAndRecipientId
};
