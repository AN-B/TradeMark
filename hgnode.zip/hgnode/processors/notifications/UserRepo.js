/*jslint node:true es5:true*/
"use strict";
var entityCache = require('../../framework/EntityCache.js');

function getMembersByUserId(id, callback) {
    var Member = entityCache.Member;

    Member.find({UserId: id}, function (err, members) {
        if (err) {
            return callback(err);
        }
        return callback(null, members);
    });
}
function getRecipientsByUserIds(ids, callback) {
    var UserInfo = entityCache.UserInfo;
    UserInfo.find({hgId: {$in : ids}}, function (err, users) {

        if (err) {
            return callback('business.user.noauth.elup');
        }

        return callback(null, users);
    });
}
function geRecipientsByGroupId(id, callback) {
    var Member = entityCache.Member;

    Member.find({GroupId: id}, function (err, members) {
        if (err) {
            return callback(err);
        }
        return callback(null, members);
    });
}
module.exports = {
    getMembersByUserId: getMembersByUserId,
    getRecipientsByUserIds: getRecipientsByUserIds,
    geRecipientsByGroupId: geRecipientsByGroupId
};