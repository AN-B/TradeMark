/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js'),
        track = params.Data.track,
        ids = [],
        i,
        len = track.Collaborators.length;
    if (track.CreatorMember.hgId !== track.AssignedMember.hgId) {
        ids.push(track.CreatorMember.UserId);
    }
    for (i = 0; i < len; i += 1) {
        if (track.Collaborators[i].AccessLevel === 'Manager') {
            ids.push(track.Collaborators[i].UserId);
        }
    }
    EntityCache.UserInfo.find({hgId: {$in: ids}}, function (error, users) {
        if (error) {
            return callback(error);
        }
        params.NotificationQueueItem.RecipientList = users.map(function (userInfo) {
            return {
                Name: userInfo.UserPersonal.FirstName,
                Address: userInfo.UserPersonal.PrimaryEmail || config.email.Alert,
                WelcomeBadgePending: !userInfo.LastLoginTime,
                GroupId: userInfo.Preference.DefaultGroupId
            };
        });
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    });
};
