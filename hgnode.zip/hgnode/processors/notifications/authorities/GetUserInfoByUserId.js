/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js');
    EntityCache.UserInfo.findOne({
        hgId: params.UserInfoUserId
    }, function (err, userInfo) {
        if (err) {
            return callback('err.usr.lui');
        }
        if (!userInfo) {
            return callback('err.usr.uie');
        }
        params.NotificationQueueItem.RecipientList.push({
            Name: userInfo.UserPersonal.FirstName,
            Address: userInfo.UserPersonal.PrimaryEmail || config.email.Alert,
            WelcomeBadgePending: !userInfo.LastLoginTime,
            GroupId: userInfo.Preference.DefaultGroupId
        });
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    });
};
