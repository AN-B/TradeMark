/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js'),
        recipientMember = params.Data.Recognition.RecipientMember,
        managerMemberId,
        managerUserId,
        finalCallback = function (params, cb) {
            cb(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        };
    if (recipientMember && recipientMember.MyManagers && recipientMember.MyManagers.length) {
        managerMemberId = recipientMember.MyManagers[0].MemberId;
    }
    if (managerMemberId) {
        EntityCache.Member.findOne({
            hgId: managerMemberId,
            MembershipStatus: 'Active'
        }, function (error, managerMember) {
            if (error || !managerMember) {
                return callback('err.usr.uie');
            }
            managerUserId = managerMember.UserId;
            EntityCache.UserInfo.findOne({hgId: managerUserId}, function (error, user) {
                if (error || !user) {
                    return callback('err.usr.uie');
                }
                params.NotificationQueueItem.RecipientList.push({
                    Name: user.UserPersonal.FullName,
                    Address: user.UserPersonal.PrimaryEmail || config.email.Alert,
                    WelcomeBadgePending: false,
                    GroupId: user.Preference.DefaultGroupId
                });
                EntityCache.Member.find({
                    RolesInGroup: 'Admin',
                    MembershipStatus: 'Active',
                    GroupId: recipientMember.GroupId
                }, function (error, adminMembers) {
                    if (!error && adminMembers && adminMembers.length) {
                        EntityCache.UserInfo.find({hgId: {$in: adminMembers.map(function (member) {
                            return member.UserId;
                        })}}, function (error, adminUsers) {
                            if (!error && adminUsers && adminUsers.length > 0) {
                                adminUsers.forEach(function (user) {
                                    params.NotificationQueueItem.RecipientList.push({
                                        Name: user.UserPersonal.FullName,
                                        Address: user.UserPersonal.PrimaryEmail || config.email.Alert,
                                        WelcomeBadgePending: false,
                                        GroupId: user.Preference.DefaultGroupId
                                    });
                                });
                            }
                            finalCallback(params, callback);
                        });
                    } else {
                        finalCallback(params, callback);
                    }
                });
            });
        });
    } else {
        EntityCache.Member.find({
            RolesInGroup: 'Admin',
            MembershipStatus: 'Active',
            GroupId: recipientMember.GroupId
        }, function (error, adminMembers) {
            if (error || !adminMembers || !adminMembers.length) {
                return callback('err.usr.uie');
            }
            EntityCache.UserInfo.find({hgId: {$in: adminMembers.map(function (member) {
                return member.UserId;
            })}}, function (error, adminUsers) {
                if (error || !adminUsers || !adminUsers.length) {
                    return callback('err.usr.uie');
                }
                adminUsers.forEach(function (user) {
                    params.NotificationQueueItem.RecipientList.push({
                        Name: user.UserPersonal.FullName,
                        Address: user.UserPersonal.PrimaryEmail || config.email.Alert,
                        WelcomeBadgePending: false,
                        GroupId: user.Preference.DefaultGroupId
                    });
                });
                finalCallback(params, callback);
            });
        });
    }
};
