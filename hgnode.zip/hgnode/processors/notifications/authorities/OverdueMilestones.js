/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var NotificationsEnums = require('../../../enums/NotificationsEnums.js'),
        OverdueMilestoneNotification = require('./OverdueMilestoneEmailNotification.js');
    OverdueMilestoneNotification.get(params, function (err, queue) {
        if (err || queue.length === 0) {
            return callback("Error creating overdue email notifications");
        }
        callback(null, {
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: NotificationsEnums.DispatchOption.Queue,
            CompleteCallback: params.CompleteCallback,
            NotificationQueueItems: queue
        });
    });
};
