/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js'),
        i,
        len,
        userId,
        userIds = [];
    for (i = 0, len = params.Data.Comment.Recipients.length; i < len; i += 1) {
        userId = params.Data.Comment.Recipients[i].UserId;
        if (userId !== params.Data.CommentUserId) {
            userIds.push(userId);
        }
    }
    EntityCache.UserInfo.find({hgId: {$in: userIds}}, function (err, userInfo) {
        if (err) {
            return callback('err.usr.lui');
        }
        if (!userInfo || !userInfo.length) {
            return callback('err.usr.uie');
        }
        EntityCache.Member.find({
            GroupId: userInfo[0].Preference.DefaultGroupId,
            UserId: {
                $in: userInfo.map(function (user) {
                    return user.hgId;
                })
            }
        }, function (error, members) {
            var memberHashByUserId = {};
            if (error) {
                return callback(error);
            }
            members.forEach(function (member) {
                memberHashByUserId[member.UserId] = member;
            });
            params.NotificationQueueItem.RecipientList = userInfo.map(function (user) {
                return {
                    Name: user.UserPersonal.FirstName,
                    Address: user.UserPersonal.PrimaryEmail || config.email.Alert,
                    WelcomeBadgePending: !user.LastLoginTime,
                    MemberId: memberHashByUserId[user.hgId].hgId,
                    GroupId: user.Preference.DefaultGroupId
                };
            });
            callback(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    });
};