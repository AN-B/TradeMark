/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        MemberEnums = require('../../../enums/MemberEnums.js'),
        getUserInfoByUserId = require('./GetUserInfoByUserId.js');
    EntityCache.Member.findOne({hgId: params.MemberId, MembershipStatus: MemberEnums.Status.Active}, function (err, member) {
        if (err) {
            return callback('err.usr.lui');
        }
        if (!member) {
            return callback('err.usr.uie');
        }
        params.UserInfoUserId = member.UserId;
        getUserInfoByUserId(params, callback);
    });
};
