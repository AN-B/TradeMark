/*jslint node:true es5:true*/
"use strict";
var config = require('../../../configurations/config.js'),
    userRepository = require('./UserRepo.js'),
    EntityCache = require('../../framework/EntityCache.js');

function buildEmailContent(tracks, userData, params, callback) {
    var stonesOverdue = 0,
        trackUrls = [],
        queueItem = EntityCache.NotificationQueueItem();
    tracks.forEach(function (track, trackIndex) {
        if (userData.hgId === track.AssignedMember.UserId) {

            track.CareerTrackTemplate.MileStones.forEach(function (milestone) {
                if (milestone.Status === "OverDue") {
                    stonesOverdue += 1;
                    trackUrls.push(['<a href="', [config.protocol, config.baseUrl, '#/Track/Iso/', milestone.hgId].join(''), '">', milestone.RecognitionTemplate.Title, '</a><br/>'].join(''));
                }
            });
        }
        if (trackIndex === tracks.length - 1) {
            if (stonesOverdue === 0) {
                return callback();
            }
            queueItem.DeliveryMethods = params.NotificationQueueItem.DeliveryMethods;
            queueItem.TemplateId = params.NotificationQueueItem.TemplateId;
            queueItem.Subject = params.NotificationQueueItem.Subject;
            queueItem.FirstName = userData.UserPersonal.FirstName;
            queueItem.MergeFields = {
                first_name: userData.UserPersonal.FirstName,
                overdue_milestones_quantity: stonesOverdue,
                track_urls: trackUrls.join('')
            };
            queueItem.RecipientList.push({
                Name : userData.UserPersonal.FirstName,
                Address : userData.UserPersonal.PrimaryEmail || config.email.Alert,
                GroupId: userData.Preference.DefaultGroupId
            });

            callback(queueItem);
        }

    });
}

function getAssignedMemberIds(tracks, callback) {
    var retVal = [];
    if (tracks.length === 0) {
        callback(retVal);
    }
    tracks.forEach(function (track, index) {
        if (retVal.indexOf(track.AssignedMember.UserId) === -1) {
            retVal.push(track.AssignedMember.UserId);
        }
        if (index === tracks.length - 1) {
            return callback(retVal);
        }
    });
}

function get(params, done) {
    var tracks = params.Data,
        queue = [];
    if (!tracks) {
        return done(null, queue);
    }
    getAssignedMemberIds(tracks, function (userIds) {
        userIds.forEach(function (id) {
            userRepository.getRecipientsByUserIds([id], function (err, userData) {
                if (err) {
                    return done(err);
                }
                buildEmailContent(tracks, userData[0], params, function (queueItem) {
                    if (queueItem) {
                        queue.push(queueItem);
                    }
                    if (userIds.length === queue.length) {
                        done(null, queue);
                    }
                });
            });
        });
    });
}

module.exports = {
    get: get
};