/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js'),
        NotificationsEnums = require('../../../enums/NotificationsEnums.js');
    EntityCache.UserInfo.find({
        hgId: {$in: params.Data.People.map(function (person) { return person.UserId; })}
    }, function (err, users) {
        var len = users.length,
            i,
            item,
            queue = [];
        if (err) {
            return callback('err.usr.lui');
        }
        if (!users || !users.length) {
            return callback('err.usr.uie');
        }
        for (i = 0; i < len; i += 1) {
            item = EntityCache.NotificationQueueItem({
                DeliveryMethods: params.NotificationQueueItem.DeliveryMethods,
                TemplateId: params.NotificationQueueItem.TemplateId,
                Subject: params.NotificationQueueItem.Subject
            });
            item.RecipientList.push({
                Name: users[i].UserPersonal.FirstName,
                Address: users[i].UserPersonal.PrimaryEmail || config.email.Alert,
                WelcomeBadgePending: !users[i].LastLoginTime,
                GroupId: users[i].Preference.DefaultGroupId
            });
            item.FirstName = users[i].UserPersonal.FirstName;
            queue.push(item);
        }
        callback(null, {
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: NotificationsEnums.DispatchOption.Queue,
            NotificationQueueItems: queue
        });
    });
};
