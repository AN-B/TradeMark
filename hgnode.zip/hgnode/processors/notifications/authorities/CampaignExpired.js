/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var iLen,
        i,
        requests = [],
        Async = require('async'),
        getQueueForCampaignNotifications = require('./GetQueueForCampaignNotifications.js');
    for (i = 0, iLen = params.Data.Items.length; i < iLen; i += 1) {
        requests.push({
            correlationId: params.correlationId,
            Data: {
                GroupId: params.Data.GroupId,
                GroupName: params.Data.GroupName,
                Item: params.Data.Items[i],
                PointAdminUserId: params.Data.PointAdminUserId
            },
            NotificationEvent: params.NotificationEvent,
            NotificationQueueItem: params.NotificationQueueItem,
            EventName: params.EventName,
            DispatchOption: params.DispatchOption,
            SendOutNotifications: callback
        });
    }
    Async.each(requests, getQueueForCampaignNotifications, function (error) {
        if (error) {
            callback(error);
        }
    });
};
