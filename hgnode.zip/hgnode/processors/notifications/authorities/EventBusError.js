/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var config = require('../../../configurations/config.js');
    params.NotificationQueueItem.RecipientList.push({
        Name: 'HG Alert',
        Address: config.email.Alert,
        WelcomeBadgePending: false
    });
    callback(null, {
        NotificationQueueItem: params.NotificationQueueItem,
        Data: params.Data,
        NotificationEvent: params.NotificationEvent,
        DispatchOption: params.DispatchOption
    });
};
