/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var getUserInfoByUserId = require('./GetUserInfoByUserId.js'),
        completedMilestone = params.Data.completedMilestone;
    if (params.Data.track.AssignedMember.UserId === params.Data.track.CreatorMember.UserId) {
        return callback('You do not get email if you complete a self assigned milestone');
    }
    if (!completedMilestone.RequiresApproval && !completedMilestone.RecognitionTemplate.CreditValue) {
        return callback('You do not get an email if milestone does not require approval');
    }
    params.UserInfoUserId = params.Data.track.AssignedMember.UserId;
    getUserInfoByUserId(params, callback);
};
