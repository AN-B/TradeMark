/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        MemberEnums = require('../../../enums/MemberEnums.js'),
        config = require('../../../configurations/config.js');
    EntityCache.Member.find({
        hgId: {$in: params.Data.RecipientMemberIds || params.RecipientMemberIds},
        MembershipStatus: MemberEnums.Status.Active
    }, function (error, members) {
        if (error) {
            return callback(error);
        }
        var userIds = members.map(function (member) {
            return member.UserId;
        });
        EntityCache.UserInfo.find({hgId: {$in: userIds}}, function (error, users) {
            if (error) {
                return callback(error);
            }
            params.NotificationQueueItem.RecipientList = users.map(function (userInfo) {
                return {
                    Name: userInfo.UserPersonal.FirstName,
                    Address: userInfo.UserPersonal.PrimaryEmail || config.email.Alert,
                    WelcomeBadgePending: !userInfo.LastLoginTime,
                    GroupId: userInfo.Preference.DefaultGroupId
                };
            });
            callback(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    });
};
