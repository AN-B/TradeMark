/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var Async = require('async'),
        EntityCache = require('../../../framework/EntityCache.js'),
        MemberEnums = require('../../../enums/MemberEnums.js'),
        config = require('../../../configurations/config.js'),
        getSubscriberInGroup = function (request, callback) {
            var i,
                len;
            EntityCache.Member.find({
                MembershipStatus: MemberEnums.Status.Active,
                GroupId: request.Data.GroupId
            }, function (err, members) {
                if (err) {
                    return callback('error loading members');
                }
                EntityCache.UserInfo.find({
                    hgId: {
                        $in: members.map(function (member) {
                            return member.UserId;
                        })
                    }
                }, function (err, users) {
                    if (err) {
                        return callback('error loading users');
                    }
                    for (i = 0, len = users.length; i < len; i += 1) {
                        request.NotificationQueueItem.RecipientList.push({
                            Name: users[i].UserPersonal.FirstName,
                            Address: users[i].UserPersonal.PrimaryEmail || config.email.Alert,
                            WelcomeBadgePending: !users[i].LastLoginTime,
                            GroupId: users[i].Preference.DefaultGroupId
                        });
                    }
                    callback();
                });
            });
        },
        notificationQueueItems = params.NotificationQueueItems,
        requests = notificationQueueItems.map(function (nqi) {
            return {
                NotificationQueueItem: nqi,
                Data: params.Data
            };
        }),
        len = requests.length;
    Async.whilst(
        function () {
            len -= 1;
            return len > -1;
        },
        function (callback) {
            getSubscriberInGroup(requests[len], callback);
        },
        function (err) {
            if (err) {
                callback(err + ' error happened in resolveRecipientForOneNotificationQueueItem');
            } else {
                callback(null, {
                    NotificationQueueItems: notificationQueueItems,
                    Data: params.Data,
                    NotificationEvent: params.NotificationEvent,
                    DispatchOption: params.DispatchOption
                });
            }
        }
    );
};
