/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        getRecipientsByMemberIds = require('./GetRecipientsByMemberIds.js');
    EntityCache.Comment.findOne({hgId: params.Data.CoachingNoteId}, function (error, note) {
        if (error || !note) {
            return callback('Error loading the coaching note');
        }
        var recipientMemberIds = [];
        if (params.Data.CommentorMemberId === note.MemberId) {
            //someone commented the coaching note that he gave, so comment should go to note's recipient
            recipientMemberIds.push(note.Recipient.MemberId);
        } else if (params.Data.CommentorMemberId === note.Recipient.MemberId) {
            //someone commented the coaching note that he received, so comment should go to note's giver
            recipientMemberIds.push(note.MemberId);
        } else {
            //someone commented coaching notes given AND received by others, so comment goes to both
            recipientMemberIds.push(note.Recipient.MemberId);
            recipientMemberIds.push(note.MemberId);
        }
        params.Data.RecipientMemberIds = recipientMemberIds;
        getRecipientsByMemberIds(params, callback);
    });
};
