/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js'),
        index,
        len,
        i,
        queue = [],
        item,
        adminFullName,
        adminEmail,
        userIds = [params.Data.Item.CreatedBy],
        campaignDays = Math.floor((new Date(params.Data.Item.ExpireDate).getTime() / 86400000) - (new Date(params.Data.Item.CreatedDate).getTime() / 86400000) + 1);
    EntityCache.UserInfo.findOne({
        hgId: params.Data.PointAdminUserId
    }, function (err, userInfo) {
        if (err || !userInfo) {
            return callback('err.usr.lui');
        }
        adminFullName = userInfo.UserPersonal.FullName;
        adminEmail = userInfo.UserPersonal.PrimaryEmail || config.email.Alert;
        userIds.push(userInfo.hgId);
        for (i = 0, len = params.Data.Item.CampaignItem.Backers.length; i < len; i += 1) {
            userIds.push(params.Data.Item.CampaignItem.Backers[i].UserId);
        }
        EntityCache.UserInfo.find({
            hgId: {$in: userIds}
        }, function (err, userInfo) {
            var ret;
            if (err || !userInfo) {
                return callback('err.usr.lui');
            }
            for (index = 0, len = userInfo.length; index < len; index += 1) {
                item = new EntityCache.NotificationQueueItem({
                    DeliveryMethods: params.NotificationQueueItem.DeliveryMethods,
                    TemplateId: params.NotificationQueueItem.TemplateId,
                    Subject: params.NotificationQueueItem.Subject,
                    MergeFields: {}
                });
                item.RecipientList.push({
                    Name: userInfo[index].UserPersonal.FirstName,
                    Address: userInfo[index].UserPersonal.PrimaryEmail || config.email.Alert,
                    WelcomeBadgePending: !userInfo[index].LastLoginTime,
                    GroupId: userInfo[index].Preference.DefaultGroupId
                });
                item.MergeFields.points_admin_full_name = adminFullName;
                item.MergeFields.points_admin_email = adminEmail;
                item.MergeFields.campaign_product = params.Data.Item.Name;
                item.MergeFields.program_name = params.Data.Item.GroupName;
                item.MergeFields.campaign_days = campaignDays;
                queue.push(item);
            }
            ret = {
                NotificationQueueItems: queue,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption,
                CompleteCallback: params.CompleteCallback
            };
            if (params.SendOutNotifications) {
                params.SendOutNotifications(null, ret);
            } else if (callback) {
                callback(null, ret);
            }
        });
    });
};
