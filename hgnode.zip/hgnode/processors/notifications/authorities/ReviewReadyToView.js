/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var getRecipientByMemberId = require('./GetRecipientByMemberId.js'),
        review = params.Data.Review,
        containNonConfidential = false,
        i,
        ilen,
        j,
        jlen;
    for (i = 0, ilen = review.Card.Sections.length; i < ilen; i += 1) {
        for (j = 0, jlen = review.Card.Sections[i].Questions.length; j < jlen; j += 1) {
            if (!review.Card.Sections[i].Questions[j].Confidential) {
                containNonConfidential = true;
                i = ilen;
                break;
            }
        }
    }
    if (containNonConfidential) {
        params.MemberId = params.Data.People.MemberId;
        getRecipientByMemberId(params, callback);
    } else {
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    }
};
