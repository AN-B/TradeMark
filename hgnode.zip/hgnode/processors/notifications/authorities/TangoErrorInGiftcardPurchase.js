/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    params.NotificationQueueItem.RecipientList.push({
        Name: 'HG Operations',
        Address: 'operations@highground.com',
        WelcomeBadgePending: false
    });
    callback(null, {
        NotificationQueueItem: params.NotificationQueueItem,
        Data: params.Data,
        NotificationEvent: params.NotificationEvent,
        DispatchOption: params.DispatchOption
    });
};
