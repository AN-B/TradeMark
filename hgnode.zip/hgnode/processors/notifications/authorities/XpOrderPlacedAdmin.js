/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        EntityEnums = require('../../../enums/EntityEnums.js'),
        config = require('../../../configurations/config.js');
    EntityCache.Member.find({
        GroupId: params.Data.ProductOrder.ProductItem.GroupId,
        MembershipStatus: 'Active',
        $or: [{RolesInGroup: {$in: [EntityEnums.MembersRoleInGroup.Admin, EntityEnums.MembersRoleInGroup.HGAdmin]}}, {AddedPermissions: 'ManageProductOrder'}]
    }, function (err, members) {
        if (err || !members || !members.length) {
            return callback('error loading xpOrderPlacedAdmin members');
        }
        EntityCache.UserInfo.find({
            hgId: {$in: members.map(function (member) { return member.UserId; })}
        }, function (err, userInfos) {
            if (err || !userInfos || !userInfos.length) {
                return callback('error loading xpOrderPlacedAdmin users');
            }
            userInfos.forEach(function (userInfo) {
                params.NotificationQueueItem.RecipientList.push({
                    Name: userInfo.UserPersonal.FullName,
                    Address: userInfo.UserPersonal.PrimaryEmail || config.email.Alert,
                    WelcomeBadgePending: false,
                    GroupId: userInfo.Preference.DefaultGroupId
                });
            });
            callback(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    });
};
