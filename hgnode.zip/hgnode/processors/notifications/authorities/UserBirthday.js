/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js'),
        notificationQueueItem = params.NotificationQueueItem,
        userInfo = params.Data.user;
    EntityCache.ScheduleEvent.findOne({UserId: userInfo.hgId}, function (err, scheduleEvent) {
        if (err) {
            return callback('err.usr.lui');
        }
        if (scheduleEvent && scheduleEvent.EmailSent.Birthday) {
            // birthday email already sent
            return;
        }
        if (!scheduleEvent) {
            scheduleEvent = new EntityCache.ScheduleEvent({
                UserId: userInfo.hgId,
                EmailSent: {
                    Birthday: true
                }
            });
            scheduleEvent.save();
        }
        scheduleEvent.EmailSent.Birthday = true;
        scheduleEvent.save();
        notificationQueueItem.RecipientList.push({
            Name: userInfo.UserPersonal.FirstName,
            Address: userInfo.UserPersonal.PrimaryEmail || config.email.Alert,
            WelcomeBadgePending: !userInfo.LastLoginTime,
            GroupId: userInfo.Preference.DefaultGroupId
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    });
};
