/*jslint node:true es5:true*/
'use strict';

module.exports = function (params, callback) {
    var EntityCache = require('../../../framework/EntityCache.js'),
        config = require('../../../configurations/config.js');
    EntityCache.UserInfo.find({
        hgId: {$in: params.Data.PointRecipients}
    }, function (err, userInfo) {
        if (err) {
            return callback('err.usr.lui');
        }
        if (!userInfo || !userInfo.length) {
            return callback('err.usr.uie');
        }
        params.NotificationQueueItem.RecipientList = userInfo.map(function (user) {
            return {
                Name: user.UserPersonal.FirstName,
                Address: user.UserPersonal.PrimaryEmail || config.email.Alert,
                WelcomeBadgePending: !user.LastLoginTime,
                GroupId: user.Preference.DefaultGroupId
            };
        });
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    });
};
