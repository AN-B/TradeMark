/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    NotificationPreferenceProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            NotificationsEnums = require('../../enums/NotificationsEnums.js'),
            EventResponder = require('../../util/EventResponder.js'),
            HgLog = require('../../framework/HgLog'),

            populateOneDefaultCategory = function (preference, categoryName) {
                var category = {},
                    eventsInCategory = NotificationsEnums.GetEventsInCategory(categoryName),
                    i,
                    len;
                category.Name = categoryName;
                category.DailyDigestOnly = false;
                category.EventDeliveryMethods = [];
                for (i = 0, len = eventsInCategory.length; i < len; i += 1) {
                    category.EventDeliveryMethods.push({
                        EventName : eventsInCategory[i].Name
                    });
                }
                preference.Categories.push(category);
            },

            populateDefaultPreference = function (preference) {
                var categoryName = Object.keys(NotificationsEnums.Category),
                    i,
                    len;
                for (i = 0, len = categoryName.length; i < len; i += 1) {
                    populateOneDefaultCategory(preference, categoryName[i]);
                }
            },

            savePreference = function (preference) {
                var i,
                    j;
                EntityCache.NotificationSubscription.remove({'MemberId' : preference.MemberId}, function (err) {
                    if (err) {
                        HgLog.error({methodName: 'savePreference', error: err});
                    }
                });
                for (i = 0; i < preference.Categories.length; i += 1) {
                    for (j = 0; j < preference.Categories[i].EventDeliveryMethods.length; j += 1) {
                        if (preference.Categories[i].EventDeliveryMethods[j].Email === true) {
                            EntityCache.NotificationSubscription({
                                MemberId : preference.MemberId,
                                UserId : preference.UserId,
                                GroupId : preference.GroupId,
                                CategoryName : preference.Categories[i].Name,
                                EventName : preference.Categories[i].EventDeliveryMethods[j].EventName,
                                DeliveryMethod : NotificationsEnums.DeliveryMethod.Email,
                                CreatedBy : preference.UserId,
                                ModifiedBy : preference.UserId
                            }).save();
                        }
                    }
                }
            },

            populatePreferenceBySubscriptions = function (preference, subscriptions) {
                var i,
                    categoryName,
                    eventName,
                    category,
                    eventDeliveryMethod,
                    categoryFilter = function (el) {
                        return el.Name === categoryName;
                    },
                    eventFilter = function (el) {
                        return el.EventName === eventName;
                    };
                for (i = 0; i < subscriptions.length; i += 1) {
                    categoryName = subscriptions[i].CategoryName;
                    eventName = subscriptions[i].EventName;
                    category = preference.Categories.filter(categoryFilter);
                    if (category && category.length > 0) {
                        eventDeliveryMethod = category[0].EventDeliveryMethods.filter(eventFilter);
                        if (eventDeliveryMethod && eventDeliveryMethod.length > 0) {
                            eventDeliveryMethod[0][subscriptions[i].DeliveryMethod] = true;
                        }
                    }
                }
            };

        this.UpdateNotificationPreference = function (params) {
            var updateRequest = params.UpdateRequest;
            EntityCache.NotificationSubscription.find({'MemberId' : params.MemberId, 'EventName' : updateRequest.EventName, 'DeliveryMethod' : updateRequest.DeliveryMedthod}).remove();
            if (updateRequest.Subscribe === 'true') {
                EntityCache.NotificationSubscription({
                    MemberId : params.MemberId,
                    UserId : params.UserId,
                    GroupId : params.GroupId,
                    CategoryName : NotificationsEnums.Event[updateRequest.EventName].Category,
                    EventName : updateRequest.EventName,
                    CreatedBy : params.UserId,
                    ModifiedBy : params.UserId
                }).save();
            }
            EventResponder.RespondWithData(EventEmitterCache, params, 'Updated');
        };

        this.GetNotificationPreference = function (params) {
            var preference = EntityCache.NotificationPreference({
                    UserId : params.UserId,
                    MemberId : params.MemberId,
                    GroupId : params.GroupId
                });
            populateDefaultPreference(preference);
            EntityCache.NotificationSubscription.find({'MemberId' : params.MemberId}, function (err, subscriptions) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, err);
                } else if (subscriptions && subscriptions.length > 0) {
                    populatePreferenceBySubscriptions(preference, subscriptions);
                    EventResponder.RespondWithData(EventEmitterCache, params, preference);
                } else {
                    //there is no subscription record for the current member
                    savePreference(preference);
                    EventResponder.RespondWithData(EventEmitterCache, params, preference);
                }
            });
        };
    };

module.exports = NotificationPreferenceProcessor;
