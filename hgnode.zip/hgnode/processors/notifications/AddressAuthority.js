/*jslint node:true es5:true*/
'use strict';
var NotificationsEnums = require('../../enums/NotificationsEnums.js'),
    FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    AuthorityFactory = {},
    authorities = {
        GetRecipientByMemberId: require('./authorities/GetRecipientByMemberId.js'),
        UserBirthday: require('./authorities/UserBirthday.js'),
        GetRecipientsByMemberIds: require('./authorities/GetRecipientsByMemberIds.js'),
        CommentReceived: require('./authorities/CommentReceived.js'),
        GetUserInfoByUserId: require('./authorities/GetUserInfoByUserId.js'),
        CommentCoaching: require('./authorities/CommentCoaching.js'),
        TangoErrorInGiftcardPurchase: require('./authorities/TangoErrorInGiftcardPurchase.js'),
        GroupNewsPublished: require('./authorities/GroupNewsPublished.js'),
        MilestoneApproved: require('./authorities/MilestoneApproved.js'),
        GetTrackCompletionRequest: require('./authorities/GetTrackCompletionRequest.js'),
        PublicRecognitionRatingReceived: require('./authorities/PublicRecognitionRatingReceived.js'),
        RefundCredit: require('./authorities/RefundCredit.js'),
        OverdueMilestones: require('./authorities/OverdueMilestones.js'),
        XpProductItemExpired: require('./authorities/XpProductItemExpired.js'),
        XpOrderPlacedAdmin: require('./authorities/XpOrderPlacedAdmin.js'),
        GetAdminIssuedPoints: require('./authorities/GetAdminIssuedPoints.js'),
        ReviewReadyToView: require('./authorities/ReviewReadyToView.js'),
        ReviewReadyToSignOff: require('./authorities/ReviewReadyToSignOff.js'),
        UserRequestedInfo: require('./authorities/UserRequestedInfo.js'),
        EventBusError: require('./authorities/EventBusError.js'),
        InvoiceInfo: require('./authorities/InvoiceInfo.js'),
        GetQueueForCampaignNotifications: require('./authorities/GetQueueForCampaignNotifications.js'),
        CampaignExpired: require('./authorities/CampaignExpired.js')
    },
    extractData = {
        MemberId: function (params) {
            return params.Data.MemberId;
        },
        FeedbackSessionReviewerMemberId: function (params) {
            return params.Data.ReviewerMemberId;
        },
        FeedbackSessionSubjectMemberId: function (params) {
            return params.Data.SubjectMemberId;
        },
        GetSubjectMemberIdFromSession: function (params) {
            var subject = params.Data.FeedbackSession.Participants.find(function (p) {
                if (params.Data.FeedbackSession.CycleType === FeedbackEnums.CycleType.EvaluateOthers) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Requester;
                }
                return p.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
            });
            if (subject) {
                return subject.MemberId;
            }
        },
        GetReviewerMemberIdsFromSession: function (params) {
            return params.Data.FeedbackSession.Participants.reduce(function (memo, p) {
                if (p.ParticipantType === FeedbackEnums.SessionParticipantType.Reviewer) {
                    memo.push(p.MemberId);
                }
                return memo;
            }, []);
        },
        GoalOwnerMemberId: function (params) {
            return params.Data.GoalOwnerMemberId;
        },
        GoalOwnerDotMemberId: function (params) {
            return params.Data.GoalOwner.MemberId;
        },
        ApproverMemberId: function (params) {
            return params.Data.Approver.MemberId;
        },
        CycleCreatedBy: function (params) {
            return params.Data.Cycle.CreatedBy;
        },
        CycleCycleOwnerUserId: function (params) {
            return params.Data.Cycle.CycleOwner.UserId;
        },
        CollaboratorMemberId: function (params) {
            return params.Data.CollaboratorMemberId;
        },
        ParticipantOwnerMemberId: function (params) {
            return params.Data.Participant.Owner.MemberId;
        },
        OwnerMemberId: function (params) {
            return params.Data.OwnerMemberId;
        },
        OwnerMemberIdDot: function (params) {
            return params.Data.Owner.MemberId;
        },
        GoalOwnerMemberIdDot: function (params) {
            return params.Data.Goal.Owner.MemberId;
        },
        ToMemberMemberId: function (params) {
            return params.Data.ToMember.MemberId;
        },
        RecipientMemberId: function (params) {
            return params.Data.RecipientMemberId;
        },
        UserId: function (params) {
            return params.Data.UserId;
        },
        RequesterUserId: function (params) {
            return params.Data.RequesterUserId;
        },
        RejecteeUserId: function (params) {
            return params.Data.RejecteeUserId;
        },
        RejectorUserId: function (params) {
            return params.Data.RejectorUserId;
        },
        AdminUserId: function (params) {
            return params.Data.AdminUserId;
        },
        RecognitionRecipientMemberUserId: function (params) {
            return params.Data.Recognition.RecipientMember.UserId;
        },
        RecognitionIssuerMemberUserId: function (params) {
            return params.Data.IssuerUserId;
        },
        ServiceAwardPointUserId: function (params) {
            return params.Data.PointMasterUserId;
        },
        TrackAssignedMemberUserId: function (params) {
            return params.Data.Track.AssignedMember.UserId;
        },
        ProductOrderRequesterUserId: function (params) {
            return params.Data.ProductOrder.Requester.UserId;
        },
        ProductOrderRecipientUserId: function (params) {
            return params.Data.ProductOrder.Recipient.UserId;
        },
        PeopleMemberId: function (params) {
            return params.Data.People.MemberId;
        },
        ReviewCreatedBy: function (params) {
            return params.Data.Review.CreatedBy;
        },
        ReviewMemberId: function (params) {
            return params.Data.ReviewMemberId;
        },
        RecipientId: function (params) {
            return params.Data.RecipientId;
        },
        OffBoardUserId: function (params) {
            return params.Data.OffBoardUserId;
        },
        GroupAdminUserId: function (params) {
            return params.Data.GroupAdminUserId;
        },
        ProductIdeaSuggesterUserId: function (params) {
            return params.Data.ProductIdeaSuggesterUserId;
        },
        PointAdminUserId: function (params) {
            return params.Data.PointAdminUserId;
        }
    },
    setEventsActions = function (events, assign) {
        if (events && events.length) {
            events.forEach(function (ev) {
                AuthorityFactory[ev] = assign;
            });
        }
    };

setEventsActions([
    NotificationsEnums.Event.PulseSurveyOverdue.Name,
    NotificationsEnums.Event.RecognitionPointsAdded.Name,
    NotificationsEnums.Event.GoalOwnershipTransferred.Name,
    NotificationsEnums.Event.GoalApproverTransferred.Name,
    NotificationsEnums.Event.SurveyDelivered.Name,
    NotificationsEnums.Event.ProcessingFailed.Name,
    NotificationsEnums.Event.FileRequiresApproval.Name,
    NotificationsEnums.Event.FileProcessed.Name,
    NotificationsEnums.Event.SurveyCompleted.Name,
    NotificationsEnums.Event.SurveyDueSoon.Name,
    NotificationsEnums.Event.AdminPointsReplenished.Name,
    NotificationsEnums.Event.MemberGoalStatus.Name,
    NotificationsEnums.Event.ApproverOKRStatus.Name,
    NotificationsEnums.Event.MemberDailyRecap.Name,
    NotificationsEnums.Event.MemberWeeklyRecap.Name,
    NotificationsEnums.Event.TrackCheckIn.Name,
    NotificationsEnums.Event.TrackCompletionRequestApproved.Name,
    NotificationsEnums.Event.TransferCreditsComplete.Name,
    NotificationsEnums.Event.ReviewDelivered.Name,
    NotificationsEnums.Event.ClosedReview.Name,
    NotificationsEnums.Event.PastOverdueDelivered.Name,
    NotificationsEnums.Event.CycleReviewsClosedOrArchived.Name,
    NotificationsEnums.Event.RemovedFromCycle.Name,
    NotificationsEnums.Event.ReviewDeadlineDelivered.Name,
    NotificationsEnums.Event.EmployeeOnboarded.Name,
    NotificationsEnums.Event.AccountsMerged.Name,
    NotificationsEnums.Event.FeedbackCardAvailable.Name,
    NotificationsEnums.Event.RecognitionGive.Name,
    NotificationsEnums.Event.TalentInsightAssessmentDelivered.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.MemberId }
});
setEventsActions([
    NotificationsEnums.Event.Anniversary.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.RecognitionRecipientMemberUserId }
});
setEventsActions([
    NotificationsEnums.Event.GoalCloseRejected.Name,
    NotificationsEnums.Event.GoalSetRejected.Name,
    NotificationsEnums.Event.GoalsClosureApproved.Name,
    NotificationsEnums.Event.GoalsSetApproved.Name,
    NotificationsEnums.Event.GoalCreatedForYou.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.GoalOwnerMemberId }
});
setEventsActions([
    NotificationsEnums.Event.GoalCycleDelivered.Name,
    NotificationsEnums.Event.TemplateGoalAssigned.Name,
    NotificationsEnums.Event.ParticipantRemovedFromCycle.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.GoalOwnerDotMemberId }
});
setEventsActions([
    NotificationsEnums.Event.Birthday.Name
], {
    auth: authorities.UserBirthday
});
setEventsActions([
    NotificationsEnums.Event.CommentGoal.Name
], {
    auth: authorities.GetRecipientsByMemberIds
});
setEventsActions([
    NotificationsEnums.Event.CommentReceived.Name,
    NotificationsEnums.Event.RecognitionCommentReceived.Name,
    NotificationsEnums.Event.TrackCommentReceived.Name
], {
    auth: authorities.CommentReceived
});
setEventsActions([
    NotificationsEnums.Event.FeedbackSessionRated.Name,
    NotificationsEnums.Event.FeedbackRequestExpiring.Name,
    NotificationsEnums.Event.FeedbackSessionRequested.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.FeedbackSessionReviewerMemberId }
});
setEventsActions([
    NotificationsEnums.Event.FeedbackSessionSubmitted.Name,
    NotificationsEnums.Event.FeedbackSessionDeclined.Name,
    NotificationsEnums.Event.EvaluateOthersSubmitted.Name,
    NotificationsEnums.Event.GiveFeedbackSubmitted.Name,
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.FeedbackSessionSubjectMemberId }
});
setEventsActions([
    NotificationsEnums.Event.FeedbackCheckInManagerNotesAvailable.Name,
    NotificationsEnums.Event.SelfEvaluationDelivered.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.GetSubjectMemberIdFromSession }
});
setEventsActions([
    NotificationsEnums.Event.SelfEvaluationSubmitted.Name
], {
    auth: authorities.GetRecipientsByMemberIds,
    args: { RecipientMemberIds: extractData.GetReviewerMemberIdsFromSession }
});
setEventsActions([
    NotificationsEnums.Event.GoalCloseRequested.Name,
    NotificationsEnums.Event.GoalSetRequested.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.ApproverMemberId }
});
setEventsActions([
    NotificationsEnums.Event.PerformanceReviewsCreated.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.CycleCreatedBy }
});
setEventsActions([
    NotificationsEnums.Event.GoalCycleParticipantUploadError.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.MemberId }
});
setEventsActions([
    NotificationsEnums.Event.GoalCycleBuilt.Name,
    NotificationsEnums.Event.GoalCycleParticipantUploadProcessed.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.CycleCycleOwnerUserId }
});
setEventsActions([
    NotificationsEnums.Event.ContributorAdded.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.CollaboratorMemberId }
});
setEventsActions([
    NotificationsEnums.Event.CloseGoalOverdue.Name,
    NotificationsEnums.Event.CloseGoalPrompt.Name,
    NotificationsEnums.Event.GoalOverdueReminder.Name,
    NotificationsEnums.Event.GoalCreationReminder.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.ParticipantOwnerMemberId }
});
setEventsActions([
    NotificationsEnums.Event.CloseAdhocGoalPrompt.Name,
    NotificationsEnums.Event.CloseSingleAdhocGoalReminder.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.OwnerMemberId }
});
setEventsActions([
    NotificationsEnums.Event.GoalCheckIn.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.OwnerMemberIdDot }
});
setEventsActions([
    NotificationsEnums.Event.GoalCycleOwnershipTransferred.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.ToMemberMemberId }
});
setEventsActions([
    NotificationsEnums.Event.CoachingNoteReceived.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.RecipientMemberId }
});
setEventsActions([
    NotificationsEnums.Event.CommentCoaching.Name
], {
    auth: authorities.CommentCoaching,
    args: { MemberId: extractData.RecipientMemberId }
});
setEventsActions([
    NotificationsEnums.Event.CreditBillMeLater.Name,
    NotificationsEnums.Event.CreditPurchased.Name,
    NotificationsEnums.Event.ReportNotProcessed.Name,
    NotificationsEnums.Event.PasswordResetRequestCreated.Name,
    NotificationsEnums.Event.PasswordChanged.Name,
    NotificationsEnums.Event.UserLockedOut.Name,
    NotificationsEnums.Event.TangoGiftCard.Name,
    NotificationsEnums.Event.ExportGroupDataRequest.Name,
    NotificationsEnums.Event.AuthCodeCreated.Name,
    NotificationsEnums.Event.UserTagged.Name,
    NotificationsEnums.Event.ResendWelcomeEmailCompleted.Name,
    NotificationsEnums.Event.UserNotificationEmailChanged.Name,
    NotificationsEnums.Event.ProductIdeaRejected.Name,
    NotificationsEnums.Event.ProductIdeaPurchased.Name,
    NotificationsEnums.Event.FeedbackCycleClosedOrArchived.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.UserId }
});
setEventsActions([
    NotificationsEnums.Event.ReportReadyToDownload.Name,
    NotificationsEnums.Event.YearSummaryReportReady.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.RequesterUserId }
});
setEventsActions([
    NotificationsEnums.Event.ReviewRejected.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.RejecteeUserId }
});
setEventsActions([
    NotificationsEnums.Event.ReviewRequestReject.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.RejectorUserId }
});
setEventsActions([
    NotificationsEnums.Event.ReviewRequestUnsubmit.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.AdminUserId }
});
setEventsActions([
    NotificationsEnums.Event.GiveRecognitionError.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.RecognitionIssuerMemberUserId }
});
setEventsActions([
    NotificationsEnums.Event.ServiceAwardPointMissing.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.ServiceAwardPointUserId }
});
setEventsActions([
    NotificationsEnums.Event.RecognitionReceived.Name,
    NotificationsEnums.Event.WelcomeReceived.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.RecognitionRecipientMemberUserId }
});
setEventsActions([
    NotificationsEnums.Event.TrackAssigned.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.TrackAssignedMemberUserId }
});
setEventsActions([
    NotificationsEnums.Event.XpOrderPlacedGifter.Name,
    NotificationsEnums.Event.XpOrderPlacedRequester.Name,
    NotificationsEnums.Event.XpOrderCancelledRequester.Name,
    NotificationsEnums.Event.XpOrderCancelledGifter.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.ProductOrderRequesterUserId }
});
setEventsActions([
    NotificationsEnums.Event.XpOrderCancelledRecipient.Name,
    NotificationsEnums.Event.XpOrderPlacedRecipient.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.ProductOrderRecipientUserId }
});
setEventsActions([
    NotificationsEnums.Event.UnsubmittedReview.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.ReviewMemberId}
});
setEventsActions([
    NotificationsEnums.Event.FeedbackReceived.Name,
    NotificationsEnums.Event.FeedbackComment.Name,
    NotificationsEnums.Event.FeedbackRequested.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.RecipientId }
});
setEventsActions([
    NotificationsEnums.Event.GroupNewsPublished.Name
], {
    auth: authorities.GroupNewsPublished
});
setEventsActions([
    NotificationsEnums.Event.MilestoneApproved.Name
], {
    auth: authorities.MilestoneApproved
});
setEventsActions([
    NotificationsEnums.Event.MilestoneCompleted.Name,
    NotificationsEnums.Event.TrackCompleted.Name,
    NotificationsEnums.Event.TrackCompletionRequested.Name
], {
    auth: authorities.GetTrackCompletionRequest
});
setEventsActions([
    NotificationsEnums.Event.OffBoardMember.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.OffBoardUserId }
});
setEventsActions([
    NotificationsEnums.Event.PublicRecognitionReceived.Name,
    NotificationsEnums.Event.PublicFeedbackReceived.Name
], {
    auth: authorities.PublicRecognitionRatingReceived
});
setEventsActions([
    NotificationsEnums.Event.RefundCreditsComplete.Name
], {
    auth: authorities.RefundCredit
});
setEventsActions([
    NotificationsEnums.Event.OverdueMilestones.Name
], {
    auth: authorities.OverdueMilestones
});
setEventsActions([
    NotificationsEnums.Event.XpProductItemExpired.Name
], {
    auth: authorities.XpProductItemExpired
});
setEventsActions([
    NotificationsEnums.Event.XpOrderPlacedAdmin.Name
], {
    auth: authorities.XpOrderPlacedAdmin
});
setEventsActions([
    NotificationsEnums.Event.AdminIssuedPoints.Name
], {
    auth: authorities.GetAdminIssuedPoints
});
setEventsActions([
    NotificationsEnums.Event.YouSubmittedReview.Name,
    NotificationsEnums.Event.OtherSubmittedReview.Name
], {
    auth: authorities.GetRecipientByMemberId,
    args: { MemberId: extractData.PeopleMemberId }
});
setEventsActions([
    NotificationsEnums.Event.CreatedbySubmittedReview.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.ReviewCreatedBy }
});
setEventsActions([
    NotificationsEnums.Event.ReviewReadyToView.Name
], {
    auth: authorities.ReviewReadyToView
});
setEventsActions([
    NotificationsEnums.Event.ReviewReadyToSignOff.Name
], {
    auth: authorities.ReviewReadyToSignOff
});
setEventsActions([
    NotificationsEnums.Event.TangoOrderLoadUserError.Name,
    NotificationsEnums.Event.TangoGiftcardOrderRequestError.Name,
    NotificationsEnums.Event.ManualGiftcardOrderSubmittedAdmin.Name,
    NotificationsEnums.Event.TangoErrorInGiftcardPurchase.Name
], {
    auth: authorities.TangoErrorInGiftcardPurchase
});
setEventsActions([
    NotificationsEnums.Event.UserRequestedInfo.Name
], {
    auth: authorities.UserRequestedInfo
});
setEventsActions([
    NotificationsEnums.Event.EventBusError.Name,
    NotificationsEnums.Event.BatchEngineError.Name,
    NotificationsEnums.Event.ScheduledOffboardError.Name
], {
    auth: authorities.EventBusError
});
setEventsActions([
    NotificationsEnums.Event.MonthlyInvoice.Name
], {
    auth: authorities.InvoiceInfo
});
setEventsActions([
    NotificationsEnums.Event.ProductIdeaApproved.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.ProductIdeaSuggesterUserId }
});
setEventsActions([
    NotificationsEnums.Event.ProductIdeaSuggested.Name
], {
    auth: authorities.GetUserInfoByUserId,
    args: { UserInfoUserId: extractData.PointAdminUserId }
});
setEventsActions([
    NotificationsEnums.Event.CampaignFunded.Name
], {
    auth: authorities.GetQueueForCampaignNotifications
});
setEventsActions([
    NotificationsEnums.Event.XpCampaignItemExpired.Name
], {
    auth: authorities.CampaignExpired
});

module.exports = function (params, callback) {
    var newParams = {
            correlationId: params.correlationId,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            EventName: params.EventName,
            NotificationQueueItem: params.NotificationQueueItem,
            NotificationQueueItems: params.NotificationQueueItems,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        },
        authority = AuthorityFactory[params.NotificationEvent],
        args;
    if (authority && typeof authority.auth === 'function') {
        args = authority.args;
        if (args) {
            Object.keys(args).forEach(function (key) {
                if (typeof args[key] === 'function') {
                    newParams[key] = args[key](params);
                }
            });
        }
        authority.auth(newParams, callback);
        return;
    }
    callback(params.NotificationEvent + ' --- Notification Address Authority: Entity type not supported for email.');
};
