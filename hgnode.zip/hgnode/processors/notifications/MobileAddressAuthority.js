/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    MobileAddressAuthority = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);
        var EntityCache = require('../../framework/EntityCache.js'),
            NotificationsEnums = require('../../enums/NotificationsEnums.js'),
            HgLog = require('../../framework/HgLog'),
            getUnreadMessageNumbersByUserIds = function (userIds, callback) {
                if (!userIds.length) {
                    return callback(null, []);
                }
                var userIdCountPairs = [];
                EntityCache.MobileNotificationItem.find({UserId: {$in: userIds}, Viewed: false}, {UserId: true}, function (err, items) {
                    if (err) {
                        return callback(null, userIdCountPairs);
                    }
                    userIds.forEach(function (userId) {
                        var userItems = items.filter(function (item) {
                                return item.UserId === userId;
                            });
                        userIdCountPairs.push({
                            UserId: userId,
                            Count: userItems.length
                        });
                    });
                    callback(null, userIdCountPairs);
                });
            };

        this.GetAddressees = function (params, callback) {
            var onlineUserIds = [],
                pair,
                userIds = [],
                query,
                projection;

            switch (params.NotificationEvent) {
            case NotificationsEnums.Event.Birthday.Name:
                userIds = [params.Data.user.hgId];
                break;
            case NotificationsEnums.Event.CongratsReceived.Name:
            case NotificationsEnums.Event.RecognitionReceived.Name:
                userIds = [params.Data.Recognition.RecipientMember.UserId];
                break;
            case NotificationsEnums.Event.RecognitionCommentReceived.Name:
                userIds = params.Data.Comment.Recipients
                    .filter(function (r) {
                        return r.UserId !== params.Data.CommentUserId;
                    })
                    .map(function (user) {
                        return user.UserId;
                    });
                break;
            case NotificationsEnums.Event.ConversationStarted.Name:
            case NotificationsEnums.Event.FeedbackReceived.Name:
            case NotificationsEnums.Event.FeedbackRequested.Name:
            case NotificationsEnums.Event.ConversationComment.Name:
                userIds = [params.Data.RecipientId];
                break;
            case NotificationsEnums.Event.SurveyDelivered.Name:
            case NotificationsEnums.Event.SurveyDueSoon.Name:
                userIds = [params.Data.UserId];
                break;
            }
            if (userIds.length) {
                query = {
                    hgId: {$in: userIds},
                    DeviceUuid: {$exists: true}
                };
            } else if (params.NotificationEvent ===  NotificationsEnums.Event.GroupNewsPublished.Name) {
                query = {
                    'UserContext.CurrentGroupId': params.Data.GroupId,
                    DeviceUuid: {$exists: true}
                };
            }
            if (!query) {
                return callback(null, {UserIds: onlineUserIds, Addressees: []});
            }
            projection = {
                _id : 0,
                UserId : '$hgId',
                DevicePlatform : '$DevicePlatform',
                DeviceUuid : '$DeviceUuid',
                DeviceToken : '$DeviceToken',
                RegistrationId : '$RegistrationId',
                DeviceVersion : '$DeviceVersion'
            };

            EntityCache.UserInfoWithToken.aggregate([{$match: query}, {$project: projection}],
                     function (err, addressees) {
                    if (err || !addressees) {
                        callback(err);
                        return;
                    }
                    addressees.forEach(function (a) {
                        if (onlineUserIds.indexOf(a.UserId) === -1) {
                            onlineUserIds.push(a.UserId);
                        }
                    });
                    getUnreadMessageNumbersByUserIds(onlineUserIds, function (err, userIdCountPairs) {
                        if (err) {
                            HgLog.error({methodName: 'GetAddressees', error: err});
                        }
                        addressees.forEach(function (addressee) {
                            pair = userIdCountPairs.filter(function (userIdCountPair) {
                                return userIdCountPair.UserId === addressee.UserId;
                            });
                            if (pair && pair.length === 1) {
                                addressee.UnreadMessageNumber = pair[0].Count || 0;
                            }
                        });
                        callback(null, {UserIds : onlineUserIds, Addressees : addressees});
                    });
                });
        };
    };

module.exports = MobileAddressAuthority;
