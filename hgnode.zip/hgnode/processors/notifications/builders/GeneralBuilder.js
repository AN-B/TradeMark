/*jslint node:true es5:true*/
var GeneralBuilder = function () {
    'use strict';
    var DateHelper = require('../../../util/DateHelper');

    this.ScheduledOffboardError = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            buildErrorInfo = function (memberOffboardErrors) {
                var errorMessage = '';
                memberOffboardErrors.forEach(function (memberOffboardError) {
                    errorMessage += memberOffboardError.ActivitySummary + ": " + memberOffboardError.Error + '<br>';
                });
                return errorMessage;
            };

        notificationQueueItem.MergeFields = {
            error_info: buildErrorInfo(params.Data)
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.EventBusError = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;

        notificationQueueItem.MergeFields = {
            item_info: params.Data.Item,
            audit_info: params.Data.Audit
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.BatchEngineError = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            error: params.Data.Error ? ('Error: ' + params.Data.Error) : '',
            batch_type: params.Data.BatchType,
            batch_id: params.Data.BatchId,
            number_records_processed: params.Data.NumProcessedRecords
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.RefundCreditsComplete = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            admin_user_name: params.Data.AdminUserName,
            employee_name: params.Data.EmployeeName,
            count_credits_refunded: params.Data.CreditAmount,
            refund_date: DateHelper.formatDateStringFromTimestamp(new Date())
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.MonthlyInvoice = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;

        notificationQueueItem.MergeFields = {
            download_url: params.Data.DownloadUrl
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
};

module.exports = GeneralBuilder;