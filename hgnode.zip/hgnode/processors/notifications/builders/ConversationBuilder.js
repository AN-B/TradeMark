"use strict";
var config = require('../../../configurations/config');
function getUrl(memId, recId) {
    return [config.protocol, config.baseUrl, '#/Profile/Feedback/Comment/', memId, '/', recId].join('');
}
function FeedbackReceived(params, callback) {
    params.NotificationQueueItem.MergeFields = {
        sender_name : params.Data.Name,
        feedback_url: getUrl(params.Data.UrlMemberId, params.Data.Id)
    };
    params.NotificationQueueItem.Subject =  params.Data.Name + ' just gave you feedback!';
    callback(null, {
        NotificationQueueItem: params.NotificationQueueItem,
        Data : params.Data,
        NotificationEvent : params.NotificationEvent,
        DispatchOption : params.DispatchOption
    });
}
function FeedbackComment(params, callback) {
    params.NotificationQueueItem.MergeFields = {
        sender_name : params.Data.Name,
        feedback_url: getUrl(params.Data.UrlMemberId, params.Data.Id)
    };
    params.NotificationQueueItem.Subject = params.Data.Name + ' just commented on your feedback!';
    callback(null, {
        NotificationQueueItem: params.NotificationQueueItem,
        Data : params.Data,
        NotificationEvent : params.NotificationEvent,
        DispatchOption : params.DispatchOption
    });
}
function FeedbackRequested(params, callback) {
    params.NotificationQueueItem.MergeFields = {
        sender_name : params.Data.Name,
        feedback_url: getUrl(params.Data.UrlMemberId, params.Data.Id)
    };
    params.NotificationQueueItem.Subject =  params.Data.Name + ' requested your feedback!';
    callback(null, {
        NotificationQueueItem: params.NotificationQueueItem,
        Data : params.Data,
        NotificationEvent : params.NotificationEvent,
        DispatchOption : params.DispatchOption
    });
}
module.exports = {
    FeedbackReceived: FeedbackReceived,
    FeedbackComment: FeedbackComment,
    FeedbackRequested: FeedbackRequested
};

