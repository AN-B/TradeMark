/*jslint node:true es5:true*/
var ProvisionBuilder = function () {
    "use strict";
    var config = require('../../../configurations/config'),
        htmlHelper = require('../../../helpers/htmlHelper.js'),
        ProvisionTemplates = {
            ProvisionFailed: require('../../../../static/templates/server/provision/processing-failed.html')
        };
    this.GetProcessingFailedContent = function (params) {
        return {
            first_name: params.Data.FullName,
            error: Array.isArray(params.Data.Error) ? params.Data.Error.map(function (item, index) {
                return htmlHelper.replaceTokens(ProvisionTemplates.ProvisionFailed, {
                    Index: index + 1,
                    Error: item
                });
            }).join('') : params.Data.Error,
            note: params.Data.Note,
            filename: params.Data.FileName
        };
    };
    this.ProcessingFailed = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            fullname: params.Data.FullName,
            error: Array.isArray(params.Data.Error) ? params.Data.Error.map(function (item, index) {
                return htmlHelper.replaceTokens(ProvisionTemplates.ProvisionFailed, {
                    Index: index + 1,
                    Error: item
                });
            }).join('') : params.Data.Error,
            filename: params.Data.FileName
        };
        callback(null, {NotificationQueueItem: params.NotificationQueueItem, Data: params.Data, NotificationEvent: params.NotificationEvent, DispatchOption: params.DispatchOption});
    };
    this.FileRequiresApproval = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            fullname: params.Data.FullName,
            action: params.Data.Action,
            filename: params.Data.FileName,
            confirm_url: [config.protocol, config.baseUrl, 'provision.html#/Provisioning/Company/Confirm/', params.Data.Id].join('')
        };
        callback(null, {NotificationQueueItem: params.NotificationQueueItem, Data: params.Data, NotificationEvent: params.NotificationEvent, DispatchOption: params.DispatchOption});
    };
    this.FileProcessed = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            fullname: params.Data.FullName,
            filename: params.Data.FileName
        };
        callback(null, {NotificationQueueItem: params.NotificationQueueItem, Data: params.Data, NotificationEvent: params.NotificationEvent, DispatchOption: params.DispatchOption});
    };
    this.ResendWelcomeEmailCompleted = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            first_name: params.NotificationQueueItem.RecipientList[0].Name,         // Currently assumed that only one admin will receive the notification
            group_name: params.Data.GroupName
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.AccountsMerged = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            oldUserName: params.Data.OldUserName,
            newUserName: params.Data.NewUserName
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
};

module.exports = ProvisionBuilder;