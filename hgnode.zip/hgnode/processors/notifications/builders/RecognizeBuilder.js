/*jslint node:true es5:true*/
var RecognizeBuilder = function () {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        config = require('../../../configurations/config'),
        recognition = 'recognition',
        recognitionHelper = require('../../../helpers/recognitionHelper.js'),
        i18nHelper = require('../../../helpers/i18nHelper.js');
    function commentInlineCss(comment) {
        return comment.split('<input').join('<input style="background-color:transparent;color:#666;border:0;padding:0;margin:0;font-size:14px;font-family:helvetica;"');
    }
    function commentReceived(params, callback) {
        var CareerTrack = EntityCache.CareerTrack,
            comment = params.Data.Comment,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem,
            groupId = params.Data.GroupId;

        mergeField.commentor_name = comment.CommenterFirstName + ' ' + comment.CommenterLastName;
        mergeField.comment = comment.Comment;

        if (comment.EntityType === 'Milestone') {
            mergeField.comment_url = config.protocol + config.baseUrl + '#/Track/Iso/' + comment.EntityId + '?gid=' + groupId;
        } else if (comment.EntityType === 'Coaching') {
            mergeField.comment_url = config.protocol + config.baseUrl + '#/Track/Iso/' + comment.EntityId + '/Coaching' + '?gid=' + groupId;
        } else if (comment.EntityType === 'Recognition') {
            mergeField.comment_url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + comment.EntityId + '?gid=' + groupId;
        }

        if (comment.EntityType === 'Milestone' || comment.EntityType === 'Coaching') {
            CareerTrack.findOne({$or: [{'CareerTrackTemplate.Goal.hgId': comment.EntityId}, {'CareerTrackTemplate.MileStones.hgId': comment.EntityId}]}, function (err, track) {
                mergeField.entity_type = track.CareerTrackTemplate.Title + ' track';
                mergeField.track_name = track.CareerTrackTemplate.Title;

                notificationQueueItem.MergeFields = mergeField;
                callback(null, {
                    NotificationQueueItem: notificationQueueItem,
                    Data: params.Data,
                    NotificationEvent: params.NotificationEvent,
                    DispatchOption: params.DispatchOption
                });
            });
        } else {
            mergeField.entity_type = recognition;
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        }
    }

    //looks like its structured for more than one type of comment
    //might need to separate into each builder
    this.RecognitionCommentReceived = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem,
            recipient = notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0] : {};
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.RecognitionCommentReceived.body_txt', {
            first_name: recipient.Name || '',
            commentor_name: params.Data.Comment.CommenterFirstName + ' ' + params.Data.Comment.CommenterLastName,
            comment: commentInlineCss(params.Data.Comment.Comment)
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + Data.Comment.EntityId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.RecognitionCommentReceived.link_txt');
        notificationQueueItem.MergeFields.optout_txt = i18nHelper.translate(Data.i18n, 'eml.RecognitionCommentReceived.optout_txt', {
            optout_url: config.protocol + config.baseUrl + '#/Recognize/OptOut/' + Data.Comment.EntityId + (recipient.MemberId ? '/' + recipient.MemberId : '') + '?gid=' + Data.GroupId
        });
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.RecognitionCommentReceived.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.RecognitionCommentReceived.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.CommentReceived = function (params, callback) {
        commentReceived(params, callback);
    };

    this.RecognitionPointsAdded = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            recognition_url: config.protocol + config.baseUrl + '#/Recognize/Iso/' + params.Data.EntityId + '?gid=' + params.Data.GroupId,
            first_name: params.Data.RecepientsFirstName,
            giver_name: params.Data.GiverName,
            points_added: params.Data.Points
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.RecognitionGive = function (params, callback) {
        var data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            link_url: config.protocol + config.baseUrl + '#/Recognize/Company/GiveEveryday' + '?gid=' + data.GroupId,
            Subject: i18nHelper.translate(data.i18n, 'eml.RecogntionGive.sub'),
            teaser: i18nHelper.translate(data.i18n, 'eml.RecogntionGive.tea'),
            body_txt: i18nHelper.translate(data.i18n, 'eml.RecogntionGive.body_txt', {
                first_name: data.ReportName,
                program_name: data.GroupName,
                notes: data.Notes || ''
            }),
            link_txt: i18nHelper.translate(data.i18n, 'eml.RecogntionGive.link_txt'),
            thank: i18nHelper.translate(data.i18n, 'eml.common.thank')
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.WelcomeReceived = function (params, callback) {
        var Data = params.Data,
            mergeField =  {},
            theGiver,
            notificationQueueItem = params.NotificationQueueItem,
            getGiverName = function (recognition, group) {
                if (recognition.CreatorMember && recognition.CreatorMember.FullName) {
                    return recognition.CreatorMember.FullName;
                }
                if (recognition.TriggerInfo && recognition.TriggerInfo.GroupName) {
                    return recognition.TriggerInfo.GroupName;
                }
                if (group) {
                    return group.ProgramName;
                }
            };

        theGiver = getGiverName(Data.Recognition, Data.Group);
        if (Data.Recognition.Template.Publicity !== 'Private' && Data.Recognition.PublicCreatorInfo && Data.Recognition.PublicCreatorInfo.FullName && !theGiver) {
            theGiver = Data.Recognition.PublicCreatorInfo.FullName;
            if (Data.Recognition.PublicCreatorInfo.CompanyName && Data.Recognition.PublicCreatorInfo.CompanyName.length) {
                theGiver += ' (' + Data.Recognition.PublicCreatorInfo.CompanyName + ')';
            }
        }
        mergeField.body_txt = i18nHelper.translate(Data.i18n, 'eml.WelcomeReceived.body_txt', {
            first_name: Data.Recognition.RecipientMember.FirstName,
            recog_giver: theGiver,
            template_title: recognitionHelper.getRecognitionTitle(Data.i18n, Data.Recognition)
        });
        mergeField.link_txt = i18nHelper.translate(Data.i18n, 'eml.WelcomeReceived.link_txt');
        mergeField.recog_link = config.protocol + config.baseUrl + '#/Recognize/Iso/' + Data.Recognition.BatchId + '?gid=' + Data.GroupId;
        mergeField.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        mergeField.teaser = i18nHelper.translate(Data.i18n, 'eml.WelcomeReceived.tea');
        notificationQueueItem.MergeFields = mergeField;
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.WelcomeReceived.sub', {
            program_name: theGiver
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.CommentCoaching = function (params, callback) {
        var mergeField = {},
            Data = params.Data;
        EntityCache.Comment.findOne({hgId: Data.CoachingNoteId}, function (error, note) {
            if (error || !note) {
                callback('Error loading the coaching note');
                return;
            }
            mergeField.coaching_url = config.protocol + config.baseUrl +
                    '#/Profile/Coaching/' + note.Recipient.MemberId + '/' + Data.CoachingNoteId + '?gid=' + Data.GroupId;
            EntityCache.Member.findOne({hgId: Data.CommentorMemberId}, function (error, member) {
                if (error || !member) {
                    callback('Error loading the commentor');
                    return;
                }
                mergeField.commentor_name = member.FullName;
                params.NotificationQueueItem.MergeFields = mergeField;
                params.NotificationQueueItem.Subject =  mergeField.commentor_name + ' just commented on your coaching note';
                callback(null, {NotificationQueueItem: params.NotificationQueueItem, Data: Data, NotificationEvent: params.NotificationEvent, DispatchOption: params.DispatchOption});
            });
        });
    };

    this.CommentGoal = function (params, callback) {
        var Data = params.Data;
        params.NotificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.CommentGoal.sub', {
            name: Data.CommentorName
        });
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(Data.i18n, 'eml.CommentGoal.tea'),
            link_txt: i18nHelper.translate(Data.i18n, 'eml.CommentGoal.lnk'),
            link_url: config.protocol + config.baseUrl + '#/Profile/GoalDetails/View/' + Data.Goal.Owner.MemberId + '/' + Data.Goal.hgId + '?gid=' + Data.GroupId,
            thank: i18nHelper.translate(Data.i18n, 'eml.common.thank'),
            body_txt: i18nHelper.translate(Data.i18n, 'eml.CommentGoal.bod', {
                first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '',
                commentor_name: Data.CommentorName
            })
        };
        callback(null, {NotificationQueueItem: params.NotificationQueueItem, Data: Data, NotificationEvent: params.NotificationEvent, DispatchOption: params.DispatchOption});
    };
    this.UserTagged = function (params, callback) {
        var Data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            link_txt: i18nHelper.translate(Data.i18n, 'eml.UserTagged.link_txt'),
            link_url: config.protocol + config.baseUrl + '#/Recognize/Iso/' + Data.RecognitionId + '?gid=' + Data.GroupId,
            thank: i18nHelper.translate(Data.i18n, 'eml.common.thank'),
            teaser: i18nHelper.translate(Data.i18n, 'eml.UserTagged.tea'),
            body_txt: i18nHelper.translate(Data.i18n, 'eml.UserTagged.body_txt', {
                first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '',
                commentor_name: Data.Comment.CommenterFirstName + ' ' + Data.Comment.CommenterLastName,
                comment: commentInlineCss(Data.Comment.Comment),
                entity_type: recognition
            })
        };
        params.NotificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.UserTagged.sub', {
            commentor_name: Data.Comment.CommenterFirstName + ' ' + Data.Comment.CommenterLastName
        });
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.CoachingNoteReceived = function (params, callback) {
        var Data = params.Data,
            mergeField = {
                manager_name: Data.ManagerFullName,
                coaching_url: config.protocol + config.baseUrl + '#/Profile/Coaching/' + Data.RecipientMemberId + '/' + Data.NoteId + '?gid=' + Data.GroupId
            };
        params.NotificationQueueItem.MergeFields = mergeField;
        params.NotificationQueueItem.Subject =  i18nHelper.translate(Data.i18n, 'eml.CoachingNoteReceived.sub', {
            manager_full_name: Data.ManagerFullName
        });
        callback(null, {NotificationQueueItem: params.NotificationQueueItem, Data: Data, NotificationEvent: params.NotificationEvent, DispatchOption: params.DispatchOption, CompleteCallback: params.CompleteCallback});
    };

    this.ServiceAwardPointMissing = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.ServiceAwardPointMissing.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            recipient_full_name: Data.RecipientMemberName,
            badge_title: Data.Title,
            point_number: Data.PointMissingTotal
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + Data.BatchId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.ServiceAwardPointMissing.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.ServiceAwardPointMissing.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.ServiceAwardPointMissing.sub', {
            cycle_title: Data.CycleTitle
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.RecognitionReceived = function (params, callback) {
        var Data = params.Data,
            mergeField =  {},
            theGiver,
            notificationQueueItem = params.NotificationQueueItem,
            getGiverName = function (recognition, group) {
                if (recognition.CreatorMember && recognition.CreatorMember.FullName) {
                    return recognition.CreatorMember.FullName;
                }
                if (recognition.TriggerInfo && recognition.TriggerInfo.GroupName) {
                    return recognition.TriggerInfo.GroupName;
                }
                if (group) {
                    return group.ProgramName;
                }
            };
        theGiver = getGiverName(Data.Recognition, Data.Group);
        if (Data.Recognition.Template.Publicity !== 'Private' && Data.Recognition.PublicCreatorInfo && Data.Recognition.PublicCreatorInfo.FullName && !theGiver) {
            theGiver = Data.Recognition.PublicCreatorInfo.FullName;
            if (Data.Recognition.PublicCreatorInfo.CompanyName && Data.Recognition.PublicCreatorInfo.CompanyName.length) {
                theGiver += ' (' + Data.Recognition.PublicCreatorInfo.CompanyName + ')';
            }
        }
        mergeField.body_txt = i18nHelper.translate(Data.i18n, 'eml.RecognitionReceived.body_txt', {
            first_name: Data.Recognition.RecipientMember.FirstName,
            recog_giver: theGiver,
            template_title: recognitionHelper.getRecognitionTitle(Data.i18n, Data.Recognition)
        });
        mergeField.link_txt = i18nHelper.translate(Data.i18n, 'eml.RecognitionReceived.link_txt');
        mergeField.recog_link = config.protocol + config.baseUrl + '#/Recognize/Iso/' + Data.Recognition.BatchId + '?gid=' + Data.GroupId;
        mergeField.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        mergeField.teaser = i18nHelper.translate(Data.i18n, 'eml.RecognitionReceived.tea');
        notificationQueueItem.MergeFields = mergeField;
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.RecognitionReceived.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    //a member was recognized with Company
    // and/or Member Ratings with/without a predefined message
    this.PublicRecognitionReceived = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem,
            recog_giver = Data.Recognition.PublicCreatorInfo.FullName.length > 0 ? Data.Recognition.PublicCreatorInfo.FullName : '',
            recog_giver_company = Data.Recognition.PublicCreatorInfo.CompanyName > 0 ? '(' + Data.Recognition.PublicCreatorInfo.CompanyName + ')' : '';
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.body_txt', {
            company_name: Data.Recognition.RecipientMember.GroupName,
            recipient_full_name: Data.Recognition.RecipientMember.FullName,
            if_canned_message_selected: Data.Recognition.CannedMessage,
            company_rating_number: Data.Recognition.CompanyRating ? Data.Recognition.CompanyRating.toString() : i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.none'),
            recipient_first_name_rating_number: Data.Recognition.MemberRating ? Data.Recognition.MemberRating.toString() : i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.none'),
            recog_giver: recog_giver,
            recog_giver_company: recog_giver_company,
            template_title: Data.Recognition.Template.Title
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + Data.Recognition.BatchId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.tea', {
            recipient_full_name: Data.Recognition.RecipientMember.FullName
        });
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
    this.GiveRecognitionError = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.GiveRecognitionError.body_txt', {
            issuer_name: Data.IssuerUserFullName,
            error_message: i18nHelper.translate(Data.Lang, Data.ErrorMessage)
        });
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.GiveRecognitionError.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.GiveRecognitionError.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.PublicFeedbackReceived = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.PublicFeedbackReceived.body_txt', {
            company_name: Data.Recognition.RecipientMember.GroupName,
            recipient_full_name: Data.Recognition.RecipientMember.FullName,
            if_canned_message_selected: Data.Recognition.CannedMessage,
            company_rating_number: Data.Recognition.CompanyRating ? Data.Recognition.CompanyRating.toString() : i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.none'),
            recipient_first_name_rating_number: Data.Recognition.MemberRating ? Data.Recognition.MemberRating.toString() : i18nHelper.translate(Data.i18n, 'eml.PublicRecognitionReceived.none'),
            recog_giver: Data.Recognition.PublicCreatorInfo.FullName + ' (' + Data.Recognition.PublicCreatorInfo.CompanyName + ')'
        });
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.PublicFeedbackReceived.tea', {
            recipient_full_name: Data.Recognition.RecipientMember.FullName
        });
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.PublicFeedbackReceived.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
};

module.exports = RecognizeBuilder;