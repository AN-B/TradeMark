/*jslint node:true es5:true*/
var PerformBuilder = function () {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        DateHelper = require('../../../util/DateHelper'),
        config = require('../../../configurations/config'),
        htmlHelper = require('../../../helpers/htmlHelper.js'),
        PerformTemplates = {
            ReviewClosed: require('../../../../static/templates/server/perform/perform-review-closed.html')
        },
        getPeopleNameByType = function (review, peopleType) {
            var i,
                len,
                fullName = '';
            for (i = 0, len = review.Peoples.length; i < len; i += 1) {
                if (review.Peoples[i].PeopleType === peopleType) {
                    fullName = review.Peoples[i].MemberFullname;
                    break;
                }
            }
            return fullName;
        },
        mapPeopleTypeName = function (originalPeopleTypeName) {
            if (originalPeopleTypeName === 'Subject') {
                return 'Reviewee';
            }
            return originalPeopleTypeName;
        },
        getImageStorePath = function () {
            return config.s3store.imageStore[config.nextIndex()];
        };

    function cycleReviewsClosedOrArchivedBuilder(params, callback) {
        var peopleReviews = params.Data.PeopleReviews,
            subjectImgSrc = config.s3store.s3bucket ? '' : config.baseUrl;
        params.NotificationQueueItem.MergeFields = {
            first_name : params.Data.FullName,
            cycle_name : peopleReviews[0].CycleName,
            reviews_table: peopleReviews.map(function (review) {
                return htmlHelper.replaceTokens(htmlHelper.toggleAreas(PerformTemplates.ReviewClosed, {
                    HasManagerAvatar: review.ManagerSummary,
                    HasManagerSummary: review.ManagerSummary
                }), {
                    SubjectAvatarUrl: config.protocol + subjectImgSrc + getImageStorePath() + '/' + config.filepath.UserProfile + review.SubjectSummary.UserId + '.jpg',
                    ManagerAvatarUrl: review.ManagerSummary ? config.protocol + subjectImgSrc + getImageStorePath() + '/' + config.filepath.UserProfile + review.ManagerSummary.UserId + '.jpg' : '',
                    ReviewTitle: review.ReviewTitle,
                    CycleName: review.CycleName,
                    RevieweeFullName: review.SubjectSummary.FullName,
                    ManagerFullName: review.ManagerSummary.FullName,
                    PeopleType: mapPeopleTypeName(review.PeopleType),
                    DueDate: DateHelper.formatDateStringFromTimestamp(review.DueDate)
                });
            }).join('')
        };
        params.NotificationQueueItem.Subject = peopleReviews[0].CycleName + ' no longer requires your completion.';
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    }

    this.CycleReviewsClosedOrArchived = function (params, callback) {
        cycleReviewsClosedOrArchivedBuilder(params, callback);
    };

    this.RemovedFromCycle = function (params, callback) {
        cycleReviewsClosedOrArchivedBuilder(params, callback);
    };

    this.PastOverdueDelivered = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            peopleReviews = params.Data.PeopleReviews,
            reviews_table = '',
            curReview = '',
            i,
            subjectImgSrc,
            managerImgSrc;
        notificationQueueItem.MergeFields = {
            first_name : params.Data.FullName
        };
        if (peopleReviews.length === 1) {
            notificationQueueItem.Subject = 'Your review is late!';
        } else {
            notificationQueueItem.Subject = 'Your reviews are late!';
        }
        for (i = 0; i < peopleReviews.length; i += 1) {
            curReview = '';
            subjectImgSrc = '';
            managerImgSrc = '';
            if (config.s3store.s3bucket === '') {
                subjectImgSrc = config.baseUrl;
                managerImgSrc = config.baseUrl;
            }
            subjectImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + peopleReviews[i].SubjectSummary.UserId;
            if (peopleReviews[i].ManagerSummary) {
                managerImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + peopleReviews[i].ManagerSummary.UserId;
            }
            curReview += '<table width="540" border="0" cellpadding="0" cellspacing="0" style="padding:15px 10px 10px 15px;border:1px dashed #a8a48e;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td width="90">' +
                '<a href="' + config.protocol + config.baseUrl + '#/Profile/Perform/' + peopleReviews[i].SubjectSummary.MemberId + '/' + peopleReviews[i].ReviewId + '/1' +
                '" style="color:#86a64b;text-decoration:none;">' +
                '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + subjectImgSrc  + '.jpg">' +
                '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + managerImgSrc  + '.jpg">' +
                '</a></td><td><a style="color:#86a64b;text-decoration:none;" href="' +
                config.protocol + config.baseUrl + '#/Profile/Perform/' + peopleReviews[i].SubjectSummary.MemberId + '/' + peopleReviews[i].ReviewId + '/1' + '" ><font face="Helvetica,sans-serif"><strong>' +
                peopleReviews[i].ReviewTitle + '</strong></font></a></td></tr><tr><td></td><td>';
            curReview += '<table style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td><font face="Helvetica,sans-serif" color="#666666">Cycle Name: ' + peopleReviews[i].CycleName + '</font></td></tr>';
            curReview += '<tr><td><font face="Helvetica,sans-serif" color="#666666">Reviewee: ' + peopleReviews[i].SubjectSummary.FullName + '</font></td></tr>';
            if (peopleReviews[i].ManagerSummary) {
                curReview += '<tr><td><font face="Helvetica,sans-serif" color="#666666">Manager: ' + peopleReviews[i].ManagerSummary.FullName + '</font></td></tr>';
            }
            curReview += '<tr><td><font face="Helvetica,sans-serif" color="#666666">Role: ' + mapPeopleTypeName(peopleReviews[i].PeopleType) + '</font></td></tr>';
            curReview += '<tr><td><font face="Helvetica,sans-serif" color="#666666">Due date: ' + DateHelper.formatDateStringFromTimestamp(peopleReviews[i].DueDate) + '</font></td></tr>';
            curReview += '</tbody></table></td><tr></tbody></table><br />';
            reviews_table += curReview;
        }
        notificationQueueItem.MergeFields.reviews_table = reviews_table;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.ReviewDelivered = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            peopleReviews = params.Data.PeopleReviews,
            reviews_table = '',
            curReview = '',
            i,
            subjectImgSrc,
            managerImgSrc;
        notificationQueueItem.MergeFields = {
            first_name : params.Data.FullName,
            cycle_name : peopleReviews[0].CycleName
            // notes: params.Data.Notes ? "Notes from " + params.Data.SenderName + ":\r\n " + params.Data.Notes : ""
        };
        EntityCache.UserInfo.findOne({hgId : peopleReviews[0].CreatedBy}, function (error, userInfo) {
            var senderName = '';
            if (!error && userInfo && userInfo.UserPersonal) {
                senderName = userInfo.UserPersonal.FullName;
            }
            notificationQueueItem.MergeFields.notes = params.Data.Notes ? "Notes from Administrator " + senderName + ":\r\n " + params.Data.Notes : "";
            notificationQueueItem.Subject = peopleReviews[0].CycleName + ' has been assigned to you!';
            for (i = 0; i < peopleReviews.length; i += 1) {
                curReview = '';
                subjectImgSrc = '';
                managerImgSrc = '';
                if (config.s3store.s3bucket === '') {
                    subjectImgSrc = config.baseUrl;
                    managerImgSrc = config.baseUrl;
                }
                subjectImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + peopleReviews[i].SubjectSummary.UserId;
                if (peopleReviews[i].ManagerSummary) {
                    managerImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + peopleReviews[i].ManagerSummary.UserId;
                }
                curReview += '<table width="540" border="0" cellpadding="0" cellspacing="0" style="padding:15px 10px 10px 15px;border:1px dashed #a8a48e;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td width="90">' +
                    '<a href="' + config.protocol + config.baseUrl + '#/Profile/Perform/' + peopleReviews[i].SubjectSummary.MemberId + '/' + peopleReviews[i].ReviewId + '/1' +
                    '" style="color:#86a64b;text-decoration:none;">' +
                    '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + subjectImgSrc  + '.jpg">' +
                    '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + managerImgSrc  + '.jpg">' +
                    '</a></td><td><a style="color:#86a64b;text-decoration:none;" href="' +
                    config.protocol + config.baseUrl + '#/Profile/Perform/' + params.Data.MemberId + '/' + peopleReviews[i].ReviewId + '/1' + '" ><font face="Helvetica,sans-serif"><strong>' +
                    peopleReviews[i].ReviewTitle + '</strong></font></a></td></tr><tr><td></td><td>';
                curReview += '<table style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><font face="Helvetica,sans-serif" color="#666666">Cycle Name: ' + peopleReviews[i].CycleName + '</font></td></tr>';
                curReview += '<tr><td style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><font face="Helvetica,sans-serif" color="#666666">Reviewee: ' + peopleReviews[i].SubjectSummary.FullName + '</font></td></tr>';
                if (peopleReviews[i].ManagerSummary) {
                    curReview += '<tr><td style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><font face="Helvetica,sans-serif" color="#666666">Manager: ' + peopleReviews[i].ManagerSummary.FullName + '</font></td></tr>';
                }
                curReview += '<tr><td style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><font face="Helvetica,sans-serif" color="#666666">Role: ' + mapPeopleTypeName(peopleReviews[i].PeopleType) + '</font></td></tr>';
                if (peopleReviews[i].DueDate) {
                    curReview += '<tr><td style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><font face="Helvetica,sans-serif" color="#666666">Due date: ' + DateHelper.formatDateStringFromTimestamp(peopleReviews[i].DueDate) + '</font></td></tr>';
                }
                curReview += '</tbody></table></td><tr></tbody></table><br />';
                reviews_table += curReview;
            }
            notificationQueueItem.MergeFields.reviews_table = reviews_table;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption,
                CompleteCallback : params.CompleteCallback
            });
        });
    };

    this.YouSubmittedReview = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            subject = params.Data.Review.Peoples.filter(function (p) {return p.PeopleType === 'Subject'; })[0];
        notificationQueueItem.MergeFields = {
            first_name : params.Data.People.MemberFullname,
            review_title : params.Data.Review.Card.Title,
            cycle_name : params.Data.Review.CycleName,
            subject_name : getPeopleNameByType(params.Data.Review, 'Subject'),
            manager_name : getPeopleNameByType(params.Data.Review, 'Manager'),
            review_url : [config.protocol,
                config.baseUrl,
                '#/Profile/Perform/' + subject.MemberId].join('')
        };
        notificationQueueItem.Subject = 'Thank you for submitting review for ' + params.Data.Review.CycleName;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.ReviewReadyToView = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            subject = params.Data.Review.Peoples.filter(function (p) {return p.PeopleType === 'Subject'; })[0];
        notificationQueueItem.MergeFields = {
            first_name : params.Data.People.MemberFullname,
            review_title : params.Data.Review.Card.Title,
            review_url : [config.protocol, config.baseUrl, '#/Profile/Perform/', subject.MemberId, '/', params.Data.Review.hgId, '/1'].join('')
        };
        notificationQueueItem.Subject = 'Take a look! ' + params.Data.Review.Card.Title + ' is now available for you to view.';
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.ReviewReadyToSignOff = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            reviewTitle = params.Data.Review.Card.Title,
            curReview,
            subjectImgSrc,
            managerImgSrc,
            reviews_table,
            peoples = params.Data.Review.Peoples,
            subjectArray,
            subject,
            managerArray,
            manager,
            profilePerformUrl = [config.protocol, config.baseUrl, '#/Profile/Perform/SignOff/', params.Data.Review.hgId].join('');

        if (peoples.length > 0) {
            subjectArray = params.Data.Review.Peoples.filter(function (e) {
                return e.PeopleType === 'Subject';
            });
            if (subjectArray.length > 0) {
                subject = subjectArray[0];
            }
            managerArray = params.Data.Review.Peoples.filter(function (e) {
                return e.PeopleType === 'Manager';
            });
            if (managerArray.length > 0) {
                manager = managerArray[0];
            }
        }
        curReview = '';
        reviews_table = '';
        subjectImgSrc = '';
        managerImgSrc = '';
        notificationQueueItem.MergeFields = {
            first_name: notificationQueueItem.RecipientList[0] ? notificationQueueItem.RecipientList[0].Name : '',
            review_title: reviewTitle,
            profile_perform_url: profilePerformUrl
        };
        notificationQueueItem.Subject =  params.Data.Review.Card.Title + ' is now ready for you to sign off.';
        if (config.s3store.s3bucket === '') {
            subjectImgSrc = config.baseUrl;
            managerImgSrc = config.baseUrl;
        }
        subjectImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + subject.UserId;
        managerImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + manager.UserId;
        curReview += '<table width="540" border="0" cellpadding="0" cellspacing="0" style="padding:15px 10px 10px 15px;border:1px dashed #a8a48e;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td width="90">' +
            '<a href="' + config.protocol + config.baseUrl + '#/Profile/Perform/' + params.Data.Review.MyMemberId + '/' + params.Data.Review.hgId + '/1' +
            '" style="color:#86a64b;text-decoration:none;">' +
            '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + subjectImgSrc  + '.jpg">' +
            '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + managerImgSrc  + '.jpg">' +
            '</a></td><td><a style="color:#86a64b;text-decoration:none;" href="' +
            config.protocol + config.baseUrl + '#/Profile/Perform/' + params.Data.Review.MyMemberId + '/' + params.Data.Review.hgId + '/1' + '" ><font face="Helvetica,sans-serif"><strong><a style="color:#86a64b;text-decoration:none;" href="' + profilePerformUrl + '"> ' + reviewTitle + ' </a></strong></font></a></td></tr><tr><td></td><td>';
        curReview += '<table style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td><font face="Helvetica,sans-serif" color="#666666">Cycle Name: ' + params.Data.Review.CycleName + '</font></td></tr>';
        curReview += '<tr><td><font face="Helvetica,sans-serif" color="#666666">Reviewee: ' + subject.MemberFullname + '</font></td></tr>';
        curReview += '<tr><td><font face="Helvetica,sans-serif" color="#666666">Manager: ' + manager.MemberFullname + '</font></td></tr>';
        curReview += '</tbody></table></td><tr></tbody></table><br />';
        reviews_table += curReview;
        notificationQueueItem.MergeFields.reviews_table =  reviews_table;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.OtherSubmittedReview = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            subject = params.Data.Review.Peoples.filter(function (p) {return p.PeopleType === 'Subject'; })[0];
        notificationQueueItem.MergeFields = {
            first_name : params.Data.People.MemberFullname,
            review_title : params.Data.Review.Card.Title,
            cycle_name : params.Data.Review.CycleName,
            subject_name : getPeopleNameByType(params.Data.Review, 'Subject'),
            manager_name : getPeopleNameByType(params.Data.Review, 'Manager'),
            review_url : [config.protocol, config.baseUrl, '#/Profile/Perform/', subject.MemberId, '/', params.Data.Review.hgId, '/1'].join(''),
            submitter_name : params.Data.SubmitMemberName
        };
        notificationQueueItem.Subject = params.Data.SubmitMemberName + ' has submitted a review for ' + params.Data.Review.CycleName;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.CreatedbySubmittedReview = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            subject = params.Data.Review.Peoples.filter(function (p) {return p.PeopleType === 'Subject'; })[0];
        notificationQueueItem.MergeFields = {
            review_title : params.Data.Review.Card.Title,
            cycle_name : params.Data.Review.CycleName,
            subject_name : getPeopleNameByType(params.Data.Review, 'Subject'),
            manager_name : getPeopleNameByType(params.Data.Review, 'Manager'),
            review_url : [config.protocol, config.baseUrl, '#/Profile/Perform/', subject.MemberId, '/', params.Data.Review.hgId, '/1'].join(''),
            submitter_name : params.Data.SubmitMemberName
        };
        notificationQueueItem.Subject = params.Data.SubmitMemberName + ' has submitted a review for ' + params.Data.Review.CycleName;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption,
            CompleteCallback : params.CompleteCallback
        });
    };

    this.UnsubmittedReview = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            subject = params.Data.Review.Peoples.filter(function (p) {return p.PeopleType === 'Subject'; })[0];
        notificationQueueItem.MergeFields = {
            first_name : params.Data.ReviewMemberName,
            review_title : params.Data.Review.Card.Title,
            cycle_name : params.Data.Review.CycleName,
            notes: params.Data.Notes ? "Notes from " + params.Data.SenderName + ":\r\n " + params.Data.Notes : "",
            review_url : [config.protocol, config.baseUrl, '#/Profile/Perform/', subject.MemberId, '/', params.Data.Review.hgId, '/1'].join('')
        };
        notificationQueueItem.Subject = "Your review for " + params.Data.Review.CycleName + " has been unsubmitted.";
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption,
            CompleteCallback : params.CompleteCallback
        });
    };

    this.ReviewRequestUnsubmit = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            requester,
            requesterFullName;
        EntityCache.UserInfo.findOne({hgId : params.Data.RequesterUserId}, function (error, requesterUser) {
            if (error) {
                callback(error, null);
                return;
            }
            requesterFullName = requesterUser.UserPersonal.FullName;
            EntityCache.UserInfo.findOne({hgId : params.Data.AdminUserId}, function (error, adminUser) {
                if (error) {
                    callback(error, null);
                    return;
                }
                EntityCache.PerformanceReview.findOne({hgId : params.Data.ReviewId}, function (error, review) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    requester = review.Peoples.filter(function (people) {
                        return people.UserId === params.Data.RequesterUserId;
                    });
                    if (!requester || requester.length !== 1) {
                        callback('Cannot find requester', null);
                        return;
                    }
                    if (requester[0].Anonymous === true) {
                        if (requester[0].AnonymousId) {
                            requesterFullName = 'Anonymous ' + requester[0].AnonymousId;
                        } else {
                            requesterFullName = 'Anonymous';
                        }
                    }
                    notificationQueueItem.MergeFields = {
                        first_name : adminUser.UserPersonal.FirstName,
                        review_title : review.Card.Title,
                        cycle_name : review.CycleName,
                        requester_name : requesterFullName,
                        notes: params.Data.Note ? "Notes from " + requesterFullName + ":\r\n " + params.Data.Note : "",
                        review_url : [config.protocol,
                            config.baseUrl,
                            '#/Admin/Perform/Cycles/Details/',
                            review.CycleId, "/Filter/UnsubmitRequest"].join('')
                    };
                    notificationQueueItem.Subject = requesterFullName + ' has requested to unsubmit review!';
                    callback(null, { NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption, CompleteCallback : params.CompleteCallback});
                });
            });
        });
    };

    this.ReviewRequestReject = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            rejector,
            requester,
            requesterFullName;
        EntityCache.UserInfo.findOne({hgId : params.Data.RequesterUserId}, function (error, requesterUser) {
            if (error) {
                callback(error, null);
                return;
            }
            requesterFullName = requesterUser.UserPersonal.FullName;
            EntityCache.UserInfo.findOne({hgId : params.Data.RejectorUserId}, function (error, rejectorUser) {
                if (error) {
                    callback(error, null);
                    return;
                }
                EntityCache.PerformanceReview.findOne({hgId : params.Data.ReviewId}, function (error, review) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    rejector = review.Peoples.filter(function (people) {
                        return people.UserId === params.Data.RejectorUserId;
                    });
                    if (!rejector || rejector.length !== 1) {
                        callback('Cannot find rejector', null);
                        return;
                    }
                    requester = review.Peoples.filter(function (people) {
                        return people.UserId === params.Data.RequesterUserId;
                    });
                    if (!requester || requester.length !== 1) {
                        callback('Cannot find requester', null);
                        return;
                    }
                    if (requester[0].Anonymous === true) {
                        if (requester[0].AnonymousId) {
                            requesterFullName = 'Anonymous ' + requester[0].AnonymousId;
                        } else {
                            requesterFullName = 'Anonymous';
                        }
                    }

                    notificationQueueItem.MergeFields = {
                        first_name : rejectorUser.UserPersonal.FirstName,
                        review_title : review.Card.Title,
                        cycle_name : review.CycleName,
                        requester_name : requesterFullName,
                        notes: params.Data.Note ? "Notes from " + requesterFullName + ":\r\n " + params.Data.Note : "",
                        review_url : [config.protocol, config.baseUrl, '#/Profile/Perform/', rejector[0].MemberId, '/', params.Data.ReviewId, '/1'].join('')
                    };
                    notificationQueueItem.Subject = requesterFullName + ' has requested to edit review!';
                    callback(null, { NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption, CompleteCallback : params.CompleteCallback});
                });
            });
        });
    };

    this.ReviewRejected = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        EntityCache.Member.findOne({hgId : params.Data.RejecteeMemberId}, function (error, rejecteeMember) {
            if (error) {
                callback(error, null);
                return;
            }
            EntityCache.Member.findOne({hgId : params.Data.RejectorMemberId}, function (error, rejectorMember) {
                if (error) {
                    callback(error, null);
                    return;
                }
                EntityCache.PerformanceReview.findOne({hgId : params.Data.ReviewId}, function (error, review) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    var subject = review.Peoples.filter(function (p) {return p.PeopleType === 'Subject'; })[0],
                        rejectorFullName = rejectorMember.FullName,
                        rejector = review.Peoples.filter(function (p) { return p.MemberId === params.Data.RejectorMemberId; })[0];

                    if (rejector.Anonymous === true) {
                        if (rejector.AnonymousId) {
                            rejectorFullName = 'Anonymous ' + rejector.AnonymousId;
                        } else {
                            rejectorFullName = 'Anonymous';
                        }
                    }

                    notificationQueueItem.MergeFields = {
                        first_name : rejecteeMember.FirstName,
                        review_title : review.Card.Title,
                        cycle_name : review.CycleName,
                        notes: params.Data.Note ? "Notes from " + rejectorFullName + ":\r\n " + params.Data.Note : "",
                        review_url : [config.protocol, config.baseUrl, '#/Profile/Perform/', subject.MemberId, '/', params.Data.ReviewId, '/1'].join('')
                    };
                    notificationQueueItem.Subject = "Your review for " + review.CycleName + " has been rejected by " + rejectorFullName;
                    callback(null, { NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption, CompleteCallback : params.CompleteCallback});
                });
            });
        });
    };

    this.ClosedReview = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            first_name : params.Data.PersonName,
            review_title : params.Data.ReviewTitle,
            cycle_name : params.Data.CycleName,
            people_type_name : params.Data.PersonType
        };
        notificationQueueItem.Subject = 'The review has been closed.';
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption,
            CompleteCallback : params.CompleteCallback
        });
    };

    this.ReviewDeadlineDelivered = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            peopleReviews = params.Data.PeopleReviews,
            reviews_table = '',
            curReview = '',
            i,
            subjectImgSrc,
            managerImgSrc;
        notificationQueueItem.MergeFields = {
            first_name : params.Data.FullName,
            cycle_name : peopleReviews[0].CycleName,
            notes: params.Data.Notes ? "Notes from " + params.Data.SenderName + ":\r\n " + params.Data.Notes : ""
        };
        notificationQueueItem.Subject = 'Time is almost up!';
        for (i = 0; i < peopleReviews.length; i += 1) {
            curReview = '';
            subjectImgSrc = '';
            managerImgSrc = '';
            if (config.s3store.s3bucket === '') {
                subjectImgSrc = config.baseUrl;
                managerImgSrc = config.baseUrl;
            }
            subjectImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + peopleReviews[i].SubjectSummary.UserId;
            if (peopleReviews[i].ManagerSummary) {
                managerImgSrc += getImageStorePath() + '/' + config.filepath.UserProfile + peopleReviews[i].ManagerSummary.UserId;
            }
            curReview += '<table width="540" border="0" cellpadding="0" cellspacing="0" style="padding:15px 10px 10px 15px;border:1px dashed #a8a48e;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td width="90">' +
                '<a href="' + config.protocol + config.baseUrl + '#/Profile/Perform/' + peopleReviews[i].SubjectSummary.MemberId + '/' + peopleReviews[i].ReviewId + '/1' +
                '" style="color:#86a64b;text-decoration:none;">' +
                '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + subjectImgSrc  + '.jpg">' +
                '<img height="32" width="32" style="width:32px;min-height:32px;margin-right:6px;vertical-align:middle;" src="https:' + managerImgSrc  + '.jpg">' +
                '</a></td><td><a style="color:#86a64b;text-decoration:none;" href="' +
                config.protocol + config.baseUrl + '#/Profile/Perform/' + peopleReviews[i].SubjectSummary.MemberId + '/' + peopleReviews[i].ReviewId + '/1' + '" ><strong>' +
                peopleReviews[i].ReviewTitle + '</strong></a></td></tr><tr><td></td><td>';
            curReview += '<table style="font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;"><tbody><tr><td>Cycle Name: ' + peopleReviews[i].CycleName + '</td></tr>';
            curReview += '<tr><td>Reviewee: ' + peopleReviews[i].SubjectSummary.FullName + '</td></tr>';
            if (peopleReviews[i].ManagerSummary) {
                curReview += '<tr><td>Manager: ' + peopleReviews[i].ManagerSummary.FullName + '</td></tr>';
            }
            curReview += '<tr><td>Role: ' + mapPeopleTypeName(peopleReviews[i].PeopleType) + '</td></tr>';
            curReview += '<tr><td>Due date: ' + DateHelper.formatDateStringFromTimestamp(peopleReviews[i].DueDate) + '</td></tr>';
            curReview += '</tbody></table></td><tr></tbody></table><br />';
            reviews_table += curReview;
        }
        notificationQueueItem.MergeFields.reviews_table = reviews_table;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

};

module.exports = PerformBuilder;