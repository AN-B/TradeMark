/*jslint node:true es5:true*/
var GroupBuilder = function () {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        HgLog = require('../../../framework/HgLog'),
        i18nHelper = require('../../../helpers/i18nHelper.js'),
        config = require('../../../configurations/config'),
        isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
        htmlHelper = require('../../../helpers/htmlHelper.js'),
        DateHelper = require('../../../util/DateHelper');

    this.EmployeeOnboarded = function (params, callback) {
        var UserSecurity = EntityCache.UserSecurity,
            Member = EntityCache.Member,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem,
            WELCOME_EMAIL_EXPIRE_HOURS = 48,
            updateTokenExpireDate = function (token) {
                EntityCache.ActionToken.findOneAndUpdate({
                    hgId: token
                }, {
                    $set: {
                        ExpireDate: Date.now() + 3600 * 1000 * WELCOME_EMAIL_EXPIRE_HOURS,
                        ModifiedDate: Date.now()
                    }
                }, {
                    new: true
                }, function (error) {
                    if (error) {
                        HgLog.error({methodName: 'updateTokenExpireDate', error: error});
                    }
                });
            };
        Member.findOne({hgId: params.Data.MemberId}, function (err, member) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!member) {
                return callback('business.user.noauth.uidne');
            }
            EntityCache.Group.findOne({hgId: member.GroupId}, function (error, group) {
                if (error) {
                    return callback('Error Loading Group');
                }
                if (!group) {
                    return callback('Group Not Found');
                }
                //need to find out if the user needs to reset his password
                UserSecurity.findOne({hgId: member.UserId}, function (err, userSecurity) {
                    if (err) {
                        return callback('business.user.noauth.elup');
                    }
                    if (!userSecurity) {
                        return callback('business.user.noauth.uidne');
                    }
                    if (userSecurity.Status === 'PasswordChangeRequired') {
                        mergeField.link_url = [config.protocol, config.baseUrl, 'public/#/ResetPassword/', userSecurity.ActionToken, '?welcome=1'].join('');
                        updateTokenExpireDate(userSecurity.ActionToken);
                    } else {
                        mergeField.link_url = config.protocol + config.baseUrl;
                    }
                    notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.EmployeeOnboarded.sub');
                    mergeField.body_txt = i18nHelper.translate(params.Data.i18n, 'eml.EmployeeOnboarded.body_txt', {
                        company: group.ProgramName || group.GroupName,
                        first_name: member.FirstName,
                        username: userSecurity.UserName,
                        hours: WELCOME_EMAIL_EXPIRE_HOURS.toString()
                    });
                    mergeField.teaser = i18nHelper.translate(params.Data.i18n, 'eml.EmployeeOnboarded.tea', {
                        company: member.GroupName
                    });
                    mergeField.link_txt = i18nHelper.translate(params.Data.i18n, 'eml.EmployeeOnboarded.link_txt');
                    mergeField.thank = i18nHelper.translate(params.Data.i18n, 'eml.common.thank');
                    notificationQueueItem.MergeFields = mergeField;
                    callback(null, {
                        NotificationQueueItem: notificationQueueItem,
                        Data: params.Data,
                        NotificationEvent: params.NotificationEvent,
                        DispatchOption: params.DispatchOption
                    });
                });
            });
        });
    };

    this.ReportReadyToDownload = function (params, callback) {
        var mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;
        mergeField.export_url = [config.protocol, config.baseUrl, '#/Admin/Reports/Download'].join('');
        mergeField.report_name = params.Data.ReportTypeName;
        notificationQueueItem.MergeFields = mergeField;
        callback(null, {NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption});
    };

    this.YearSummaryReportReady = function (params, callback) {
        var Member = EntityCache.Member,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem,
            getAvatarPath = function (userId) {
                if (isLocal) {
                    return config.protocol + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + userId + '.jpg';
                }
                return config.protocol + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + userId + '.jpg';
            },
            summaryTemplate = require('../../../../static/templates/server/report/profile-summary.html'),
            includedItems = [],
            translationMap = {
                Goals: 'eml.YearSummaryReportReady.gls',
                Checkins: 'eml.YearSummaryReportReady.chk',
                Recognitions: 'eml.YearSummaryReportReady.rcg',
                Feedback: 'eml.YearSummaryReportReady.fdb'
            };

        Member.findOne({
            hgId: params.Data.Payload.MemberId,
            GroupId:  params.Data.ReportGroupId
        }, {UserId: 1, FullName: 1}, {lean: true}, function (err, member) {
            if (err || !member) {
                return callback('business.user.noauth.elup');
            }
            Object.keys(params.Data.Payload.Summary).forEach(function (item) {
                if (translationMap[item]) {
                    includedItems.push(i18nHelper.translate(params.Data.i18n, translationMap[item]));
                }
            });
            notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.YearSummaryReportReady.sub');
            mergeField = {
                teaser: i18nHelper.translate(params.Data.i18n, 'eml.YearSummaryReportReady.tea'),
                body_txt: i18nHelper.translate(params.Data.i18n, 'eml.YearSummaryReportReady.body_txt', {
                    first_name: params.Data.RequesterFullname,
                    html_body: htmlHelper.replaceTokens(summaryTemplate, {
                        AvatarPath: getAvatarPath(member.UserId),
                        MemberFullName: member.FullName,
                        StartDate: DateHelper.formatDateStringFromTimestamp(params.Data.StartDate),
                        EndDate: DateHelper.formatDateStringFromTimestamp(params.Data.EndDate),
                        IncludedItems: includedItems.join(', ')
                    })
                }),
                link_url: [config.protocol, config.baseUrl, '#/User/ImportantNotifications/All'].join(''),
                link_txt: i18nHelper.translate(params.Data.i18n, 'eml.YearSummaryReportReady.link_txt')
            };

            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    };

    this.ReportNotProcessed = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            report_name: params.Data.ReportName
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.ExportGroupDataRequest = function (params, callback) {
        var UserInfo = EntityCache.UserInfo,
            Data = params.Data,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;
        mergeField.export_url = [config.protocol, config.baseUrl, 'provision/#/Provisioning/Company/', Data.DataExportId].join('');
        UserInfo.findOne({'hgId' : params.Data.UserId}, function (err, userInfo) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!userInfo) {
                return callback('business.user.noauth.uidne');
            }
            mergeField.first_name = userInfo.UserPersonal.FirstName;
            mergeField.LastName = userInfo.UserPersonal.LastName;
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption
            });
        });
    };

    function populateEmailByNews(request, callback) {
        // override the subject field with the news title, issue #2997
        request.NotificationQueueItem.Subject = request.Data.Title;
        request.NotificationQueueItem.MergeFields = {
            company_name: request.Data.GroupName,
            news_title: request.Data.Title,
            news_body: request.Data.Body
        };
        callback();
    }

    this.GroupNewsPublished = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        populateEmailByNews({
            NotificationQueueItem : notificationQueueItem,
            Data : params.Data
        }, function (error) {
            if (error) {
                return callback(error);
            }
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    };

    this.OffBoardMember = function (params, callback) {
        var UserInfo = EntityCache.UserInfo,
            Data = params.Data,
            mergeField =  {},
            i18n,
            notificationQueueItem = params.NotificationQueueItem;

        UserInfo.findOne({hgId: params.Data.OffBoardUserId}, function (err, userInfo) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!userInfo) {
                return callback('business.user.noauth.uidne');
            }
            i18n = userInfo.Preference.DefaultGroupId + '/email/' + (userInfo.i18n || 'en');
            notificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.OffBoardMember.sub', {
                group: Data.GroupName
            });
            mergeField.teaser = i18nHelper.translate(i18n, 'eml.OffBoardMember.tea');
            mergeField.body_txt = i18nHelper.translate(i18n, 'eml.OffBoardMember.body_txt', {
                first_name: userInfo.UserPersonal.FirstName,
                group: Data.GroupName,
                user_name: userInfo.UserName
            });
            mergeField.thank = i18nHelper.translate(i18n, 'eml.OffBoardMember.thank', {
                group: Data.GroupName
            });
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    };
};

module.exports = GroupBuilder;