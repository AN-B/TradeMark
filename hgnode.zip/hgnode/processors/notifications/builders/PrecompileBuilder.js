var PrecompileBuilder = function () {
    'use strict';
    var EntityCache = require('../../../framework/EntityCache'),
        RecognitionEnums = require('../../../enums/RecognitionEnums.js'),
        HgCache = require('../../../framework/RedisConnectionCache'),
        HgLog = require('../../../framework/HgLog'),
        ConstantEnums = require('../../../enums/ConstantEnums'),
        Async = require('async'),
        time = require('time'),
        getUniqueGroupIds = function (members) {
            var ids = [];
            if (members && members.length > 0) {
                members.forEach(function (member) {
                    if (ids.indexOf(member.GroupId) === -1) {
                        ids.push(member.GroupId);
                    }
                });
            }
            return ids;
        },
        getProjections = function () {
            return {
                hgId: true,
                FullName: true,
                GroupId: true,
                GroupName: true,
                RolesInGroup: true,
                Position: true,
                Birthdate: true,
                StartingDate: true,
                Location: true,
                GroupDepartmentName: true,
                GroupDepartmentId: true,
                UserId: true
            };
        },
        //date stuff that can be moved to date helper
        getComingWeekDays = function () {
            var today = new Date(),
                i,
                weekDays = [],
                day,
                daytime;
            for (i = 0; i < 7; i += 1) {
                daytime = new time.Date(+today + (i * 24 * 60 * 60 * 1000));
                day = {
                    Date: daytime.getDate(),
                    Month: daytime.getMonth()
                };
                weekDays.push(day);
            }
            return weekDays;
        },
        getPastWeekDays = function () {
            var today = new Date(),
                i,
                weekDays = [],
                day,
                daytime;
            for (i = 1; i <= 7; i += 1) {
                daytime = new time.Date(+today - (i * 24 * 60 * 60 * 1000));
                day = {
                    Date: daytime.getDate(),
                    Month: daytime.getMonth()
                };
                weekDays.push(day);
            }
            return weekDays;
        },
        getWeekendDays = function () {
            var today = new Date(),
                saturday = new time.Date(+today + (24 * 60 * 60 * 1000)),
                sunday = new time.Date(+today + (2 * 24 * 60 * 60 * 1000));
            //TO-DO: need to check for scenario where the next day is the beginning of a new month
            return {
                SaturdayDate: saturday.getDate(),
                SundayDate: sunday.getDate(),
                SaturdayMonth: saturday.getMonth(),
                SundayMonth: sunday.getMonth()
            };
        },
        getPastWeekendDays = function () {
            var today = new Date(),
                saturday = new time.Date(+today - (2 * 24 * 60 * 60 * 1000)),
                sunday = new time.Date(+today - (24 * 60 * 60 * 1000));
            return {
                SaturdayDate: saturday.getDate(),
                SundayDate: sunday.getDate(),
                SaturdayMonth: saturday.getMonth(),
                SundayMonth: sunday.getMonth()
            };
        },
        setTimeToZeroHours = function (date) {
            // today and yesterday are instances of time.Date with timezone specified by Group.TimeZone
            // setting hours to 0 will set hours to 0 for that timezone, correctly offsetting the timestamp
            date.setHours(0);
            date.setMinutes(0);
            date.setSeconds(0);
            date.setMilliseconds(0);
            return date;
        },

        // birthdays
        buildBirthdayQuery = function (weekDays) {
            var i,
                query,
                str = 'var d = new Date(this.Birthdate); return',
                year = new Date().getUTCFullYear();

            str += '(d.getUTCDate() ===' + weekDays[0].Date + ' && d.getUTCMonth() === ' + weekDays[0].Month + ')';
            for (i = 0; i < weekDays.length; i += 1) {
                str += ' || (d.getUTCDate() ===' + weekDays[i].Date + ' && d.getUTCMonth() === ' + weekDays[i].Month + ')';
            }
            str += ' && d.getUTCFullYear() !==' + year;
            query = {
                "$where": str,
                MembershipStatus: 'Active'
            };
            return query;
        },
        processBirthdayQuery = function (params, callback) {
            var memberUserIdIndex = {};
            EntityCache.Member.find(params.Query, function (err, members) {
                if (err) {
                    return callback(err);
                }
                if (!members.length) {
                    return callback(null, []);
                }
                members.forEach(function (item) {
                    memberUserIdIndex[item.UserId] = {
                        Birthdate: item.Birthdate,
                        hgId: item.hgId
                    };
                });
                EntityCache.UserInfo.find({
                    hgId: {
                        $in: members.map(function (item) {
                            return item.UserId;
                        })
                    },
                    "Preference.SuppressBirthday": false
                }, function (error, users) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, users.map(function (item) {
                        return {
                            FullName: item.UserPersonal.FullName,
                            Birthdate: memberUserIdIndex[item.hgId].Birthdate,
                            GroupId: item.Preference.DefaultGroupId,
                            SuppressBirthday: item.Preference.SuppressBirthday,
                            UserId: item.hgId,
                            hgId: memberUserIdIndex[item.hgId].hgId
                        };
                    }));
                });
            });
        },
        getComingWeekBirthdays = function (params, callback) {
            var queryBirthday,
                weekDays = getComingWeekDays();
            queryBirthday = buildBirthdayQuery(weekDays);
            queryBirthday.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            processBirthdayQuery({Query: queryBirthday}, callback);
        },
        getPastWeekBirthdays = function (params, callback) {
            var queryBirthday,
                weekDays = getPastWeekDays();
            queryBirthday = buildBirthdayQuery(weekDays);
            queryBirthday.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            processBirthdayQuery({Query: queryBirthday}, callback);
        },
        getComingWeekendBirthdays = function (params, callback) {
            var today = new Date().getDay(),
                queryBirthday,
                weekend = getWeekendDays(),
                year = new Date().getUTCFullYear();
            if (today !== 5) {
                callback(null, []);
                return;
            }
            queryBirthday = {
                MembershipStatus: 'Active',
                "$where": ["var d = new Date(this.Birthdate); return (d.getUTCDate() === ", weekend.SaturdayDate, " && d.getUTCMonth() === ", weekend.SaturdayMonth, ") || (d.getUTCDate() === ", weekend.SundayDate, " && d.getUTCMonth() === ", weekend.SundayMonth, ") && d.getUTCFullYear() !== ", year].join('')
            };
            queryBirthday.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            processBirthdayQuery({Query: queryBirthday}, callback);
        },
        getTomorrowBirthdays = function (params, callback) {
            var tomorrow = new Date(),
                date,
                month,
                queryBirthday,
                year = new Date().getUTCFullYear();
            tomorrow.setDate(tomorrow.getDate() + 1);
            date = tomorrow.getDate();
            month = tomorrow.getMonth();
            queryBirthday = {
                MembershipStatus: 'Active',
                "$where": ["var d = new Date(this.Birthdate); return d.getUTCDate() === ", date, " && d.getUTCMonth() === ", month, " && d.getUTCFullYear() !== ", year].join('')
            };
            queryBirthday.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            processBirthdayQuery({Query: queryBirthday}, callback);
        },
        getPastWeekendBirthdays = function (params, callback) {
            var today = new Date().getDay(),
                queryBirthday,
                weekend = getPastWeekendDays(),
                year = new Date().getUTCFullYear();

            if (today !== 1) {
                callback(null, []);
                return;
            }
            queryBirthday = {
                MembershipStatus: 'Active',
                "$where": ["var d = new Date(this.Birthdate); return (d.getUTCDate() === ", weekend.SaturdayDate, " && d.getUTCMonth() === ", weekend.SaturdayMonth, ") || (d.getUTCDate() === ", weekend.SundayDate, " && d.getUTCMonth() === ", weekend.SundayMonth, ") && d.getUTCFullYear() !== ", year].join('')
            };
            queryBirthday.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            processBirthdayQuery({Query: queryBirthday}, callback);
        },
        getTodayBirthdays = function (params, callback) {
            var today = new Date(),
                date,
                month,
                queryBirthday,
                year = new Date().getUTCFullYear();
            date = today.getDate();
            month = today.getMonth();
            queryBirthday = {
                MembershipStatus: 'Active',
                "$where": ["var d = new Date(this.Birthdate); return d.getUTCDate() === ", date, " && d.getUTCMonth() === ", month, " && d.getUTCFullYear() !== ", year].join('')
            };
            queryBirthday.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            processBirthdayQuery({Query: queryBirthday}, callback);
        },
        precompileGroupBirthdays = function (params, callback) {
            var birthdays = {
                ComingWeekend: [],
                Tomorrow: [],
                PastWeekend: [],
                Today: []
            };
            getComingWeekendBirthdays(params, function (error, ComingWeekendBirthdays) {
                if (error) {
                    callback(error, null);
                    return;
                }
                birthdays.ComingWeekend = ComingWeekendBirthdays;
                getTomorrowBirthdays(params, function (error, TomorrowBirthdays) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    birthdays.Tomorrow = TomorrowBirthdays;
                    getPastWeekendBirthdays(params, function (error, PastWeekendBirthdays) {
                        if (error) {
                            callback(error, null);
                            return;
                        }
                        birthdays.PastWeekend = PastWeekendBirthdays;
                        getTodayBirthdays(params, function (error, TodayBirthdays) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            birthdays.Today = TodayBirthdays;
                            callback(null, birthdays);
                        });
                    });
                });
            });
        },
        precompileWeeklyGroupBirthdays = function (params, callback) {
            var birthdays = {
                PastWeek: [],
                ComingWeek: []
            };
            getComingWeekBirthdays(params, function (error, ComingWeekBirthdays) {
                if (error) {
                    callback(error, null);
                    return;
                }
                birthdays.ComingWeek = ComingWeekBirthdays;
                getPastWeekBirthdays(params, function (error, PastWeekBirthdays) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    birthdays.PastWeek = PastWeekBirthdays;
                    callback(null, birthdays);
                });
            });
        },
        precompileGroup = function (params, cb) {
            EntityCache.Group.findOne({
                hgId: params.GroupId
            }, {
                _id: false,
                hgId: true,
                GroupName: true,
                ProgramName: true,
                'Preference.FeatureFlags': true
            }, cb);
        },
        precompileRecognitionTemplateIdsBirthday = function (params, cb) {
            EntityCache.RecognitionTemplate.findOne({
                GroupId: params.GroupId,
                Type: RecognitionEnums.TemplateType.Birthday,
                Category: RecognitionEnums.RecognitionCategory.System,
                DefaultBadge: true
            }, function (error, template) {
                if (error) {
                    return cb(error);
                }
                if (!template) {
                    return cb(null, []);
                }
                cb(null, [template.hgId]);
            });
        },
        precompileRecognitionTemplateIdsAnniversary = function (params, cb) {
            EntityCache.RecognitionTemplate.find({
                GroupId: params.GroupId,
                Type: {
                    $in: [
                        RecognitionEnums.TemplateType.Milestone,
                        RecognitionEnums.TemplateType.Anniversary
                    ]
                },
                Category: RecognitionEnums.RecognitionCategory.System,
                SubCategory: {
                    $in: [
                        RecognitionEnums.RecognitionSubCategory.ServiceAward,
                        RecognitionEnums.RecognitionSubCategory.Default]
                }
            }, function (error, templates) {
                if (error) {
                    return cb(error);
                }
                if (!templates && !templates.length) {
                    return cb(null, []);
                }
                cb(null, templates.map(function (template) {
                    return template.hgId;
                }));
            });
        },
        //anniversaries
        buildAnniversaryQuery = function (weekDays) {
            var i,
                query,
                str = 'var d = new Date(this.StartingDate); return',
                year = new Date().getUTCFullYear();
            str += '((d.getUTCDate() ===' + weekDays[0].Date + ' && d.getUTCMonth() === ' + weekDays[0].Month + ')';
            for (i = 1; i < weekDays.length; i += 1) {
                str += ' || (d.getUTCDate() ===' + weekDays[i].Date + ' && d.getUTCMonth() === ' + weekDays[i].Month + ')';
            }
            str += ') && d.getUTCFullYear() !==' + year;
            query = {"$where": str};
            return query;
        },
        getComingWeekAnniversaries = function (params, callback) {
            var queryAnniversary,
                weekDays = getComingWeekDays();
            queryAnniversary = buildAnniversaryQuery(weekDays);
            queryAnniversary.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            queryAnniversary.MembershipStatus = 'Active';
            EntityCache.Member.find(queryAnniversary, getProjections(), callback);
        },
        getPastWeekAnniversaries = function (params, callback) {
            var queryAnniversary,
                weekDays = getPastWeekDays();
            queryAnniversary = buildAnniversaryQuery(weekDays);
            queryAnniversary.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            queryAnniversary.MembershipStatus = 'Active';
            EntityCache.Member.find(queryAnniversary, getProjections(), callback);
        },
        getTodayAnniversaries = function (params, callback) {
            var today = new Date(),
                date,
                month,
                queryAnniversary,
                year = new Date().getUTCFullYear();
            date = today.getDate();
            month = today.getMonth();
            queryAnniversary = {'MembershipStatus' : 'Active', "$where": "var d = new Date(this." + "StartingDate" + "); return d.getUTCDate() === " + date + " && d.getUTCMonth() === " + month + " && d.getUTCFullYear() !== " + year};
            queryAnniversary.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            EntityCache.Member.find(queryAnniversary, getProjections(), callback);
        },
        getComingWeekendAnniversaries = function (params, callback) {
            var today = new Date().getDay(),
                queryAnniversary,
                weekend = getWeekendDays(),
                year = new Date().getUTCFullYear();
            if (today !== 5) {
                callback(null, []);
                return;
            }
            queryAnniversary = {'MembershipStatus' : 'Active', "$where": "var d = new Date(this." + "StartingDate" + "); " +
                "return ((d.getUTCDate() === " + weekend.SaturdayDate + " && d.getUTCMonth() === " + weekend.SaturdayMonth + ") || (d.getUTCDate() === " + weekend.SundayDate + " && d.getUTCMonth() === " + weekend.SundayMonth + ")) && (d.getUTCFullYear() !== " + year + ')'};
            queryAnniversary.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            EntityCache.Member.find(queryAnniversary, getProjections(), callback);
        },
        getTomorrowAnniversaries = function (params, callback) {
            var tomorrow = new Date(),
                date,
                month,
                queryAnniversary,
                year = new Date().getUTCFullYear();
            tomorrow.setDate(tomorrow.getDate() + 1);
            date = tomorrow.getDate();
            month = tomorrow.getMonth();
            queryAnniversary = {'MembershipStatus' : 'Active', "$where": "var d = new Date(this." + "StartingDate" + "); return d.getUTCDate() === " + date + " && d.getUTCMonth() === " + month + " && d.getUTCFullYear() !== " + year};
            queryAnniversary.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            EntityCache.Member.find(queryAnniversary, getProjections(), callback);
        },
        getPastWeekendAnniversaries = function (params, callback) {
            var today = new Date().getDay(),
                queryAnniversary,
                weekend = getPastWeekendDays(),
                year = new Date().getUTCFullYear();

            if (today !== 1) {//today isn't Monday
                callback(null, []);
                return;
            }
            queryAnniversary = {'MembershipStatus' : 'Active', "$where": "var d = new Date(this." + "StartingDate" + "); " +
                "return ((d.getUTCDate() === " + weekend.SaturdayDate + " && d.getUTCMonth() === " + weekend.SaturdayMonth + ") || (d.getUTCDate() === " + weekend.SundayDate + " && d.getUTCMonth() === " + weekend.SundayMonth + ")) && (d.getUTCFullYear() !== " + year + ')'};
            queryAnniversary.GroupId = params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId;
            EntityCache.Member.find(queryAnniversary, getProjections(), callback);
        },
        getUserIdsWithSuppressAnniversaryEnabled = function (params, callback) {
            var query = {
                    'Preference.DefaultGroupId' : params.GroupIds && params.GroupIds.length ? { $in: params.GroupIds} : params.GroupId,
                    'Preference.SuppressAnniversary' : true
                },
                project = { '_id' : 0, hgId : 1 };
            EntityCache.UserInfo.find(query, project, function (err, userIds) {
                return callback(err, userIds);
            });
        },
        excludeSuppressAnniversaryMembers = function (supressUsers, anniversaryMembers) {
            var supressUsersHashById = {};
            supressUsers.forEach(function (user) {
                supressUsersHashById[user.hgId] = true;
            });
            anniversaryMembers = anniversaryMembers.filter(function (member) {
                return !supressUsersHashById[member.UserId];
            });
            return anniversaryMembers;
        },
        precompileGroupAnniversaries = function (params, callback) {
            var anniversaries = {
                ComingWeekend : [],
                Tomorrow : [],
                PastWeekend : [],
                Today : []
            };
            //  remove members that want to suppress their anniversary announcements
            getUserIdsWithSuppressAnniversaryEnabled(params, function (error, userIds) {
                if (error) { return callback(error); }
                getComingWeekendAnniversaries(params, function (error, ComingWeekendAnniversaries) {
                    if (error) { return callback(error); }
                    anniversaries.ComingWeekend = excludeSuppressAnniversaryMembers(userIds, ComingWeekendAnniversaries);
                    getTomorrowAnniversaries(params, function (error, TomorrowAnniversaries) {
                        if (error) { return callback(error); }
                        anniversaries.Tomorrow = excludeSuppressAnniversaryMembers(userIds, TomorrowAnniversaries);
                        getPastWeekendAnniversaries(params, function (error, PastWeekendAnniversaries) {
                            if (error) { return callback(error); }
                            anniversaries.PastWeekend = excludeSuppressAnniversaryMembers(userIds, PastWeekendAnniversaries);
                            getTodayAnniversaries(params, function (error, TodayAnniversaries) {
                                if (error) { return callback(error); }
                                anniversaries.Today = excludeSuppressAnniversaryMembers(userIds, TodayAnniversaries);
                                callback(null, anniversaries);
                            });
                        });
                    });
                });
            });
        },
        precompileWeeklyGroupAnniversaries = function (params, callback) {
            var anniversaries = {
                ComingWeek : [],
                PastWeek : []
            };
            getUserIdsWithSuppressAnniversaryEnabled(params, function (error, userIds) {
                if (error) { return callback(error); }
                getComingWeekAnniversaries(params, function (error, ComingWeekAnniversaries) {
                    if (error) { return callback(error); }
                    anniversaries.ComingWeek = excludeSuppressAnniversaryMembers(userIds, ComingWeekAnniversaries);
                    getPastWeekAnniversaries(params, function (error, PastWeekAnniversaries) {
                        if (error) { return callback(error); }
                        anniversaries.PastWeek = excludeSuppressAnniversaryMembers(userIds, PastWeekAnniversaries);
                        callback(error, anniversaries);
                    });
                });
            });
        },
        buildRecognitionConidition = function (params) {
            return {
                'Template.GroupId': params.GroupIds && params.GroupIds.length ? {$in: params.GroupIds} : params.GroupId,
                'Template.Type': {$in: [
                    RecognitionEnums.Type.Recognition,
                    RecognitionEnums.Type.Award,
                    RecognitionEnums.Type.Thanks,
                    RecognitionEnums.Type.Quick,
                    RecognitionEnums.Type.Congrats
                ]},
                CreatedDate: {$gte: params.StartDate.getTime(), $lte: params.EndDate.getTime()},
                Status: RecognitionEnums.Status.Active,
                SuppressInFeed: false
            };
        },
        recognitionProjection = {
            hgId: true,
            BatchId: true,
            BadgeFilename: true,
            "Template.Title": true,
            "Template.Description": true,
            "Template.Message": true,
            "Template.FriendlyGroupId": true,
            "Template.GroupId": true,
            "Template.GroupName": true,
            "Template.ForegroundFilename": true,
            "Template.BackgroundFilename": true,
            "Template.BadgeId": true,
            "Template.hgId": true,
            "RecipientMember.hgId": true,
            "RecipientMember.UserId": true,
            "RecipientMember.FullName": true,
            "CreatorMember.hgId": true,
            "CreatorMember.UserId": true,
            "CreatorMember.FullName": true,
            PublicCreatorInfo: true,
            CommentCount: true,
            CongratsCount: true,
            TriggerInfo: true,
            Message: true
        },
        getPastWeekRecognitionsAndComments = function (params, callback) {
            var today = new time.Date(),
                mquery,
                startDate,
                endDate,
                timezone = 'America/Chicago',
                recognitionIds = [];
            time.tzset(timezone);
            startDate = new time.Date(+today - (7 * 24 * 60 * 60 * 1000));
            startDate = setTimeToZeroHours(startDate);
            endDate = setTimeToZeroHours(today);
            mquery = EntityCache.Recognition.find(buildRecognitionConidition({
                GroupIds: params.GroupIds,
                GroupId: params.GroupId,
                StartDate: startDate,
                EndDate: endDate
            }), recognitionProjection);
            mquery.sort({ModifiedDate : -1}).exec(function (err, companyRecognitions) {
                if (err) {
                    return callback(err);
                }
                companyRecognitions.forEach(function (recognition) {
                    recognitionIds.push(recognition.hgId);
                });
                EntityCache.Comment.find({EntityId : {$in : recognitionIds}}, function (error, comments) {
                    if (error) {
                        return callback(null, {Recognitions : companyRecognitions});
                    }
                    callback(null, {Recognitions : companyRecognitions, Comments : comments});
                });
            });
        },
        getPastWeekendRecognitions = function (params, callback) {
            var today = new time.Date(),
                day = new Date().getDay(),
                mquery,
                startDate,
                endDate,
                timezone = 'America/Chicago';
            time.tzset(timezone);
            startDate = new time.Date(+today - (3 * 24 * 60 * 60 * 1000));
            startDate = setTimeToZeroHours(startDate);
            endDate = setTimeToZeroHours(today);
            if (day !== 1) {//today isn't Monday
                callback(null, []);
                return;
            }
            mquery = EntityCache.Recognition.find(buildRecognitionConidition({
                GroupIds: params.GroupIds,
                GroupId: params.GroupId,
                StartDate: startDate,
                EndDate: endDate
            }), recognitionProjection);
            mquery.exec(callback);
        },
        getYesterdayRecognitions = function (params, callback) {
            var today = new time.Date(),
                mquery,
                startDate,
                endDate,
                timezone = 'America/Chicago';
            time.tzset(timezone);
            startDate = new time.Date(+today - (24 * 60 * 60 * 1000));
            startDate = setTimeToZeroHours(startDate);
            endDate = setTimeToZeroHours(today);
            mquery = EntityCache.Recognition.find(buildRecognitionConidition({
                GroupIds: params.GroupIds,
                GroupId: params.GroupId,
                StartDate: startDate,
                EndDate: endDate
            }), recognitionProjection);
            mquery.exec(callback);
        },
        getTodayRecognitions = function (params, callback) {
            var today = new time.Date(),
                mquery,
                startDate,
                endDate,
                timezone = 'America/Chicago';
            time.tzset(timezone);
            startDate = setTimeToZeroHours(today);
            endDate = new time.Date();
            mquery = EntityCache.Recognition.find(buildRecognitionConidition({
                GroupIds: params.GroupIds,
                GroupId: params.GroupId,
                StartDate: startDate,
                EndDate: endDate
            }), recognitionProjection);
            mquery.exec(callback);
        },
        calculateRecognitionRelevance = function (RecognitionsAndComments) {
            var recognitions = RecognitionsAndComments.Recognitions,
                comments = RecognitionsAndComments.Comments,
                recNumberInBatchHashByBatchId = {},
                commentNumberHashByRecognitionId = {};
            recognitions.forEach(function (recognition) {
                if (recNumberInBatchHashByBatchId[recognition.BatchId]) {
                    recNumberInBatchHashByBatchId[recognition.BatchId] += 1;
                } else {
                    recNumberInBatchHashByBatchId[recognition.BatchId] = 1;
                }
            });
            comments.forEach(function (comment) {
                if (commentNumberHashByRecognitionId[comment.EntityId]) {
                    commentNumberHashByRecognitionId[comment.EntityId] += 1;
                } else {
                    commentNumberHashByRecognitionId[comment.EntityId] = 1;
                }
            });
            recognitions.forEach(function (recognition) {
                var recNumberInBatch = recNumberInBatchHashByBatchId[recognition.BatchId],
                    commentNum = commentNumberHashByRecognitionId[recognition.hgId] || 0,
                    likeNum = recognition.CongratsCount,
                    relevance = commentNum * 2 + likeNum + recNumberInBatch * 2;
                if (recognition.Template.Title.indexOf('Anniversary') > -1 || recognition.Template.Title.indexOf('Birthday') > -1) {
                    relevance -= 10;
                }
                recognition.Relevence = relevance;
            });
            recognitions.sort(function (rec1, rec2) {
                return rec1.Relevence > rec2.Relevence ? -1 : 1;
            });
        },
        precompileWeeklyRecognitionsAndComments = function (params, callback) {
            getPastWeekRecognitionsAndComments(params, function (error, RecognitionsAndComments) {
                if (error) {
                    callback(error, null);
                    return;
                }
                calculateRecognitionRelevance(RecognitionsAndComments);
                callback(null, RecognitionsAndComments);
            });
        },
        preCompileRecognitions = function (params, callback) {
            var recognitions = {
                PastWeekend : [],
                Yesterday : [],
                Today : []//this is mainly for today's anniversary and birthday recognitions
            };
            getPastWeekendRecognitions(params, function (error, PastWeekendRecognitions) {
                if (error) {
                    callback(error, null);
                    return;
                }
                recognitions.PastWeekend = PastWeekendRecognitions;
                getYesterdayRecognitions(params, function (error, YesterdayRecognitions) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    recognitions.Yesterday = YesterdayRecognitions;
                    getTodayRecognitions(params, function (error, TodayRecognitions) {
                        if (error) {
                            callback(error, null);
                            return;
                        }
                        recognitions.Today = TodayRecognitions;
                        callback(null, recognitions);
                    });
                });
            });
        },
        loadWeeklyContentForOneGroup = function (params, callback) {
            var cacheKey = 'WeeklyRecapGroupContent-' + params.GroupId;
            HgCache.GlobalGet(cacheKey, function (error, map) {
                if (error || !map) {//map doesn't exist in redis, build it
                    map = {
                        Group: {},
                        BirthdayUsers: [],
                        AnniversaryMembers: [],
                        Recognitions: [],
                        Comments: [],
                        RecognitionTemplateIds: {
                            Birthday: [],
                            Anniversary: []
                        }
                    };

                    Async.parallel({
                        Group: function (pCb) {
                            precompileGroup(params, pCb);
                        },
                        WeeklyGroupBirthdays: function (pCb) {
                            precompileWeeklyGroupBirthdays(params, pCb);
                        },
                        WeeklyGroupAnniversaries: function (pCb) {
                            precompileWeeklyGroupAnniversaries(params, pCb);
                        },
                        RecognitionsAndComments: function (pCb) {
                            precompileWeeklyRecognitionsAndComments(params, pCb);
                        },
                        RecognitionTemplateIdsBirthday: function (pCb) {
                            precompileRecognitionTemplateIdsBirthday(params, pCb);
                        },
                        RecognitionTemplateIdsAnniversary: function (pCb) {
                            precompileRecognitionTemplateIdsAnniversary(params, pCb);
                        }
                    }, function (err, results) {
                        if (err) {
                            return callback(err);
                        }
                        map.Group = results.Group;
                        map.BirthdayUsers = results.WeeklyGroupBirthdays;
                        map.AnniversaryMembers = results.WeeklyGroupAnniversaries;
                        map.Recognitions = results.RecognitionsAndComments.Recognitions;
                        map.Comments = results.RecognitionsAndComments.Comments;
                        map.RecognitionTemplateIds.Birthday = results.RecognitionTemplateIdsBirthday;
                        map.RecognitionTemplateIds.Anniversary = results.RecognitionTemplateIdsAnniversary;
                        params.GroupContentMapping[params.GroupId] = map;
                        HgCache.GlobalSet(cacheKey, map, function (err) {
                            if (err) {
                                HgLog.info('*** Unable to set value to Redis: ' + err.toString() + ' ***');
                            }
                            callback();
                        }, ConstantEnums.RECAP_MEMCACHED_INTERVAL);
                    });
                } else {
                    params.GroupContentMapping[params.GroupId] = JSON.parse(map);
                    callback();
                }
            });
        },
        loadDailyContentForOneGroup = function (params, callback) {
            var cacheKey = 'DailyRecapGroupContent-' + params.GroupId;
            HgCache.GlobalGet(cacheKey, function (error, map) {
                if (error || !map) {//map doesn't exist in redis, build it
                    map = {
                        Group: {},
                        BirthdayUsers: {},
                        AnniversaryMembers: {},
                        Recognitions: [],
                        RecognitionTemplateIds: {
                            Birthday: [],
                            Anniversary: []
                        }
                    };

                    Async.parallel({
                        Group: function (pCb) {
                            precompileGroup(params, pCb);
                        },
                        GroupBirthdays: function (pCb) {
                            precompileGroupBirthdays(params, pCb);
                        },
                        GroupAnniversaries: function (pCb) {
                            precompileGroupAnniversaries(params, pCb);
                        },
                        Recognitions: function (pCb) {
                            preCompileRecognitions(params, pCb);
                        },
                        RecognitionTemplateIdsBirthday: function (pCb) {
                            precompileRecognitionTemplateIdsBirthday(params, pCb);
                        },
                        RecognitionTemplateIdsAnniversary: function (pCb) {
                            precompileRecognitionTemplateIdsAnniversary(params, pCb);
                        }
                    }, function (err, results) {
                        if (err) {
                            return callback(err);
                        }
                        map.Group = results.Group;
                        map.BirthdayUsers = results.GroupBirthdays;
                        map.AnniversaryMembers = results.GroupAnniversaries;
                        map.Recognitions = results.Recognitions;
                        map.RecognitionTemplateIds.Birthday = results.RecognitionTemplateIdsBirthday;
                        map.RecognitionTemplateIds.Anniversary = results.RecognitionTemplateIdsAnniversary;
                        params.GroupContentMapping[params.GroupId] = map;
                        HgCache.GlobalSet(cacheKey, map, function (err) {
                            if (err) {
                                HgLog.info('*** Unable to set value to Redis: ' + err.toString() + ' ***');
                            }
                            callback();
                        }, ConstantEnums.RECAP_MEMCACHED_INTERVAL);
                    });
                } else {
                    params.GroupContentMapping[params.GroupId] = JSON.parse(map);
                    callback();
                }
            });
        };

    this.PrecompileWeeklyGroupContent = function (params, callback) {
        var groupIds = getUniqueGroupIds(params.Members),
            groupContentMapping = {};//groupContentMapping[groupId] is the group's content
        Async.each(groupIds.map(function (groupId) {
            return {
                GroupId: groupId,
                GroupContentMapping: groupContentMapping
            };
        }), loadWeeklyContentForOneGroup, function (error) {
            if (error) {
                return callback(error);
            }
            return callback(null, groupContentMapping);
        });
    };

    this.PrecompileGroupContent = function (params, callback) {
        var groupIds = getUniqueGroupIds(params.Members),
            groupContentMapping = {};
        Async.each(groupIds.map(function (groupId) {
            return {
                GroupId: groupId,
                GroupContentMapping: groupContentMapping
            };
        }), loadDailyContentForOneGroup, function (error) {
            if (error) {
                return callback(error);
            }
            return callback(null, groupContentMapping);
        });
    };
};

module.exports = PrecompileBuilder;