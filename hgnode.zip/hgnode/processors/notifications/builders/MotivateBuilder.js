/*jslint node:true es5:true*/
var MotivateBuilder = function () {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        config = require('../../../configurations/config'),
        i18nHelper = require('../../../helpers/i18nHelper.js'),
        localizedTemplatedIds = [39443];

    this.TangoGiftCard = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem,
            keyName = 'eml.TangoGiftCard';
        params.NotificationQueueItem.MergeFields = params.Data;
        params.NotificationQueueItem.MergeFields.card_image_url = '<img alt="Reward Card Image" src="' + params.NotificationQueueItem.MergeFields.card_image_url + '"></img>';
        if (localizedTemplatedIds.indexOf(notificationQueueItem.TemplateId) > -1) {
            keyName += '_' + notificationQueueItem.TemplateId;
            params.NotificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, keyName + '.body_txt', {
                first_name: Data.first_name,
                order_number: Data.order_number
            });
            notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, keyName + 'sub', {
                card_name: Data.CardName
            });
            params.NotificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, keyName +  '.link_txt');
            params.NotificationQueueItem.MergeFields.recog_link = config.protocol + config.baseUrl + '#/Recognize/Profile/GiveEveryday';
            params.NotificationQueueItem.MergeFields.claim_url_txt = i18nHelper.translate(Data.i18n, keyName +  '.claim_url_txt');
            params.NotificationQueueItem.MergeFields.gca_txt = i18nHelper.translate(Data.i18n, keyName +  '.gca_txt');
            params.NotificationQueueItem.MergeFields.redeem_instructions = i18nHelper.translate(Data.i18n, keyName +  '.redeem_instructions');
            params.NotificationQueueItem.MergeFields.disclaimer = i18nHelper.translate(Data.i18n, keyName +  '.disclaimer');
            params.NotificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, keyName +  '.tea');
            params.NotificationQueueItem.Subject = i18nHelper.translate(Data.i18n, keyName + '.sub');
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption,
                CompleteCallback: params.CompleteCallback
            });
        } else {
            params.NotificationQueueItem.Subject = "Your " + Data.CardName + "  gift card information is inside!";
            callback(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        }
    };

    this.TangoOrderLoadUserError = function (params, callback) {
        var data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            user_id: data.EventBusItem.Payload.UserId,
            group_id: data.EventBusItem.Payload.GroupId,
            credits: data.EventBusItem.Payload.Credits,
            event_id: data.EventBusItem.hgId
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.TangoGiftcardOrderRequestError = function (params, callback) {
        var data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            user_name: data.UserInfo.UserName,
            full_name: data.UserInfo.UserPersonal.FullName,
            user_id: data.EventBusItem.Payload.UserId,
            group_id: data.EventBusItem.Payload.GroupId,
            credits: data.EventBusItem.Payload.Credits,
            event_id: data.EventBusItem.hgId
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.ManualGiftcardOrderSubmittedAdmin = function (params, callback) {
        var data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            full_name: data.UserInfo.UserPersonal.FullName,
            user_name: data.UserInfo.UserName,
            primary_email: data.UserInfo.UserPersonal.PrimaryEmail,
            group_name: data.UserInfo.UserContext.CurrentGroupName,
            order_description: data.OrderRequest.Description,
            card_name: data.OrderRequest.RequestedDenominations[0].IssuerId,
            tango_sku: data.OrderRequest.RequestedDenominations[0].TangoSKU,
            denomination: data.OrderRequest.RequestedDenominations[0].Denomination,
            amount: data.OrderRequest.RequestedDenominations[0].Denomination
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };


    this.TangoErrorInGiftcardPurchase = function (params, callback) {
        var data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            full_name: data.UserInfo.UserPersonal.FullName,
            user_name: data.UserInfo.UserName,
            primary_email: data.UserInfo.UserPersonal.PrimaryEmail,
            group_name: data.UserInfo.UserContext.CurrentGroupName,
            tango_error: data.TangoError.toString(),
            order_description: data.OrderRequest.Description,
            card_name: data.OrderRequest.RequestedDenominations[0].IssuerId,
            tango_sku: data.OrderRequest.RequestedDenominations[0].TangoSKU,
            denomination: data.OrderRequest.RequestedDenominations[0].Denomination,
            issuer: data.OrderRequest.RequestedDenominations[0].IssuerId,
            credit_refunded : data.RollbackFailed === true ? 'No' : 'Yes',
            transaction_saved : data.SaveTransactionFailed === true ? 'No' : 'Yes'
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    function creditPurchasedBuilder(params, callback) {
        var UserInfo = EntityCache.UserInfo,
            Data = params.Data,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem,
            tempDate = new Date(),
            dd = tempDate.getDate(),
            mm = tempDate.getMonth() + 1,
            yyyy = tempDate.getFullYear();

        mergeField.transaction_date = mm + '/' + dd + '/' + yyyy;
        mergeField.transaction_id = Data.TransactionId;
        mergeField.transaction_amount = Data.TransactionAmount;
        mergeField.credit_amount = Data.CreditQuantity;
        mergeField.payment_method = Data.PaymentMethod;

        mergeField.total_amount = mergeField.transaction_amount; // bill me later invoice fields

        UserInfo.findOne({hgId: Data.UserId}, function (err, userInfo) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!userInfo) {
                return callback('business.user.noauth.uidne');
            }
            mergeField.first_name = userInfo.UserPersonal.FirstName;
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption});
        });
    }

    this.CreditBillMeLater = function (params, callback) {
        creditPurchasedBuilder(params, callback);
    };

    this.CreditPurchased = function (params, callback) {
        creditPurchasedBuilder(params, callback);
    };

    this.TransferCreditsComplete = function (params, callback) {
        var Data = params.Data,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;
        EntityCache.Member.findOne({
            hgId: params.Data.MemberId
        }, function (err, member) {
            if (err || !member) {
                return callback('business.user.noauth.uidne');
            }
            mergeField.body_txt = i18nHelper.translate(Data.i18n, 'eml.TransferCreditsComplete.body_txt', {
                first_name: member.FirstName,
                sender_name: Data.SenderName,
                credit_amount: Data.CreditQuantity,
                notes: Data.Notes
            });
            mergeField.link_txt = i18nHelper.translate(Data.i18n, 'eml.TransferCreditsComplete.link_txt');
            mergeField.link_url = config.protocol + config.baseUrl + '#/Recognize/Profile/GiveEveryday';
            mergeField.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
            mergeField.teaser = i18nHelper.translate(Data.i18n, 'eml.TransferCreditsComplete.tea');
            notificationQueueItem.MergeFields = mergeField;
            notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.TransferCreditsComplete.sub');
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption,
                CompleteCallback: params.CompleteCallback
            });
        });
    };

};

module.exports = MotivateBuilder;