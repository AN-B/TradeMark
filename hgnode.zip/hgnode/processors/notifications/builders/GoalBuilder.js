/*jslint node:true es5:true*/
var GoalBuilder = function () {
    'use strict';
    var EntityCache = require('../../../framework/EntityCache'),
        DateHelper = require('../../../util/DateHelper'),
        config = require('../../../configurations/config'),
        htmlHelper = require('../../../helpers/htmlHelper.js'),
        i18nHelper = require('../../../helpers/i18nHelper.js'),
        NotificationsEnums = require('../../../enums/NotificationsEnums.js'),
        GoalTemplates = {
            GoalsTable: require('../../../../static/templates/server/goal/goal-goals-table.html'),
            AdhocGoalsTable: require('../../../../static/templates/server/goal/goal-adhoc-goals-table.html'),
            CheckIn: require('../../../../static/templates/server/goal/goal-check-in.html'),
            GoalTransfer: require('../../../../static/templates/server/goal/goal-transfer-table.html'),
            GoalCycleTransfer: require('../../../../static/templates/server/goal/goal-cycle-transfer-table.html')
        },
        isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
        getParticipantType = function (pt, i18n) {
            var mapping = {
                Member: 'eml.ParticipantType.mem',
                Team: 'eml.ParticipantType.tm',
                Company: 'eml.ParticipantType.cmp'
            };
            return i18nHelper.translate(i18n, mapping[pt]) || '';
        },
        getParticipantTypeForUrl = function (participant) {
            return participant ? {
                Member: 'member',
                Team: 'department',
                Company: 'company'
            }[participant.ParticipantType] : 'member';
        },
        getCycleUrl = function (params) {
            return config.protocol + config.baseUrl + '#/Profile/Cycles/' + params.GoalOwner.MemberId + '/' + getParticipantTypeForUrl(params.Participant) + '?gid=' + params.GroupId;
        },
        getCycleMergeFields = function (params) {
            return {
                participant_type: params.Participant ? getParticipantType(params.Participant.ParticipantType, params.i18n) : '',
                due_date: params.Participant ? DateHelper.formatDateStringFromTimestamp(params.Participant.SetDueDate) : '',
                end_date: params.Participant ? DateHelper.formatDateStringFromTimestamp(params.Participant.ClosePromptDate) : '',
                close_due_date: params.Participant ? DateHelper.formatDateStringFromTimestamp(params.Participant.CloseDueDate) : '',
                question: i18nHelper.translate(params.i18n, 'eml.GoalCycleCommon.que', {
                    goal_cycle_creator_full_name: params.userInfo.UserPersonal.FullName,
                    goal_cycle_creator_email: params.userInfo.UserPersonal.PrimaryEmail || ''
                }),
                goal_cycle_title: params.CycleTitle,
                goal_process: i18nHelper.translate(params.i18n, 'eml.GoalCycleCommon.gpr', {
                    goal_cycle_title: params.CycleTitle,
                    full_name: params.RecipientFirstName || params.Participant.Owner.FullName
                })
            };
        },
        goalNotificationHelper = function (params, callback) {
            callback(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        },
        goalCycleDelivered = function (params, callback) {
            var Data = params.Data,
                i18n = Data.i18n;
            EntityCache.UserInfo.findOne({hgId: params.Data.AdminUserId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('Error loading the Cycle adminUser');
                }
                params.Data.RecipientFirstName = params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '';
                params.Data.userInfo = userInfo;
                params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.sub'].join(''));
                params.NotificationQueueItem.MergeFields = {
                    teaser: i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.tea'].join('')),
                    body_txt: i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.bod'].join(''), getCycleMergeFields(Data)),
                    link_txt: i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.lnk'].join('')),
                    link_url: getCycleUrl(Data),
                    thank: params.SuppressThank ? "" : i18nHelper.translate(i18n, 'eml.GoalCycleCommon.thk', {
                        goal_cycle_creator_full_name: userInfo.UserPersonal.FullName,
                        goal_cycle_creator_email: userInfo.UserPersonal.PrimaryEmail || ''
                    })
                };
                goalNotificationHelper(params, callback);
            });
        },
        goalCreatedForYou = function (params, callback) {
            var Data = params.Data;
            EntityCache.UserInfo.findOne({hgId: params.Data.GoalCreator.UserId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('Error loading the goal creator');
                }
                params.NotificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.GoalCreatedForYou.sub', {
                    name: Data.GoalCreator.FullName
                });
                params.NotificationQueueItem.MergeFields = {
                    teaser: i18nHelper.translate(Data.i18n, 'eml.GoalCreatedForYou.tea'),
                    link_txt: i18nHelper.translate(Data.i18n, 'eml.GoalCreatedForYou.lnk'),
                    link_url: config.protocol + config.baseUrl + '#/Profile/GoalDetails/View/' + Data.GoalOwner.MemberId + '/' + Data.GoalId + '?gid=' + Data.GroupId,
                    thank: i18nHelper.translate(Data.i18n, 'eml.GoalCreatedForYou.thk', {
                        goal_creator_full_name: userInfo.UserPersonal.FullName,
                        goal_creator_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName
                    }),
                    body_txt: i18nHelper.translate(Data.i18n, 'eml.GoalCreatedForYou.bod', {
                        first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '',
                        goal_creator_full_name: userInfo.UserPersonal.FullName,
                        goal_name: Data.GoalName
                    })
                };
                goalNotificationHelper(params, callback);
            });
        },
        goalSetRequested = function (params, callback) {
            var Data = params.Data,
                i18n = Data.i18n,
                getGoalOwnerFullNameText = function (fullname) {
                    return fullname.indexOf('s', fullname.length - fullname.length) > -1 ? (fullname + '\'') : (fullname + '\'s');
                };
            EntityCache.UserInfo.findOne({hgId: Data.AdminUserId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('Error loading the Cycle adminUser');
                }
                params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.sub'].join(''), {
                    name: Data.FullName
                });
                params.NotificationQueueItem.MergeFields = {
                    teaser: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.tea'].join('')),
                    link_txt: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.lnk'].join(''), {
                        goal_owner_full_name: Data.FullName,
                        goal_owner_full_name_s: getGoalOwnerFullNameText(Data.FullName)
                    }),
                    link_url: config.protocol + config.baseUrl + '#/Profile/ApproveGoals/' + Data.Approver.MemberId + '/' + Data.MemberId + '?gid=' + Data.GroupId,
                    thank: i18nHelper.translate(i18n, "eml.GoalCycleCommon.thk", {
                        goal_cycle_creator_full_name: userInfo.UserPersonal.FullName,
                        goal_cycle_creator_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName
                    }),
                    body_txt: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.bod'].join(''), {
                        first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '',
                        goal_owner_full_name: Data.FullName,
                        goal_cycle_title: Data.CycleTitle
                    })
                };
                goalNotificationHelper(params, callback);
            });
        },
        goalSetRejected = function (params, callback) {
            var Data = params.Data,
                i18n = Data.i18n;
            EntityCache.UserInfo.findOne({hgId: Data.Approver.UserId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('Error loading the approver');
                }
                params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.sub'].join(''));
                params.NotificationQueueItem.MergeFields = {
                    teaser: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.tea'].join('')),
                    link_txt: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.lnk'].join('')),
                    link_url: config.protocol + config.baseUrl + '#/Profile/GoalDetails/View/' + Data.GoalOwnerMemberId + '/' + Data.GoalId + '?gid=' + Data.GroupId,
                    thank: i18nHelper.translate(i18n, "eml.GoalCommon.rtk", {
                        approver_full_name: userInfo.UserPersonal.FullName,
                        approver_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName,
                        note: Data.Note
                    }),
                    body_txt: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.bod'].join(''), {
                        first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '',
                        approver_full_name: userInfo.UserPersonal.FullName,
                        goal_name: Data.GoalName,
                        goal_cycle_title: Data.CycleTitle
                    })
                };
                goalNotificationHelper(params, callback);
            });
        },
        goalsSetApproved = function (params, callback) {
            var Data = params.Data,
                i18n = Data.i18n;
            EntityCache.UserInfo.findOne({hgId: Data.Approver.UserId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('Error loading the approver');
                }
                params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.sub'].join(''));
                params.NotificationQueueItem.MergeFields = {
                    teaser: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.tea'].join('')),
                    link_txt: i18nHelper.translate(i18n, ['eml.', params.EmailKey, '.lnk'].join('')),
                    link_url: params.CloseUrl ? config.protocol + config.baseUrl + '#/Profile/Cycles/' + Data.GoalOwnerMemberId + '/' + 'closed' : config.protocol + config.baseUrl + '#/Profile/Cycles/' + Data.GoalOwnerMemberId + '/' + getParticipantTypeForUrl(Data.Participant) + '?gid=' + Data.GroupId,
                    thank: i18nHelper.translate(i18n, 'eml.GoalCommon.atk', {
                        approver_full_name: userInfo.UserPersonal.FullName,
                        approver_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName
                    }),
                    body_txt: i18nHelper.translate(Data.i18n, ['eml.', params.EmailKey, '.bod'].join(''), {
                        first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '',
                        approver_full_name: userInfo.UserPersonal.FullName,
                        goal_cycle_title: Data.CycleTitle
                    })
                };
                goalNotificationHelper(params, callback);
            });
        },
        buildGoalsTable = function (params, cycle) {
            var getAvatarPath = function (userId) {
                    if (isLocal) {
                        return config.protocol + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + userId + '.jpg';
                    }
                    return config.protocol + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + userId + '.jpg';
                },
                goalsTemplate = cycle ? GoalTemplates.GoalsTable : GoalTemplates.AdhocGoalsTable,
                groupId = params.GroupId;
            return params.goals.map(function (goal) {
                return htmlHelper.replaceTokens(goalsTemplate, {
                    GoalUrl: config.protocol + config.baseUrl + '#/Profile/GoalDetails/View/' + goal.Owner.MemberId + '/' + goal.hgId + '?gid=' + groupId,
                    AvatarPath: getAvatarPath(goal.Owner.UserId),
                    GoalName: goal.Name,
                    CycleTitle: cycle ? cycle.Title : i18nHelper.translate(params.i18n, 'server.hge.na'),
                    CycleName: i18nHelper.translate(params.i18n, 'eml.common.cn'),
                    LastUpdated: i18nHelper.translate(params.i18n, 'eml.common.lu'),
                    GoalType: i18nHelper.translate(params.i18n, 'eml.common.gt'),
                    LastCheckInDate: DateHelper.formatDateStringFromTimestamp(goal.LastCheckInDate),
                    ParticipantType: goal.Participant ? getParticipantType(goal.Participant.ParticipantType, params.i18n) : ''
                });
            }).join('');
        },
        sendGoalReminder = function (params, callback) {
            var i18n = params.Data.i18n,
                Data = params.Data,
                contactUserId;
            if (!Data) {
                return callback('Error, no data present to complete request.');
            }
            EntityCache.Member.findOne({hgId: Data.Participant.Owner.MemberId}, function (err, member) {
                if (err || !member) {
                    return callback('Error loading the member');
                }
                if (member.MyManagers.length && member.MyManagers[0].UserId) {
                    contactUserId = member.MyManagers[0].UserId;
                } else {
                    contactUserId = Data.Cycle.CycleOwner.UserId;
                }
                EntityCache.UserInfo.findOne({hgId: contactUserId}, function (err, userInfo) {
                    if (err || !userInfo) {
                        return callback('Error loading the contact user');
                    }
                    params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.sub'].join(''));
                    params.NotificationQueueItem.MergeFields = {
                        teaser: i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.tea'].join('')),
                        body_txt: i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.bod'].join(''), {
                            first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : 0,
                            goal_cycle_title: params.Data.CycleTitle,
                            end_date: Data.Participant ? DateHelper.formatDateStringFromTimestamp(Data.Participant.ClosePromptDate) : '',
                            participant_type: Data.Participant ? getParticipantType(Data.Participant.ParticipantType, i18n) : '',
                            url_goals_profile: config.protocol + config.baseUrl + '#/Profile/Cycles/' + Data.Participant.Owner.MemberId + '/' + getParticipantTypeForUrl(Data.Participant) + '?gid=' + Data.GroupId,
                            due_date: Data.Participant ? DateHelper.formatDateStringFromTimestamp(Data.Participant.SetDueDate) : '',
                            close_due_date: Data.Participant ? DateHelper.formatDateStringFromTimestamp(Data.Participant.CloseDueDate) : '',
                            manager_notes: Data.Comment || '',
                            direct_manager_full_name: userInfo.UserPersonal.FullName,
                            direct_manager_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName,
                            full_name: Data.Goal && Data.Goal.Owner ? Data.Goal.Owner.FullName : "",
                            goal_name: Data.Goal ? Data.Goal.Name : "",
                            last_updated : Data.Goal && Data.Goal.LastCheckInDate ? DateHelper.formatDateStringFromTimestamp(params.Data.Goal.LastCheckInDate) : ""
                        }),
                        link_txt: i18nHelper.translate(i18n, ['eml.', params.ReminderType, '.lnk'].join('')),
                        link_url: config.protocol + config.baseUrl + '#/Profile/Cycles/' + Data.GoalOwner.MemberId + '/' + getParticipantTypeForUrl(Data.Participant) + '?gid=' + Data.GroupId,
                        thank: i18nHelper.translate(i18n, 'eml.GoalCommon.thk', {
                            direct_manager_full_name: userInfo.UserPersonal.FullName,
                            direct_manager_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName
                        })
                    };
                    callback(null, {
                        NotificationQueueItem: params.NotificationQueueItem,
                        Data: Data,
                        NotificationEvent: params.NotificationEvent,
                        DispatchOption: params.DispatchOption
                    });
                });
            });
        },
        sendGoalReminderV2 = function (params, callback) {
            var i18n = params.Data.i18n,
                Data = params.Data,
                contactUserId;
            if (!Data) {
                return callback('Error, no data present to complete request.');
            }
            EntityCache.Member.findOne({hgId: Data.Participant.Owner.MemberId}, function (err, member) {
                if (err || !member) {
                    return callback('Error loading the member');
                }
                if (member.MyManagers.length && member.MyManagers[0].UserId) {
                    contactUserId = member.MyManagers[0].UserId;
                } else {
                    contactUserId = Data.Cycle.CycleOwner.UserId;
                }
                EntityCache.UserInfo.findOne({hgId: contactUserId}, function (err, userInfo) {
                    if (err || !userInfo) {
                        return callback('Error loading the contact user');
                    }
                    params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.' + params.ReminderType + '.sub');
                    params.NotificationQueueItem.MergeFields = {
                        teaser: i18nHelper.translate(i18n, 'eml.' + params.ReminderType + '.tea'),
                        body_txt: i18nHelper.translate(i18n, 'eml.' + params.ReminderType + '.bod', {
                            first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : 0,
                            goal_cycle_title: params.Data.CycleTitle,
                            end_date: Data.Participant ? DateHelper.formatDateStringFromTimestamp(Data.Participant.ClosePromptDate) : '',
                            participant_type: Data.Participant ? getParticipantType(Data.Participant.ParticipantType, i18n) : '',
                            url_goals_profile: config.protocol + config.baseUrl + '#/Profile/Cycles/' + Data.Participant.Owner.MemberId + '/' + getParticipantTypeForUrl(Data.Participant) + '?gid=' + Data.GroupId,
                            due_date: Data.Participant ? DateHelper.formatDateStringFromTimestamp(Data.Participant.SetDueDate) : '',
                            close_due_date: Data.Participant ? DateHelper.formatDateStringFromTimestamp(Data.Participant.CloseDueDate) : '',
                            manager_notes: Data.Comment || '',
                            direct_manager_full_name: userInfo.UserPersonal.FullName,
                            direct_manager_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName,
                            full_name: Data.Goal && Data.Goal.Owner ? Data.Goal.Owner.FullName : "",
                            goal_name: Data.Goal ? Data.Goal.Name : "",
                            last_updated : Data.Goal && Data.Goal.LastCheckInDate ? DateHelper.formatDateStringFromTimestamp(params.Data.Goal.LastCheckInDate) : ""
                        }),
                        link_txt: i18nHelper.translate(i18n, 'eml.' + params.ReminderType + '.lnk'),
                        link_url: config.protocol + config.baseUrl + '#/Profile/Cycles/' + params.Data.GoalOwner.MemberId + '/' + getParticipantTypeForUrl(params.Data.Participant)  + '?gid=' + Data.GroupId,
                        thank: i18nHelper.translate(i18n, 'eml.' + params.ReminderType + '.thk', {
                            direct_manager_full_name: userInfo.UserPersonal.FullName,
                            direct_manager_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName
                        })
                    };
                    callback(null, {
                        NotificationQueueItem: params.NotificationQueueItem,
                        Data: Data,
                        NotificationEvent: params.NotificationEvent,
                        DispatchOption: params.DispatchOption
                    });
                });
            });
        };
    this.GoalCycleOwnershipTransferred = function (params, callback) {
        var i18n = params.Data.i18n,
            Data = params.Data,
            buildTable = function (data) {
                var groupId = data.GroupId;
                return data.Cycles.map(function (item) {
                    return htmlHelper.replaceTokens(GoalTemplates.GoalCycleTransfer, {
                        GoalUrl: config.protocol + config.baseUrl + '#/Admin/Goals/Cycles/Details/' + item.hgId + '?gid=' + groupId,
                        Title: item.Title
                    });
                }).join('');
            };
        params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.GoalCycleOwnershipTransferred.sub');
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(i18n, 'eml.GoalCycleOwnershipTransferred.tea'),
            body_txt: i18nHelper.translate(i18n, 'eml.GoalCycleOwnershipTransferred.bod', {
                first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : 0,
                goal_cycles_table: buildTable(Data)
            }),
            thank: i18nHelper.translate(i18n, 'eml.common.thank')
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.GoalCycleParticipantUploadError = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem,
            buildTable = function () {
                var tableHtml = '',
                    mapping = {
                        LoadFileData: 'eml.GoalCycleParticipantUploadError.lfd',
                        EmptyUserList: 'eml.GoalCycleParticipantUploadError.el',
                        InvalidOperation: 'eml.GoalCycleParticipantUploadError.io',
                        MixedOperation: 'eml.GoalCycleParticipantUploadError.mo',
                        ErrorLoadUsers: 'eml.GoalCycleParticipantUploadError.elu',
                        InvalidUserName: 'eml.GoalCycleParticipantUploadError.iun',
                        ErrorLoadMembers: 'eml.GoalCycleParticipantUploadError.elm',
                        InvalidMember: 'eml.GoalCycleParticipantUploadError.im'
                    },
                    i,
                    len = Data.Error.length > 20 ? 20 : Data.Error.length;
                for (i = 0; i < len; i += 1) {
                    tableHtml += i18nHelper.translate(params.Data.i18n, mapping[Data.Error[i].Type], {
                        value: Data.Error[i].Value || ""
                    });
                }
                return tableHtml;
            };
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadError.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            file_name: Data.FileName,
            audits: buildTable()
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Admin/Goals/Cycles/Details/' + Data.CycleId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadError.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadError.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadError.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
    this.GoalCycleParticipantUploadProcessed = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem,
            buildTable = function () {
                var tableHtml = '',
                    mapping = {
                        SkipAdd: 'eml.GoalCycleParticipantUploadProcessed.sa',
                        SkipRemove: 'eml.GoalCycleParticipantUploadProcessed.sr',
                        Add: 'eml.GoalCycleParticipantUploadProcessed.add',
                        Remove: 'eml.GoalCycleParticipantUploadProcessed.rem',
                        ErrorAdd: 'eml.GoalCycleParticipantUploadProcessed.ea',
                        ErrorRemove: 'eml.GoalCycleParticipantUploadProcessed.er'
                    },
                    i,
                    len = Data.OperationAudits.length > 20 ? 20 : Data.OperationAudits.length;
                for (i = 0; i < len; i += 1) {
                    tableHtml += i18nHelper.translate(params.Data.i18n, mapping[Data.OperationAudits[i].Type], {
                        member_name: Data.OperationAudits[i].Name,
                        error: Data.OperationAudits[i].Error || ""
                    });
                }
                return tableHtml;
            },
            buildSummary = function () {
                var summaryHtml = '',
                    Numbers = {
                        SkipAdd: 0,
                        SkipRemove: 0,
                        Add: 0,
                        Remove: 0,
                        ErrorAdd: 0,
                        ErrorRemove: 0
                    },
                    mapping = {
                        SkipAdd: 'eml.GoalCycleParticipantUploadProcessed.nsa',
                        SkipRemove: 'eml.GoalCycleParticipantUploadProcessed.nsr',
                        Add: 'eml.GoalCycleParticipantUploadProcessed.nadd',
                        Remove: 'eml.GoalCycleParticipantUploadProcessed.nrem',
                        ErrorAdd: 'eml.GoalCycleParticipantUploadProcessed.nea',
                        ErrorRemove: 'eml.GoalCycleParticipantUploadProcessed.ner'
                    };
                params.Data.OperationAudits.forEach(function (audit) {
                    Numbers[audit.Type] += 1;
                });
                Object.keys(mapping).forEach(function (key) {
                    summaryHtml += i18nHelper.translate(params.Data.i18n, mapping[key], {
                        number: Numbers[key]
                    });
                });
                return summaryHtml;
            };
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadProcessed.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            cycle_title: Data.Cycle.Title,
            audits: buildTable(),
            summary: buildSummary()
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Admin/Goals/Cycles/Details/' + Data.Cycle.hgId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadProcessed.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadProcessed.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.GoalCycleParticipantUploadProcessed.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
    this.GoalOwnershipTransferred = function (params, callback) {
        var Data = params.Data,
            i18n = params.Data.i18n,
            buildTable = function (data) {
                var getAvatarPath = function (userId) {
                        if (isLocal) {
                            return config.protocol + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + userId + '.jpg';
                        }
                        return config.protocol + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + userId + '.jpg';
                    };
                return data.Goal.map(function (item) {
                    return htmlHelper.replaceTokens(GoalTemplates.GoalTransfer, {
                        GoalUrl: config.protocol + config.baseUrl + '#/Profile/Cycles/' + item.Owner.MemberId + '?gid=' + Data.GroupId,
                        Title: item.Title,
                        AvatarPath: getAvatarPath(item.Owner.UserId)
                    });
                }).join('');
            };
        params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.GoalOwnershipTransferred.sub');
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(i18n, 'eml.GoalOwnershipTransferred.tea'),
            body_txt: i18nHelper.translate(i18n, 'eml.GoalOwnershipTransferred.bod', {
                first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : 0,
                goals_table: buildTable(Data)
            }),
            thank: i18nHelper.translate(i18n, 'eml.common.thank')
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.GoalApproverTransferred = function (params, callback) {
        var Data = params.Data,
            i18n = params.Data.i18n,
            buildTable = function (data) {
                var getAvatarPath = function (userId) {
                        if (isLocal) {
                            return config.protocol + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + userId + '.jpg';
                        }
                        return config.protocol + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + userId + '.jpg';
                    };
                return data.Goal.map(function (item) {
                    return htmlHelper.replaceTokens(GoalTemplates.GoalTransfer, {
                        GoalUrl: config.protocol + config.baseUrl + '#/Profile/Cycles/' + item.Owner.MemberId + '?gid=' + Data.GroupId,
                        Title: item.Title,
                        AvatarPath: getAvatarPath(item.Owner.UserId)
                    });
                }).join('');
            };
        params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.GoalApproverTransferred.sub');
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(i18n, 'eml.GoalApproverTransferred.tea'),
            body_txt: i18nHelper.translate(i18n, 'eml.GoalApproverTransferred.bod', {
                first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : 0,
                goals_table: buildTable(Data)
            }),
            thank: i18nHelper.translate(i18n, 'eml.common.thank')
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.GoalCycleBuilt = function (params, callback) {
        var Data = params.Data,
            i18n = params.Data.i18n;
        params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.GoalCycleBuilt.sub');
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(i18n, 'eml.GoalCycleBuilt.tea'),
            body_txt: i18nHelper.translate(i18n, 'eml.GoalCycleBuilt.bod', {
                goal_cycle_title: Data.Cycle.Title,
                first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : 0
            }),
            link_txt: i18nHelper.translate(i18n, 'eml.GoalCycleBuilt.lnk'),
            link_url: config.protocol + config.baseUrl + '#/Admin/Goals/Cycles/Edit/' + Data.Cycle.hgId + '?gid=' + Data.GroupId,
            thank: i18nHelper.translate(i18n, 'eml.common.thank')
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.CloseAdhocGoalPrompt = function (params, callback) {
        var Data = params.Data,
            i18n = params.Data.i18n;
        params.NotificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.CloseAdhocGoalPrompt.sub');
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(i18n, 'eml.CloseAdhocGoalPrompt.tea'),
            body_txt: i18nHelper.translate(i18n, 'eml.CloseAdhocGoalPrompt.bod', {
                first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : 0,
                Goals: buildGoalsTable({
                    goals: Data.Goals,
                    GroupId: Data.GroupId,
                    i18n: i18n
                })
            }),
            link_txt: i18nHelper.translate(i18n, 'eml.CloseAdhocGoalPrompt.lnk'),
            link_url: config.protocol + config.baseUrl + '#/Profile/Cycles/' + Data.OwnerMemberId + '/' + 'member?gid=' + Data.GroupId,
            thank: i18nHelper.translate(i18n, 'eml.common.thank')
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.GoalCheckIn = function (params, callback) {
        var Data = params.Data,
            label = 'Lbl',
            cycle = Data.Cycle,
            goalMap = {
                OnTimeGoals: Data.OnTimeGoals.length,
                LateGoals: params.Data.LateGoals.length,
                ClosedGoals: params.Data.ClosedGoals.length,
                SubmittedForClosureGoals: params.Data.SubmittedForClosureGoals.length
            },
            replaceMap = {};
        Object.keys(goalMap).forEach(function (g) {
            if (goalMap[g]) {
                replaceMap[g + label] = i18nHelper.translate(params.Data.i18n, 'eml.GoalCheckIn.' + g + label);
                replaceMap[g] = buildGoalsTable({
                    goals: params.Data[g],
                    GroupId: Data.GroupId,
                    i18n: params.Data.i18n
                }, cycle);
            }
        });

        params.NotificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.GoalCheckIn.sub');
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(params.Data.i18n, 'eml.GoalCheckIn.tea'),
            body_txt: i18nHelper.translate(params.Data.i18n, 'eml.GoalCheckIn.bod', {
                first_name: params.Data.Owner.FullName,
                CycleTitle: cycle.Title,
                CheckInFrequency: params.Data.CheckInFrequency.toLowerCase(),
                html_body: htmlHelper.replaceTokens(
                    htmlHelper.toggleAreas(GoalTemplates.CheckIn, goalMap),
                    replaceMap
                )
            })
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.GoalsClosureApproved = function (params, callback) {
        params.CloseUrl = true;
        params.EmailKey = 'GoalsClosureApproved';
        goalsSetApproved(params, callback);
    };

    this.GoalsSetApproved = function (params, callback) {
        params.EmailKey = 'GoalsSetApproved';
        goalsSetApproved(params, callback);
    };

    this.GoalCloseRejected = function (params, callback) {
        params.EmailKey = 'GoalCloseRejected';
        goalSetRejected(params, callback);
    };

    this.GoalSetRejected = function (params, callback) {
        params.EmailKey = 'GoalSetRejected';
        goalSetRejected(params, callback);
    };

    this.GoalCloseRequested = function (params, callback) {
        params.EmailKey = 'GoalCloseRequested';
        goalSetRequested(params, callback);
    };

    this.GoalCreatedForYou = function (params, callback) {
        goalCreatedForYou(params, callback);
    };

    this.GoalSetRequested = function (params, callback) {
        params.EmailKey = 'GoalSetRequested';
        goalSetRequested(params, callback);
    };

    this.TemplateGoalAssigned = function (params, callback) {
        params.ReminderType = NotificationsEnums.Event.TemplateGoalAssigned.Name;
        params.SuppressThank = true;
        goalCycleDelivered(params, callback);
    };

    this.GoalCycleDelivered = function (params, callback) {
        params.ReminderType = 'GoalCycleDelivered';
        goalCycleDelivered(params, callback);
    };
    this.GoalCreationReminder = function (params, callback) {
        params.ReminderType = 'GoalCreationReminder';
        sendGoalReminderV2(params, callback);
    };
    this.GoalOverdueReminder = function (params, callback) {
        params.ReminderType = 'GoalOverdueReminder';
        sendGoalReminderV2(params, callback);
    };
    this.CloseGoalPrompt = function (params, callback) {
        params.ReminderType = 'CloseGoalPrompt';
        sendGoalReminderV2(params, callback);
    };
    this.CloseGoalOverdue = function (params, callback) {
        params.ReminderType = 'CloseGoalOverdue';
        sendGoalReminder(params, callback);
    };
    this.CloseSingleAdhocGoalReminder = function (params, callback) {
        var Data = params.Data;
        EntityCache.Member.findOne({hgId: Data.Goal.Owner.MemberId}, function (err, member) {
            if (err || !member) {
                return callback('Error loading the member');
            }
            if (!member.MyManagers.length || !member.MyManagers[0].UserId) {
                return callback('User does not have a manager');
            }
            EntityCache.UserInfo.findOne({hgId: member.MyManagers[0].UserId}, function (err, userInfo) {
                if (err || !userInfo) {
                    return callback('Error loading the contact user');
                }
                params.NotificationQueueItem.Subject = i18nHelper.translate(Data.i18n, ['eml.CloseSingleAdhocGoalReminder.sub'].join(''));
                params.NotificationQueueItem.MergeFields = {
                    teaser: i18nHelper.translate(Data.i18n, ['eml.CloseSingleAdhocGoalReminder.tea'].join('')),
                    body_txt: i18nHelper.translate(Data.i18n, ['eml.CloseSingleAdhocGoalReminder.bod'].join(''), {
                        first_name: params.NotificationQueueItem.RecipientList.length ? params.NotificationQueueItem.RecipientList[0].Name : '',
                        manager_notes: Data.Comment || '',
                        direct_manager_full_name: userInfo.UserPersonal.FullName,
                        direct_manager_email: userInfo.UserPersonal.PrimaryEmail || userInfo.UserName,
                        full_name: Data.Goal && Data.Goal.Owner ? Data.Goal.Owner.FullName : "",
                        goal_name: Data.Goal ? Data.Goal.Name : ""
                    }),
                    link_txt: i18nHelper.translate(Data.i18n, ['eml.CloseSingleAdhocGoalReminder.lnk'].join('')),
                    link_url: config.protocol + config.baseUrl + '#/Profile/GoalDetails/View/' + Data.Goal.Owner.MemberId + '/' + Data.Goal.hgId + '?gid=' + Data.GroupId,
                    thank: i18nHelper.translate(Data.i18n, 'eml.common.thank')
                };
                callback(null, {
                    NotificationQueueItem: params.NotificationQueueItem,
                    Data: Data,
                    NotificationEvent: params.NotificationEvent,
                    DispatchOption: params.DispatchOption
                });
            });
        });
    };
    this.GoalOwnershipTransferred = function (params, callback) {
        var Data = params.Data,
            buildTable = function (data) {
                var getAvatarPath = function (userId) {
                        if (isLocal) {
                            return config.protocol + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + userId + '.jpg';
                        }
                        return config.protocol + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + userId + '.jpg';
                    },
                    groupId = data.GroupId;
                return data.Goal.map(function (item) {
                    return htmlHelper.replaceTokens(GoalTemplates.GoalTransfer, {
                        GoalUrl: config.protocol + config.baseUrl + '#/Profile/Cycles/' + item.Owner.MemberId + '/' + getParticipantTypeForUrl(item.Participant) + '?gid=' + groupId,
                        Title: item.Title,
                        AvatarPath: getAvatarPath(item.Owner.UserId)
                    });
                }).join('');
            };
        params.NotificationQueueItem.MergeFields = {
            full_name: Data.FullName,
            goals_table: buildTable(Data)
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
};

module.exports = GoalBuilder;