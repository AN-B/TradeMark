/*jslint node:true es5:true*/
var RecapBuilder = function () {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        RecapHtmlTemplateEnums = require('../../../enums/RecapHtmlTemplateEnums.js'),
        DateHelper = require('../../../util/DateHelper'),
        SurveyEnums = require('../../../enums/SurveyEnums.js'),
        ConstantEnums = require('../../../enums/ConstantEnums.js'),
        FeatureFlagEnums = require('../../../enums/FeatureFlagEnums.js'),
        Enums = require('../../../enums/EntityEnums.js'),
        htmlHelper = require('../../../helpers/htmlHelper.js'),
        time = require('time'),
        config = require('../../../configurations/config'),
        i18nHelper = require('../../../helpers/i18nHelper.js'),
        buildTrackInProgressRow = function (params, track) {
            var url = config.protocol + config.baseUrl + '#/Track/Iso/' + track.hgId + '?gid=' + params.Data.GroupId,
                imgSrc,
                milestoneIds = [],
                curTime = new Date().getTime(),
                overdueMilestones = 0,
                overdueMessage = '',
                LastUpdateInfo = '',
                i;
            if (config.s3store.s3bucket === '') {
                imgSrc = 'http:' + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.RecognitionTemplateRoot + track.CareerTrackTemplate.Goal.RecognitionTemplate.FriendlyGroupId + '/' + track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId + '.svg';
            } else {
                imgSrc = 'https:' + config.baseUrl + 'svgx/' + config.filepath.RecognitionTemplateRoot + track.CareerTrackTemplate.Goal.RecognitionTemplate.FriendlyGroupId + '/' + track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId + '.svg';
            }
            track.SetPercentAchieved();
            for (i = 0; i < track.CareerTrackTemplate.MileStones.length; i += 1) {
                milestoneIds.push(track.CareerTrackTemplate.MileStones[i].hgId);
                if (track.CareerTrackTemplate.MileStones[i].TargetDate) {
                    if (curTime > track.CareerTrackTemplate.MileStones[i].TargetDate &&
                            track.CareerTrackTemplate.MileStones[i].PercentAchieved !== 100 &&
                            [Enums.MilestoneStatus.NotStarted, Enums.MilestoneStatus.InProgress, Enums.MilestoneStatus.OverDue].indexOf(track.CareerTrackTemplate.MileStones[i].Status) > -1) {
                        overdueMilestones += 1;
                    }
                }
            }
            if (overdueMilestones > 0) {
                if (overdueMilestones === 1) {
                    overdueMessage = '1 milestone overdue';
                } else {
                    overdueMessage = overdueMilestones + ' milestones overdue';
                }
            }
            if (track.ModifiedDate < curTime - 365 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over 1 year since this track has been updated. Should you close it?";
            } else if (track.ModifiedDate < curTime - 180 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over 6 months since this track has been updated. Should you close it?";
            } else if (track.ModifiedDate < curTime - 90 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over 3 months since this track has been updated. Should you close it?";
            } else if (track.ModifiedDate < curTime - 60 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over 2 months since this track has been updated. Should you close it?";
            } else if (track.ModifiedDate < curTime - 30 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over a month since this track has been updated. Should you close it?";
            } else if (track.ModifiedDate < curTime - 21 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over 3 weeks since this track has been updated. Should you close it?";
            } else if (track.ModifiedDate < curTime - 14 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over 2 weeks since this track has been updated. Should you close it?";
            } else if (track.ModifiedDate < curTime - 7 * 24 * 3600 * 1000) {
                LastUpdateInfo = "It's been over 1 week since this track has been updated. Should you close it?";
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TrackInProgressRow, {
                TrackUrl: url,
                TrackImageSrc: imgSrc,
                TrackTitle: track.CareerTrackTemplate.Title,
                Percentage: track.PercentAchieved,
                OverdueMilestoneMessage: overdueMessage,
                LastUpdateInfo: LastUpdateInfo
            });
        },
        getFilter = function (relevancyMap) {
            var isAll = !Object.keys(relevancyMap).length;
            return function (umbre) {
                return isAll || !!relevancyMap[umbre.hgId];
            };
        },
        buildTracksInProgressHtml = function (params) {
            var tracksInProgress = params.TracksInProgress;
            if (!tracksInProgress || !tracksInProgress.length) {
                return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.GoCreateTrack, {
                    Link: config.protocol + config.baseUrl + '#/Track/Create' + '?gid=' + params.Data.GroupId,
                });
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TracksInProgress, {
                HeaderTracksInProgress: 'You are working on ' + tracksInProgress.length + ' track' + (tracksInProgress.length > 1 ? 's' : ''),
                TracksInProgressRows: tracksInProgress.map(function (track) {
                    return buildTrackInProgressRow(params, track);
                }).join('')
            });
        },
        buildTrackNeedApprovalRow = function (params, track) {
            var imgSrc = [
                    config.filepath.RecognitionTemplateRoot,
                    track.CareerTrackTemplate.Goal.RecognitionTemplate.FriendlyGroupId,
                    '/',
                    track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId,
                    '.svg'
                ].join('');
            if (config.s3store.s3bucket === '') {
                imgSrc = [
                    'http:',
                    config.baseUrl,
                    config.s3store.imageStore[0],
                    '/'
                ].join('') + imgSrc;
            } else {
                imgSrc = [
                    'https:',
                    config.baseUrl,
                    'svgx/'
                ].join('') + imgSrc;
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TrackNeedApprovalRow, {
                TrackUrl: config.protocol + config.baseUrl + '#/Track/Iso/' + track.hgId + '?gid=' + params.Data.GroupId,
                TrackImageSrc: imgSrc,
                TrackTitle: track.CareerTrackTemplate.Title
            });
        },
        buildTracksNeedApprovalHtml = function (params) {
            var tracksNeedApproval = params.TracksNeedApproval;
            if (!tracksNeedApproval || !tracksNeedApproval.length) {
                return '';
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TrackNeedApproval, {
                HeaderTrackNeedApproval: tracksNeedApproval.length === 1 ? 'This track needs your approval:' : 'These tracks need your approval:',
                TracksNeedApprovalRows: tracksNeedApproval.map(function (track) {
                    return buildTrackNeedApprovalRow(params, track);
                }).join('')
            });
        },
        buildViewRecognitionsHtml = function (params, recapType) {
            var companyRecognitions = recapType !== Enums.RecapType.Daily ? params.Data.GroupContent[params.Data.GroupId].Recognitions : params.Data.GroupContent[params.Data.GroupId].Recognitions.Yesterday,
                url,
                buttonText,
                Data = params.Data;
            if (!companyRecognitions || !companyRecognitions.length) {
                buttonText = 'eml.RecapBuilder.grs';
                url = config.protocol + config.baseUrl + '#/Recognize/Profile/GiveEveryday' + '?gid=' + Data.GroupId;
            } else {
                buttonText = 'eml.RecapBuilder.vr';
                url = config.protocol + config.baseUrl + '#/Company/Filter/All' + '?gid=' + Data.GroupId;
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.ViewRecognitionButton, {
                URLViewRecognitions: url,
                RecognitionButtonText: i18nHelper.translate(params.Data.i18n, buttonText)
            });
        },
        buildRecipientAvatars = function (recognition, recognitionsInSameBatch) {
            var avatarsHtml,
                imgSrc,
                i,
                limit = recognitionsInSameBatch.length <= 10 ? recognitionsInSameBatch.length : 10;
            if (config.s3store.s3bucket === '') {
                imgSrc = 'http:' + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + recognition.RecipientMember.UserId + '.jpg';
            } else {
                imgSrc = 'https:' + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + recognition.RecipientMember.UserId + '.jpg';
            }
            avatarsHtml = htmlHelper.replaceTokens(RecapHtmlTemplateEnums.OneRecipientAvatar, {
                OneRecipientImageSrc: imgSrc
            });
            for (i = 0; i < limit; i += 1) {
                if (config.s3store.s3bucket === '') {
                    imgSrc = 'http:' + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + recognitionsInSameBatch[i].RecipientMember.UserId + '.jpg';
                } else {
                    imgSrc = 'https:' + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + recognitionsInSameBatch[i].RecipientMember.UserId + '.jpg';
                }
                avatarsHtml += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.OneRecipientAvatar, {
                    OneRecipientImageSrc: imgSrc
                });
            }
            return avatarsHtml;
        },
        buildCompanyRecognitionRow = function (params, recognition, companyRecognitions) {
            var url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + recognition.BatchId + '?gid=' + params.Data.GroupId,
                likeUrl = config.protocol + config.baseUrl + '#/Recognize/Like/' + recognition.BatchId + '?gid=' + params.Data.GroupId,
                imgSrc,
                commentText = '',
                i,
                trimComment = function (comment) {
                    var text = comment.slice(0, 150);
                    if (text.length < 150 || comment.length === 150) {
                        return text;
                    }
                    if (comment[149] !== ' ') {
                        for (i = 150; i < 170; i += 1) {
                            if (!comment[i] || comment[i] === ' ') {
                                break;
                            }
                            text += comment[i];
                        }
                    }
                    text += '...';
                    return text;
                },
                getTitle = function () {
                    if (recognition.SubValue) {
                        return recognition.SubValue + ' (' + recognition.Template.Title + ')';
                    }
                    return recognition.Template.Title;
                },
                recognitionsInSameBatch = companyRecognitions.filter(function (r) {
                    return r.BatchId === recognition.BatchId && r.hgId !== recognition.hgId;
                }),
                recipientInfo = '',
                recipientAvatars = '';
            if (recognitionsInSameBatch.length === 0) {
                recipientInfo = recognition.RecipientMember.FullName;
            } else if (recognitionsInSameBatch.length === 1) {
                recipientInfo = recognition.RecipientMember.FullName + ' and ' + recognitionsInSameBatch[0].RecipientMember.FullName;
            } else if (recognitionsInSameBatch.length === 2) {
                recipientInfo = recognition.RecipientMember.FullName + ' and ' + recognitionsInSameBatch[0].RecipientMember.FullName + ' and 1 other';
            } else {
                recipientInfo = recognition.RecipientMember.FullName + ' and ' + recognitionsInSameBatch[0].RecipientMember.FullName + ' and ' + (recognitionsInSameBatch.length - 1) + ' others';
            }
            if (recognitionsInSameBatch.length === 0) {
                if (config.s3store.s3bucket === '') {
                    imgSrc = 'http:' + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.UserProfile + recognition.RecipientMember.UserId + '.jpg';
                } else {
                    imgSrc = 'https:' + config.s3store.imageStore[config.nextIndex()] + '/' + config.filepath.UserProfile + recognition.RecipientMember.UserId + '.jpg';
                }
            } else {
                if (config.s3store.s3bucket === '') {
                    imgSrc = 'http:' + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.RecognitionTemplateRoot + recognition.Template.FriendlyGroupId + '/' + recognition.BadgeFilename + '.svg';
                } else {
                    imgSrc = 'https:' + config.baseUrl + 'svgx/' + config.filepath.RecognitionTemplateRoot + recognition.Template.FriendlyGroupId + '/' + recognition.BadgeFilename + '.svg';
                }
                recipientAvatars = buildRecipientAvatars(recognition, recognitionsInSameBatch);
            }
            if (recognition.Message || recognition.CannedMessage) {
                commentText = trimComment(recognition.Message || recognition.CannedMessage);
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.CompanyRecognitionRow, {
                RecipientAvatars: recipientAvatars,
                RecUrl: url,
                LikeUrl: likeUrl,
                RecipientImageSrc: imgSrc,
                CommentSummary: commentText,
                LikeText: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.lt'),
                ReceivedRecognitionMessage: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.rcrr', {
                    RecipientName: recipientInfo,
                    RecTitle: getTitle()
                })
            });
        },
        getNextMostRelevantRecognition = function (recognitions) {
            if (recognitions && recognitions.length > 0) {
                return recognitions[0];
            }
        },
        buildCompanyRecognitionsHtml = function (params, recapType) {
            var companyRecognitions = [],
                companyRecognitionRows = '',
                yesterdayText = 'eml.RecapBuilder.yst',
                clonedCompanyRecognitions,
                nextMostRelevantRecognition,
                i,
                j,
                notInSameBatchFilter = function (r) {
                    return r.BatchId !== nextMostRelevantRecognition.BatchId;
                },
                relevantRecognitions,
                relevancyMap = params.Data.RelevancyMap;
            if (recapType !== 'Daily') {
                companyRecognitions = params.Data.GroupContent[params.Data.GroupId].Recognitions;
                yesterdayText = 'eml.RecapBuilder.wk';
            } else {
                if (params.Data.Mode === 'Monday') { // this is from the old code to handle weekend recap
                    yesterdayText = 'eml.RecapBuilder.fr';
                    companyRecognitions = params.Data.GroupContent[params.Data.GroupId].Recognitions.PastWeekend;
                } else {
                    companyRecognitions = params.Data.GroupContent[params.Data.GroupId].Recognitions.Yesterday;
                }
            }
            yesterdayText = i18nHelper.translate(params.Data.i18n, yesterdayText);
            if (!companyRecognitions || companyRecognitions.length < 1) {
                return '';
            }
            clonedCompanyRecognitions = companyRecognitions.slice(0);
            if (relevancyMap) {
                relevantRecognitions = clonedCompanyRecognitions.filter(function (recognition) {
                    var recipientMemberId = recognition.RecipientMember ? recognition.RecipientMember.hgId : "",
                        creatorMemberId = recognition.CreatorMember ? recognition.CreatorMember.hgId : "";
                    return relevancyMap[recipientMemberId] || relevancyMap[creatorMemberId];
                }).slice(0);
            } else {
                relevantRecognitions = clonedCompanyRecognitions.slice(0);
            }
            for (i = 0; i < 5; i += 1) {
                nextMostRelevantRecognition = getNextMostRelevantRecognition(relevantRecognitions);
                if (nextMostRelevantRecognition) {
                    companyRecognitionRows += buildCompanyRecognitionRow(params, nextMostRelevantRecognition, clonedCompanyRecognitions);
                    relevantRecognitions = relevantRecognitions.filter(notInSameBatchFilter);
                    clonedCompanyRecognitions = clonedCompanyRecognitions.filter(notInSameBatchFilter);
                } else {
                    break;
                }
            }
            //if there are less than 5 badges from the relevancy list, pad with company wide badges
            for (j = i; j < 5; j += 1) {
                nextMostRelevantRecognition = getNextMostRelevantRecognition(clonedCompanyRecognitions);
                if (nextMostRelevantRecognition) {
                    companyRecognitionRows += buildCompanyRecognitionRow(params, nextMostRelevantRecognition, clonedCompanyRecognitions);
                    clonedCompanyRecognitions = clonedCompanyRecognitions.filter(notInSameBatchFilter);
                } else {
                    break;
                }
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.CompanyRecognitions, {
                CompanyRecognitionMessage: i18nHelper.translate(params.Data.i18n,
                    companyRecognitions.length === 1 ? 'eml.RecapBuilder.rcr1' : 'eml.RecapBuilder.rcrm', {
                        CompanyRecognitionNumber: companyRecognitions.length,
                        CompanyRecognitionTime: yesterdayText
                    }),
                CompanyRecognitionRows: companyRecognitionRows
            });
        },
        buildMyRecognitionRow = function (params, recognition) {
            var comments = [],
                url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + recognition.BatchId  + '?gid=' + params.Data.GroupId,
                imgSrc,
                clHtml = '',
                getTitle = function () {
                    if (recognition.SubValue) {
                        return recognition.SubValue + ' (' + recognition.Template.Title + ')';
                    }
                    return recognition.Template.Title;
                };
            if (params.Data.GroupContent[params.Data.GroupId].Comments && params.Data.GroupContent[params.Data.GroupId].Comments.length) {
                comments = params.Data.GroupContent[params.Data.GroupId].Comments.filter(function (comment) {
                    return comment.EntityId === recognition.hgId;
                });
            }
            if (config.s3store.s3bucket === '') {
                imgSrc = 'http:' + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.RecognitionTemplateRoot + recognition.Template.FriendlyGroupId + '/' + recognition.BadgeFilename + '.svg';
            } else {
                imgSrc = 'https:' + config.baseUrl + 'svgx/' + config.filepath.RecognitionTemplateRoot + recognition.Template.FriendlyGroupId + '/' + recognition.BadgeFilename + '.svg';
            }
            if (recognition.CongratsCount > 0 || comments.length > 0) {
                clHtml += ' - ';
                if (recognition.CongratsCount === 1) {
                    clHtml += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.ol');
                    if (comments.length > 0) {
                        clHtml += ', ';
                    }
                } else if (recognition.CongratsCount > 1) {
                    clHtml += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.li', {
                        like_num: recognition.CongratsCount
                    });
                    if (comments.length > 0) {
                        clHtml += ', ';
                    }
                }
                if (comments.length === 1) {
                    clHtml += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.oc');
                } else if (comments.length > 1) {
                    clHtml += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.co', {
                        comment_num: comments.length
                    });
                }
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.MyRecognitionRow, {
                RecUrl: url,
                RecImageSrc: imgSrc,
                RecTitle: getTitle(),
                LikeCommentCount: clHtml
            });
        },
        buildMyRecognitionsHtml = function (params, recapType) {
            var myRecognitions = params.Data.GroupContent[params.Data.GroupId].Recognitions.Yesterday,
                yesterdayText = 'eml.RecapBuilder.yst';
            if (recapType !== 'Daily') {
                myRecognitions = params.Data.GroupContent[params.Data.GroupId].Recognitions;
                yesterdayText = 'eml.RecapBuilder.wk';
            }
            myRecognitions = myRecognitions || [];
            myRecognitions = myRecognitions.filter(function (recognition) {
                return recognition.RecipientMember.hgId === params.Member.hgId;
            });
            if (!myRecognitions || !myRecognitions.length) {
                return '';
            }
            yesterdayText = i18nHelper.translate(params.Data.i18n, yesterdayText);
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.MyRecognitions, {
                MyRecognitionNumber: i18nHelper.translate(params.Data.i18n,
                    myRecognitions.length === 1 ? 'eml.RecapBuilder.yr1' : 'eml.RecapBuilder.yrm', {
                        MyRecognitionNumber: myRecognitions.length,
                        CompanyRecognitionTime: yesterdayText
                    }),
                MyRecognitionRows: myRecognitions.map(function (recognition) {
                    return buildMyRecognitionRow(params, recognition);
                }).join('')
            });
        },
        buildPulseSurveyRowHtml = function (params) {
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.MyPulseSurveyRow, {
                FeedUrl: config.protocol + config.baseUrl + '#/Company/Filter/All' + '?gid=' + params.Data.GroupId,
                QuestionText: params.PendingSurvey.QuestionText
            });
        },
        buildPulseSurveyHtml = function (params) {
            if (!params.PendingSurvey) {
                return '';
            }
            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.MyPulseSurvey, {
                MyRecognitionRow: buildPulseSurveyRowHtml(params)
            });
        },
        buildRecognitionsAndTracksHtmlByRecapType = function (params, recapType) {
            var html = htmlHelper.replaceTokens(RecapHtmlTemplateEnums.Greeting, {
                MyFirstName: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.hi', { MyFirstName: params.Member.FullName})
            });
            if (!params.HideRecognitionInRecap) {
                html += buildMyRecognitionsHtml(params, recapType);
                html += buildCompanyRecognitionsHtml(params, recapType);
                html += buildViewRecognitionsHtml(params, recapType);
            }
            if (!params.HideTrackInRecap) {
                html += buildTracksNeedApprovalHtml(params);
                html += buildTracksInProgressHtml(params);
            }
            html += buildPulseSurveyHtml(params);
            return html;
        },
        buildDailyRecognitionsAndTracksHtml = function (params) {
            return buildRecognitionsAndTracksHtmlByRecapType(params, 'Daily');
        },
        buildWeeklyRecognitionsAndTracksHtml = function (params) {
            return buildRecognitionsAndTracksHtmlByRecapType(params, 'Weekly');
        },
        buildAnniversaryRow = function (params, member, recapType, recapPeriod) {
            var Data = params.Data,
                recognitionTemplateIds = Data.GroupContent[Data.GroupId].RecognitionTemplateIds,
                years = new Date().getFullYear() - new Date(member.StartingDate).getFullYear(),
                curMonth = new Date().getMonth(),
                anniversaryMonth = new Date(member.StartingDate).getMonth(),
                recapTypeRecognitions = recapType === Enums.RecapType.Daily ? Data.GroupContent[Data.GroupId].Recognitions[recapPeriod] || [] : Data.GroupContent[Data.GroupId].Recognitions,
                recognition,
                url;
            // Change to redirect anniversary to Feed
            if (curMonth === 11 && anniversaryMonth === 0) {
                years += 1;
            }
            if (curMonth === 0 && anniversaryMonth === 11) {
                years -= 1;
            }

            recognition = recapTypeRecognitions.find(function (recognition) {
                return recognitionTemplateIds.Anniversary.indexOf(recognition.Template.hgId) !== -1 && recognition.RecipientMember.UserId === member.UserId;
            });

            if (recognition) {
                url = [config.protocol, config.baseUrl, '#/Recognize/Iso/', recognition.BatchId].join('') + '?gid=' + Data.GroupId;
            } else {
                url = [config.protocol, config.baseUrl, '#/Company/Filter/All'].join('') + '?gid=' + Data.GroupId;
            }

            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.AnniversaryRow, {
                RecUrl: url,
                AnnSummary: member.FullName + ' - ' + years
            });
        },
        buildBirthdayRow = function (params, member, recapType, recapPeriod) {
            var Data = params.Data,
                recapTypeRecognitions = recapType === Enums.RecapType.Daily ? params.Data.GroupContent[params.Data.GroupId].Recognitions[recapPeriod] || [] : params.Data.GroupContent[params.Data.GroupId].Recognitions,
                recognitionTemplateIds = Data.GroupContent[Data.GroupId].RecognitionTemplateIds,
                recognition,
                url,
                getNumericBirthDayFormat = function (datetime) {
                    var month = new Date(datetime).getMonth() + 1,
                        date = new Date(datetime).getDate(),
                        strMon = month <= 9 ? '0' + month : month,
                        strDate = date <= 9 ? '0' + date : date;
                    return " - " + strMon + "/" + strDate;
                };

            recognition = recapTypeRecognitions.find(function (recognition) {
                return recognitionTemplateIds.Birthday.indexOf(recognition.Template.hgId) !== -1 && recognition.RecipientMember.UserId === member.UserId;
            });

            if (recognition) {
                url = [config.protocol, config.baseUrl, '#/Recognize/Iso/', recognition.BatchId].join('') + '?gid=' + Data.GroupId;
            } else {
                url = [config.protocol, config.baseUrl, '#/Company/Filter/All'].join('') + '?gid=' + Data.GroupId;
            }

            return htmlHelper.replaceTokens(RecapHtmlTemplateEnums.BirthdayRow, {
                RecUrl: url,
                BirthdaySummary: member.FullName + getNumericBirthDayFormat(member.Birthdate)
            });
        },
        truncateAnniversariesBirthdays = function (members, relevancyMap) {
            var isAll = !Object.keys(relevancyMap).length,
                relevants,
                nonRelevant;
            if (isAll) {
                return members.slice(0, ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT);
            }
            relevants = members.filter(function (member) {
                return !!relevancyMap[member.hgId];
            });
            if (relevants.length >= ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT) {
                return relevants.slice(0, ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT);
            }
            nonRelevant = members.filter(function (member) {
                return !relevancyMap[member.hgId];
            });
            return relevants.concat(nonRelevant.slice(0, ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT - relevants.length));
        },
        sortByStartDateDesc = function (member1, member2) {
            return member1.StartingDate < member2.StartingDate ? -1 : 1;
        },
        sortByBirthdayAsc = function (member1, member2) {
            var birthdayObj1 = new Date(member1.Birthdate),
                birthdayObj2 = new Date(member2.Birthdate),
                birthday1 = new Date(1980, 1, 1, birthdayObj1.getMonth(), birthdayObj1.getDate()),
                birthday2 = new Date(1980, 1, 1, birthdayObj2.getMonth(), birthdayObj2.getDate());
            return birthday1 < birthday2 ? -1 : 1;
        },
        buildDailyAnniversariesAndBirthdayHtml = function (params) {
            var html = '',
                relevancyMap = params.Data.RelevancyMap || {},
                isAll = !Object.keys(relevancyMap).length,
                todayAnniversary = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Today, relevancyMap),
                tomorrowAnniversary = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Tomorrow, relevancyMap),
                comingWeekendAnniversary = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.ComingWeekend, relevancyMap),
                pastWeekendAnniversary = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.PastWeekend, relevancyMap),
                todayBirthday = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Today.filter(function (user) {
                    return user.GroupId === params.Member.GroupId;
                }), relevancyMap),
                tomorrowBirthday = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Tomorrow.filter(function (user) {
                    return user.GroupId === params.Member.GroupId;
                }), relevancyMap),
                comingWeekendBirthday = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.ComingWeekend.filter(function (user) {
                    return user.GroupId === params.Member.GroupId;
                }), relevancyMap),
                pastWeekendBirthday = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.PastWeekend.filter(function (user) {
                    return user.GroupId === params.Member.GroupId && !user.SuppressBirthday && (isAll || relevancyMap[user.hgId]);
                }), relevancyMap),
                anniversaryCount = todayAnniversary.length + tomorrowAnniversary.length + comingWeekendAnniversary.length + pastWeekendAnniversary.length,
                birthdayCount = todayBirthday.length + tomorrowBirthday.length + comingWeekendBirthday.length  + pastWeekendBirthday.length,
                periods = ['Today', 'Tomorrow', 'ComingWeekend', 'PastWeekend'];

            todayAnniversary = todayAnniversary.sort(sortByStartDateDesc);
            tomorrowAnniversary = tomorrowAnniversary.sort(sortByStartDateDesc);
            comingWeekendAnniversary = comingWeekendAnniversary.sort(sortByStartDateDesc);
            pastWeekendAnniversary = pastWeekendAnniversary.sort(sortByStartDateDesc);
            comingWeekendBirthday = comingWeekendBirthday.sort(sortByBirthdayAsc);
            pastWeekendBirthday = pastWeekendBirthday.sort(sortByBirthdayAsc);

            if (anniversaryCount) {
                if (todayAnniversary.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TodaysAnniversary, {
                        HeaderTodaysAnniversary: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.ta'),
                        TodaysAnniversaries: todayAnniversary.slice(0, ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildAnniversaryRow(params, member, 'Daily', periods[0]);
                        }).join('')
                    });
                    if (params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Today.length > ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.sma', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Today.length
                        });
                    }
                }
                if (params.Data.Mode !== 'Friday' && tomorrowAnniversary.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TomorrowsAnniversary, {
                        HeaderTomorrowsAnniversary: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.toa'),
                        TomorrowsAnniversaries: tomorrowAnniversary.slice(0, ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildAnniversaryRow(params, member, 'Daily', periods[1]);
                        }).join('')
                    });
                    if (params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Tomorrow.length > ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.sma', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Tomorrow.length
                        });
                    }
                }
                if (comingWeekendAnniversary.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.ComingWeekendAnniversary, {
                        HeaderComingWeekendAnniversary: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.twka'),
                        ComingWeekendAnniversaries: comingWeekendAnniversary.slice(0, ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildAnniversaryRow(params, member, 'Daily', periods[2]);
                        }).join('')
                    });
                    if (params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.ComingWeekend.length > ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.sma', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.ComingWeekend.length
                        });
                    }
                }
                if (pastWeekendAnniversary.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.PastWeekendAnniversary, {
                        HeaderPastWeekendAnniversary: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.pwka'),
                        PastWeekendAnniversaries: pastWeekendAnniversary.slice(0, ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildAnniversaryRow(params, member, 'Daily', periods[3]);
                        }).join('')
                    });
                    if (params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.PastWeekend.length > ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.sma', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.PastWeekend.length
                        });
                    }
                }
            } else {
                html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TodaysAnniversary, {
                    HeaderTodaysAnniversary: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.na'),
                    TodaysAnniversaries: ''
                });
            }
            if (birthdayCount) {
                if (todayBirthday.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TodayBirthday, {
                        HeaderTodayBirthday: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.tb'),
                        TodayBirthdays: todayBirthday.slice(0, ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildBirthdayRow(params, member, 'Daily', periods[0]);
                        }).join('')
                    });
                    if (params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Today.length > ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.smb', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Today.length
                        });
                    }
                }
                if (params.Data.Mode !== 'Friday' && tomorrowBirthday.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TomorrowBirthday, {
                        HeaderTomorrowBirthday: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.tob'),
                        TomorrowBirthdays: tomorrowBirthday.slice(0, ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildBirthdayRow(params, member, 'Daily', periods[1]);
                        }).join('')
                    });
                    if (params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Tomorrow.length > ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.smb', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Tomorrow.length
                        });
                    }
                }
                if (comingWeekendBirthday.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.ComingWeekendBirthday, {
                        HeaderComingWeekendBirthday: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.twkb'),
                        ComingWeekendBirthdays: comingWeekendBirthday.slice(0, ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildBirthdayRow(params, member, 'Daily', periods[2]);
                        }).join('')
                    });
                    if (comingWeekendBirthday.length > ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.smb', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.ComingWeekend.length
                        });
                    }
                }
                if (pastWeekendBirthday.length) {
                    html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.PastWeekendBirthday, {
                        HeaderPastWeekendBirthday: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.pwb'),
                        PastWeekendBirthdays: pastWeekendBirthday.slice(0, ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT).map(function (member) {
                            return buildBirthdayRow(params, member, 'Daily', periods[3]);
                        }).join('')
                    });
                    if (params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.PastWeekend.length > ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT) {
                        html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.smb', {
                            optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                            total: params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.PastWeekend.length
                        });
                    }
                }
            } else {
                html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.TodayBirthday, {
                    HeaderTodayBirthday: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.nb'),
                    TodayBirthdays: ''
                });
            }
            return html;
        },
        buildAnniversariesAndBirthdayHtml = function (params) {
            var html = '',
                relevancyMap = params.Data.RelevancyMap || {},
                pastWeekAnniversary = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.PastWeek, relevancyMap),
                comingWeekAnniversary = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.ComingWeek, relevancyMap),
                pastWeekBirthday = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.PastWeek.filter(function (member) {
                    return member.GroupId === params.Member.GroupId;
                }), relevancyMap),
                comingWeekBirthday = truncateAnniversariesBirthdays(params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.ComingWeek.filter(function (member) {
                    return member.GroupId === params.Member.GroupId;
                }), relevancyMap);
            pastWeekAnniversary = pastWeekAnniversary.sort(sortByStartDateDesc);
            comingWeekAnniversary = comingWeekAnniversary.sort(sortByStartDateDesc);
            pastWeekBirthday = pastWeekBirthday.sort(sortByBirthdayAsc);
            comingWeekBirthday = comingWeekBirthday.sort(sortByBirthdayAsc);
            if (pastWeekAnniversary.length) {
                html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.PastWeekAnniversary, {
                    HeaderPastWeekAnniversary: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.lwa'),
                    PastWeekAnniversaries: pastWeekAnniversary.map(function (member) {
                        return buildAnniversaryRow(params, member);
                    }).join('')
                });
                if (params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.PastWeek.length > ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT) {
                    html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.sma', {
                        optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                        total: params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.PastWeek.length
                    });
                }
            }
            if (comingWeekAnniversary.length) {
                html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.ComingAnniversary, {
                    HeaderComingWeekAnniversary: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.twa'),
                    ComingWeekAnniversaries: comingWeekAnniversary.map(function (member) {
                        return buildAnniversaryRow(params, member);
                    }).join('')
                });
                if (params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.ComingWeek.length > ConstantEnums.ANNIVERSARY_ANNOUNCEMENT_LIMIT) {
                    html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.sma', {
                        optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                        total: params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.ComingWeek.length
                    });
                }
            }
            if (pastWeekBirthday.length) {
                html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.PastWeekBirthday, {
                    HeaderPastWeekBirthday: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.lwb'),
                    PastWeekBirthdays: pastWeekBirthday.map(function (user) {
                        return buildBirthdayRow(params, user);
                    }).join('')
                });
                if (params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.PastWeek.length > ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT) {
                    html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.smb', {
                        optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                        total: params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.PastWeek.length
                    });
                }
            }
            if (comingWeekBirthday.length) {
                html += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.ComingBirthday, {
                    HeaderComingWeekBirthday: i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.twb'),
                    ComingWeekBirthdays: comingWeekBirthday.map(function (user) {
                        return buildBirthdayRow(params, user);
                    }).join('')
                });
                if (params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.ComingWeek.length > ConstantEnums.BIRTHDAY_ANNOUNCEMENT_LIMIT) {
                    html += i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.smb', {
                        optout_url: config.protocol + config.baseUrl + '#/Company/Filter/All?gid=' + params.Data.GroupId,
                        total: params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.ComingWeek.length
                    });
                }
            }
            return html;
        },
        loadPendingSurvey = function (params, callback) {
            if (!params.LoadSurvey) {
                return callback();
            }
            EntityCache.SurveyAnswer.findOne({
                Type: SurveyEnums.Type.Pulse,
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                Status: SurveyEnums.SurveyAnswerStatus.Pending,
                ExpireDate: {$gte: Date.now()}
            }, function (error, surveyAnswer) {
                if (error || !surveyAnswer) {
                    return callback(error);
                }
                EntityCache.Survey.findOne({
                    hgId: surveyAnswer.SurveyId,
                    Status: SurveyEnums.Status.Active
                }, function (error, survey) {
                    if (error || !survey) {
                        return callback(error);
                    }
                    callback(null, {
                        SurveyId: surveyAnswer.SurveyId,
                        ExpireDate: surveyAnswer.ExpireDate,
                        QuestionText: surveyAnswer.QandA[0].QuestionText
                    });
                });
            });
        },
        getLastUpdated = function (days) {
            var value;
            if (days === 0) {
                value = 'Today';
            } else if (days === 1) {
                value = 'Yesterday';
            } else {
                value = days + ' days ago';
            }
            return value;
        },
        buildEmployeeGoalRowHtml = function (memberId, groupId, data) {
            var reportName,
                trackStatus,
                rowIndex,
                managerDirectReports = data.ManagerIndex[memberId],
                directReportTracksHgIds = managerDirectReports.map(function (item) {
                    return item.hgId;
                }),
                directReportTracks = data.Tracks.filter(function (item) {
                    return directReportTracksHgIds.indexOf(item._id) > -1;
                }),
                getEmployeeName = function (hgId) {
                    var filterResult = managerDirectReports.filter(function (item) {
                        return item.hgId === hgId;
                    })[0];
                    return filterResult ? filterResult.FullName : '';
                },
                result = [];
            directReportTracks = directReportTracks.sort(function (a, b) {
                return a.GoalScore > b.GoalScore ? -1 : 1;
            });
            directReportTracks.forEach(function (item) {
                reportName = getEmployeeName(item._id);
                rowIndex = 0;
                item.rows.forEach(function (item) {
                    if (rowIndex === 0) {
                        trackStatus = htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalNameRow, {
                            EmployeeName: reportName
                        });
                        rowIndex += 1;
                    } else {
                        trackStatus = RecapHtmlTemplateEnums.EmployeeGoalEmptyTD;
                    }
                    trackStatus += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusTitleTD, {
                        EmployeeGoalStatusTitleTD: item.Title,
                        GoalUrl: [config.protocol, config.baseUrl, '#/Track/Iso/', item.hgId, '?gid=', groupId].join('')
                    });
                    trackStatus += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusLastUpdatedTD, {
                        EmployeeGoalStatusLastUpdatedTD: getLastUpdated(item.LastUpdatedDate)
                    });
                    trackStatus += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusNotificationPrefTD, {
                        EmployeeGoalStatusNotificationPrefTD: item.NotificationFrequency
                    });
                    trackStatus += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusOnTargetTD, {
                        EmployeeGoalStatusOnTargetTD: item.OnTarget,
                        EmployeeGoalOnTarget: item.OnTarget
                    });
                    trackStatus += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusPercentCompletionTD, {
                        EmployeeGoalStatusPercentCompletionTD: item.PercentAchieved
                    });
                    result.push(htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusRow, {
                        EmployeeGoalStatusRow: trackStatus
                    }));
                });
            });
            return result.join('');
        },
        buildEmployeeOKRRowHtml = function (groupId, goals) {
            var result = [];

            goals.forEach(function (goal) {
                //employee name column
                var goalStatusRow = htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalNameRow, {
                    EmployeeName: goal.FullName
                });
                //goal name column
                goalStatusRow += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusTitleTD, {
                    EmployeeGoalStatusTitleTD: goal.Name,
                    GoalUrl: [config.protocol, config.baseUrl, '#/Profile/GoalDetails/View/', goal.MemberId, '/', goal.GoalId, '?gid=', groupId].join('')
                });
                //last updated column
                goalStatusRow += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusLastUpdatedTD, {
                    EmployeeGoalStatusLastUpdatedTD: getLastUpdated(DateHelper.getDaysBetween(new Date(goal.ModifiedDate), new Date()))
                });
                //update frequency column
                goalStatusRow += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusNotificationPrefTD, {
                    EmployeeGoalStatusNotificationPrefTD: goal.CheckInFrequency
                });
                //current column
                goalStatusRow += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusOnTargetTD, {
                    EmployeeGoalStatusOnTargetTD: goal.UpToDate,
                    EmployeeGoalOnTarget: goal.UpToDate ? 'Yes' : 'No'
                });
                //percent completed column
                goalStatusRow += htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusPercentCompletionTD, {
                    EmployeeGoalStatusPercentCompletionTD: Math.round(goal.PercentCompletion) + '%'
                });

                result.push(htmlHelper.replaceTokens(RecapHtmlTemplateEnums.EmployeeGoalStatusRow, {
                    EmployeeGoalStatusRow: goalStatusRow
                }));
            });
            return result.join('');
        },
        loadTracks = function (params, callback) {
            if (params.HideTrackInRecap) {
                return callback(null, {
                    TracksNeedApproval: [],
                    TracksInProgress: []
                });
            }
            EntityCache.CareerTrack.find({
                'AssignedMember.hgId': params.Data.MemberId,
                Status: {
                    $in : [
                        Enums.TrackStatus.Assigned,
                        Enums.TrackStatus.Partial]
                }
            }, function (error, tracksInProgress) {
                if (error) {
                    return callback(null, {
                        TracksNeedApproval: [],
                        TracksInProgress: []
                    });
                }
                EntityCache.CareerTrack.find({
                    'CreatorMember.hgId': params.Data.MemberId,
                    'CareerTrackTemplate.Goal.Status': {
                        $in: [
                            Enums.MilestoneStatus.NotStarted,
                            Enums.MilestoneStatus.InProgress,
                            Enums.MilestoneStatus.OverDue,
                            Enums.MilestoneStatus.RequestComplete]
                    },
                    'CareerTrackTemplate.MileStones.Status': Enums.MilestoneStatus.RequestComplete
                }, function (error, tracksNeedApproval) {
                    if (error) {
                        return callback(null, {
                            TracksNeedApproval: [],
                            TracksInProgress: tracksInProgress
                        });
                    }
                    return callback(null, {
                        TracksNeedApproval: tracksNeedApproval,
                        TracksInProgress: tracksInProgress
                    });
                });
            });
        };

    this.MemberDailyRecap = function (params, callback) {
        var mergeField = {},
            notificationQueueItem = params.NotificationQueueItem,
            memberId = params.Data.MemberId,
            member = params.Data.CurMember,
            group,
            hideRecognitionInRecap = false,
            hideTrackInRecap = false,
            interval,
            relevancyMap = params.Data.RelevancyMap || {},
            isAll = !Object.keys(relevancyMap).length,
            featureFilter = function (m) {
                return m.Name === 'Permissions' && m.Value.indexOf('recognizeTabs.giveRecognition') > -1;
            },
            featureFilterTrack = function (m) {
                return m.Name === 'Permissions' && m.Value.indexOf('trackTabs') > -1;
            },
            isEmailWorthSending = function () {
                var birthdayAvailable = false,
                    anniversariesAvailable = false,
                    recognitionsAvailable = false,
                    sendEmail = false,
                    tomorrowAnniversary = params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Tomorrow.filter(getFilter(relevancyMap)),
                    todayAnniversary = params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.Today.filter(getFilter(relevancyMap)),
                    comingWeekendAnniversary = params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.ComingWeekend.filter(getFilter(relevancyMap)),
                    pastWeekendAnniversary = params.Data.GroupContent[params.Data.GroupId].AnniversaryMembers.PastWeekend.filter(getFilter(relevancyMap)),
                    todayBirthday = params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Today.filter(function (user) {
                        return user.GroupId === params.Member.GroupId && !user.SuppressBirthday && (isAll || relevancyMap[user.hgId]);
                    }),
                    tomorrowBirthday = params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.Tomorrow.filter(function (user) {
                        return user.GroupId === params.Member.GroupId && !user.SuppressBirthday && (isAll || relevancyMap[user.hgId]);
                    }),
                    comingWeekendBirthday = params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.ComingWeekend.filter(function (user) {
                        return user.GroupId === params.Member.GroupId && !user.SuppressBirthday && (isAll || relevancyMap[user.hgId]);
                    }),
                    pastWeekendBirthday = params.Data.GroupContent[params.Data.GroupId].BirthdayUsers.PastWeekend.filter(function (user) {
                        return user.GroupId === params.Member.GroupId && !user.SuppressBirthday && (isAll || relevancyMap[user.hgId]);
                    }),
                    yesterdayRecognitions = params.Data.GroupContent[params.Data.GroupId].Recognitions.Yesterday,
                    pastWeekendRecognitions = params.Data.GroupContent[params.Data.GroupId].Recognitions.PastWeekend;
                if (params.Data.Mode === 'Regular') {
                    recognitionsAvailable = !hideRecognitionInRecap && yesterdayRecognitions.length;
                } else if (params.Data.Mode === 'Monday') {
                    recognitionsAvailable = !hideRecognitionInRecap && pastWeekendRecognitions.length;
                    anniversariesAvailable = !!pastWeekendAnniversary.length;
                    birthdayAvailable = !!pastWeekendBirthday.length;
                } else if (params.Data.Mode === 'Friday') {
                    recognitionsAvailable = !hideRecognitionInRecap && yesterdayRecognitions.length;
                    anniversariesAvailable = !!comingWeekendAnniversary.length;
                    birthdayAvailable = !!comingWeekendBirthday.length;
                }
                sendEmail |= !!tomorrowAnniversary.length;
                sendEmail |= !!todayAnniversary.length;
                sendEmail |= !!todayBirthday.length;
                sendEmail |= !!tomorrowBirthday.length;
                sendEmail |= anniversariesAvailable;
                sendEmail |= birthdayAvailable;
                sendEmail |= recognitionsAvailable;
                sendEmail |= (!hideTrackInRecap && params.TracksNeedApproval && params.TracksNeedApproval.length);
                sendEmail |= (!hideTrackInRecap && params.TracksInProgress && params.TracksInProgress.length);
                return sendEmail;
            },
            programName,
            disabledFeatures,
            d,
            dlen;
        interval = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.dare');
        mergeField.interval = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.rec', {
            interval: interval
        });
        mergeField.time_period = DateHelper.formatDateStringFromTimestamp(new time.Date());
        params.Member = member;
        group = params.Data.GroupContent[params.Data.GroupId].Group;
        if (!group) {
            return callback('Can not find group');
        }
        params.Group = group;
        programName = group.ProgramName || group.GroupName;
        notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.cya', {
            program_name: programName
        });
        mergeField.teaser = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.act', {
            interval: interval,
            company: programName
        });
        disabledFeatures = group.Preference.FeatureFlags.filter(function (featureFlag) {
            return featureFlag.FeatureName === FeatureFlagEnums.DisableFeatureByRole.Text && featureFlag.FeatureEnabled;
        });
        for (d = 0, dlen = disabledFeatures.length; d < dlen; d += 1) {
            if (disabledFeatures[d].FeatureMeta.some(featureFilter)) {
                hideRecognitionInRecap = true;
            }
            if (disabledFeatures[d].FeatureMeta.some(featureFilterTrack)) {
                hideTrackInRecap = true;
            }
        }
        if (!hideTrackInRecap) {
            if (group.Preference.FeatureFlags.some(function (featureFlag) {
                    return featureFlag.FeatureName === FeatureFlagEnums.DisableTracks && featureFlag.FeatureEnabled;
                })) {
                hideTrackInRecap = true;
            }
        }
        params.HideRecognitionInRecap = hideRecognitionInRecap;
        params.HideTrackInRecap = hideTrackInRecap;
        loadTracks(params, function (error, data) {
            if (error) {
                return callback(error);
            }
            params.TracksNeedApproval = data.TracksNeedApproval;
            params.TracksInProgress = data.TracksInProgress;
            loadPendingSurvey({
                MemberId: memberId,
                GroupId: member.GroupId,
                LoadSurvey: group.Preference.FeatureFlags.some(function (featureFlag) {
                    return featureFlag.FeatureName === FeatureFlagEnums.EnablePulseSurvey && featureFlag.FeatureEnabled;
                })
            }, function (error, surveyAnswer) {
                if (error) {
                    return callback(error);
                }
                if (!error && surveyAnswer) {
                    params.PendingSurvey = surveyAnswer;
                }
                mergeField.worth_sending = isEmailWorthSending();
                mergeField.email_body = htmlHelper.replaceTokens(RecapHtmlTemplateEnums.CSS + RecapHtmlTemplateEnums.WeeklyRecTracksAnnTable, {
                    RecognitionsAndTracksHtml: buildDailyRecognitionsAndTracksHtml(params),
                    AnniversariesAndBirthdays: buildDailyAnniversariesAndBirthdayHtml(params)
                });
                notificationQueueItem.MergeFields = mergeField;
                callback(null, {
                    NotificationQueueItem: notificationQueueItem,
                    Data: params.Data,
                    NotificationEvent: params.NotificationEvent,
                    DispatchOption: params.DispatchOption,
                    CompleteCallback: params.CompleteCallback
                });
            });
        });
    };

    this.MemberWeeklyRecap = function (params, callback) {
        var mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem,
            memberId = params.Data.MemberId,
            member = params.Data.CurMember,
            group,
            interval,
            programName,
            disabledFeatures,
            d,
            dlen,
            featureFilter = function (m) {
                return m.Name === 'Permissions' && m.Value.indexOf('recognizeTabs.giveRecognition') > -1;
            },
            featureFilterTrack = function (m) {
                return m.Name === 'Permissions' && m.Value.indexOf('trackTabs') > -1;
            },
            hideRecognitionInRecap = false,
            hideTrackInRecap = false,
            getWeeklyTimePeriod = function () {
                var endDate = new time.Date(),
                    startDate = new time.Date(endDate - (7 * 24 * 60 * 60 * 1000)),
                    str = startDate.getMonth() + 1 + '/' + startDate.getDate() + '/' + startDate.getFullYear();
                str += '&nbsp;&#8203;~&#8203;&nbsp;' + (endDate.getMonth() + 1) + '/' + endDate.getDate() + '/' + endDate.getFullYear();
                return str;
            };
        interval = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.wkre');
        mergeField.interval = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.rec', {
            interval: interval
        });
        mergeField.time_period = getWeeklyTimePeriod();
        params.Member = member;
        group = params.Data.GroupContent[params.Data.GroupId].Group;
        if (!group) {
            return callback('Can not find group');
        }
        programName = group.ProgramName || group.GroupName;
        params.Group = group;
        notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.cya', {
            program_name: programName
        });
        mergeField.teaser = i18nHelper.translate(params.Data.i18n, 'eml.RecapBuilder.act', {
            company: programName,
            interval: interval
        });
        disabledFeatures = group.Preference.FeatureFlags.filter(function (featureFlag) {
            return featureFlag.FeatureName === FeatureFlagEnums.DisableFeatureByRole.Text && featureFlag.FeatureEnabled;
        });
        for (d = 0, dlen = disabledFeatures.length; d < dlen; d += 1) {
            if (disabledFeatures[d].FeatureMeta.some(featureFilter)) {
                hideRecognitionInRecap = true;
            }
            if (disabledFeatures[d].FeatureMeta.some(featureFilterTrack)) {
                hideTrackInRecap = true;
            }
        }
        if (!hideTrackInRecap) {
            if (group.Preference.FeatureFlags.some(function (featureFlag) {
                    return featureFlag.FeatureName === FeatureFlagEnums.DisableTracks && featureFlag.FeatureEnabled;
                })) {
                hideTrackInRecap = true;
            }
        }
        params.HideRecognitionInRecap = hideRecognitionInRecap;
        params.HideTrackInRecap = hideTrackInRecap;
        loadTracks(params, function (error, data) {
            if (error) {
                return callback(error);
            }
            params.TracksNeedApproval = data.TracksNeedApproval;
            params.TracksInProgress = data.TracksInProgress;
            loadPendingSurvey({
                MemberId: memberId,
                GroupId: member.GroupId,
                LoadSurvey:  group.Preference.FeatureFlags.some(function (featureFlag) {
                    return featureFlag.FeatureName === FeatureFlagEnums.EnablePulseSurvey && featureFlag.FeatureEnabled;
                })
            }, function (error, surveyAnswer) {
                if (!error && surveyAnswer) {
                    params.PendingSurvey = surveyAnswer;
                }
                mergeField.email_body = htmlHelper.replaceTokens(RecapHtmlTemplateEnums.CSS + RecapHtmlTemplateEnums.WeeklyRecTracksAnnTable, {
                    RecognitionsAndTracksHtml: buildWeeklyRecognitionsAndTracksHtml(params),
                    AnniversariesAndBirthdays: buildAnniversariesAndBirthdayHtml(params)
                });
                notificationQueueItem.MergeFields = mergeField;
                callback(null, {
                    NotificationQueueItem: notificationQueueItem,
                    Data: params.Data,
                    NotificationEvent: params.NotificationEvent,
                    DispatchOption: params.DispatchOption,
                    CompleteCallback: params.CompleteCallback
                });
            });
        });
    };

    this.MemberGoalStatus = function (params, callback) {
        var memberId = params.Data.MemberId;
        EntityCache.Member.findOne({hgId: memberId}, function (err, member) {
            if (err || !member) {
                return callback('server.hge.grp.elm');
            }
            params.NotificationQueueItem.MergeFields = {
                email_body: htmlHelper.replaceTokens(RecapHtmlTemplateEnums.CSS + RecapHtmlTemplateEnums.WeeklyEmployeeGoalStatusTable, {
                    MemberGoalsHtml: buildEmployeeGoalRowHtml(memberId, params.Data.GroupId, params.Data.GroupContent)
                }),
                manager_name: member.FullName
            };
            callback(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption,
                CompleteCallback : params.CompleteCallback
            });
        });
    };

    this.ApproverOKRStatus = function (params, callback) {
        params.NotificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.ApproverOKRStatus.sub');
        params.NotificationQueueItem.MergeFields = {
            teaser: i18nHelper.translate(params.Data.i18n, 'eml.ApproverOKRStatus.tea'),
            body_txt: i18nHelper.translate(params.Data.i18n, 'eml.ApproverOKRStatus.bod', {
                manager_name: params.Data.Approver.FullName,
                email_body: htmlHelper.replaceTokens(RecapHtmlTemplateEnums.CSS + RecapHtmlTemplateEnums.WeeklyEmployeeGoalStatusTable, {
                    MemberGoalsHtml: buildEmployeeOKRRowHtml(params.Data.GroupId, params.Data.Goals)
                })
            })
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
};

module.exports = RecapBuilder;
