/*jslint node:true es5:true*/
var SurveyBuilder = function () {
    "use strict";
    var config = require('../../../configurations/config'),
        htmlHelper = require('../../../helpers/htmlHelper.js'),
        i18nHelper = require('../../../helpers/i18nHelper.js'),
        SurveyEnums = require('../../../enums/SurveyEnums.js'),
        SurveyTemplates = {
            PulseSurveyMoodOverdue: require('../../../../static/templates/server/survey/pulse-survey-overdue-mood-answer.html'),
            PulseSurveyMultipleChoiceOverdue: require('../../../../static/templates/server/survey/pulse-survey-overdue-multiplechoice-answer.html')
        };
    this.SurveyDelivered = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            full_name: params.Data.FullName,
            survey_url: [config.protocol, config.baseUrl].join('')
        };
        callback(null, {NotificationQueueItem: params.NotificationQueueItem, Data: params.Data, NotificationEvent: params.NotificationEvent, DispatchOption: params.DispatchOption});
    };
    this.SurveyCompleted = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            admin_name: params.Data.FullName,
            survey_url: [config.protocol, config.baseUrl, '#/Admin/Survey/Benchmark/Results'].join(''),
            survey_pdf_url: [config.protocol, config.baseUrl, 'svc/Survey/LoadSurveyPDF?surveyResultId=', params.Data.SurveyResultId].join(''),
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.SurveyDueSoon = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            employee_name: params.Data.FullName,
            due_date: params.Data.DueDate,
            survey_url: [config.protocol, config.baseUrl].join('')
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
    this.PulseSurveyOverdue = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            AnswerFactory = {},
            mergeField = {};
        AnswerFactory[SurveyEnums.AnswerTypes.Mood] = function getMoodAnswerType() {
            var text = [];
            params.Data.Question.AnswerSelectors.forEach(function (item, index) {
                text.push(htmlHelper.replaceTokens(SurveyTemplates.PulseSurveyMoodOverdue, {
                    url_img: (index - 2) + '.png',
                    url: [config.protocol, config.baseUrl, '#/Survey/Answer/', params.Data.SurveyAnswerId, '/', item.Value].join('')
                }));
            });
            return '<p align="center">' + text.join('') + '</p>';
        };
        AnswerFactory[SurveyEnums.AnswerTypes.MultipleChoice] = function getMCAnswerType() {
            var text = [];
            params.Data.Question.AnswerSelectors.forEach(function (item) {
                text.push(htmlHelper.replaceTokens(SurveyTemplates.PulseSurveyMultipleChoiceOverdue, {
                    text: item.Text,
                    url: [config.protocol, config.baseUrl, '#/Survey/Answer/', params.Data.SurveyAnswerId, '/', item.Value].join('')
                }));
            });
            return text.join('');
        };
        AnswerFactory[SurveyEnums.AnswerTypes.Text] = function getTextAnswerType() {
            return htmlHelper.replaceTokens(SurveyTemplates.PulseSurveyMultipleChoiceOverdue, {
                url: [config.protocol, config.baseUrl].join(''),
                text: i18nHelper.translate(params.Data.i18n.replace("/email", ""), 'services.int.sur.tdd')
            });
        };
        mergeField.first_name = params.Data.FullName;
        notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.PulseSurveyOverdue.sub');
        mergeField.teaser = i18nHelper.translate(params.Data.i18n, 'eml.PulseSurveyOverdue.tea');
        mergeField.body_txt = i18nHelper.translate(params.Data.i18n, 'eml.PulseSurveyOverdue.body_txt', {
            question: params.Data.Question.QuestionText,
            responseType: params.Data.Question.AnswerType === SurveyEnums.AnswerTypes.Text ? i18nHelper.translate(params.Data.i18n.replace("/email", ""), 'services.int.sur.tde') : i18nHelper.translate(params.Data.i18n.replace("/email", ""), 'services.int.sur.mde'),
            answerType: AnswerFactory[params.Data.Question.AnswerType]()
        });
        notificationQueueItem.MergeFields = mergeField;
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
};

module.exports = SurveyBuilder;
