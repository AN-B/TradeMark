/*jslint node:true es5:true*/
var TrackBuilder = function () {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        EntityEnums = require('../../../enums/EntityEnums.js'),
        TrackCheckInHtmlTemplateEnums = require('../../../enums/TrackCheckInHtmlTemplateEnums.js'),
        NotificationsEnums = require('../../../enums/NotificationsEnums.js'),
        RecurrenceEnums = require('../../../enums/RecurrenceEnums.js'),
        config = require('../../../configurations/config'),
        htmlHelper = require('../../../helpers/htmlHelper.js');

    function buildTrackCheckInRow(track) {
        var rowHtml,
            url = config.protocol + config.baseUrl + '#/Track/Iso/' + track.hgId,
            imgSrc,
            milestoneIds = [],
            curTime = Date.now(),
            overdueMilestones = 0,
            overdueMessage = '',
            LastUpdateInfo = '',
            LastUpdateDate = new Date(track.ModifiedDate),
            lastupdateSummary = (LastUpdateDate.getMonth() + 1) + '/' + LastUpdateDate.getDate() + '/' + LastUpdateDate.getFullYear(),
            i,
            nextMilestoneduedate,
            strNextMilestoneduedate,
            nextMilestonedueMessage = '',
            numDaysSinceLastUpdate,
            tempDate,
            requiredUpdateDayNumber,
            milestoneOverdueDate;
        numDaysSinceLastUpdate = Math.floor((curTime - track.ModifiedDate) / (24 * 3600 * 1000));
        if (config.s3store.s3bucket === '') {
            imgSrc = 'http:' + config.baseUrl + config.s3store.imageStore[0] + '/' + config.filepath.RecognitionTemplateRoot + track.CareerTrackTemplate.Goal.RecognitionTemplate.FriendlyGroupId + '/' + track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId + '.svg';
        } else {
            imgSrc = 'https:' + config.baseUrl + 'svgx/' + config.filepath.RecognitionTemplateRoot + track.CareerTrackTemplate.Goal.RecognitionTemplate.FriendlyGroupId + '/' + track.CareerTrackTemplate.Goal.RecognitionTemplate.hgId + '.svg';
        }
        rowHtml = htmlHelper.replaceTokens(TrackCheckInHtmlTemplateEnums.TrackInProgressRow, {
            LastUpdate: lastupdateSummary,
            TrackUrl: url,
            TrackImageSrc: imgSrc,
            TrackTitle: track.CareerTrackTemplate.Title
        });
        for (i = 0; i < track.CareerTrackTemplate.MileStones.length; i += 1) {
            milestoneIds.push(track.CareerTrackTemplate.MileStones[i].hgId);
            if (track.CareerTrackTemplate.MileStones[i].TargetDate) {
                milestoneOverdueDate = track.CareerTrackTemplate.MileStones[i].TargetDate + 24 * 3600 * 1000;//1 day later
                if (!nextMilestoneduedate || nextMilestoneduedate > track.CareerTrackTemplate.MileStones[i].TargetDate) {
                    nextMilestoneduedate = track.CareerTrackTemplate.MileStones[i].TargetDate;
                }
                if (curTime > milestoneOverdueDate && track.CareerTrackTemplate.MileStones[i].PercentAchieved !== 100 && [EntityEnums.MilestoneStatus.NotStarted, EntityEnums.MilestoneStatus.InProgress, EntityEnums.MilestoneStatus.OverDue].indexOf(track.CareerTrackTemplate.MileStones[i].Status) > -1) {
                    overdueMilestones += 1;
                }
            }
        }
        if (overdueMilestones > 0) {
            if (overdueMilestones === 1) {
                overdueMessage = '1 milestone overdue';
            } else {
                overdueMessage = overdueMilestones + ' milestones overdue';
            }
        }
        requiredUpdateDayNumber = NotificationsEnums.FrequencyInterval[track.NotificationFrequency] || NotificationsEnums.FrequencyInterval.Weekly;
        if (numDaysSinceLastUpdate >= requiredUpdateDayNumber) {
            rowHtml = htmlHelper.replaceTokens(rowHtml, {
                DayOrUpdateNumber: numDaysSinceLastUpdate,
                DaysOrUpdateMessage: 'Days since last update',
                BorderColor: '#E74C3C',
                FontColor: '#E74C3C'
            });
        } else {
            rowHtml = htmlHelper.replaceTokens(rowHtml, {
                DayOrUpdateNumber: '',
                DaysOrUpdateMessage: 'Updated on schedule',
                BorderColor: '#4594d0',
                FontColor: '#4594d0'
            });
        }
        if (!overdueMessage && nextMilestoneduedate) {
            tempDate = new Date(nextMilestoneduedate);
            strNextMilestoneduedate = (tempDate.getMonth() + 1) + '/' + tempDate.getDate() + '/' + tempDate.getFullYear();
            nextMilestonedueMessage = 'Next milestone is due on <strong>' + strNextMilestoneduedate + '</strong>';
        }
        return htmlHelper.replaceTokens(rowHtml, {
            OverdueMilestoneMessage: overdueMessage,
            NextMilestoneDueInfo: nextMilestonedueMessage,
            LastUpdateInfo: LastUpdateInfo
        });
    }

    function buildTracksOfFrequencyHtml(tracks, frequency) {
        return htmlHelper.replaceTokens(TrackCheckInHtmlTemplateEnums.TracksInProgress, {
            HeaderTracksInProgress: 'These goals require <strong>' + frequency + "</strong> updates. Here's how you're doing:",
            TracksInProgressRows: tracks.map(function (track) {
                return buildTrackCheckInRow(track);
            }).join('')
        });
    }

    function buildTracksCheckInHtml(params) {
        var html = htmlHelper.replaceTokens(TrackCheckInHtmlTemplateEnums.Greeting, {
                MyFirstName: params.Member.FirstName
            }),
            trackPeriods = {},
            i,
            len = params.TracksInProgress.length,
            track;

        for (i = 0; i < len; i += 1) {
            track = params.TracksInProgress[i];
            if (trackPeriods[track.NotificationFrequency]) {
                trackPeriods[track.NotificationFrequency].push(track);
            } else {
                trackPeriods[track.NotificationFrequency] = [track];
            }
        }
        // force the build order by Weekly, Monthly, Quarterly
        [RecurrenceEnums.RecurrencePeriod.Weekly,
            RecurrenceEnums.RecurrencePeriod.Monthly,
            RecurrenceEnums.RecurrencePeriod.Quarterly].forEach(function (r) {
            if (trackPeriods[r]) {
                html += buildTracksOfFrequencyHtml(trackPeriods[r], r);
            }
        });
        return html;
    }

    this.TrackCheckIn = function (params, callback) {
        params.TracksInProgress = params.Data.Tracks;
        params.Member = params.Data.Tracks[0].AssignedMember;
        params.NotificationQueueItem.MergeFields = {
            email_body: htmlHelper.replaceTokens(TrackCheckInHtmlTemplateEnums.CSS + TrackCheckInHtmlTemplateEnums.BodyTable, {
                TracksHtml: buildTracksCheckInHtml(params)
            })
        };
        EntityCache.Group.findOne({hgId: params.Member.GroupId}, function (error, group) {
            if (error || !group) {
                return callback(error);
            }
            params.NotificationQueueItem.Subject = 'Check Your ' + (group.ProgramName || group.GroupName) + ' Goal Progress';
            callback(null, {
                NotificationQueueItem: params.NotificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption,
                CompleteCallback: params.CompleteCallback
            });
        });
    };

    this.TrackAssigned = function (params, callback) {
        var Data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            first_name: Data.Track.AssignedMember.FirstName,
            creator_name: Data.Track.CreatorMember.FullName,
            track_name: Data.Track.CareerTrackTemplate.Title,
            notes: Data.Notes,
            track_url: config.protocol + config.baseUrl + '#/Track/Iso/' + Data.Track.hgId
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.TrackCompleted = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            track_assignee: Data.track.AssignedMember.FullName,
            first_name: notificationQueueItem.RecipientList[0] ? notificationQueueItem.RecipientList[0].Name : '',
            track_name: Data.track.CareerTrackTemplate.Title,
            track_url: config.protocol + config.baseUrl + '#/Track/Iso/' + Data.track.hgId
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.TrackCompletionRequested = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            first_name: notificationQueueItem.RecipientList[0] ? notificationQueueItem.RecipientList[0].Name : '',
            track_name: Data.track.CareerTrackTemplate.Title,
            assignee_name: Data.track.AssignedMember.FullName,
            track_url: config.protocol + config.baseUrl + '#/Track/Iso/' + Data.track.hgId
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.TrackCompletionRequestApproved = function (params, callback) {
        var Data = params.Data;
        params.NotificationQueueItem.MergeFields = {
            first_name: Data.track.AssignedMember.FirstName,
            approver_name: Data.track.CreatorMember.FirstName,
            track_name: Data.track.CareerTrackTemplate.Title,
            track_url: config.protocol + config.baseUrl + '#/Track/Iso/' + Data.track.hgId
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data : Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.ContributorAdded = function (params, callback) {
        var mergeField = {},
            notificationQueueItem = params.NotificationQueueItem;


        notificationQueueItem.MergeFields = mergeField;
        params.NotificationQueueItem.MergeFields = {
            first_name: notificationQueueItem.RecipientList && notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : '',
            track_assigner: params.Data.Assigner.UserPersonal.FirstName,
            track_name: params.Data.Track.CareerTrackTemplate.Title,
            track_url: config.protocol + config.baseUrl + '/#/Track/Iso/' + params.Data.Track.hgId
        };
        params.NotificationQueueItem.Subject = "You've been added as a collaborator on " + params.Data.Track.CareerTrackTemplate.Title;
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.OverdueMilestones = function (params, callback) {
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.MilestoneApproved = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            first_name: params.Data.track.AssignedMember.FirstName,
            approver_name: params.Data.track.CreatorMember.FirstName,
            milestone_name: params.Data.completedMilestone.DisplayName,
            track_url: config.protocol + config.baseUrl + '/#/Track/Iso/' + params.Data.track.hgId
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.MilestoneCompleted = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            first_name: notificationQueueItem.RecipientList[0] ? notificationQueueItem.RecipientList[0].Name : '',
            track_assignee: Data.track.AssignedMember.FullName,
            milestone_name: Data.pendingMilestone.DisplayName,
            track_url: config.protocol + config.baseUrl + '#/Track/Iso/' + Data.track.hgId
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.TrackCommentReceived = function (params, callback) {
        var CareerTrack = EntityCache.CareerTrack,
            comment = params.Data.Comment,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;
        mergeField.commentor_name = comment.CommenterFirstName + ' ' + comment.CommenterLastName;
        mergeField.comment = comment.Comment;
        if (comment.EntityType === 'Milestone') {
            mergeField.comment_url = config.protocol + config.baseUrl + '#/Track/Iso/' + comment.EntityId;
        } else if (comment.EntityType === 'Coaching') {
            mergeField.comment_url = config.protocol + config.baseUrl + '#/Track/Iso/' + comment.EntityId + '/Coaching';
        } else if (comment.EntityType === 'Recognition') {
            mergeField.comment_url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + comment.EntityId;
        }
        if (comment.EntityType === 'Milestone' || comment.EntityType === 'Coaching') {
            CareerTrack.findOne({$or: [{'CareerTrackTemplate.Goal.hgId': comment.EntityId}, {'CareerTrackTemplate.MileStones.hgId': comment.EntityId}]}, function (err, track) {
                mergeField.entity_type = track.CareerTrackTemplate.Title + ' track';
                mergeField.track_name = track.CareerTrackTemplate.Title;
                notificationQueueItem.MergeFields = mergeField;
                callback(null, {
                    NotificationQueueItem: notificationQueueItem,
                    Data : params.Data,
                    NotificationEvent : params.NotificationEvent,
                    DispatchOption : params.DispatchOption
                });
            });
        } else {
            mergeField.entity_type = 'recognition';
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption
            });
        }
    };
};

module.exports = TrackBuilder;