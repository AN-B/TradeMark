/*jslint node:true es5:true*/
var ProductBuilder = function (EventEmitterCache) {
    "use strict";
    var EventData = require('../../../common/EventData'),
        EntityCache = require('../../../framework/EntityCache'),
        config = require('../../../configurations/config');

    this.ProductIdeaSuggested = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            user_full_name : params.Data.SubmitterName,
            new_product_suggestion : params.Data.ProductName,
            new_product_link : config.protocol + config.baseUrl + '#/Admin/Points/Products',
            program_name : params.Data.ProgramName
        };
        notificationQueueItem.Subject = 'Product Suggestion Submitted';
        if (callback) {
            callback(null, { NotificationQueueItem: params.NotificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption, CompleteCallback : params.CompleteCallback});
        } else {
            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                NotificationQueueItem: notificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption,
                CompleteCallback : params.CompleteCallback
            }));
        }
    };
    this.ProductIdeaRejected = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            approver_full_name: params.Data.ApproverFullName,
            new_product_suggestion: params.Data.NewProductSuggestion,
            note: params.Data.note,
            approver_email: params.Data.ApproverEmail,
            program_name : params.Data.ProgramName
        };
        notificationQueueItem.Subject = 'Product Suggestion Rejected';
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption,
            CompleteCallback : params.CompleteCallback
        });
    };

    this.ProductIdeaApproved = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            approver_full_name : params.Data.ApproverName,
            new_product_suggestion : params.Data.ProductSuggestionName,
            approver_email : params.Data.ApproverEmail,
            program_name : params.Data.ProgramName
        };
        notificationQueueItem.Subject = 'Product Suggestion Approved';
        if (callback) {
            callback(null, { NotificationQueueItem: params.NotificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption, CompleteCallback : params.CompleteCallback});
        } else {
            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                NotificationQueueItem: notificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption,
                CompleteCallback : params.CompleteCallback
            }));
        }
    };

    this.CampaignFunded = function (params, callback) {
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.ProductIdeaPurchased = function (params, callback) {
        EntityCache.UserInfo.findOne({hgId: params.Data.PointAdmin.UserId}, function (error, adminUserInfo) {
            if (error || !adminUserInfo) {
                return callback('error loading point admin user info');
            }
            params.NotificationQueueItem.MergeFields = {
                first_name : params.NotificationQueueItem.RecipientList[0].Name,
                points_admin_full_name: adminUserInfo.UserPersonal.FullName,
                product_name : params.Data.NewProductSuggestion,
                points_admin_email: adminUserInfo.UserPersonal.PrimaryEmail || adminUserInfo.UserName,
                price_in_points : params.Data.PriceInPoints,
                program_name : params.Data.ProgramName
            };
            params.NotificationQueueItem.Subject = 'Product Suggestion Idea has been purchased';
            if (callback) {
                callback(null, { NotificationQueueItem: params.NotificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent,
                    DispatchOption : params.DispatchOption, CompleteCallback : params.CompleteCallback});
            }
        });
    };
};

module.exports = ProductBuilder;