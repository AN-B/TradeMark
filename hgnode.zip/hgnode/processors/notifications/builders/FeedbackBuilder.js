/*jslint node:true es5:true*/
var FeedbackBuilder = function () {
    "use strict";
    var config = require('../../../configurations/config'),
        FeedbackEnums = require('../../../enums/FeedbackEnums.js'),
        ConstantEnums = require('../../../enums/ConstantEnums.js'),
        i18nHelper = require('../../../helpers/i18nHelper.js');

    this.FeedbackSessionRequested = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRequested.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            subject_name: Data.SubjectFullName,
            cycle_title: Data.CycleTitle,
            request_note: Data.RequestNote
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/Start/' + Data.FeedbackSession.hgId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRequested.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRequested.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRequested.sub', {
            cycle_title: Data.CycleTitle
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.FeedbackSessionRated = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRated.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            subject_name: Data.Subject.FullName,
            cycle_title: Data.CycleTitle,
            rating_note: Data.RatingNote
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/Thanks/' + Data.FeedbackSession.hgId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRated.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRated.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionRated.sub', {
            subject_name: Data.Subject.FullName
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.FeedbackRequestExpiring = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem,
            expireInDays =  Math.round((Data.FeedbackSession.ExpirationDate - Date.now()) / ConstantEnums.MILLI_SECONDS_PER_DAY);
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpiring.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            subject_name: Data.SubjectFullName,
            cycle_title: Data.CycleTitle,
            number_of_days: Math.round((Date.now() - Data.FeedbackSession.CreatedDate) / ConstantEnums.MILLI_SECONDS_PER_DAY),
            expire_in_days: expireInDays
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/Start/' + Data.FeedbackSession.hgId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpiring.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpiring.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpiring.sub', {
            cycle_title: Data.CycleTitle,
            expire_in_days: expireInDays
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.SelfEvaluationDelivered = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationDelivered.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            reviewer_name: Data.ReviewerFullName,
            group_name: Data.GroupName,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl +
            (Data.FeedbackSession.Note ? '#/Profile/Feedback/SelfEvalStart/' : '#/Profile/Feedback/SelfEvalAnswer/') +
            Data.FeedbackSession.hgId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationDelivered.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationDelivered.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationDelivered.sub', {
            cycle_title: Data.CycleTitle
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.FeedbackCheckInManagerNotesAvailable = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackCheckInManagerNotesAvailable.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/SelfEvalView/' + params.Data.FeedbackSession.hgId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackCheckInManagerNotesAvailable.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackCheckInManagerNotesAvailable.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackCheckInManagerNotesAvailable.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };

    this.TalentInsightAssessmentDelivered = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.TalentInsightAssessmentDelivered.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            reviewer_name: Data.ReviewerFullName,
            group_name: Data.GroupName,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Team/Talent/' + Data.CycleId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.TalentInsightAssessmentDelivered.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.TalentInsightAssessmentDelivered.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.TalentInsightAssessmentDelivered.sub', {
            cycle_title: Data.CycleTitle
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.SelfEvaluationSubmitted = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem,
            subject = params.Data.FeedbackSession.Participants.filter(function (p) {
                if (params.Data.FeedbackSession.CycleType === FeedbackEnums.CycleType.EvaluateOthers) {
                    return p.ParticipantType === FeedbackEnums.SessionParticipantType.Requester;
                }
                return p.ParticipantType === FeedbackEnums.SessionParticipantType.Subject;
            });
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationSubmitted.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            subject_name: subject.length ? subject[0].FullName : "",
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/SelfEvalView/' + Data.FeedbackSession.hgId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationSubmitted.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationSubmitted.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.SelfEvaluationSubmitted.sub', {
            cycle_title: Data.CycleTitle,
            subject_name: subject.length ? subject[0].FullName : ""
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.FeedbackSessionSubmitted = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionSubmitted.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            reviewer_name: Data.ReviewerFullName,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/View/' + params.Data.FeedbackSession.RequestId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionSubmitted.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionSubmitted.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionSubmitted.sub', {
            cycle_title: Data.CycleTitle,
            reviewer_name: Data.ReviewerFullName
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
    this.EvaluateOthersSubmitted = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.EvaluateOthersSubmitted.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            reviewer_name: Data.ReviewerFullName,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/View/' + params.Data.FeedbackSession.RequestId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.EvaluateOthersSubmitted.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.EvaluateOthersSubmitted.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.EvaluateOthersSubmitted.sub', {
            cycle_title: Data.CycleTitle,
            reviewer_name: Data.ReviewerFullName
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
    this.GiveFeedbackSubmitted = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.GiveFeedbackSubmitted.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            reviewer_name: Data.ReviewerFullName,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/Rate/' + params.Data.FeedbackSession.hgId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.GiveFeedbackSubmitted.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.GiveFeedbackSubmitted.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.GiveFeedbackSubmitted.sub', {
            cycle_title: Data.CycleTitle,
            reviewer_name: Data.ReviewerFullName
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.FeedbackSessionDeclined = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionDeclined.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            reviewer_name: Data.Reviewer.FullName,
            cycle_title: Data.CycleTitle,
            decline_note: Data.DeclineNote
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/Feedback/View/' + params.Data.FeedbackSession.RequestId + '?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionDeclined.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionDeclined.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackSessionDeclined.sub', {
            cycle_title: Data.CycleTitle
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.FeedbackRequestExpired = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpired.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            reviewer_name: Data.Reviewer.FullName,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/FeedbackSession/Archived/AboutMe?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpired.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpired.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackRequestExpired.sub', {
            cycle_title: Data.CycleTitle
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
    this.FeedbackCardAvailable = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackCardAvailable.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.MergeFields.link_url = config.protocol + config.baseUrl + '#/Profile/FeedbackSession/Type?gid=' + Data.GroupId;
        notificationQueueItem.MergeFields.link_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackCardAvailable.link_txt');
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackCardAvailable.tea');
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackCardAvailable.sub');
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
    this.FeedbackCycleClosedOrArchived = function (params, callback) {
        var Data = params.Data,
            notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {};
        notificationQueueItem.MergeFields.body_txt = i18nHelper.translate(Data.i18n, 'eml.FeedbackCycleClosedOrArchived.body_txt', {
            first_name: notificationQueueItem.RecipientList.length ? notificationQueueItem.RecipientList[0].Name : 0,
            cycle_title: Data.CycleTitle,
            cycle_status: Data.CycleStatus === FeedbackEnums.CycleStatus.Closed ? i18nHelper.translate(Data.i18n.replace("/email", ""), 'common.clo').toLowerCase() : i18nHelper.translate(Data.i18n.replace("/email", ""), 'common.dltt').toLowerCase(),
            access_type: Data.CycleStatus === FeedbackEnums.CycleStatus.Closed ? i18nHelper.translate(Data.i18n.replace("/email", ""), 'common.stl').toLowerCase() : i18nHelper.translate(Data.i18n.replace("/email", ""), 'common.nol').toLowerCase(),
            admin_name: Data.AdminName,
            admin_email: Data.AdminEmail
        });
        notificationQueueItem.MergeFields.thank = i18nHelper.translate(Data.i18n, 'eml.common.thank');
        notificationQueueItem.MergeFields.teaser = i18nHelper.translate(Data.i18n, 'eml.FeedbackCycleClosedOrArchived.tea', {
            cycle_title: Data.CycleTitle
        });
        notificationQueueItem.Subject = i18nHelper.translate(Data.i18n, 'eml.FeedbackCycleClosedOrArchived.sub', {
            cycle_title: Data.CycleTitle
        });
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };
};

module.exports = FeedbackBuilder;
