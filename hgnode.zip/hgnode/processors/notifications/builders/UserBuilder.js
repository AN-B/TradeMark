/*jslint node:true es5:true*/
var UserBuilder = function () {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        i18nHelper = require('../../../helpers/i18nHelper.js'),
        recognitionHelper = require('../../../helpers/recognitionHelper.js'),
        config = require('../../../configurations/config');

    this.Birthday = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            mergeField =  {};
        EntityCache.Member.findOne({'UserId': params.Data.user.hgId}, function (err, member) {
            var i18n = params.Data.i18n;
            params.Data.GroupId = member.GroupId;
            notificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.Birthday.sub', {
                company: member.GroupName
            });
            mergeField.teaser = i18nHelper.translate(i18n, 'eml.Birthday.tea', {
                first_name: params.Data.user.UserPersonal.FirstName
            });
            mergeField.body_txt = i18nHelper.translate(i18n, 'eml.Birthday.body_txt', {
                first_name: params.Data.user.UserPersonal.FirstName,
                company: member.GroupName,
                birthday_title: recognitionHelper.getRecognitionTitle(i18n, params.Data.recognition)
            });
            mergeField.link_txt = i18nHelper.translate(i18n, 'eml.Birthday.link_txt');
            mergeField.thank = i18nHelper.translate(i18n, 'eml.common.thank');
            mergeField.link_url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + params.Data.recognition.BatchId + '?gid=' + params.Data.GroupId;
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption,
                CompleteCallback: params.CompleteCallback
            });
        });
    };

    this.Anniversary = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            i18n = params.Data.i18n,
            mergeField =  {};

        notificationQueueItem.Subject = i18nHelper.translate(i18n, 'eml.Anniversary.sub', {
            company: params.Data.Recognition.RecipientMember.GroupName
        });
        mergeField.teaser = i18nHelper.translate(i18n, 'eml.Anniversary.tea', {
            first_name: params.Data.Recognition.RecipientMember.FirstName
        });
        mergeField.body_txt = i18nHelper.translate(i18n, 'eml.Anniversary.body_txt', {
            first_name: params.Data.Recognition.RecipientMember.FirstName,
            company: params.Data.Recognition.RecipientMember.GroupName,
            birthday_title: recognitionHelper.getRecognitionTitle(i18n, params.Data.Recognition)
        });
        mergeField.link_txt = i18nHelper.translate(i18n, 'eml.Anniversary.link_txt');
        mergeField.thank = i18nHelper.translate(i18n, 'eml.common.thank');
        mergeField.link_url = config.protocol + config.baseUrl + '#/Recognize/Iso/' + params.Data.Recognition.BatchId + '?gid=' + params.Data.GroupId;
        notificationQueueItem.MergeFields = mergeField;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption,
            CompleteCallback: params.CompleteCallback
        });
    };

    this.UserNotificationEmailChanged = function (params, callback) {
        var mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;

        EntityCache.UserInfo.findOne({hgId: params.Data.UserId}, function (err, userInfo) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!userInfo) {
                return callback('business.user.noauth.uidne');
            }
            notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.UserNotificationEmailChanged.sub');
            mergeField.teaser = i18nHelper.translate(params.Data.i18n, 'eml.UserNotificationEmailChanged.tea');
            mergeField.body_txt = i18nHelper.translate(params.Data.i18n, 'eml.UserNotificationEmailChanged.body_txt', {
                first_name: userInfo.UserPersonal.FirstName
            });
            mergeField.thank = i18nHelper.translate(params.Data.i18n, 'eml.common.thank');
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    };

    this.PasswordResetRequestCreated = function (params, callback) {
        var UserInfo = EntityCache.UserInfo,
            Data = params.Data,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;

        UserInfo.findOne({hgId: params.Data.UserId}, function (err, userInfo) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!userInfo) {
                return callback('business.user.noauth.uidne');
            }
            notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.PasswordResetRequestCreated.sub');
            mergeField.link_url = config.protocol + config.baseUrl + 'public/#/ResetPassword/' + Data.ActionTokenId;
            mergeField.link_txt = i18nHelper.translate(params.Data.i18n, 'eml.PasswordResetRequestCreated.link_txt');
            mergeField.teaser = i18nHelper.translate(params.Data.i18n, 'eml.PasswordResetRequestCreated.tea');
            mergeField.body_txt = i18nHelper.translate(params.Data.i18n, 'eml.PasswordResetRequestCreated.body_txt', {
                first_name: userInfo.UserPersonal.FirstName,
                link_url: config.protocol + config.baseUrl + 'public/#/ResetPassword/' + Data.ActionTokenId
            });
            mergeField.thank = i18nHelper.translate(params.Data.i18n, 'eml.common.thank');
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    };

    this.PasswordChanged = function (params, callback) {
        var UserInfo = EntityCache.UserInfo,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;
        UserInfo.findOne({'hgId' : params.Data.UserId}, function (err, userInfo) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!userInfo) {
                return callback('business.user.noauth.uidne');
            }
            notificationQueueItem.Subject = i18nHelper.translate(params.Data.i18n, 'eml.PasswordChanged.sub');
            mergeField.link_url = config.protocol + config.baseUrl;
            mergeField.link_txt = i18nHelper.translate(params.Data.i18n, 'eml.PasswordChanged.link_txt');
            mergeField.teaser = i18nHelper.translate(params.Data.i18n, 'eml.PasswordChanged.tea');
            mergeField.body_txt = i18nHelper.translate(params.Data.i18n, 'eml.PasswordChanged.body_txt', {
                first_name: userInfo.UserPersonal.FirstName,
                link_url: config.protocol + config.baseUrl
            });
            mergeField.thank = i18nHelper.translate(params.Data.i18n, 'eml.common.thank');
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption
            });
        });
    };

    this.UserLockedOut = function (params, callback) {
        var UserInfo = EntityCache.UserInfo,
            mergeField =  {},
            notificationQueueItem = params.NotificationQueueItem;

        mergeField.reset_password_url = config.protocol + config.baseUrl + 'public/#/ForgotPassword';

        UserInfo.findOne({'hgId' : params.Data.UserId}, function (err, userInfo) {
            if (err) {
                return callback('business.user.noauth.elup');
            }
            if (!userInfo) {
                return callback('business.user.noauth.uidne');
            }
            mergeField.first_name = userInfo.UserPersonal.FirstName;
            notificationQueueItem.MergeFields = mergeField;
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption,
                CompleteCallback : params.CompleteCallback
            });
        });
    };

    this.UserRequestedInfo = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            mergeField = {
                name : params.Data.Lead.Name,
                company : params.Data.Lead.Company,
                email : params.Data.Lead.Email,
                phone : params.Data.Lead.Phone
            };
        notificationQueueItem.MergeFields = mergeField;
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.AuthCodeCreated = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;

        notificationQueueItem.MergeFields = {
            authCode: params.Data.AuthCode,
            first_name: params.Data.FirstName,
            last_name: params.Data.LastName
        };

        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data: params.Data,
            NotificationEvent: params.NotificationEvent,
            DispatchOption: params.DispatchOption
        });
    };
};

module.exports = UserBuilder;
