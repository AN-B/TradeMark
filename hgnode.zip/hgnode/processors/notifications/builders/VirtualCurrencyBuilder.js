var VirtualCurrencyBuilder = function (EventEmitterCache) {
    "use strict";
    var EntityCache = require('../../../framework/EntityCache'),
        EventData = require('../../../common/EventData'),
        DateHelper = require('../../../util/DateHelper'),
        AccountTypeEnums = require('../../../enums/AccountType'),
        config = require('../../../configurations/config');

    this.AdminIssuedPoints = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.MergeFields = {
            count_points_issued: params.Data.pointsIssued,
            from_balance: params.Data.FromAccountType,
            to_balance: params.Data.ToAccountType
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.AdminPointsReplenished = function (params, callback) {
        params.NotificationQueueItem.MergeFields = {
            points_admin: params.Data.FullName,
            total_points: params.Data.Points
        };
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.XpOrderPlacedAdmin = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.Subject = 'New order placed by ' + params.Data.ProductOrder.Requester.FullName;
        notificationQueueItem.MergeFields = {
            order_number : params.Data.ProductOrder.FriendlyId,
            first_name: params.Data.ProductOrder.Requester.FullName,
            item_name: params.Data.ProductOrder.ProductItem.Name,
            recipient_full_name : params.Data.ProductOrder.Recipient.FullName ||  params.Data.ProductOrder.Requester.FullName,
            quantity: params.Data.ProductOrder.Quantity,
            points : params.Data.ProductOrder.Quantity * params.Data.ProductOrder.ProductItem.PointCost,
            url: config.protocol + config.baseUrl + '#/Admin/Points/Orders',
            account_type : params.Data.AccountType === AccountTypeEnums.PointSpend ? 'Spending account' : 'Transfer account',
            instruction : params.Data.ProductOrder.ProductItem.RedeemInstruction
        };
        if (callback) {
            callback(null, {
                NotificationQueueItem: notificationQueueItem,
                Data : params.Data,
                NotificationEvent : params.NotificationEvent,
                DispatchOption : params.DispatchOption,
                CompleteCallback : params.CompleteCallback
            });
        } else {
            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                NotificationQueueItem: notificationQueueItem,
                Data: params.Data,
                NotificationEvent: params.NotificationEvent,
                DispatchOption: params.DispatchOption,
                CompleteCallback: params.CompleteCallback
            }));
        }
    };

    this.XpProductItemExpired = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            text = '';
        params.Data.Items.forEach(function (item) {
            text += item.Name + '<br>';
        });
        notificationQueueItem.MergeFields = {
            items : text,
            url: config.protocol + config.baseUrl + '#/Admin/Points/Products'
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };

    this.XpCampaignItemExpired = function (params, callback) {
        callback(null, {
            NotificationQueueItem: params.NotificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption,
            CompleteCallback : params.CompleteCallback
        });
    };

    this.XpOrderPlacedRecipient = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.Subject = 'Redeem your ' + params.Data.ProductOrder.ProductItem.Name + '!';
        notificationQueueItem.MergeFields = {
            order_number : params.Data.ProductOrder.FriendlyId,
            first_name: params.Data.ProductOrder.Recipient.FullName,
            item_name: params.Data.ProductOrder.ProductItem.Name,
            quantity: params.Data.ProductOrder.Quantity,
            request_name : params.Data.ProductOrder.Requester.FullName,
            url: config.protocol + config.baseUrl + '/#/Motivate/XpOrder/' + params.Data.ProductOrder.hgId,
            instruction : params.Data.ProductOrder.ProductItem.RedeemInstruction,
            reachout_admin_text : ''
        };
        EntityCache.Group.findOne({'hgId' : params.Data.ProductOrder.ProductItem.GroupId}, function (err, group) {
            if (!err && group && group.PointMasterMemberId) {
                notificationQueueItem.MergeFields.group_name = group.GroupName;
                EntityCache.Member.findOne({'hgId' : group.PointMasterMemberId}, function (err, member) {
                    if (!err && member) {
                        EntityCache.UserInfo.findOne({hgId : member.UserId}, function (err, userInfo) {
                            if (!err && userInfo) {
                                var reachout_admin_text = 'If you have questions regarding your order, please reach out to ' + userInfo.UserPersonal.FullName + ' at ' + (userInfo.UserPersonal.PrimaryEmail || userInfo.UserName);
                                notificationQueueItem.MergeFields.reachout_admin_text = reachout_admin_text;
                            }
                            callback(null, {NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption});
                        });
                    } else {
                        callback(null, {NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption});
                    }
                });
            } else {
                callback(null, {NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption});
            }
        });
    };

    this.XpOrderPlacedRequester = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.Subject = 'Redeem your ' + params.Data.ProductOrder.ProductItem.Name + '!';
        notificationQueueItem.MergeFields = {
            order_number : params.Data.ProductOrder.FriendlyId,
            first_name: params.Data.ProductOrder.Recipient.FullName,
            item_name: params.Data.ProductOrder.ProductItem.Name,
            quantity: params.Data.ProductOrder.Quantity,
            request_name : params.Data.ProductOrder.Requester.FullName,
            url: config.protocol + config.baseUrl + '/#/Motivate/XpOrder/' + params.Data.ProductOrder.hgId,
            instruction : params.Data.ProductOrder.ProductItem.RedeemInstruction,
            reachout_admin_text : ''
        };
        EntityCache.Group.findOne({'hgId' : params.Data.ProductOrder.ProductItem.GroupId}, function (err, group) {
            if (!err && group && group.PointMasterMemberId) {
                notificationQueueItem.MergeFields.group_name = group.GroupName;
                EntityCache.Member.findOne({'hgId' : group.PointMasterMemberId}, function (err, member) {
                    if (!err && member) {
                        EntityCache.UserInfo.findOne({hgId : member.UserId}, function (err, userInfo) {
                            if (!err && userInfo) {
                                var reachout_admin_text = 'If you have questions regarding your order, please reach out to ' + userInfo.UserPersonal.FullName + ' at ' + (userInfo.UserPersonal.PrimaryEmail || userInfo.UserName);
                                notificationQueueItem.MergeFields.reachout_admin_text = reachout_admin_text;
                            }
                            callback(null, {NotificationQueueItem: notificationQueueItem, Data : params.Data, NotificationEvent : params.NotificationEvent, DispatchOption : params.DispatchOption});
                        });
                    } else {
                        if (callback) {
                            callback(null, {
                                NotificationQueueItem: notificationQueueItem,
                                Data : params.Data,
                                NotificationEvent : params.NotificationEvent,
                                DispatchOption : params.DispatchOption,
                                CompleteCallback : params.CompleteCallback
                            });
                        } else {
                            EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                                NotificationQueueItem: notificationQueueItem,
                                Data: params.Data,
                                NotificationEvent: params.NotificationEvent,
                                DispatchOption: params.DispatchOption,
                                CompleteCallback: params.CompleteCallback
                            }));
                        }
                    }
                });
            } else {
                if (callback) {
                    callback(null, {
                        NotificationQueueItem: notificationQueueItem,
                        Data : params.Data,
                        NotificationEvent : params.NotificationEvent,
                        DispatchOption : params.DispatchOption,
                        CompleteCallback : params.CompleteCallback
                    });
                } else {
                    EventEmitterCache.emit(params.EventName, new EventData(params.correlationId, {
                        NotificationQueueItem: notificationQueueItem,
                        Data: params.Data,
                        NotificationEvent: params.NotificationEvent,
                        DispatchOption: params.DispatchOption,
                        CompleteCallback: params.CompleteCallback
                    }));
                }
            }
        });
    };

    this.XpOrderCancelledRecipient = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            strDate = DateHelper.formatDateStringFromTimestamp(params.Data.ProductOrder.CreatedDate);
        notificationQueueItem.Subject = 'Order for ' + params.Data.ProductOrder.ProductItem.Name + ' cancelled';

        notificationQueueItem.MergeFields = {
            order_number : params.Data.ProductOrder.FriendlyId,
            first_name: params.Data.ProductOrder.Recipient.FullName,
            item_name: params.Data.ProductOrder.ProductItem.Name,
            quantity: params.Data.ProductOrder.Quantity,
            request_name : params.Data.ProductOrder.Requester.FullName,
            url: config.protocol + config.baseUrl + '/#/Motivate/XpOrder/' + params.Data.ProductOrder.hgId,
            points : params.Data.ProductOrder.Quantity * params.Data.ProductOrder.ProductItem.PointCost,
            cancel_comments: params.Data.Note || 'None',
            reachout_admin_text : '',
            account_type : params.Data.AccountType === AccountTypeEnums.PointSpend ? 'Spending account' : 'Transfer account',
            order_date : strDate
        };
        EntityCache.Group.findOne({'hgId' : params.Data.ProductOrder.ProductItem.GroupId}, function (err, group) {
            if (!err && group && group.PointMasterMemberId) {
                EntityCache.Member.findOne({'hgId' : group.PointMasterMemberId}, function (err, member) {
                    if (!err && member) {
                        EntityCache.UserInfo.findOne({hgId : member.UserId}, function (err, userInfo) {
                            if (!err && userInfo) {
                                var reachout_admin_text = 'If you have any questions, or believe this order was cancelled in error, please contact ' + userInfo.UserPersonal.FullName + ' at ' + (userInfo.UserPersonal.PrimaryEmail || userInfo.UserName);
                                notificationQueueItem.MergeFields.reachout_admin_text = reachout_admin_text;
                            }
                            callback(null, {
                                NotificationQueueItem: notificationQueueItem,
                                Data : params.Data,
                                NotificationEvent : params.NotificationEvent,
                                DispatchOption : params.DispatchOption
                            });
                        });
                    } else {
                        callback(null, {
                            NotificationQueueItem: notificationQueueItem,
                            Data : params.Data,
                            NotificationEvent : params.NotificationEvent,
                            DispatchOption : params.DispatchOption
                        });
                    }
                });
            } else {
                callback(null, {
                    NotificationQueueItem: notificationQueueItem,
                    Data : params.Data,
                    NotificationEvent : params.NotificationEvent,
                    DispatchOption : params.DispatchOption
                });
            }
        });
    };

    function xpOrderCancelledBuilder(params, callback) {
        var notificationQueueItem = params.NotificationQueueItem,
            strDate = DateHelper.formatDateStringFromTimestamp(params.Data.ProductOrder.CreatedDate);
        notificationQueueItem.Subject = 'Order for ' + params.Data.ProductOrder.ProductItem.Name + ' cancelled';
        notificationQueueItem.MergeFields = {
            recipient_full_name : params.Data.ProductOrder.Recipient.FullName,
            order_number : params.Data.ProductOrder.FriendlyId,
            first_name: params.Data.ProductOrder.ProductItem.ProductType === 'Store' ? params.Data.ProductOrder.Requester.FullName : params.Data.BakerFullName,
            item_name: params.Data.ProductOrder.ProductItem.Name,
            quantity: params.Data.ProductOrder.Quantity,
            request_name : params.Data.ProductOrder.Requester.FullName,
            url: config.protocol + config.baseUrl + '/#/Motivate/XpOrder/' + params.Data.ProductOrder.hgId,
            points : params.Data.ProductOrder.ProductItem.ProductType === 'Store' ? params.Data.ProductOrder.Quantity * params.Data.ProductOrder.ProductItem.PointCost : params.Data.BakerPoint,
            reachout_admin_text : '',
            cancel_comments: params.Data.Note || 'None',
            account_type : params.Data.AccountType === AccountTypeEnums.PointSpend ? 'Spending account' : 'Transfer account',
            order_date : strDate
        };
        EntityCache.Group.findOne({'hgId' : params.Data.ProductOrder.ProductItem.GroupId}, function (err, group) {
            if (!err && group && group.PointMasterMemberId) {
                EntityCache.Member.findOne({'hgId' : group.PointMasterMemberId}, function (err, member) {
                    if (!err && member) {
                        EntityCache.UserInfo.findOne({hgId : member.UserId}, function (err, userInfo) {
                            if (!err && userInfo) {
                                var reachout_admin_text = 'If you have any questions, or believe this order was cancelled in error, please contact ' + userInfo.UserPersonal.FullName + ' at ' + (userInfo.UserPersonal.PrimaryEmail || userInfo.UserName);
                                notificationQueueItem.MergeFields.reachout_admin_text = reachout_admin_text;
                            }
                            callback(null, {
                                NotificationQueueItem: notificationQueueItem,
                                Data : params.Data,
                                NotificationEvent : params.NotificationEvent,
                                DispatchOption : params.DispatchOption
                            });
                        });
                    } else {
                        callback(null, {
                            NotificationQueueItem: notificationQueueItem,
                            Data : params.Data,
                            NotificationEvent : params.NotificationEvent,
                            DispatchOption : params.DispatchOption
                        });
                    }
                });
            } else {
                callback(null, {
                    NotificationQueueItem: notificationQueueItem,
                    Data : params.Data,
                    NotificationEvent : params.NotificationEvent,
                    DispatchOption : params.DispatchOption
                });
            }
        });
    }

    this.XpOrderCancelledRequester = function (params, callback) {
        xpOrderCancelledBuilder(params, callback);
    };

    this.XpOrderCancelledGifter = function (params, callback) {
        xpOrderCancelledBuilder(params, callback);
    };

    this.XpOrderPlacedGifter = function (params, callback) {
        var notificationQueueItem = params.NotificationQueueItem;
        notificationQueueItem.Subject = 'You gave ' + params.Data.ProductOrder.Recipient.FullName + ' a ' + params.Data.ProductOrder.ProductItem.Name;

        notificationQueueItem.MergeFields = {
            order_number : params.Data.ProductOrder.FriendlyId,
            first_name: params.Data.ProductOrder.Requester.FullName,
            item_name: params.Data.ProductOrder.ProductItem.Name,
            gift_recipient_full_name : params.Data.ProductOrder.Recipient.FullName,
            quantity: params.Data.ProductOrder.Quantity,
            points : params.Data.ProductOrder.Quantity * params.Data.ProductOrder.ProductItem.PointCost,
            account_type : params.Data.AccountType === AccountTypeEnums.PointSpend ? 'Spending account' : 'Transfer account',
            instruction : params.Data.ProductOrder.ProductItem.RedeemInstruction
        };
        callback(null, {
            NotificationQueueItem: notificationQueueItem,
            Data : params.Data,
            NotificationEvent : params.NotificationEvent,
            DispatchOption : params.DispatchOption
        });
    };
};

module.exports = VirtualCurrencyBuilder;