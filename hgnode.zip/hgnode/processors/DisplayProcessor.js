/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    DisplayProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid');

        function addDisplay(params, callback) {
            var displaySetting = new EntityCache.Display({
                hgId: guid.v1(),
                GroupId: params.GroupId,
                GroupRecognitionAvatarInterval: params.GroupRecognitionAvatarInterval,
                RecognitionInterval: params.RecognitionInterval,
                CreatedBy: params.UserId,
                ModifiedBy: params.UserId,
                CreatedDate: new Date().getTime()
            });
            displaySetting.save(function (error) {
                callback(error, 'display.err.uds');
            });
        }
        this.SaveDisplay = function (params, callback) {
            EntityCache.Display.findOne({GroupId: params.GroupId}, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    addDisplay(params, callback);
                } else {
                    EntityCache.Display.update({GroupId: params.GroupId}, {
                        $set: {
                            ModifiedBy: params.ModifiedBy,
                            GroupRecognitionAvatarInterval: params.GroupRecognitionAvatarInterval,
                            RecognitionInterval: params.RecognitionInterval
                        }
                    }, function (error, data) {
                        callback(error, 'display.err.uds');
                    });
                }
            });
        };
        this.GetDisplayByGroupId = function (params, callback) {
            EntityCache.Display.findOne({GroupId: params.GroupId}, callback);
        };
        this.GetDisplayById = function (params, callback) {
            EntityCache.Display.findOne({hgId: params.hgId}, callback);
        };
    };

module.exports = DisplayProcessor;
