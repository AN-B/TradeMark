'use strict';
var GoalEnums = require('../../enums/GoalEnums.js'),
    FeedbackEnums = require('../../enums/FeedbackEnums.js'),
    MemberEnums = require('../../enums/MemberEnums.js'),
    AutocompleteEnums = require('../../enums/AutocompleteEnums.js'),
    EntityEnum = require('../../enums/EntityEnums.js'),
    autoCompleteTypeMap = {
        CreditAdmins: function (params) {
            var query = {},
                projection = {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$FullName',
                    UserId: '$UserId',
                    AvatarId: '$UserId',
                    Position: '$Position',
                    Type: {$concat: ['CreditAdmins']},
                    DepartmentName: '$GroupDepartmentName',
                    DepartmentId: '$GroupDepartmentId',
                    LocationName: '$Location.Name',
                    LocationId: '$Location.hgId',
                    MailCD: "$MailCD"
                };
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
            } else {
                query = {
                    GroupId: params.GroupId,
                    RolesInGroup: { $in: [
                        MemberEnums.MemberRole.Admin.Name,
                        MemberEnums.MemberRole.Owner.Name,
                        MemberEnums.MemberRole.HGAdmin.Name
                    ]}
                };
                if (params.SearchTermAscii) {
                    query.SearchField = params.SearchTermAscii.toLowerCase();
                } else {
                    query.$or = [{FullName: {$regex: params.SearchTerm, $options: "i"}}];
                }
                if (params.Status.length === 1) {
                    query.MembershipStatus = params.Status[0];
                } else if (params.Status.length > 1) {
                    query.MembershipStatus = { $in: params.Status};
                }
                if (params.ExcludeSelf) {
                    params.Excluded.push(params.MemberId);
                }
                if (params.Excluded.length) {
                    query.hgId = { $nin: params.Excluded};
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.Member,
                AggregateParams: [
                    {$match: query},
                    {$unwind: {path: "$MyManagers", preserveNullAndEmptyArrays: true}},
                    {$project: AutocompleteEnums.SearchProjection(params, projection)},
                    {$project: AutocompleteEnums.SearchProximityProjection(projection)},
                    {$group: AutocompleteEnums.RepackGroup(projection)},
                    {$project: AutocompleteEnums.RepackProjection(projection)},
                    {$sort: {ProximityScore: -1, Name: 1}},
                    {$skip: parseInt(params.Skip, 10) || 0},
                    {$limit: parseInt(params.Take, 10) || 10}
                ]
            };
        },
        Member: function (params) {
            return autoCompleteTypeMap.Member_Internal(params, {
                _id: 0,
                Id: '$hgId',
                Name: '$FullName',
                UserId: '$UserId',
                AvatarId: '$UserId',
                Position: '$Position',
                DepartmentName: '$GroupDepartmentName',
                DepartmentId: '$GroupDepartmentId',
                LocationName: '$Location.Name',
                LocationId: '$Location.hgId',
                Type: {$concat: ['Member']},
                MailCD: "$MailCD"
            }, 'Name');
        },
        MobileMember: function (params) {
            // changes to this structure should be verified against search in mobile to prevent issues
            var query = {};
            if (params.Bookmarked && params.Bookmarked.length > 0) {
                query.hgId = { $in: params.Bookmarked};
            }
            return autoCompleteTypeMap.Member_Internal(params, {
                _id: 0,
                hgId: '$hgId',
                Name: '$FullName',
                FullName: '$FullName',
                UserId: '$UserId',
                Position: '$Position',
                GroupDepartmentName: '$GroupDepartmentName',
                Type: {$concat: ['Member']},
                DepartmentName: '$GroupDepartmentName',
                DepartmentId: '$GroupDepartmentId',
                LocationName: '$Location.Name',
                LocationId: '$Location.hgId',
                MailCD: "$MailCD"
            }, 'Name', query);
        },
        Member_Internal: function (params, projection, sortField, query) {
            var temp,
                search = {$regex: params.SearchTerm, $options: 'i'};
            query = query || {};
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
                if (params.Status && params.Status.length === 1) {
                    query.MembershipStatus = params.Status[0];
                } else if (params.Status && params.Status.length > 1) {
                    query.MembershipStatus = {$in: params.Status};
                }
            } else {
                query.GroupId = params.GroupId;
                if (params.SearchTermAscii) {
                    if (params.SearchDepartment) {
                        query.$or = [{GroupDepartmentName: search}];
                    }
                    if (params.SearchLocation) {
                        query.$or =  query.$or || [];
                        query.$or.push({'Location.Name': search});
                    }
                    if (!params.SearchLocation && !params.SearchDepartment) {
                        query.SearchField = params.SearchTermAscii.toLowerCase();
                    } else {
                        query.$or.push({SearchField: params.SearchTermAscii.toLowerCase()});
                    }
                } else {
                    query.FullName = search;
                }
                if (params.Status.length === 1) {
                    query.MembershipStatus = params.Status[0];
                } else if (params.Status.length > 1) {
                    query.MembershipStatus = {$in: params.Status};
                }
                if (params.ExcludeSelf) {
                    params.Excluded.push(params.MemberId);
                }
                if (params.Roles.length) {
                    query.RolesInGroup = {$in: params.Roles};
                }
                if (params.Excluded.length) {
                    query.hgId = {$nin: params.Excluded};
                }
                if (params.SelectedDepartmentIds && params.SelectedDepartmentIds.length) {
                    query.GroupDepartmentId = { $in: params.SelectedDepartmentIds};
                }
            }
            if (params.ExtendedFields && params.ExtendedFields.length) {
                params.ExtendedFields.forEach(function (field) {
                    temp = field.split(".");
                    if (temp.length > 1) {
                        field = temp[0]; //support for multi dot keys
                    }
                    projection[field] = ['$', field].join('');
                });
            }
            return {
                EntityType: AutocompleteEnums.Entity.Member,
                AggregateParams: [
                    {$match: query},
                    {$unwind: {path: "$MyManagers", preserveNullAndEmptyArrays: true}},
                    {$project: AutocompleteEnums.SearchProjection(params, projection)},
                    {$project: AutocompleteEnums.SearchProximityProjection(projection)},
                    {$group: AutocompleteEnums.RepackGroup(projection)},
                    {$project: AutocompleteEnums.RepackProjection(projection)},
                    {$sort: {ProximityScore: -1, Name: 1}},
                    {$skip: parseInt(params.Skip, 10) || 0},
                    {$limit: parseInt(params.Take, 10) || 10}
                ]
            };
        },
        Group: function (params) {
            var query = {};
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
            } else {
                query = {
                    $or: [
                        {GroupName: {$regex: params.SearchTerm, $options: 'i'}}
                    ]
                };
                if (params.Status.length === 1) {
                    query.Status = params.Status[0];
                } else if (params.Status.length > 1) {
                    query.Status = { $in: params.Status};
                }
                if (params.ExcludeSelf) {
                    params.Excluded.push(params.GroupId);
                }
                if (params.Excluded.length > 0) {
                    query.hgId = { $nin: params.Excluded};
                }
            }
            if (params.ExcludeFoundingCompany) {
                query['Preference.FeatureFlags.FeatureName'] = { $ne:  'IsFoundingCompany' };
            }
            return {
                EntityType: AutocompleteEnums.Entity.Group,
                Query: query,
                Projection: {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$GroupName',
                    AvatarId: '$hgId',
                    Type: {$concat: ['Group']}
                },
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        },
        Location: function (params) {
            return autoCompleteTypeMap.Location_Internal(params, {
                _id: 0,
                Id: '$hgId',
                AvatarId: '$hgId',
                hgId: '$hgId',
                Name: '$Name',
                Type: {$concat: ['Location']}
            });
        },
        MobileLocation: function (params) {
            // changes to this structure should be verified against search in mobile to prevent issues
            var query = {};
            if (params.Bookmarked && params.Bookmarked.length > 0) {
                query.hgId = { $in: params.Bookmarked};
            }
            return autoCompleteTypeMap.Location_Internal(params, {
                _id: 0,
                hgId: '$hgId',
                Name: '$Name',
                Type: {$concat: ['Location']}
            }, query);
        },
        Location_Internal: function (params, projection, query) {
            query = query || {};
            if (params.PreSelectedId) {
                query.hgId = {$in: params.PreSelectedId };
            } else {
                query = {
                    GroupId: params.GroupId,
                    Type: AutocompleteEnums.Entity.Location,
                    Status: EntityEnum.MembershipStatus.Active,
                    Name: {$regex: params.SearchTerm, $options: 'i'}
                };
                if (params.Excluded && params.Excluded.length) {
                    query.hgId = {$nin: params.Excluded};
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.Team,
                Query: query,
                Projection: projection,
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        },
        RecogntionLocation: function (params) {
            var query = {};
            if (params.PreSelectedId) {
                query['Location.hgId'] = { $in: params.PreSelectedId };
            } else {
                query = {
                    GroupId: params.GroupId,
                    'Location.Name': {$regex: params.SearchTerm, $options: 'i'},
                    MembershipStatus: EntityEnum.MembershipStatus.Active
                };
                if (params.Excluded && params.Excluded.length) {
                    query['Location.hgId'] = {$nin: params.Excluded};
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.Member,
                Query: query,
                Group: {
                    _id: {Id: '$Location.hgId', Name: '$Location.Name'},
                    count: {'$sum': 1}
                },
                Projection: {
                    _id: 0,
                    Id: '$_id.Id',
                    AvatarId: '$_id.Id',
                    hgId: '$_id.Id',
                    Name: '$_id.Name',
                    numMembers: '$count',
                    Type: {$concat: ['Location']}
                },
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        },
        Department: function (params) {
            function postProcess(data) {
                if (!data || !data.length) {
                    return [];
                }
                data.forEach(function (item) {
                    item.numMembers = item.TeamMembers.length;
                    delete item.TeamMembers;
                });
                return data;
            }
            return autoCompleteTypeMap.Department_Internal(params, {
                _id: 0,
                Id: '$hgId',
                Name: '$Name',
                AvatarId: '$hgId',
                Type: {$concat: ['Department']},
                TeamMembers: '$TeamMembers',
                Description: '$Description'
            }, null, postProcess);
        },
        MobileDepartment: function (params) {
            // changes to this structure should be verified against search in mobile to prevent issues
            var query = {};
            if (params.Bookmarked) {
                query.hgId = { $in: params.Bookmarked};
            }
            return autoCompleteTypeMap.Department_Internal(params, {
                _id: 0,
                hgId: '$hgId',
                Name: '$Name',
                Type: {$concat: ['Department']}
            }, query);
        },
        Department_Internal: function (params, projection, query, postProcess) {
            query = query || {};
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
            } else {
                query.GroupId = params.GroupId;
                query.Type = 'Department';
                query.Status = 'Active';
                query.Name = {$regex: params.SearchTerm, $options: 'i'};
                if (params.Excluded.length) {
                    query.hgId = { $nin: params.Excluded};
                }
            }
            if (params.ExtendedFields && params.ExtendedFields.length) {
                params.ExtendedFields.forEach(function (field) {
                    projection[field] = ['$', field].join('');
                });
            }
            return {
                EntityType: AutocompleteEnums.Entity.Team,
                Query: query,
                Projection: projection,
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0,
                PostDataProcess: postProcess
            };
        },
        PublicTeam: function (params) {
            var query = {};
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
            } else {
                query = {
                    GroupId: params.GroupId,
                    Type: EntityEnum.TeamType.Pod,
                    IsPublic: true,
                    Status: EntityEnum.TeamStatus.Active,
                    Name: {$regex: params.SearchTerm, $options: 'i'}
                };
                if (params.Excluded.length) {
                    query.hgId = {$nin: params.Excluded};
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.Team,
                Query: query,
                Projection: {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$Name',
                    AvatarId: '$hgId',
                    Type: {$concat: ['PublicTeam']}
                },
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        },
        Team: function (params) {
            var query = {};
            if (params.PreSelectedId) {
                query.hgId = {$in: params.PreSelectedId};
            } else {
                query = {
                    GroupId: params.GroupId,
                    Type: EntityEnum.TeamType.Pod,
                    Status: EntityEnum.TeamStatus.Active,
                    $or: [{'TeamMembers.MemberId': params.MemberId}, {IsPublic: true}, {OwnerId: params.MemberId}],
                    Name: {$regex: params.SearchTerm, $options: 'i'}
                };
                if (params.Excluded.length) {
                    query.hgId = { $nin: params.Excluded};
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.Team,
                Query: query,
                Projection: {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$Name',
                    AvatarId: '$hgId',
                    Type: {$concat: ['Team']}
                },
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        },
        Manager: function (params) {
            var query = {},
                projection = {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$FullName',
                    UserId: '$UserId',
                    AvatarId: '$UserId',
                    Position: '$Position',
                    Type: {$concat: ['Manager']},
                    DepartmentName: '$GroupDepartmentName',
                    DepartmentId: '$GroupDepartmentId',
                    LocationName: '$Location.Name',
                    LocationId: '$Location.hgId',
                    MailCD: "$MailCD"
                };
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
            } else {
                query = {
                    GroupId: params.GroupId,
                    RolesInGroup: MemberEnums.MemberRole.Manager.Name
                };
                if (params.SearchTermAscii) {
                    query.SearchField = params.SearchTermAscii.toLowerCase();
                } else {
                    query.$or = [{FullName: {$regex: params.SearchTerm, $options: "i"}}];
                }
                if (params.Status.length === 1) {
                    query.MembershipStatus = params.Status[0];
                } else if (params.Status.length > 1) {
                    query.MembershipStatus = { $in: params.Status};
                } else {
                    query.MembershipStatus = MemberEnums.Status.Active;
                }
                if (params.ExcludeSelf) {
                    params.Excluded.push(params.MemberId);
                }
                if (params.Excluded.length) {
                    query.hgId = { $nin: params.Excluded};
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.Member,
                AggregateParams: [
                    {$match: query},
                    {$unwind: {path: "$MyManagers", preserveNullAndEmptyArrays: true}},
                    {$project: AutocompleteEnums.SearchProjection(params, projection)},
                    {$project: AutocompleteEnums.SearchProximityProjection(projection)},
                    {$group: AutocompleteEnums.RepackGroup(projection)},
                    {$project: AutocompleteEnums.RepackProjection(projection)},
                    {$sort: {ProximityScore: -1, Name: 1}},
                    {$skip: parseInt(params.Skip, 10) || 0},
                    {$limit: parseInt(params.Take, 10) || 10}
                ]
            };
        },
        MemberAndDepartment: function (params) {
            return [
                autoCompleteTypeMap[AutocompleteEnums.Entity.Department](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.Member](params)
            ];
        },
        MemberAndLocation: function (params) {
            return [
                autoCompleteTypeMap[AutocompleteEnums.Entity.Member](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.RecogntionLocation](params)
            ];
        },
        MemberAndDepartmentandLocationFavorite: function (params) {
            return [
                autoCompleteTypeMap[AutocompleteEnums.Entity.Member](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.Department](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.Location](params)
            ];
        },
        MemberAndDepartmentandLocation: function (params) {
            return [
                autoCompleteTypeMap[AutocompleteEnums.Entity.Member](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.Department](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.RecogntionLocation](params)
            ];
        },
        MobileMemberAndDepartment: function (params) {
            return [
                autoCompleteTypeMap[AutocompleteEnums.Entity.MobileMember](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.MobileDepartment](params)
            ];
        },
        MobileMemberAndDepartmentAndLocationFavorite: function (params) {
            return [
                autoCompleteTypeMap[AutocompleteEnums.Entity.MobileMember](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.MobileDepartment](params),
                autoCompleteTypeMap[AutocompleteEnums.Entity.MobileLocation](params)
            ];
        },
        MemberAccountBalance_Internal: function (params) {
            var query = {},
                temp,
                projection = {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$FullName',
                    UserId: '$UserId',
                    AvatarId: '$UserId',
                    Position: '$Position',
                    Department: '$GroupDepartmentName',
                    Type: {$concat: ['Member']},
                    DepartmentName: '$GroupDepartmentName',
                    DepartmentId: '$GroupDepartmentId',
                    LocationName: '$Location.Name',
                    LocationId: '$Location.hgId',
                    MailCD: "$MailCD"
                };
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
            } else {
                query = {
                    GroupId: params.GroupId
                };
                if (params.SearchTermAscii) {
                    query.SearchField = params.SearchTermAscii.toLowerCase();
                } else {
                    query.$or = [{FullName: {$regex: params.SearchTerm, $options: "i"}}];
                }
                if (params.Status.length === 1) {
                    query.MembershipStatus = params.Status[0];
                } else if (params.Status.length > 1) {
                    query.MembershipStatus = { $in: params.Status};
                }
                if (params.ExcludeSelf) {
                    params.Excluded.push(params.MemberId);
                }
                if (params.Excluded.length) {
                    query.hgId = { $nin: params.Excluded};
                }
            }
            if (params.ExtendedFields && params.ExtendedFields.length) {
                params.ExtendedFields.forEach(function (field) {
                    temp = field.split(".");
                    if (temp.length > 1) {
                        field = temp[0]; //support for multi dot keys
                    }
                    projection[field] = ['$', field].join('');
                });
            }
            return {
                EntityType: AutocompleteEnums.Entity.Member,
                AggregateParams: [
                    {$match: query},
                    {$unwind: {path: "$MyManagers", preserveNullAndEmptyArrays: true}},
                    {$project: AutocompleteEnums.SearchProjection(params, projection)},
                    {$project: AutocompleteEnums.SearchProximityProjection(projection)},
                    {$group: AutocompleteEnums.RepackGroup(projection)},
                    {$project: AutocompleteEnums.RepackProjection(projection)},
                    {$sort: {ProximityScore: -1, Name: 1}},
                    {$skip: parseInt(params.Skip, 10) || 0},
                    {$limit: parseInt(params.Take, 10) || 10}
                ]
            };
        },
        MemberAccountBalance: function (params) {
            var result = autoCompleteTypeMap.MemberAccountBalance_Internal(params);
            result.Custom = 'MemberAccountBalance';
            return result;
        },
        MemberWithCreditReport: function (params) {
            var result = autoCompleteTypeMap.MemberAccountBalance_Internal(params);
            result.Custom = 'MemberWithCreditReport';
            if (params.SortField && params.SortDirection) {
                result.AggregateParams.forEach(function (item) {
                    if (item.hasOwnProperty('$sort')) {
                        item.$sort[params.SortField] = params.SortDirection;
                    }
                });
            }
            return result;
        },
        SurveyDriver_Internal: function (params) {
            var query = {};
            if (params.PreSelectedId) {
                query.hgId = { $in: params.PreSelectedId };
            } else {
                query = {
                    $or: [
                        { Name: {$regex: params.SearchTerm, $options: 'i'} }
                    ]
                };
                if (params.Status.length === 1) {
                    query.Status = params.Status[0];
                } else if (params.Status.length > 1) {
                    query.Status = { $in: params.Status};
                } else {
                    query.Status = 'Active';
                }
                if (params.Excluded.length) {
                    query.hgId = { $nin: params.Excluded};
                }
                query.GroupId = (params.GroupId) ? {$in: [null, params.GroupId]} : null;
            }
            return {
                EntityType: AutocompleteEnums.Entity.SurveyDriver,
                Query: query,
                Projection: {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$Name',
                    Description: '$Description',
                    Type: {$concat: ['SurveyDriver']}
                },
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        },
        ProvSurveyDriver: function (params) {
            delete params.GroupId;
            return autoCompleteTypeMap.SurveyDriver_Internal(params);
        },
        SurveyDriver: function (params) {
            return autoCompleteTypeMap.SurveyDriver_Internal(params);
        },
        GoalCycles: function (params) {
            var query = {};
            if (params.PreSelectedId) {
                query.hgId = {$in: params.PreSelectedId};
            } else {
                query = {
                    GroupId: params.GroupId,
                    Title: {$regex: params.SearchTerm, $options: 'i'}
                };
                if (params.Excluded.length) {
                    query.hgId = {$nin: params.Excluded};
                }
                if (params.Status.length === 1) {
                    query.Status = params.Status[0];
                } else if (params.Status.length > 1) {
                    query.Status = { $in: params.Status};
                } else {
                    query.Status = GoalEnums.CycleStatus.InProgress;
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.GoalCycle,
                Query: query,
                Projection: {
                    _id: 0,
                    Id: '$hgId',
                    hgId: '$hgId',
                    Name: '$Title',
                    Description: '$Title',
                    Type: {$concat: ['OpenGoalCycles']},
                    Start: "$CreatedDate",
                    End: "$ClosePromptDate"
                },
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        },
        FeedbackCycles: function (params) {
            var query = {};
            if (params.PreSelectedId) {
                query.hgId = {$in: params.PreSelectedId};
            } else {
                query = {
                    GroupId: params.GroupId,
                    Status: {
                        $in: [
                            FeedbackEnums.CycleStatus.InProgress,
                            FeedbackEnums.CycleStatus.Closed
                        ]
                    },
                    Title: {$regex: params.SearchTerm, $options: 'i'}
                };
                if (params.Excluded.length) {
                    query.hgId = {$nin: params.Excluded};
                }
            }
            return {
                EntityType: AutocompleteEnums.Entity.FeedbackCycle,
                Query: query,
                Projection: {
                    _id: 0,
                    Id: '$hgId',
                    hgId: '$hgId',
                    Name: '$Title',
                    Description: '$Description',
                    Type: {$concat: ['FeedbackCycles']}
                },
                Sort: {Name: params.SortDirection || 1},
                Skip: parseInt(params.Skip, 10) || 0,
                Take: parseInt(params.Take, 10) || 0
            };
        }
    },
    availableTypes = [
        'Group',
        'Member',
        'PublicTeam',
        'Team',
        'Department',
        'Manager',
        'MemberAndDepartment',
        'MemberAndLocation',
        'MemberAndDepartmentandLocation',
        'MemberAndDepartmentandLocationFavorite',
        'CreditAdmins',
        'MembersWithDirectReports',
        'Location',
        'MemberWithCreditReport',
        'MobileMember',
        'MobileDepartment',
        'MobileLocation',
        'MobileMemberAndDepartment',
        'MobileMemberAndDepartmentAndLocationFavorite',
        'SurveyDriver',
        'ProvSurveyDriver',
        'MemberAccountBalance',
        'GoalCycles',
        'FeedbackCycles'
    ];
module.exports = {
    AutoCompleteTypeMap: autoCompleteTypeMap,
    AvailableTypes: availableTypes
};
