/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    AutoComplete = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var QueryTypeMap = require('./AutoCompleteTypeMap.js').AutoCompleteTypeMap,
            AutoCompleteQueryProcessor = require('./AutoCompleteQueryProcessor.js'),
            AutoCompleteCustomQuery = require('./AutoCompleteCustomQuery.js'),
            Async = require('async');
        function executeQuery(params, fcallback) {
            var customQuery,
                tasks = [],
                results = [];
            if (params.Custom) {
                customQuery =  new AutoCompleteCustomQuery();
                customQuery[params.Custom](params, fcallback);
            } else if (!Array.isArray(params)) {
                AutoCompleteQueryProcessor.ExecuteQuery(params, fcallback);
            } else {
                params.forEach(function (item) {
                    tasks.push(function (callback) {
                        AutoCompleteQueryProcessor.ExecuteQuery(item, callback);
                    });
                });
                Async.parallel(tasks, function (error, data) {
                    if (error) {
                        return fcallback(error);
                    }
                    data.map(function (rItem) {
                        results = results.concat(rItem);
                    });
                    fcallback(null, results);
                });
            }
        }
        this.Lookup = function (params, callback) {
            executeQuery(QueryTypeMap[params.Type](params), callback);
        };
    };

module.exports = AutoComplete;