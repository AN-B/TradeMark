/*jslint node:true es5:true*/
var AutoCompleteCustomQuery = function () {
    'use strict';
    var EntityCache = require('../../framework/EntityCache.js'),
        AccountTypeEnums = require('../../enums/AccountType'),
        MemberEnums = require('../../enums/MemberEnums'),
        AutoCompleteQueryProcessor = require('./AutoCompleteQueryProcessor.js');

    this.DirectReport = function (params, callback) {
        AutoCompleteQueryProcessor.ExecuteQuery(params, function (error, data) {
            var directReportIndex = {},
                projection = {
                    _id: 0,
                    Id: '$hgId',
                    Name: '$FullName',
                    FirstName: '$FirstName',
                    LastName: '$LastName',
                    FullName: '$FullName',
                    UserId: '$UserId',
                    AvatarId: '$UserId',
                    Description: '$GroupDepartmentName',
                    Role: '$RolesInGroup',
                    Type: {$concat : ['MembersWithDirectReports']}
                };
            if (error) {
                return callback(error);
            }
            if (!data || data.length === 0) {
                return callback(null, []);
            }
            data.forEach(function (item) {
                directReportIndex[item.Id[0]] = item.DRCount;
            });
            if (params.ExtendedFields.length > 0) {
                params.ExtendedFields.forEach(function (field) {
                    projection[field] = ['$', field].join('');
                });
            }
            EntityCache.Member.aggregate([
                {$match: {
                    hgId: { $in: data.map(function (item) { return item.Id[0]; })},
                    MembershipStatus: MemberEnums.Status.Active
                }},
                {$project: projection},
                {$sort: {Name: 1}}],
                function (error, result) {
                    if (error) {
                        return callback(error);
                    }
                    result.forEach(function (item) {
                        item.DirectReports =  directReportIndex[item.Id] || 0;
                    });
                    callback(null, result);
                });
        });
    };
    function getMemberAccountBalance(params, callback) {
        AutoCompleteQueryProcessor.ExecuteQuery(params, function (error, members) {
            if (error) {
                return callback(error);
            }
            if (!members || !members.length) {
                return callback(null, []);
            }
            var i,
                length,
                filteredMember,
                ownerIdIds = [],
                memberFilter = function (member) {
                    return member.Id === this.OwnerId || member.UserId === this.OwnerId;
                };
            ownerIdIds = ownerIdIds.concat(members.map(function (item) { return item.Id; }));
            ownerIdIds = ownerIdIds.concat(members.map(function (item) { return item.UserId; }));
            EntityCache.CreditAccount.aggregate([
                {$match: {
                    OwnerId: { $in: ownerIdIds},
                    AccountType: {$in: [
                        AccountTypeEnums.PointSpend,
                        AccountTypeEnums.PointTransfer,
                        AccountTypeEnums.Spend,
                        AccountTypeEnums.Transfer
                    ]}
                }},
                {$project: {
                    _id: 0,
                    Balance: '$Balance',
                    AccountType: '$AccountType',
                    OwnerId: '$OwnerId'
                }}
            ], function (err, accounts) {
                if (err) {
                    return callback(err);
                }
                for (i = 0, length = accounts.length; i < length; i += 1) {
                    filteredMember = members.filter(memberFilter, accounts[i]);
                    if (filteredMember.length === 1) {
                        filteredMember[0][accounts[i].AccountType] = accounts[i].Balance;
                    }
                }
                callback(null, members);
            });
        });
    }
    this.MemberAccountBalance = function (params, callback) {
        getMemberAccountBalance(params, callback);
    };
    this.MemberWithCreditReport = function (params, callback) {
        var response = {
                groupMembers: []
            },
            compareFilteredMember = function (member) {
                return member.MemberId === this.OwnerId;
            };
        AutoCompleteQueryProcessor.ExecuteQuery(params, function (error, members) {
            var i,
                len,
                length,
                account,
                filteredMember,
                member;
            if (error) {
                return callback(error);
            }
            if (!members || members.length === 0) {
                return callback(null, response);
            }
            for (i = 0, len = members.length; i < len; i += 1) {
                member = members[i];
                response.groupMembers.push({
                    MemberId: member.Id,
                    UserId: member.UserId,
                    FullName: member.FullName,
                    Role: member.RolesInGroup && member.RolesInGroup.length === 1 ? member.RolesInGroup[0] : '',
                    PointSpend: 0,
                    PointTransfer: 0,
                    IssuePoints: 0
                });
            }
            EntityCache.CreditAccount.aggregate([
                {$match : {
                    OwnerId : { $in : members.map(function (item) {return item.Id; })},
                    AccountType: {$in: [AccountTypeEnums.PointSpend, AccountTypeEnums.PointTransfer]}
                }
                    },
                {$project : {
                    _id : 0,
                    Balance : '$Balance',
                    AccountType : '$AccountType',
                    Type : {$concat : ['CreditReport']},
                    OwnerId : '$OwnerId'
                }},
                {$sort : {Name : 1}}],
                function (err, accounts) {
                    if (err) {
                        return callback(err);
                    }
                    for (i = 0, length = accounts.length; i < length; i += 1) {
                        account = accounts[i];
                        filteredMember = response.groupMembers.filter(compareFilteredMember, account);
                        if (filteredMember && filteredMember.length === 1) {
                            filteredMember[0][account.AccountType] = account.Balance;
                        }
                    }
                    callback(null, response);
                });
        });
    };
};

module.exports = AutoCompleteCustomQuery;