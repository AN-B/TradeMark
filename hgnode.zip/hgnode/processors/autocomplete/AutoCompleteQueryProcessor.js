/*jslint node:true es5:true*/
'use strict';
var EntityCache = require('../../framework/EntityCache.js');

function executeQuery(params, callback) {
    var aggregateParams;
    if (params.AggregateParams) {
        aggregateParams = params.AggregateParams;
    } else {
        aggregateParams = [
            {$match: params.Query || {}},
            {$project: params.Projection || {}},
            {$sort: params.Sort || {}},
            {$skip: parseInt(params.Skip, 10) || 0}
        ];
        if (params.Group) {
            aggregateParams.splice(1, 0, {$group: params.Group});
        }
        if (params.Take) {
            aggregateParams.push({$limit: parseInt(params.Take, 10) || 10});
        }
    }
    EntityCache[params.EntityType].aggregate(aggregateParams, function (error, data) {
        if (error) {
            return callback(error);
        }
        if (params.PostDataProcess) {
            data = params.PostDataProcess(data);
        }
        callback(null, data);
    });
}

module.exports = {
    ExecuteQuery: executeQuery
};