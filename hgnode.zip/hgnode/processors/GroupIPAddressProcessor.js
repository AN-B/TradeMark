/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    GroupIPAddressProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            guid = require('node-uuid'),
            ipAddressHelper = require('../helpers/ipAddressHelper.js'),
            nodeIp = require('ip'),
            self = this;

        function addIPAddress(params, callback) {
            var ipAddressInfo = new EntityCache.GroupIPAddress({
                hgId : guid.v1(),
                GroupId : params.GroupId,
                IPRange : params.IPRange,
                CreatedBy : params.UserId,
                ModifiedBy : params.UserId,
                CreatedDate : new Date().getTime(),
                ModifiedDate : new Date().getTime()
            });
            ipAddressInfo.save(function (error) {
                callback(error, 'groupIPAddress.msg.uds');
            });
        }
        function isIPPrivate(ipaddresses) {
            var i,
                len = ipaddresses.length,
                ret;
            for (i = 0; i < len; i += 1) {
                if (nodeIp.isPrivate(ipaddresses[i])) {
                    ret = true;
                    break;
                }
            }
            return ret;
        }
        function validateIPRange(params, callback) {
            var ipAddresses = [];
            if (params.IPRange.length === 0) {
                return callback();
            }
            params.IPRange.forEach(function (item) {
                if (item.Start) {
                    ipAddresses.push(item.Start);
                }
                if (item.End) {
                    ipAddresses.push(item.End);
                }
            });
            if (ipAddresses.length > 0 && isIPPrivate(ipAddresses)) {
                callback('groupIPAddress.msg.pia');
            } else {
                callback();
            }
        }
        this.IsClientIPAllowed = function (params, callback) {
            if (!params || !params.SId) {
                return callback('groupIPAddress.msg.mci');
            }
            self.GetIPAddressById({hgId : params.SId}, function (error, data) {
                if (error) {
                    return callback(error);
                }
                if (!data) {
                    return callback('groupIPAddress.msg.uci');
                }
                params.GroupSettings = data;
                if (ipAddressHelper.validClientIP(params)) {
                    callback(null, {GroupId : data.GroupId});
                } else {
                    callback('groupIPAddress.msg.adi');
                }
            });
        };
        this.SaveIPAddress = function (params, callback) {
            validateIPRange(params, function (error, result) {
                if (error) {
                    return callback(error);
                }
                EntityCache.GroupIPAddress.findOne({GroupId : params.GroupId}, function (error, data) {
                    if (error) {
                        callback(error);
                    } else if (!data) {
                        addIPAddress(params, callback);
                    } else {
                        EntityCache.GroupIPAddress.update({GroupId : params.GroupId}, {
                            $set : {
                                ModifiedBy : params.UserId,
                                ModifiedDate : new Date().getTime(),
                                IPRange : params.IPRange
                            }
                        }, function (error, data) {
                            callback(error, 'groupIPAddress.msg.uds');
                        });
                    }
                });
            });
        };
        this.GetIPAddressByGroupId = function (params, callback) {
            EntityCache.GroupIPAddress.findOne({GroupId : params.GroupId}, callback);
        };
        this.GetIPAddressById = function (params, callback) {
            EntityCache.GroupIPAddress.findOne({hgId : params.hgId}, callback);
        };
    };

module.exports = GroupIPAddressProcessor;
