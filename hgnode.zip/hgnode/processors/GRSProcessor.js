var HgBaseProcessor = require('../framework/HgProcessor.js'),
    GRSProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            HgLog = require('../framework/HgLog.js');

        this.InsertGRSOrder = function (params, callback) {
            var order = new EntityCache.GRSOrder({
                    MemberPIN: params.order.pin,
                    MemberHgId: params.order.employeeId,
                    MemberFirstName: params.order.firstName,
                    MemberLastName: params.order.lastName,
                    ShippingCompany: params.order.shipCompany,
                    ShippingAddress1: params.order.shipAddress1,
                    ShippingAddress2: params.order.shipAddress2,
                    ShippingCity: params.order.shipCity,
                    ShippingState: params.order.shipProvinceState,
                    ShippingCountry: params.order.shipCountry,
                    ShippingPostalCode: params.order.shipPostal,
                    ShippingTelephone: params.order.shipTelephone,
                    ShippingEmail: params.order.shipEmail,
                    BusinessAddress: params.order.businessAddress,
                    OrderNumber: params.order.orderNumber,
                    PointsPurchased: params.order.pointsPurchased,
                    PointsPurchasedCost: params.order.pointsPurchasedCost,
                    PointsPurchasedCurrency: params.order.pointsPurchasedCurrency,
                    TotalPointCost: params.order.totalPointCost,
                    OrderItems: []
                });

            params.order.orderItems.map(function (orderItem) {
                order.OrderItems.push({
                    LineItemId: orderItem.lineItemId,
                    OrderId: orderItem.orderId,
                    OrderedAt: orderItem.orderedAt,
                    ProductName: orderItem.name,
                    ProductDescription: orderItem.description,
                    Quantity: orderItem.quantity,
                    PointCost: orderItem.pointCost
                });
            });

            order.save(function (err) {
                if (err) {
                    HgLog.error('Error saving GRS Order', err);
                    return callback(err);
                }
                callback();
            });
        };
    };

module.exports = GRSProcessor;