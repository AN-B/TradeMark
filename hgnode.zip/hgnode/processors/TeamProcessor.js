/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    TeamProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EventEmitterCache = this.EventEmitterCache,
            config = require('../configurations/config.js'),
            PusherManager = require('../util/PusherManager'),
            guid = require('node-uuid'),
            EventResponder = require('../util/EventResponder.js'),
            FileHelper = require('../util/FileHelper.js'),
            ProcessorHelper = require('../util/ProcessorHelper.js'),
            fileUpload = require('../helpers/fileUpload.js'),
            Async = require('async'),
            arrayUtil = require('../util/arrayUtil.js'),
            EntityEnums = require('../enums/EntityEnums.js'),
            HgLog = require('../framework/HgLog'),
            self = this,
            alreadyInTeam = function (team, teamMember) {
                var i,
                    len;
                for (i = 0, len = team.TeamMembers.length; i < len; i += 1) {
                    if (team.TeamMembers[i].TeamId === teamMember.TeamId && team.TeamMembers[i].MemberId === teamMember.MemberId) {
                        return true;
                    }
                }
                return false;
            },
            copyTeamDefaultAvatar = function (copyParam) {
                if (process.env.NODE_ENV === 'test') {
                    return;
                }
                fileUpload.copyUserDefaultAvatar({
                    request: {
                        srcFilePath: FileHelper.AppRootPath + '/' + config.filepath.Provision + '/default_team_avatar.jpg',
                        destFilePath: FileHelper.AppRootPath + '/' + config.filepath.ImageRoot,
                        source: config.s3store.defaultAvatars + 'default_team_avatar.jpg',
                        dest: config.filepath.TeamProfile  + copyParam.teamId + '.jpg'
                    }
                });
            },
            copyLocationDefaultAvatar = function (copyParam) {
                if (process.env.NODE_ENV === 'test') {
                    return;
                }
                fileUpload.copyUserDefaultAvatar({
                    request: {
                        srcFilePath: FileHelper.AppRootPath + '/' + config.filepath.Provision + '/default_location_avatar.jpg',
                        destFilePath: FileHelper.AppRootPath + '/' + config.filepath.ImageRoot,
                        source: config.s3store.defaultAvatars + 'default_location_avatar.jpg',
                        dest: config.filepath.TeamProfile  + copyParam.teamId + '.jpg'
                    }
                });
            },
            getDepartmentsUpByTeamId = function (params, callback) {
                var departments = [],
                    recurseLevel = 20,
                    getParentDepartment = function (teamId, finalCallback) {
                        EntityCache.Team.findOne({
                            GroupId: params.GroupId,
                            Status: EntityEnums.TeamStatus.Active,
                            Type: EntityEnums.TeamType.Department,
                            'ChildTeams.TeamId': teamId
                        }, function (error, team) {
                            if (!error && team && recurseLevel > 0) {
                                departments.push(team);
                                recurseLevel -= 1;
                                getParentDepartment(team.hgId, finalCallback);
                            } else {
                                finalCallback(null, departments);
                            }
                        });
                    };
                getParentDepartment(params.TeamId, callback);
            },
            getNestedDepartments = function (params, callback) {
                var departmentIds = [],
                    recurseLevel = 20,
                    getChildDepartments = function (teamIds, innerCallback) {
                        EntityCache.Team.find({
                            GroupId: params.GroupId,
                            hgId: {$in: teamIds},
                            Status: EntityEnums.TeamStatus.Active,
                            Type: EntityEnums.TeamType.Department
                        }, function (error, teams) {
                            var childTeamIds = [];
                            if (error || !teams.length || recurseLevel < 1) {
                                return innerCallback(null, departmentIds);
                            }
                            recurseLevel -= 1;
                            //teams are found
                            departmentIds = departmentIds.concat(teams.map(function (team) {
                                return team.hgId;
                            }));
                            teams.forEach(function (team) {
                                childTeamIds = childTeamIds.concat(team.ChildTeams.map(function (ct) {
                                    return ct.TeamId;
                                }));
                            });
                            if (!childTeamIds.length) {
                                return innerCallback(null, departmentIds);
                            }
                            getChildDepartments(childTeamIds, innerCallback);
                        });
                    };
                getChildDepartments(params.TeamIds, callback);
            },
            updateTeamMembers = function (params, callback) {
                var team = params.team;
                EntityCache.Member.find({hgId : {$in : params.MemberIds}}, function (err, members) {
                    if (err) {
                        return callback(err);
                    }
                    team.TeamMembers = members.map(function (member) {
                        return {
                            TeamId: team.hgId,
                            MemberFullName: member.FullName,
                            MemberId: member.hgId
                        };
                    });
                    callback(null, team);
                });
            },
            updateChildTeams = function (params, callback) {
                var team = params.team;
                EntityCache.Team.find({hgId: {$in: params.ChildTeamIds}, Status: {$ne : 'Deleted'}}, function (err, childTeams) {
                    var i,
                        j,
                        jlen,
                        ilen,
                        existingMembers;

                    if (err) {
                        return callback(err);
                    }
                    existingMembers = team.TeamMembers.map(function (member) {
                        return member.MemberId;
                    });
                    team.ChildTeams = [];
                    for (i = 0, ilen = childTeams.length; i < ilen; i += 1) {
                        team.ChildTeams.push({
                            TeamId: childTeams[i].hgId,
                            TeamName: childTeams[i].Name
                        });
                        for (j = 0, jlen = childTeams[i].TeamMembers.length; j < jlen; j += 1) {
                            if (existingMembers.indexOf(childTeams[i].TeamMembers[j].MemberId) === -1) {
                                existingMembers.push(childTeams[i].TeamMembers[j].MemberId);
                                team.TeamMembers.push({
                                    TeamId: childTeams[i].TeamMembers[j].TeamId,
                                    MemberFullName: childTeams[i].TeamMembers[j].MemberFullName,
                                    MemberId: childTeams[i].TeamMembers[j].MemberId
                                });
                            }
                        }
                    }
                    callback(null, team);
                });
            };
        this.DefaultEntityName = 'Team';

        this.GetNestedDepartments = function (params, callback) {
            EntityCache.Team.find({
                GroupId: params.GroupId,
                hgId: {$in: params.TeamIds},
                Status: EntityEnums.TeamStatus.Active,
                Type: EntityEnums.TeamType.Department
            }, function (error, teams) {
                if (error) {
                    return callback(error);
                }
                if (!teams.length) {
                    return callback("services.int.tea.iti");
                }
                getNestedDepartments({
                    GroupId: params.GroupId,
                    TeamIds: teams.map(function (team) {
                        return team.hgId;
                    })
                }, function (error, nestedDpartments) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, nestedDpartments);
                });
            });
        };

        this.GetDepartmentsUpByMemberId = function (params, callback) {
            var deptsUp = [],
                levelUp = 1;
            EntityCache.Team.findOne({
                GroupId: params.GroupId,
                'TeamMembers.MemberId': params.MemberId,
                Status: EntityEnums.TeamStatus.Active,
                Type: EntityEnums.TeamType.Department
            }, function (error, team) {
                if (error) {
                    return callback(error);
                }
                if (!team) {
                    return callback(null, []);
                }
                getDepartmentsUpByTeamId({GroupId: params.GroupId, TeamId: team.hgId}, function (error, departmentsUp) {
                    if (error) {
                        return callback(error);
                    }
                    deptsUp.push({
                        TeamId: team.hgId,
                        TeamName: team.Name,
                        LevelUp: levelUp
                    });
                    departmentsUp.forEach(function (d) {
                        levelUp += 1;
                        deptsUp.push({
                            TeamId: d.hgId,
                            TeamName: d.Name,
                            LevelUp: levelUp
                        });
                    });
                    callback(null, deptsUp);
                });
            });
        };

        this.GetTeamsByTeamGoalOwner = function (params, callback) {
            EntityCache.Team.find({
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active,
                'GoalOwner.MemberId': params.MemberId
            }, callback);
        };

        this.RemoveTeamGoalOwner = function (params, callback) {
            EntityCache.Team.update({hgId: params.TeamId}, {$set: {GoalOwner: null}}, callback);
        };

        this.GetDepartmentsForMembers = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active,
                'TeamMembers.MemberId': {$in: params.MemberIds}
            };
            EntityCache.Team.find(condition, callback);
        };
        //used in provision
        this.GetTeamsByName = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                Status: EntityEnums.TeamStatus.Active,
                Type: params.Type,
                Name: { $in: params.TeamNames}
            };
            EntityCache.Team.find(condition, callback);
        };
        this.CheckDuplicateNameCodeInGroup = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                Status: EntityEnums.TeamStatus.Active,
                Type: EntityEnums.TeamType.Location,
                $or: [
                    {Name: {$regex: params.Name, $options: 'i'} }
                ]
            };
            if (params.LocationCode) {
                condition.$or.push({LocationCode: params.LocationCode});
            }
            //for editing
            if (params.hgId) {
                condition.hgId = {$ne: params.hgId};
            }
            EntityCache.Team.count(condition, function (error, count) {
                if (error || count > 0) {
                    return callback(null, true);
                }
                return callback(null, false);
            });
        };

        this.SetGoalOwner = function (params, callback) {
            var goalOwner = {
                MemberId: params.GoalOwnerMemberId,
                UserId: params.GoalOwnerUserId,
                FullName: params.GoalOwnerFullName,
                Title: params.GoalOwnerTitle
            };
            EntityCache.Team.update({hgId: params.TeamId}, {$set: {GoalOwner: goalOwner}}, function (error) {
                callback(error, 'goal.prc.elg');
            });
        };

        this.RemoveGoalOwner = function (params, callback) {
            EntityCache.Team.update({hgId: params.TeamId}, {$set: {GoalOwner: {
                MemberId: null,
                UserId: null,
                FullName: null,
                Title: null
            }}}, function (error) {
                callback(error, 'team.int.msg.gor');
            });
        };

        this.GetMemberDepartment = function (params, callback) {
            var condition = {
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active,
                'TeamMembers.MemberId': params.MemberId
            };
            EntityCache.Team.findOne(condition, function (error, team) {
                if (error) {
                    return callback(error);
                }
                if (!team) {
                    return callback(null, {});
                }
                return callback(null, team);
            });
        };

        this.GetLocationsByGroupId = function (params, callback) {
            var condition = {GroupId: params.GroupId, Type: EntityEnums.TeamType.Location, Status: EntityEnums.TeamStatus.Active};
            if (params.Search && params.Search.length > 0) {
                condition.$or = [{
                    Name: new RegExp(params.Search.replace(/([.*?=+&#!:${}()|\[\]\/\\\^\+])/g, "\\$1"), "i")
                }];
            }
            EntityCache.Team.find(condition).sort({ Name: 1 }).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(callback);
        };

        this.GetDepartmentByDepartmentId = function (params, callback) {
            var projection = {};
            if (params.Fields) {
                projection = params.Fields;
            }
            EntityCache.Team.findOne({
                hgId: params.DepartmentId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active
            }, projection, callback);
        };
        this.GetDepartmentNamesByGroupId = function (params, callback) {
            EntityCache.Team.find({
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active
            }, {
                _id: 0,
                hgId: 1,
                Name: 1
            }, {sort: {
                Name: 1
            }}).skip(parseInt(params.Skip, 10) || 0).limit(parseInt(params.Take, 10) || 0).exec(function (error, departments) {
                return callback(error, departments);
            });
        };
        this.GetDepartmentsByGroupId = function (params, callback) {
            EntityCache.Team.find({
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active
            })
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetDepartmentsAutocomplete = function (params, callback) {
            EntityCache.Team.find({
                GroupId: params.groupId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active,
                Name:  new RegExp(params.search, "i")
            }, null, {
                sort: {
                    Name: 1
                }
            }).skip(parseInt(params.skip, 10) || 0).limit(parseInt(params.take, 10) || 0).exec(function (error, departments) {
                callback(error, departments);
            });
        };
        this.GetLocationsAutocomplete = function (params, callback) {
            EntityCache.Team.find({
                GroupId: params.groupId,
                Type: EntityEnums.TeamType.Location,
                Status: EntityEnums.TeamStatus.Active,
                Name: new RegExp(params.search, "i")
            }, null, {
                sort: {
                    Name: 1
                }
            }).skip(parseInt(params.skip, 10) || 0).limit(parseInt(params.take, 10) || 0).exec(callback);
        };

        this.GetTeamsByGroupIdCount = function (params, callback) {
            EntityCache.Team.count({
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active
            }, callback);
        };

        this.DeleteLocation = function (params, callback) {
            EntityCache.Team.update({hgId: params.LocationId}, {$set: {Status: EntityEnums.TeamStatus.Deleted}}, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, 'Location deleted');
            });
        };

        this.DeleteDepartment = function (params, callback) {
            EntityCache.Team.findOne({hgId: params.ItemId, GroupId: params.GroupId}, function (err, department) {
                if (err) {
                    return callback(err);
                }
                if (!department) {
                    return callback('business.tea.pro.elo');
                }
                department.ModifiedBy = params.UserId;
                department.Status = EntityEnums.TeamStatus.Deleted;
                department.save(function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        EntityCache.Team.update({ChildTeams: { $elemMatch: { TeamId: params.ItemId }}, Status: {$ne: EntityEnums.TeamStatus.Deleted}},
                            {$pull: { ChildTeams: { TeamId: params.ItemId }}, $set: {ModifiedBy: params.UserId }},
                            { multi: true }, function (error) {
                                if (error) {
                                    callback(error);
                                } else {
                                    callback(null, 'business.tea.pro.ded');
                                }
                            });
                    }
                });
            });
        };

        this.DeleteTeam = function (params) {
            EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                if (err || !team) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'error loading team');
                    return;
                }
                if (team.OwnerId !== params.OwnerId) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'You have to be the team owner to do this operation');
                    return;
                }
                team.ModifiedBy = params.UserId;
                team.Status = EntityEnums.TeamStatus.Deleted;
                team.save();
                // pusher message should be moved to the internal service layer
                PusherManager.TeamUpdated({
                    team: team,
                    operation: "DELETE"
                });
                EventResponder.RespondWithData(EventEmitterCache, params, 'Team deleted');
            });
        };

        this.AssignTeamOwner = function (params) {
            EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                if (err || !team) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'error loading team');
                    return;
                }
                if (team.OwnerId !== params.OwnerId) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'You have to be the team owner to do this operation');
                    return;
                }
                EntityCache.Member.findOne({hgId: params.NewOwnerId}, function (err, member) {
                    if (err || !member) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'error loading member');
                        return;
                    }
                    team.OwnerId = member.hgId;
                    team.OwnerFullName = member.FullName;
                    team.ModifiedBy = params.UserId;
                    team.save();
                    // pusher message should be moved to the internal service layer
                    PusherManager.TeamUpdated({
                        team: team,
                        operation: "ASSIGNTEAMOWNER"
                    });
                    EventResponder.RespondWithData(EventEmitterCache, params, 'Team owner assigned');
                });
            });
        };

        this.LoadAncestorTeamIds = function (params) {
            EntityCache.Team.find({Type: EntityEnums.TeamType.Pod, 'ChildTeams.TeamId': params.TeamId, Status: {$ne: EntityEnums.TeamStatus.Deleted}}, function (err, teams) {
                var teamIds = [],
                    i,
                    len;
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'error loading teams');
                    return;
                }
                for (i = 0, len = teams.length; i < len; i += 1) {
                    teamIds.push(teams[i].hgId);
                }
                EventResponder.RespondWithData(EventEmitterCache, params, teamIds);
            });
        };

        this.RefreshTeam = function (params) {
            EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                var i,
                    j,
                    ilen,
                    jlen,
                    callback = params.Callback,
                    directMembers = [],
                    childTeamIds = [],
                    groupId = team.GroupId,
                    memberExists = function (teamembers, curMember) {
                        var mIndex;
                        for (mIndex = 0; mIndex < teamembers.length; mIndex += 1) {
                            if (teamembers[mIndex].TeamId === curMember.TeamId && teamembers[mIndex].MemberId === curMember.MemberId) {
                                return true;
                            }
                        }
                        return false;
                    };
                if (err || !team) {
                    if (callback) {
                        callback('RefreshTeam load failed', null);
                    }
                    return;
                }
                for (i = 0, ilen = team.TeamMembers.length; i < ilen; i += 1) {
                    if (team.TeamMembers[i].TeamId === team.hgId && !memberExists(directMembers, team.TeamMembers[i])) {
                        directMembers.push(team.TeamMembers[i]);
                    }
                }
                team.TeamMembers = directMembers;
                for (i = 0, ilen = team.ChildTeams.length; i < ilen; i += 1) {
                    childTeamIds.push(team.ChildTeams[i].TeamId);
                }
                EntityCache.Team.find({hgId: {$in: childTeamIds}, Status: {$ne: EntityEnums.TeamStatus.Deleted}}, function (err, childTeams) {
                    if (childTeams) {
                        for (i = 0, ilen = childTeams.length; i < ilen; i += 1) {
                            if (childTeams[i].GroupId === groupId) {
                                for (j = 0, jlen = childTeams[i].TeamMembers.length; j < jlen; j += 1) {
                                    if (!memberExists(team.TeamMembers, childTeams[i].TeamMembers[j])) {
                                        team.TeamMembers.push({
                                            TeamId: childTeams[i].TeamMembers[j].TeamId,
                                            MemberFullName: childTeams[i].TeamMembers[j].MemberFullName,
                                            MemberId: childTeams[i].TeamMembers[j].MemberId
                                        });
                                    }
                                }
                            }
                        }
                    }
                    team.save();
                    if (callback) {
                        callback(null, 'RefreshTeam done');
                    }
                });
            });
        };

        this.CreateLocation = function (params, callback) {
            var team = new EntityCache.Team(params);
            team.hgId = guid.v1();
            team.CreatedBy = params.UserId;
            team.ModifiedBy = params.UserId;
            team.save(function (error) {
                copyLocationDefaultAvatar({
                    teamId: team.hgId
                });
                callback(error, team);
            });
        };

        this.CreateLocations = function (params, callback) {
            if (!params.Locations || !params.Locations.length) {
                return callback(null, 'server.info.mem.madd');
            }
            params.Locations.forEach(function (location) {
                location.hgId = guid.v1();
            });
            return EntityCache.Team.insertMany(params.Locations, callback);
        };

        this.UpdateLocation = function (params, callback) {
            EntityCache.Team.findOne({hgId: params.hgId}, function (error, team) {
                if (error || !team || team.Status !==  EntityEnums.TeamStatus.Active || team.Type !== EntityEnums.TeamType.Location) {
                    return callback('business.tea.pro.ell');
                }
                team.Name = params.LocationName || params.Name;
                team.Description = params.Description;
                team.Address = params.Address;
                team.Phone = params.Phone;
                team.LocationCode = params.LocationCode;
                team.i18n = params.i18n;
                team.tz = params.tz;
                team.save(callback);
            });
        };

        this.SaveTeam = function (params, callback) {
            var team;
            if (!params.TeamId) {
                team = EntityCache.Team(params);
                team.hgId = guid.v1();
                team.CreatedBy = params.UserId;
                team.ModifiedBy = params.UserId;
                updateTeamMembers({
                    team: team,
                    MemberIds: params.MemberIds
                }, function (err, team) {
                    if (err) {
                        return callback(err);
                    }
                    updateChildTeams({
                        team: team,
                        ChildTeamIds: params.ChildTeamIds
                    }, function (err, team) {
                        if (err) {
                            return callback(err);
                        }
                        EntityCache.Team.find({Name: params.Name, GroupId: params.GroupId, Status: {$ne: EntityEnums.TeamStatus.Deleted}}, function (err, exist) {
                            if (exist && exist.length) {
                                return callback('services.int.tea.tne');
                            }
                            team.save(function (err) {
                                if (err) {
                                    return callback(err);
                                }
                                copyTeamDefaultAvatar({
                                    teamId: team.hgId
                                });
                                PusherManager.TeamUpdated({
                                    team: team,
                                    operation: "CREATE"
                                });
                                callback(null, team);
                            });
                        });
                    });
                });

            } else {
                EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                    if (err || !team) {
                        return callback('services.team.tdx');
                    }
                    updateTeamMembers({
                        team: team,
                        MemberIds: params.MemberIds
                    }, function (err, team) {
                        if (err) {
                            return callback(err);
                        }
                        updateChildTeams({
                            team: team,
                            ChildTeamIds: params.ChildTeamIds
                        }, function (err, team) {
                            if (err) {
                                return callback(err);
                            }
                            team.Name = params.Name;
                            team.Description = params.Description;
                            team.ModifiedBy = params.UserId;
                            team.IsPublic = params.IsPublic;
                            team.save(function (err) {
                                if (err) {
                                    return callback(err);
                                }
                                PusherManager.TeamUpdated({
                                    team: team,
                                    operation: "UPDATE"
                                });
                                callback(null, team);
                            });
                        });
                    });
                });
            }
        };
        this.ExcludeTeam = function (params) {
            EntityCache.Team.findOne({hgId: params.OriginalTeamId}, function (err, originalTeam) {
                var i,
                    len,
                    existingMembers = [];
                if (err || !originalTeam) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'Team not found');
                    return;
                }
                for (i = 0, len = originalTeam.ChildTeams.length; i < len; i += 1) {
                    if (originalTeam.ChildTeams[i].TeamId === params.ExcludeTeamId) {
                        originalTeam.ChildTeams.splice(i, 1);
                        break;
                    }
                }
                for (i = 0, len = originalTeam.TeamMembers.length; i < len; i += 1) {
                    existingMembers.push(originalTeam.TeamMembers[i]);
                }
                originalTeam.TeamMembers.length = 0;
                for (i = 0, len = existingMembers.length; i < len; i += 1) {
                    if (existingMembers[i].TeamId !== params.ExcludeTeamId) {
                        originalTeam.TeamMembers.push(existingMembers[i]);
                    }
                }
                originalTeam.ModifiedBy = params.userId;
                originalTeam.ModifiedDate = new Date().getTime();
                originalTeam.save(function (err) {
                    if (err) {
                        if (params.EventName) {
                            EventResponder.RespondWithError(EventEmitterCache, params, err);
                        } else {
                            params.Callback(err, null);
                        }
                        return;
                    }
                    PusherManager.TeamUpdated({
                        team: originalTeam,
                        operation: "EXCLUDETEAM"
                    });
                    if (params.EventName) {
                        EventResponder.RespondWithData(EventEmitterCache, params, originalTeam);
                    } else {
                        params.Callback(null, originalTeam);
                    }
                });
            });
        };

        this.AddMemberToTeamForProvision = function (params) {
            var callback = params.Callback;
            EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                if (err || !team) {
                    callback('Error loading team.');
                    return;
                }
                EntityCache.Member.findOne({hgId: params.MemberId}, function (err, member) {
                    var newTeamMember;
                    if (err || !member) {
                        callback('Error loading member.');
                        return;
                    }
                    newTeamMember = {
                        TeamId: team.hgId,
                        MemberFullName: member.FullName,
                        MemberId: member.hgId
                    };
                    if (!alreadyInTeam(team, newTeamMember)) {
                        team.TeamMembers.push(newTeamMember);
                    }
                    team.ModifiedBy = params.UserId;
                    team.ModifiedDate = new Date().getTime();
                    team.save(function (err) {
                        if (err) {
                            callback(err);
                            return;
                        }
                        callback();
                    });
                });
            });
        };

        this.SetOwnerForProvision = function (params) {
            var callback = params.Callback;
            EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                if (err || !team) {
                    callback('Error loading team.');
                    return;
                }
                if (team.OwnerId && team.OwnerId.length > 0) {//already has owner
                    callback(null);
                    return;
                }
                EntityCache.Member.findOne({hgId: params.OwnerId}, function (err, member) {
                    if (err || !member) {
                        callback('Error loading member.');
                        return;
                    }
                    team.OwnerId = member.hgId;
                    team.OwnerFullName = member.FullName;
                    team.save();
                    callback(null);
                });
            });
        };
        this.GetDepartmentsByMemberIds = function (params, callback) {
            EntityCache.Team.find({
                GroupId: params.GroupId,
                'TeamMembers.MemberId': {
                    $in: params.MemberId
                },
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active
            }, {}, {
                lean: true
            }).exec(function (err, departments) {
                if (err) {
                    callback('business.tea.pro.eld', null);
                } else {
                    callback(null, departments);
                }
            });
        };
        this.GetGroupPublicTeams = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Pod,
                Status: {$ne: EntityEnums.TeamStatus.Deleted},
                IsPublic: true
            };
            EntityCache.Team.find(query, callback);
        };
        this.GetTeamsByMemberId = function (params) {
            var queryMap = {
                    All: { Type: EntityEnums.TeamType.Pod, $or: [{'TeamMembers.MemberId': params.MemberId}, {IsPublic: true}], GroupId: params.GroupId, Status: {$ne: EntityEnums.TeamStatus.Deleted}},
                    MemberOnly: {Type: EntityEnums.TeamType.Pod, 'TeamMembers.MemberId': params.MemberId, GroupId: params.GroupId, Status: {$ne: EntityEnums.TeamStatus.Deleted}},
                    PublicOnly: {Type: EntityEnums.TeamType.Pod, IsPublic: true, GroupId: params.GroupId, Status: {$ne: EntityEnums.TeamStatus.Deleted}},
                    OwnOrBelong: {Type: EntityEnums.TeamType.Pod, $or: [{'TeamMembers.MemberId': params.MemberId}, {OwnerId: params.MemberId}], GroupId: params.GroupId, Status: {$ne: EntityEnums.TeamStatus.Deleted}},
                    TeamOnly: {Type: EntityEnums.TeamType.Pod, $or: [{'TeamMembers.MemberId': params.MemberId}, {IsPublic: true}], GroupId: params.GroupId, Status: {$ne: EntityEnums.TeamStatus.Deleted}},
                    TeamByMember: {Type: EntityEnums.TeamType.Department, 'TeamMembers.MemberId': params.MemberId, GroupId: params.GroupId, Status: EntityEnums.TeamStatus.Active}
                },
                query = queryMap[params.Filter];
            if (query) {
                EntityCache.Team.find(query).sort({Name: 1}).exec(function (err, teams) {
                    if (err) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'Error loading teams');
                    } else {
                        if (params.Callback) {
                            params.Callback(null, teams);
                        } else {
                            EventResponder.RespondWithData(EventEmitterCache, params, teams);
                        }
                    }
                });
            } else {
                EventResponder.RespondWithError(EventEmitterCache, params, 'Invalid filter selection: ' + params.Filter);
            }
        };

        this.GetTeamsByOwnerId = function (params) {
            var query = {
                    OwnerId: params.OwnerId,
                    GroupId: params.GroupId,
                    Status: {$ne: EntityEnums.TeamStatus.Deleted},
                    Type: EntityEnums.TeamType.Pod
                };
            EntityCache.Team.find(query, function (err, teams) {
                if (err) {
                    EventResponder.RespondWithError(EventEmitterCache, params, 'loading team error');
                    return;
                }
                EventResponder.RespondWithData(EventEmitterCache, params, teams.sort(arrayUtil.sortByName));
            });
        };

        this.GetTeamByIdCompact = function (params, callback) {
            EntityCache.Team.findOne({
                GroupId: params.GroupId,
                hgId: params.TeamId
            }, {
                hgId: true,
                Name: true,
                Description: true,
                Type: true,
                GoalOwner: true,
                Address: true,
                LocationCode: true,
                DepartmentCode: true,
                i18n: true,
                tz: true
            }, {
                lean: true
            }, callback);
        };

        this.GetTeamById = function (params, callback) {
            EntityCache.Team.findOne({GroupId: params.GroupId, hgId: params.TeamId}, function (err, team) {
                if (err || !team) {
                    callback('business.tea.pro.elt');
                    return;
                }
                callback(null, team);
            });
        };

        this.GetTeamMembers = function (params, callback) {
            EntityCache.Team.findOne({hgId: params.TeamId}, function (err, team) {
                var i,
                    len,
                    memberIds = [];
                if (err || !team) {
                    callback('business.tea.pro.elt');
                    return;
                }
                for (i = 0, len = team.TeamMembers.length; i < len; i += 1) {
                    if (memberIds.indexOf(team.TeamMembers[i].MemberId) === -1) {
                        memberIds.push(team.TeamMembers[i].MemberId);
                    }
                }
                if (params.Skip > 0 || params.Take > 0) {
                    memberIds = memberIds.slice(params.Skip, params.Take);
                }
                EntityCache.Member.find({hgId: {$in: memberIds}, MembershipStatus: EntityEnums.MembershipStatus.Active}, function (err, members) {
                    if (err || !members) {
                        return callback('business.tea.pro.elm');
                    }
                    callback(null, members);
                });
            });
        };
        this.GetMemberIdsForTeamIds = function (params, callback) {
            var memberIds = [],
                query = {
                    hgId:  {$in: params.TeamIds},
                    GroupId: params.GroupId,
                    Status: EntityEnums.TeamStatus.Active,
                    Type: params.TeamType || EntityEnums.TeamType.Pod
                },
                project = {
                    _id: 0,
                    'TeamMembers.MemberId': 1
                };
            EntityCache.Team.find(query, project, function (error, teams) {
                if (error) { return callback(error); }
                if (teams.length === 0) { return callback(null, []); }
                teams.forEach(function (item) {
                    item.TeamMembers.forEach(function (item) {
                        memberIds.push(item.MemberId);
                    });
                });
                callback(null, memberIds);
            });
        };
        // this method should be deprecated, should not be accessing Member Entity
        this.GetTeamsMembers = function (params) {
            if (!params.TeamIds || params.TeamIds.length === 0) {
                EventResponder.RespondWithData(EventEmitterCache, params, []);
            } else {
                EntityCache.Team.find({hgId:  {$in: params.TeamIds}, Status: {$ne: EntityEnums.TeamStatus.Deleted}}, function (err, teams) {
                    var i,
                        j,
                        ilen,
                        jlen,
                        memberIds = [],
                        team;
                    if (err || !teams) {
                        EventResponder.RespondWithError(EventEmitterCache, params, 'loading team error');
                        return;
                    }
                    for (j = 0, jlen = teams.length; j < jlen; j += 1) {
                        team = teams[j];
                        for (i = 0, ilen = team.TeamMembers.length; i < ilen; i += 1) {
                            if (memberIds.indexOf(team.TeamMembers[i].MemberId) === -1) {
                                memberIds.push(team.TeamMembers[i].MemberId);
                            }
                        }
                    }
                    EntityCache.Member.find({hgId: {$in: memberIds}}, function (err, members) {
                        if (err || !members) {
                            EventResponder.RespondWithError(EventEmitterCache, params, 'loading member error');
                            return;
                        }
                        EventResponder.RespondWithData(EventEmitterCache, params, members);
                    });
                });
            }
        };

        this.GetTeamsByIds = function (params, callback) {
            EntityCache.Team.find({hgId: {$in: params.TeamIds}}, params.Fields || {}, function (err, teams) {
                if (err || !teams) {
                    callback('business.tea.pro.lte');
                } else {
                    callback(null, teams.sort(arrayUtil.sortByName));
                }
            });
        };

        this.RemoveMembersFromTeams = function (params, callback) {
            var filterQuery = {'TeamMembers.MemberId':  { $in: params.MemberIds},  Status: {$ne: EntityEnums.TeamStatus.Deleted}},
                updateQuery = { TeamMembers: { MemberId: { $in: params.MemberIds} }},
                modifiedQuery = { ModifiedDate: new Date().getTime(), ModifiedBy: params.UserId};
            EntityCache.Team.update(filterQuery, {$pull: updateQuery, $set: modifiedQuery}, {multi: true}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'Teams Updated');
                }
            });
        };

        this.GetGroupTeams = function (params, callback) {
            EntityCache.Team.find({GroupId: params.GroupId}, function (error, data) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, data);
                }
            });
        };

        this.RemoveTeams = function (params, callback) {
            EntityCache.Team.remove({hgId: {$in: params.TeamHgIds}}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'Teams Removed');
                }
            });
        };

        this.AddTeams = function (params, callback) {
            EntityCache.Team.insertMany(params.Teams, function (error) {
                if (error) {
                    return callback(error);
                }
                if (!params.CopyAvatar || params.CopyAvatar) {
                    params.Teams.map(function (team) {
                        if (!params.IsLocation) {
                            copyTeamDefaultAvatar({ teamId: team.hgId});
                        } else {
                            copyLocationDefaultAvatar({ teamId: team.hgId});
                        }
                    });
                }
                callback(null, 'Teams Added');
            });
        };

        this.AddMembersToTeam = function (params, callback) {
            function addMembers(teamMember, callback) {
                EntityCache.Team.update({hgId: teamMember.TeamId }, { $push: { TeamMembers: teamMember}, $set: {ModifiedDate: new Date().getTime(), ModifiedBy: params.UserId}}, function () {
                    callback();
                });
            }
            Async.each(params.TeamMembers, addMembers, function () {
                callback(null, 'Members added to Team');
            });
        };

        this.BulkAssignMembersToDepartments = function (params, callback) {
            var memberIds = [];
            params.Data.forEach(function (t) {
                t.teamMembers.forEach(function (d) {
                    memberIds.push(d.MemberId);
                });
            });
            EntityCache.Team.update({ GroupId: params.GroupId, Type: EntityEnums.TeamType.Department }, {
                $pull: {
                    TeamMembers: {
                        MemberId: {$in: memberIds}
                    }
                }
            }, { multi: true }, function (error) {
                if (error) {
                    return callback(error);
                }
                Async.each(params.Data, function (team, tCallback) {
                    EntityCache.Team.update({
                        hgId: team._id.DepartmentId
                    }, {
                        $addToSet: {
                            TeamMembers: {
                                $each: team.teamMembers || []
                            }
                        }
                    }, tCallback);
                }, callback);
            });
        };

        this.AssignMembersToDepartments = function (params, callback) {
            function removeUsersFromTeams(departmentMember, callback) {
                EntityCache.Team.update({
                    GroupId: params.GroupId,
                    Type: EntityEnums.TeamType.Department,
                    'TeamMembers.MemberId':  departmentMember.MemberId
                }, {
                    $pull: {
                        TeamMembers: {
                            MemberId: departmentMember.MemberId
                        }
                    }
                }, {
                    multi: true
                }, callback);
            }
            function addUserToTeam(departmentMember, callback) {
                EntityCache.Team.update({hgId: departmentMember.TeamId}, {
                    $addToSet: {
                        TeamMembers: departmentMember
                    },
                    $set: {
                        ModifiedBy: params.UserId
                    }
                }, callback);
            }
            if (!params.AllDepartmentMembers || !params.AllDepartmentMembers.length) {
                return callback();
            }
            Async.waterfall([
                function (fcallback) {
                    // remove users from the departments first
                    Async.eachSeries(params.AllDepartmentMembers, removeUsersFromTeams, fcallback);
                },
                function (fcallback) {
                    // add users to the department
                    Async.eachSeries(params.AllDepartmentMembers, addUserToTeam, fcallback);
                }
            ], function (error) {
                if (error) {
                    HgLog.error({methodName: 'AssignMembersToDepartments', error: error});
                }
                callback(error, 'server.info.team.matd');
            });
        };

        this.UpdateTeam = function (params, callback) {
            var fieldsToUpdate = ProcessorHelper.GetUpdateJson(params.Fields, params.Team, params.UserId);
            EntityCache.Team.update({hgId: params.Team.hgId}, {$set: fieldsToUpdate}, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'Team Updated');
                }
            });
        };

        this.UpdateTeams = function (params, callback) {
            function updateTeam(team, callback) {
                self.UpdateTeam({Fields: params.Fields, Team: team, UserId: params.UserId}, function (error) {
                    if (!error) {
                        callback();
                    }
                });
            }
            if (params.Teams && params.Teams.length > 0) {
                Async.each(params.Teams, updateTeam, function () {
                    callback(null, 'Team Updated');
                });
            } else {
                callback(null, 'Team Updated');
            }
        };
        this.GetTeamsByGroupId = function (params, callback) {
            EntityCache.Team.find({GroupId: params.GroupId}, function (err, data) {
                if (!err) {
                    callback(null, data);
                } else {
                    callback(err);
                }
            });
        };
        this.GetDepartmentByName = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Name: params.Name,
                Status: EntityEnums.TeamStatus.Active,
                Type: EntityEnums.TeamType.Department
            };
            EntityCache.Team.findOne(query, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    callback('business.tea.pro.dde');
                } else {
                    callback(null, data);
                }
            });
        };
        this.GetLocationByName = function (params, callback) {
            EntityCache.Team.findOne({
                GroupId: params.GroupId,
                Name: params.Name,
                Status: EntityEnums.TeamStatus.Active,
                Type: EntityEnums.TeamType.Location
            }, function (error, data) {
                if (error) {
                    callback(error);
                } else if (!data) {
                    callback('business.tea.pro.lde');
                } else {
                    callback(null, data);
                }
            });
        };
        this.AddDepartment = function (params, callback) {
            var department = new EntityCache.Team(params);
            department.save(function (error) {
                if (error) {
                    return callback(error);
                }
                copyTeamDefaultAvatar({teamId: department.hgId});
                callback(null, department);
            });
        };
        this.UpdateDepartment = function (params, callback) {
            EntityCache.Team.findOne({hgId: params.Team.hgId}, function (error, data) {
                if (error) { return callback(error); }
                if (!data) { return callback('Error loading Department'); }
                // only updating Name, description members and child teams
                data.Name = params.Team.Name;
                data.Description = params.Team.Description;
                data.TeamMembers = params.Team.TeamMembers;
                data.ChildTeams = params.Team.ChildTeams;
                data.ModifiedBy = params.UserId;
                data.save(function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        callback(null, 'Department Saved');
                    }
                });
            });
        };
        this.GetTeamIdsByMemberId = function (params, callback) {
            EntityCache.Team.find({
                'TeamMembers.MemberId': params.MemberId,
                Status: {
                    $ne: EntityEnums.TeamStatus.Deleted
                }
            }).distinct('hgId', function (err, teamIds) {
                callback(err, teamIds);
            });
        };
        this.GetMemberDepartment = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                'TeamMembers.MemberId': params.MemberId,
                Type: EntityEnums.TeamType.Department,
                Status: EntityEnums.TeamStatus.Active
            };
            EntityCache.Team.findOne(query, callback);
        };

        this.GetDepartmentIdByMemberId = function (params, callback) {
            EntityCache.Team.findOne({
                'TeamMembers.MemberId': params.MemberId,
                Status: {
                    $ne: EntityEnums.TeamStatus.Deleted
                },
                Type: EntityEnums.TeamType.Department
            }, {
                _id: 0,
                hgId: 1
            }, function (err, data) {
                data = data || {};
                callback(err, data.hgId);
            });
        };
        this.GetMemberIdsForDepartmentIds = function (params, callback) {
            var memberIds = [],
                query = {
                    hgId:  {$in: params.DepartmentIds},
                    GroupId: params.GroupId,
                    Status: EntityEnums.TeamStatus.Active,
                    Type: EntityEnums.TeamType.Department
                },
                project = {
                    _id: 0,
                    'TeamMembers.MemberId': 1
                };
            EntityCache.Team.find(query, project, function (error, teams) {
                if (error) { return callback(error); }
                if (teams.length === 0) { return callback(null, []); }
                teams.forEach(function (item) {
                    item.TeamMembers.forEach(function (item) {
                        memberIds.push(item.MemberId);
                    });
                });
                callback(null, memberIds);
            });
        };
        this.GetDepartmentsByIds = function (params, callback) {
            EntityCache.Team.find({
                hgId:  {$in: params.DepartmentIds},
                GroupId: params.GroupId,
                Status: EntityEnums.TeamStatus.Active,
                Type: EntityEnums.TeamType.Department
            }, params.Fields || {}, {sort: {Name: 1}}, callback);
        };
        this.TransferDepartmentOwner = function (params, callback) {
            EntityCache.Team.update({
                'GoalOwner.MemberId': params.FromMemberId
            }, {
                $set: {
                    ModifiedBy: params.UserId,
                    'GoalOwner.MemberId': params.ToMember.MemberId,
                    'GoalOwner.UserId': params.ToMember.UserId,
                    'GoalOwner.FullName': params.ToMember.FullName
                }
            }, {
                multi: true
            }, callback);
        };
        this.GetDepartmentOwnerCount = function (params, callback) {
            EntityCache.Team.count({
                'GoalOwner.MemberId': params.MemberId,
                Status: EntityEnums.TeamStatus.Active
            }, callback);
        };
        //specical method used in provision
        this.GetProvisionTeamData = function (params, callback) {
            var dKey = {};
            EntityCache.Team.find({
                GroupId: params.GroupId,
                Type: params.Type,
                Status: EntityEnums.TeamStatus.Active
            }, {
                _id: 0,
                hgId: 1,
                Name: 1,
                i18n: 1
            }, {
                lean: true
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    dKey[item.Name.toLowerCase()] = {
                        Id: item.hgId,
                        i18n: item.i18n || ''
                    };
                });
                callback(null, dKey);
            });
        };
        this.GetLocationByIds = function (params, callback) {
            var query = {
                hgId: { $in: params.LocationIds},
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Location
            };
            if (params.AddressRequired) {
                query.Address = {$exists: true};
            }
            EntityCache.Team.find({
                hgId: { $in: params.LocationIds},
                GroupId: params.GroupId,
                Type: EntityEnums.TeamType.Location
            }, params.Fields || {}, {sort: {Name: 1}}, callback);
        };
    };

module.exports = TeamProcessor;
