/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    SurveyProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../../framework/EntityCache.js'),
            Async = require('async'),
            guid = require('node-uuid'),
            config = require('../../configurations/config.js'),
            SurveyEnums = require('../../enums/SurveyEnums.js'),
            TemplateEnums = require('../../enums/TemplateEnums.js'),
            self = this;

        function canDeleteDriver(params, callback) {
            EntityCache.Survey.findOne({
                GroupId: params.GroupId,
                'Template.Type': SurveyEnums.Type.Benchmark
            }, function (error, survey) {
                if (error || !survey) {
                    return callback(error);
                }
                if (survey.Template.UberQuestion.Driver.hgId === params.hgId) {
                    return callback(JSON.stringify(['business.sur.pro.sdc', {driverName: survey.Template.UberQuestion.Driver.Name}]));
                }
                var usedDriver = survey.Template.DriverQuestions.filter(function (item) {
                    return item.Driver.hgId === params.hgId && item.Status !== SurveyEnums.QuestionStatus.Deleted;
                });
                if (usedDriver.length) {
                    return callback(JSON.stringify(['business.sur.pro.gdc', {driverName: usedDriver[0].Driver.Name, question: usedDriver[0].Question}]));
                }
                callback();
            });
        }
        this.AddSurveyDriver = function (params, callback) {
            var surveyDriver = EntityCache.SurveyDriver(params);
            surveyDriver.hgId = guid.v1();
            surveyDriver.CreatedBy = params.UserId;
            surveyDriver.ModifiedBy = params.UserId;
            surveyDriver.Status = SurveyEnums.SurveyDriverStatus.Active;
            if (params.GroupId) {
                surveyDriver.GroupId = params.GroupId;
            }
            surveyDriver.save(callback);
        };
        this.UpdateSurveyDriver = function (params, callback) {
            EntityCache.SurveyDriver.findOne({hgId: params.hgId}, function (error, surveyDriver) {
                if (error) {
                    return callback(error);
                }
                surveyDriver.ModifiedBy = params.UserId;
                surveyDriver.Name = params.Name;
                surveyDriver.Description = params.Description;
                surveyDriver.Status = params.Status || SurveyEnums.SurveyDriverStatus.Active;
                surveyDriver.save(callback);
            });
        };

        this.DeleteSurveyDriver = function (params, callback) {
            canDeleteDriver(params, function (error) {
                if (error) {
                    return callback(error);
                }
                EntityCache.SurveyDriver.update({
                    hgId: params.hgId
                }, {
                    $set: {
                        ModifiedBy: params.UserId,
                        Status: SurveyEnums.SurveyDriverStatus.Deleted
                    }
                }, callback);
            });
        };
        this.GetSurveyDriverById = function (params, callback) {
            EntityCache.SurveyDriver.findOne({hgId: params.hgId}, callback);
        };
        this.GetSurveyDriverByName = function (params, callback) {
            var query = {
                Name: new RegExp(params.Name, "i"),
                Status: SurveyEnums.SurveyDriverStatus.Active
            };
            query.GroupId = params.GroupSpecific ? { $in: [null, params.GroupId] } : null;
            EntityCache.SurveyDriver.findOne(query, callback);
        };
        this.GetSurveyDrivers = function (params, callback) {
            var query = {
                Status: SurveyEnums.SurveyDriverStatus.Active
            };
            query.GroupId = params.GroupId ? {
                $in: [null, params.GroupId]
            } : null;
            EntityCache.SurveyDriver.find(query, null, {sort: {Name: 1}}, callback);
        };
        this.GetBenchmarkSurveyComments = function (params, callback) {
            var query1 = {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId,
                    Status: { $in: [
                        SurveyEnums.SurveyAnswerStatus.InProgress,
                        SurveyEnums.SurveyAnswerStatus.Completed
                    ]},
                    Type: SurveyEnums.Type.Benchmark
                },
                query2 = {
                    "QandA.Comment": {$exists: true},
                };
            if (params.LimitResultByLocation && params.LocationId) {
                query1.LocationId = params.LocationId;
            }
            if (params.QuestionId) {
                query2["QandA.QuestionId"] = params.QuestionId;
            } else if (params.DriverId) {
                query2["QandA.DriverId"] = params.DriverId;
                query2["QandA.Order"] = {$gt: 0};
            } else {
                query2["QandA.Order"] = 0;
            }
            if (params.keyword) {
                query1["QandA.Comment"] = {$regex: params.keyword, $options: 'i'};
                query2["QandA.Comment"].$regex = params.keyword;
                query2["QandA.Comment"].$options = 'i';
            }
            Async.parallel({
                commentCount: function (fcallback) {
                    EntityCache.SurveyAnswer.aggregate([
                        { $match: query1},
                        { $unwind: "$QandA"},
                        { $match: query2}
                    ], function (error, data) {
                        fcallback(error, data.length || 0);
                    });
                },
                comments: function (fcallback) {
                    EntityCache.SurveyAnswer.aggregate([
                        { $match: query1},
                        { $unwind: "$QandA"},
                        { $match: query2},
                        { $skip: parseInt(params.Skip, 10) || 0},
                        { $limit: parseInt(params.Take, 10) || 10},
                        { $project: { _id: 0, QandA: 1}}
                    ], fcallback);
                }
            }, callback);
        };
        this.GetGroupSurvey = function (params, callback) {
            EntityCache.Survey.findOne({GroupId: params.GroupId, 'Template.Type': params.Type}, function (error, data) {
                if (error || !data) {
                    return callback(error);
                }
                callback(null, data.toJSON());
            });
        };
        this.AddSurvey = function (params, callback) {
            var survey = EntityCache.Survey(params);
            survey.hgId = guid.v1();
            survey.CreatedBy = params.UserId;
            survey.ModifiedBy = params.UserId;
            survey.save(callback);
        };
        this.UpdateSurvey = function (params, callback) {
            EntityCache.Survey.findOne({hgId: params.hgId}, function (error, survey) {
                if (error) {
                    callback(error);
                } else if (!survey) {
                    callback('business.sur.pro.els');
                } else {
                    survey.ModifiedBy = params.UserId;
                    if (survey.Template.Type === TemplateEnums.Type.Benchmark) {
                        survey.Template.Status = params.Template.Status;
                        survey.Template.Title = params.Template.Title;
                        survey.Template.Description = params.Template.Description;
                        survey.Template.UberQuestion = params.Template.UberQuestion;
                        survey.Template.DriverQuestions = params.Template.DriverQuestions;
                        survey.markModified('Template');
                    } else {
                        survey.Template = params.Template;
                        survey.CurrentQuestionId = params.CurrentQuestionId;
                    }
                    survey.StartDate = params.StartDate;
                    survey.Points = params.Points;
                    survey.Reminder = params.Reminder;
                    survey.DaysToLive = params.DaysToLive;
                    survey.Frequency = params.Frequency;
                    survey.PeriodType = params.PeriodType;
                    survey.Status = params.Status || SurveyEnums.Status.Active;
                    survey.KioskEnable = params.KioskEnable;
                    survey.save(function (error, result) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, result);
                    });
                }
            });
        };
        this.GetSurveyById = function (params, callback) {
            EntityCache.Survey.findOne({hgId: params.hgId}, params.Fields || {}, {lean: true}, callback);
        };
        this.GetGroupSurveyById = function (params, callback) {
            EntityCache.Survey.findOne({hgId: params.hgId, GroupId: params.GroupId}, params.Fields || {}, callback);
        };
        this.UpdateSurveyStatus = function (params, callback) {
            EntityCache.Survey.findOne({hgId : params.hgId}, function (error, survey) {
                if (error) {
                    callback(error);
                } else if (!survey) {
                    callback('business.sur.pro.els');
                } else {
                    if (params.Participant) {
                        survey.Participant = params.Participant;
                    }
                    survey.ModifiedBy = params.UserId;
                    survey.Status = params.Status;
                    survey.save(callback);
                }
            });
        };
        this.DisableSurvey = function (params, callback) {
            EntityCache.Survey.findOne({hgId : params.hgId}, function (error, survey) {
                if (error) {
                    callback(error);
                } else if (!survey) {
                    callback('business.sur.pro.els');
                } else {
                    survey.NextScheduleDisabled = true;
                    survey.ModifiedBy = params.UserId;
                    survey.save(callback);
                }
            });
        };
        this.SaveMemberSurveys = function (params, callback) {
            EntityCache.SurveyAnswer.create(params.Surveys, callback);
        };
        this.GetSurveyAnswerById = function (params, callback) {
            EntityCache.SurveyAnswer.findOne({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                hgId: params.hgId
            }, callback);
        };
        this.GetPendingSurveyByMemberId = function (params, callback) {
            EntityCache.SurveyAnswer.findOne({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                Type: params.Type,
                Status: { $in: params.Status},
                ExpireDate: { $gt: Date.now()}
            }, callback);
        };
        this.DismissPulseSurvey = function (params, callback) {
            EntityCache.SurveyAnswer.update({
                hgId: params.hgId,
                Type: SurveyEnums.Type.Pulse,
                Status: SurveyEnums.SurveyAnswerStatus.Pending,
                ExpireDate: { $gt: Date.now()}
            }, {
                $set: {
                    Status: SurveyEnums.SurveyAnswerStatus.Dismissed,
                    ModifiedBy: params.UserId
                }
            }, callback);
        };
        this.GetSurveyMemberQuestionById = function (params, callback) {
            var query = {
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                RecurrenceId: params.RecurrenceId,
                SurveyId: params.SurveyId,
                CurrentRoundId: params.CurrentRoundId,
                Type: params.Type,
                Status: { $in: params.Status},
                ExpireDate: { $gt: Date.now()}
            };
            EntityCache.SurveyAnswer.aggregate([
                { $match : query},
                { $unwind: "$QandA"},
                { $match: {'QandA.QuestionId': params.QuestionId}},
                { $project: { _id: 0, QandA: 1}}
            ], callback);
        };
        this.GetBenchmarkSurveyMemberQuestionById = function (params, callback) {
            var query = {
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                RecurrenceId: params.RecurrenceId,
                SurveyId: params.SurveyId,
                CurrentRoundId: params.CurrentRoundId,
                Type: SurveyEnums.Type.Benchmark,
                Status: { $in: [
                    SurveyEnums.SurveyAnswerStatus.InProgress,
                    SurveyEnums.SurveyAnswerStatus.Pending
                ]},
                ExpireDate: { $gt: Date.now()}
            };
            EntityCache.SurveyAnswer.aggregate([
                { $match : query},
                { $unwind: "$QandA"},
                { $match: {'QandA.QuestionId': params.QuestionId}},
                { $project: { _id: 0, QandA: 1}}
            ], callback);
        };
        this.GetBenchmarkMemberQuestionsByAnswerStatus = function (params, callback) {
            var query = {
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                Type: SurveyEnums.Type.Benchmark,
                Status: { $in: [
                    SurveyEnums.SurveyAnswerStatus.InProgress,
                    SurveyEnums.SurveyAnswerStatus.Pending
                ]},
                ExpireDate: { $gt: Date.now()}
            },
                aggregateParam = [
                    { $match : query},
                    { $unwind: "$QandA"},
                    { $match: {'QandA.Status': params.QuestionStatus}},
                    { $sort: {'QandA.Order': 1}}
                ];
            if (params.Take) {
                aggregateParam.push({$skip: parseInt(params.Skip, 10) || 0});
                aggregateParam.push({$limit: parseInt(params.Take, 10) || 10});
            }
            aggregateParam.push({ $project: { _id: 0, QandA: 1, SurveyId: 1, RecurrenceId: 1, CurrentRoundId: 1, LastViewedIndex: 1}});
            EntityCache.SurveyAnswer.aggregate(aggregateParam, callback);
        };
        this.AnswerSurvey = function (params, callback) {
            if (params.Survey.Template.Type === SurveyEnums.Type.Pulse) {
                self.AnswerPulseSurvey(params, callback);
            } else if (params.Survey.Template.Type === SurveyEnums.Type.Benchmark) {
                self.AnswerBenchmarkSurvey(params, callback);
            } else {
                callback('Not Implemented');
            }
        };
        this.AnswerPulseSurvey = function (params, callback) {
            var update = {
                Status: SurveyEnums.SurveyAnswerStatus.Completed,
                ModifiedBy: params.UserId,
                'QandA.$.AnsweredDate': Date.now(),
                'QandA.$.Status': SurveyEnums.SurveyAnswerStatus.Completed
            };
            if (params.SurveyAnswerRequest.AnswerType === SurveyEnums.AnswerTypes.Text) {
                update['QandA.$.Comment'] = params.SurveyAnswerRequest.Comment;
            } else {
                update['QandA.$.AnswerValue'] = params.SurveyAnswerRequest.AnswerValue;
                update['QandA.$.ScaledAnswerValue'] = params.SurveyAnswerRequest.ScaledAnswerValue;
            }
            EntityCache.SurveyAnswer.update({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                SurveyId: params.SurveyAnswerRequest.SurveyId,
                RecurrenceId: params.SurveyAnswerRequest.RecurrenceId,
                CurrentRoundId: params.SurveyAnswerRequest.CurrentRoundId,
                Type: SurveyEnums.Type.Pulse,
                'QandA.QuestionId': params.SurveyAnswerRequest.QuestionId,
                Status: SurveyEnums.SurveyAnswerStatus.Pending,
                ExpireDate: { $gt: Date.now()}
            }, {
                $set: update
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, {Completed: true});
            });
        };
        this.FinishBenchmarkSurvey = function (params, callback) {
            Async.parallel({
                updateStatus: function (fcallback) {
                    EntityCache.SurveyAnswer.update({
                        GroupId: params.GroupId,
                        MemberId: params.MemberId,
                        SurveyId: params.SurveyAnswerRequest.SurveyId,
                        RecurrenceId: params.SurveyAnswerRequest.RecurrenceId,
                        CurrentRoundId: params.SurveyAnswerRequest.CurrentRoundId,
                        Type: SurveyEnums.Type.Benchmark,
                        Status: SurveyEnums.SurveyAnswerStatus.InProgress,
                        ExpireDate: { $gt: Date.now()}
                    }, {
                        $set : {
                            CompletedDate: Date.now(),
                            Status: SurveyEnums.SurveyAnswerStatus.Completed
                        }
                    }, fcallback);
                },
                updateCompletedCount: function (fcallback) {
                    EntityCache.Survey.update({
                        GroupId: params.GroupId,
                        hgId: params.SurveyAnswerRequest.SurveyId,
                        Status: SurveyEnums.Status.InProgress
                    }, {
                        $inc: {
                            Completed: 1,
                            InProgress: -1
                        }
                    }, fcallback);
                },
                updateSurveyResultCount: function (fcallback) {
                    EntityCache.SurveyResult.update({
                        GroupId: params.GroupId,
                        SurveyId: params.SurveyAnswerRequest.SurveyId,
                        RecurrenceId: params.SurveyAnswerRequest.RecurrenceId,
                        CurrentRoundId: params.SurveyAnswerRequest.CurrentRoundId,
                        Status: SurveyEnums.SurveyResultStatus.InProgress
                    }, {
                        $inc: {
                            Completed: 1
                        }
                    }, fcallback);
                }
            }, callback);
        };
        this.AnswerBenchmarkSurvey = function (params, callback) {
            var update = {
                    ModifiedBy: params.UserId,
                    'QandA.$.ScaledAnswerValue': params.SurveyAnswerRequest.ScaledAnswerValue,
                    'QandA.$.AnswerValue': params.SurveyAnswerRequest.AnswerValue,
                    'QandA.$.AnsweredDate': Date.now(),
                    'QandA.$.Status': SurveyEnums.SurveyAnswerStatus.Completed
                };
            if (params.SurveyAnswerRequest.Comment) {
                update['QandA.$.Comment'] = params.SurveyAnswerRequest.Comment;
            }
            EntityCache.SurveyAnswer.update({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                SurveyId: params.SurveyAnswerRequest.SurveyId,
                RecurrenceId: params.SurveyAnswerRequest.RecurrenceId,
                CurrentRoundId: params.SurveyAnswerRequest.CurrentRoundId,
                Type: SurveyEnums.Type.Benchmark,
                'QandA.QuestionId': params.SurveyAnswerRequest.QuestionId,
                Status: SurveyEnums.SurveyAnswerStatus.InProgress,
                ExpireDate: { $gt: Date.now()}
            }, {
                $set: update
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                params.Skip = 0;
                params.Take = 5;
                params.QuestionStatus = SurveyEnums.SurveyAnswerStatus.Pending;
                self.GetBenchmarkMemberQuestionsByAnswerStatus(params, function (error, questions) {
                    if (error) {
                        return callback(error);
                    }
                    if (questions && questions.length > 0) {
                        return callback(null, {Completed: false});
                    }
                    self.FinishBenchmarkSurvey(params, function (error, result) {
                        if (error) {
                            return callback(error);
                        }
                        callback(null, {Completed: true});
                    });
                });
            });
        };
        this.AnonymizeUserSurveyAnswer = function (params, callback) {
            EntityCache.SurveyAnswer.update({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                SurveyId: params.SurveyAnswerRequest.SurveyId,
                RecurrenceId: params.SurveyAnswerRequest.RecurrenceId,
                CurrentRoundId: params.SurveyAnswerRequest.CurrentRoundId,
                Type: SurveyEnums.Type.Benchmark,
                Status: SurveyEnums.SurveyAnswerStatus.Completed
            }, {
                $set: {
                    MemberId: config.HighgroundGlobalUserId,
                    UserId: config.HighgroundGlobalUserId,
                    FullName: 'Gus'
                }
            }, callback);
        };
        this.StartBenchmarkSurvey = function (params, callback) {
            EntityCache.SurveyAnswer.update({
                GroupId: params.GroupId,
                MemberId: params.MemberId,
                SurveyId: params.SurveyStartRequest.SurveyId,
                RecurrenceId: params.SurveyStartRequest.RecurrenceId,
                CurrentRoundId: params.SurveyStartRequest.CurrentRoundId,
                Type: SurveyEnums.Type.Benchmark,
                Status: SurveyEnums.SurveyAnswerStatus.Pending,
                ExpireDate: { $gt: Date.now()}
            }, {
                $set : {
                    ModifiedBy: params.UserId,
                    Status: SurveyEnums.SurveyAnswerStatus.InProgress,
                    StartDate: Date.now()
                }
            }, function (error, result) {
                if (error) {
                    return callback(error);
                }
                if (result === 0) {
                    return callback();
                }
                EntityCache.Survey.update({
                    GroupId: params.GroupId,
                    hgId: params.SurveyStartRequest.SurveyId,
                    Status: SurveyEnums.Status.InProgress
                }, {
                    $inc: {
                        InProgress: 1
                    }
                }, callback);
            });
        };
        this.SurveyCompleted = function (params, callback) {
            EntityCache.Survey.findOne({ hgId: params.SurveyId, Status: SurveyEnums.Status.InProgress}, function (error, survey) {
                if (error) {
                    return callback(error);
                }
                if (!survey.NextScheduleDisabled && params.Recurrence && params.Recurrence.NextTriggerDate) {
                    survey.Status = SurveyEnums.Status.Scheduled;
                    survey.StartDate = params.Recurrence.NextTriggerDate;
                } else {
                    survey.Status = SurveyEnums.Status.Active;
                    survey.NextScheduleDisabled = false;
                }
                survey.Completed = 0;
                survey.InProgress = 0;
                survey.Participant = 0;
                survey.save(callback);
            });
        };
        this.GetUnCompletedSurveys = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId,
                Type: params.Type,
                Status: {$in: params.Status},
                ExpireDate: { $gt: Date.now()}
            };
            EntityCache.SurveyAnswer.find(query, callback);
        };
        this.GetExpiredSurveys = function (params, callback) {
            EntityCache.SurveyAnswer.find({
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId,
                Type: params.Type,
                Status: { $in: params.Status},
                ExpireDate: { $lte: Date.now()}
            }, callback);
        };
        this.AddSurveyResult = function (params, callback) {
            var surveyResult = EntityCache.SurveyResult(params);
            surveyResult.hgId = guid.v1();
            surveyResult.CreatedBy = params.UserId;
            surveyResult.ModifiedBy = params.UserId;
            surveyResult.save(callback);
        };
        this.GetInProgressSurvey = function (params, callback) {
            EntityCache.SurveyResult.findOne({
                SurveyId: params.SurveyId,
                GroupId: params.GroupId,
                Status: SurveyEnums.SurveyResultStatus.InProgress
            }, params.Fields || {}, { lean: true }, callback);
        };
        this.GetSurveyResult = function (params, callback) {
            EntityCache.SurveyResult.find({
                GroupId: params.GroupId,
                Status: SurveyEnums.SurveyResultStatus.Completed,
                Type: params.Type
            }).sort({CreatedDate: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetSurveyResultById = function (params, callback) {
            EntityCache.SurveyResult.findOne({
                hgId: params.SurveyResultId
            }, callback);
        };
        this.SetSurveyAnswerReminder = function (params, callback) {
            EntityCache.SurveyAnswer.update({
                hgId: {$in: params.SurveyAnswerIds}
            }, {
                $set: {
                    RemindSent: true
                }
            }, {multi: true}, callback);
        };
        this.UpdateInProgressSurveyResult = function (params, callback) {
            EntityCache.SurveyResult.findOne({
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                Status: SurveyEnums.SurveyResultStatus.InProgress
            }, function (error, result) {
                if (error) {
                    callback(error);
                } else if (!result) {
                    callback('business.sur.pro.elr');
                } else {
                    EntityCache.SurveyResult.find({
                        GroupId: params.GroupId,
                        CreatedDate: {$lt: result.CreatedDate},
                        Status: SurveyEnums.SurveyResultStatus.Completed,
                        Type: result.Type
                    }).sort({CreatedDate: -1})
                        .limit(1)
                        .exec(function (error, previousResult) {
                            if (error) {
                                return callback(error);
                            }
                            if (previousResult.length) {
                                result.PreviousResultId = previousResult[0].hgId;
                            }
                            result.Status = SurveyEnums.SurveyResultStatus.Completed;
                            result.save(callback);
                        });
                }
            });
        };
        this.GetSurveyAnswersBySurveyId = function (params, callback) {
            var condition = {GroupId: params.GroupId};
            if (params.SurveyId) {
                condition.SurveyId = params.SurveyId;
            }
            if (params.StartDate && params.EndDate) {
                condition.ModifiedDate = {$gte: params.StartDate, $lt: params.EndDate};
            }
            if (params.DepartmentId) {
                condition.DepartmentId = params.DepartmentId;
            }
            if (params.LocationId) {
                condition.LocationId = params.LocationId;
            }
            if (params.Status && params.Status.length) {
                condition.Status = {$in: params.Status};
            }
            if (params.CurrentRoundIds) {
                condition.CurrentRoundId = {$in: params.CurrentRoundIds};
            }
            EntityCache.SurveyAnswer.find(condition, params.Fields || {}, callback);
        };
        this.GetSurveyResultBySurveyId = function (params, callback) {
            EntityCache.SurveyResult.find({GroupId: params.GroupId, SurveyId: params.SurveyId})
                .sort({CreatedDate : 1})
                .exec(callback);
        };
        this.GetMoodPulseSurveyRoundId = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                Type: SurveyEnums.Type.Pulse,
                'Summary.Type': SurveyEnums.AnswerTypes.Mood
            };
            if (params.StartDate && params.EndDate) {
                query.ModifiedDate = {
                    $gte: params.StartDate,
                    $lte: params.EndDate
                };
            }
            EntityCache.SurveyResult.find(query).sort({CreatedDate: 1}).exec(callback);
        };
        this.GetSurveyResultBySurvey = function (params, callback) {
            EntityCache.SurveyResult.findOne({
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId
            }, callback);
        };
        this.GetCurrentBenchmarkSurveyByGroupId = function (params, callback) {
            EntityCache.SurveyResult.findOne({
                GroupId: params.GroupId,
                Type: SurveyEnums.Type.Benchmark,
                Status: SurveyEnums.SurveyAnswerStatus.InProgress
            }, {
                _id: 0,
                hgId: 1,
                SurveyId: 1,
                RecurrenceId: 1,
                CurrentRoundId: 1
            }, {lean: true}, callback);
        };
        this.GeneratedPDF = function (params, callback) {
            EntityCache.SurveyResult.update({
                hgId: params.SurveyResultId
            }, {
                $set: {
                    PDFGenerated: true
                }
            }, callback);
        };
        this.UpdateLastViewedIndex = function (params, callback) {
            EntityCache.SurveyAnswer.update({
                MemberId: params.MemberId,
                GroupId: params.GroupId,
                Type: SurveyEnums.Type.Benchmark,
                Status: { $in: [
                    SurveyEnums.SurveyAnswerStatus.InProgress,
                    SurveyEnums.SurveyAnswerStatus.Pending
                ]},
                ExpireDate: { $gt: Date.now()}
            }, {
                $set: {
                    LastViewedIndex: params.Index
                }
            }, callback);
        };
        this.GetSurveyAnswerByCode = function (params, callback) {
            EntityCache.SurveyAnswer.findOne({
                GroupId: params.GroupId,
                AccessCode: params.AccessCode
            }, params.Fields, {lean: true}, callback);
        };
        this.GetBenchmarkCohortTypeData = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                RecurrenceId: params.RecurrenceId,
                SurveyId: params.SurveyId,
                CurrentRoundId: params.CurrentRoundId,
                Type: SurveyEnums.Type.Benchmark,
            };
            query[params.Search] = params.SearchValue;
            EntityCache.SurveyAnswer.aggregate([
                { $match: query},
                { $group: {
                    _id: params.GroupKey,
                    Count: {$sum: 1}
                }},
                { $match: {Count : { $gte : 5}}},
                { $sort: {'_id.Name': 1}},
                { $limit: 10}
            ], callback);
        };
        this.GetGroupAccessCodes = function (params, callback) {
            EntityCache.SurveyAnswer.find({
                GroupId: params.GroupId
            }, {AccessCode: 1}, {lean: true}, callback);
        };
        this.GetSurveyQuestionByCode = function (params, callback) {
            EntityCache.SurveyAnswer.aggregate([
                {
                    $match: {
                        AccessCode: params.Code.toLowerCase(),
                        GroupId: params.GroupId,
                        Type: SurveyEnums.Type.Benchmark,
                        Status: { $in: [
                            SurveyEnums.SurveyAnswerStatus.InProgress,
                            SurveyEnums.SurveyAnswerStatus.Pending
                        ]},
                        ExpireDate: { $gt: Date.now()}
                    }
                }, {
                    $unwind: "$QandA"
                }, {
                    $match: {
                        'QandA.Status': params.QuestionStatus
                    }
                }, {
                    $sort: {'QandA.Order': 1}
                }, {
                    $project: {
                        _id: 0,
                        QandA: 1,
                        UserId: 1,
                        MemberId: 1,
                        SurveyId: 1,
                        RecurrenceId: 1,
                        CurrentRoundId: 1,
                        LastViewedIndex: 1
                    }
                }], callback);
        };
        this.GetSurveyQuestCntByCode = function (params, callback) {
            EntityCache.SurveyAnswer.aggregate([
                {
                    $match: {
                        AccessCode: params.Code.toLowerCase(),
                        GroupId: params.GroupId,
                        Type: SurveyEnums.Type.Benchmark,
                        Status: { $in: [
                            SurveyEnums.SurveyAnswerStatus.InProgress,
                            SurveyEnums.SurveyAnswerStatus.Pending
                        ]},
                        ExpireDate: { $gt: Date.now()}
                    }
                }, {
                    $unwind: "$QandA"
                }, {
                    $match: {
                        'QandA.Status': params.QuestionStatus
                    }
                }, {
                    $group: {
                        _id: null,
                        count: {$sum: 1},
                        MemberId: { $first: "$MemberId" },
                        SurveyId: { $first: "$SurveyId" },
                        RecurrenceId: {$first: "$RecurrenceId"},
                        CurrentRoundId: {$first: "$CurrentRoundId"},
                    }
                }],
                function (err, data) {
                    var item = data.length ? data[0] : null;
                    if (err || !item) {
                        return callback(err, {});
                    }
                    self.StartBenchmarkSurvey({
                        GroupId: params.GroupId,
                        MemberId: item.MemberId,
                        SurveyStartRequest: {
                            SurveyId: item.SurveyId,
                            RecurrenceId: item.RecurrenceId,
                            CurrentRoundId: item.CurrentRoundId
                        }
                    }, function (err) {
                        if (err) {
                            return callback(err);
                        }
                        callback(null, item);
                    });
                });
        };

        this.GetSurveyLocationStats = function (params, callback) {
            var stats = {
                Completed: 0,
                InProgress: 0,
                Pending: 0,
                Participant: 0
            };
            EntityCache.SurveyAnswer.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    CurrentRoundId: params.CurrentRoundId,
                    LocationId: params.LocationId
                }},
                {$group: {
                    _id: "$Status",
                    count: {$sum: 1}
                }}
            ], function (error, data) {
                if (error) {
                    return callback(error);
                }
                data.forEach(function (item) {
                    stats[item._id] = item.count;
                    stats.Participant += item.count;
                });
                stats.NotStarted = stats.Pending;
                callback(null, stats);
            });
        };

    };

module.exports = SurveyProcessor;
