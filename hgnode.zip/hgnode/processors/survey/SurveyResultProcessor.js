/*jslint node:true es5:true*/
var HgBaseProcessor = require('../../framework/HgProcessor.js'),
    SurveyResultProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../../framework/EntityCache.js'),
            SurveyEnums = require('../../enums/SurveyEnums.js'),
            async = require('async'),
            self = this;

        this.GetSummary = function (params, callback) {
            // This query includes serveral query hacks not currently available in mongo db 2.4.
            var aggregateParam = [],
                query = {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId
                };
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            aggregateParam = [
                { $match: query},
                { $unwind: "$QandA"},
                { $match: params.SecondQueryFilter || {}},
                { $group: {
                    _id: params.GroupQueryKey,
                    Positive: { $sum: { $cond: [{ $gt: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Neutral:  { $sum: { $cond: [{ $eq: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Negative: { $sum: { $cond: [{$and: [{ $gte: [ "$QandA.ScaledAnswerValue", 0 ] }, { $lt: [ "$QandA.ScaledAnswerValue", 50 ] }]}, 1, 0 ]}},
                    Comment: { $sum: { $cond: [ { $ifNull: [ "$QandA.Comment", false ] }, 1, 0 ]}},
                    ResponseScore: { $sum: "$QandA.ScaledAnswerValue"},
                    Participant: { $sum:  {$cond: [ { $gte: [ "$QandA.ScaledAnswerValue", -1 ]}, 1, 0 ]}},
                    CumulativeTotal: {$sum: 1},
                    ActualParticipant: {$addToSet: "$hgId"}
                }},
                {$unwind: "$ActualParticipant"},
                {$group: {
                    _id: params.SecondGroupQueryKey || { Id: "$_id.Id", Name: "$_id.Name"},
                    Positive: {$first: "$Positive"},
                    Neutral: {$first: "$Neutral"},
                    Negative: {$first: "$Negative"},
                    Comment: {$first: "$Comment"},
                    ResponseScore: {$first: "$ResponseScore"},
                    Participant: {$first: "$Participant"},
                    CumulativeTotal: {$first: "$CumulativeTotal"},
                    Total: {$sum: 1}
                }},
                { $project: {
                    _id: 1,
                    Comment: 1,
                    Participant: 1,
                    neutral: { $cond: [ { $eq: [ "$Participant", 0]}, 0, { $multiply: [{$divide : [ "$Neutral", "$Participant"] }, 100 ]} ]},
                    unfavorable: { $cond: [ { $eq: [ "$Participant", 0]}, 0, { $multiply: [{$divide : [ "$Negative", "$Participant"] }, 100 ]} ]},
                    favorable: { $cond: [ { $eq: [ "$Participant", 0]}, 0, { $multiply: [{$divide : [ "$Positive", "$Participant"] }, 100 ]}]},
                    participation: { $multiply: [{$divide : [ "$Participant", "$CumulativeTotal"] }, 100 ]},
                    engagement: { $cond: [ { $eq: [ "$Participant", 0]}, 0, {$divide : [ "$ResponseScore", "$Participant"]} ]},
                    Total: 1,
                    ResponseScore: 1
                }},
                { $match: {Total: {$gte: 5}}},
                { $sort: {'engagement': -1}},
                { $skip: parseInt(params.Skip, 10) || 0}
            ];
            if (params.Take && params.Take > 0) {
                aggregateParam.push({ $limit: parseInt(params.Take, 10) || 10});
            }
            EntityCache.SurveyAnswer.aggregate(aggregateParam, callback);
        };
        this.GetDriverResultSection = function (params, callback) {
            var query = {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId
                },
                aggregateParam = [],
                getBothMaxAndMin = function (data) {
                    var result = data.sort(function (a, b) {
                        return b.engagement - a.engagement;
                    }), sResult = {
                        max: (result.length > 0) ? result[0]._id : 'N/A',
                        min: (result.length > 0) ? result[data.length - 1]._id : 'N/A'
                    };
                    return {
                        max: (sResult.max === sResult.min) ? 'N/A' : sResult.max,
                        min: (sResult.max === sResult.min) ? 'N/A' : sResult.min
                    };
                },
                getGroupDriverResult = function (result) {
                    var dResult = {};
                    result.forEach(function (item) {
                        dResult[item._id.DriverName] = getBothMaxAndMin(item.data);
                    });
                    return dResult;
                };
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            aggregateParam = [
                { $match: query},
                { $unwind: "$QandA"},
                { $group: {
                    _id: params.GroupKey,
                    ResponseScore: { $sum: "$QandA.ScaledAnswerValue"},
                    Participant: { $sum:  {$cond: [ { $gte: [ "$QandA.ScaledAnswerValue", -1 ]}, 1, 0 ]}},
                    CumulativeTotal: {$sum: 1},
                    ActualParticipant: {$addToSet: "$hgId"}
                }},
                {$unwind: "$ActualParticipant"},
                {$group: {
                    _id: "$_id",
                    ResponseScore: {$first: "$ResponseScore"},
                    Participant: {$first: "$Participant"},
                    CumulativeTotal: {$first: "$CumulativeTotal"},
                    Total: {$sum: 1}
                }},
                {$match: {Total: {$gte: 5}}},
                {$project: {
                    engagement: { $cond: [ { $eq: [ "$Participant", 0]}, 0, {$divide : [ "$ResponseScore", "$Participant"]} ]}
                }}
            ];
            if (params.GroupByDriver) {
                aggregateParam.push({$group: {
                    _id: { DriverName: "$_id.DriverName", DriverId:  "$_id.DriverId"},
                    data: {$push: {engagement : "$engagement", _id : "$_id.Name"}}
                }});
            }
            EntityCache.SurveyAnswer.aggregate(aggregateParam, function (error, result) {
                if (error) {
                    return callback(error);
                }
                return callback(null, (!params.GroupByDriver) ? getBothMaxAndMin(result) : getGroupDriverResult(result));
            });
        };
        this.GetDriverDetailByCohort = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId
            },
                aggregateParam = [];
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            aggregateParam = [
                { $match: query},
                { $unwind: "$QandA"},
                { $match: {}},
                { $group: {
                    _id: params.GroupKey,
                    Positive: { $sum: { $cond: [{ $gt: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Neutral:  { $sum: { $cond: [{ $eq: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Negative: { $sum: { $cond: [{$and: [{ $gte: [ "$QandA.ScaledAnswerValue", 0 ] }, { $lt: [ "$QandA.ScaledAnswerValue", 50 ] }]}, 1, 0 ]}},
                    ResponseScore: { $sum: "$QandA.ScaledAnswerValue"},
                    Participant: { $sum:  {$cond: [ { $gte: [ "$QandA.ScaledAnswerValue", -1 ]}, 1, 0 ]}},
                    CumulativeTotal: {$sum: 1},
                    ActualParticipant: {$addToSet: "$hgId"},
                    RealParticipant: {$addToSet : {$cond: [ { $gte: [ "$QandA.ScaledAnswerValue", -1 ]}, "$hgId", 0 ]}}
                }},
                { $unwind: "$ActualParticipant"},
                { $group: {
                    _id: {
                        Id: "$_id.Id",
                        Name: "$_id.Name",
                        DriverId: "$_id.DriverId",
                        DriverName: "$_id.DriverName"
                    },
                    Positive: {$first: "$Positive"},
                    Neutral: {$first: "$Neutral"},
                    Negative: {$first: "$Negative"},
                    ResponseScore: {$first: "$ResponseScore"},
                    Participant: {$first: "$Participant"},
                    CumulativeTotal: {$first: "$CumulativeTotal"},
                    Total: {$sum: 1},
                    RealParticipant: {$first: "$RealParticipant"}
                }},
                {$unwind: "$RealParticipant"},
                {$match: {RealParticipant : { $ne: 0}}},
                {$group: {
                    _id: "$_id",
                    Positive: {$first: "$Positive"},
                    Neutral: {$first: "$Neutral"},
                    Negative: {$first: "$Negative"},
                    ResponseScore: {$first: "$ResponseScore"},
                    CumulativeTotal: {$first: "$CumulativeTotal"},
                    OParticipant: {$first: "$Participant"},
                    Total: {$first: "$Total"},
                    Participant: {$sum: 1}
                }},
                { $match: {Total: {$gte: 5}}},
                { $group: {
                    _id: {
                        DriverName: "$_id.DriverName",
                        DriverId:  "$_id.DriverId"
                    },
                    data: {$push: {
                        _id : "$_id.Name",
                        engagement: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, {$divide : [ "$ResponseScore", "$OParticipant"]} ]},
                        participation: { $multiply: [{$divide : [ "$OParticipant", "$CumulativeTotal"] }, 100 ]},
                        unfavorable: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, { $multiply: [{$divide : [ "$Negative", "$OParticipant"] }, 100 ]} ]},
                        favorable: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, { $multiply: [{$divide : [ "$Positive", "$OParticipant"] }, 100 ]}]},
                        neutral: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, { $multiply: [{$divide : [ "$Neutral", "$OParticipant"] }, 100 ]} ]},
                        Total: "$Total",
                        ResponseScore: "$ResponseScore",
                        Participant: "$Participant"
                    }}
                }},
                { $sort: {'_id.DriverName': 1}}
            ];
            EntityCache.SurveyAnswer.aggregate(aggregateParam, callback);
        };
        this.GetSurveyComments = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId
            };
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            EntityCache.SurveyAnswer.aggregate([
                { $match: query},
                { $unwind: "$QandA"},
                { $match: {'QandA.Comment' : { $exists: true}}},
                { $project: {
                    _id: 0,
                    DepartmentName: 1,
                    Role: 1,
                    Tenure: 1,
                    LocationName: 1,
                    "QandA.Comment": 1,
                    "QandA.DriverName": 1,
                    "QandA.QuestionId" : 1,
                    "QandA.QuestionText" : 1,
                    "QandA.AnswerValue" : 1
                }}
            ], callback);
        };
        this.GetEngagementScoreByCohort = function (params, callback) {
            var aggregateParam = [],
                query = {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId
                };
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            aggregateParam = [
                { $match: query},
                { $unwind: "$QandA"},
                { $match: params.SecondQueryFilter || {}},
                { $group: {
                    _id: params.GroupKey,
                    Positive: { $sum: { $cond: [{ $gt: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Neutral:  { $sum: { $cond: [{ $eq: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Negative: { $sum: { $cond: [{$and: [{ $gte: [ "$QandA.ScaledAnswerValue", 0 ] }, { $lt: [ "$QandA.ScaledAnswerValue", 50 ] }]}, 1, 0 ]}},
                    ResponseScore: { $sum: "$QandA.ScaledAnswerValue"},
                    Participant: { $sum:  {$cond: [ { $gte: [ "$QandA.ScaledAnswerValue", -1 ]}, 1, 0 ]}},
                    ActualParticipant: {$addToSet: "$hgId"},
                    RealParticipant: {$addToSet : {$cond: [ { $gte: [ "$QandA.ScaledAnswerValue", -1 ]}, "$hgId", 0 ]}}
                }},
                {$unwind: "$ActualParticipant"},
                {$group: {
                    _id: "$_id",
                    Positive: {$first: "$Positive"},
                    Neutral: {$first: "$Neutral"},
                    Negative: {$first: "$Negative"},
                    ResponseScore: {$first: "$ResponseScore"},
                    Participant: {$first: "$Participant"},
                    Total: {$sum: 1},
                    RealParticipant: {$first: "$RealParticipant"}
                }},
                {$unwind: "$RealParticipant"},
                {$match: {RealParticipant : { $ne: 0}}},
                {$group: {
                    _id: "$_id",
                    Positive: {$first: "$Positive"},
                    Neutral: {$first: "$Neutral"},
                    Negative: {$first: "$Negative"},
                    ResponseScore: {$first: "$ResponseScore"},
                    OParticipant: {$first: "$Participant"},
                    Total: {$first: "$Total"},
                    Participant: {$sum: 1}
                }},
                {$project: {
                    id: 1,
                    Total: 1,
                    ResponseScore: 1,
                    Participant: 1,
                    neutral: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, { $multiply: [{$divide : [ "$Neutral", "$OParticipant"] }, 100 ]} ]},
                    unfavorable: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, { $multiply: [{$divide : [ "$Negative", "$OParticipant"] }, 100 ]} ]},
                    favorable: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, { $multiply: [{$divide : [ "$Positive", "$OParticipant"] }, 100 ]}]},
                    engagement: { $cond: [ { $eq: [ "$OParticipant", 0]}, 0, {$divide : [ "$ResponseScore", "$OParticipant"]} ]}
                }},
                {$match: {Total: {$gte: 5}}},
                {$sort: {engagement : 1}}
            ];
            EntityCache.SurveyAnswer.aggregate(aggregateParam, callback);
        };
        this.GetQuestionDetailByCohort = function (params, callback) {
            var aggregateParam = [],
                query = {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId
                };
            if (params.LimitResultByLocation && params.LocationId) {
                query.LocationId = params.LocationId;
            }
            aggregateParam = [
                { $match: query},
                { $unwind: "$QandA"},
                { $match: params.SecondQueryFilter || {}},
                { $group: {
                    _id: params.DetailGroupKey,
                    Positive: { $sum: { $cond: [{ $gt: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Neutral:  { $sum: { $cond: [{ $eq: [ "$QandA.ScaledAnswerValue", 50 ]}, 1, 0 ]}},
                    Negative: { $sum: { $cond: [{$and: [{ $gte: [ "$QandA.ScaledAnswerValue", 0 ] }, { $lt: [ "$QandA.ScaledAnswerValue", 50 ] }]}, 1, 0 ]}},
                    Comment: { $sum: { $cond: [ { $ifNull: [ "$QandA.Comment", false ] }, 1, 0 ]}},
                    ResponseScore: { $sum: "$QandA.ScaledAnswerValue"},
                    Participant: { $sum:  {$cond: [ { $gte: [ "$QandA.ScaledAnswerValue", -1 ]}, 1, 0 ]}},
                    CumulativeTotal: {$sum: 1},
                    ActualParticipant: {$addToSet: "$hgId"}
                }},
                {$unwind: "$ActualParticipant"},
                {$group: {
                    _id: {
                        Id: "$_id.Id",
                        Name: "$_id.Name",
                        DriverId: "$_id.DriverId",
                        DriverName: "$_id.DriverName",
                        QuestionText: "$_id.QuestionText",
                        QuestionId: "$_id.QuestionId"
                    },
                    Positive: {$first: "$Positive"},
                    Neutral: {$first: "$Neutral"},
                    Negative: {$first: "$Negative"},
                    Comment: {$first: "$Comment"},
                    ResponseScore: {$first: "$ResponseScore"},
                    Participant: {$first: "$Participant"},
                    CumulativeTotal: {$first: "$CumulativeTotal"},
                    Total: {$sum: 1}
                }},
                { $match: {Total: {$gte: 5}}},
                {$group: {
                    _id: {
                        Id: "$_id.Id",
                        Name:  "$_id.Name"
                    },
                    data: {$push: {
                        _id : {
                            DN: "$_id.DriverName",
                            QT: "$_id.QuestionText",
                            QId: "$_id.QuestionId"
                        },
                        engagement : { $cond: [ { $eq: [ "$Participant", 0]}, 0, {$divide : [ "$ResponseScore", "$Participant"]} ]},
                        unfavorable: { $cond: [ { $eq: [ "$Participant", 0]}, 0, { $multiply: [{$divide : [ "$Negative", "$Participant"] }, 100 ]} ]},
                        favorable: { $cond: [ { $eq: [ "$Participant", 0]}, 0, { $multiply: [{$divide : [ "$Positive", "$Participant"] }, 100 ]}]},
                        neutral: { $cond: [ { $eq: [ "$Participant", 0]}, 0, { $multiply: [{$divide : [ "$Neutral", "$Participant"] }, 100 ]} ]},
                        Comment: "$Comment"
                    }}
                }},
                { $sort: {'_id.Name': 1}}
            ];
            EntityCache.SurveyAnswer.aggregate(aggregateParam, callback);
        };
        this.GetAnswerSurveyCount = function (params, callback) {
            EntityCache.SurveyAnswer.count({
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId,
                Status: params.Status
            }, callback);
        };
        this.GetSurveyResultById = function (params, callback) {
            EntityCache.SurveyResult.findOne({
                hgId: params.hgId,
                GroupId: params.GroupId
            }, callback);
        };
        this.GetSurveyResultCount = function (params, callback) {
            EntityCache.SurveyResult.count({
                GroupId: params.GroupId,
                Status: params.Status,
                Type: params.Type
            }, callback);
        };
        this.GetSurveyResults = function (params, callback) {
            EntityCache.SurveyResult.find({
                GroupId: params.GroupId,
                Status: params.Status,
                Type: params.Type
            }).sort({CreatedDate: -1})
                .skip(parseInt(params.Skip, 10) || 0)
                .limit(parseInt(params.Take, 10) || 0)
                .exec(callback);
        };
        this.GetPulseSurveyAverage = function (params, callback) {
            EntityCache.SurveyAnswer.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId,
                    Status: SurveyEnums.QuestionStatus.Completed,
                    Type: SurveyEnums.Type.Pulse
                }},
                {$unwind: "$QandA"},
                {$group: {
                    _id: {
                        AnswerValue: "$QandA.QuestionId"
                    },
                    average: { $avg: "$QandA.ScaledAnswerValue"}
                }}
            ], function (error, result) {
                if (error) {
                    return callback(error);
                }
                callback(null, result.length ? result[0].average : 0);
            });
        };
        this.GetPulseSurveyHighestAnswerOption = function (params, callback) {
            var aggregateParam = [
                {$match: {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId,
                    Status: SurveyEnums.QuestionStatus.Completed,
                    Type: SurveyEnums.Type.Pulse
                }},
                {$unwind: "$QandA"},
                {$group: {
                    _id: {
                        AnswerValue: "$QandA.AnswerValue"
                    },
                    total: {$sum : 1}
                }},
                {$sort: {
                    total: -1
                }}
            ];
            if (params.SingleResult) {
                aggregateParam.push({$limit: 1});
            }
            EntityCache.SurveyAnswer.aggregate(aggregateParam, callback);
        };
        this.GetPulseQuestionBySurveyResult = function (params, callback) {
            EntityCache.SurveyAnswer.findOne({
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId
            }, function (error, data) {
                if (error || !data) {
                    return callback(error || 'business.sur.pro.elq');
                }
                callback(null, {
                    Question: data.QandA[0].QuestionText,
                    AnswerSelectors: data.QandA[0].AnswerSelectors || [],
                    QuestionType: data.QandA[0].AnswerType
                });
            });
        };
        this.GetPulseMultipleChoiceAnswerOption = function (params, callback) {
            EntityCache.SurveyAnswer.findOne({
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId,
                Type: SurveyEnums.Type.Pulse
            }, function (error, data) {
                if (error || !data || !data.QandA.length) {
                    return callback(error);
                }
                callback(null, data.QandA[0].AnswerSelectors);
            });
        };
        this.GetSurveyParticipation = function (params, callback) {
            var aggregateParam = [
                {$match: {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId
                }},
                {$unwind: "$QandA"},
                {$group: {
                    _id: params.GroupKey,
                    Participant: { $sum:  {$cond: [ { $gte: [ params.ParticipantFilter, -1 ]}, 1, 0 ]}},
                    CumulativeTotal: {$sum: 1},
                    ActualParticipant: {$addToSet: "$hgId"}
                }},
                {$unwind: "$ActualParticipant"},
                {$group: {
                    _id: { Id: "$_id.Id", Name: "$_id.Name"},
                    Participant: {$first: "$Participant"},
                    CumulativeTotal: {$first: "$CumulativeTotal"},
                    Total: {$sum: 1}
                }},
                {$project: {
                    _id: 1,
                    Participant: 1,
                    participation: { $multiply: [{$divide : [ "$Participant", "$CumulativeTotal"] }, 100 ]},
                    Total: 1
                }},
                {$match: {Total: {$gte: 5}}}
            ];
            if (params.Take) {
                aggregateParam.push({$limit: params.Take});
            }
            EntityCache.SurveyAnswer.aggregate(aggregateParam, callback);
        };
        this.GetPulseMultipleChoiceCohortResult = function (params, callback) {
            async.parallel({
                participation: function (fcallback) {
                    self.GetSurveyParticipation({
                        GroupId: params.GroupId,
                        SurveyId: params.SurveyId,
                        RecurrenceId: params.RecurrenceId,
                        CurrentRoundId: params.CurrentRoundId,
                        ParticipantFilter: "$QandA.AnswerValue",
                        GroupKey: params.GroupKey,
                        Take: params.Take
                    }, fcallback);
                },
                results: function (fcallback) {
                    params.GroupKey.Value = "$QandA.AnswerValue";
                    EntityCache.SurveyAnswer.aggregate([
                        {$match: {
                            GroupId: params.GroupId,
                            SurveyId: params.SurveyId,
                            RecurrenceId: params.RecurrenceId,
                            CurrentRoundId: params.CurrentRoundId,
                            Status: SurveyEnums.QuestionStatus.Completed
                        }},
                        {$unwind: "$QandA"},
                        {$group: {
                            _id: params.GroupKey,
                            total: {$sum: 1}
                        }},
                        {$group: {
                            _id: {
                                Id: "$_id.Id",
                                Name: "$_id.Name"
                            },
                            result: {$addToSet: {
                                count: "$total",
                                value: "$_id.Value"
                            }},
                            total: { $max: "$total"}
                        }}
                    ], fcallback);
                }
            }, callback);
        };
        this.GetTextParticipationResult = function (params, callback) {
            self.GetSurveyParticipation({
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId,
                ParticipantFilter: "$QandA.Comment",
                GroupKey: params.GroupKey,
                Take: params.Take
            }, callback);
        };
        this.GetSurveyTextData = function (params, callback) {
            var query = {
                GroupId: params.GroupId,
                SurveyId: params.SurveyId,
                RecurrenceId: params.RecurrenceId,
                CurrentRoundId: params.CurrentRoundId,
                Status: SurveyEnums.SurveyAnswerStatus.Completed,
                "QandA.Comment": {$exists: true}
            };
            if (params.CohortId && params.CohortField) {
                query[params.CohortField] = params.CohortId;
            }
            async.parallel({
                textCount: function (fcallback) {
                    EntityCache.SurveyAnswer.aggregate([
                        { $match: query},
                        { $unwind: "$QandA"}
                    ], function (error, data) {
                        fcallback(error, data.length || 0);
                    });
                },
                texts: function (fcallback) {
                    EntityCache.SurveyAnswer.aggregate([
                        { $match: query},
                        { $unwind: "$QandA"},
                        { $skip: parseInt(params.Skip, 10) || 0},
                        { $limit: parseInt(params.Take, 10) || 10},
                        { $project: { _id: 0, 'QandA.Comment': 1}}
                    ], fcallback);
                }
            }, callback);
        };
        this.GetSurveyResultDrivers = function (params, callback) {
            EntityCache.SurveyAnswer.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    CurrentRoundId: params.CurrentRoundId
                }},
                {$limit: 1},
                {$unwind: "$QandA"},
                {$group: {
                    _id: null,
                    data: {$addToSet: {
                        hgId: "$QandA.DriverId",
                        Name: "$QandA.DriverName"
                    }}
                }}
            ], function (error, drivers) {
                if (error) {
                    return callback(error);
                }
                callback(null, drivers.length ? drivers[0].data : drivers);
            });
        };
        this.GetSurveyCohortCount = function (params, callback) {
            EntityCache.SurveyAnswer.aggregate([
                {$match: {
                    GroupId: params.GroupId,
                    SurveyId: params.SurveyId,
                    RecurrenceId: params.RecurrenceId,
                    CurrentRoundId: params.CurrentRoundId
                }},
                {$group: {
                    _id: params.CohortKey,
                    total: {$sum: 1}
                }}
            ], function (error, data) {
                if (error) {
                    return callback('business.sur.pro.ecr');
                }
                if (!data) {
                    return callback();
                }
                var cohortIndex = {};
                data.forEach(function (item) {
                    cohortIndex[item._id.Id] = {
                        name: item._id.Name,
                        total: item.total
                    };
                });
                callback(null, cohortIndex);
            });
        };
        this.UpdatePulseSurveyResult = function (params, callback) {
            var getSelectAnswerOption = function (varams) {
                    var getText = function (options, value) {
                        var selectedOption = [];
                        if (options.length) {
                            selectedOption = options.filter(function (item) {
                                return item.Value === value;
                            });
                        }
                        return selectedOption.length ? selectedOption[0].Text : '';
                    };
                    return {
                        text: varams.HighestVotes.length ? getText(varams.Options, varams.HighestVotes[0]._id.AnswerValue) : '',
                        value: varams.CompletedCount && varams.HighestVotes.length ?
                                Math.round(varams.HighestVotes[0].total / varams.CompletedCount * 100) : 0
                    };
                };
            self.GetPulseQuestionBySurveyResult({
                GroupId: params.SurveyResult.GroupId,
                SurveyId: params.SurveyResult.SurveyId,
                RecurrenceId: params.SurveyResult.RecurrenceId,
                CurrentRoundId: params.SurveyResult.CurrentRoundId
            }, function (error, question) {
                if (error) {
                    return callback(error);
                }
                async.parallel({
                    completedAnswerCount: function (fcallback) {
                        self.GetAnswerSurveyCount({
                            GroupId: params.SurveyResult.GroupId,
                            SurveyId: params.SurveyResult.SurveyId,
                            RecurrenceId: params.SurveyResult.RecurrenceId,
                            CurrentRoundId: params.SurveyResult.CurrentRoundId,
                            Status: SurveyEnums.QuestionStatus.Completed
                        }, fcallback);
                    },
                    average: function (fcallback) {
                        if (question.QuestionType === SurveyEnums.AnswerTypes.Text || question.QuestionType === SurveyEnums.AnswerTypes.MultipleChoice) {
                            return fcallback();
                        }
                        self.GetPulseSurveyAverage({
                            GroupId: params.SurveyResult.GroupId,
                            SurveyId: params.SurveyResult.SurveyId,
                            RecurrenceId: params.SurveyResult.RecurrenceId,
                            CurrentRoundId: params.SurveyResult.CurrentRoundId
                        }, fcallback);
                    },
                    answerOptions: function (fcallback) {
                        if (question.QuestionType  !== SurveyEnums.AnswerTypes.MultipleChoice) {
                            return fcallback();
                        }
                        self.GetPulseMultipleChoiceAnswerOption({
                            GroupId: params.SurveyResult.GroupId,
                            SurveyId: params.SurveyResult.SurveyId,
                            RecurrenceId: params.SurveyResult.RecurrenceId,
                            CurrentRoundId: params.SurveyResult.CurrentRoundId
                        }, fcallback);
                    },
                    highestOptionVote: function (fcallback) {
                        if (question.QuestionType  === SurveyEnums.AnswerTypes.Text) {
                            return fcallback();
                        }
                        self.GetPulseSurveyHighestAnswerOption({
                            GroupId: params.SurveyResult.GroupId,
                            SurveyId: params.SurveyResult.SurveyId,
                            RecurrenceId: params.SurveyResult.RecurrenceId,
                            CurrentRoundId: params.SurveyResult.CurrentRoundId,
                            SingleResult: true
                        }, fcallback);
                    }
                }, function (error, result) {
                    if (error) {
                        return callback(error);
                    }
                    EntityCache.SurveyResult.update({
                        hgId: params.SurveyResult.hgId
                    }, {
                        $set: {
                            Status: SurveyEnums.SurveyResultStatus.Completed,
                            Completed: result.completedAnswerCount || 0,
                            Question: question.Question,
                            Summary: {
                                Type: question.QuestionType,
                                Average: result.average || 0,
                                HighestOptionVote: result.highestOptionVote && result.highestOptionVote.length ? result.highestOptionVote[0]._id.AnswerValue : '',
                                CommentCount: question.QuestionType  === SurveyEnums.AnswerTypes.Text ? result.completedAnswerCount : 0,
                                SelectedOption: question.QuestionType  === SurveyEnums.AnswerTypes.MultipleChoice ? getSelectAnswerOption({
                                    CompletedCount: result.completedAnswerCount,
                                    HighestVotes: result.highestOptionVote,
                                    Options: result.answerOptions
                                }) : ''
                            }
                        }
                    }, callback);
                });
            });
        };
    };

module.exports = SurveyResultProcessor;
