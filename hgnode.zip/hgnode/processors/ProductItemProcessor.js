/*jslint node:true es5:true*/
var HgBaseProcessor = require('../framework/HgProcessor.js'),
    DateHelper = require('../util/DateHelper.js'),
    Enums = require('../enums/EntityEnums.js'),
    ProductItemProcessor = function () {
        'use strict';
        HgBaseProcessor.apply(this, arguments);

        var EntityCache = require('../framework/EntityCache.js'),
            EntityEnums = require('../enums/EntityEnums'),
            guid = require('node-uuid');

        this.DefaultEntityName = 'ProductItem';

        this.CreateProductItem = function (params, callback) {
            var item = new EntityCache.ProductItem(params.ItemRequest);

            item.hgId = guid.v1();
            item.CreatedBy = params.UserId;
            item.ModifiedBy = params.UserId;
            item.CreateDate = Date.now();
            item.ModifiedDate = Date.now();
            item.GroupId = params.GroupId;
            item.GroupName = params.GroupName;
            item.FriendlyGroupId = params.FriendlyGroupId;
            item.ExpireDate = params.ItemRequest.ExpireDate ? DateHelper.setDateToEndOfDay(params.ItemRequest.ExpireDate) : null;
            item.Owner = params.ItemRequest.Owner;
            item.SuggestedBy = params.SuggestedBy;
            item.CampaignItem.Backers = [];
            item.CampaignItem.PledgedPrice = 0;
            delete item.CampaignItem.FundCompletedDate;

            item.save(function (err) {
                callback(err, item);
            });
        };

        this.GetItemById = function (params, callback) {
            EntityCache.ProductItem.findOne({hgId: params.ItemId}, callback);
        };

        this.AddTagToItem = function (params, callback) {
            EntityCache.ProductItem.findOneAndUpdate({
                hgId: params.ProductItemId
            }, {
                $addToSet: {
                    Tags: {
                        TagId: params.Tag.hgId,
                        TagName: params.Tag.Name
                    }
                },
                $set: {
                    ModifiedBy: params.UserId
                }
            }, {
                new: true
            }, callback);
        };

        this.RemoveTagFromItem = function (params, callback) {
            EntityCache.ProductItem.findOne({hgId: params.ProductItemId}, function (error, item) {
                if (error || !item) {
                    return callback('productItem.int.msg.eli');
                }
                item.Tags = item.Tags.filter(function (tag) {
                    return tag.TagId !== params.TagId;
                });
                item.save(function (error) {
                    callback(error, item);
                });
            });
        };

        this.ExpireProductItems = function (params, callback) {
            var nowTimeStamp = Date.now();
            EntityCache.ProductItem.find({
                ExpireDate: {$lte : nowTimeStamp},
                Status: EntityEnums.ProductItemStatus.Active,
                ProductType: {$ne: Enums.ProductItemType.Campaign}
            }, function (err, items) {
                if (err) {
                    return callback(err);
                }
                var groupIds = [],
                    groupSummaries = [];
                items.forEach(function (item) {
                    if (groupIds.indexOf(item.GroupId) === -1) {
                        groupIds.push(item.GroupId);
                        groupSummaries.push({
                            GroupId: item.GroupId,
                            GroupName: item.GroupName
                        });
                    }
                });
                EntityCache.ProductItem.update({
                    ExpireDate: {$lte: nowTimeStamp},
                    Status: EntityEnums.ProductItemStatus.Active
                }, {
                    $set: {
                        Status: EntityEnums.ProductItemStatus.Draft
                    }
                }, {
                    multi: true
                }, function (err) {
                    callback(err, {
                        Items: items,
                        GroupSummaries: groupSummaries
                    });
                });
            });
        };

        this.ExpireCampaignItems = function (params, callback) {
            var nowTimeStamp = Date.now();
            EntityCache.ProductItem.find({
                ExpireDate: {$lte : nowTimeStamp},
                Status: EntityEnums.ProductItemStatus.Active,
                ProductType: Enums.ProductItemType.Campaign
            }, function (err, items) {
                if (err) {
                    return callback(err);
                }
                var groupIds = [],
                    groupSummaries = [],
                    i,
                    len = items.length,
                    expiredItems = [],
                    fulfilledItems = [];
                for (i = 0; i < len; i += 1) {
                    if (items[i].CampaignItem.FundingGoal > items[i].CampaignItem.PledgedPrice) {
                        expiredItems.push(items[i]);
                        if (groupIds.indexOf(items[i].GroupId) === -1) {
                            groupIds.push(items[i].GroupId);
                            groupSummaries.push({
                                GroupId: items[i].GroupId,
                                GroupName: items[i].GroupName
                            });
                        }
                    } else {
                        fulfilledItems.push(items[i]);
                    }
                }
                EntityCache.ProductItem.update({
                    hgId: {
                        $in: fulfilledItems.map(function (i) {
                            return i.hgId;
                        })
                    }
                }, {
                    $set: {Status: Enums.ProductItemStatus.Fulfilled}
                }, {
                    multi: true
                }, function (err) {
                    if (err) {
                        return callback(err);
                    }
                    EntityCache.ProductItem.update({
                        hgId: {
                            $in: expiredItems.map(function (i) {
                                return i.hgId;
                            })
                        }
                    }, {
                        $set: {Status: Enums.ProductItemStatus.Draft}
                    }, {
                        multi: true
                    }, function (err) {
                        if (err) {
                            return callback(err);
                        }
                        callback(null, {Items: expiredItems, GroupSummaries: groupSummaries});
                    });
                });
            });
        };

        this.UpdateProductItem = function (params, callback) {
            EntityCache.ProductItem.findOne({hgId: params.ItemRequest.hgId}, function (err, item) {
                var owner = null,
                    updateQuery,
                    beforeStatus,
                    beforeType;
                if (err || !item) {
                    return callback('admin.poi.pro.cfi');
                }
                beforeStatus = item.Status;
                beforeType = item.ProductType;
                if (params.ItemRequest.Owner && params.ItemRequest.Owner.MemberId && params.ItemRequest.Owner.UserId) {
                    owner = {
                        MemberId: params.ItemRequest.Owner.MemberId,
                        UserId: params.ItemRequest.Owner.UserId
                    };
                }
                if (!params.UpdateImage) {
                    updateQuery = {
                        $set: {
                            Name: params.ItemRequest.Name,
                            Description: params.ItemRequest.Description || '',
                            ExpireDate: params.ItemRequest.ExpireDate ? DateHelper.setDateToEndOfDay(params.ItemRequest.ExpireDate) : null,
                            ProductImageFile: params.ItemRequest.ProductImageFile,
                            RedeemInstruction: params.ItemRequest.RedeemInstruction || '',
                            Status: params.ItemRequest.Status,
                            GroupName: params.GroupName,
                            Owner: owner,
                            ProductType: params.ItemRequest.ProductType,
                            Accessibility: params.ItemRequest.Accessibility,
                            Tags: params.ItemRequest.Tags || []
                        }
                    };
                    if (params.ItemRequest.ProductType === 'Campaign') {
                        updateQuery.$set['CampaignItem.FundingGoal'] = params.ItemRequest.CampaignItem.FundingGoal;
                        updateQuery.$set['CampaignItem.PledgedPrice'] = params.ItemRequest.CampaignItem.PledgedPrice;
                    } else {
                        updateQuery.$set.PointCost = params.ItemRequest.PointCost;
                        updateQuery.$set.AvailableNumber = params.ItemRequest.AvailableNumber;
                    }
                } else {
                    updateQuery = {
                        $set: {
                            ProductImageFile: params.ItemRequest.ProductImageFile
                        }
                    };
                }

                EntityCache.ProductItem.findOneAndUpdate(
                    {hgId: params.ItemRequest.hgId},
                    updateQuery,
                    {new: true},
                    function (err, item) {
                        callback(err, {
                            NewAvailable: beforeStatus !== 'Active' && params.ItemRequest.Status === 'Active',
                            ProductItemSwitchFlag: beforeType !== params.ItemRequest.ProductType && (params.ItemRequest.Status === 'Active'),
                            Item: item
                        });
                    }
                );
            });
        };

        this.UpdateItemAvailableNumber = function (params, callback) {
            EntityCache.ProductItem.findOneAndUpdate({
                hgId: params.ItemId
            }, {
                $inc: {AvailableNumber: params.Number}
            }, {
                new: true
            }, function (err, item) {
                if (item.AvailableNumber <= 0) {
                    EntityCache.ProductItem.findOneAndUpdate({
                        hgId: params.ItemId
                    }, {
                        $set: {
                            Status: EntityEnums.ProductItemStatus.Draft
                        }
                    }, {
                        new: true
                    }, callback);
                } else {
                    callback(err, item);
                }
            });
        };

        this.GetCampaignProductItems = function (params, callback) {
            var today = new Date(),
                mainCondition,
                locationCondition = {
                    $or: [
                        {'Accessibility.RestrictByLocation': false},
                        {'Accessibility.Locations.hgId': params.LocationId}
                    ]
                },
                deptCondition = {
                    $or: [
                        {'Accessibility.RestrictByDept': false},
                        {'Accessibility.Departments.hgId': params.DepartmentId}
                    ]
                };
            today.setDate(today.getDate() - 5);
            mainCondition = {
                $and: [
                    {
                        GroupId: params.GroupId,
                        Status: Enums.ProductItemStatus.Active,
                        ProductType: Enums.ProductItemType.Campaign,
                        $or: [
                            {ExpireDate: {$gte: Date.now()}},
                            {ExpireDate: {$exists: false}},
                            {ExpireDate: null}
                        ]
                    }
                ]
            };
            mainCondition.$and.push(locationCondition);
            mainCondition.$and.push(deptCondition);
            EntityCache.ProductItem.find(mainCondition, callback);
        };

        this.GetProductItemsByDeptsAndLocations = function (params, callback) {
            var mainCondition = {
                    $and: [
                        {
                            GroupId: params.GroupId,
                            Status: Enums.ProductItemStatus.Active,
                            ProductType: Enums.ProductItemType.Store,
                            PointCost: {$lte: params.Balance},
                            'Owner.MemberId': {$ne: params.MemberId},
                            AvailableNumber: {$gte: params.RecipientMemberIds.length},
                            $or: [
                                {ExpireDate: {$gte: Date.now()}},
                                {ExpireDate: {$exists: false}},
                                {ExpireDate: null}
                            ]
                        }
                    ]
                },
                locationCondition = {
                    $or: [
                        {'Accessibility.RestrictByLocation': false}
                    ]
                },
                deptCondition = {
                    $or: [
                        {'Accessibility.RestrictByDept': false}
                    ]
                };
            if (params.RecipentLocationIds && params.RecipentLocationIds.length) {
                locationCondition.$or.push({'Accessibility.Locations.hgId': {$all: params.RecipentLocationIds}});
            }
            if (params.RecipientDepartmentIds && params.RecipientDepartmentIds.length) {
                deptCondition.$or.push({'Accessibility.Departments.hgId': {$all: params.RecipientDepartmentIds}});
            }
            mainCondition.$and.push(locationCondition);
            mainCondition.$and.push(deptCondition);

            if (params.search) {
                mainCondition.$and.push({Description: {$regex: params.search, $options: 'i'}});
            }
            EntityCache.ProductItem.find(mainCondition)
                .skip(parseInt(params.skip, 10) || 0)
                .limit(parseInt(params.take, 10) || 0)
                .exec(callback);
        };

        this.GetProductItemsForGiftingOneMember = function (params, callback) {
            var mainCondition = {
                    $and: [
                        {
                            GroupId: params.GroupId,
                            Status: Enums.ProductItemStatus.Active,
                            ProductType: Enums.ProductItemType.Store,
                            $or: [
                                {ExpireDate: {$gte: Date.now()}},
                                {ExpireDate: {$exists: false}},
                                {ExpireDate: null}
                            ]
                        }
                    ]
                },
                locationCondition = {
                    $or: [
                        {'Accessibility.RestrictByLocation': false},
                        {'Accessibility.Locations.hgId': params.RecipentLocationId}
                    ]
                },
                deptCondition = {
                    $or: [
                        {'Accessibility.RestrictByDept': false},
                        {'Accessibility.Departments.hgId': params.RecipientDepartmentId}
                    ]
                };
            mainCondition.$and.push(locationCondition);
            mainCondition.$and.push(deptCondition);
            if (params.search) {
                mainCondition.$and.push({Description: {$regex: params.search, $options: 'i'}});
            }
            EntityCache.ProductItem.find(mainCondition)
                    .skip(parseInt(params.skip, 10) || 0)
                    .limit(parseInt(params.take, 10) || 0)
                    .exec(callback);
        };

        this.GetProductItemsForPurchase = function (params, callback) {
            var mainCondition = {
                    $and: [
                        {
                            GroupId: params.GroupId,
                            Status: Enums.ProductItemStatus.Active,
                            ProductType: Enums.ProductItemType.Store,
                            $or: [
                                {ExpireDate: {$gte: Date.now()}},
                                {ExpireDate: {$exists: false}},
                                {ExpireDate: null}
                            ]
                        }
                    ]
                },
                locationCondition = {
                    $or: [
                        {'Accessibility.RestrictByLocation': false},
                        {'Accessibility.Locations.hgId': params.LocationId}
                    ]
                },
                deptCondition = {
                    $or: [
                        {'Accessibility.RestrictByDept': false},
                        {'Accessibility.Departments.hgId': params.DepartmentId}
                    ]
                };

            mainCondition.$and.push(locationCondition);
            mainCondition.$and.push(deptCondition);

            if (params.searchTerm && params.searchTerm.length) {
                mainCondition.$and.push(
                    {$or: [
                        {Name: {$regex: params.searchTerm, $options: 'i'}},
                        {Description: {$regex: params.searchTerm, $options: 'i'}}
                    ]
                        }
                );
            }

            if (params.TagFilter) {
                mainCondition['Tags.TagName'] = params.TagFilter;
            }

            EntityCache.ProductItem.find(mainCondition)
                .skip(parseInt(params.skip, 10) || 0)
                .limit(parseInt(params.take, 10) || 0)
                .exec(function (err, items) {
                    callback(err, items);
                });
        };

        this.GetActiveProductItems = function (params, callback) {
            EntityCache.ProductItem.find({
                $or: [
                    {ExpireDate: {$gte: Date.now()}},
                    {ExpireDate: {$exists: false}},
                    {ExpireDate: null}
                ],
                Status: Enums.ProductItemStatus.Active,
                GroupId: params.GroupId,
                ProductType: Enums.ProductItemType.Store
            }, function (err, items) {
                callback(err, items);
            });
        };
        this.GetPagedActiveProductItems = function (params, callback) {
            var mquery = {
                    $and: [
                        {$or: [
                            {ExpireDate: {$gte: Date.now()}},
                            {ExpireDate: {$exists: false}},
                            {ExpireDate: null}
                        ]}
                    ],
                    Status: Enums.ProductItemStatus.Active,
                    GroupId: params.GroupId
                };
            if (params.searchTerm && params.searchTerm.length > 0) {
                mquery.$and.push(
                    {$or: [
                        {'Name': {$regex: params.searchTerm, $options: 'i'}},
                        {'Description': {$regex: params.searchTerm, $options: 'i'}}
                    ]
                        }
                );
            }
            EntityCache.ProductItem.find(mquery).skip(parseInt(params.skip, 10) || 0)
                .limit(parseInt(params.take, 10) || 0)
                .exec(function (err, items) {
                    callback(err, items);
                });
        };
        this.GetAllProductItems = function (params, callback) {
            EntityCache.ProductItem.find({
                GroupId: params.GroupId,
                Status: {$in: [
                    Enums.ProductItemStatus.Active,
                    Enums.ProductItemStatus.Draft,
                    Enums.ProductItemStatus.ApprovalPending,
                    Enums.ProductItemStatus.Fulfilled
                ]}
            }).exec(function (err, items) {
                callback(err, items);
            });
        };

        this.ArchiveProductItem = function (params, callback) {
            EntityCache.ProductItem.findOneAndUpdate({
                hgId: params.ItemDeleteRequest.hgId
            }, {
                $set: {
                    Status: Enums.ProductItemStatus.Archived
                }
            }, {
                new: true
            }, function (err, item) {
                callback(err, 'prod.item.pid');
            });
        };

        this.findAndUpdateCampaign = function (params, callback) {
            EntityCache.ProductItem.findOne({hgId: params.ItemId}, function (err, item) {
                if (err || !item) {
                    callback('prod.item.cfi');
                } else {
                    var backers = [], matchFlag = false, i, len,
                        backerObj = {
                            UserId: params.UserId,
                            MemberId: params.Data.MemberId,
                            FullName: params.Data.FullName,
                            FirstName: params.Data.FirstName,
                            LastName: params.Data.LastName,
                            PledgePoint: params.PledgePoints
                        };

                    if (item.CampaignItem.Backers.length > 0) {
                        for (i = 0, len = item.CampaignItem.Backers.length; i < len; i += 1) {
                            if (item.CampaignItem.Backers[i].MemberId === params.Data.MemberId) {
                                matchFlag = true;
                                item.CampaignItem.Backers[i].PledgePoint += params.PledgePoints;
                            }
                            backers.push({
                                UserId: item.CampaignItem.Backers[i].UserId,
                                MemberId: item.CampaignItem.Backers[i].MemberId,
                                FullName: item.CampaignItem.Backers[i].FullName,
                                FirstName: item.CampaignItem.Backers[i].FirstName,
                                LastName: item.CampaignItem.Backers[i].LastName,
                                PledgePoint: item.CampaignItem.Backers[i].PledgePoint
                            });
                        }
                        if (!matchFlag) {
                            backers.push(backerObj);
                        }
                    } else {
                        backers.push(backerObj);
                    }
                    EntityCache.ProductItem.findOneAndUpdate(
                        {hgId: params.ItemId},
                        {
                            $inc: {'CampaignItem.PledgedPrice': params.PledgePoints},
                            $set: {'CampaignItem.Backers': backers,
                                    'CampaignItem.FundCompletedDate': Date.now()}
                        },
                        {
                            new: true
                        },
                        function (err, item) {
                            callback(err, { Item: item });
                        }
                    );
                }
            });
        };
    };

module.exports = ProductItemProcessor;
