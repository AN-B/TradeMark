/*jslint node:true es5:true nomen:true stupid: true*/
"use strict";
var fs = require('fs.extra'),
    uuid = require('node-uuid'),
    cfg = require('../configurations/config.js'),
    keystore = require('../configurations/keystore.js'),
    AWS = require('aws-sdk'),
    imageProcessor = require('./imageProcessor'),
    ex = require('../lib/extend'),
    util = require('util'),
    Async = require('async'),
    AdmZip = require('adm-zip'),
    s3Util = require('./s3Util'),
    cryptoHelper = require('./cryptoHelper.js'),
    path = __dirname.replace('/hgnode/helpers', ''),
    pathModule = require('path'),
    i18nHelper = require('../helpers/i18nHelper.js'),
    fsUtil = require('./fileSystemUtil.js'),
    HgLog = require('../framework/HgLog.js'),
    AppRootPath = pathModule.dirname(process.mainModule.filename).replace('/node_modules/mocha/bin', ''),
    StringDecoder = require('string_decoder').StringDecoder,
    isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
    s3;

AWS.config.update({
    accessKeyId: keystore.amazon_aws.key,
    secretAccessKey: keystore.amazon_aws.secret
});

s3 = new AWS.S3();

function upload(params, callback) {
    if (!params.req || !params.req.xhr) {
        return callback('server.flupload.mup');
    }
    if (!params.FileName || !params.RemoteFilePath) {
        return callback('server.flupload.mfp');
    }
    var fname = params.req.header('x-file-name')
                    .replace(/[&%#\^]/g, '')
                    .replace(/-/g, ''),
        data = new Buffer('');
    params.req.on('data', function (chunk) {
        data = Buffer.concat([data, chunk]);
    });
    params.req.on('end', function () {
        if (isLocal) {
            fs.writeFile(path + '/provision/' + params.FileName, new Buffer(cryptoHelper.encrypt(data), 'binary'), 'binary', function (error) {
                if (error) {
                    HgLog.error(error);
                    return callback(error);
                }
                return callback(null, {
                    message: fname +  i18nHelper.translate(i18nHelper.detectLang(params), 'server.flupload.sul'),
                    success: true,
                    filename: fname
                });
            });
        }
        s3.putObject({
            Bucket: cfg.s3store.s3bucket,
            Key: params.RemoteFilePath + params.FileName,
            Body: new Buffer(cryptoHelper.encrypt(data), 'binary'),
            ACL: 'public-read',
            ContentType: 'binary',
            ContentDisposition: 'binary'
        }, function (error) {
            if (error) {
                return callback(error);
            }
            callback(null, {
                message: fname +  i18nHelper.translate(i18nHelper.detectLang(params), 'server.flupload.sul'),
                success: true,
                filename: fname
            });
        });
    });
}
function getFile(params, callback) {
    if (isLocal) {
        fs.readFile(params.srcPath + params.Filename, function (error, data) {
            callback(error, cryptoHelper.decrypt(data));
        });
    } else {
        s3.getObject({
            Bucket: cfg.s3store.s3bucket,
            Key: params.s3_srcPath + params.Filename
        }, function (error, data) {
            if (error || !data || !data.Body) {
                return callback(error || 'Error accessing file');
            }
            callback(null, cryptoHelper.decrypt(data.Body));
        });
    }
}

function saveReport(params, callback) {
    var destPath,
        sourceFileFullPathName = __dirname.replace('hgnode/helpers', 'provision/') + params.Filename,
        encryptedFileFullPathName = __dirname.replace('hgnode/helpers', 'provision/encrypted_') + params.Filename,
        sourceStream,
        destStream,
        cipher = cryptoHelper.createCipher();
    if (isLocal) {
        destPath = params.destPath;
        fs.mkdir(destPath, function (err) {
            if (err && err.code !== 'EEXIST') {
                HgLog.error(err.code);
                return callback(err);
            }
            if (typeof params.Buffer === 'string') {
                //this for existing reports that are not streamed to file
                fs.writeFile(destPath + params.Filename, cryptoHelper.encrypt(params.Buffer), 'binary', function (err) {
                    if (err) {
                        HgLog.error(err);
                        return callback(err);
                    }
                    callback(null, 'File saved');
                });
            } else {
                sourceStream = fs.createReadStream(sourceFileFullPathName);
                destStream = fs.createWriteStream(destPath + params.Filename);
                sourceStream.pipe(cipher);
                cipher.pipe(destStream);
                cipher.on('end', function () {
                    callback(null, 'File saved');
                });
            }
        });
    } else {
        if (typeof params.Buffer === 'string') {
            s3.putObject({
                Bucket: cfg.s3store.s3bucket,
                Key: params.s3_destPath + params.Filename,
                Body: new Buffer(cryptoHelper.encrypt(params.Buffer), 'binary'),
                ACL: 'public-read',
                ContentType: 'application/vnd.ms-excel'
            }, function (err) {
                if (err) {
                    HgLog.error(err);
                    if (callback) {
                        return callback(err);
                    }
                }
                if (callback) {
                    callback(null, 'File saved');
                }
            });
        } else {
            sourceStream = fs.createReadStream(sourceFileFullPathName);
            destStream = fs.createWriteStream(encryptedFileFullPathName);
            sourceStream.pipe(cipher);
            cipher.pipe(destStream);
            cipher.on('end', function () {
                sourceStream = fs.createReadStream(encryptedFileFullPathName);
                s3.putObject({
                    Bucket: cfg.s3store.s3bucket,
                    Key: params.s3_destPath + params.Filename,
                    Body: sourceStream,
                    ACL: 'public-read',
                    ContentType: 'application/vnd.ms-excel'
                }, function (err) {
                    if (err) {
                        HgLog.error(err);
                        if (callback) {
                            return callback(err);
                        }
                    }
                    if (callback) {
                        callback(null, 'File saved');
                    }
                });
            });
        }
    }
}

function saveBuffer(params) {
    var destPath;
    if (isLocal) {
        destPath = params.destPath;
        fs.mkdir(destPath, function (err) {
            if (err && err.code !== 'EEXIST') {
                HgLog.error(err.code);
            } else {
                fs.writeFile(destPath + '/' + params.CompositeFilename, params.Buffer, function (err) {
                    if (err) {
                        HgLog.error(err);
                    }
                    if (params.Callback) {
                        params.Callback();
                    }
                });
            }
        });
    } else {
        s3.putObject({
            Bucket: cfg.s3store.s3bucket,
            Key: params.s3_destPath + '/' + params.CompositeFilename,
            Body: new Buffer(params.Buffer),
            ACL: 'public-read',
            ContentType: 'image/svg+xml',
            ContentDisposition: 'binary'
        }, function (err) {
            if (err) {
                HgLog.error(err);
            }
            if (params.Callback) {
                params.Callback();
            }
        });
    }
}

function uploadGravatar(params) {
    if (params.UserId && params.Image && params.Callback) {
        if (isLocal) {
            fs.writeFile(path + '/static/img/user/' + params.UserId + '.jpg', params.Image.join(''), 'binary', function (err) {
                if (err) {
                    HgLog.error(err);
                }
                params.Callback(err);
            });
        } else {
            s3.putObject({
                Bucket: cfg.s3store.s3bucket,
                Key: 'user/' + params.UserId + '.jpg',
                Body: new Buffer(params.Image.join(''), 'binary'),
                ACL: 'public-read',
                ContentType: 'image/jpeg'
            }, function (err) {
                if (err) {
                    HgLog.error(err);
                }
                params.Callback(err);
            });
        }
    } else {
        HgLog.error('invalid parameters passed');
    }
}

// Moves a file asynchronously over partition borders
function moveFile(source, dest, callback) {
    var is = fs.createReadStream(source),
        os = fs.createWriteStream(dest);
    is.on('error', function (err) {
        HgLog.error(err);
        callback(err);
    });
    is.on('end', function () {
        fs.unlink(source, function (err) {
            if (err) {
                HgLog.error(err);
            }
            callback();
        });
    });
    os.on('error', function (err) {
        HgLog.error(err);
        callback(err);
    });
    is.pipe(os);
}

//copy user avatar and team avatar file to the local/s3 directory
function copyUserDefaultAvatar(options) {
    var r;
    if (isLocal) {
        r = fs.createReadStream(options.request.srcFilePath).
            pipe(fs.createWriteStream(options.request.destFilePath + options.request.dest));
        r.on('close', function () {
            if (options.callback) {
                options.callback(options.request);
            }
        });
    } else {
        s3.copyObject({
            Bucket: cfg.s3store.s3bucket,
            CopySource: cfg.s3store.s3bucket + options.request.source,
            Key: options.request.dest,
            ACL: 'public-read'
        }, function (err) {
            if (err) {
                HgLog.error(err);
            }
            if (options.callback) {
                if (err) {
                    return options.callback(err);
                }
                options.callback();
            }
        });
    }
}

function copyCompanyDefaultLogos(groupId, callback) {
    var r,
        defaultCompanyLogoFile = path + "/" + cfg.filepath.Provision + "company_default_logo.png",
        defaultCompanyProfileFile = path + "/" + cfg.filepath.Provision + "company_default_profile.jpg",
        localDestPath = path + "/" + cfg.filepath.ImageRoot,
        companyLogoDestFile = cfg.filepath.GroupRoot + "branding/" + groupId + ".png",
        companyProfileDestFile = cfg.filepath.GroupRoot + "profile/" + groupId + ".jpg";
    if (isLocal) {
        fs.createReadStream(defaultCompanyLogoFile).pipe(fs.createWriteStream(localDestPath + companyLogoDestFile));
        r = fs.createReadStream(defaultCompanyProfileFile).pipe(fs.createWriteStream(localDestPath + companyProfileDestFile));
        r.on('close', function (err, data) {
            if (err) {
                return callback(err);
            }
            callback(null, data);
        });
    } else {
        s3Util.pushS3File(defaultCompanyLogoFile, companyLogoDestFile, function (err) {
            if (err) {
                return callback(err);
            }
            s3Util.pushS3File(defaultCompanyProfileFile, companyProfileDestFile, function (err, data) {
                if (err) {
                    return callback(err);
                }
                callback(null, data);
            });
        });
    }
}

function copy(args) {
    var options = {
            filepath: '',
            request: null,
            callback: {}
        },
        r,
        destPath;
    ex.extend(options, args);
    if (isLocal) {
        destPath = options.request.destPath;
        if (destPath) {
            fs.mkdirp(destPath, function (err) {
                if (err && err.code !== 'EEXIST') {
                    HgLog.error(err.code);
                } else {
                    r = fs.createReadStream(options.request.filepath + options.request.source).pipe(fs.createWriteStream(options.request.filepath + options.request.dest));
                    r.on('close', function () {
                        options.callback(null, options.request);
                    });
                }
            });
        } else {
            r = fs.createReadStream(options.request.filepath + options.request.source).pipe(fs.createWriteStream(options.request.filepath + options.request.dest));
            r.on('close', function () {
                if (options.callback) {
                    options.callback(null, options.request);
                }
            });
        }
    } else {
        s3.getObject({
            Bucket: cfg.s3store.s3bucket,
            Key: options.request.source
        }, function (err, response) {
            if (err) {
                HgLog.error(err);
                if (options.callback) {
                    options.callback(err);
                }
            } else {
                s3.putObject({
                    Bucket: cfg.s3store.s3bucket,
                    Key: options.request.dest,
                    Body : response.Body,
                    ACL: 'public-read',
                    ContentType: response.ContentType,
                    ContentDisposition: 'binary'
                }, function (err, resp) {
                    if (options.callback) {
                        if (err) {
                            return options.callback(err);
                        }
                        options.callback(null, resp);
                    }
                });
            }
        });
    }
}

function uploadGroupProvisionFile(req, callback) {
    var fname,
        data;
    if (req.xhr) {
        fname = req.header('x-file-name').replace(/[&%#\^]/g, '').replace(/-/g, '');
        data = new Buffer('');
        req.on('data', function (chunk) {
            data = Buffer.concat([data, chunk]);
        });
        req.on('end', function () {
            req.rawBody = data;
            if (isLocal) {
                fs.writeFile(path + '/provision/' + fname, req.rawBody, 'binary', function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        message: fname + ' Successfully Uploaded',
                        success: true,
                        filename: fname
                    });
                });
            } else {
                s3.putObject({
                    Bucket: cfg.s3store.s3bucket,
                    Key: 'provision/' + fname,
                    Body: new Buffer(req.rawBody, 'binary'),
                    ACL: 'public-read',
                    ContentType: 'binary',
                    ContentDisposition: 'binary'
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        message: fname + ' Successfully Uploaded',
                        success: true,
                        filename: fname
                    });
                });
            }
        });
    }
}

function uploadGoalCycleParticipantFile(req, callback) {
    uploadGroupProvisionFile(req, callback);
}

function uploadPemCert(req, callback) {
    if (req.xhr) {
        var data = new Buffer(''),
            decoder = new StringDecoder('utf8');
        req.on('data', function (chunk) {
            data = Buffer.concat([data, chunk]);
        });
        req.on('end', function () {
            callback(null, decoder.write(data));
        });
    } else {
        callback('No XHR request to decode!');
    }
}

function createDirectory(folderName, callback) {
    var folderPath = path + '/provision/' + folderName;
    fs.mkdirp(folderPath, function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, {
            message: folderName + ' Successfully Created.',
            success: true,
            folderName: folderName
        });
    });
}

function deleteFile(fileName, callback) {
    fs.exists(fileName, function (exists) {
        if (exists) {
            fs.unlink(fileName, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    message: fileName + ' is deleted.',
                    success: true
                });
            });
        } else {
            callback(null, {
                message: fileName + ' not Present.',
                success: true
            });
        }
    });
}

function uploadExportData(folderName, callback) {
    var admZip = new AdmZip(),
        folderPath = path + '/provision/' + folderName,
        filepath = path + '/provision/' + folderName + '.zip',
        s3Object;
    admZip.addLocalFolder(folderPath, "");
    admZip.writeZip(filepath);
    if (isLocal) {
        fs.rmrf(folderPath, function (error) {
            if (error) {
                return callback(error);
            }
            callback(null, {
                message: filepath + ' Successfully Saved File.',
                success: true,
                filepath: filepath
            });
        });
    } else {
        fs.readFile(filepath, function (err, data) {
            s3Object = {
                Bucket: cfg.s3store.s3bucket,
                Key: 'provision/' + folderName + '.zip',
                Body: data,
                ACL: 'public-read',
                ContentType: 'binary',
                ContentDisposition: 'binary'
            };
            s3.putObject(s3Object, function (error) {
                if (error) {
                    return callback(error);
                }
                deleteFile(filepath, function (err) {
                    if (err) {
                        return callback(err);
                    }
                    fs.rmrf(folderPath, function (err) {
                        if (err) {
                            return callback(err);
                        }
                        callback(null, 'File Deleted');
                    });
                });
            });
        });
    }
}
function uploadExportedDataInReportFolder(params, callback) {
    var admZip = new AdmZip(),
        folderPath = path + '/provision/' + params.folderName,
        filepath = path + '/provision/' + params.folderName + '.zip',
        s3Object,
        destPath,
        destfolder;
    admZip.addLocalFolder(folderPath, "");
    admZip.writeZip(filepath);
    if (isLocal) {
        destPath = AppRootPath + '/' + cfg.filepath.ImageRoot + cfg.filepath.Reports + params.FriendlyGroupId + '/' + params.hgId + '.zip';
        destfolder = AppRootPath + '/' + cfg.filepath.ImageRoot + cfg.filepath.Reports + params.FriendlyGroupId + '/';
        fs.mkdir(destfolder, function (err) {
            if (err && err.code !== 'EEXIST') {
                HgLog.error(err.code);
            } else {
                fs.readFile(filepath, function (error, data) {
                    if (error) {
                        return callback(error);
                    }
                    fs.writeFile(destPath, cryptoHelper.encrypt(data), 'binary', function (error) {
                        if (error) {
                            return callback(error);
                        }
                        fs.rmrf(folderPath, function (error) {
                            if (error) {
                                return callback(error);
                            }
                            callback(null, {
                                message: filepath + ' Successfully Saved File.',
                                success: true,
                                filepath: filepath
                            });
                        });
                    });
                });
            }
        });
    } else {
        fs.readFile(filepath, function (err, data) {
            s3Object = {
                Bucket: cfg.s3store.s3bucket,
                Key: cfg.filepath.Reports + params.FriendlyGroupId + '/' + params.hgId + '.zip',
                Body: cryptoHelper.encrypt(data),
                ACL: 'public-read',
                ContentType: 'binary',
                ContentDisposition: 'binary'
            };
            s3.putObject(s3Object, function (error) {
                if (error) {
                    return callback(error);
                }
                deleteFile(filepath, function (err) {
                    if (err) {
                        return callback(err);
                    }
                    fs.rmrf(folderPath, function (err) {
                        if (err) {
                            return callback(error);
                        }
                        callback(null, 'File Deleted');
                    });
                });
            });
        });
    }
}

function createFileForExportedData(filepath, data, callback) {
    fs.writeFile(path + '/provision/' + filepath, data, function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, {
            message: filepath + ' Successfully Saved File.',
            success: true,
            filepath: filepath
        });
    });
}

function exportUserAvatars(params, callback) {
    var data = params.data,
        stream;
    data.forEach(function (user) {
        if (isLocal) {
            fs.exists(path + params.source + user.UserId + '.jpg', function (exists) {
                if (exists) {
                    stream = fs.createReadStream(path + params.source + user.UserId + '.jpg').
                        pipe(fs.createWriteStream(path + params.dest + user.UserId + '.jpg'));
                    stream.on('close', function (err) {
                        callback(err);
                    });
                }
            });
        } else {
            stream = fs.createWriteStream(path + params.dest + user.UserId + '.jpg');
            s3.getObject({
                Bucket: cfg.s3store.s3bucket,
                Key: path + params.s3_source + user.UserId + '.jpg'
            }).createReadStream().pipe(stream);
        }
    });
    callback(null, {
        message: 'Successfully copied user Avatars.',
        success: true
    });
}

function exportTeamAvatars(params, callback) {
    var data = params.data,
        stream;
    data.forEach(function (team) {
        if (isLocal) {
            fs.exists(path + params.source + team.hgId + '.jpg', function (exists) {
                if (exists) {
                    stream = fs.createReadStream(path + params.source + team.hgId + '.jpg').
                        pipe(fs.createWriteStream(path + params.dest + team.hgId + '.jpg'));
                    stream.on('close', function (err) {
                        callback(err);
                    });
                }
            });
        } else {
            stream = fs.createWriteStream(path + params.dest + team.hgId + '.jpg');
            s3.getObject({
                Bucket: cfg.s3store.s3bucket,
                Key: path + params.s3_source + team.hgId + '.jpg'
            }).createReadStream().pipe(stream);
        }
    });
    callback(null, {
        message: 'Successfully copied Team Avatars.',
        success: true
    });
}


function DeleteReport(params) {
    if (isLocal) {
        fs.unlink(params.srcPath + params.Filename, function (error) {
            if (error) {
                HgLog.error(error);
            }
        });
    } else {
        s3.deleteObject({
            Bucket: cfg.s3store.s3bucket,
            Key: params.s3_srcPath + params.Filename
        }, function (error, data) {
            if (error) {
                HgLog.error(error + data);
            }
        });
    }
}

function uploadPerformCardImportFile(req, callback) {
    var fname,
        data;
    if (req.xhr) {
        fname = req.header('x-file-name').replace(/[&%#\^]/g, '').replace(/-/g, '');
        data = new Buffer('');
        req.on('data', function (chunk) {
            data = Buffer.concat([data, chunk]);
        });
        req.on('end', function () {
            req.rawBody = data;
            if (isLocal) {
                fs.writeFile(path + '/provision/' + fname, req.rawBody, 'binary', function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        message: fname + ' Successfully Uploaded',
                        success: true,
                        filename: fname
                    });
                });
            } else {
                s3.putObject({
                    Bucket: cfg.s3store.s3bucket,
                    Key: 'provision/' + fname,
                    Body: new Buffer(req.rawBody, 'binary'),
                    ACL: 'public-read',
                    ContentType: 'binary',
                    ContentDisposition: 'binary'
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        message: fname + ' Successfully Uploaded',
                        success: true,
                        filename: fname
                    });
                });
            }
        });
    }
}

function uploadProvisionedBinaryFile(req, callback) {
    var fname,
        data;
    if (req.xhr) {
        fname = req.header('x-file-name').replace(/[&%#\^]/g, '').replace(/-/g, '');
        data = new Buffer('');
        req.on('data', function (chunk) {
            data = Buffer.concat([data, chunk]);
        });
        req.on('end', function () {
            req.rawBody = data;
            fs.writeFile(path + '/provision/' + fname, req.rawBody, 'binary', function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    message: fname + ' Successfully Uploaded',
                    success: true,
                    filename: fname
                });
            });
        });
    }
}

function uploadBrandingLogoFile(req, callback) {
    var fname,
        data,
        destPath = '/static/img/tmp/';
    if (req.xhr) {
        fname = req.header('x-file-name').replace(/[&%#\^]/g, '').replace(/-/g, '');
        data = new Buffer('');
        req.on('data', function (chunk) {
            data = Buffer.concat([data, chunk]);
        });
        req.on('end', function () {
            req.rawBody = data;
            fs.writeFile(path + destPath + fname, req.rawBody, 'binary', function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    message: fname + ' Successfully Uploaded',
                    success: true,
                    filename: fname,
                    path: destPath
                });
            });
        });
    }
}

function uploadProvisioningImage(req, callback) {
    var fname,
        data,
        destPath = '/static/img/tmp/';
    if (req.xhr) {
        fname = req.header('x-file-name').replace(/[&%#\^]/g, '').replace(/-/g, '');
        data = new Buffer('');
        req.on('data', function (chunk) {
            data = Buffer.concat([data, chunk]);
        });
        req.on('end', function () {
            req.rawBody = data;
            fs.writeFile(path + destPath + fname, req.rawBody, 'binary', function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, {
                    message: fname + ' Successfully Uploaded',
                    success: true,
                    filename: fname,
                    path: destPath
                });
            });
        });
    }
}

function saveExportedPerformCard(fname, data, callback) {
    if (isLocal) {
        fs.writeFile(path + '/provision/' + fname, data, function (error) {
            if (error) {
                return callback(error);
            }
            callback(null, {
                message: fname + ' Successfully Saved File.',
                success: true,
                filename: fname
            });
        });
    } else {
        s3.putObject({
            Bucket: cfg.s3store.s3bucket,
            Key: 'provision/' + fname,
            Body: new Buffer(data, 'utf8'),
            ACL: 'public-read',
            ContentType: 'text/plain',
            ContentDisposition: 'text/plain'
        }, function (error) {
            if (error) {
                return callback(error);
            }
            callback(null, {
                message: fname + ' Successfully Saved File',
                success: true,
                filename: fname
            });
        });
    }
}

function uploadTangoFileToS3(fileName, callback) {
    var source = [__dirname.replace('hgnode/helpers', ''), 'provision/', fileName].join('');
    if (isLocal) {
        return callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    }
    s3Util.pushS3File(source, 'provision/' + fileName, function (err) {
        if (err) {
            return callback(err);
        }
        callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    });
}

function uploadBrandingFileToS3(fileName, callback) {
    var source = [__dirname.replace('hgnode/helpers', ''), 'provision/', fileName].join(''),
        dest = 'provision/' + fileName;
    if (isLocal) {
        return callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    }
    s3Util.pushS3File(source, dest, function (err) {
        if (err) {
            return callback(err);
        }
        callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    });
}

function uploadBrandingLogoToS3(fileName, callback) {
    var source = [__dirname.replace('hgnode/helpers', ''), '/static/img/tmp/', fileName].join(''),
        dest = 'tmp/' + fileName;
    if (isLocal) {
        return callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    }
    s3Util.pushS3File(source, dest, function (err) {
        if (err) {
            return callback(err);
        }
        callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    });
}

function uploadProvisioningImageToS3Temp(fileName, callback) {
    var source = [__dirname.replace('hgnode/helpers', ''), '/static/img/tmp/', fileName].join(''),
        dest = 'tmp/' + fileName;
    if (isLocal) {
        return callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    }
    s3Util.pushS3File(source, dest, function (err) {
        if (err) {
            return callback(err);
        }
        callback(null, {
            message: fileName + ' Successfully Saved File',
            success: true,
            filename: fileName
        });
    });
}

function saveBannerFile(params, callback) {
    var srcFile = 'provision/' + params.BannerFile,
        fileName = params.GroupId + '.html',
        dstFile = 'banner/' + fileName;
    if (isLocal) {
        return callback(null, {
            message: 'Local environment. File push bypassed. ' + dstFile,
            success: true,
            FileName: fileName
        });
    }
    s3Util.moveS3File(srcFile, dstFile, 'binary', 'text/html', function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, {
            message: 'File moved to ' + dstFile,
            success: true,
            FileName: fileName
        });
    });
}

function saveBarLogo(params, callback) {
    var srcFile = 'tmp/' + params.BarLogo,
        fileName = params.GroupId + '.png',
        dstFile = 'company/branding/' + fileName;
    if (isLocal) {
        return callback(null, {
            message: 'Local environment. File push bypassed. ' + dstFile,
            success: true,
            FileName: fileName
        });
    }
    s3Util.moveS3File(srcFile, dstFile, 'binary', 'image/png', function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, {
            message: 'File moved to ' + dstFile,
            success: true,
            FileName: fileName
        });
    });
}

function savePubRecImage(params, callback) {
    var srcFile = 'tmp/' + params.FileName,
        fileName = params.Size + '-' + params.GroupId + '.png',
        dstFile = 'home/' + fileName;
    if (isLocal) {
        return callback(null, {
            message: 'Local environment. File push bypassed. ' + dstFile,
            success: true,
            FileName: fileName
        });
    }
    s3Util.moveS3File(srcFile, dstFile, 'binary', 'image/png', function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, {
            message: 'File moved to ' + dstFile,
            success: true,
            FileName: fileName
        });
    });
}

function saveProfileLogo(params, callback) {
    var srcFile = 'tmp/' + params.ProfileLogo,
        fileName = params.GroupId + '.jpg',
        dstFile = 'company/profile/' + fileName;
    if (isLocal) {
        return callback(null, {
            message: 'Local environment. File push bypassed. ' + dstFile,
            success: true,
            FileName: fileName
        });
    }
    s3Util.moveS3File(srcFile, dstFile, 'binary', 'image/jpg', function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, {
            message: 'File moved to ' + dstFile,
            success: true,
            FileName: fileName
        });
    });
}

function downloadExportedDataFile(fileName, callback) {
    if (isLocal) {
        return callback(null, {
            message: fileName + ' file downloaded successfully',
            success: true,
            fileName: fileName
        });
    }
    s3Util.getS3File('provision/' + fileName, path + '/provision/' + fileName, function (err) {
        if (err) {
            return callback(err);
        }
        callback(null, {
            message: fileName + ' file downloaded  successfully',
            success: true,
            fileName: fileName
        });
    });
}

function uploadSingleBadge(req, targetdir, callback) {
    var fname, data;
    if (req.xhr) {
        fname = req.header('x-file-name').replace(/[&%#\^]/g, '').replace(/-/g, '');
        data = new Buffer('');
        req.on('data', function (chunk) {
            data = Buffer.concat([data, chunk]);
        });
        req.on('end', function () {
            req.rawBody = data;
            if (isLocal) {
                fs.writeFile(path + targetdir + fname, req.rawBody, 'binary', function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        message: fname + ' Successfully Uploaded',
                        success: true,
                        filename: fname
                    });
                });
            } else {
                s3.putObject({
                    Bucket: cfg.s3store.s3bucket,
                    Key: 'tmp/badges/group/' + req.query.FriendlyGroupId + '/' + fname,
                    Body: new Buffer(req.rawBody, 'binary'),
                    ACL: 'public-read',
                    ContentType: 'image/svg+xml',
                    ContentDisposition: 'binary'
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    callback(null, {
                        message: fname + ' Successfully Uploaded',
                        success: true,
                        filename: fname
                    });
                });
            }
        });
    }
}

function uploadCertsToS3(params, finalCallback) {
    var files = [];
    if (isLocal) {
        return finalCallback(null, 'Running on the Local Environment');
    }
    params.Files.forEach(function (item) {
        files.push(['tmp/certs/group/', params.FriendlyGroupId, '/svg/', item].join(''));
        files.push(['tmp/certs/group/', params.FriendlyGroupId, '/tn/', item.replace('.svg', '.png')].join(''));
    });
    Async.eachLimit(files, 10, function (svgFile, callback) {
        var sourceFile = [__dirname.replace('hgnode/helpers', ''), 'static/img/', svgFile].join('');
        s3Util.pushS3File(sourceFile, svgFile, function (error) {
            if (error) {
                return callback(error);
            }
            callback();
        });
    }, function (error) {
        if (error) {
            return finalCallback(error);
        }
        finalCallback(null, 'Certificate Files Pushed to S3.');
    });
}

function uploadAvatarsToTmpS3(params, finalCallback) {
    var files;
    if (isLocal) {
        return finalCallback(null, 'Running on the Local Environment');
    }
    files = params.Manifest.map(function (item) {
        return {
            srcFile: ['tmp/avatar/group/', params.FriendlyGroupId, '/', item.Avatar].join(''),
            dstFile: ['tmp/avatar/group/', params.FriendlyGroupId, '/', item.UserId, '.jpg'].join('')
        };
    });
    Async.eachLimit(files, 10, function (avatar, callback) {
        var sourceFile = [__dirname.replace('hgnode/helpers', ''), 'static/img/', avatar.srcFile].join('');
        s3Util.pushS3File(sourceFile, avatar.dstFile, function (error) {
            if (error) {
                return callback(error);
            }
            callback();
        });
    }, function (error) {
        if (error) {
            return finalCallback(error);
        }
        finalCallback(null, 'Avatar Files Pushed to S3.');
    });
}

function saveAvatarsToS3(params, finalCallback) {
    var files;
    if (isLocal) {
        return finalCallback(null, 'Running on the Local Environment');
    }
    files = params.Users.map(function (item) {
        return {
            srcFile: ['tmp/avatar/group/', params.FriendlyGroupId, '/', item, '.jpg'].join(''),
            dstFile: ['user/', item, '.jpg'].join('')
        };
    });
    Async.eachLimit(files, 10, function (avatar, callback) {
        s3Util.moveS3File(avatar.srcFile, avatar.dstFile, 'binary', 'image/jpg', function (error) {
            if (error) {
                return callback(error);
            }
            callback();
        });
    }, function (error) {
        if (error) {
            return finalCallback(error);
        }
        finalCallback(null, 'Avatar Files Pushed to S3.');
    });
}

function uploadBadge(params, callback) {
    var file,
        fileBuffer,
        metaData;
    if (isLocal) {
        return callback({
            success: true,
            message: params.FileName + ' file successfully saved.',
            filename: params.FileName
        });
    }
    file = params.FolderPath + params.FileName;
    fileBuffer = fs.readFileSync(file);
    metaData = fsUtil.getContentTypeByFile(params.FileName);
    s3.putObject({
        Bucket: cfg.s3store.s3bucket,
        Key: 'tmp/badges/group/' + params.FriendlyGroupId + '/' + params.FileName,
        Body: fileBuffer,
        ACL: 'public-read',
        ContentType: metaData
    }, function (error) {
        if (error) {
            return callback({
                success: false,
                error: error
            });
        }
        callback({
            success: true,
            message: params.FileName + ' file successfully saved.',
            filename: params.FileName
        });
    });
}

function mobileAvatarUpload(req, filename, callback) {
    imageProcessor.crop(req.files.file.path, function (err) {
        if (err) {
            HgLog.error(err);
            return callback(err, null);
        }
        fs.readFile(req.files.file.path, function (err, data) {
            s3.putObject({
                Bucket: cfg.s3store.s3bucket,
                Key: 'user/' + filename,
                Body: data,
                ACL: 'public-read',
                ContentType: 'image/jpeg'
            }, function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, {message: 'Successfully Uploaded'});
                }
            });
        });
    });
}

module.exports = {
    saveReport: saveReport,
    copyUserDefaultAvatar: copyUserDefaultAvatar,
    saveBuffer: saveBuffer,
    copy: copy,
    deleteFile: deleteFile,
    uploadGravatar: uploadGravatar,
    uploadGroupProvisionFile: uploadGroupProvisionFile,
    createDirectory: createDirectory,
    uploadExportData: uploadExportData,
    createFileForExportedData: createFileForExportedData,
    exportUserAvatars: exportUserAvatars,
    exportTeamAvatars: exportTeamAvatars,
    uploadPerformCardImportFile: uploadPerformCardImportFile,
    uploadProvisionedBinaryFile: uploadProvisionedBinaryFile,
    uploadBrandingLogoFile: uploadBrandingLogoFile,
    saveExportedPerformCard: saveExportedPerformCard,
    moveFile: moveFile,
    downloadExportedDataFile: downloadExportedDataFile,
    uploadBadge: uploadBadge,
    uploadSingleBadge: uploadSingleBadge,
    uploadCertsToS3: uploadCertsToS3,
    mobileAvatarUpload: mobileAvatarUpload,
    copyCompanyDefaultLogos: copyCompanyDefaultLogos,
    uploadTangoFileToS3: uploadTangoFileToS3,
    uploadBrandingFileToS3: uploadBrandingFileToS3,
    uploadBrandingLogoToS3: uploadBrandingLogoToS3,
    saveBannerFile: saveBannerFile,
    saveBarLogo: saveBarLogo,
    saveProfileLogo: saveProfileLogo,
    uploadProvisioningImage: uploadProvisioningImage,
    uploadProvisioningImageToS3Temp: uploadProvisioningImageToS3Temp,
    savePubRecImage: savePubRecImage,
    uploadAvatarsToTmpS3: uploadAvatarsToTmpS3,
    saveAvatarsToS3: saveAvatarsToS3,
    uploadPemCert: uploadPemCert,
    getFile: getFile,
    DeleteReport: DeleteReport,
    uploadExportedDataInReportFolder: uploadExportedDataInReportFolder,
    uploadGoalCycleParticipantFile: uploadGoalCycleParticipantFile,
    upload: upload
};
