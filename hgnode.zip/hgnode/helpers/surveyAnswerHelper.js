var AnswerHelper = function () {
    'use strict';
    var ratingScaleCalcluator = function (params) {
            var maxValue = Math.max.apply(Math, params.AnswerSelectors.map(function (answerSelector) {
                return answerSelector.Value;
            }));
            return (params.AnswerValue - 1) / (maxValue - 1) * 100;
        },
        moodCalculator = function (params) {
            var maxValue = Math.max.apply(Math, params.AnswerSelectors.map(function (answerSelector) {
                return answerSelector.Value;
            }));
            return params.AnswerValue / maxValue * 100;
        },
        defaultValidator = function (params) {
            var invalid = (!params.AnswerSelectors || params.AnswerSelectors.length < 2),
                maxValue,
                minValue;
            if (invalid) {
                return !invalid;
            }
            maxValue = Math.max.apply(Math, params.AnswerSelectors.map(function (answerSelector) {
                return answerSelector.Value;
            }));
            minValue = Math.min.apply(Math, params.AnswerSelectors.map(function (answerSelector) {
                return answerSelector.Value;
            }));
            invalid = invalid || (params.AnswerValue < minValue || params.AnswerValue > maxValue);
            invalid = invalid || (params.AnswerSelectors.map(function (s) { return s.Value; }).indexOf(params.AnswerValue) === -1);
            return !invalid;
        },
        multipleChoiceValidator = function (params) {
            var invalid = (!params.AnswerSelectors || params.AnswerSelectors.length < 2);
            if (invalid) {
                return !invalid;
            }
            invalid = invalid || (params.AnswerSelectors.map(function (s) { return s.Value; }).indexOf(params.AnswerValue) === -1);
            return !invalid;
        },
        textValidator = function (params) {
            return params.Comment && params.Comment.length <= 120;
        },
        calculators = {
            RatingScale: function (params) {
                return ratingScaleCalcluator(params);
            },
            Mood: function (params) {
                return moodCalculator(params);
            },
            MultipleChoice: function () {
                return 100;
            },
            Text: function () {
                return 100;
            }
        },
        validators = {
            RatingScale: function (params) {
                return defaultValidator(params);
            },
            Mood: function (params) {
                return defaultValidator(params);
            },
            MultipleChoice: function (params) {
                return multipleChoiceValidator(params);
            },
            Text: function (params) {
                return textValidator(params);
            }
        };
    this.Calculate = function (params) {
        var calculator = calculators[params.AnswerType];
        if (!calculator) {
            return "method not implemented";
        }
        return calculator(params);
    };
    this.Validate = function (params) {
        var validator = validators[params.AnswerType];
        if (!validator) {
            return "method not implemented";
        }
        return validator(params);
    };
    this.GenerateAccessCode = function (length) {
        var charSet = "2345679acdefghjkmnpqrstwxyz",
            charLength = charSet.length,
            i,
            code = '';
        for (i = 0; i < length; i += 1) {
            code += charSet.charAt(Math.floor(Math.random() * charLength));
        }
        return code;
    };
};

module.exports = AnswerHelper;
