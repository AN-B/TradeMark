/*jslint node:true es5:true nomen:true*/
'use strict';
var paramUtil = require('../util/params.js'),
    httpHelper = require('./httpHelper.js'),
    config = require('../configurations/config.js'),
    keyStore = require('../configurations/keystore.js');

function getActualAddress(originalAddress) {
    var actualAddress = originalAddress;
    if (process.env.BUILD_ENV !== 'prod') {
        if (actualAddress.toLowerCase().trim() !== config.email.BlackHole.toLowerCase().trim()) {
            actualAddress = process.env.REDIRECT_ADDRESS || config.email.FromAddress;
        }
    }
    return actualAddress;
}

function getEmailStatus(params, callback) {
    var requestOptions,
        validationResult =  paramUtil.checkForRequiredParametersWithErrorResult(['id'], params, false, false);
    if (validationResult.success) {
        requestOptions = {
            hostname: 'api.expresspigeon.com',
            path: '/messages/' + params.id,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-auth-key': keyStore.expresspigeon_api
            }
        };
        httpHelper.sendRequest({ requestOptions : requestOptions, requestData : null }, function (error, responseData) {
            if (error) {
                callback(error, responseData);
            } else {
                callback(null, responseData);
            }
        });
    } else {
        callback(validationResult.error);
    }
}

function sendEmail(params, callback) {
    var emailOptions, requestOptions,
        requiredParams = ['ReplyTo', 'From', 'To', 'Subject', 'TemplateId', 'MergeFields'],
        validationResult =  paramUtil.checkForRequiredParametersWithErrorResult(requiredParams, params, false, false);
    if (validationResult.success) {
        emailOptions = {
            template_id: params.TemplateId,
            from: params.From,
            reply_to: getActualAddress(params.ReplyTo),
            to: getActualAddress(params.To),
            subject: params.Subject,
            merge_fields: params.MergeFields
        };
        requestOptions = {
            hostname: 'api.expresspigeon.com',
            path: '/messages',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': JSON.stringify(emailOptions).length,
                'X-auth-key': keyStore.expresspigeon_api
            }
        };
        httpHelper.sendRequest({ requestOptions : requestOptions, requestData : JSON.stringify(emailOptions) }, function (error, responseData) {
            if (error) {
                callback(error, responseData);
            } else {
                callback(null, responseData);
            }
        });
    } else {
        callback(validationResult.error);
    }
}

module.exports = {
    SendEmail : sendEmail,
    GetEmailStatus : getEmailStatus
};