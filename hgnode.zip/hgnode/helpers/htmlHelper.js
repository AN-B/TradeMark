/*jslint node:true es5:true nomen:true*/
'use strict';
function replaceTokens(text, params) {
    var keys,
        i,
        len;
    if (typeof params === 'object') {
        keys = Object.keys(params);
        for (i = 0, len = keys.length; i < len; i += 1) {
            text = text.replace(new RegExp('{{' + keys[i] + '}}', 'g'), params[keys[i]]);
        }
    }
    return text;
}

function toggleAreas(text, params) {
    var keys,
        i,
        len;
    if (typeof params === 'object') {
        keys = Object.keys(params);
        for (i = 0, len = keys.length; i < len; i += 1) {
            if (params[keys[i]]) {
                text = text.replace(new RegExp('<%' + keys[i] + '%>', 'g'), '');
            } else {
                text = text.replace(new RegExp('<%' + keys[i] + '.*' + keys[i] + '%>', 'g'), '');
            }
        }
    }
    return text;
}

module.exports = {
    replaceTokens: replaceTokens,
    toggleAreas: toggleAreas
};
