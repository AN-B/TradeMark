/*jslint node:true es5:true nomen:true stupid: true*/
"use strict";

function getRecognitionTitle(i18n, recognition) {
    var content,
        title = (recognition.SubValue) ? recognition.SubValue + ' (' + recognition.Template.Title + ')' : recognition.Template.Title;
    if (recognition.Template.TranslatedValues &&
            recognition.Template.TranslatedValues.length &&
            recognition.Template.TranslatedValues.some(function (item) {
                return item.lang === i18n;
            })) {
        content = recognition.Template.TranslatedValues.filter(function (item) {
            return item.lang === i18n;
        })[0];
        if (content) {
            title = content.values.SubValue ? [content.values.SubValue, ' (', content.values.Title, ')'].join('') : content.values.Title || recognition.Template.Title;
        }
    }
    return title;
}

module.exports = {
    getRecognitionTitle: getRecognitionTitle
};