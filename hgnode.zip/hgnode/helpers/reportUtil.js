'use strict';
var reportQueries = require('../helpers/queryLibrary.js').queryLibrary,
    arrayUtil = require('../util/arrayUtil.js'),
    getArrayIndexData = function (params) {
        var ret;
        arrayUtil.MultipleObjectIndexOf(params.Data, params.PropSearch, function (index) {
            if (index !== -1) {
                ret = params.Data[index];
            }
        });
        return ret;
    },
    getArrayFieldIndexData = function (params) {
        var ret, i, len;
        for (i = 0, len = params.Data.length; i < len; i += 1) {
            if (params.Data[i][params.FieldName]) {
                ret = params.Data[i][params.FieldName];
                break;
            }
        }
        return ret;
    },
    buildGroup = function (params) {
        var groupStmt = {}, ret = {};
        if (params.Data) {
            params.Data.GroupBy.forEach(function (item) {
                groupStmt[item.FieldAlias] = '$' + item.FieldName;
            });
            ret = { _id : groupStmt};
            params.Data.GroupFunc.forEach(function (item) {
                switch (item.Function.Type) {
                case 'sum':
                    ret[item.FieldAlias] = { '$sum':  (item.Function.FieldType === 'Property') ? '$' + item.Function.FieldValue : item.Function.FieldValue};
                    break;
                }
            });
        }
        return ret;
    },
    getFilter = function (params) {
        var filter = {}, temp, lst, vl;
        params.FilterDefinition.map(function (item) {
            if (item.Type === 'Static') {
                if (item.Value !== undefined) {
                    filter[item.Name] = item.Value;
                }
            } else if (item.Type === 'date') {
                temp = getArrayFieldIndexData({Data : params.FilterData, FieldName : item.Name});
                if (temp.Start && temp.End) {
                    if (item.IncludeStart === undefined && item.IncludeEnd) {
                        filter[item.Name] = { $lte : temp.End };
                    } else if (item.IncludeStart && item.IncludeEnd) {
                        filter[item.Name] = { $gte : temp.Start, $lte : temp.End };
                    } else if (!item.IncludeStart && item.IncludeEnd) {
                        filter[item.Name] = { $gt : temp.Start, $lte : temp.End };
                    } else if (item.IncludeStart && !item.IncludeEnd) {
                        filter[item.Name] = { $gte : temp.Start, $lt : temp.End };
                    } else if (!item.IncludeStart && !item.IncludeEnd) {
                        filter[item.Name] = { $gt : temp.Start, $lt : temp.End };
                    }
                }
            } else if (item.Type === 'NotInArrary') {
                lst = getArrayFieldIndexData({Data : params.FilterData, FieldName : item.Name});
                if (lst && lst.length > 0) {
                    filter[item.Name] = { $nin : lst};
                }
            } else if (item.Type === 'string') {
                vl = getArrayFieldIndexData({Data : params.FilterData, FieldName : item.Name});
                if (vl !== undefined) {
                    filter[item.Name] = getArrayFieldIndexData({Data : params.FilterData, FieldName : item.Name});
                }
            }
        });
        return filter;
    },
    buildExecutedQuery = function (params) {
        var title, filter, data, sort, limit, group;
        filter = getFilter({FilterDefinition : params.Data, FilterData : params.Filter});
        title = (params.PreQueryTitle) ?  params.PreQueryTitle + ' ' + params.Query.Title : params.Query.Title;
        sort = (params.Query.Sort !== undefined && params.Query.Sort !== null) ? params.Query.Sort : {};
        limit = (params.Query.Limit !== undefined && params.Query.Limit !== null) ? params.Query.Limit : 0;
        if (params.Query.Type === 'find') {
            data = {limitQuery : limit, sortQuery : sort, filterQuery : filter, projectQuery : params.Query.Project, entity : params.Query.Entity, Title: title, type: params.Query.Type};
        } else if (params.Query.Type === 'aggregate') {
            group = (params.GroupDefinition && params.GroupDefinition.Data) ? buildGroup({Data : params.GroupDefinition.Data}) : params.Query.Group;
            data = {sortQuery : sort, filterQuery : filter, groupQuery : group, entity : params.Query.Entity, Title: title, type: params.Query.Type};
        } else if (params.Query.Type === 'distinct') {
            data = {filterQuery : filter, distinctField : params.Query.DistinctField,  entity : params.Query.Entity, Title: title, type: params.Query.Type};
        }
        return data;
    },
    buildQuery = function (params) {
        var queries = [], queryFilterDefinition, queryGroupDefinition, queryFilter,
            preQueryTitle;
        params.ReportQueries.Queries.map(function (item) {
            queryFilterDefinition = getArrayIndexData({Data : params.ReportQueries.FilterDefinition, PropSearch : [{FieldName : 'Name', FieldValue : item.Filter}]});
            queryGroupDefinition = (item.Group) ? getArrayIndexData({Data : params.ReportQueries.GroupDefinition, PropSearch : [{FieldName : 'Name', FieldValue : item.Group}]}) : null;
            queryFilter = getArrayIndexData({Data : params.Filters, PropSearch : [{FieldName : 'Name', FieldValue : item.Filter}]});
            if (queryFilterDefinition && queryFilter) {
                if (queryFilterDefinition.IsFilterAnArray) {
                    if (queryFilter.Filter) {
                        queryFilter.Filter.map(function (queryFilterItem) {
                            if (item.AddPreQueryTitle) {
                                if (queryFilterDefinition.PreQueryTitleField) {
                                    preQueryTitle = (queryFilterItem[0][queryFilterDefinition.PreQueryTitleField] && queryFilterItem[0][queryFilterDefinition.PreQueryTitleField].Title) ? queryFilterItem[0][queryFilterDefinition.PreQueryTitleField].Title : queryFilterItem[0][queryFilterDefinition.PreQueryTitleField];
                                }
                            }
                            queries.push(buildExecutedQuery({GroupDefinition : queryGroupDefinition, Query : item, Data : queryFilterDefinition.Data, Filter: queryFilterItem, PreQueryTitle : preQueryTitle}));
                        });
                    }
                } else {
                    queries.push(buildExecutedQuery({GroupDefinition : queryGroupDefinition, Query : item, Data : queryFilterDefinition.Data, Filter: queryFilter.Filter}));
                }
            }
        });
        return queries;
    },
    getQuery = function (params, callback) {
        var querySection = getArrayIndexData({Data : reportQueries, PropSearch : [{FieldName : 'Name', FieldValue : params.ReportName}]}),
            queries = [];
        if (querySection) {
            queries = buildQuery({ ReportQueries : querySection, Filters : params.Filters});
            callback(null, {Queries: queries, ExcelTemplate : querySection.ExcelTemplate});
        } else {
            callback(params.ReportName + ' was not found in the Report Query Library');
        }
    },
    getExcelReports = function () {
        var ret = [];
        reportQueries.map(function (item) {
            if (item.ExcelTemplate !== '') {
                ret.push({Name : item.Name, DisplayName : item.DisplayName});
            }
        });
        ret.sort(function (a, b) {
            return a.Name.toLowerCase() > b.Name.toLowerCase() ? 1 : -1;
        });
        return ret;
    },
    buildFilter = function (params) {
        var filter = [];
        if (params.GroupId) {
            filter.push({ GroupId : params.GroupId});
        }

        if (params.hgId) {
            filter.push({ hgId : params.hgId});
        }

        if (params.PreferenceDefaultGroupId) {
            filter.push({ 'Preference.DefaultGroupId' : params.PreferenceDefaultGroupId});
        }

        if (params.CreatorMemberGroupId) {
            filter.push({ 'CreatorMember.GroupId' : params.CreatorMemberGroupId});
        }

        if (params.CareerTrackTemplateGroupId) {
            filter.push({ 'CareerTrackTemplate.GroupId' : params.CareerTrackTemplateGroupId});
        }

        if (params.CreatedDate) {
            filter.push({ CreatedDate : {
                Start : params.CreatedDate.Start,
                End : params.CreatedDate.End
            }});
        }

        if (params.Start && params.End) {
            filter.push({ Date : {
                Start : params.Start,
                End : params.End
            }});
        }
        return filter;
    };

module.exports = {
    getQuery : getQuery,
    getArrayIndexData : getArrayIndexData,
    getExcelReports : getExcelReports,
    buildFilter : buildFilter
};
