/*jslint node:true es5:true nomen:true*/
'use strict';
var Goal = {
    Status: {
        Behind: 'profile.goals.prgs.beh',
        OnTrack: 'profile.goals.prgs.ont',
        AtRisk: 'profile.goals.prgs.risk',
        Aligned: 'admin.gls.cyc.det.ali'
    },
    Type: {
        Member: 'profile.goals.gtyp.ind',
        Team: 'profile.goals.gtyp.dep',
        Company: 'profile.goals.gtyp.cop',
        Personal: 'profile.goals.gtyp.per'
    },
    GoalStatus: {
        Editing: 'goal.int.edi',
        SubmittedForSet: 'goal.int.sfs',
        InProgress: 'common.ipr',
        PendingClosure: 'goal.int.pcl',
        SubmittedForClosure: 'goal.int.sfc',
        Closed: 'goal.int.cls',
        Archived: 'common.arc'
    }
},
    Member = {
        Role: {
            Employee: 'common.mrole.emp',
            Consultant: 'common.mrole.con',
            Manager: 'common.mrole.man',
            Director: 'common.mrole.dir',
            Executive: 'common.mrole.exe',
            Admin: 'common.mrole.adm',
            HGAdmin: 'HGAdmin'
        }
    };

module.exports = {
    Goal: Goal,
    Member: Member
};