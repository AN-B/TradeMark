/*jslint node:true es5:true nomen:true stupid: true*/
'use strict';
var fs = require('fs'),
    hgLog = require('../framework/HgLog.js');

function createDirPath(dirPath, callback) {
    fs.exists(dirPath, function (exists) {
        if (exists) {
            callback(null, {success: true});
        } else {
            fs.mkdir(dirPath, function (err) {
                if (err && err.code !== 'EEXIST') {
                    hgLog.error(err.code);
                    callback(err.code, {success: false});
                } else {
                    callback(null, {success: true});
                }
            });
        }
    });
}

function getContentDispositionFile(fn) {
    return ['.html', '.csv', '.css', '.json', '.js'].indexOf(fn.toLowerCase()) >= 0 ? 'text' : 'binary';
}

function getContentTypeByFile(fileName) {
    var rc, fn = fileName.toLowerCase();
    if (fn.indexOf('.html') >= 0) {
        rc = 'text/html';
    } else if (fn.indexOf('.css') >= 0) {
        rc = 'text/css';
    } else if (fn.indexOf('.json') >= 0) {
        rc = 'application/json';
    } else if (fn.indexOf('.js') >= 0) {
        rc = 'application/x-javascript';
    } else if (fn.indexOf('.png') >= 0) {
        rc = 'image/png';
    } else if (fn.indexOf('.jpg') >= 0) {
        rc = 'image/jpg';
    } else if (fn.indexOf('.svg') >= 0) {
        rc = 'image/svg+xml';
    } else {
        rc = 'application/octet-stream';
    }
    return rc;
}

function getFileList(path) {
    var i, fileInfo, filesFound, fileList = [];
    filesFound = fs.readdirSync(path);
    for (i = 0; i < filesFound.length; i += 1) {
        fileInfo = fs.lstatSync(path + filesFound[i]);
        if (fileInfo.isFile()) {
            fileList.push(filesFound[i]);
        }
    }
    return fileList;
}

module.exports = {
    createDirPath: createDirPath,
    getContentTypeByFile: getContentTypeByFile,
    getFileList: getFileList,
    getContentDispositionFile : getContentDispositionFile
};