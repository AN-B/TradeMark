/*jslint node:true es5:true nomen:true*/
'use strict';
var nodeIp = require('ip');
//Validate IP Range
//http://stackoverflow.com/questions/1503893/validate-ip-address-is-not-0-0-0-0-or-multicast-address
function ipToNumber(ipAddress) {
    var arr = ipAddress.split("."),
        n = 0,
        i;
    for (i = 0; i < 4; i += 1) {
        n = n * 256;
        n += parseInt(arr[i], 10);
    }
    return n;
}
function isIPInRange(params) {
    var min = ipToNumber(params.Start),
        max = ipToNumber(params.End),
        ipNum = ipToNumber(params.TestClientIP);
    return (ipNum !== 0 && (ipNum >= min && ipNum <= max));
}
function validClientIP(params) {
    var i = 0, valid = false;
    if (!nodeIp.isPrivate(params.IPAddress)) {
        for (i = 0; i < params.GroupSettings.IPRange.length; i += 1) {
            if (!params.GroupSettings.IPRange[i].End && params.GroupSettings.IPRange[i].Start === params.IPAddress) {
                valid = true;
                break;
            }
            if (params.GroupSettings.IPRange[i].End && isIPInRange({ TestClientIP : params.IPAddress,
                    Start : params.GroupSettings.IPRange[i].Start,
                    End : params.GroupSettings.IPRange[i].End })) {
                valid = true;
                break;
            }
        }
    }
    return valid;
}

module.exports = {
    validClientIP: validClientIP
};