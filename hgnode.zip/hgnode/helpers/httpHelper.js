/*jslint node:true es5:true nomen:true*/
'use strict';
var https = require('https'),
    httpResponseCodes = require('../enums/HttpResponseCodes.js');

function sendRequest(params, callback) {
    if (!process.env.BUILD_ENV || ['test'].indexOf(process.env.BUILD_ENV || '') > -1) {
        return callback();
    }
    if (!params.requestOptions) {
        return callback('Missing requestOptions.');
    }
    if (params.requestOptions.method === 'POST' && !params.requestData) {
        return callback('Missing requestData.');
    }

    var httpsRequest, responseData = '';
    httpsRequest = https.request(params.requestOptions, function (httpsResponse) {
        httpsResponse.on('data', function (dataChunk) {
            responseData += dataChunk;
        });
        httpsResponse.on('end', function () {
            if (httpsResponse.statusCode === httpResponseCodes.Success.OK || httpsResponse.statusCode === httpResponseCodes.Success.Created) {
                callback(null, responseData);
            } else {
                callback('Error sending requests (HTTP ' + httpsResponse.statusCode + ') ', responseData);
            }
        });
        httpsResponse.on('error', function (error) {
            callback(error);
        });
    });
    if (params.requestData) {
        httpsRequest.write(params.requestData);
    }
    httpsRequest.end();
}

module.exports = {
    sendRequest: sendRequest
};
