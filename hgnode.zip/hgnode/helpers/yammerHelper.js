"use strict";

var Config = require('../configurations/config'),
    Keystore = require('../configurations/keystore'),
    EntityEnums = require('../enums/EntityEnums'),
    HgLog = require('../framework/HgLog'),
    https = require('https'),
    ResponseCodes = require('../enums/HttpResponseCodes');

function getToken(params, callback) {
    var req;

    req = https.request({
        hostname: Config.yammer.oauthhost,
        path: Config.yammer.oauthpath.accessToken + '?client_id=' + Keystore.yammer.clientId + '&client_secret=' + Keystore.yammer.clientSecret + '&code=' + params.code,
        port: 443,
        method: 'POST'
    }, function (res) {
        var stringResponse = '',
            jsonResponse;

        res.on('data', function (dataChunk) {
            stringResponse += dataChunk;
        });
        res.on('end', function () {
            try {
                jsonResponse = JSON.parse(stringResponse);

                params.YammerProps = {
                    access_token: jsonResponse.access_token.token,
                    created_at: new Date(jsonResponse.access_token.created_at).getTime(),
                    expires: jsonResponse.access_token.expires_at,
                    network_name: jsonResponse.user.network_name,
                    verified_admin: jsonResponse.user.verified_admin,
                    user_email: jsonResponse.user.contact.email_addresses[0].address,
                    user_hgId: params.UserId,
                    user_name: jsonResponse.user.full_name
                };

                callback(null, params);
            } catch (err) {
                HgLog.error('Error parsing Yammer JSON: ' + err + '. Yammer response: ' + stringResponse);
                callback('Error parsing Yammer JSON: ' + stringResponse, null);
            }
        });
        res.on('error', function (err) {
            HgLog.error('Error receiving Yammer response: ' + err);
            callback('Error receiving Yammer response: ' + err, null);
        });
    });
    req.end();
}

function getYammerAuthUrl() {
    return 'https://' + Config.yammer.oauthhost + Config.yammer.oauthpath.authorization +
        '?client_id=' + Keystore.yammer.clientId;
}

function postToYammer(params, callback) {
    var req,
        payloadString = JSON.stringify(params.payload);

    HgLog.debug('Posting to Yammer', params.payload);

    req = https.request({
        hostname: Config.yammer.oauthhost,
        port: 443,
        path: params.yammerEndpoint,
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + params.accessToken,
            'Content-Type': 'application/json'
        }
    }, function (res) {
        var stringResponse = '';

        res.on('data', function (data) {
            stringResponse += data;
        });
        res.on('end', function () {
            if (res.statusCode === ResponseCodes.ClientError.TooManyRequests) {
                HgLog.error('Reached Yammer rate limit:', stringResponse);
                return callback({
                    statusCode: res.statusCode,
                    error: 'Reached Yammer rate limit: ' + stringResponse
                });
            }

            if (res.statusCode >= 300) {
                HgLog.error('Received ' + res.statusCode + ' response from Yammer:', stringResponse);
                HgLog.error('Tried to send this payload:', params.payload);
                return callback({
                    statusCode: res.statusCode,
                    error: 'Received ' + res.statusCode + ' response from Yammer: ' + stringResponse + '. Payload: ' + payloadString
                });
            }

            try {
                callback(null, JSON.parse(stringResponse));
            } catch (err) {
                HgLog.error('Error parsing Yammer JSON: ' + err + '. Yammer response: ' + stringResponse);
                callback({
                    error: 'Error parsing Yammer JSON: ' + stringResponse
                });
            }
        });
        res.on('error', function (err) {
            HgLog.error('Error posting to Yammer: ' + err.error);
            callback(err);
        });
    });

    req.write(payloadString);
    req.end();
}

function postMessage(params, callback) {
    params.yammerEndpoint = '/api/v1/messages.json';
    postToYammer(params, callback);
}

function getYammerData(options, callback) {
    https.get(options, function (res) {
        var stringResponse = '';

        res.on('data', function (data) {
            stringResponse += data;
        });
        res.on('end', function () {
            if (res.statusCode === ResponseCodes.ClientError.TooManyRequests) {
                HgLog.error('Reached Yammer rate limit:', stringResponse);
                return callback({
                    statusCode: res.statusCode,
                    error: 'Reached Yammer rate limit: ' + stringResponse
                });
            }

            if (res.statusCode >= 300) {
                HgLog.error('Received ' + res.statusCode + ' response from Yammer:', stringResponse);
                HgLog.error('Tried to get yammer info for http options: ' + JSON.stringify(options));
                return callback({
                    statusCode: res.statusCode,
                    error: 'Received ' + res.statusCode + ' response from Yammer: ' + stringResponse + '.'
                });
            }

            try {
                callback(null, JSON.parse(stringResponse));
            } catch (err) {
                HgLog.error('Error parsing Yammer JSON: ' + err);
                callback('Error parsing Yammer JSON: ' + err);
            }
        });
        res.on('error', function (err) {
            HgLog.error('Error querying Yammer data: ' + err);
            callback('Error querying Yammer data: ' + err);
        });
    });
}
function getYammerAutocomplete(params, callback) {
    getYammerData({
        hostname: Config.yammer.oauthhost,
        path: '/api/v1/autocomplete/ranked?models=' + params.queryModels + '&prefix=' + params.queryText,
        port: 443,
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer ' + params.accessToken
        }
    }, callback);
}

function getYammerUsersInNetwork(params, callback) {
    HgLog.debug(['Getting Yammer Users for network with access token: ', params.accessToken].join(''));
    getYammerData({
        hostname: Config.yammer.oauthhost,
        path: '/api/v1/users.json',
        port: 443,
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer ' + params.accessToken
        }
    }, function (err, data) {
        var yammerMap = {},
            primaryEmail,
            email;
        if (err) {
            return callback(err);
        }
        data.forEach(function (datum) {
            primaryEmail = datum.contact && datum.contact.email_addresses && datum.contact.email_addresses.find(function (email) {
                return email.type === EntityEnums.YammerEmailType;
            });
            primaryEmail = primaryEmail && primaryEmail.address && primaryEmail.address.toLowerCase();
            email = datum.email && datum.email.toLowerCase();
            if (email) {
                yammerMap[email] = datum.id;
            }
            if (primaryEmail) {
                yammerMap[primaryEmail] = datum.id;
            }
        });
        callback(null, yammerMap);
    });
}

module.exports = {
    getToken: getToken,
    getYammerAuthUrl: getYammerAuthUrl,
    postMessage: postMessage,
    getYammerAutocomplete: getYammerAutocomplete,
    getYammerUsersInNetwork: getYammerUsersInNetwork
};
