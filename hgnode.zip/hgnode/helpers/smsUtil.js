"use strict";
var AWS = require('aws-sdk'),
    phone = require('phone'),
    keystore = require('../configurations/keystore.js'),
    sns;


AWS.config.update({
    accessKeyId: keystore.amazon_aws.key,
    secretAccessKey: keystore.amazon_aws.secret,
    region: 'us-east-1'
});

sns = new AWS.SNS({apiVersion: '2010-03-31'});

function publish(params, callback) {
    sns.publish({
        PhoneNumber: params.phoneNumber,
        Message: params.message
    }, callback);
}

function toE164(params) {
    return phone(params.phoneNumber, params.country || '')[0];
}

module.exports = {
    publish: publish,
    toE164: toE164
};