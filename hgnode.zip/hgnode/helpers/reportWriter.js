'use strict';
var RWriter = function (params) {
    var fs = require('fs'),
        csvWriterModule = require('csv-write-stream'),
        XlsxWriter = require('../lib/XlsxWriter.js'),
        paramUtil = require('../util/params.js'),
        allowedType = ['csv', 'xlsx'],
        requiredParams = ['Type', 'FilePath', 'Header'],
        ReportWriter,
        valResult;
    valResult = paramUtil.checkForRequiredParametersWithErrorResult(requiredParams, params, false, false);
    if (!valResult.success) {
        throw new Error(valResult.error);
    }
    if (allowedType.indexOf(params.Type) === -1) {
        throw new Error('Error Un-Recognized Report type');
    }
    ReportWriter = function init() {
        this.reportType = params.Type;
        switch (params.Type) {
        case 'csv':
            this.writer = csvWriterModule({ headers: params.Header});
            this.writer.pipe(fs.createWriteStream(params.FilePath));
            break;
        case 'xlsx':
            this.writer = new XlsxWriter();
            this.writer.getReadStream().pipe(fs.createWriteStream(params.FilePath));
            if (params.Style && params.Style.ColumnWidth) {
                this.writer.defineColumns(params.Style.ColumnWidth);
            }
            this.writer.addHeader(params.Header);
            break;
        }
    };
    ReportWriter.prototype.addRow = function (row) {
        switch (this.reportType) {
        case 'csv':
            this.writer.write(row);
            break;
        case 'xlsx':
            this.writer.addRowArray(row);
            break;
        }
        return;
    };
    ReportWriter.prototype.finish = function () {
        switch (this.reportType) {
        case 'csv':
            this.writer.end();
            break;
        case 'xlsx':
            this.writer.finalize();
            break;
        }
    };
    return new ReportWriter();
};
module.exports = RWriter;
