"use strict";
var Iconv  = require('iconv').Iconv,
    HgLog = require('../framework/HgLog.js'),
    ClusterCache = require('../framework/ClusterCache.js'),
    jsonHelper = require('../helpers/jsonHelper.js'),
    englishSpeaking = [
        'en-us',
        'en-au',
        'en-bz',
        'en-ca',
        'en-cb',
        'en-gb',
        'en-in',
        'en-ie',
        'en-jm',
        'en-nz',
        'en-ph',
        'en-za',
        'en-tt',
        'pt-br'
    ],
    requireUncached = function (module) {
        delete require.cache[require.resolve(module)];
        return require(module);
    },
    getRequireFunc = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1 ? requireUncached : require,
    getFilePath = function (langIndex) {
        var langPackage;
        if (langIndex) {
            try {
                langPackage = getRequireFunc('../../static/templates/i18n/' + langIndex + '.json');
            } catch (e) {
                // if the file does not exist, send back the default english file
                HgLog.error(e);
                langIndex = langIndex.split('/');
                switch (langIndex.length) {
                case 4:
                    langIndex = langIndex[2] + '/' + langIndex[3];
                    break;
                case 3:
                    langIndex = langIndex[2];
                    break;
                case 2:
                    langIndex = langIndex[1];
                    break;
                default:
                    langIndex = 'en';
                    break;
                }
                return getRequireFunc('../../static/templates/i18n/' + langIndex + '.json');
            }
        }
        return langPackage;
    },
    languageCache = {},
    customTerminologyCache = {},
    supportedLanguages = {
        en: 'English',
        'pt-br': 'Portuguese - Brazil'
    };

Object.keys(supportedLanguages).forEach(function (sl) {
    languageCache[sl] = getFilePath(sl);

    // Remove mobile client strings to reduce memory usage and data transmission to web
    if (languageCache[sl] && languageCache[sl].mcli) {
        delete languageCache[sl].mcli;
    }

    languageCache['email/' + sl] = getFilePath('email/' + sl);
});

function getLanguageAbbr(value) {
    var ret;
    value = value || supportedLanguages.en;
    ret = Object.keys(supportedLanguages).filter(function (item) {
        return supportedLanguages[item].toLowerCase() === value.toLowerCase();
    });
    return ret.length ? ret[0] : '';
}

function getLanguageName(value) {
    var ret = Object.keys(supportedLanguages).filter(function (key) {
        return key === value.toLowerCase();
    }).map(function (mvalue) {
        return supportedLanguages[mvalue];
    });
    return ret.length ? ret[0] : '';
}

function getLanguageIndex(i18n) {
    if (i18n) {
        i18n = i18n.split(',')[0].split(';')[0].toLowerCase();
    }
    if (!i18n || englishSpeaking.indexOf(i18n) > -1) {
        i18n = 'en';
    }
    return i18n;
}

function detectLang(params, excludeCustom) {
    var theLang = 'en-US,en;q=0.8';
    if (params.req && params.req.headers && params.req.headers['accept-language']) {
        theLang = params.req.headers['accept-language'];
    }
    if (!excludeCustom) {
        if (params.currentuser && params.currentuser.UserContext && params.currentuser.UserContext.CurrentGroupId) {
            theLang = params.currentuser.UserContext.CurrentGroupId + '/' + theLang;
        } else if (params.GroupId) {
            theLang = params.GroupId + '/' + theLang;
        }
    }
    return theLang;
}

function translate(lang, index, params, level) {
    var trans,
        keys,
        reg,
        parts,
        groupId,
        i,
        len,
        target,
        theLangCache = {},
        j,
        jlen,
        langPath,
        origLangPath;
    if (!lang || typeof index !== 'string') {
        return index;
    }
    // prevent infinite loop
    if (level > 5) {
        return 'circular reference for ' + index;
    }
    origLangPath = lang;
    lang = lang.split('/');
    switch (lang.length) {
    case 3:
        groupId = lang[0];
        target = lang[1];
        lang = lang[2];
        break;
    case 2:
        // first param can either be group id or target, but not both, check to see which it is
        if (lang[0].length === 36) {
            groupId = lang[0];
        } else {
            target = lang[0];
        }
        lang = lang[1];
        break;
    default:
        lang = lang[0];
        break;
    }
    lang = getLanguageIndex(lang);
    langPath = lang;
    if (target) {
        langPath = target + '/' + lang;
    }
    if (groupId && customTerminologyCache && customTerminologyCache[groupId]) {
        for (j = 0, jlen = customTerminologyCache[groupId].length; j < jlen; j += 1) {
            theLangCache[customTerminologyCache[groupId][j].i18n] = customTerminologyCache[groupId][j].lang;
        }
    }
    if (!theLangCache[langPath]) {
        theLangCache = languageCache;
    }
    parts = index.split('.');
    trans = theLangCache[langPath];
    if (!trans) {
        if (target) {
            trans = theLangCache[target + '/en'];
        } else {
            trans = theLangCache.en;
        }
    }
    for (i = 0, len = parts.length; i < len; i += 1) {
        if (trans) {
            trans = trans[parts[i]];
        }
    }
    // replace tokenized fields with parameters
    if (trans && params) {
        keys = Object.keys(params);
        for (i = 0, len = keys.length; i < len; i += 1) {
            reg = new RegExp("{{" + keys[i] + "}}", "g");
            trans = trans.replace(reg, params[keys[i]]);
        }
    }
    if (trans && trans.indexOf('@:') > -1) {
        return translate(origLangPath, trans.split('@:')[1], params, level ? level + 1 : 1);
    }
    // if translation is not found on foreign language, force english
    if (lang !== 'en' && !trans) {
        return translate(target ? target + '/en' : 'en', index, params);
    }
    return trans || index;
}

function serverTranslate(lang, index, params) {
    index = jsonHelper.parseJsonString(index || '') || index;
    if (typeof index === 'string') {
        return translate(lang, index, params);
    }
    if (Array.isArray(index)) {
        return (index.length === 2) ?
                translate(lang, index[0], index[1]) :
                translate(lang, index[0], params);
    }
    return index;
}

function convertTextToAscii(text) {
    return text ? new Iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE').convert(text).toString() : '';
}

function getDefaultLanguageFile(lang) {
    if (languageCache[lang]) {
        return languageCache[lang];
    }
    if (lang.split('/').length === 2) {
        return languageCache['email/en'];
    }
    return languageCache.en;
}

function removeCustomTerminology(groupId) {
    if (customTerminologyCache[groupId]) {
        delete customTerminologyCache[groupId];
    }
}

function setAllCustomTerminologyFiles(params) {
    if (params.EntityCache) {
        if (!params.query) {
            params.query = {};
        }
        params.EntityCache.GroupTerminology.find(params.query, function (err, terminology) {
            var k,
                x,
                t,
                lang,
                ob,
                obk,
                key,
                parts,
                i,
                len,
                pointer,
                generateMobileTerms = function (params) {
                    var langData;
                    obk = Object.keys(lang.Definitions);
                    for (ob = obk.length - 1; ob > -1; ob -= 1) {
                        key = obk[ob];
                        parts = key.split('-');
                        // Include only mobile client strings to reduce memory usage and data transmission to mobile
                        if (parts[0] === 'mcli') {
                            langData = langData || {};
                            pointer = langData;
                            for (i = 0, len = parts.length; i < len; i += 1) {
                                if (i === (len - 1)) {
                                    pointer[parts[i]] = lang.Definitions[key];
                                } else {
                                    pointer[parts[i]] = pointer[parts[i]] || {};
                                }
                                pointer = pointer[parts[i]];
                            }
                        }
                    }
                    if (langData) {
                        customTerminologyCache[params.groupId].push({
                            i18n: params.langType,
                            lang: langData
                        });
                    }
                },
                replaceTerms = function (params) {
                    var langTemp = params.langSet,
                        replaced = false;
                    obk = Object.keys(lang.Definitions);
                    for (ob = obk.length - 1; ob > -1; ob -= 1) {
                        key = obk[ob];
                        parts = key.split('-');
                        // Remove mobile client strings to reduce memory usage and data transmission to web
                        if (parts[0] !== 'mcli') {
                            pointer = langTemp[parts[0]];
                            for (i = 1, len = parts.length - 1; i < len; i += 1) {
                                if (pointer) {
                                    pointer = pointer[parts[i]];
                                }
                            }
                            if (pointer && pointer[parts[len]]) {
                                pointer[parts[len]] = lang.Definitions[key];
                                replaced = true;
                            }
                        }
                    }
                    if (replaced || customTerminologyCache[params.groupId].length) {
                        customTerminologyCache[params.groupId].push({
                            i18n: params.langType,
                            lang: langTemp
                        });
                    }
                };
            if (err) {
                HgLog.error(err);
            } else {
                if (terminology && terminology.length) {
                    for (k = terminology.length - 1; k > -1; k -= 1) {
                        t = terminology[k];
                        if (!customTerminologyCache[t.GroupId] || params.query.GroupId) {
                            customTerminologyCache[t.GroupId] = [];
                        }
                        if (t.Languages && t.Languages.length) {
                            for (x = t.Languages.length - 1; x > -1; x -= 1) {
                                lang = t.Languages[x];
                                if (lang.Definitions) {
                                    replaceTerms({
                                        langSet: JSON.parse(JSON.stringify(getDefaultLanguageFile(lang.i18n))),
                                        langType: lang.i18n,
                                        groupId: t.GroupId
                                    });
                                    replaceTerms({
                                        langSet: JSON.parse(JSON.stringify(getDefaultLanguageFile('email/' + lang.i18n))),
                                        langType: 'email/' + lang.i18n,
                                        groupId: t.GroupId
                                    });
                                    generateMobileTerms({
                                        langType: 'mobile/' + lang.i18n,
                                        groupId: t.GroupId
                                    });
                                }
                            }
                        }
                    }
                }
            }
        });
    }
}

function getEnglishFile() {
    return languageCache.en;
}

function getMobileLanguageFile(params, callback) {
    var lang,
        tokenHelper = require('./tokenHelper.js'),
        userToken = tokenHelper.GetMobileToken(params.req, 'UserToken');

    if (!userToken || !params.EntityCache) {
        return callback();
    }

    if (params.req.params && params.req.params.langFile) {
        lang = params.req.params.langFile.split('.');
    } else {
        lang = ['en'];
    }

    if (!lang.length) {
        return callback();
    }

    lang = "mobile/" + lang[0].toLowerCase();
    params.EntityCache.UserInfoWithToken.findOne({
        UserToken: userToken
    }, {
        _id: 0,
        "UserContext.CurrentGroupId": 1
    }, function (err, userInfo) {
        if (err) {
            return callback(err);
        }
        if (!userInfo ||
                !userInfo.UserContext ||
                !userInfo.UserContext.CurrentGroupId ||
                !customTerminologyCache[userInfo.UserContext.CurrentGroupId]) {
            return callback();
        }
        lang = customTerminologyCache[userInfo.UserContext.CurrentGroupId].filter(function (f) {
            return f.i18n === lang;
        });
        callback(null, (lang.length) ? lang[0].lang : null);
    });
}

function getLanguageFile(params, callback) {
    var lang,
        tokenHelper = require('./tokenHelper.js'),
        userToken = 'UserToken',
        actAsUserToken = 'ActAsUserToken',
        groupTerm = null,
        query = {},
        origLang,
        ct;
    if (params.req && params.req.params && params.req.params.langFile) {
        lang = params.req.params.langFile.split('.');
    } else {
        lang = ['en'];
    }
    if (lang.length && params.EntityCache) {
        lang = lang[0].toLowerCase();
        origLang = lang;
        ct = lang.split('=');
        if (ct.length > 1 && ct[0] === 'ct') {
            origLang = getLanguageIndex(detectLang(params));
            ct = ct[1];
            lang = origLang;
        } else {
            ct = null;
        }
        if (params.req) {
            actAsUserToken = tokenHelper.GetToken(params.req, actAsUserToken);
            if (actAsUserToken) {
                query.ActAsUserToken = actAsUserToken;
            } else {
                query.UserToken = tokenHelper.GetToken(params.req, userToken);
            }
            params.EntityCache.UserInfoWithToken.findOne(query, {
                _id: 0,
                "UserContext.CurrentGroupId": 1
            }, function (err, userInfo) {
                if (err) {
                    return callback(err);
                }
                if (userInfo && userInfo.UserContext && userInfo.UserContext.CurrentGroupId) {
                    groupTerm = userInfo.UserContext.CurrentGroupId;
                } else if (ct) {
                    groupTerm = ct;
                }
                if (groupTerm && customTerminologyCache[groupTerm]) {
                    lang = customTerminologyCache[groupTerm].filter(function (f) {
                        return f.i18n === lang;
                    });
                    if (lang.length) {
                        lang = lang[0].lang;
                    } else {
                        if (languageCache[origLang]) {
                            lang = languageCache[origLang];
                        } else {
                            lang = languageCache.en;
                        }
                    }
                    callback(null, lang);
                } else if (languageCache[lang]) {
                    callback(null, languageCache[lang]);
                } else {
                    callback(null, languageCache.en);
                }
            });
        } else if (languageCache[lang]) {
            callback(null, languageCache[lang]);
        } else {
            callback(null, languageCache.en);
        }
    } else {
        callback(null, languageCache.en);
    }
}

function getRequestLanguageIndex(params) {
    return getLanguageIndex(detectLang(params));
}

module.exports = {
    getLanguageIndex: getLanguageIndex,
    englishSpeaking: englishSpeaking,
    translate: translate,
    serverTranslate: serverTranslate,
    detectLang: detectLang,
    convertTextToAscii: convertTextToAscii,
    getLanguageFile: getLanguageFile,
    getMobileLanguageFile: getMobileLanguageFile,
    getEnglishFile: getEnglishFile,
    getRequestLanguageIndex: getRequestLanguageIndex,
    supportedLanguages: supportedLanguages,
    setAllCustomTerminologyFiles: setAllCustomTerminologyFiles,
    removeCustomTerminology: removeCustomTerminology,
    getLanguageAbbr: getLanguageAbbr,
    getLanguageName: getLanguageName
};
