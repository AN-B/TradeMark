'use strict';
var reportQueries = [{
        Name : "LaunchStatsReport",
        DisplayName : 'Launch Stats',
        Queries : [
            { Entity : 'UserInfo', Sort : {"Preference.DefaultGroupId" : 1}, Type : 'find', Title : 'UserInfoList', Filter: "UserInfoFilter",  Project : {"UserPersonal.FullName" : 1, "hgId" : 1, "Preference.DefaultGroupId" : 1, "UserPersonal.PrimaryEmail" : 1, 'CreatedDate' : 1, 'AvatarVersion' : 1, "LastLoginTime": 1}},
            { Entity : 'Member', Sort : {"hgId" : 1}, Type : 'find', Title : 'MembersList', Filter : "OffBoardedMemberFilter",  Project : { "hgId" : 1, "FullName" : 1,  "MembershipStatus" : 1,  "UserId" : 1, RolesInGroup : 1, MyManagers : 1, Location: 1}}
        ],
        ExcelTemplate : 'LaunchStats.xlsx',
        FilterDefinition : [{Name : "UserInfoFilter", Data : [{Name : 'Preference.DefaultGroupId', Type: 'string'}]},
                {Name : "OffBoardedMemberFilter", Data : [{Name : 'GroupId', Type: 'string'}]}]
    }, {
        Name : "TrackActivityReport",
        DisplayName : 'Track Activity',
        Queries : [
            { Entity : 'Group', Limit : 0, Sort : {}, Type : 'find', Title : 'Group-Info', Filter: "DefaultFilter", Project : { "hgId" : 1, "GroupName" : 1}},
            { Entity : 'UserInfo', Limit : 0, Sort : {}, Type : 'find', Title : 'Group-UserInfo', Filter: "GroupFilter", Project : { "hgId" : 1, "UserPersonal.PrimaryEmail" : 1}},
            { Entity : 'Member', Limit : 0, Sort : {}, Type : 'find', Title : 'Member-Info', Filter: "MemberFilter", Project : { "hgId" : 1, "UserId" : 1}},
            { Entity : 'CareerTrack', Limit : 0, Sort : {CreatedDate : -1}, Type : 'find', Title : 'Group-Track', Filter: "TrackFilter",
                Project : { "CareerTrackTemplate.Goal.ClosedDate" : 1, "CareerTrackTemplate.Goal.TargetDate" : 1,
                    "CareerTrackTemplate.Title" : 1, "Status" : 1, "AssignedMember.RolesInGroup" : 1, "AssignedMember.MyManagers" : 1,
                    "AssignedMember.FullName" : 1, "AssignedMember.GroupDepartmentName" : 1, "ModifiedDate" : 1, "CreatedDate" : 1,
                    'CareerTrackTemplate.MileStones.RecognitionTemplate.Title' : 1, "PercentAchieved" : 1, "NotificationFrequency" : 1,
                    "CreatorMember.FullName" : 1, "CareerTrackTemplate.ObjectiveWeight" : 1}}
        ],
        ExcelTemplate : 'Track.Activity.xlsx',
        FilterDefinition : [{Name : "DefaultFilter", Data : [{Name : 'hgId', Type : 'string'}]},
                            {Name : "MemberFilter", Data : [{Name : 'GroupId', Type : 'string'}]},
                            {Name : "GroupFilter", Data : [{Name : 'Preference.DefaultGroupId', Type : 'string'}]},
                            {Name : "TrackFilter", Data : [{Name : 'CareerTrackTemplate.GroupId', Type : 'string'}, {Name : 'CreatedDate', Type : 'date', IncludeStart : true, IncludeEnd : true}]}]
    }, {
        Name : "DashboardReport",
        DisplayName : 'Dashboard Queries',
        Queries : [
            { Entity : 'UserActivityAudit', Sort : {}, Type : 'aggregate', Title : 'User-Activity', Filter: "DefaultFilter", Project : {"Date" : 1, "MemberId" : 1}, Group : { _id : { MemberId : "$MemberId", Date : "$Date"}}},
            { Entity : 'Member', Sort : {}, Type : 'aggregate', Title : 'Member-Info', Filter: "MemberDepartmentFilter", Project : {"hgId" : 1, "GroupDepartmentName" : 1}, Group : { _id : { hgId : "$hgId", GroupDepartmentName : "$GroupDepartmentName"}}},
            { Entity : 'GroupUserSystemActivityReport', Sort : {}, Type : 'aggregate', Title : 'Unique Daily User Activity', Filter: "GroupUserSystemActivityFilter",  Group : { _id : {Type: "$Type", Date: "$Date"}, Total : {$sum : "$NumberofUsers"}}},
            { Entity : 'GroupRecognitionActivityReport', Sort : {}, Type : 'aggregate', Title : 'Recognition-Activity', Filter: "DefaultFilter",  Group : { _id : { Date : "$Date", GroupId : "$GroupId"}, Total : {$sum : "$Count"}}},
            { Entity : 'CommentActivityReport', Sort : {}, Type : 'aggregate', Title : 'Comment-Activity', Filter: "DefaultFilter",  Group : { _id : { Date : "$Date", GroupId : "$GroupId"}, Total : {$sum : "$Count"}}},
            { Entity : 'CongratActivityReport', Sort : {}, Type : 'aggregate', Title : 'Congrats-Activity', Filter: "DefaultFilter",  Group : { _id : { Date : "$Date", GroupId : "$GroupId"}, Total : {$sum : "$Count"}}},
            { Entity : 'GroupRecognitionActivityReport', Sort : {}, Type : 'aggregate', Title : 'RecognitionCategory', Filter: "RecognitionCategoryFilter",  Group : { _id : { Category : "$RecognitionCategory" }, Total : {$sum : "$Count"}}},
            { Entity : 'GroupRecognitionActivityReport', Sort : {}, Type : 'aggregate', Title : 'DailyRecognitionCategory', Filter: "GroupRecognitionActivityFilter",  Group : { _id : {Category : "$RecognitionCategory", Date : "$Date"}, Total : {$sum : "$Count"}}}
        ],
        ExcelTemplate : '',
        FilterDefinition : [{Name : "DefaultFilter", Data : [{Name : 'GroupId', Type : 'string'}, {Name : 'Date', Type : 'date', IncludeStart : true, IncludeEnd : true}]},
                            {Name : "RecognitionCategoryFilter", Data : [{Name : 'RecognitionStatus', Type : 'Static', Value : 'Active'}, {Name : 'GroupId', Type : 'string'}, {Name : 'Date', Type : 'date', IncludeStart : true, IncludeEnd : true}]},
                            {Name : "GroupUserSystemActivityFilter", Data : [{Name : 'GroupId', Type : 'string'}, {Name : 'Date', Type : 'date', IncludeStart : true, IncludeEnd : true}, {Name : 'Type', Type : 'Static', Value : 'Daily'}]},
                            {Name : "GroupRecognitionActivityFilter", Data : [{Name : 'GroupId', Type : 'string'}, {Name : 'Date', Type : 'date', IncludeStart : true, IncludeEnd : true}, {Name : 'RecognitionStatus', Type : 'Static', Value : 'Active'}]},
                            {Name : "MemberDepartmentFilter", Data : [{Name : 'GroupId', Type : 'string'}, {Name : 'MembershipStatus', Type : 'Static', Value : 'Active'}]}]
    }];

module.exports = {
    queryLibrary : reportQueries
};