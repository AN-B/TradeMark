/*jslint node:true es5:true nomen:true stupid: true*/
"use strict";
var pFilter = require('../util/WordFilter.js'),
    ProfanityEnums = require('../enums/ProfanityEnums.js'),
    EntityEnums = require('../enums/EntityEnums.js'),
    ClusterCache = require('../framework/ClusterCache.js'),
    i18nHelper = require('../helpers/i18nHelper.js'),
    isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
    HgLog = require('../framework/HgLog.js');

function contains(params) {
    params.Lang = params.Lang || 'en';
    if (!params.Entity || Object.keys(ProfanityEnums.EntityTypes).indexOf(params.Entity) === -1) {
        return false;
    }
    var langIndex = params.Lang.split('/'),
        entityToValidate = ProfanityEnums.EntityTypes[params.Entity],
        fieldsIndex = (function () {
            var rt = {};
            entityToValidate.Fields.forEach(function (item) {
                rt[item] = true;
            });
            return rt;
        }()),
        isNotValid = false,
        wordList = pFilter.WordList, //set default
        cc = ClusterCache.get(),
        groupClusterCache;
    if (params.Data.GroupId && cc) {
        groupClusterCache = cc[params.Data.GroupId];
    }
    if (langIndex.length > 1) {
        params.Lang = langIndex[langIndex.length - 1];
        if (i18nHelper.englishSpeaking.indexOf(params.Lang) > -1) {
            params.Lang = 'en';
        }
    }
    if (!isLocal && (!groupClusterCache || !groupClusterCache.ProfanityFilter)) {
        return false;
    }
    if (groupClusterCache && groupClusterCache.WordList && groupClusterCache.WordList[params.Lang]) {
        wordList = groupClusterCache.WordList[params.Lang];
    }
    function coreCheck(cparams) {
        if (typeof cparams.Data.toObject === 'function') {
            cparams.Data = cparams.Data.toObject();
        }
        var i,
            len,
            key,
            pData,
            translatedContent,
            data = cparams.Data,
            keys = cparams.Keys,
            getTranslatedContent = function (tdata) {
                return tdata.filter(function (item) {
                    return item.lang === params.Lang;
                })[0];
            };
        if (isNotValid) {
            return true;
        }
        for (i = 0, len = keys.length; i < len; i += 1) {
            key = keys[i];
            if (key === 'TranslatedValues') {
                translatedContent = getTranslatedContent(data[key]);
                if (translatedContent && translatedContent.values) {
                    coreCheck({
                        Data: translatedContent.values,
                        Keys: Object.keys(translatedContent.values),
                        FieldsIndex: cparams.FieldsIndex
                    });
                }
            } else if (typeof data[key] === 'object') {
                pData = data[key];
                pData = pData && pData._doc ? pData._doc : pData || {};
                coreCheck({
                    Data: pData,
                    Keys: Object.keys(pData),
                    FieldsIndex: cparams.FieldsIndex
                });
            } else if (data[key] && cparams.FieldsIndex[key] &&
                    pFilter.ContainsProfanity(data[key], wordList)) {
                isNotValid = true;
                HgLog.warn({
                    Type: EntityEnums.LogglyFilterType.ProfanityBannedWords,
                    EntityType: params.Entity,
                    Field: key,
                    Word: data[key],
                    GroupId: params.Data.GroupId,
                    UserId: params.Data.UserId || '',
                    MemberId: params.Data.MemberId || ''
                });
                break;
            }
        }
    }
    coreCheck({
        Data: params.Data,
        Keys: Object.keys(params.Data),
        FieldsIndex: fieldsIndex
    });
    return isNotValid;
}

module.exports = {
    contains: contains,
    ErrorMessage: 'server.common.lwn'
};