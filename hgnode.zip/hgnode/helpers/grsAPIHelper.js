/*jslint node:true es5:true*/
'use strict';

var GRSAPIHelper = function () {
    var HgLog = require('../framework/HgLog.js'),
        config = require('../configurations/config.js'),
        keystore = require('../configurations/keystore.js'),
        superagent = require('superagent'),
        GRSMethodEnums = require('../enums/GRSMethodEnums.js'),
        baseUrl = 'https://' + config.GRS.storefront.host + '/client/json.php/';

    function getAuth(id) {
        return id + ':' + new Buffer(JSON.stringify({
            id: id,
            token: keystore.GRS.storefront.token
        })).toString('base64');
    }

    this.CreateSubordinateAccount = function (params, callback) {
        superagent.post(baseUrl + GRSMethodEnums.createSubordinateAccount)
            .auth(getAuth(keystore.GRS.storefront.adminUser))
            .type('form')
            .send({account: JSON.stringify({
                employeeId: params.EmployeeId,
                firstName: params.FirstName,
                lastName: params.LastName,
                email: params.Email,
                postalCode: params.PostalCode,
                provinceState: params.State,
                country: params.Country,
                language: params.Language,
                accessGroups: ['DefaultStorefrontExternalMember'],
                hierarchyNodeCode: 'ROOT',
                sendWelcomeLetter: false,
                metadata: [{
                    id: 'hgCompany',
                    name: 'hgCompany',
                    data: params.GroupName
                }]
            })})
            .end(function (err, res) {
                if (err) {
                    HgLog.error('Error creating subordinate account: ' + err.status);
                    if (res) {
                        HgLog.error("Error body: " + res.body);
                    }
                    return callback('Error creating GRS account');
                }

                if (res.type === 'text/html') {
                    try {
                        var response = JSON.parse(res.text);
                        if (response.error && response.error.errorMessage) {
                            HgLog.error('GRS createSubordinateAccount error', response.error.errorMessage);
                        }
                    } catch (e) {
                        HgLog.error('Error parsing GRS text response', e);
                    }
                }

                if (res.body.error && res.body.error.errorMessage) {
                    HgLog.error('GRS createSubordinateAccount error', res.body.error.errorMessage);
                }

                if (!res.body.id) {
                    HgLog.error('No GRSMemberId!');
                    return callback('No GRSMemberId!');
                }

                callback(null, res.body.id);
            });
    };

    this.GetSSOSession = function (params, callback) {
        superagent.get(baseUrl + GRSMethodEnums.getSsoSession)
            .auth(getAuth(params.GRSMemberId))
            .end(function (err, res) {
                if (err) {
                    HgLog.error('Error getting SSO session', err);
                    return callback('Error getting SSO session');
                }

                if (!res.body.url) {
                    return callback('Error getting SSO URL');
                }

                callback(null, res.body.url);
            });
    };
};

module.exports = new GRSAPIHelper();