/*jslint node:true es5:true todo: true */
'use strict';
var FileHelper = require('../util/FileHelper.js'),
    HgLog = require('../framework/HgLog'),
    Async = require('async');

function processValueSetting(request, callback) {
    FileHelper.CopyBadgeImage({
        BadgeId: request.BadgeId,
        FriendlyGroupId: request.FriendlyGroupId,
        TemplateId: request.TemplateId,
        Callback: callback
    });
}

//TODO this needs to be placed on the ESB and when it is complete then we need to send an email to the user
//TODO specifying the images have been copied.
function createImagesForValueLevels(params, badgeInternalService) {
    Async.each(params.requests, function (request, cb) {
        if (!request.Group.ValueLevelSetting.Levels || !request.Group.ValueLevelSetting.Levels.length) {
            return cb('Group is not present.');
        }

        badgeInternalService.GetBadgeById(request, function (err, badge) {
            var iconFilename,
                borderFilename,
                compositeFilename;
            if (err || !badge) {
                cb(['No badge available with Id: ', request.BadgeId]);
            }
            iconFilename = badge.Filename;
            request.Group.ValueLevelSetting.Levels.forEach(function (level) {
                var compositeParams;
                borderFilename = level.ImageId + '.svg';
                compositeFilename = request.ImageId + '_' + level.Name + '.svg';
                compositeParams = {
                    FirstImageFilename: borderFilename,
                    SecondImageFilename: iconFilename,
                    CompositeFilename: compositeFilename,
                    FriendlyGroupId: request.Group.FriendlyGroupId,
                    ForegroundFillColor: request.IconPickerColor,
                    BackgroundFillColor: request.BkgdPickerColor
                };
                FileHelper.CompositeImages(compositeParams);
            });
        });
    }, function (error) {
        if (error) {
            HgLog.debug(error);
        }
    });
}

module.exports = {
    processValueSetting: processValueSetting,
    createImagesForValueLevels: createImagesForValueLevels
};