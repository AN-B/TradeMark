/*jslint node:true es5:true nomen:true*/
'use strict';
var fs = require('fs'),
    uuid = require('node-uuid'),
    imageProcessor = require('./imageProcessor'),
    fileUpload = require('./fileUpload'),
    s3Util = require('./s3Util'),
    path = __dirname.replace('/hgnode/helpers', ''),
    fsUtil = require('./fileSystemUtil.js'),
    hgLog = require('../framework/HgLog.js'),
    isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1,
    tmpImgDir = '/static/img/tmp/';

function sanitizeFileName(file) {
    return file.replace(/[&%#\^]/g, '').replace(/-/g, '');
}

function readImageFromXHR(req, callback) {
    var fname = sanitizeFileName(req.header('x-file-name')),
        tempfile = '/tmp/' + uuid.v1(),
        ws = fs.createWriteStream(tempfile);

    ws.on('error', function (err) {
        callback(err);
    });

    ws.on('close', function (err) {
        if (err) {
            callback(err);
        }
        fsUtil.createDirPath(path + tmpImgDir, function (err) {
            if (err) {
                hgLog.error(err);
                callback(err);
            }
            fileUpload.moveFile(tempfile, path + tmpImgDir + fname, function () {
                if (err) {
                    callback(err);
                }
                if (isLocal) {
                    callback(null, {success: true, filename: fname});
                } else {
                    s3Util.uploadS3Jpeg(path + tmpImgDir + fname, fname, 'tmp', function (err) {
                        if (err) {
                            callback(err);
                        } else {
                            callback(null, {success: true, filename: fname});
                        }
                    });
                }
            });
        });
    });

    req.on('data', function (data) {
        ws.write(data);
    });

    req.on('end', function () {
        ws.end();
    });
}

function readImageFromQQfile(req, callback) {
    var fname = sanitizeFileName(req.files.qqfile.name);

    // the file-uploader does not report the size on IE8, so we have to use the content-length header
    if (req.files.qqfile.size / 1024 > 3072 || req.headers['content-length'] / 1024 > 3072) {
        callback(null, {
            success: false,
            error: "Uploaded file exceeds 3 MB."
        });
    } else {
        fsUtil.createDirPath(path + tmpImgDir, function (err) {
            if (err) {
                callback(err);
            } else {
                fs.rename(req.files.qqfile.path, path + tmpImgDir + fname, function (err) {
                    if (err) {
                        callback(err);
                    } else {
                        if (isLocal) {
                            callback(null, {success: true, filename: fname});
                        } else {
                            s3Util.uploadS3Jpeg(path + tmpImgDir + fname, fname, 'tmp', function (err) {
                                if (err) {
                                    callback(err);
                                } else {
                                    callback(null, {success: true, filename: fname});
                                }
                            });
                        }
                    }
                });
            }
        });
    }
}

function uploadTempImage(req, callback) {
    if (req.xhr) {
        readImageFromXHR(req, callback);
    } else if (req.files.qqfile) {
        readImageFromQQfile(req, callback);
    } else {
        callback(null, {
            success: false,
            error: "Couldn't read image!"
        });
    }
}

function processAndCropImage(req, targetdir, callback) {
    if (!isLocal) {
        s3Util.getS3File('tmp/' + req.originalName, targetdir + tmpImgDir + req.originalName, function (err) {
            if (err) {
                callback(err);
            } else {
                imageProcessor.cropAndResizeImage(req, targetdir, function (err, data) {
                    if (err) {
                        callback(err);
                    } else {
                        s3Util.uploadS3Jpeg(data.filename, data.dest, req.imgDirectory, function (err, json) {
                            if (err || !json) {
                                callback(err);
                            } else {
                                callback(null, {filename: json.name});
                            }
                        });
                    }
                });
            }
        });
    } else {
        imageProcessor.cropAndResizeImage(req, targetdir, function (err, data) {
            if (err) {
                callback(err);
            } else {
                callback(null, {filename: data.dest});
            }
        });
    }
}

exports.uploadTempImage = uploadTempImage;
exports.processAndCropImage = processAndCropImage;