/*jslint node:true es5:true nomen:true stupid: true*/
"use strict";
var environment = process.env.BUILD_ENV || 'local';

function getMobileToken(req, type) {
    return (req.header) ? req.header(type) : '';
}
function getToken(req, type) {
    var value = '';
    if (req.cookies) {
        value = (environment !== 'test' && environment !== 'local') ? req.cookies[environment + '.' +  type] : req.cookies[type];
    }
    return value;
}

module.exports = {
    GetMobileToken: getMobileToken,
    GetToken: getToken
};