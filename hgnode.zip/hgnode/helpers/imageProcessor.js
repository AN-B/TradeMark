/*jslint node:true es5:true*/
"use strict";
var easyimg = require('easyimage'),
    config = require('../configurations/config.js'),
    fsUtil = require('./fileSystemUtil.js'),
    fs = require('fs'),
    gm = require('gm'),
    uuid = require('node-uuid'),
    HgLog = require('../framework/HgLog'),
    imageMagick = gm.subClass({imageMagick: true});

function resize(image, width, height, callback) {
    var params = {
        src: image,
        dst: image,
        width: width || 200,
        height: height || 200
    };
    easyimg.resize(params, function (err) {
        if (err) {
            callback(err, null);
        } else {
            callback(null, {success: true});
        }
    });
}

function processUpload(file, width, height, callback) {
    var fName = '',
        path;
    easyimg.info(file, function (err, features) {
        if (err) {
            callback(err, null);
        } else {
            fName = features.name.split('.')[0] + '.jpg';
            path = file.split('/');
            path[path.length - 1] = fName;
            easyimg.convert({src: file, dst: path.join('/'), quality: 80}, function (err) {
                if (err) {
                    callback(err, null);
                } else {
                    resize(path.join('/'), width, height, function (err) {
                        if (err) {
                            callback(err, null);
                        } else {
                            callback(null, {success: true, filename: fName});
                        }
                    });
                }
            });
        }
    });
}

function process(req, targetdir, callback) {
    var imgDirectory = req.imgDirectory || "user",
        imgFile = req.userGuid || req.defaultFileName || uuid.v1(),
        destinationFilename = targetdir + '/static/img/' + imgDirectory + '/' + imgFile + '.jpg',
        cropParams = {
            src: targetdir + '/static/img/tmp/' + req.originalName,
            dst: destinationFilename,       //fun fact, after easyimage.crop(), this property will have " around it as part of the string
            cropwidth: parseInt(req.width, 10),
            cropheight: parseInt(req.height, 10),
            gravity: 'NorthWest',
            x: parseInt(req.x1, 10),
            y: parseInt(req.y1, 10)
        };

    fsUtil.createDirPath(targetdir + '/static/img/' + imgDirectory, function (err) {
        if (err) {
            return callback(err);
        }

        if (req.cropToSquare) {
            if (Math.abs(cropParams.cropwidth - cropParams.cropheight) >= 1) {
                HgLog.debug('cropwidth !== cropheight with >= 1 pixel of tolerance', {
                    cropwidth: cropParams.cropwidth,
                    cropheight: cropParams.cropheight,
                    result: cropParams.cropwidth - cropParams.cropheight
                });
                cropParams.cropwidth = Math.min(cropParams.cropwidth, cropParams.cropheight);
                cropParams.cropheight = Math.min(cropParams.cropwidth, cropParams.cropheight);
            }

            if (req.height - req.width >= 1) {
                HgLog.debug('height > width with >= 1 pixel of tolerance', {
                    height: req.height,
                    width: req.width,
                    result: req.height - req.width
                });
                cropParams.y = (req.height - cropParams.cropheight) / 2;
            }

            if (req.width - req.height >= 1) {
                HgLog.debug('width > height with >= 1 pixel of tolerance', {
                    height: req.height,
                    width: req.width,
                    result: req.width - req.height
                });
                cropParams.x = (req.width - cropParams.cropwidth) / 2;
            }
        }

        easyimg.crop(cropParams, function (err) {
            if (err) {
                return callback(err);
            }
            resize(destinationFilename, req.finalWidth, req.finalHeight, function (err) {
                if (err) {
                    return callback(err);
                }
                callback(null, {
                    success: true,
                    fileDir: imgDirectory,
                    filename: destinationFilename,
                    dest: imgFile + '.jpg'
                });
            });
        });
    });
}

function convert(file, ie9, width, height, callback) {
    var fName = '',
        path,
        temp;
    path = file.split('/');
    fName = path[path.length - 1];
    path[path.length - 1] = fName.split('.')[0] + '.jpg';
    temp = fName.split('.');
    if (ie9 && (temp[temp.length - 1].toLowerCase() === "png" || temp[temp.length - 1].toLowerCase() === "bmp")) {
        imageMagick(file)
            .quality(80)
            .transparent('white')
            .resize(200, 200)
            .write(path.join('/'), function (err) {
                if (err) {
                    HgLog.error(err);
                } else {
                    callback(null, {success: true, filename: fName});
                }
            });
    } else {
        processUpload(file, width, height, function (err, data) {
            callback(err, data);
        });
    }
}

function cropAndResizeImage(req, targetdir, callback) {
    var imgDirectory = req.imgDirectory || "user";
    fsUtil.createDirPath(targetdir + '/static/img/' + imgDirectory, function (err) {
        if (err) {
            callback(err);
        } else {
            process(req, targetdir, callback);
        }
    });
}

function crop(image, callback) {
    easyimg.crop({
        src: image,
        dst: image,
        cropwidth: 200,
        cropheight: 200,
        quality: 85
    }, function (err) {
        if (err) {
            callback(err, null);
        } else {
            callback(null, {success: true});
        }
    });
}

module.exports = {
    cropAndResizeImage: cropAndResizeImage,
    convert: convert,
    crop: crop
};