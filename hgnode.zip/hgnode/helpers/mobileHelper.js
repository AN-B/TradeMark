/*jslint node:true es5:true nomen:true stupid: true*/
"use strict";

function getMobileAppVersion(req) {
    return (req.header) ? req.header('AppVersion') : -1;
}

module.exports = {
    getMobileAppVersion: getMobileAppVersion
};