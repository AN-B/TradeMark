/*jslint node:true es5:true nomen:true stupid: true*/
"use strict";
var crypto = require('crypto'),
    algorithm = 'aes-256-ctr',
    keystore = require('../configurations/keystore'),
    HgLog = require('../framework/HgLog'),
    password = keystore.CryptoPassword;

function decrypt(buffer) {
    var decipher = crypto.createDecipher(algorithm, password);
    return Buffer.concat([decipher.update(buffer), decipher.final()]);
}

function encrypt(buffer) {
    var cipher = crypto.createCipher(algorithm, password);
    return Buffer.concat([cipher.update(buffer), cipher.final()]);
}
function createCipher() {
    return crypto.createCipher(algorithm, password);
}

function createDecipher() {
    return crypto.createDecipher(algorithm, password);
}

function encryptHgId(hgId) {
    var hgIdBuffer = new Buffer(hgId);
    return encrypt(hgIdBuffer).toString('hex');
}

function decryptHgId(string) {
    var encryptedBuffer = new Buffer(string, 'hex');
    return decrypt(encryptedBuffer).toString();
}

function md5(data) {
    return crypto.createHash('md5').update(data).digest('hex');
}

function generatePasswordHash(params, callback) {
    var iterations = params.iterations || 15000,
        keyLen = 512,
        pepper = process.env.PEPPER || 'pepper',
        secret;

    if (!params.salt) {
        try {
            params.salt = crypto.randomBytes(16).toString('hex');    // 16 bytes = 128 bits
        } catch (err) {
            HgLog.error('Error generating random bytes for salt', err);
            return callback('Could not generate salt. Please try again.'); //better error message here
        }
    }

    secret = params.password + params.salt;

    crypto.pbkdf2(secret, pepper, iterations, keyLen, function (err, key) {
        if (err) {
            HgLog.error(err);
            return callback(err);
        }

        callback(null, {
            passwordHash: key.toString('hex'),
            salt: params.salt,
            iterations: iterations
        });
    });
}

module.exports = {
    decrypt: decrypt,
    encrypt: encrypt,
    createCipher: createCipher,
    createDecipher: createDecipher,
    encryptHgId: encryptHgId,
    decryptHgId: decryptHgId,
    md5: md5,
    generatePasswordHash: generatePasswordHash
};