"use strict";
var SSHHelper = function () {
    var SSH2 = require('ssh2'),
        fs = require('fs'),
        cfg = require('../configurations/config'),
        keystore = require('../configurations/keystore'),
        HgLog = require('../framework/HgLog'),
        s3Util = require('./s3Util'),
        isLocal = ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1 || !process.env.BUILD_ENV,
        SHelper = function init() {
            HgLog.debug('creating SSH object');
            this.connection = new SSH2();
            this.connected = false;
        };
    SHelper.prototype.connect = function (callback) {
        HgLog.debug('connecting to SSH');
        this.connection.on('error', callback);
        this.connection.on('ready', function () {
            this.connected = true;
            callback();
        }.bind(this));
        this.connection.connect({
            host: cfg.hg_sftp.host,
            port: cfg.hg_sftp.port,
            username: keystore.hg_sftp.username,
            password: keystore.hg_sftp.password
        });
    };
    SHelper.prototype.connected = this.connected;
    SHelper.prototype.disconnect = function () {
        if (this.connected) {
            HgLog.debug('disconnecting from SSH');
            this.connection.end();
            this.connected = false;
        }
    };
    SHelper.prototype.transferRemoteFileToLocal = function (params, callback) {
        this.connection.sftp(function (error, sftp) {
            if (error) {
                return callback(error);
            }
            var r = sftp.createReadStream(params.RemoteFile).pipe(fs.createWriteStream(params.LocalFile));
            r.on('error', callback);
            r.on('close', callback);
        });
    };
    SHelper.prototype.transferRemoteFileToS3 = function (params, callback) {
        var pushFileToS3 = function (error) {
            if (isLocal) {
                HgLog.error('Local Env do nothing');
                return callback();
            }
            if (error) {
                HgLog.error(error);
                return callback(error);
            }
            s3Util.pushS3File(params.LocalFile, "provision/" + params.FileName, function (error, message) {
                if (error) {
                    HgLog.error('Error Pushing File to S3', error);
                    return callback(error);
                }
                fs.unlink(params.LocalFile);
                callback(error, message);
            });
        };
        this.connection.sftp(function (error, sftp) {
            if (error) {
                return callback(error);
            }
            var r = sftp.createReadStream(params.RemoteFile).pipe(fs.createWriteStream(params.LocalFile));
            r.on('error', callback);
            r.on('close', pushFileToS3);
        });
    };
    return new SHelper();
};
module.exports = SSHHelper;