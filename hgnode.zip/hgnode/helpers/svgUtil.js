'use strict';
var im = require('imagemagick-safe'),
    fs = require('fs'),
    HgCache = require('../framework/RedisConnectionCache'),
    HgLog = require('../framework/HgLog'),
    https = require('https'),
    crytoHelper = require('./cryptoHelper.js'),
    isLocal = !process.env.BUILD_ENV || ['local', 'test'].indexOf(process.env.BUILD_ENV) > -1;

function convertSvg2Png(image, response, hash) {
    var conv = im.convert(['-background', 'none', 'svg:-', 'png:-']),
        img = [];
    conv.on('data', function (data) {
        img.push(data);
    });
    conv.on('end', function () {
        img = img.join('');
        response.writeHead(200, {'Content-Type': 'image/png'});
        response.end(img, 'binary');
        if (hash) {
            HgCache.GlobalSet(hash, (new Buffer(img)).toString('base64'), function (err) {
                if (err) {
                    HgLog.info('*** Unable to save image to Redis: ' + err.toString() + ' ***');
                }
            }, 2592000);
        }
    });
    conv.stdin.write(image);
    conv.stdin.end();
}
function getSvgFile(params) {
    var buffers = [];
    if (isLocal) {
        fs.readFile('./static' + params.url, 'utf8', function (error, svg) {
            if (error) {
                throw error;
            }
            params.res.writeHead(200, {'Content-Type': 'image/svg+xml'});
            params.res.end(svg, 'binary');
            params.res.end();
        });
    } else {
        https.get('https:' + params.url, function (res) {
            res.on('data', function (chunk) {
                buffers.push(chunk);
            });
            res.on('end', function () {
                params.res.writeHead(200, {'Content-Type': 'image/svg+xml'});
                params.res.end(Buffer.concat(buffers), 'binary');
                params.res.end();
            });
        });
    }
}
function processSVGBadge(params) {
    var buffers = [],
        hash = null;
    if (isLocal) {
        fs.readFile('./static' + params.url, 'utf8', function (error, svg) {
            if (error) {
                throw error;
            }
            convertSvg2Png(svg, params.response);
        });
    } else {
        hash = crytoHelper.md5(params.url);
        HgCache.GlobalGet(hash, function (cacheGetError, cacheResult) {
            if (cacheGetError || !cacheResult) {
                https.get('https:' + params.url, function (res) {
                    res.on('data', function (chunk) {
                        buffers.push(chunk);
                    });
                    res.on('end', function () {
                        convertSvg2Png(Buffer.concat(buffers), params.response, hash);
                    });
                });
            } else {
                params.response.writeHead(200, {'Content-Type': 'image/png'});
                params.response.end(new Buffer(cacheResult, 'base64').toString(), 'binary');
            }
        });
    }
}



module.exports = {
    processSVGBadge: processSVGBadge,
    getSvgFile: getSvgFile
};
