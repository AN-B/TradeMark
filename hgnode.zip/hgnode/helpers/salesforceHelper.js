/*jslint node:true es5:true*/
var SalesforceHelper = function () {
        'use strict';

        var Keystore = require('../configurations/keystore.js'),
            HgError = require('../common/HgError.js'),
            HgLog = require('../framework/HgLog.js'),
            ParamUtil = require('../util/params.js'),
            Crypto = require('crypto');

        this.VerifyRequestSignature = function (params, callback) {
            if (!ParamUtil.checkForRequiredParameters(['canvasRequest'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }

            var splitCanvasRequest = params.canvasRequest.split('.'),
                signature = splitCanvasRequest[0],
                request = splitCanvasRequest[1],
                hmac,
                digest;

            if (!signature && !request) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }

            hmac = Crypto.createHmac('SHA256', Keystore.canvas_api.key);
            hmac.update(request);
            digest = hmac.digest('base64').toString();

            if (digest !== signature) {
                HgLog.warn('Invalid signature in force.com canvas request. signature: ' + signature + ' !== computed digest: ' + digest);
                return callback('Invalid signature');
            }

            callback();
        };

        this.GetAuthenticationFromRequest = function (params, callback) {
            if (!ParamUtil.checkForRequiredParameters(['canvasRequest'], params)) {
                return callback(HgError.Enums.Generic.MissingParameters);
            }

            try {
                var b64jsonEnvelope = params.canvasRequest.split('.')[1],
                    jsonEnvelope = JSON.parse(new Buffer(b64jsonEnvelope, 'base64').toString()),
                    authEnvelope = {
                        userId: jsonEnvelope.context.user.userId,
                        userName: jsonEnvelope.context.user.userName,
                        email: jsonEnvelope.context.user.email,
                        profileId: jsonEnvelope.context.user.profileId
                    };
                callback(null, authEnvelope);
            } catch (ex) {
                HgLog.error("Error parsing Salesforce authentication", ex);
                callback("Error parsing Salesforce authentication");
            }
        };
    };

module.exports = new SalesforceHelper();