"use strict";
var config = require('../configurations/config.js'),
    keystore = require('../configurations/keystore.js'),
    fsUtil = require('./fileSystemUtil.js'),
    fs = require('fs'),
    AWS = require('aws-sdk'),
    HgLog = require('../framework/HgLog.js'),
    s3;

AWS.config.update({
    accessKeyId: keystore.amazon_aws.key,
    secretAccessKey: keystore.amazon_aws.secret
});

s3 = new AWS.S3();

function getS3FileBuffer(source, callback) {
    var data = new Buffer('');
    s3.getObject({
        Bucket: config.s3store.s3bucket,
        Key: source
    }).on('httpData', function (chunk) {
        data = Buffer.concat([data, chunk]);
    }).on('complete', function () {
        callback(null, { data: data});
    }).on('error', function (error) {
        callback(error);
    }).send();
}

function getS3File(source, dest, callback) {
    var fstream = fs.createWriteStream(dest, {
        flags: 'w',
        encoding: null
    });
    s3.getObject({
        Bucket: config.s3store.s3bucket,
        Key: source
    }).on('httpData', function (chunk) {
        fstream.write(chunk);
    }).on('complete', function () {
        fstream.end();
        callback(null, { message: 'successfully retrieved and saved file!'});
    }).on('error', function (err) {
        HgLog.error(err);
        callback(err);
    }).send();
}

function pushS3FileBuffer(dataBuffer, contentType, contentDisposition, destination, callback) {
    s3.putObject({
        Bucket: config.s3store.s3bucket,
        Key: destination,
        Body: dataBuffer,
        ACL: 'public-read',
        ContentType: contentType,
        ContentDisposition: contentDisposition
    }, function (error) {
        if (error) {
            return callback(error);
        }
        callback(null, {
            success: true,
            message: 'file successfully Pushed to S3.'
        });
    });
}

function pushS3File(sourceFilePath, destination, callback) {
    fs.exists(sourceFilePath, function (exists) {
        if (!exists) {
            return callback('File not found: ' + sourceFilePath);
        }
        fs.readFile(sourceFilePath, function (err, data) {
            s3.putObject({
                Bucket: config.s3store.s3bucket,
                Key: destination,
                Body: data,
                ACL: 'public-read',
                ContentType: fsUtil.getContentTypeByFile(sourceFilePath),
                ContentDisposition: fsUtil.getContentDispositionFile(sourceFilePath)
            }, function (error) {
                if (error) {
                    return callback(error);
                }
                callback(null, { success : true, message : sourceFilePath + 'file successfully Pushed to S3.'});
            });
        });
    });
}

function deleteS3File(source, callback) {
    s3.deleteObject({
        Bucket: config.s3store.s3bucket,
        Key: source
    }, function (error, data) {
        if (error) {
            return callback(error);
        }
        callback(null, data);
    });
}

function moveS3File(source, destination, contentType, contentDisposition, callback) {
    getS3FileBuffer(source, function (error, result) {
        if (error) {
            return callback(error);
        }
        pushS3FileBuffer(result.data, contentType, contentDisposition, destination, function (error) {
            if (error) {
                return callback(error);
            }
            deleteS3File(source, function (error, data) {
                if (error) {
                    return callback(error);
                }
                callback(null, data);
            });
        });
    });
}

function getS3FileContent(source, callback) {
    var data = new Buffer('');
    s3.getObject({
        Bucket: config.s3store.s3bucket,
        Key: source
    }).on('httpData', function (chunk) {
        data = Buffer.concat([data, chunk]);
    }).on('complete', function () {
        callback(null, data);
    }).on('error', function (error) {
        callback(error);
    }).send();
}

function uploadS3Jpeg(source, filename, s3Dir, callback) {
    var jpgFile = (filename.substring(filename.length - 4, filename.length).toLowerCase() === '.jpg'),
        s3object,
        s3keyDir = (s3Dir !== '' && s3Dir !== undefined && s3Dir !== null) ? s3Dir : /USER/.test(source.toUpperCase()) ? 'user' : 'team';
    fs.readFile(source, function (err, data) {
        if (err) {
            return callback(err);
        }
        s3object = {
            Bucket: config.s3store.s3bucket,
            Key: s3keyDir + '/' + filename,
            Body: data,
            ContentType: 'image/jpeg',
            ACL: 'public-read'
        };
        if (!jpgFile) {
            s3object.ContentDisposition = 'binary';
        }
        s3.putObject(s3object, function (err) {
            if (err) {
                HgLog.error(err);
                return callback(err);
            }
            fs.unlink(source, function (err) {
                if (err) {
                    HgLog.error(err);
                    return callback(err);
                }
                callback(null, {
                    statusCode: 200,
                    message: 'Successfully uploaded data',
                    name: filename,
                    fileDir: s3keyDir
                });
            });
        });
    });
}

function fileExist(source, callback) {
    s3.headObject({
        Bucket: config.s3store.s3bucket,
        Key: source
    }, function (error, result) {
        callback(error, !!result);
    });
}

module.exports = {
    getS3File: getS3File,
    deleteS3File: deleteS3File,
    getS3FileContent: getS3FileContent,
    uploadS3Jpeg: uploadS3Jpeg,
    pushS3File: pushS3File,
    pushS3FileBuffer: pushS3FileBuffer,
    getS3FileBuffer: getS3FileBuffer,
    moveS3File: moveS3File,
    fileExist: fileExist
};