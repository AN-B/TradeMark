var exec = require('child_process').exec,
    deployCount = 1,
    err;
setInterval(function() {
    console.log('Auto deploying to dev server...' + deployCount);
    exec('/bin/sh ~/projects/hgapp/deploy/hgndeploy.sh dev projects ccf=yes,srr=yes,rnm=no,rut=yes,bcc=no,uhc=no,uev=yes');
    console.log('Done.');
    deployCount += 1;
}, 120000);

