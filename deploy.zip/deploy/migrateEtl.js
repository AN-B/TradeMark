/*jslint node:true es5:true*/
'use strict';
var fs = require('fs'),
    argsv = require('minimist')(process.argv.slice(2)),
    availableEnv = [
        'borg',
        'cylon',
        'demo',
        'dev',
        'local',
        'poc',
        'prod',
        'qa',
        'st',
        'test',
        'tron',
        'uat',
        'ripley',
        'scully',
        'trinity',
        'avatar'
    ];

function checkArgs() {
    var result = true;
    if (!argsv.env) {
        console.log('Missing Required Env');
        result = false;
    }
    if (!argsv.f) {
        console.log('Missing Required ETL File');
        result = false;
    }
    if (argsv.env && availableEnv.indexOf(argsv.env) === -1) {
        console.log('Unknown Environment: ' + argsv.env);
        result = false;
    }
    if (argsv.f && !fs.existsSync([__dirname, '/', argsv.f].join(''))) {
        console.log('Data Migration Script Not found: ' + argsv.f);
        result = false;
    }
    return result;
}


function executeScript(fileName, callback) {
    var ConnectionCache = require('../hgnode/framework/ConnectionCache.js');
    ConnectionCache.init(function () {
        //load script
        var fileLoad = require([__dirname, '/', argsv.f].join(''));
        //Execute Script
        fileLoad.Run(callback);
    });
}

if (!checkArgs()) {
    return process.exit(1);
}
console.log('==================================');
console.log('| Running Data Migration Script! |');
console.log('==================================');

//Set ENV Variable
process.env.BUILD_ENV = argsv.env;

//Run Script
executeScript(argsv.f, function (error) {
    if (error) {
        console.log('==============================');
        console.log('| Houston we have a problem! |');
        console.log('==============================');
        console.log(error);
        process.exit(1);
    }
    console.log('============================');
    console.log('| Data Migration Complete! |');
    console.log('============================');
    process.exit(0);
});

