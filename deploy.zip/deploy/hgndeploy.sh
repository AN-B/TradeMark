#!/bin/bash

# to auto deploy without prompts
# . projects/hgapp/deploy/hgndeploy.sh dev projects ccf=yes,srr=yes,bcc=no,rds=no,usk=no,uev=no,rdm=no,srn=no
# ccf=copy changed files to s3  [yes]
# srr=skip refresh repos        [yes]
# bcc=bypass change check       [no]
# rds=remove deploy status      [no]
# usk=update slack              [yes]
# uev=update environments page  [yes]
# rdm=run database migration    [no]
# srn=send release notes        [no]

# set up environment variables
fullServerName=""
webServer="yes"
configEnv="local"
currentNode=""
envName=""
changedFiles="yes"
skipRefreshRepos="yes"
syncStage="no"
deleteBackup="yes"
bypassChangeCheck="no"
updateSlack="yes"
updateEnviornmentsWeb="yes"
rootPath="projects"
scriptRunPath=${PWD}
sendReleaseNotes="no"
removeDeployStatus="no"
branch="None"
rc=-1
autoDeploy=""
runDatabaseMigration="no"
statusioComponentId=""
preboot="no"
multiplex="no"
api="no"
copyJSlib="no"
workerProcess="no"
restoreFilePrefix=""
statusioAuth=""
refreshTime="30000"
angularDebug="enable"
# set the build version
buildVersion=`date +%s`

# function to set the passed in parameters during a headless auto-deploy
function setParameter() {
    echo $1"="$2
    case "$1" in
    "ccf")
        changedFiles=${2}
    ;;
    "srr")
        skipRefreshRepos=${2}
    ;;
    "bcc")
        bypassChangeCheck=${2}
    ;;
    "usk")
        updateSlack=${2}
    ;;
    "uev")
        updateEnviornmentsWeb=${2}
    ;;
    "rdm")
        runDatabaseMigration=${2}
    ;;
    "srn")
        sendReleaseNotes=${2}
    ;;
    "rds")
        removeDeployStatus=${2}
    ;;
    *)
        echo "Invalid parameter "$1
    ;;
    esac
}

# spinner function for long running tasks
spinner()
{
    local pid=$1
    local delay=0.25
    local spinstr='|/-\'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

# function to check if an error occurred during an operation and exit the deploy process
function errorCheck() {
    if [[ $rc = -1 ]] ; then
        rc=$?
    fi
    if [[ $rc != 0 ]] ; then
        echo "ERROR: "$rc" >> "${1}
        if [[ $autoDeploy = "" ]]; then
            if [[ $updateSlack = "yes" ]]; then
                BUILD_ENV=$configEnv node $rootPath/hgapp/deploy/notifySlackDeployment.js "error" `id -un`
            fi
        else
            BUILD_ENV=$configEnv node $rootPath/hgapp/deploy/emailDevelopers.js $rc $rootPath $envName $branch ${1}
            # set a tracking file to indicate an error
            badBuilds=1
            # increment the badBuilds count
            if [ -f $rootPath/heroku-$currentNode/errorHappened.txt ]; then
                badBuilds=`expr $badBuilds + $(cat $rootPath/heroku-$currentNode/errorHappened.txt)`
            fi
            echo $badBuilds > $rootPath/heroku-$currentNode/errorHappened.txt
        fi
        # always remove the tracking file on error
        rm -Rfd $rootPath/heroku-$currentNode/deployStatus.txt
        # remove the database directory
        if [[ ${2} = "db" ]]; then
            rm -Rfd $rootPath/heroku-$currentNode/database
        fi
        exit $rc
    fi
    rc=-1
    echo "Done."
}

# function to run the etl script against the target environment's database
function runDatabaseEtlScript() {
    cd ~
    cd $rootPath/hgapp
    echo "Building connection strings..."
    # get all the connection strings and replica
    hgcommon="MONGO_HGCOMMON='"$(heroku config:get MONGO_HGCOMMON --app $currentNode)"'"
    errorCheck
    if [[ $hgcommon = "" ]]; then
        echo "Error >> Blank hgcommon connection string!"
        exit 1
    fi
    hgfinance="MONGO_HGFINANCE='"$(heroku config:get MONGO_HGFINANCE --app $currentNode)"'"
    errorCheck
    if [[ $hgfinance = "" ]]; then
        echo "Error >> Blank hgfinance connection string!"
        exit 1
    fi
    hglog="MONGODB_HGLOG='"$(heroku config:get MONGODB_HGLOG --app $currentNode)"'"
    errorCheck
    if [[ $hglog = "" ]]; then
        echo "Error >> Blank hglog connection string!"
        exit 1
    fi
    hgperform="MONGO_HGPERFORM='"$(heroku config:get MONGO_HGPERFORM --app $currentNode)"'"
    errorCheck
    if [[ $hgperform = "" ]]; then
        echo "Error >> Blank hgperform connection string!"
        exit 1
    fi
    hgperka="MONGO_HGPERKA='"$(heroku config:get MONGO_HGPERKA --app $currentNode)"'"
    errorCheck
    if [[ $hgperka = "" ]]; then
        echo "Error >> Blank hgperka connection string!"
        exit 1
    fi
    hgreports="MONGO_HGREPORTS='"$(heroku config:get MONGO_HGREPORTS --app $currentNode)"'"
    errorCheck
    if [[ $hgreports = "" ]]; then
        echo "Error >> Blank hgreports connection string!"
        exit 1
    fi
    hgsecurity="MONGO_HGSECURITY='"$(heroku config:get MONGO_HGSECURITY --app $currentNode)"'"
    errorCheck
    if [[ $hgsecurity = "" ]]; then
        echo "Error >> Blank hgsecurity connection string!"
        exit 1
    fi
    hgthanka="MONGO_HGTHANKA='"$(heroku config:get MONGO_HGTHANKA --app $currentNode)"'"
    errorCheck
    if [[ $hgthanka = "" ]]; then
        echo "Error >> Blank hgthanka connection string!"
        exit 1
    fi
    rprimary="REPLICA_PRIMARY='"$(heroku config:get REPLICA_PRIMARY --app $currentNode)"'"
    errorCheck
    if [[ $rprimary = "" ]]; then
        echo "Error >> Blank rprimary connection string!"
        exit 1
    fi
    rsecondary="REPLICA_SECONDARY='"$(heroku config:get REPLICA_SECONDARY --app $currentNode)"'"
    errorCheck
    if [[ $rsecondary = "" ]]; then
        echo "Error >> Blank rsecondary connection string!"
        exit 1
    fi
    rprimaryb="REPLICA_PRIMARY_B='"$(heroku config:get REPLICA_PRIMARY_B --app $currentNode)"'"
    errorCheck
    rsecondaryb="REPLICA_SECONDARY_B='"$(heroku config:get REPLICA_SECONDARY_B --app $currentNode)"'"
    errorCheck
    replica="MONGO_REPLICA='"$(heroku config:get MONGO_REPLICA --app $currentNode)"'"
    errorCheck
    if [[ $replica = "" ]]; then
        echo "Error >> Blank replica connection string!"
        exit 1
    fi
    replicab="MONGO_REPLICA_LR='"$(heroku config:get MONGO_REPLICA_LR --app $currentNode)"'"
    errorCheck
    # build out the etl path
    branchVersion=${branch//release\//}
    branchVersion=${branchVersion//hotfix\//}
    branchVersion=${branchVersion//feature\//}
    eltpath="node deploy/migrateEtl.js --env "$configEnv" --f releases/"$branchVersion"/etl.js"
    echo "Done."
    # copy required language files to dev env
    echo "Copying language files..."
    cp $rootPath/heroku-$currentNode/static/templates/i18n/en.json $rootPath/hgapp/static/templates/i18n
    errorCheck "Error while copying en.json file."
    cp $rootPath/heroku-$currentNode/static/templates/i18n/email/en.json $rootPath/hgapp/static/templates/i18n/email
    errorCheck "Error while copying email/en.json file."
    echo "Running scripts against databases..."
    # build out the run command and include the setting of the process environment variables
    runcmd=$hgcommon" "$hgfinance" "$hglog" "$hgperform" "$hgperka" "$hgreports" "$hgsecurity" "$hgthanka" "$rprimary" "$rsecondary" "$rprimaryb" "$rsecondaryb" "$replica" "$replicab" "$eltpath
    eval $runcmd
    # do not stop the deploy if there is a database script error
    if [[ $? != 0 ]]; then
        echo ">>>>>> Error while running database script! >>> "$etlpath
    else
        echo "Successful."
    fi
}

# function to set the correct status on status.highground.com page
function setStatusIo() {
    statusValue=${1}
    if [[ $statusioAuth != "" ]]; then
        curl https://api.statuspage.io/v1/pages/b9nx5rrg3vvw/components/$statusioComponentId.json -H "Authorization: OAuth $statusioAuth" -X PATCH -d "component[status]=$statusValue"
    fi
}

# function to alter the local files for specific environments
function alterLocalEnvironmentFiles() {
    timeoutFiles=( "display/app.js" "hgapp/app.js" "provision/app.js" )
    for t in "${timeoutFiles[@]}"
    do
        echo "Altering "$t" for "$currentNode
        sed "s/refreshTime = 30210/refreshTime = $refreshTime/g" $rootPath/heroku-$currentNode/static/source/$t > tempfile; mv tempfile $rootPath/heroku-$currentNode/static/source/$t
        errorCheck "Error while altering refresh timeout"
    done
    if [[ $angularDebug = "disable" ]]; then
        echo "Altering static/source/hgapp.js for "$currentNode
        sed "s/strictDi: false/strictDi: true/g" $rootPath/heroku-$currentNode/static/source/hgapp.js > tempfile; mv tempfile $rootPath/heroku-$currentNode/static/source/hgapp.js
        errorCheck "Error while setting strictDi flag"
        echo "Altering static/source/config/app.config.js for "$currentNode
        sed "s/debugInfoEnabled(true)/debugInfoEnabled(false)/g" $rootPath/heroku-$currentNode/static/source/core/config/app.config.js > tempfile; mv tempfile $rootPath/heroku-$currentNode/static/source/core/config/app.config.js
        errorCheck "Error while setting debugInfoEnabled flag"
    fi
}

# function to change the api docs url
function changeAPIDocsUrl() {
    # only change the docs for non-production environments
    if [[ $envName != "apiprod" ]]; then
        for f in $rootPath/heroku-$currentNode/hgnode/api/1.0/doc/*
        do
            sed "s/api.highground.com/$envName.highground.com/g" $f > tempfile; mv tempfile $f
        done
        echo "Altering apidoc.json for "$currentNode
        sed "s/api.highground.com/$envName.highground.com/g" $rootPath/heroku-$currentNode/apidoc.json > tempfile; mv tempfile $rootPath/heroku-$currentNode/apidoc.json
        errorCheck "Error while altering apidoc.json file"
    fi
}

# set the root path if it was passed in
if [ "$2" ]
then
    rootPath=$2
fi

# set the auto-deploy parameters if they were passed in
if [ "$3" ]
then
    autoDeploy=$3
    IFS=',' read -a settings <<< $autoDeploy
    for element in ${settings[@]}
    do
        IFS='=' read -a params <<< $element
        setParameter ${params[0]} ${params[1]}
    done
fi

# set the root path and change directory to the hgapp
rootPath="$scriptRunPath/$rootPath"
cd $rootPath/hgapp

# this is prevent users from running this script from within the hgapp path
if [[ $scriptRunPath =~ .*hgapp.* ]]; then
    echo ">>>>>>> WRONG SCRIPT PATH, SHOULD BE YOUR HOME DIRECTORY <<<<<<<"
    cd ~
    return
fi

# print out the header ascii graphic
if [[ $autoDeploy = "" ]]; then
    cat deploy/resources/header.txt
fi

echo "Root path set to: $rootPath"

# get the current branch from git
echo "Setting branch name..."
branch=$(git rev-parse --abbrev-ref HEAD)
errorCheck "Error while setting branch name."

# check for the supported environments
source $rootPath/hgapp/deploy/resources/environments.sh

if [[ $currentNode = "" ]]; then
    echo -e "\a"
    cd ~
    return
fi

# check if the user/machine has access to deploy to the selected server
allowServerAccess=$(heroku config:get BUILD_ENV --app $currentNode)
noAccessMessage="You do not have access to that server, or heroku API service is currently down, or network access to that server is impeded."
echo "Confirming access permission for "$currentNode"..."
if [[ $allowServerAccess = "" ]]; then
    echo $noAccessMessage
    if [[ $autoDeploy = "" ]]; then
        say $noAccessMessage
    fi
    cd ~
    return
fi
echo "Done."

# if in auto deploy mode, check if there is a current tracking file
# exit if it is currently being deployed
# if not in auto deploy, remove the tracking file, just in case the last time it did not clear
if [[ $autoDeploy != "" && $removeDeployStatus = "no" ]]; then
    if [ -f $rootPath/heroku-$currentNode/deployStatus.txt ]; then
        echo "AUTO-DEPLOYMENT IN PROGRESS, PLEASE WAIT UNTIL COMPLETED!"
        cd ~
        return
    else
        # if auto deploy mode, create a tracking file in the current deploy directory
        echo "Creating tracking file..."
        echo $branch > $rootPath/heroku-$currentNode/deployStatus.txt
        errorCheck "Error while creating the tracking file"
    fi
else
    rm -Rfd $rootPath/heroku-$currentNode/deployStatus.txt
    rm -Rfd $rootPath/heroku-$currentNode/errorHappened.txt
fi
# remove the errorCapture file
rm -Rfd $rootPath/heroku-$currentNode/errorCapture.txt

# start deployment by asking skip questions, normal path is to answer "yes" to every question
echo "Deploying "$branch" to "$fullServerName" environment..."
if [[ $autoDeploy = "" ]]; then
    while true; do
        read -p "Are you sure you want to deploy "$branch" to "$fullServerName" (Yes or No)? " yn
        case $yn in
            [Yy]* ) break;;
            [Nn]* )
                cd ~
                echo -e "\a"
                return
            ;;
            * ) echo "Please answer Yes or No.";;
        esac
    done

    if [[ $webServer = "yes" ]]; then
        while true; do
            read -p "Copy only changed files to S3 (Yes or No)? " yn
            case $yn in
                [Yy]* )
                    changedFiles="yes"
                    break
                ;;
                [Nn]* )
                    changedFiles="no"
                    break
                ;;
                * ) echo "Please answer Yes or No.";;
            esac
        done
        while true; do
            read -p "Skip copying javascript libraries (Yes or No)? " yn
            case $yn in
                [Yy]* )
                    copyJSlib="no"
                    break
                ;;
                [Nn]* )
                    copyJSlib="yes"
                    break
                ;;
                * ) echo "Please answer Yes or No.";;
            esac
        done
    fi

    while true; do
        read -p "Skip rebuilding the repository (Yes or No)? " yn
        case $yn in
            [Yy]* )
                skipRefreshRepos="yes"
                break
            ;;
            [Nn]* )
                skipRefreshRepos="no"
                break
            ;;
            * ) echo "Please answer Yes or No.";;
        esac
    done

    while true; do
        read -p "Skip running the database migration/ETL (Yes or No)? " yn
        case $yn in
            [Yy]* )
                runDatabaseMigration="no"
                break
            ;;
            [Nn]* )
                runDatabaseMigration="yes"
                break
            ;;
            * ) echo "Please answer Yes or No.";;
        esac
    done

    if [[ $envName = "st" ]]; then
        while true; do
            read -p "Skip syncing Production to Staging server (Yes or No)? " yn
            case $yn in
                [Yy]* )
                    syncStage="no"
                    break
                ;;
                [Nn]* )
                    syncStage="yes"
                    while true; do
                        read -p "Skip deleting database backup source files (Yes or No)? " ans
                        case $ans in
                            [Yy]* )
                                deleteBackup="no"
                                break
                            ;;
                            [Nn]* )
                                deleteBackup="yes"
                                break
                            ;;
                            * ) echo "Please answer Yes or No.";;
                        esac
                    done
                    break
                ;;
                * ) echo "Please answer Yes or No.";;
            esac
        done

    fi

    if [[ $envName = "prod" ]]; then
        while true; do
            read -p "You are going to deploy to PRODUCTION! Continue (Yes or No)? " yn
            case $yn in
                [Yy]* ) break;;
                [Nn]* )
                    cd ~
                    echo -e "\a"
                    return
                ;;
                * ) echo "Please answer Yes or No.";;
            esac
        done
    fi
else
    # check if any changes
    if [[ $bypassChangeCheck = "no" ]]; then
        cd $rootPath/hgapp
        uptodate=$(git pull --dry-run 2>&1 | grep $branch)
        if [[ $uptodate = "" ]]; then
            echo "No changes to deploy."
            echo "Removing tracking file..."
            rm -Rfd $rootPath/heroku-$currentNode/deployStatus.txt
            cd ~
            return
        else
            echo "Auto-deploying..."
        fi
    else
        echo "Auto-deploying..."
    fi
fi

# set ulimit high
echo "Setting ulimit to 4096..."
ulimit -n 4096
errorCheck "Error while setting ulimit."

# notify Slack channels deployment starting
if [[ $updateSlack = "yes" ]]; then
    echo "Notifying Slack channels deployment is starting..."
    BUILD_ENV=$configEnv node $rootPath/hgapp/deploy/notifySlackDeployment.js "deploying" `id -un` $fullServerName $branch
    errorCheck "Error while notifying HipChat room."
fi

# set the statusio auth token
if [[ $statusioComponentId != "" ]]; then
    statusioAuth=$(heroku config:get STATUSIO_AUTH --app hgnconfig)
fi

# check if repository is too large and prune it, anything larger than 100MB should be pruned
repoSize=`heroku info --app $currentNode | grep "Repo Size" | sed "s/[^0-9]//g"`
echo "Repo size: "$repoSize" MB"
if [[ $repoSize -gt 100 ]]; then
    # check if heroku repo plugin is installed
    repoTools=`heroku plugins | grep "heroku-repo"`
    if [[ $repoTools = heroku-repo* ]]; then
        echo "Repository for "$currentNode" is too large, pruning..."
        heroku repo:reset -a $currentNode
        errorCheck "Error while pruning Heroku repository."
        skipRefreshRepos="no"
    else
        echo "You are required to install Heroku repo tools >> heroku plugins:install https://github.com/heroku/heroku-repo.git"
        exit 1
    fi
fi

# if re-syncing repository to heroku, force uploading of all S3 files
if [[ $skipRefreshRepos = "no" ]]; then
    changedFiles="no"
fi

# s3 sync requires aws cli to be installed locally, and credentials for access to S3 buckets
# to install
# $ sudo pip install awscli
# if above doesn't work, or an update is needed, use:
#    sudo -H pip install awscli --upgrade --ignore-installed six
#    sudo pip install futures
# $ aws configure
# enter the AWS Access Key ID, AWS Secret Access Key, Default region name (us-east-1), and Default output format (json)
if [[ $syncStage = "yes" ]]; then
    echo "Downloading the latest production backup from S3..."
    # find the key of the last backup of production data stored on S3
    PRODFILEKEY=`aws s3 ls s3://hgarchive/mongolab/$restoreFilePrefix --recursive | sort | grep tgz | tail -n 1 | awk '{print $4}' | sed "s/mongolab\///g"`
    # copy the file from S3 to your local backup/st directory
    if [ ! -f $rootPath/backup/st/$PRODFILEKEY ]; then
        aws s3 cp s3://hgarchive/mongolab/$PRODFILEKEY $rootPath/backup/st/
        errorCheck "Error while downloading production backup from S3."
    fi
    if [ ! -f $rootPath/backup/st/$PRODFILEKEY ]; then
        echo "Missing file: "$PRODFILEKEY" >>> file did not download."
        exit 1
    fi
    # uncompress the database files
    echo "Unpacking "$PRODFILEKEY"..."
    cd  $rootPath/backup/st
    gunzip -c $PRODFILEKEY | tar xopf -
    errorCheck "Error while unpacking "$PRODFILEKEY
    cd ~
    # staging the database files
    echo "Moving database files..."
    PRODFILEDIR=`echo $PRODFILEKEY | sed "s/\.tgz//g"`
    if [[ $PRODFILEDIR = "" ]]; then
        echo "Directory name is blank!"
        exit 1
    fi
    mv $rootPath/backup/st/$PRODFILEDIR/hgcommon $rootPath/backup/st/
    mv $rootPath/backup/st/$PRODFILEDIR/hgfinance $rootPath/backup/st/
    mv $rootPath/backup/st/$PRODFILEDIR/hgperform $rootPath/backup/st/
    mv $rootPath/backup/st/$PRODFILEDIR/hgperka $rootPath/backup/st/
    mv $rootPath/backup/st/$PRODFILEDIR/hgsecurity $rootPath/backup/st/
    mv $rootPath/backup/st/$PRODFILEDIR/hgthanka $rootPath/backup/st/
    errorCheck "Error while moving database files"
    # remove the rest of the files that not needed

    echo "Removing dir and tgz file..."
    rm -Rfd $rootPath/backup/st/$PRODFILEKEY
    rm -Rfd $rootPath/backup/st/$PRODFILEDIR
    errorCheck "Error while removing dir and tgz files."

    echo "Set maintenance on in Staging..."
    heroku maintenance:on --app hgnst
    errorCheck "Error while setting maintenance on in Staging."

    # removed the syncing of s3 files because the cross-region replication will take care of it
    # hgprod --> hgprod-backup --> hgstage

    dbPrimary=$(heroku config:get REPLICA_PRIMARY --app hgnst)
    dbHost=$(heroku config:get MONGO_HGLOG --app hgnst)
    dbPort=$(heroku config:get MONGO_HGLOG_PORT --app hgnst)
    dbHost=${dbHost/__primary__/$dbPrimary}':'$dbPort
    # set the credential variables from the heroku config file
    echo "Reading configuration credentials..."
    echo "Reading username..."
    dbUser=$(heroku config:get MONGO_HGLOG_USERNAME --app hgnst)
    errorCheck "Error while reading database username value."
    echo "Reading password..."
    dbPassword=$(heroku config:get MONGO_HGLOG_PASSWORD --app hgnst)
    errorCheck "Error while reading database password value."

    # mongorestore requires mongo server to be installed locally
    if [[ $dbHost != "" && $dbUser != "" && $dbPassword != "" ]]; then
        # remove large collections that should not be synced
        echo "Removing collections that should not be synced..."
        rm -Rfd $rootPath/backup/st/hgcommon/Notification.bson
        rm -Rfd $rootPath/backup/st/hgcommon/Notification.metadata.json
        rm -Rfd $rootPath/backup/st/hgcommon/NotificationQueueItem.bson
        rm -Rfd $rootPath/backup/st/hgcommon/NotificationQueueItem.metadata.json
        rm -Rfd $rootPath/backup/st/hgcommon/EventBusItem.bson
        rm -Rfd $rootPath/backup/st/hgcommon/EventBusItem.metadata.json
        rm -Rfd $rootPath/backup/st/hgcommon/ExperiencePointActivity.bson
        rm -Rfd $rootPath/backup/st/hgcommon/ExperiencePointActivity.metadata.json
        rm -Rfd $rootPath/backup/st/hgcommon/MemberTutorial.bson
        rm -Rfd $rootPath/backup/st/hgcommon/MemberTutorial.metadata.json
        rm -Rfd $rootPath/backup/st/hgcommon/UserInfoWithToken.bson
        rm -Rfd $rootPath/backup/st/hgcommon/UserInfoWithToken.metadata.json
        rm -Rfd $rootPath/backup/st/hgcommon/ProvisionActivity.bson
        rm -Rfd $rootPath/backup/st/hgcommon/ProvisionActivity.metadata.json
        #rm -Rfd $rootPath/backup/st/hgfinance/Transaction.bson
        #rm -Rfd $rootPath/backup/st/hgfinance/Transaction.metadata.json
        rm -Rfd $rootPath/backup/st/hgsecurity/UserSecurityWithToken.bson
        rm -Rfd $rootPath/backup/st/hgsecurity/UserSecurityWithToken.metadata.json
        rm -Rfd $rootPath/backup/st/hgthanka/MemberInteraction.bson
        rm -Rfd $rootPath/backup/st/hgthanka/MemberInteraction.metadata.json
        rm -Rfd $rootPath/backup/st/hgthanka/MemberRelevancy.bson
        rm -Rfd $rootPath/backup/st/hgthanka/MemberRelevancy.metadata.json
        errorCheck "Error while removing collections."
        echo "Restoring production database to staging database..."
        echo "Restoring hgperka..."
        mongorestore --drop -h $dbHost -d st-hgperka -u $dbUser -p $dbPassword $rootPath/backup/st/hgperka
        errorCheck "Error while restoring hgperka to staging."
        sleep 90 & spinner $!
        echo "Restoring hgfinance..."
        mongorestore --drop -h $dbHost -d st-hgfinance -u $dbUser -p $dbPassword $rootPath/backup/st/hgfinance
        errorCheck "Error while restoring hgfinance to staging."
        sleep 90 & spinner $!
        echo "Restoring hgsecurity..."
        mongorestore --drop -h $dbHost -d st-hgsecurity -u $dbUser -p $dbPassword $rootPath/backup/st/hgsecurity
        errorCheck "Error while restoring hgsecurity to staging."
        sleep 90 & spinner $!
        echo "Restoring hgperform..."
        mongorestore --drop -h $dbHost -d st-hgperform -u $dbUser -p $dbPassword $rootPath/backup/st/hgperform
        errorCheck "Error while restoring hgperform to staging."
        sleep 90 & spinner $!
        echo "Restoring hgthanka..."
        mongorestore --drop -h $dbHost -d st-hgthanka -u $dbUser -p $dbPassword $rootPath/backup/st/hgthanka
        errorCheck "Error while restoring hgthanka to staging."
        sleep 90 & spinner $!
        echo "Restoring hgcommon..."
        mongorestore --drop -h $dbHost -d st-hgcommon -u $dbUser -p $dbPassword $rootPath/backup/st/hgcommon
        errorCheck "Error while restoring hgcommon to staging."
        # do not restore hgreports yet until the archiving project has completed
        #echo "Restoring hgreports..."
        #mongorestore --drop -h $dbHost -d st-hgreports -u $dbUser -p $dbPassword $rootPath/backup/st/hgreports
        #errorCheck "Error while restoring hgreports to staging."
        # do not restore hglog - until we prune the user activity log, we will not restore this database
        #echo "Restoring hglog..."
        #mongorestore --drop -h $dbHost -d st-hglog -u $dbUser -p $dbPassword $rootPath/backup/st/hglog
        #errorCheck "Error while restoring hglog to staging."
        # remove all staging collections
        if [[ $deleteBackup = "yes" ]]; then
            echo "Removing all staging collections..."
            rm -Rfd $rootPath/backup/st/hgcommon
            rm -Rfd $rootPath/backup/st/hgfinance
            rm -Rfd $rootPath/backup/st/hgperform
            rm -Rfd $rootPath/backup/st/hgperka
            rm -Rfd $rootPath/backup/st/hgsecurity
            rm -Rfd $rootPath/backup/st/hgthanka
            errorCheck "Error while removing all staging collections."
        fi
        # restore the user account
        echo "Reading user credentials for staging databases..."
        stagingUsername=$(heroku config:get STAGING_USERNAME --app hgnconfig)
        stagingPassword=$(heroku config:get STAGING_PASSWORD --app hgnconfig)
        errorCheck "Error while reading credentials."
        if [[ $stagingUsername != "" && $stagingPassword != "" ]]; then
            echo "Copying file restoreStagingUser.js..."
            cp $rootPath/hgapp/deploy/db-scripts/restoreStagingUser.js $rootPath/backup/st/restoreStagingUser.js
            sed "s/STAGING_USERNAME/$stagingUsername/g" $rootPath/backup/st/restoreStagingUser.js > tempfile; mv tempfile $rootPath/backup/st/restoreStagingUser.js
            sed "s/STAGING_PASSWORD/$stagingPassword/g" $rootPath/backup/st/restoreStagingUser.js > tempfile; mv tempfile $rootPath/backup/st/restoreStagingUser.js
            errorCheck "Error while copying file restoreStagingUser.js."
            echo "Reading connection string for staging databases..."
            connection=$(heroku config:get STAGE_CONNECT --app hgnconfig)
            errorCheck "Error while reading connection string for staging databases."
            if [[ $connection != "" ]]; then
                echo "Pause for 1 minute before executing the restore script to allow databases to spin back up..."
                sleep 60 & spinner $!
                echo "Executing restoreStagingUser.js script against staging databases..."
                cd $rootPath/hgapp/deploy/db-scripts
                mongoctl connect $connection $rootPath/backup/st/restoreStagingUser.js
                errorCheck "Error while executing restoreStagingUser.js script."
                echo "Removing restoreStagingUser.js file..."
                rm -Rfd $rootPath/backup/st/restoreStagingUser.js
                errorCheck "Error while removing restoreStagingUser.js file."
                cd $rootPath/hgapp
            fi
        fi
    fi
fi

# pull latest code
# requirement: add these settings to .netrc file in the local user directory
#   machine github.com
#   login myloginName
#   password myPassword
cd $rootPath/hgapp
echo "Removing git log file..."
rm .git/gc.log
errorCheck "Error while removing git log file."
echo "Pruning files in local git repro..."
git gc --auto
errorCheck "Error while pruning git repro files."
echo "Pulling latest code from github..."
git pull
errorCheck "Error while pulling latest code from github."

# staging files
echo "Staging updated files..."
echo "Clearing current staging directories..."
echo "Removing hgnode directory..."
rm -Rfd $rootPath/heroku-$currentNode/hgnode
errorCheck "Error while removing hgnode directory."
echo "Removing certs directory..."
rm -Rfd $rootPath/heroku-$currentNode/certs
errorCheck "Error while removing certs directory"
echo "Removing static directory..."
rm -Rfd $rootPath/heroku-$currentNode/static
errorCheck "Error while removing static directory."
echo "Removing build directory..."
rm -Rfd $rootPath/heroku-$currentNode/build
errorCheck "Error while removing build directory."

# create the local directory if not exists
if [ -d $rootPath/heroku-$currentNode ]; then
    echo "Directory heroku-"$currentNode" exists"
else
    echo "Creating directory heroku-"$currentNode"..."
    mkdir $rootPath/heroku-$currentNode
    errorCheck "Error while creating heroku directory."
fi

# copy all of the staged directories
echo "Copying directories.."
if [ -d $rootPath/heroku-$currentNode/node_modules ]; then
    echo "node_modules exists, will perform npm install only"
else
    echo "Copying node_modules for fast tracking..."
    cp -R $rootPath/hgapp/node_modules $rootPath/heroku-$currentNode
    errorCheck "Error while copying node_modules directory."
fi
echo "Copying gitignore..."
cp $rootPath/hgapp/deploy/deploy-gitignore $rootPath/heroku-$currentNode/.gitignore
errorCheck "Error while copying the .gitignore file."
echo "Copying hgnode..."
rsync -av --exclude='hgnode/test' $rootPath/hgapp/hgnode $rootPath/heroku-$currentNode
errorCheck "Error while copying hgnode directory."
echo "Copying package files..."
cp -Rf $rootPath/hgapp/package.json $rootPath/heroku-$currentNode
errorCheck "Error while copying package.json file."
echo "Copying Procfile..."
cp -Rf $rootPath/hgapp/Procfile $rootPath/heroku-$currentNode
errorCheck "Error while copying Procfile file."
echo "Copying certs..."
cp -R $rootPath/hgapp/deploy/certs $rootPath/heroku-$currentNode
errorCheck "Error while copying certs."
echo "Copying provision directory..."
cp -Rf $rootPath/hgapp/provision $rootPath/heroku-$currentNode
errorCheck "Error while copying provision directory."
echo "Copying build files..."
cp -R $rootPath/hgapp/build $rootPath/heroku-$currentNode
errorCheck "Error while copying build directory."

# copy all of the build files for static assets if deploying the web server
if [[ $webServer = "yes" ]]; then
    echo "Copying static files..."
    rsync -av --exclude='static/img' $rootPath/hgapp/static $rootPath/heroku-$currentNode
    mkdir $rootPath/heroku-$currentNode/static/img
    cp -R $rootPath/hgapp/static/img/mocks $rootPath/heroku-$currentNode/static/img/mocks
    cp -R $rootPath/hgapp/static/img/pdf $rootPath/heroku-$currentNode/static/img/pdf
    errorCheck "Error while copying static files."
    # alter the cookies.js file to include the environment
    echo "Altering cookies.js file to set the environment..."
    sed "s/SUBDOMAIN_ENVIRONMENT = ''/SUBDOMAIN_ENVIRONMENT = '$envName.'/g" $rootPath/heroku-$currentNode/static/source/core/utility/cookies.js > tempfile; mv tempfile $rootPath/heroku-$currentNode/static/source/core/utility/cookies.js
    if [[ $multiplex = "yes" ]]; then
        sed "s/ENABLE_CONNECTION_MULTIPLEX = false/ENABLE_CONNECTION_MULTIPLEX = true/g" $rootPath/heroku-$currentNode/static/source/core/utility/cookies.js > tempfile; mv tempfile $rootPath/heroku-$currentNode/static/source/core/utility/cookies.js
    fi
    errorCheck "Error while altering cookies.js file."
    if [[ $cdnName != "" ]]; then
        echo "Alter http.js file for CDN.."
        cdnList=$(cat $rootPath/heroku-$currentNode/hgnode/configurations/cf/$envName-config.js | grep $cdnName | tr '\n' ' ')
        errorCheck "Error while reading configuration file."
        # escape slashes
        cdnList="${cdnList//\//\\/}"
        # remove all spaces
        cdnList="${cdnList// /}"
        # add placeholder after commas
        cdnList="${cdnList//,/,NEWLINE}"
        cdnPlaceHolder="\/\/_cdn_list_goes_here"
        sed "s/$cdnPlaceHolder/$cdnList/g" $rootPath/heroku-$currentNode/static/source/hgapp/config/http.js > tempfile; mv tempfile $rootPath/heroku-$currentNode/static/source/hgapp/config/http.js
        errorCheck "Error while altering http.js file."
        sed 's/NEWLINE/\
                /g' $rootPath/heroku-$currentNode/static/source/hgapp/config/http.js > tempfile; mv tempfile $rootPath/heroku-$currentNode/static/source/hgapp/config/http.js
        errorCheck "Error while altering http.js file."
    fi
    echo "Copying tempprovision directory..."
    cp -Rf $rootPath/hgapp/tempprovision $rootPath/heroku-$currentNode
    errorCheck "Error while copying tempprovision directory."
    # alter the local environment files (for prod and angular debugging)
    alterLocalEnvironmentFiles
fi

# copy server.js file
echo "Copying server.js file..."
cp -Rf $rootPath/hgapp/server.js $rootPath/heroku-$currentNode
errorCheck "Error while copying server.js file."
echo "Copying worker.js file..."
cp -Rf $rootPath/hgapp/worker.js $rootPath/heroku-$currentNode
errorCheck "Error while copying worker.js file."

# if api server, copy the webSocket.server.js file and apidocs
if [[ $api = "yes" ]]; then
    echo "Copying webSocket.server.js file..."
    cp -Rf $rootPath/hgapp/webSocket.server.js $rootPath/heroku-$currentNode
    errorCheck "Error while copying webSocket.server.js file."

    echo "Copying API docs"
    # copy apidoc.json file
    cp -Rf $rootPath/hgapp/apidoc.json $rootPath/heroku-$currentNode
    errorCheck "Error while copying apidoc.json file."
    cp -Rf $rootPath/hgapp/apidoc $rootPath/heroku-$currentNode
    errorCheck "Error while copying apidoc folder"

    # change the api docs url to point to the correct environment
    changeAPIDocsUrl
fi
echo "Copying slugignore file..."
cp -Rf $rootPath/hgapp/.slugignore $rootPath/heroku-$currentNode
errorCheck "Error while copying slugignore file."

# change out environmental settings
echo "Changing environmental settings..."
# remove all other config files
echo "Removing all config files..."
rm -Rfd $rootPath/heroku-$currentNode/hgnode/configurations/cf/*-config.js
errorCheck "Error while removing config files."
echo "Removing all keystore files..."
rm -Rfd $rootPath/heroku-$currentNode/hgnode/configurations/ks/*-keystore.js
errorCheck "Error while removing keystore files."

# copy the target environment config and keystore
echo "Copying "$configEnv"-config.js file..."
cp -Rf $rootPath/hgapp/hgnode/configurations/cf/$configEnv-config.js $rootPath/heroku-$currentNode/hgnode/configurations/cf
errorCheck "Error while copying "$configEnv"-config.js file."
echo "Copying "$configEnv"-keystore.js file..."
cp -Rf $rootPath/hgapp/hgnode/configurations/ks/$configEnv-keystore.js $rootPath/heroku-$currentNode/hgnode/configurations/ks
errorCheck "Error while copying "$configEnv"-keystore.js file."

# set the procfile correctly for server type
if [[ $workerProcess = "no" ]]; then
    echo "Altering Procfile file..."
    sed "/worker.js/d" $rootPath/heroku-$currentNode/Procfile > tempfile; mv tempfile $rootPath/heroku-$currentNode/Procfile
    errorCheck "Error while altering Procfile file."
fi

# read aws keys
echo "Reading AWS creds..."
awsKey=$(heroku config:get AWS_KEY --app $currentNode)
errorCheck "Error reading AWS Key"
awsSecret=$(heroku config:get AWS_SECRET --app $currentNode)
errorCheck "Error reading AWS Secret"

# build the static files only for web server deployments
cd $rootPath/heroku-$currentNode
npm install
if [[ $webServer = "yes" ]]; then
    echo "Building server files..."
    if [[ $autoDeploy = "" ]]; then
        BUILD_ENV=$configEnv node build/hgapp-build.js
        rc=$?
    else
        BUILD_ENV=$configEnv node build/hgapp-build.js > errorCapture.txt
        rc=$?
    fi
    if [[ $rc != 0 ]] ; then
        echo "Error code - " $rc
        if [[ $autoDeploy = "" ]]; then
            say "Error building server files."
        fi
        errorCheck "Error while building server files. Could be a JSLint or a node module loading issue."
    fi
    echo "Done."

    # remove local static assets
    echo "Removing local static assets..."
    echo "Removing badges directory..."
    rm -Rfd $rootPath/heroku-$currentNode/static/img/badges
    errorCheck "Error while removing badges."
    # remove everything in user directory becuase the wildcard operation fails on a per extension basis (too many files)
    echo "Removing user directory..."
    rm -Rfd $rootPath/heroku-$currentNode/static/img/user
    errorCheck "Error while removing user directory."
    # add the single file back in
    echo "Creating user directory..."
    mkdir $rootPath/heroku-$currentNode/static/img/user
    errorCheck "Error creating user directory."
    echo "Copying user-readme.txt file..."
    cp -Rf $rootPath/hgapp/static/img/user/user-readme.txt $rootPath/heroku-$currentNode/static/img/user
    errorCheck "Error while copying user-readme.txt file."
    # remove everything from team directory
    echo "Removing team directory..."
    rm -Rfd $rootPath/heroku-$currentNode/static/img/team
    errorCheck "Error while removing team directory."
    # add the single file back in
    echo "Creating team directory..."
    mkdir $rootPath/heroku-$currentNode/static/img/team
    errorCheck "Error while creating team directory."
    echo "Copying team-readme.txt file..."
    cp -Rf $rootPath/hgapp/static/img/team/team-readme.txt $rootPath/heroku-$currentNode/static/img/team
    errorCheck "Error while copying team-readme.txt file."
    # remove everything from product directory
    echo "Removing product directory..."
    rm -Rfd $rootPath/heroku-$currentNode/static/img/product
    errorCheck "Error while removing product directory."
    # add the single file back in
    echo "Creating product directory..."
    mkdir $rootPath/heroku-$currentNode/static/img/product
    errorCheck "Error while creating product directory."
    echo "Copying readme.txt file..."
    cp -Rf $rootPath/hgapp/static/img/product/readme.txt $rootPath/heroku-$currentNode/static/img/product
    errorCheck "Error while copying readme.txt file."
    # remove everything from tmp directory
    echo "Removing tmp directory..."
    rm -Rfd $rootPath/heroku-$currentNode/static/img/tmp
    errorCheck "Error while removing tmp directory."
    # add the single file back in
    echo "Creating tmp directory..."
    mkdir $rootPath/heroku-$currentNode/static/img/tmp
    errorCheck "Error while creating tmp directory."
    echo "Copying tmp-readme.txt file..."
    cp -Rf $rootPath/hgapp/static/img/tmp/tmp-readme.txt $rootPath/heroku-$currentNode/static/img/tmp
    errorCheck "Error while copying tmp-readme.txt file."
    # remove hgprototype-sidesearch
    echo "Removing hgprototype-sidesearch..."
    rm -Rfd $rootPath/heroku-$currentNode/static/templates/hgprototype-sidesearch
    errorCheck "Error while removing hgprototype-sidesearch directory."
    # get list of changed files
    echo "Compiling list of changed files..."
    # include added directories in these folders so git status will list them into changedFiles.txt for uploading
    echo "Adding static/app/* files to git..."
    git add static/app/* --all
    errorCheck "Error while adding static/app/* files to git."
    echo "Adding static/lib/* files to git..."
    git add static/lib/* --all
    errorCheck "Error while adding static/lib/* files to git."
    echo "Adding static/files/* files to git..."
    git add static/files/* --all
    errorCheck "Error while adding static/files/* files to git."
    echo "Adding static/lib/angular/* files to git..."
    git add static/lib/angular/* --all
    errorCheck "Error while adding static/lib/angular/* files to git."
    echo "Adding static/lib/plugins/* files to git..."
    git add static/lib/plugins/* --all
    errorCheck "Error while adding static/lib/plugins/* files to git."
    echo "Adding static/css/images/* files to git..."
    git add static/css/images/* --all
    errorCheck "Error while adding static/css/images/* files to git."
    echo "Creating changedFiles.txt file..."
    git status -s | cut -c4- > changedFiles.txt
    errorCheck "Error while creating changedFiles.txt file."
    if [[ $copyJSlib = "yes" ]]; then
        echo "Flagging JS lib files to be copied to S3..."
        echo "" >> changedFiles.txt
        echo "static/app/hgapp.angular.lib.js" >> changedFiles.txt
        echo "static/app/hgapp.jquery.lib.js" >> changedFiles.txt
        errorCheck "Error while flagging JS lib files."
    fi
    # upload static files to s3 only for web server deployments
    echo "Uploading static files"
    AWS_KEY=$awsKey AWS_SECRET=$awsSecret GIT_DIFF=$rootPath/heroku-$currentNode CHANGED_FILES=$changedFiles BUILD_ENV=$configEnv node build/s3FileUpload.js
    errorCheck "Error while uploading static files to S3."
else
    echo "Setting the build version to "$buildVersion
    sed "s/314159265359/$buildVersion/g" $rootPath/heroku-$currentNode/server.js > tempfile; mv tempfile $rootPath/heroku-$currentNode/server.js
    # copy language files for translations
    echo "Creating static directory for language files..."
    mkdir $rootPath/heroku-$currentNode/static
    mkdir $rootPath/heroku-$currentNode/static/templates
    mkdir $rootPath/heroku-$currentNode/static/img
    errorCheck "Error while creating directory for language files."
    echo "Copying language build files..."
    cp -R $rootPath/hgapp/static/lang $rootPath/heroku-$currentNode/static
    errorCheck "Error while copying language build files."
    echo "Copying language files..."
    cp -R $rootPath/hgapp/static/templates/i18n $rootPath/heroku-$currentNode/static/templates
    errorCheck "Error while copying language files."
    rm -Rfd $rootPath/heroku-$currentNode/static/templates/i18n/readme.txt
    echo "Building files for server..."
    BUILD_ENV=$configEnv node build/server-build.js $api
    errorCheck "Error while building files."
    # copy server html template files
    echo "Copying email HTML templates to server..."
    cp -R $rootPath/hgapp/static/templates/server $rootPath/heroku-$currentNode/static/templates
    errorCheck "Error while copying email HTML templates."
    echo "Copying font files..."
    cp -R $rootPath/hgapp/static/fonts $rootPath/heroku-$currentNode/static
    errorCheck "Error while copying fonts files."
    echo "Copying pdf files..."
    cp -R $rootPath/hgapp/static/img/pdf $rootPath/heroku-$currentNode/static/img
    errorCheck "Error while copying pdf files."
fi

# copy custom-map.json file
echo "Copying custom-map.json file..."
cp -Rf $rootPath/heroku-$currentNode/static/lang/custom-map.json $rootPath/heroku-$currentNode/static/templates/i18n
errorCheck "Error while copying custom-map.json file..."

# remove source and build files
echo "Removing source, build, and test files..."
echo "Removing build directory..."
rm -Rfd $rootPath/heroku-$currentNode/build
errorCheck "Error while removing build directory."
echo "Removing build.log file..."
rm -Rfd $rootPath/heroku-$currentNode/build.log
errorCheck "Error while removing build.log file."
echo "Removing exceptions.log file..."
rm -Rfd $rootPath/heroku-$currentNode/exceptions.log
errorCheck "Error while removing exceptions.log file."
echo "Removing static/angular-seed directory..."
rm -Rfd $rootPath/heroku-$currentNode/static/angular-seed
errorCheck "Error while removing static/angular-seed directory."
echo "Removing static/html directory..."
rm -Rfd $rootPath/heroku-$currentNode/static/html
errorCheck "Error while removing static/html directory."
echo "Removing static/img/attachment directory..."
echo "Removing static/less directory..."
rm -Rfd $rootPath/heroku-$currentNode/static/less
errorCheck "Error while removing static/less directory."
echo "Removing static/source directory..."
rm -Rfd $rootPath/heroku-$currentNode/static/source
errorCheck "Error while removing static/source directory."
echo "Removing static/templates/banner directory..."
rm -Rfd $rootPath/heroku-$currentNode/static/templates/banner
errorCheck "Error while removing static/templates/banner directory."
echo "Removing static/lang directory..."
rm -Rfd $rootPath/heroku-$currentNode/static/lang
errorCheck "Error while removing static/lang directory."
echo "Removing static/helpers directory..."
rm -Rfd $rootPath/heroku-$currentNode/static/helpers
errorCheck "Error while removing static/helpers directory."
echo "Removing provision/*.xlsx files..."
rm -Rfd $rootPath/heroku-$currentNode/provision/*.xlsx
errorCheck "Error while removing provision/*.xlsx files."
echo "Removing provision/*.xls files..."
rm -Rfd $rootPath/heroku-$currentNode/provision/*.xls
errorCheck "Error while removing provision/*.xls files."
echo "Removing tempprovision/*.xlsx files..."
rm -Rfd $rootPath/heroku-$currentNode/tempprovision/*.xlsx
errorCheck "Error while removing tempprovision/*.xlsx files."
echo "Removing tempprovision/*.xls files..."
rm -Rfd $rootPath/heroku-$currentNode/tempprovision/*.xls
errorCheck "Error while removing tempprovision/*.xls files."
echo "Removing provision/*.XLSX files..."
rm -Rfd $rootPath/heroku-$currentNode/provision/*.XLSX
errorCheck "Error while removing provision/*.XLSX files."
echo "Removing provision/*.XLS files..."
rm -Rfd $rootPath/heroku-$currentNode/provision/*.XLS
errorCheck "Error while removing provision/*.XLS files."
echo "Removing tempprovision/*.XLSX files..."
rm -Rfd $rootPath/heroku-$currentNode/tempprovision/*.XLSX
errorCheck "Error while removing tempprovision/*.XLSX files."
echo "Removing tempprovision/*.XLS files..."
rm -Rfd $rootPath/heroku-$currentNode/tempprovision/*.XLS
errorCheck "Error while removing tempprovision/*.XLS files."
echo "Removing versionNumber.txt file..."
rm -Rfd $rootPath/heroku-$currentNode/static/versionNumber.txt
errorCheck "Error while removing versionNumber.txt file."

# remove worker.js file if the environment doesn't include a worker
if [[ $workerProcess = "no" ]]; then
    echo "Removing worker.js file..."
    rm -Rfd $rootPath/heroku-$currentNode/worker.js
    errorCheck "Error while removing worker.js file."
fi

echo "Removing changedFiles.txt file..."
rm -Rfd $rootPath/heroku-$currentNode/changedFiles.txt
errorCheck "Error while removing changedFiles.txt file."
echo "Removing errorCapture.txt file..."
rm -Rfd $rootPath/heroku-$currentNode/errorCapture.txt
errorCheck "Error while removing errorCapture.txt file."

# check to refresh repos
if [[ $skipRefreshRepos = "no" ]]; then
    # remove all git tracking files
    echo "Clearing all git tracking files..."
    rm -Rf `find . -name .git`
    errorCheck "Error while removing all .git tracking files."
    echo "Re-establishing git repository..."
    git init
    errorCheck "Error while initializing git repository."
    echo "Adding new files to local git repository..."
    git add . --all
    errorCheck "Error while adding all files to local git repository."
    echo "Adding modified files to local git repository..."
    git add -u
    errorCheck "Error while adding modified files to local git repository."
    echo "Committing files to local git repository..."
    git commit -m "Refreshing remote "$currentNode" git repository to decrease size of heroku repos."
    errorCheck "Error while committing files to local git repository."
    echo "Syncing to remote git respository..."
    heroku git:remote -a $currentNode
    errorCheck "Error while syncing to remote git respository."
else
    # add any new files for web
    echo "Updating new files to "$currentNode" repository..."
    echo "Adding new files to local git repository..."
    git add . --all
    errorCheck "Error while adding new files to local git repository."
    echo "Adding modified files to local git repository..."
    git add -u
    errorCheck "Error while adding modified files to local git repository."

    # commit files for web
    echo "Committing changes to "$currentNode" repository..."
    git commit -m "commit release code"
    errorCheck "Error while committing files to local git repository."
fi

# get number of web dynos from config
echo "Reading the number of web dynos..."
dynos=$(heroku ps --app $currentNode | grep -E0 'web\.' | wc -l)
let "dynos=$dynos+0"
if [[ $dynos = 0 ]]; then
    dynos=1
fi
errorCheck "Error while reading the number of web dynos."

echo "There are "$dynos" web dynos for "$currentNode

# enable maintenance mode on site
if [[ $preboot = "no" ]]; then
    echo "Enabling maintenance mode..."
    heroku maintenance:on --app $currentNode
    errorCheck "Error while enabling maintenance mode on heroku app."
fi
if [[ $statusioComponentId != "" ]]; then
    echo "Setting status.io page..."
    setStatusIo "partial_outage"
    errorCheck "Error while setting status.io page."
fi

# stop worker process and web process
if [[ $preboot = "no" ]]; then
        echo "Stopping web dynos..."
        heroku ps:scale web=0 --app $currentNode
        errorCheck "Error while scaling down web dynos on heroku app."
    if [[ $workerProcess = "yes" ]]; then
        echo "Stopping worker dyno..."
        heroku ps:scale worker=0 --app $currentNode
        errorCheck "Error while scaling down worker dyno on heroku app."
    fi
fi

# switch to home path
cd ~
cd $rootPath/heroku-$currentNode

# if deploying to esb, disable the worker process first
if [[ $workerProcess = "yes" ]]; then
    echo "Disabling worker dyno process..."
    heroku ps:scale worker=0 --app $currentNode
    errorCheck "Error while disabling worker dyno process."
fi

# push code to web
echo "Pushing changes to "$currentNode" web site..."
git push -f heroku master
# if failed to push code, enable worker and take site out of maintenance mode
if [[ $? != 0 ]]; then
    echo "Issue encountered while pushing code to heroku. Current version was not updated."
    # turn on worker process only for esb server deployments
    if [[ $workerProcess = "yes" ]]; then
        heroku ps:scale web=$dynos worker=1 --app $currentNode
    else
        heroku ps:scale web=$dynos --app $currentNode
    fi
    if [[ $preboot = "no" ]]; then
        heroku maintenance:off --app $currentNode
    fi
    if [[ $statusioComponentId != "" ]]; then
        echo "Setting status.io page to operational..."
        setStatusIo "operational"
        errorCheck "Error while setting status.io page."
    fi
    rc=127
    errorCheck "Error while pushing code to heroku."
fi

# deploy database scripts
# to deploy database scripts, access to the hgnconfig server is required
#   that is where the admin database connection strings live (as environment variables)
if [[ $runDatabaseMigration = "yes" ]]; then
    # the CI server time zone should always be set to UTC
    runDatabaseEtlScript
fi

# turn on web and worker process
if [[ $preboot = "no" ]]; then
    echo "Starting web dynos..."
    heroku ps:scale web=$dynos --app $currentNode
    errorCheck "Error while scaling up the web dynos on heroku app."
    if [[ $workerProcess = "yes" ]]; then
        echo "Waiting for 1 minute before spinning up worker process.."
        sleep 60 & spinner $!
        echo "Stating worker dyno..."
        heroku ps:scale worker=1 --app $currentNode
        errorCheck "Error while scaling up the worker dyno."
    fi
else
    # sleep for 3 minutes
    echo "This is a preboot environment."
    echo "It requires some time to move all requests to the new dyno clusters."
    echo "Waiting for 3 minutes..."
    sleep 60 & spinner $!
    echo "Waiting for 2 minutes..."
    sleep 60 & spinner $!
    echo "Waiting for 1 minute..."
    sleep 30 & spinner $!
    echo "Waiting for 30 seconds..."
    sleep 20 & spinner $!
    echo "Waiting for 10 seconds..."
    sleep 10 & spinner $!
    if [[ $workerProcess = "yes" ]]; then
        echo "Enabling the worker dyno process.."
        heroku ps:scale worker=1 --app $currentNode
        errorCheck "Error while scaling up the worker dyno process."
    fi
    # set the status page to operational
    if [[ $statusioComponentId != "" ]]; then
        echo "Setting status.io page to operational..."
        setStatusIo "operational"
        errorCheck "Error while setting status.io page."
    fi
fi

# disable maintenance mode
if [[ $preboot = "no" ]]; then
    echo "Disabling maintenance mode..."
    heroku maintenance:off --app $currentNode
    errorCheck "Error while disabling maintenance mode on heroku app."
    if [[ $statusioComponentId != "" ]]; then
        echo "Setting status.io page to operational..."
        setStatusIo "operational"
        errorCheck "Error while setting status.io page."
    fi
else
    if [[ $syncStage = "yes" ]]; then
        heroku maintenance:off --app hgnst
    fi
fi

# successful deployment
if [[ $autoDeploy = "" ]]; then
    say "Deployment to "$fullServerName" server completed."
else
    # remove the tracking file
    echo "Removing tracking file..."
    rm -Rfd $rootPath/heroku-$currentNode/deployStatus.txt
    # check if last deployment was an error
    if [ -f $rootPath/heroku-$currentNode/errorHappened.txt ]; then
        echo "Sending success email..."
        BUILD_ENV=$configEnv node $rootPath/hgapp/deploy/emailDevelopers.js "SUCCESS" $rootPath $envName $branch $(cat $rootPath/heroku-$currentNode/errorHappened.txt)
        errorCheck "Error while sending deployment email."
        # remove all the old error capture files
        echo "Removing old error capture files..."
        rm -Rfd $rootPath/heroku-$currentNode/errorCapture*.txt
        errorCheck "Error while deleting the old error capture files."
    fi
fi
echo "Removing any existing error flag files..."
rm -Rfd $rootPath/heroku-$currentNode/errorHappened.txt

# email release notes if deploying to production or override is set
if [[ $sendReleaseNotes = "yes" ]]; then
    echo "Reading github token..."
    githubToken=$(heroku config:get GITHUB_TOKEN --app hgnconfig)
    errorCheck "Error while reading github token."
    echo "Reading express pigeon token..."
    expressPigeon=$(heroku config:get EXPRESS_PIGEON --app $currentNode)
    errorCheck "Error while reading express pigeon token."
    echo "Emailing release notes..."
    BUILD_ENV=$configEnv GITHUB_TOKEN=$githubToken EXPRESS_PIGEON=$expressPigeon node $rootPath/hgapp/deploy/emailDevelopers.js "RELEASE" $rootPath $envName $branch "Email Deployment Release Notes."
    errorCheck "Error while emailing release notes."
fi

# if deploying to prod, confirm that staging is disabled
if [[ $envName = "prod" ]]; then
    echo "Scaling back staging web process..."
    heroku ps:scale web=0 --app hgnst
    echo "Done."
    echo "Enable maintenance mode on staging site..."
    heroku maintenance:on --app hgnst
    echo "Done."
    echo "Scaling back staging mobile server..."
    heroku ps:scale web=0 --app hgmost
    echo "Done."
    echo "Scaling back staging esb server..."
    heroku ps:scale worker=0 web=0 --app hgesbst
    echo "Done."
    echo "Scaling back staging api server..."
    heroku ps:scale web=0 --app hgapist
    echo "Done."
fi

# update environments json file
if [[ $updateEnviornmentsWeb = "yes" ]]; then
    echo "Updating environments page..."
    BUILD_ENV=$configEnv AWS_KEY=$awsKey AWS_SECRET=$awsSecret node $rootPath/hgapp/deploy/updateEnvironmentsPage.js $envName $branch `id -un` $rootPath/hgapp
    errorCheck "Error while updating environments web page."
fi

# notify Slack channels deployment successful
if [[ $updateSlack = "yes" ]]; then
    echo "Notifying Slack channels of successful deployment..."
    BUILD_ENV=$configEnv node $rootPath/hgapp/deploy/notifySlackDeployment.js "deployed" `id -un` $fullServerName $branch
    errorCheck "Error while notifying Slack channels."
fi

# return to home directory
cd ~
echo -e "\a"
echo "Site is ready."
