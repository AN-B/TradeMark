var async = require('async'),
    fs = require('fs'),
    GitHubApi = require('github'),
    github = new GitHubApi({
        version: '3.0.0',
        protocol: 'https',
    }),
    milestoneName = process.argv[2];

if (!milestoneName) {
    console.log('Error >>> Milestone name require!');
    process.exit(1);
}

github.authenticate({
    type: "oauth",
    token: "53029766010bf7e65243ce017da7abf421493bf2"
});

function getAllItems (action, callback) {
    var allItems = [],
        lastResponse;
    async.doWhilst(
        function (callback) {
            action.cmd(action.params, function (err, data) {
                if (err) {
                    callback('Error getting items: ' + err);
                } else {
                    console.log('Got ' + data.length + ' items, page ' + action.params.page);
                    allItems = allItems.concat(data);
                    lastResponse = data;
                    action.params.page += 1;
                    callback();
                }
            });
        },
        function () {
            return github.hasNextPage(lastResponse);
        },
        function (err) {
            if (err) {
                callback(err);
            } else {
                console.log('Got a total of ' + allItems.length + ' items.');
                callback(null, allItems);
            }
        }
    );
};


getAllItems({
    cmd: github.issues.getAllMilestones,
    params: {
        user: 'HighGroundInc',
        repo: 'hgapp',
        filter: 'all',
        state: 'open',
        per_page: 100,
        page: 1
    }
}, function (error, allMilestones) {
    var theMilestone;
    if (error) {
        console.log(error);
    } else if (allMilestones) {
        theMilestone = allMilestones.filter(function(milestone) {
            return milestone.title === milestoneName;
        });
        if (theMilestone && theMilestone.length) {
            getAllItems({
                cmd: github.issues.repoIssues,
                params: {
                    user: 'HighGroundInc',
                    repo: 'hgapp',
                    filter: 'all',
                    state: 'open',
                    milestone: theMilestone[0].number,
                    per_page: 100,
                    page: 1
                }
            }, function (error, allIssues) {
                var customerRequests;
                if (error) {
                    console.log(error);
                } else if (allIssues) {
                    allIssues = allIssues.sort(function (a,b) {
                        return a.number - b.number;
                    });
                    // gather the customer requests
                    customerRequests = allIssues.filter(function (issue) {
                        return issue.labels.filter(function (label) {
                                return label.name === '-CUST REQ-';
                            }).length > 0;
                    });
                    customerRequests = customerRequests.map(function (issue) {
                        return ['#' + issue.number, issue.title].join(' ');
                    });
                    // gather all the issues
                    allIssues = allIssues.map(function (issue) {
                        return ['#' + issue.number, issue.title].join(' ');
                    });
                    //console.log(allIssues[0].labels);
                    console.log('Customer Requests');
                    console.log(customerRequests);
                    console.log('\nAll Issues');
                    console.log(allIssues);
                }
            });
        } else {
            console.log('Error >>> Milestone (' + milestoneName + ') not found.');
            process.exit(1);
        }
        //console.log(allMilestones);
    }
});
