load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgfinance");

//UnitType was added to Transaction with VC release.
//Fix historical data and default UnitType value to Credit
var query = {
    UnitType : null
},
update = {
	$set : {
		UnitType : 'Credit'
	}
}
db.Transaction.update(query, update, {multi : true});

switchDB("hgcommon");
db.Group.update({GroupName : 'Keno Kozie'}, {$set : {PublicDisplayName : "K2 Engage"}});

switchDB("hgthanka");
//data cleanup for Collaborators on Track MileStones.
//Track Collaborators only should be set that the root level and not at the MileStone level
db.CareerTrack.find({}).forEach(function (doc) {
    var itemDoc = doc;
    itemDoc.CareerTrackTemplate.MileStones.forEach(function(mStones) {
        mStones.Collaborators = [];
    });
    db.CareerTrack.save(itemDoc);
});

switchDB("hgreports");
//Default All Likes to Recongition
db.MetricsCongrat.update({}, { $set : {c : 'Recognition'}}, {multi : true});
