/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function updateTitleForAllActiveNotificationWithEventSelfEvaluationSubmitted(callback) {
        EntityCache.Notification.aggregate([{
            $match: {
                "Event.Name" : "SelfEvaluationSubmitted",
                "Deleted" : false 
            }
        }, {
            $group: {
                _id: null,
                data: {
                    $addToSet : "$EntityId"
                }
            }
        }], function (error, result) {

            var feedbackSessionIds;
            if (error) {
                return callback(error);
            }
            feedbackSessionIds = result[0].data;
            EntityCache.FeedbackSession.find({
                hgId: {
                    $in: feedbackSessionIds
                }
            }, {
                CycleTitle: 1,
                hgId: 1
            }, function (error, CycleTitles) {
                var checkInTitleMap = {};
                if (error) {
                    return callback(error);
                }
                if(!CycleTitles.length || !feedbackSessionIds.length || CycleTitles.length !== feedbackSessionIds.length) {
                    return callback("not all cycles names are available");
                }
                CycleTitles.forEach(function (CycleTitle) {
                    checkInTitleMap[CycleTitle.hgId] = CycleTitle.CycleTitle;
                });
                EntityCache.Notification.find({
                    "Event.Name" : "SelfEvaluationSubmitted",
                    "Deleted" : false
                }, function (error, selfEvaluationSubmittedNotifications) {
                    if (error) {
                        return callback(error);
                    }
                    Async.each(selfEvaluationSubmittedNotifications, function (selfEvaluationSubmittedNotification, pCallback) {
                        if (!checkInTitleMap[selfEvaluationSubmittedNotification.EntityId]) {
                            return pCallback();
                        }
                        selfEvaluationSubmittedNotification.Title = checkInTitleMap[selfEvaluationSubmittedNotification.EntityId];
                        selfEvaluationSubmittedNotification.save(pCallback);
                    }, callback
                    );
                });
            });
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            updateTitleForAllActiveNotificationWithEventSelfEvaluationSubmitted
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();