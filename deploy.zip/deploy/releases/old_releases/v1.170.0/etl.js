var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addPasswordPolicyProperty(callback) {
        var defaultObj = {
            MinChar: {
                Value: 8, 
                RegEx: '(?=^.{8,}$)'
            } ,
            MinAlpha: {
                Value: 1,
                RegEx: '(?=(.*[a-z]){1,})'
            },
            MinNum: {
                Value: 1,
                RegEx: '(?=(.*\\d){1,})'
            },
            MinUpper: {
                Value: 1,
                RegEx: '(?=(.*[A-Z]){1,})'
            },
            MinSpec: {
                Value: 0,
                RegEx: '(?=(.*[!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~]){0,})'
            },
            Expiration: 0,
            ExpDate: 0,
            RegEx: '(?=^.{8,}$)(?=(.*[a-z]){1,})(?=(.*?[A-Z]){1,})(?=(.*\\d){1,})(?=(.*[!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~]){0,})'
        };
        EntityCache.Group.update({}, {$set: {PasswordPolicy: defaultObj}}, {multi: true}, function (err) {
            if (err) {
                return callback(err);
            }
            callback();
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            addPasswordPolicyProperty
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();