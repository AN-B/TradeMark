/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
    	coaching = require('../../Analytics/coaching.js'),
    	recognition = require('../../Analytics/recognition.js'),
    	shares = require('../../Analytics/shares.js'),
    	Async = require('async');
    /*
     *  Migration Script Template
     *  You need a run function with callback parameter
     *  Must call the callback function when done.
     *
     *  Description:
     *  This script migrates recognition, coaching, shares notes from main 
     *  collection to metrics collecition
     */

    this.Run = function (fcallback) {
    	Async.series([
  			shares.MigrateData,
  			recognition.MigrateData,
  			coaching.MigrateData
  		], function (error, results) {
  			fcallback(error, results);
  		});
    };
};
module.exports = new HgMigrationFile();