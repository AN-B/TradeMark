var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function archiveInvalidPetitions(callback) {
        EntityCache.Petition.find({
            PetitionTypeName: {$in: ['GoalSet', 'GoalClose']},
            Status: 'Pending'
        }, function (error, petitions) {
            if (error) {
                return callback(error);
            }
            var entityIds = petitions.map(function (p) {
                return p.EntityId;
            });
            EntityCache.Goal.find({
                hgId: {$in: entityIds},
                Status: {$in: ['SubmittedForSet', 'SubmittedForClosure']}
            }, function (error, goals) {
                if (error) {
                    return callback(error);
                }
                var invalidPetitionIds = petitions.filter(function (petition) {
                        return !goals.some(function (goal) {
                            return goal.hgId === petition.EntityId;
                        });
                    }).map(function (p) {
                        return p.hgId;
                    });
                EntityCache.Petition.update({
                    hgId: {$in: invalidPetitionIds}
                }, {
                    $set: {
                        Status: 'Archived',
                        ModifiedBy: 'goal_weighting_script'
                    }
                }, {
                    multi: true
                }, function (error, data) {
                    if (error) {
                        return callback('Updating failed', error, data);
                    }
                    callback(null, 'Done');
                });
            });
        });
    }
    function updateRecognitionTemplate(templateRecord, callback) {
        EntityCache.RecognitionTemplate.update({
            GroupId: templateRecord.GroupId,
            hgId: templateRecord.OldhgId
        }, {
            $set: {
                hgId: templateRecord.NewhgId
            }
        }, {
            multi: true
        }, function (error) {
            callback(error);
        });
        // EntityCache.RecognitionTemplate.count({
        //     GroupId: templateRecord.GroupId,
        //     hgId: templateRecord.OldhgId
        // }, function (error, data) {
        //     console.log('count', data);
        //     callback();
        // });
    }

    function updateTranslations(templateRecord, callback) {
        EntityCache.Translations.update({
            GroupId: templateRecord.GroupId,
            EntityId: templateRecord.OldhgId
        }, {
            $set: {
                EntityId: templateRecord.NewhgId
            }
        }, {
            multi: true
        }, function (error) {
            callback(error);
        });
        // EntityCache.Translations.count({
        //     GroupId: templateRecord.GroupId,
        //     EntityId: templateRecord.OldhgId
        // }, function (error, data) {
        //     console.log('count', data);
        //     callback();
        // });
    }

     function updateRecognition(templateRecord, callback) {
        EntityCache.Recognition.update({
            GroupId: templateRecord.GroupId,
            'Template.hgId': templateRecord.OldhgId
        }, {
            $set: {
                'Template.hgId': templateRecord.NewhgId
            }
        }, {
            multi: true
        }, function (error) {
            callback(error);
        });
        // EntityCache.Recognition.count({
        //     GroupId: templateRecord.GroupId,
        //     'Template.hgId': templateRecord.OldhgId
        // }, function (error, data) {
        //     console.log('count', data);
        //     callback();
        // });
    }

    function replaceFidelityTemplateIds(callback) {
        var templateIds = [
            {
                GroupId: "1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde",
                OldhgId: "12c5a400-e1cb-11e3-8093-61f635b7e0a5",
                NewhgId: "8d766170-0d71-11e6-b4e8-bf0668c59ab7"
            },
            {
                GroupId: "1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde",
                OldhgId: "12c52ed0-e1cb-11e3-8093-61f635b7e0a5",
                NewhgId: "8d766171-0d71-11e6-b4e8-bf0668c59ab7"
            },
            {
                GroupId: "1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde",
                OldhgId: "12c5f220-e1cb-11e3-8093-61f635b7e0a5",
                NewhgId: "8d766172-0d71-11e6-b4e8-bf0668c59ab7"
            },
            {
                GroupId: "1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde",
                OldhgId: "12c57cf0-e1cb-11e3-8093-61f635b7e0a5",
                NewhgId: "8d766173-0d71-11e6-b4e8-bf0668c59ab7"
            },
            {
                GroupId: "1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde",
                OldhgId: "12c555e0-e1cb-11e3-8093-61f635b7e0a5",
                NewhgId: "8d766174-0d71-11e6-b4e8-bf0668c59ab7"
            }
        ];
        async.each(templateIds, function (templateRecord, tCallback) {
            async.waterfall([
                function (fcallback) {
                    updateRecognitionTemplate(templateRecord, fcallback);
                },
                function (fcallback) {
                    updateTranslations(templateRecord, fcallback);
                },
                function (fcallback) {
                    updateRecognition(templateRecord, fcallback);
                }
            ], tCallback);
        }, function (error) {
            callback(error);
        });
    }

    this.Run = function (callback) {
        async.series([
            archiveInvalidPetitions,
            replaceFidelityTemplateIds
        ], callback);
    };
};

module.exports = new HgMigrationFile();