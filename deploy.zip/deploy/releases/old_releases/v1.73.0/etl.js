/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
      Async = require('async');

    function addTeamMemberIndex(callback) {
        EntityCache.Team.db.collections.Team.ensureIndex({
            GroupId : 1,
            "TeamMembers.MemberId" : 1,
            Type : 1,
            Status : 1
        }, {name : 'TeamMemberIndex' }, callback);
    }
    this.Run = function (fcallback) {
      Async.series([
          addTeamMemberIndex
      ], function (error, results) {
        fcallback(error, results);
      });
    };
};
module.exports = new HgMigrationFile();