/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        guid = require('node-uuid');

    function addInternationalVisaCard(callback) {
        var card = new EntityCache.TangoCard({
            CardName : "Global Visa",
            Country : "Global",
            CreatedBy : "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
            CreatedDate : Date.now(),
            Denominations : [
                {
                    CurrencyType : "USD",
                    MaxPrice : 0,
                    MinPrice : 0,
                    UnitPrice : 2500,
                    Denomination : 2500,
                    SKU : "GLOBAL-VIRTUAL-VISA-E-2500-STD",
                    Description : "Virtual Visa (Global) $25"
                },
                {
                    CurrencyType : "USD",
                    MaxPrice : 0,
                    MinPrice : 0,
                    UnitPrice : 5000,
                    Denomination : 5000,
                    SKU : "GLOBAL-VIRTUAL-VISA-E-5000-STD",
                    Description : "Virtual Visa (Global) $50"
                },
                {
                    CurrencyType : "USD",
                    MaxPrice : 0,
                    MinPrice : 0,
                    UnitPrice : 10000,
                    Denomination : 10000,
                    SKU : "GLOBAL-VIRTUAL-VISA-E-10000-STD",
                    Description : "Virtual Visa (Global) $100"
                },
                {
                    CurrencyType : "USD",
                    MaxPrice : 0,
                    MinPrice : 0,
                    UnitPrice : 25000,
                    Denomination : 25000,
                    SKU : "GLOBAL-VIRTUAL-VISA-E-25000-STD",
                    Description : "Virtual Visa (Global) $250"
                },
                {
                    CurrencyType : "USD",
                    MaxPrice : 0,
                    MinPrice : 0,
                    UnitPrice : 50000,
                    Denomination : 50000,
                    SKU : "GLOBAL-VIRTUAL-VISA-E-50000-STD",
                    Description : "Virtual Visa (Global)"
                }
            ],
            EmailTemplateId : "27011",
            ExcludedGroupIds : [],
            GroupIds : [
                "all"
            ],
            ImageUrl : "https://hgprod.s3.amazonaws.com/giftcard/us_visa.png",
            ModifiedBy : "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
            ModifiedDate : Date.now(),
            Type : "giftcard",
            hgId : guid.v1()
        });
        EntityCache.TangoCard.remove({CardName : "Global Visa"}, function (error) {
            if (error) {
                return callback(error);
            }
            console.log('old card removed');
            card.save(function (error) {
                if (error) {
                    return callback(error);
                }
                console.log('new card saved');
                callback();
            });
        });
    }
    function addDisplayIndexes(scallback) {
        function hgIdIndex(callback) {
            EntityCache.Display.db.collections.Display.ensureIndex({
                hgId : 1
            }, {name : 'hgId' }, callback);
        }
        function coreDocIndex(callback) {
            EntityCache.Display.db.collections.Display.ensureIndex({
                GroupId : 1
            }, {name : 'CoreDocIndex' }, callback);
        }
        Async.series([
            hgIdIndex,
            coreDocIndex
        ], scallback);
    }
    function addGroupIPAddressIndexes(scallback) {
        function hgIdIndex(callback) {
            EntityCache.GroupIPAddress.db.collections.GroupIPAddress.ensureIndex({
                hgId : 1
            }, {name : 'hgId' }, callback);
        }
        function coreDocIndex(callback) {
            EntityCache.GroupIPAddress.db.collections.GroupIPAddress.ensureIndex({
                GroupId : 1
            }, {name : 'CoreDocIndex' }, callback);
        }
        Async.series([
            hgIdIndex,
            coreDocIndex
        ], scallback);
    }
    function setRecognitionDefaultVisibility(scallback) {
        EntityCache.Recognition.update({}, {$set : {Visibility : {
            RestrictByLocation : false,
            Locations : []
        }}}, {multi : true}, function (error) {
            if (error) {
                console.log(error);
                return scallback(error);
            }
            scallback();
        });
    }
    this.Run = function (callback) {
        Async.series([
            addDisplayIndexes,
            addGroupIPAddressIndexes,
            addInternationalVisaCard,
            setRecognitionDefaultVisibility
        ], callback);
    };
};
module.exports = new HgMigrationFile();
