load("commonDB.js");
setEnv("local");

switchDB("hgcommon");

// Run deploy/SchemaIndes/MemberIndex.js

//Remove Deprecated Fields
var update = {
	$unset: {
		DirectReports : "",
		PublicDisplayName : "",
		FriendlyId : "",
		FollowedMemberIds : ""
	}
};
db.Member.update({}, update);