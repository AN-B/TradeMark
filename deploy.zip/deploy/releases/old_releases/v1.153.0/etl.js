/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function setGoalUpToDate(callback) {
        //below is for dryrun
        // EntityCache.Goal.find({
        //     Status: {$in: ['InProgress', 'PendingClosure', 'SubmittedForClosure']},
        //     PercentCompletion: {$gte: 100},
        //     UpToDate: false
        // }, function (error, goals) {
        //     if (error) {
        //         return callback(error);
        //     }
        //     goals.forEach(function (goal) {
        //         console.log("Goal name:", goal.Name, "Goal Owner:", goal.Owner.FullName, "PercentCompletion: ", goal.PercentCompletion);
        //     });
        //     console.log(goals.length);
        //     callback();
        // });

        EntityCache.Goal.update({
            Status: {$in: ['InProgress', 'PendingClosure', 'SubmittedForClosure']},
            PercentCompletion: {$gte: 100},
            UpToDate: false
        }, {
            $set: {
                UpToDate: true
            }
        }, {
            multi: true
        }, callback);
    }
    this.Run = function (fcallback) {
        Async.series([
            setGoalUpToDate
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();