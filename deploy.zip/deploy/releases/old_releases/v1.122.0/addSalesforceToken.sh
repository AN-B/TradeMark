#!/usr/bin/env bash

##ATTENTION: DO NOT RUN THIS ENTIRE SCRIPT
##UNCOMMENT THE LINES FOR THE SPECIFIC ENV, THEN RUN SCRIPT

##tron
#heroku config:set --app hgntron CANVAS_API_KEY=2001959867777114905
#heroku config:set --app hgapitron CANVAS_API_KEY=2001959867777114905
#heroku config:set --app hgesbtron CANVAS_API_KEY=2001959867777114905

##prod
#heroku config:set --app hgnprod CANVAS_API_KEY=4669161324082854585
#heroku config:set --app hgapiprod CANVAS_API_KEY=4669161324082854585
#heroku config:set --app hgmoprod CANVAS_API_KEY=4669161324082854585
#heroku config:set --app hgesbprod CANVAS_API_KEY=4669161324082854585