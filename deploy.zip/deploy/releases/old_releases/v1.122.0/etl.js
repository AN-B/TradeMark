var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');


    function removeDeleteGoalCycleAlerts(callback) {
       EntityCache.GoalCycle.find({Status: 'Archived'}, function (error, data) {
            if (error || !data.length) {
                return callback(error);
            }
            var cycleIds = data.map(function (item) { return item.hgId; });
            EntityCache.ManagerAlert.update({
                Category: 'Goals',
                Status: 'Active',
                'Data.CycleId': {$in: cycleIds}
            }, {
                $set: {
                    Status: 'Deleted'
                }
            }, {
                $multi: true
            }, callback);
       });
    }

    this.Run = function (callback) {
        async.series([
            removeDeleteGoalCycleAlerts
        ], callback);
    };
};

module.exports = new HgMigrationFile();