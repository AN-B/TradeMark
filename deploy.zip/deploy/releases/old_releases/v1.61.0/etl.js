load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");
var query = {
    Category: 'Achievement',
    RestrictUsers : { $exists : true }
};
db.RecognitionTemplate.find(query).forEach(function(item) {
    var memberData = [];
    var teamData = [];
    if ((item.RestrictUsers && item.RestrictUsers.MemberIds && item.RestrictUsers.MemberIds.length > 0) ) {
        if (item.RestrictUsers && item.RestrictUsers.MemberIds && item.RestrictUsers.MemberIds.length > 0)  {
            item.RestrictUsers.MemberIds.forEach(function (mIds) {
                if (mIds.Id) {
                    memberData.push(mIds.Id);
                }
            });
        }
    }
    
    if ((item.RestrictUsers && item.RestrictUsers.TeamIds && item.RestrictUsers.TeamIds.length > 0) ) {
        if (item.RestrictUsers && item.RestrictUsers.TeamIds && item.RestrictUsers.TeamIds.length > 0)  {
            item.RestrictUsers.TeamIds.forEach(function (tIds) {
                if (tIds.Id) {
                    teamData.push(tIds.Id);
                }
            });
        }
    }
    if (memberData.length > 0 || teamData.length > 0) {
        //print('TemplateId Updated: ' + item.hgId);
            db.RecognitionTemplate.update({hgId : item.hgId}, {
            $set : {
                'RestrictUsers.MemberIds' : memberData,
                'RestrictUsers.TeamIds' : teamData
            }
        });
    }
});



switchDB("hgreports");
// Add Schema
print('==============Add Index========')
db.MetricsManager.drop();
db.MetricsManager.ensureIndex({p : 1, g : 1, m: 1, a : 1, c :1, r: 1});

// Get Employee manager mapping
switchDB("hgcommon");
var memberManagerMapping = {};
var query = {
    MembershipStatus : 'Active'
};
var members = db.Member.find(query, {_id : 0, hgId : 1, MyManagers : 1});
members.forEach(function(item) {
    if (!memberManagerMapping[item.hgId]) {
        memberManagerMapping[item.hgId] = (item.MyManagers && item.MyManagers.length > 0 && item.MyManagers[0].MemberId) ? item.MyManagers[0].MemberId : '';
    }
});

// Get Active Recognitions
switchDB("hgthanka");

var query = {
    Status : "Active",
    'Template.Type' : { $nin : ['Newsfeed', 'ProductItem']}
}, project = {
    hgId : 1,
    CreatedDate : 1,
    'CreatorMember.hgId' : 1, 
    'CreatorMember.GroupName' : 1,
    'CreatorMember.GroupId' : 1, 
    'CreatorMember.FullName' : 1, 
    'RecipientMember.hgId' : 1, 
    'RecipientMember.GroupName' : 1, 
    'RecipientMember.GroupId' : 1, 
    'RecipientMember.FullName' : 1 
};
var recognitions = db.Recognition.find(query, project).toArray();


switchDB("hgreports");
function getJustUTCDate(d) {
    return new Date(new Date(d).toString().substring(0, 15));   
}
function save(params) {
    var query = {
        p : params.Date, 
        g : params.GroupId, 
        c : params.Category,
        m : params.MemberId,
        a : params.Activity,
        r : params.ReportType
    };
    var options = {upsert: true};
    var update = {$inc : { t : 1}};
    //printjson(query);
    //printjson(update);
    db.MetricsManager.update(query, update, options);
}
for (var i = 0; i < recognitions.length; i += 1) {
    if (recognitions[i].CreatorMember && recognitions[i].CreatorMember.hgId) {
        save({
            Date : getJustUTCDate(recognitions[i].CreatedDate),
            GroupId : recognitions[i].CreatorMember.GroupId,
            Category : 'g',
            Activity : 'r',
            ReportType : (memberManagerMapping[recognitions[i].RecipientMember.hgId] === recognitions[i].CreatorMember.hgId),
            MemberId : recognitions[i].CreatorMember.hgId
        });
    }
    save({
        Date : getJustUTCDate(recognitions[i].CreatedDate),
        GroupId : recognitions[i].RecipientMember.GroupId,
        Category : 'r',
        Activity : 'r',
        ReportType : (((recognitions[i].CreatorMember && recognitions[i].CreatorMember.hgId) ?  recognitions[i].CreatorMember.hgId : '') === memberManagerMapping[recognitions[i].RecipientMember.hgId]),
        MemberId : recognitions[i].RecipientMember.hgId
    });
}



