load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

var comments = db.Comment.aggregate({$match : {'EntityType' : 'Recognition'}}, {$project : {'EntityId' : true, 'hgId' : true, 'Comment' : true}}).result;
comments.forEach(function (comment) {
    var byRecognitionId = db.Recognition.find({hgId : comment.EntityId}, {hgId : true, BatchId : true}),
        byBatchId = db.Recognition.find({BatchId : comment.EntityId}, {hgId : true, BatchId : true});
    if (byBatchId.count() > 0) {
        // print('No action required');
        // byBatchId[0].
    } else if (byRecognitionId.count() > 0) {
        // print('The EntityId is Recognition.hgId, should be changed to BatchId. From ' + byRecognitionId[0].hgId + ' to ' + byRecognitionId[0].BatchId);
        db.Comment.update({hgId : comment.hgId}, {$set : {
            EntityId : byRecognitionId[0].BatchId,
            RecognitionId : byRecognitionId[0].hgId//this is for backup purpose, hopefully won't be needed
        }});
    }
});
