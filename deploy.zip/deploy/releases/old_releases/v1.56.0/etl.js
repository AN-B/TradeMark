load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

db.Recognition.ensureIndex({'CreatedDate' : 1,  Status : 1});


//the below provisions Mercury departments
switchDB("hgcommon");

var memberTeamMappings = [
        { MemberName : 'Vip Sandhir', TeamName : 'Executives'},
        { MemberName : 'Courtney Privitera', TeamName : 'Training'},
        { MemberName : 'Zach Lona', TeamName : 'Design'},
        { MemberName : 'Kareem Bawala', TeamName : 'Development'},
        { MemberName : 'Gary Wei', TeamName : 'Development'},
        { MemberName : 'Katrina Manoshin', TeamName : 'Development'},
        { MemberName : 'Marcie Carlos', TeamName : 'QA'},
        { MemberName : 'Philip Plekhanov', TeamName : 'Development'},
        { MemberName : 'Amie Chen', TeamName : 'Design'},
        { MemberName : 'Ross Hettel', TeamName : 'Development'},
        { MemberName : 'Joseph Mainwaring', TeamName : 'Development'},
        { MemberName : 'Eamon Ford', TeamName : 'Development'},
        { MemberName : 'George Eckart', TeamName : 'Design'},
        { MemberName : 'Sergei Habel', TeamName : 'Development'},
        { MemberName : 'Jalpa Khatri', TeamName : 'QA'},
        { MemberName : 'Tony Bobulinski', TeamName : 'Executives'},
        { MemberName : 'Moose Farnham', TeamName : 'Executives'},
        { MemberName : 'Charlie Greubel', TeamName : 'Enterprise Sales'},
        { MemberName : 'Erin Guenther', TeamName : 'Customer Success'},
        { MemberName : 'Gerard Roman', TeamName : 'Customer Success'},
        { MemberName : 'Cu Barnes', TeamName : 'Development'},
        { MemberName : 'Hunter Lane', TeamName : 'Product'},
        { MemberName : 'Libby Allsberry', TeamName : 'Human Resources'},
        { MemberName : 'Corey Rutledge', TeamName : 'Finance'},
        { MemberName : 'A Goud', TeamName : 'Training'},
        { MemberName : 'Miriam Diversiev', TeamName : 'Design'},
        { MemberName : 'Brendan Farrell', TeamName : 'Inside Sales'},
        { MemberName : 'Nick Schreiber', TeamName : 'Enterprise Sales'},
        { MemberName : 'Ross Wallace', TeamName : 'Inside Sales'},
        { MemberName : 'Scott Orscheln', TeamName : 'Inside Sales'},
        { MemberName : 'Peter Wirtshafter', TeamName : 'Inside Sales'},
        { MemberName : 'Marc Gelber', TeamName : 'Inside Sales'},
        { MemberName : 'Justin Goldstein', TeamName : 'Inside Sales'},
        { MemberName : 'Clare Tuchscherer', TeamName : 'Inside Sales'}
    ],
    teamIds = [
        'e88d5efa-917b-425d-815a-9e535334783e',
        '1e455807-35b2-48b5-b8c5-623b2133deb5',
        '0f8f3de0-dd9d-4556-a855-4e8df11fda65',
        '7cfa76df-4f4d-44f7-b1b6-cea7b1f28089',
        'a9e11cf5-4c86-443f-b810-568a40ad2579',
        '4b6540e5-c15e-4c61-af1c-26d8c779dfbd',
        '61aa406a-734d-4293-bfa7-d211d1d357bb',
        'c393848a-d94f-4ca6-ad58-164f788da893',
        '41a20cc9-2672-44d2-89a7-4e171a6b6b25',
        '238b5b67-d790-47ec-857b-84c6580be3f9',
        'a9c93fdc-ab2c-4929-aaf2-be26f2e54793',
        '9e5daa41-b66f-405b-b9b9-3789803e96bf',
        'cec35af5-8981-4a30-b75d-590058628f78',
        '20593042-c3f8-4c5b-a88b-608b94db8242',
        '987e3823-7cb2-48c2-b6d6-4fba743f1d4a',
        'a3113ebc-e783-4325-8208-6fb75b022dc4',
        '0c8779c4-0d7c-4e50-bfc7-cf7934819b57',
        '4602b041-2c7e-4ea5-92d1-abec2deb0cfd',
        'a31545fc-0fca-43ee-a6ff-564c749061d7',
        '56f53294-cd2e-434a-8414-a4fd0dc26237',
        '727cfdda-8e35-4b40-b6d0-a0463f37d4cf',
        '8fb2419f-7d50-4b3d-9307-5babae41f77f',
        '5f93fad7-7e7f-4e78-8848-ea08856e3e1a',
        'a448d86a-96ba-4859-9501-2f6214b5f67c',
        '295fed7e-de12-4314-9a3b-adb5de4ff0e8',
        '56c9f7cb-241b-45de-9c06-cf26bcd3eeca',
        'e683e3ed-0be6-4ac8-bbb3-ef7167697752',
        '4e78794b-080c-4274-8d4d-e8288d6818f4',
        '629cab33-9b51-4ffb-afa1-ba2b2b25b264',
        'c88fc158-0a63-43f3-8a9f-1e44722156a1',
        '6e12a6f0-10fa-46e6-9a7c-7d96d1cb7a74',
        '388d65f3-6e6a-4252-b463-19e0e6a888c0',
        '3997585d-4ca8-40a1-b1f4-34214a13f677',
        'f8065c2f-e058-4e01-982f-261559ba840a',
        'bcc6bc8b-0680-4b6e-872e-6114023b08ba',
        '388491bc-099b-41a6-bef5-593ad3e53a2e',
        '910402bc-5f11-459d-b1a7-a7a1348d0cb5',
        '92ce8ba0-3fcc-4bd6-9276-9e9b9306e280',
        'bc875580-aabb-4b83-8099-5c8044e045c8',
        'cad0b456-513a-4b3e-9a1f-26221d0bb0d9',
        '2b474477-73bf-4cc1-ae2b-65d73ef38df3',
        '1adf02ae-c7a3-4b47-a6fc-3d0ec2599ffa',
        '4cbe245e-716b-4419-afaa-b43084aa8b0e',
        '2b0b14e5-1090-4431-b900-8cddbc3e6762',
        'b46a64ad-5f8a-4ca2-8132-b7864ae082ae',
        '996e0e91-1f48-4713-9365-a94c7a569aa6',
        '8cb34229-15ad-48fc-bb03-ca0b57890e1d',
        '09a3e367-ba81-44fd-98f1-3fa0d2d1b216',
        '22c269e3-4ca0-4a36-bb53-1c4781ad1c83',
        'ff68a7eb-aa76-4a5a-bea9-eb4f07738b72'
    ],
    groupName = 'Mercury Industries',
    ownerId = '1ddaa1c0-9cd9-11e2-ba5b-8bde9b7bbcde',
    ownerFullName = 'Erin Guenther',
    teamNames = [],
    allMembers = [],
    members = db.Member.find({GroupName : groupName, MembershipStatus : 'Active'}),
    groupId = '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde',
    teams = [],
    i = 0,
    departmentTeamMappings = [
        {TeamName : 'Training', DepartmentName : 'Operations'},
        {TeamName : 'Customer Success', DepartmentName : 'Operations'},
        {TeamName : 'Human Resources', DepartmentName : 'Operations'},
        {TeamName : 'Finance', DepartmentName : 'Operations'},
        {TeamName : 'Development', DepartmentName : 'Product Engineering'},
        {TeamName : 'Design', DepartmentName : 'Product Engineering'},
        {TeamName : 'QA', DepartmentName : 'Product Engineering'},
        {TeamName : 'Product', DepartmentName : 'Product Engineering'},
        {TeamName : 'Inside Sales', DepartmentName : 'Sales'},
        {TeamName : 'Enterprise Sales', DepartmentName : 'Sales'}
    ],
    departmentNames = [];


members.forEach(function (member) {
    allMembers.push(member);
});
//create teams
memberTeamMappings.forEach(function (mapping) {
    if (teamNames.indexOf(mapping.TeamName) === -1) {
        teamNames.push(mapping.TeamName);
    }
});
departmentTeamMappings.forEach(function (mapping) {
    if (departmentNames.indexOf(mapping.DepartmentName) === -1) {
        departmentNames.push(mapping.DepartmentName);
    }
});

teamNames.forEach(function (teamName) {
    var team = {
            hgId : teamIds[i],
            Name : teamName,
            GroupId : groupId,
            GroupName : groupName,
            Description : teamName,
            IsPublic : true,
            OwnerId : ownerId,
            OwnerFullName : ownerFullName,
            Status : 'Active',
            Type : 'Pod',
            ChildTeams : [],
            TeamMembers : [],
            CreatedBy : '1d33b360-9cd9-11e2-ba5b-8bde9b7bbcde',
            ModifiedBy : '1d33b360-9cd9-11e2-ba5b-8bde9b7bbcde',
            CreatedDate : new Date().getTime(),
            ModifiedDate : new Date().getTime()
        },
        mappingsByTeamName = memberTeamMappings.filter(function (mapping) {
            return mapping.TeamName === teamName;
        });
    if (team.Name === 'Executives') {
        team.Type = 'Department';
    }

    mappingsByTeamName.forEach(function (mapping) {
        var member = allMembers.filter(function (m) {
                return m.FullName === mapping.MemberName;
            });
        if (member && member.length === 1) {
            team.TeamMembers.push({
                MemberId : member[0].hgId,
                MemberFullName : member[0].FullName,
                TeamId : teamIds[i]
            });
        }
    });
    i += 1;
    db.Team.insert(team);
    teams.push(team);
});

//create departments
i += 1;
departmentNames.forEach(function (departmentName) {
    var department = {
            hgId : teamIds[i],
            Name : departmentName,
            GroupId : groupId,
            GroupName : groupName,
            Description : departmentName,
            IsPublic : true,
            OwnerId : ownerId,
            OwnerFullName : ownerFullName,
            Status : 'Active',
            Type : 'Department',
            ChildTeams : [],
            TeamMembers : [],
            CreatedBy : '1d33b360-9cd9-11e2-ba5b-8bde9b7bbcde',
            ModifiedBy : '1d33b360-9cd9-11e2-ba5b-8bde9b7bbcde',
            CreatedDate : new Date().getTime(),
            ModifiedDate : new Date().getTime()
        },
        mappingsByDepartmentName = departmentTeamMappings.filter(function (mapping) {
            return mapping.DepartmentName === departmentName;
        });

    mappingsByDepartmentName.forEach(function (mapping) {
        var team = teams.filter(function (t) {
                return t.Name === mapping.TeamName;
            });
        if (team && team.length === 1) {
            department.ChildTeams.push({
                TeamId : team[0].hgId,
                TeamName : team[0].Name
            });
            team[0].TeamMembers.forEach(function (teamMember) {
                department.TeamMembers.push(teamMember);
            });
        }
    });
    i += 1;
    db.Team.insert(department);
});

function getDepartmentNameForMember(member) {
    var memberTeamMapping = memberTeamMappings.filter(function (mapping) {
            return mapping.MemberName === member.FullName;
        }),
        departmentTeamMapping;
    if (!memberTeamMapping || memberTeamMapping.length < 1) {
        return null;
    }
    if (memberTeamMapping[0].TeamName === 'Executives') {
        return memberTeamMapping[0].TeamName;
    }
    departmentTeamMapping = departmentTeamMappings.filter(function (mapping) {
        return mapping.TeamName === memberTeamMapping[0].TeamName;
    });
    if (!departmentTeamMapping || departmentTeamMapping.length < 1) {
        return null;
    }
    return departmentTeamMapping[0].DepartmentName;
}
//update each member's DepartmentName
allMembers.forEach(function (member) {
    var departmentName = getDepartmentNameForMember(member);
    if (departmentName) {
        db.Member.update({hgId: member.hgId}, {$set : {GroupDepartmentName : departmentName}});
    }
});

// update all Echo members to weekly recap
var echoGroup = db.Group.findOne({GroupName:"Echo Global Logistics"});
if (echoGroup && echoGroup.hgId) {
    db.Member.update({GroupId:echoGroup.hgId},{$set:{"Preference.RecapType":"Weekly"}},{multi:true});
}
