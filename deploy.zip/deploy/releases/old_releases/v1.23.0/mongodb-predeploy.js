load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

// set UserId of the Manager in the Member object
db.Member.find().forEach(
    function (member) {
        hgId = member.hgId;
        if (member.MyManagers && member.MyManagers.length > 0) {
            var managers = [];
            if (member.MyManagers[0].MemberId === member.MyManagers[0].UserId) {
                user = db.Member.findOne({'hgId' : member.MyManagers[0].MemberId}, {'UserId' : true});
                if (user) {
                    managers.push({
                        MemberId : member.MyManagers[0].MemberId,
                        FullName : member.MyManagers[0].FullName,
                        UserId : user.UserId
                    });
                }
                // print(managers);
                db.Member.update({'hgId' : hgId}, {$set : {'MyManagers' : managers}});
            }
        }
    }
);
