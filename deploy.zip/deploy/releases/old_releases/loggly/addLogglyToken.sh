#!/usr/bin/env bash

##ATTENTION: DO NOT RUN THIS ENTIRE SCRIPT
##UNCOMMENT THE LINES FOR THE SPECIFIC ENV, THEN RUN SCRIPT

##dev
#heroku config:set --app hgndev LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##poc
#heroku config:set --app hgnpoc LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgapipoc LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbpoc LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##tron
#heroku config:set --app hgntron LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgapitron LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbtron LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##borg
#heroku config:set --app hgnborg LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgmoborg LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbborg LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##cylon
#heroku config:set --app hgncylon LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbcylon LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##ripley
#heroku config:set --app hgnripley LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbripley LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##scully
#heroku config:set --app hgnscully LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbscully LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##trinity
#heroku config:set --app hgnscully LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbscully LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##qa
#heroku config:set --app hgnqa LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgapiqa LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgmoqa LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbqa LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##uat
#heroku config:set --app hgnuat LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgapiuat LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgmouat LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbuat LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##stage
#heroku config:set --app hgnst LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgapist LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgmost LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbst LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##demo
#heroku config:set --app hgndemo LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgapidemo LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgmodemo LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbdemo LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#
##prod
#heroku config:set --app hgnprod LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgapiprod LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgmoprod LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
#heroku config:set --app hgesbprod LOGGLY_TOKEN=62ec2082-4104-458d-ae7f-3d44cd7ce1b2
