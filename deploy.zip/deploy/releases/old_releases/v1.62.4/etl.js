load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgreports");
// remove bad data
// needs full re-migration
db.MetricsCoaching.remove({ t : NaN})