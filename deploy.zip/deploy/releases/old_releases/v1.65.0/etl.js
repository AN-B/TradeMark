load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

var mappings = [
        {sfEmail : 'shane.armstrong@ama-assn.org ', hgEmail : 'sarmstrong@acquirent.com'},
        {sfEmail : 'marlon.bracamontes@ama-assn.org', hgEmail : 'mbracamontes@acquirent.com'},
        {sfEmail : 'cbriscoe2@humana.com', hgEmail : 'cbriscoe@acquirent.com'},
        {sfEmail : 'Chris.carr@transworldsystems.com', hgEmail : 'ccarr@acquirent.com'},
        {sfEmail : 'Rob.fishman@transworldsystems.com', hgEmail : 'rfishman@acquirent.com'},
        {sfEmail : 'jkeeney1@humana.com', hgEmail : 'jkeeney@acquirent.com'},
        {sfEmail : 'Jack.mccarthy@ama-assn.org', hgEmail : 'jmccarthy@acquirent.com'},
        {sfEmail : 'Jeffrey.michaels@ama-assn.org', hgEmail : 'jmichaels@acquirent.com'},
        {sfEmail : 'nicholas.morici@ama-assn.org', hgEmail : 'nmorici@acquirent.com'},
        {sfEmail : 'willie.sellers@ama-assn.org', hgEmail : 'wsellers@acquirent.com'},
        {sfEmail : 'jbishopp@highground.com', hgEmail : 'jordan@highground.com​'}
    ];

mappings.forEach(function (mapping) {
    var userInfo = db.UserInfo.findOne({'UserPersonal.PrimaryEmail' : mapping.hgEmail});
    if (userInfo) {
        var userId = userInfo.hgId,
        member = db.Member.findOne({UserId : userId});
        if (member && member.FullName) { //make sure the member is mapped correctly
            var integration = {
                Application : 'SalesForce',
                UserEmail : mapping.sfEmail
            };
            db.Member.update({UserId : userId}, {$addToSet : {Integration : integration}});
        }
        print(mapping.hgEmail + '  ' + userInfo.UserName + '  ' + member.FullName);
    } else {
        print('user does not exist:' + mapping.hgEmail);
    }
});

// Move Conversation collection from hgcommon to hgthanka
switchDB("hgcommon");

var conversations = db.Conversation.find({});
var groupId =  db.Group.findOne({GroupName : 'Mercury Industries'}).hgId;

switchDB("hgthanka");
// Add Conversation indexes
db.Conversation.ensureIndex( { BatchId : 1} );
db.Conversation.ensureIndex( { BatchId : 1, 'Creator.MemberId' : 1, Status : 1 } );
db.Conversation.ensureIndex( { BatchId : 1, 'Recipient.MemberId' : 1, Status : 1 } );
db.Conversation.ensureIndex( { BatchId : 1, 'Creator.MemberId' : 1,  'Recipient.MemberId' : 1, Status : 1 } );

// save collection data
conversations.forEach(function (item) {
    item.Source = 'Web';
    item.GroupId = groupId; // Mercury Industry
    item.FeedBackType = (item.Status === 'Active') ? 'Given' : 'Requested';
    db.Conversation.insert(item);   
});

/*
switchDB("hgreports");
// Add MetricsFeedBack indexes
db.MetricsFeedBack.ensureIndex( { g : 1, c : 1 } );

db.MetricsFeedBack.ensureIndex( { p : 1, g : 1, c : 1, s : 1 } );
*/
