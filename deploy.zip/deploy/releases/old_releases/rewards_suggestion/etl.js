load('../../db-scripts/commonDB.js');
setEnv("local");


//Below is script for the "rewards suggestion submitted by" feature
switchDB('hgperka');

var items = db.ProductItem.find({'Status' : 'ApprovalPending'}),
    user;

if (items) {
    items.forEach(function (item) {
        if(item.hasOwnProperty('hgId') && item.hasOwnProperty('CreatedBy')) {
            switchDB("hgcommon");
            user = db.UserInfo.findOne({'hgId': item.CreatedBy});
            switchDB("hgperka");
            db.ProductItem.update({hgId: item.hgId}, {
                $set: {
                    'SuggestedBy': {
                        FullName: user.UserPersonal.FullName,
                        Email: user.UserPersonal.PrimaryEmail || user.UserName
                    }
                }
            });
        }
    });
}