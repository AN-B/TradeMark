load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Group.update({'HGAccountId' : 'HG20140002'}, {$addToSet :
    {'Preference.FeatureFlags' : {
        "FeatureName" : "DisableFeatureByRole",
        "FeatureMeta" : [ 
            {
                "Name" : "Roles",
                "Value" : "OffBoarded,Employee,Manager,Executive,Owner,Admin"
            },
            {
                "Name" : "Permissions",
                "Value" : "recognizeTabs.trophyRoom,recognizeTabs.feeds,recognizeTabs.giveRecognition,recognizeTabs.badges,recognizeTabs.sendCredits,recognizeTabs.shareLink,recognizeTabs.hideRecognition,recognizeTabs.deleteFeedEntry,motivateTabs.store,motivateTabs.charities,motivateTabs.disabled,motivateTabs.noXpStore,motivateTabs.giftCards,motivateTabs.xpStore,motivateTabs.group,motivateTabs.charitiesButton,userTabs.recognizeMeLinks"
            }
        ],
        "FeatureEnabled" : true
    }
}});

db.Group.update({'HGAccountId' : 'HG20140002'}, {$addToSet :
    {'Preference.FeatureFlags' : {
        "FeatureName" : "EnablePerform",
        "FeatureEnabled" : true
    }
}});


//script 2: set Rightpoint users' WelcomeBadgePending to be true so that they don't get it when they log in
var groupId = db.Group.findOne({'HGAccountId' : 'HG20140002'}).hgId;
db.UserInfo.update({'Preference.DefaultGroupId' : groupId}, {$set : {'Flags.WelcomeBadgePending' : false}}, {multi : true});
