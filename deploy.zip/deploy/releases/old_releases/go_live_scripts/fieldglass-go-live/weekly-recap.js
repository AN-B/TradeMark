load("../../db-scripts/commonDB.js");
setEnv("local");

// set the weekly daily recap to Wednesday for Allianz
switchDB("hgcommon");
group = db.Group.findOne({GroupName:"Fieldglass"});
if (group && group.hgId) {
    db.Group.update({hgId:group.hgId},{$set:{"Preference.WeeklyRecapEnabled":true, "Preference.WeeklyRecapDay":"Monday"}});
    db.Member.update({'GroupId' : group.hgId}, {$set : {'Preference.RecapType' : 'Weekly'}}, {multi : true});
}
