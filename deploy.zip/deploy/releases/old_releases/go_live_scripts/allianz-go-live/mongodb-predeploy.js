load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

//the folloing scripts are to be run after provisioning svc/Provision/OnboardCustomer/allianz-develop-provision.xlsx

//script 1: add reference number setting for Allianz
db.Group.update({'HGAccountId' : 'HG20140001'}, {$set :
    {'Preference.ReferenceNumberTypes' : [ {
        EntityName : 'Transaction',
        Name : 'GLAccount',
        Resolver : 'GetGLAccount'
    }]}});

//script 2: set Allianz users' WelcomeBadgePending to be true so that they don't get it when they log in
var groupId = db.Group.findOne({'HGAccountId' : 'HG20140001'}).hgId;
db.UserInfo.update({'Preference.DefaultGroupId' : groupId}, {$set : {'Flags.WelcomeBadgePending' : false}}, {multi : true});

// script to suppress birthdays for everyone
group=db.Group.findOne({GroupName:'Allianz'});
usersArray=[];
if (group && group.hgId) {
    db.Member.find({GroupId:group.hgId},{_id:0,UserId:1}).forEach(function(member){
        usersArray.push(member.UserId);
    });
    db.UserInfo.update({hgId:{$in:usersArray}},{$set:{'Preference.SuppressBirthday':true}},{multi:true});
}
