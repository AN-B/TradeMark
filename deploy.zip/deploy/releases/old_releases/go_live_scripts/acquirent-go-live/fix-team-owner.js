// set the team owner for Acquirent teams to Courtney Privitera
group=db.Group.findOne({GroupName:"Acquirent"});
if (group && group.hgId) {
    owner=db.Member.findOne({GroupId:group.hgId,LastName:"Privitera"});
    if (owner && owner.hgId) {
        db.Team.update({GroupId:group.hgId,OwnerId:""},{$set:{OwnerId:owner.hgId,OwnerFullName:owner.FullName}},{multi:true});
    }
}