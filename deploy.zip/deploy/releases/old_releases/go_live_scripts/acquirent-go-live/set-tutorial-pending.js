group=db.Group.findOne({GroupName:"Acquirent"});
if (group && group.hgId) {
    db.UserInfo.update({"Preference.DefaultGroupId":group.hgId},{$set:{"Flags.TutorialPending": true}},{multi:true});
}
