// this script should transfer credits from the SPND account of one user to the TRFR account of another user
load("../../db-scripts/commonDB.js");
setEnv("local");


// set up initial parameters
groupName="[GROUP_NAME_HERE]";
srcUser="[FULL_NAME_HERE]";
dstUser="[FULL_NAME_HERE]";
amount=0;
// guids have to come from the target environment -- /svc/Provision/GenerateGuids/3
newGuids=[];
theTimestamp=(new Date()).getTime();

switchDB("hgcommon");

// get the group record
group=db.Group.findOne({GroupName:groupName});
if(group && group.hgId && newGuids.length == 3){
    // get both member records
    srcUserRecord=db.Member.findOne({GroupId:group.hgId,FullName:srcUser});
    dstUserRecord=db.Member.findOne({GroupId:group.hgId,FullName:dstUser});
    if(srcUserRecord && srcUserRecord.UserId && dstUserRecord && dstUserRecord.hgId){
        // get two transaction ids (friendly integer ids) - one for debit and one for credit
        debitId=db.FriendlyId.findAndModify({query:{EntityName:"Transaction"},update:{$inc:{FriendlyIdValue:1}},new:true});
        creditId=db.FriendlyId.findAndModify({query:{EntityName:"Transaction"},update:{$inc:{FriendlyIdValue:1}},new:true});
        if(debitId && debitId.FriendlyIdValue && creditId && creditId.FriendlyIdValue){
            switchDB("hgfinance");

            // find the actual credit account that will be debited and credited
            spendAcct=db.CreditAccount.findOne({AccountType:"SPND",OwnerId:srcUserRecord.UserId});
            transAcct=db.CreditAccount.findOne({AccountType:"TRFR",OwnerId:dstUserRecord.hgId});
            if(spendAcct && spendAcct.hgId && transAcct && transAcct.hgId){
                // store the original balances
                origSpendBalance=spendAcct.Balance;
                origTransBalance=transAcct.Balance;
                // print out the balance for both
                print(srcUserRecord.FullName+':'+origSpendBalance);
                print(dstUserRecord.FullName+':'+origTransBalance);
                // decrease source by amount
                db.CreditAccount.findAndModify({query:{hgId:spendAcct.hgId},update:{$inc:{Balance:amount*-1}}});
                // increase destination by amount
                db.CreditAccount.findAndModify({query:{hgId:transAcct.hgId},update:{$inc:{Balance:amount}}});
                // insert a transaction record for the debit
                db.Transaction.insert({
                    ModifiedDate: theTimestamp,
                    ModifiedBy: srcUserRecord.UserId,
                    CreatedDate: theTimestamp,
                    CreatedBy: srcUserRecord.UserId,
                    hgId: newGuids[1],
                    FriendlyId: debitId.FriendlyIdValue,
                    ReferenceId: newGuids[0],
                    RowVersion: 1,
                    CreditQuantity: amount*-1,
                    Info: "Debited " + amount + " credits from " + srcUserRecord.FullName + " (SPND acct). Transfer to " + dstUserRecord.FullName + " (TRFR acct).",
                    Status: "Complete",
                    Type: "Transfer",
                    UserName: srcUserRecord.FullName,
                    UserId: srcUserRecord.UserId,
                    GroupName: group.GroupName,
                    GroupId: group.hgId,
                    AccountId: spendAcct.hgId
                });
                // insert a transaction record for the credit
                db.Transaction.insert({
                    ModifiedDate: theTimestamp,
                    ModifiedBy: dstUserRecord.UserId,
                    CreatedDate: theTimestamp,
                    CreatedBy: dstUserRecord.UserId,
                    hgId: newGuids[2],
                    FriendlyId: creditId.FriendlyIdValue,
                    ReferenceId: newGuids[0],
                    RowVersion: 1,
                    CreditQuantity: amount,
                    Info: "Credited " + amount + " credits to " + dstUserRecord.FullName + " (TRFR acct). Transfer from " + srcUserRecord.FullName + " (SPND acct).",
                    Status: "Complete",
                    Type: "Transfer",
                    UserName: dstUserRecord.FullName,
                    UserId: dstUserRecord.UserId,
                    GroupName: group.GroupName,
                    GroupId: group.hgId,
                    AccountId: transAcct.hgId
                });
                // read the credit account back and check if the values are different
                spendAcct=db.CreditAccount.findOne({AccountType:"SPND",OwnerId:srcUserRecord.UserId});
                transAcct=db.CreditAccount.findOne({AccountType:"TRFR",OwnerId:dstUserRecord.hgId});
                // print out the balance for both
                print(srcUserRecord.FullName+':'+origSpendBalance+'-->'+spendAcct.Balance);
                print(dstUserRecord.FullName+':'+origTransBalance+'-->'+transAcct.Balance);
                if(origSpendBalance==spendAcct.Balance||origTransBalance==transAcct.Balance){
                    print('Error: Nothing changed!');
                }else{
                    print('Successfully transferred credits.');
                }
            } else {
                print('Error: Credit accounts not found.');
            }
        } else {
            print('Error: Could not produce friendly ids.');
        }
    } else {
        print('Error: Members not found.');
    }
} else {
    print('Error: Group not found or 3 GUIDs were not created.');
}
