// this script pulls the credits to give report for all users
load("../../db-scripts/commonDB.js");
setEnv("prod");

switchDB("hgcommon");

groupName="Acquirent";
memberArray={};
group=db.Group.findOne({GroupName:groupName});
if (group && group.hgId) {
    members=db.Member.find({GroupId:group.hgId,RolesInGroup:{$nin:['HGAdmin','OffBoarded']}});
    if (members && members.length) {
        members.forEach(function (mem) {
            memberArray[mem.hgId] = {
                FullName:mem.FullName
            };
        });
        switchDB("hgfinance");
        trans=db.CreditAccount.find({AccountType:'TRFR',OwnerId:{$in:Object.keys(memberArray)}});
        if (trans && trans.length) {
            trans.forEach(function (x) {
                print(memberArray[x.OwnerId].FullName + ': ' + x.Balance);
            })
        }
    }
}
