#!/bin/sh

# this will loop through all lines in the emps.txt file, split on colon for src and dest file names and rename them locally
# emps.txt contains the mapping of the names to guids delimited by colon
# example: John_Smith.jpg:0b2ead20-77d3-11e3-8797-5b2b8d4af8a4.jpg
while read n
do
IFS=:
set $n
mv "$1" "$2"
done < emps.txt
