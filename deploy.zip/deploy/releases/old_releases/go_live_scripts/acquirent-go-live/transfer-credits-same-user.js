// this script should transfer credits from one type of account to another when a user accidentally purchases credits for the wrong type
load("../../db-scripts/commonDB.js");
setEnv("prod");

switchDB("hgcommon");

groupName="Acquirent";
userName="ldegliantoni@acquirent.com";
srcAccount="SPND";
dstAccount="TRFR";
amount=200;
newTransactionId="76e8ab00-981d-11e3-83ed-61b896a3abf6";
theTimestamp=(new Date()).getTime();
group=db.Group.findOne({GroupName:groupName});
user=db.UserInfo.findOne({UserName:userName});
if (group && group.hgId && user && user.hgId && newTransactionId !== "????") {
    member=db.Member.findOne({GroupId:group.hgId,UserId:user.hgId});
    if (member && member.hgId) {
        friendlyId=db.FriendlyId.findAndModify({query:{EntityName:"Transaction"},update:{$inc:{FriendlyIdValue:1}},new:true});
        if (friendlyId && friendlyId.FriendlyIdValue) {
            switchDB("hgfinance");

            srcId=srcAccount==="SPND"?user.hgId:member.hgId;
            dstId=dstAccount==="TRFR"?member.hgId:user.hgId;
            src=db.CreditAccount.findOne({AccountType:srcAccount,OwnerId:srcId});
            dst=db.CreditAccount.findOne({AccountType:dstAccount,OwnerId:dstId});
            if (src && src.hgId && dst && dst.hgId) {
                // descrease source by amount
                db.CreditAccount.findAndModify({query:{hgId:src.hgId},update:{$inc:{Balance:amount*-1}}});
                // increase destination by amount
                db.CreditAccount.findAndModify({query:{hgId:dst.hgId},update:{$inc:{Balance:amount}}});
                // insert a transaction record
                db.Transaction.insert({
                    ModifiedDate: theTimestamp,
                    ModifiedBy: user.hgId,
                    CreatedDate: theTimestamp,
                    CreatedBy: user.hgId,
                    hgId: newTransactionId,
                    FriendlyId: friendlyId.FriendlyIdValue,
                    RowVersion: 1,
                    CreditQuantity: amount,
                    Info: member.FullName + " transferred " + amount + " credits from " + srcAccount + " to " + dstAccount + ".",
                    Status: "Complete",
                    Type: "Transfer",
                    UserName: member.FullName,
                    UserId: user.hgId,
                    GroupName: group.GroupName,
                    GroupId: group.hgId,
                    AccountId: src.hgId
                });
            }
        }
    }
}