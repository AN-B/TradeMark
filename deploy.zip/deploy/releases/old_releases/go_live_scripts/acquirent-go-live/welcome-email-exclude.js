members=db.Member.aggregate({$match:{"FullName":{$in:["Ryan Morehouse","Jon Elhardt","Nathan Blackburn","Nick Hogren","Kristen Schlenz","Shelli Anderson","Jeffrey Purtell","Lisa Degliantoni"]}}},{$project:{_id:0,hgId:1,FullName:1}}).result;
memberIds=[];
for(i=0;i<members.length;i++){memberIds.push(members[i].hgId);}
//db.ProvisionActivity.find({BatchId:"f7678580-8f71-11e3-83de-21f00c0936e3",Type:"MemberAdded",EntityValue:{$in:memberIds}},{_id:0,Summary:1,Notification:1});
db.ProvisionActivity.update({BatchId:"f7678580-8f71-11e3-83de-21f00c0936e3",Type:"MemberAdded",EntityValue:{$in:memberIds}},{$set:{Notification:"Sent"}},{multi:true});
db.ProvisionActivity.count({BatchId:"f7678580-8f71-11e3-83de-21f00c0936e3",Type:"MemberAdded",Notification:"Sent"});
