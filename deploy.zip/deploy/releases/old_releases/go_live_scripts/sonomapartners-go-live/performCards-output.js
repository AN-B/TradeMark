cards=[
    {
        "CreatedBy" : "dd561280-410e-11e3-bf1d-db7d183b4747",
        "CreatedDate" : 1386782824885,
        "Description" : "Project-based Feedback for Developers",
        "ExpireDate" : 1418318824901,
        "GroupId" : "fc5ea5c0-626f-11e3-a86e-d10290e48d36",
        "GroupName" : "Sonoma Partners",
        "IsTemplate" : false,
        "ModifiedBy" : "2e4a2b70-8ebe-11e3-b99c-8feca8d40e33",
        "ModifiedDate" : 1393353781376,
        "OriginalId" : "74179130-6289-11e3-9338-31c787f5f5ee",
        "PeopleTypes" : [
            {
                "_id" : "52a8a0685e5e5809000003ab",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Manager"
            },
            {
                "_id" : "52a8a0685e5e5809000003aa",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : false,
                "PeopleTypeName" : "Subject"
            },
            {
                "_id" : "52a8a0685e5e5809000003a9",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Peer"
            }
        ],
        "Sections" : [
            {
                "_id" : "530ce435534b940500aae33c",
                "ModifiedDate" : 1393353781283,
                "ModifiedBy" : "",
                "CreatedDate" : 1393353781283,
                "CreatedBy" : "",
                "hgId" : "fb244c71-7f78-11e3-b0ed-a70f560364d2",
                "Questions" : [
                    {
                        "_id" : "530ce435534b940500aae330",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781349,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781349,
                        "CreatedBy" : "",
                        "hgId" : "fb244c72-7f78-11e3-b0ed-a70f560364d2",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf625090000031c",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf625090000031b",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf625090000031a",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000319",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Work well with team members (offered to help others complete items,committed code frequently, adhered to project-specific process, etc.)?"
                    },
                    {
                        "_id" : "530ce435534b940500aae331",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781348,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781348,
                        "CreatedBy" : "",
                        "hgId" : "c377bb10-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf6250900000318",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000317",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000316",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000315",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Understand the customer's needs to ensure the right problems were solved in the right way (questioned requirements when appropriate and demonstrated forethought into how the system would actually be used)?"
                    },
                    {
                        "_id" : "530ce435534b940500aae332",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781348,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781348,
                        "CreatedBy" : "",
                        "hgId" : "c377bb11-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf6250900000314",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000313",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000312",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000311",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Proactively communicate status, delays, challenges and/or potential perf problems in a timely manner?"
                    },
                    {
                        "_id" : "530ce435534b940500aae333",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781347,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781347,
                        "CreatedBy" : "",
                        "hgId" : "c377bb12-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf6250900000310",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf625090000030f",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf625090000030e",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf625090000030d",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 4,
                        "QuestionText" : "Do what it takes to get the job done, included working late or on weekends when necessary?"
                    },
                    {
                        "_id" : "530ce435534b940500aae334",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781288,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781288,
                        "CreatedBy" : "",
                        "hgId" : "c377bb13-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf625090000030c",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf625090000030b",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf625090000030a",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000309",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 5,
                        "QuestionText" : "Handle item complexity equivalent with their role?"
                    },
                    {
                        "_id" : "530ce435534b940500aae335",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781287,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781287,
                        "CreatedBy" : "",
                        "hgId" : "c377e220-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf6250900000308",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000307",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000306",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000305",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 6,
                        "QuestionText" : "Complete items within agreed upon estimates and deadlines?"
                    },
                    {
                        "_id" : "530ce435534b940500aae336",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781287,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781287,
                        "CreatedBy" : "",
                        "hgId" : "c377e221-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf6250900000304",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000303",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000302",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf6250900000301",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 7,
                        "QuestionText" : "Spend an appropriate amount of time seeking solutions on their own before asking for help and then apply the help effectively?"
                    },
                    {
                        "_id" : "530ce435534b940500aae337",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781286,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781286,
                        "CreatedBy" : "",
                        "hgId" : "c377e222-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf6250900000300",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002ff",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002fe",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002fd",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 8,
                        "QuestionText" : "Write respectful and explainable code (problems were solved efficiently, follows Sonoma standards and it's clear such that others can maintain it later)?"
                    },
                    {
                        "_id" : "530ce435534b940500aae338",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781285,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781285,
                        "CreatedBy" : "",
                        "hgId" : "c377e223-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf62509000002fc",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002fb",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002fa",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002f9",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 9,
                        "QuestionText" : "Balance multiple projects and effectively prioritize project work?"
                    },
                    {
                        "_id" : "530ce435534b940500aae339",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781284,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781284,
                        "CreatedBy" : "",
                        "hgId" : "c377e224-8eb7-11e3-a204-214a6ae2bd03",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40a1dfbf62509000002f8",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002f7",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002f6",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40a1dfbf62509000002f5",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 10,
                        "QuestionText" : "Conduct good QA (tested code to make sure it works before going to QA and had complex code reviewed)?"
                    },
                    {
                        "_id" : "530ce435534b940500aae32f",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781284,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781284,
                        "CreatedBy" : "",
                        "hgId" : "fb247387-7f78-11e3-b0ed-a70f560364d2",
                        "Answers" : [],
                        "AnswerSelectors" : [],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 11,
                        "QuestionText" : "Please use the space below to provide additional feedback."
                    },
                    {
                        "_id" : "530ce435534b940500aae33a",
                        "QuestionHelp" : "By entering your name, the reviewee will know which feedback is yours.",
                        "ModifiedDate" : 1393353781283,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781283,
                        "CreatedBy" : "",
                        "hgId" : "3b45d0b0-9a4c-11e3-b137-f1aadcbcfff5",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53062d83e5385d050090bbfa",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "ShortText",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : true,
                        "SortOrder" : 12,
                        "QuestionText" : "Enter your name here:"
                    }
                ],
                "SortOrder" : 1,
                "Description" : "",
                "Title" : "To what extent did the Developer..."
            },
            {
                "_id" : "530ce435534b940500aae33d",
                "ModifiedDate" : 1393353781281,
                "ModifiedBy" : "",
                "CreatedDate" : 1393353781281,
                "CreatedBy" : "",
                "hgId" : "a75a1a50-9e4c-11e3-9cce-a352a6748d57",
                "Questions" : [
                    {
                        "_id" : "530ce435534b940500aae33b",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1393353781281,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1393353781281,
                        "CreatedBy" : "",
                        "hgId" : "fb247388-7f78-11e3-b0ed-a70f560364d2",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d92b28cc9c8a0500000078",
                                "Text" : "Reviewed by Coach",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "CheckBox",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Coach Review is complete and ready to send to Reviewee"
                    }
                ],
                "SortOrder" : 2,
                "Description" : "Acknowledgement that review is ready to share",
                "Title" : "Coach Review"
            }
        ],
        "Status" : "ReadyToAssign",
        "SubjectManagerOnly" : false,
        "Title" : "Developer",
        "Type" : "Project",
        "__v" : 6,
        "_id" : "52d92c2dcc9c8a050000008d",
        "hgId" : "fb244c70-7f78-11e3-b0ed-a70f560364d2"
    },
    {
        "CreatedBy" : "dd561280-410e-11e3-bf1d-db7d183b4747",
        "CreatedDate" : 1386782824885,
        "Description" : "Project-based Feedback for Tech Leads",
        "ExpireDate" : 1418318824901,
        "GroupId" : "fc5ea5c0-626f-11e3-a86e-d10290e48d36",
        "GroupName" : "Sonoma Partners",
        "IsTemplate" : false,
        "ModifiedBy" : "fc68def0-626f-11e3-a86e-d10290e48d36",
        "ModifiedDate" : 1392914019824,
        "OriginalId" : "fb244c70-7f78-11e3-b0ed-a70f560364d2",
        "PeopleTypes" : [
            {
                "_id" : "52a8a0685e5e5809000003ab",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Manager"
            },
            {
                "_id" : "52a8a0685e5e5809000003aa",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : false,
                "PeopleTypeName" : "Subject"
            },
            {
                "_id" : "52a8a0685e5e5809000003a9",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Peer"
            }
        ],
        "Sections" : [
            {
                "_id" : "53062e63ea3f1a0600298bd5",
                "ModifiedDate" : 1392914019783,
                "ModifiedBy" : "",
                "CreatedDate" : 1392914019783,
                "CreatedBy" : "",
                "hgId" : "c9b37eb1-8eb7-11e3-b99c-8feca8d40e33",
                "Questions" : [
                    {
                        "_id" : "53062e63ea3f1a0600298bcb",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019794,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019794,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c0-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f90700000337",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f90700000336",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f90700000335",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f90700000334",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Set and abide by deadlines and estimates?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bcc",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019794,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019794,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c1-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f90700000333",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f90700000332",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f90700000331",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f90700000330",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Write quality items, design documentation and release notes?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bcd",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019792,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019792,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c2-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f9070000032f",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f9070000032e",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f9070000032d",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f9070000032c",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Distribute interesting work and not keep the all difficult challenges for him/herself?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bce",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019790,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019790,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c3-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f9070000032b",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f9070000032a",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f90700000329",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f90700000328",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 4,
                        "QuestionText" : "Demonstrate expertise at developing for and customizing CRM/SFDC?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bcf",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019789,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019789,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c4-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f90700000327",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f90700000326",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f90700000325",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f90700000324",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 5,
                        "QuestionText" : "Offer solutions to client problems instead of just taking tasks?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bd0",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019788,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019788,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c5-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f90700000323",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f90700000322",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f90700000321",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f90700000320",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 6,
                        "QuestionText" : "Speak up/participate during client meetings?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bd1",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019787,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019787,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c6-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f9070000031f",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f9070000031e",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f9070000031d",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f9070000031c",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 7,
                        "QuestionText" : "Present a united front with the Project Manager (to both the client and Sonoman project team members)?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bd2",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019786,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019786,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5c7-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f4133af754f9070000031b",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f4133af754f9070000031a",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f4133af754f90700000319",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f4133af754f90700000318",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 8,
                        "QuestionText" : "Communicate what he/she will do and follow through?"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bca",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019786,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019786,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5ca-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 9,
                        "QuestionText" : "Please use the space below to provide additional feedback."
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bd3",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392914019785,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019785,
                        "CreatedBy" : "",
                        "hgId" : "c9b3a5cb-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d92b28cc9c8a0500000078",
                                "Text" : "Reviewed by Coach",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "CheckBox",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 10,
                        "QuestionText" : "Coach Review is complete and ready to send to Reviewee"
                    },
                    {
                        "_id" : "53062e63ea3f1a0600298bd4",
                        "QuestionHelp" : "By entering your name, the reviewee will know which feedback is yours.",
                        "ModifiedDate" : 1392914019783,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392914019783,
                        "CreatedBy" : "",
                        "hgId" : "c10aa860-9a4c-11e3-9644-49b148081fc6",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53062e63cadc7b0600e7d1dd",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "ShortText",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 11,
                        "QuestionText" : "Enter your name here:"
                    }
                ],
                "SortOrder" : 1,
                "Description" : "",
                "Title" : "To what extent did the Tech Lead..."
            }
        ],
        "Status" : "ReadyToAssign",
        "SubjectManagerOnly" : false,
        "Title" : "Tech Lead",
        "Type" : "Project",
        "__v" : 5,
        "_id" : "52f2c000d6b9a6050000040c",
        "hgId" : "c9b37eb0-8eb7-11e3-b99c-8feca8d40e33"
    },
    {
        "CreatedBy" : "dd561280-410e-11e3-bf1d-db7d183b4747",
        "CreatedDate" : 1386782824885,
        "Description" : "Project-based Feedback for QA",
        "ExpireDate" : 1418318824901,
        "GroupId" : "fc5ea5c0-626f-11e3-a86e-d10290e48d36",
        "GroupName" : "Sonoma Partners",
        "IsTemplate" : false,
        "ModifiedBy" : "fc68def0-626f-11e3-a86e-d10290e48d36",
        "ModifiedDate" : 1392913960858,
        "OriginalId" : "fb244c70-7f78-11e3-b0ed-a70f560364d2",
        "PeopleTypes" : [
            {
                "_id" : "52a8a0685e5e5809000003ab",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Manager"
            },
            {
                "_id" : "52a8a0685e5e5809000003aa",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : false,
                "PeopleTypeName" : "Subject"
            },
            {
                "_id" : "52a8a0685e5e5809000003a9",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Peer"
            }
        ],
        "Sections" : [
            {
                "_id" : "53062e28ea3f1a0600298bc8",
                "ModifiedDate" : 1392913960654,
                "ModifiedBy" : "",
                "CreatedDate" : 1392913960654,
                "CreatedBy" : "",
                "hgId" : "cddd0421-8eb7-11e3-b99c-8feca8d40e33",
                "Questions" : [
                    {
                        "_id" : "53062e28ea3f1a0600298bbd",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960696,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960696,
                        "CreatedBy" : "",
                        "hgId" : "cddd0422-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c7060000072b",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c7060000072a",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c70600000729",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c70600000728",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Test beyond what's on the test plan and/or in the functional spec (e.g. think of alternate flows, exercise destructive type thinking)?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bbe",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960694,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960694,
                        "CreatedBy" : "",
                        "hgId" : "cddd0423-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c70600000727",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c70600000726",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c70600000725",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c70600000724",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Identify conflicting or missing requirements and collaborate on solutions?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bbf",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960689,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960689,
                        "CreatedBy" : "",
                        "hgId" : "cddd0424-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c70600000723",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c70600000722",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c70600000721",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c70600000720",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Write detailed, well-written test plans with client usage in mind and update them as needed?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc0",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960686,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960686,
                        "CreatedBy" : "",
                        "hgId" : "cddd0425-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c7060000071f",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c7060000071e",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c7060000071d",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c7060000071c",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 4,
                        "QuestionText" : "Do what it takes to get the job done, included working late or on weekends when necessary?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc1",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960682,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960682,
                        "CreatedBy" : "",
                        "hgId" : "cddd0426-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c7060000071b",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c7060000071a",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c70600000719",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c70600000718",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 5,
                        "QuestionText" : "Work effectively with project team members (e.g. help drive deadlines, schedule test plan reviews and challenge development when appropriate)?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc2",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960678,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960678,
                        "CreatedBy" : "",
                        "hgId" : "cddd0427-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c70600000717",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c70600000716",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c70600000715",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c70600000714",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 6,
                        "QuestionText" : "Capture and write very detailed items/defects (e.g. provide specific examples, steps to reproduce and screen shots where applicable)?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc3",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960675,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960675,
                        "CreatedBy" : "",
                        "hgId" : "cddd0428-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c70600000713",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c70600000712",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c70600000711",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c70600000710",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 7,
                        "QuestionText" : "Work autonomously with minimal direction?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc4",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960670,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960670,
                        "CreatedBy" : "",
                        "hgId" : "cddd0429-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c7060000070f",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c7060000070e",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c7060000070d",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c7060000070c",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 8,
                        "QuestionText" : "Proactively communicate status, delays, challenges and/or risks in a timely manner?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc5",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960666,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960666,
                        "CreatedBy" : "",
                        "hgId" : "cddd042a-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40c8ba946c7060000070b",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40c8ba946c7060000070a",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40c8ba946c70600000709",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40c8ba946c70600000708",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 9,
                        "QuestionText" : "Functionally test the requirements based on the functional spec and supporting documents (e.g. actually log in as each security role instead of just reviewing the security matrix)?"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bbc",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960665,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960664,
                        "CreatedBy" : "",
                        "hgId" : "cddd042c-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 10,
                        "QuestionText" : "Please use the space below to provide additional feedback."
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc6",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913960662,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960662,
                        "CreatedBy" : "",
                        "hgId" : "cddd042d-8eb7-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d92b28cc9c8a0500000078",
                                "Text" : "Reviewed by Coach",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "CheckBox",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 11,
                        "QuestionText" : "Coach Review is complete and ready to send to Reviewee"
                    },
                    {
                        "_id" : "53062e28ea3f1a0600298bc7",
                        "QuestionHelp" : "By entering your name, the reviewee will know which feedback is yours.",
                        "ModifiedDate" : 1392913960655,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913960655,
                        "CreatedBy" : "",
                        "hgId" : "9dddd600-9a4c-11e3-9644-49b148081fc6",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53062e28cadc7b0600e7d1dc",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "ShortText",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 12,
                        "QuestionText" : "Enter your name here:"
                    }
                ],
                "SortOrder" : 1,
                "Description" : "",
                "Title" : "To what extent did the QA..."
            }
        ],
        "Status" : "ReadyToAssign",
        "SubjectManagerOnly" : false,
        "Title" : "QA",
        "Type" : "Project",
        "__v" : 5,
        "_id" : "52f2c007d6b9a60500000411",
        "hgId" : "cddd0420-8eb7-11e3-b99c-8feca8d40e33"
    },
    {
        "CreatedBy" : "fcac9eb0-626f-11e3-a86e-d10290e48d36",
        "CreatedDate" : 1389553007796,
        "Description" : "Project-based Feedback for Project Managers",
        "ExpireDate" : 1421089007798,
        "GroupId" : "fc5ea5c0-626f-11e3-a86e-d10290e48d36",
        "GroupName" : "Sonoma Partners",
        "IsTemplate" : false,
        "ModifiedBy" : "fc68def0-626f-11e3-a86e-d10290e48d36",
        "ModifiedDate" : 1392913881783,
        "OriginalId" : "705b3e60-8468-11e3-bec2-71481195ed0c",
        "PeopleTypes" : [
            {
                "_id" : "52d2e56f326ead0900000045",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Manager"
            },
            {
                "_id" : "52d2e56f326ead0900000044",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : false,
                "PeopleTypeName" : "Subject"
            },
            {
                "_id" : "52d2e56f326ead0900000043",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Peer"
            }
        ],
        "Sections" : [
            {
                "_id" : "53062dd9ea3f1a0600298bba",
                "ModifiedDate" : 1392913881756,
                "ModifiedBy" : "",
                "CreatedDate" : 1392913881756,
                "CreatedBy" : "",
                "hgId" : "6ec345d0-9a4c-11e3-9644-49b148081fc6",
                "Questions" : [
                    {
                        "_id" : "53062dd9ea3f1a0600298bb1",
                        "QuestionHelp" : "•\tIs aware of project goals and sets item deadlines and estimates accordingly.\n•\tMakes development team aware of code complete due date and treats it as a real deadline.\n•\tEffectively conveys technical requirements to development team",
                        "ModifiedDate" : 1392913881764,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881764,
                        "CreatedBy" : "",
                        "hgId" : "525e90f2-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40bc4f754f90700000307",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40bc4f754f90700000306",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40bc4f754f90700000305",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40bc4f754f90700000304",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "To what extent did the Project Manager exhibit \"Be a Good Communicator\"?"
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb2",
                        "QuestionHelp" : "•\tDemonstrates ability to push back on client or team member(s) when needed.\n•\tEffectively aligns/partners with Tech Lead.\n•\tGets the right folks involved / escalates issues appropriately, as needed.\n•\tDemonstrates appropriate sense of urgency/level of responsiveness.\n•\tAdapts well to unforeseen changes in scope/direction.\n•\tDemonstrates a consultative approach (offers solutions beyond being a tasktaker; challenges client and team members appropriately).",
                        "ModifiedDate" : 1392913881763,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881763,
                        "CreatedBy" : "",
                        "hgId" : "525e90f3-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40bc4f754f90700000303",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40bc4f754f90700000302",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40bc4f754f90700000301",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40bc4f754f90700000300",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "To what extent did the Project Manager exhibit \"Think Service First\"?"
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb3",
                        "QuestionHelp" : "•\tPays attention to details.\n•\tProvides client presentable documentation.\n•\tEnsures that the final deliverables are tested thoroughly and meet the client’s expectations.",
                        "ModifiedDate" : 1392913881762,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881762,
                        "CreatedBy" : "",
                        "hgId" : "525e90f4-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40bc4f754f907000002ff",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40bc4f754f907000002fe",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40bc4f754f907000002fd",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40bc4f754f907000002fc",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "To what extent did the Project Manager exhibit \"Deliver Quality Work\"?"
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb4",
                        "QuestionHelp" : "•\tDemonstrates ability to fight fires (server crashes, production down, urgent issues, unhappy clients, etc.) by remaining calm, prioritizing tasks, troubleshooting tough problems, communicating well with clients and team members and being available even when inconvenient like nights and weekends.\n•\tRemains committed to seeing the project through to completion.\n•\tEffectively manages resources, expectations and timelines; Understands what’s going on at all times during the project with the right amount of detail.",
                        "ModifiedDate" : 1392913881761,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881761,
                        "CreatedBy" : "",
                        "hgId" : "525e90f5-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40bc4f754f907000002fb",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40bc4f754f907000002fa",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f9",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f8",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 4,
                        "QuestionText" : "To what extent did the Project Manager exhibit \"Take Ownership\"?"
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb5",
                        "QuestionHelp" : "•\tFollows through on commitments (says what they’ll do then does it).\n\t- If they say they’ll email a file “by 5:00 today”, it happens.\n\t- If they don’t know an answer, they reply stating they’ll get back to the individual/team with an update by X date and do so.\n•\tWillingness to get into the weeds and be hands on when needed.",
                        "ModifiedDate" : 1392913881760,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881760,
                        "CreatedBy" : "",
                        "hgId" : "525eb800-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40bc4f754f907000002f7",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f6",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f5",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f4",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 5,
                        "QuestionText" : "To what extent did the Project Manager exhibit \"Just Do It (Don't Talk About It)\"?"
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb6",
                        "QuestionHelp" : "•\tProactively engages and motivates team members; Fosters team unity \n•\tProvides the right balance of positive feedback/encouragement and constructive feedback.\n•\tAttentive to feedback/approachable to team members \n•\tDemonstrates awareness of individual’s workloads to prevent or minimize burnout among team members (strikes right balance between task-focus/person-focus).",
                        "ModifiedDate" : 1392913881758,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881758,
                        "CreatedBy" : "",
                        "hgId" : "525eb801-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40bc4f754f907000002f3",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f2",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f1",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40bc4f754f907000002f0",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 6,
                        "QuestionText" : "To what extent did the Project Manager exhibit \"Foster a Positive Environment\"?"
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb7",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913881758,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881758,
                        "CreatedBy" : "",
                        "hgId" : "525eb802-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d2e803c097ad0800000038",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 7,
                        "QuestionText" : "Please use the space below to provide additional feedback."
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb8",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913881758,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881758,
                        "CreatedBy" : "",
                        "hgId" : "525eb803-8eb9-11e3-b99c-8feca8d40e33",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d92b5fb698d50700000058",
                                "Text" : "Reviewed by Coach",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "CheckBox",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 8,
                        "QuestionText" : "Coach Review is complete and ready to send to Reviewee"
                    },
                    {
                        "_id" : "53062dd9ea3f1a0600298bb9",
                        "QuestionHelp" : "By entering your name, the reviewee will know which feedback is yours.",
                        "ModifiedDate" : 1392913881757,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913881757,
                        "CreatedBy" : "",
                        "hgId" : "6ec345d1-9a4c-11e3-9644-49b148081fc6",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53062dd9cadc7b0600e7d1db",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "ShortText",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : true,
                        "SortOrder" : 9,
                        "QuestionText" : "Enter your name here:"
                    }
                ],
                "SortOrder" : 1,
                "Description" : "",
                "Title" : ""
            }
        ],
        "Status" : "ReadyToAssign",
        "SubjectManagerOnly" : false,
        "Title" : "Project Manager",
        "Type" : "Project",
        "__v" : 5,
        "_id" : "52f2c293d6b9a60500000463",
        "hgId" : "525e90f0-8eb9-11e3-b99c-8feca8d40e33"
    },
    {
        "CreatedBy" : "fcac9eb0-626f-11e3-a86e-d10290e48d36",
        "CreatedDate" : 1389553007796,
        "Description" : "Project-based Feedback for Discovery Projects",
        "ExpireDate" : 1421089007798,
        "GroupId" : "fc5ea5c0-626f-11e3-a86e-d10290e48d36",
        "GroupName" : "Sonoma Partners",
        "IsTemplate" : false,
        "ModifiedBy" : "fc68def0-626f-11e3-a86e-d10290e48d36",
        "ModifiedDate" : 1392913835140,
        "OriginalId" : "705b3e60-8468-11e3-bec2-71481195ed0c",
        "PeopleTypes" : [
            {
                "_id" : "52d2e56f326ead0900000045",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Manager"
            },
            {
                "_id" : "52d2e56f326ead0900000044",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : false,
                "PeopleTypeName" : "Subject"
            },
            {
                "_id" : "52d2e56f326ead0900000043",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Peer"
            }
        ],
        "Sections" : [
            {
                "_id" : "53062dabea3f1a0600298ba9",
                "ModifiedDate" : 1392913835009,
                "ModifiedBy" : "",
                "CreatedDate" : 1392913835009,
                "CreatedBy" : "",
                "hgId" : "52f4e520-9a4c-11e3-9644-49b148081fc6",
                "Questions" : [
                    {
                        "_id" : "53062dabea3f1a0600298ba0",
                        "QuestionHelp" : "•\tIs aware of project goals and sets project deadlines and estimates accordingly.\n•\tInstills confidence in the customer (articulates their needs well, delivers appropriate message, and responds in a timely manner).\n•\tFacilitates requirements gathering effectively (manages conversation well, involves customer appropriately and collects appropriate level of detail).\n•\tManages client expectations effectively (presents right-sized solutions with sensitivity to budget and clearly communicates milestones and any challenges effectively).\n•\tCommunicates with all interested parties as appropriate (Sonoma, client and/or vendor resources).\n•\tComplements sales efforts effectively by reinforcing value proposition.",
                        "ModifiedDate" : 1392913835021,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835021,
                        "CreatedBy" : "",
                        "hgId" : "53a086d0-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40ad51160080400000524",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40ad51160080400000523",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40ad51160080400000522",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40ad51160080400000521",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "To what extent did the Sonoman exhibit \"Be a Good Communicator\"?"
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba1",
                        "QuestionHelp" : "•\tDemonstrates ability to push back on client and/or team member(s) regarding budget, scope timeline, etc. when needed.\n•\tDemonstrates appropriate sense of urgency/level of responsiveness.\n•\tAdapts well to unforeseen changes in scope/direction.\n•\tDemonstrates a consultative approach by offering solutions beyond being a task-taker and challenging client/team members appropriately.",
                        "ModifiedDate" : 1392913835020,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835020,
                        "CreatedBy" : "",
                        "hgId" : "53a086d1-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40ad51160080400000520",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40ad5116008040000051f",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40ad5116008040000051e",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40ad5116008040000051d",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "To what extent did the Sonoman exhibit \"Think Service First\"?"
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba2",
                        "QuestionHelp" : "•\tPays attention to details.\n•\tProvides client presentable documentation (proper grammar, consistent formatting).\n•\tEnsures that the final deliverables meet the client’s expectations.\n•\tAccurately captures/documents business and technical requirements and with the right amount of detail.",
                        "ModifiedDate" : 1392913835019,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835019,
                        "CreatedBy" : "",
                        "hgId" : "53a086d2-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40ad5116008040000051c",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40ad5116008040000051b",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40ad5116008040000051a",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40ad51160080400000519",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "To what extent did the Sonoman exhibit \"Deliver Quality Work\"?"
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba3",
                        "QuestionHelp" : "•\tDemonstrates ability to handle challenging/sensitive conversations well (server crashes, production down, urgent issues, unhappy clients, etc.) by remaining calm, prioritizing tasks, troubleshooting tough problems and communicating well with clients and team members.\n•\tMakes oneself available even when inconvenient like nights and weekends.\n•\tRemains committed to seeing the project through to completion.\n•\tEffectively manages resources, expectations and timelines; Understands what’s going on at all times during the project",
                        "ModifiedDate" : 1392913835018,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835018,
                        "CreatedBy" : "",
                        "hgId" : "53a086d3-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40ad51160080400000518",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40ad51160080400000517",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40ad51160080400000516",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40ad51160080400000515",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 4,
                        "QuestionText" : "To what extent did the Sonoman exhibit \"Take Ownership\"?"
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba4",
                        "QuestionHelp" : "•\tFollows through on commitments (says what they’ll do then does it).\n\t- If they say they’ll email a file “by 5:00 today”, it happens.\n\t- If they don’t know an answer, they reply stating they’ll get back to the individual/team with an update by X date and do so.\n•\tWillingness to get into the weeds and be hands on when needed.",
                        "ModifiedDate" : 1392913835017,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835017,
                        "CreatedBy" : "",
                        "hgId" : "53a086d4-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40ad51160080400000514",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40ad51160080400000513",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40ad51160080400000512",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40ad51160080400000511",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 5,
                        "QuestionText" : "To what extent did the Sonoman exhibit \"Just Do It (Don't Talk About It)\"?"
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba5",
                        "QuestionHelp" : "•\tUnderstands the client’s business, challenges and goals for the project (not just what’s captured in the SOW) and has a deep understanding of their business processes.\n•\tPresents feasible solutions that meet the client’s business needs.\n•\tEffectively conveys industry and product expertise, represents Sonoma as a SME and presents oneself as a Trusted Advisor (offers best practices, lessons learned, industry and/or technical knowledge).",
                        "ModifiedDate" : 1392913835014,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835014,
                        "CreatedBy" : "",
                        "hgId" : "53a086d5-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f40ad51160080400000510",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f40ad5116008040000050f",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f40ad5116008040000050e",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f40ad5116008040000050d",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 6,
                        "QuestionText" : "To what extent did the Sonoman exhibit \"Think in Business Terms\"?"
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba6",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913835013,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835013,
                        "CreatedBy" : "",
                        "hgId" : "53a086d6-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d2e803c097ad0800000038",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 7,
                        "QuestionText" : "Please use the space below to provide additional feedback."
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba7",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913835012,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835012,
                        "CreatedBy" : "",
                        "hgId" : "53a086d7-8eb9-11e3-b0c2-c3df1227df45",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d92b5fb698d50700000058",
                                "Text" : "Reviewed by Coach",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "CheckBox",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 8,
                        "QuestionText" : "Coach Review is complete and ready to send to Reviewee"
                    },
                    {
                        "_id" : "53062dabea3f1a0600298ba8",
                        "QuestionHelp" : "By entering your name, the reviewee will know which feedback is yours.",
                        "ModifiedDate" : 1392913835009,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913835009,
                        "CreatedBy" : "",
                        "hgId" : "52f4e521-9a4c-11e3-9644-49b148081fc6",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53062dabcadc7b0600e7d1da",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "ShortText",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : true,
                        "SortOrder" : 9,
                        "QuestionText" : "Enter your name here:"
                    }
                ],
                "SortOrder" : 1,
                "Description" : "",
                "Title" : ""
            }
        ],
        "Status" : "ReadyToAssign",
        "SubjectManagerOnly" : false,
        "Title" : "Discovery Projects",
        "Type" : "Project",
        "__v" : 6,
        "_id" : "52f2c295610627040000044d",
        "hgId" : "53a05fc0-8eb9-11e3-b0c2-c3df1227df45"
    },
    {
        "CreatedBy" : "fcac9eb0-626f-11e3-a86e-d10290e48d36",
        "CreatedDate" : 1389553007796,
        "Description" : "Project-based Feedback for Business Analysts",
        "ExpireDate" : 1421089007798,
        "GroupId" : "fc5ea5c0-626f-11e3-a86e-d10290e48d36",
        "GroupName" : "Sonoma Partners",
        "IsTemplate" : false,
        "ModifiedBy" : "fc68def0-626f-11e3-a86e-d10290e48d36",
        "ModifiedDate" : 1392913762735,
        "OriginalId" : "705b3e60-8468-11e3-bec2-71481195ed0c",
        "PeopleTypes" : [
            {
                "_id" : "52d2e56f326ead0900000045",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Manager"
            },
            {
                "_id" : "52d2e56f326ead0900000044",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : false,
                "PeopleTypeName" : "Subject"
            },
            {
                "_id" : "52d2e56f326ead0900000043",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Peer"
            }
        ],
        "Sections" : [
            {
                "_id" : "53062d6213b9fe0900d8615a",
                "ModifiedDate" : 1392913762680,
                "ModifiedBy" : "",
                "CreatedDate" : 1392913762680,
                "CreatedBy" : "",
                "hgId" : "27cd12f0-9a4c-11e3-8642-d19500c56f05",
                "Questions" : [
                    {
                        "_id" : "53062d6213b9fe0900d86151",
                        "QuestionHelp" : "•\tIs aware of project goals and adheres to deadlines and estimates accordingly.\n•\tProactively keeps PM and Tech Lead informed of status and issues with deadlines/estimates.\n•\tHelps keep development team aware of code complete due date and assists in planning timeline of features and items accordingly.\n•\tEffectively conveys/clarifies business and/or technical requirements to development team.",
                        "ModifiedDate" : 1392913762693,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762693,
                        "CreatedBy" : "",
                        "hgId" : "c3e9f4b2-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f3aa03a946c7060000041f",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f3aa03a946c7060000041e",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f3aa03a946c7060000041d",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f3aa03a946c7060000041c",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "To what extent did the Business Analyst exhibit \"Be a Good Communicator\"?"
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86152",
                        "QuestionHelp" : "•\tDemonstrates ability to push back on client and/or team member(s) when needed.\n•\tGets the right folks involved/escalates issues appropriately.\n•\tDemonstrates appropriate sense of urgency/level of responsiveness.\n•\tAdapts well to unforeseen changes in scope/direction.\n•\tDemonstrates a consultative approach (offers solutions beyond being a task taker; challenges client and/or team members appropriately).",
                        "ModifiedDate" : 1392913762692,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762692,
                        "CreatedBy" : "",
                        "hgId" : "c3e9f4b3-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f3aa03a946c7060000041b",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f3aa03a946c7060000041a",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f3aa03a946c70600000419",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f3aa03a946c70600000418",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "To what extent did the Business Analyst exhibit \"Think Service First\"?"
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86153",
                        "QuestionHelp" : "•\tMaintains strong attention to detail throughout the entire project.\n•\tCreates client presentable documentation (proper grammar, consistent formatting).\n•\tWrites documentation that clearly captures client requirements, both functionally and technically; makes sure all documents are updated as needed.\n•\tTakes good notes.\n•\tEnsures that the final deliverables are tested thoroughly and meet the client’s expectations.",
                        "ModifiedDate" : 1392913762691,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762691,
                        "CreatedBy" : "",
                        "hgId" : "c3e9f4b4-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f3aa03a946c70600000417",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f3aa03a946c70600000416",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f3aa03a946c70600000415",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f3aa03a946c70600000414",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "To what extent did the Business Analyst exhibit \"Deliver Quality Work\"?"
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86154",
                        "QuestionHelp" : "•\tAssists Project Manager in fighting fires (server crashes, production down, urgent issues, unhappy clients, etc.) by remaining calm, prioritizing tasks, troubleshooting tough problems, communicating well with clients and team members and being available even when inconvenient like nights and weekends.\n•\tRemains committed to seeing the project through to completion.\n•\tProactively supports Project Manager (understands what’s going on at all times during the project and seeks out ways to help balance work load; takes ownership of larger deliverables, takes on work they may not typically do).\n•\tEnsures deliverables meet the overall business needs of the client.",
                        "ModifiedDate" : 1392913762688,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762688,
                        "CreatedBy" : "",
                        "hgId" : "c3ea1bc0-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f3aa03a946c70600000413",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f3aa03a946c70600000412",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f3aa03a946c70600000411",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f3aa03a946c70600000410",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 4,
                        "QuestionText" : "To what extent did the Business Analyst exhibit \"Take Ownership\"?"
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86155",
                        "QuestionHelp" : "•\tFollows through on commitments (says what they’ll do then does it).\n\t- If they say they’ll email a file “by 5:00 today”, it happens.\n\t- If they don’t know an answer, they reply stating they’ll get back to the individual/team with an update by X date and do so.\n•\tWillingness to get into the weeds and be hands.\n•\tFollows project process and adheres to documentation standards.\n•\tWorks autonomously with minimal direction from Project Manager.\n•\tFinds ways to facilitate smoother development and/or helps client understand system better through anticipating development questions and providing detailed documentation (e.g. security role matrix or other non-standard documentation).\n•\tDoes high quality work; doesn’t just check a box as done.",
                        "ModifiedDate" : 1392913762685,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762685,
                        "CreatedBy" : "",
                        "hgId" : "c3ea1bc1-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f3aa03a946c7060000040f",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f3aa03a946c7060000040e",
                                "Text" : "Often",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f3aa03a946c7060000040d",
                                "Text" : "Sometimes",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f3aa03a946c7060000040c",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 5,
                        "QuestionText" : "To what extent did the Business Analyst exhibit \"Just Do It (Don't Talk About It)\"?"
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86156",
                        "QuestionHelp" : "•\tProactively engages and motivates team members; fosters team unity.\n•\tProvides the right balance of positive feedback/encouragement and constructive feedback.\n•\tIs responsive to feedback/approachable to team members.\n•\tDemonstrates awareness of individual’s workloads to prevent or minimize burnout among team members (strikes right balance between task-focus/person-focus) and communicates concerns to Project Manager as necessary.",
                        "ModifiedDate" : 1392913762684,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762684,
                        "CreatedBy" : "",
                        "hgId" : "c3ea1bc2-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52f3aa03a946c7060000040b",
                                "Text" : "Not Enough",
                                "Value" : 1
                            },
                            {
                                "_id" : "52f3aa03a946c7060000040a",
                                "Text" : "Sometimes",
                                "Value" : 2
                            },
                            {
                                "_id" : "52f3aa03a946c70600000409",
                                "Text" : "Often",
                                "Value" : 3
                            },
                            {
                                "_id" : "52f3aa03a946c70600000408",
                                "Text" : "Always",
                                "Value" : 4
                            }
                        ],
                        "AnswerType" : "ScaleRating",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 6,
                        "QuestionText" : "To what extent did the Business Analyst exhibit \"Foster a Positive Environment\"?"
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86157",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913762683,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762683,
                        "CreatedBy" : "",
                        "hgId" : "c3ea1bc3-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d2e803c097ad0800000038",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 7,
                        "QuestionText" : "Please use the space below to provide additional feedback."
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86158",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1392913762682,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762682,
                        "CreatedBy" : "",
                        "hgId" : "c3ea69e0-8f42-11e3-a155-7503a79434e8",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52d92b5fb698d50700000058",
                                "Text" : "Reviewed by Coach",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "CheckBox",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 8,
                        "QuestionText" : "Coach Review is complete and ready to send to Reviewee"
                    },
                    {
                        "_id" : "53062d6213b9fe0900d86159",
                        "QuestionHelp" : "By entering your name, the reviewee will know which feedback is yours.",
                        "ModifiedDate" : 1392913762681,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1392913762681,
                        "CreatedBy" : "",
                        "hgId" : "27cd12f1-9a4c-11e3-8642-d19500c56f05",
                        "Answers" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53062d62c2e4050900cbbedb",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "ShortText",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Peer"
                        ],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : true,
                        "SortOrder" : 9,
                        "QuestionText" : "Enter your name here:"
                    }
                ],
                "SortOrder" : 1,
                "Description" : "",
                "Title" : ""
            }
        ],
        "Status" : "ReadyToAssign",
        "SubjectManagerOnly" : false,
        "Title" : "Business Analyst",
        "Type" : "Project",
        "__v" : 4,
        "_id" : "52f3a92a116008040000030e",
        "hgId" : "c3e9f4b0-8f42-11e3-a155-7503a79434e8"
    },
    {
        "CreatedBy" : "fc68def0-626f-11e3-a86e-d10290e48d36",
        "CreatedDate" : 1392129475423,
        "Description" : "",
        "ExpireDate" : 1423665475428,
        "GroupId" : "fc5ea5c0-626f-11e3-a86e-d10290e48d36",
        "GroupName" : "Sonoma Partners",
        "IsTemplate" : false,
        "ModifiedBy" : "fcac9eb0-626f-11e3-a86e-d10290e48d36",
        "ModifiedDate" : 1394553854373,
        "OriginalId" : "248a38c0-9dd5-11e3-a6a4-09ad44eb1351",
        "PeopleTypes" : [
            {
                "_id" : "52fa35c3488e67070000011e",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Manager"
            },
            {
                "_id" : "52fa35c3488e67070000011d",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Subject"
            },
            {
                "_id" : "52fa35c3488e67070000011c",
                "AllowMultiple" : false,
                "Required" : false,
                "ContainQuestionForMe" : true,
                "PeopleTypeName" : "Peer"
            }
        ],
        "Sections" : [
            {
                "_id" : "531f33fec65ac307001faf7e",
                "ModifiedDate" : 1394553854217,
                "ModifiedBy" : "",
                "CreatedDate" : 1394553854217,
                "CreatedBy" : "",
                "hgId" : "38fb3c60-9dd9-11e3-9cce-a352a6748d57",
                "Questions" : [
                    {
                        "_id" : "531f33fec65ac307001faf6d",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854221,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854221,
                        "CreatedBy" : "",
                        "hgId" : "38fb3c61-9dd9-11e3-9cce-a352a6748d57",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a26b",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a26a",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a269",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a268",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a267",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a266",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a265",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a264",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a263",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a262",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a261",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a260",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25f",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25e",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25d",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Clear Strength #1"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf6e",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854219,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854219,
                        "CreatedBy" : "",
                        "hgId" : "38fb3c62-9dd9-11e3-9cce-a352a6748d57",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a26b",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a26a",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a269",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a268",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a267",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a266",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a265",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a264",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a263",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a262",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a261",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a260",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25f",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25e",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25d",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Clear Strength #2"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf6f",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854218,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854218,
                        "CreatedBy" : "",
                        "hgId" : "38fb3c63-9dd9-11e3-9cce-a352a6748d57",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a26b",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a26a",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a269",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a268",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a267",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a266",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a265",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a264",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a263",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a262",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a261",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a260",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25f",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25e",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25d",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Clear Strength #3"
                    }
                ],
                "SortOrder" : 1,
                "Description" : "Please select up to 3 clear strengths from the How to Be Awesome list (found on Sharepoint at Operations > HR > Employee Development).",
                "Title" : "Clear Strengths (Employee Selection)"
            },
            {
                "_id" : "531f33fec65ac307001faf7f",
                "ModifiedDate" : 1394553854200,
                "ModifiedBy" : "",
                "CreatedDate" : 1394553854200,
                "CreatedBy" : "",
                "hgId" : "a8555bf1-9dd8-11e3-a6a4-09ad44eb1351",
                "Questions" : [
                    {
                        "_id" : "531f33fec65ac307001faf70",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854215,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854215,
                        "CreatedBy" : "",
                        "hgId" : "a8558300-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a26b",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a26a",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a269",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a268",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a267",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a266",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a265",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a264",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a263",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a262",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a261",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a260",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25f",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25e",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25d",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Clear Strength #1"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf71",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854214,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854214,
                        "CreatedBy" : "",
                        "hgId" : "a8558301-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a25c",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25b",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a25a",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a259",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a258",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a257",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a256",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a255",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a254",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a253",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a252",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a251",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a250",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a24f",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a24e",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Clear Strength #2"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf72",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854201,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854201,
                        "CreatedBy" : "",
                        "hgId" : "a8558302-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a24d",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a24c",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a24b",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a24a",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a249",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a248",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a247",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a246",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a245",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a244",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a243",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a242",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a241",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a240",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23f",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Clear Strength #3"
                    }
                ],
                "SortOrder" : 2,
                "Description" : "Please select up to 3 clear strengths from the How to Be Awesome list.",
                "Title" : "Clear Strengths (Manager Selection)"
            },
            {
                "_id" : "531f33fec65ac307001faf80",
                "ModifiedDate" : 1394553854185,
                "ModifiedBy" : "",
                "CreatedDate" : 1394553854185,
                "CreatedBy" : "",
                "hgId" : "a8558303-9dd8-11e3-a6a4-09ad44eb1351",
                "Questions" : [
                    {
                        "_id" : "531f33fec65ac307001faf73",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854198,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854198,
                        "CreatedBy" : "",
                        "hgId" : "a8558304-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a23e",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23d",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23c",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23b",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23a",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a239",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a238",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a237",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a236",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a235",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a234",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a233",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a232",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a231",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a230",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Growth Area #1"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf74",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854187,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854187,
                        "CreatedBy" : "",
                        "hgId" : "a8558305-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a22f",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22e",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22d",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22c",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22b",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22a",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a229",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a228",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a227",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a226",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a225",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a224",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a223",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a222",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a221",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Growth Area #2"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf75",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854186,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854186,
                        "CreatedBy" : "",
                        "hgId" : "a8558306-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a220",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a21f",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a21e",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a21d",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a21c",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a21b",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a21a",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a219",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a218",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a217",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a216",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a215",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a214",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a213",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a212",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Growth Area #3"
                    }
                ],
                "SortOrder" : 3,
                "Description" : "Please select up to 3 growth areas from the How to Be Awesome list.  When selecting growth areas, consider items in which additional focus/attention will be mutually beneficial to you and Sonoma, either because you know improvement is needed or you know the additional attention will help you and/or other Sonomans add more value to Sonoma and its clients.",
                "Title" : "Growth Areas (Employee Selection)"
            },
            {
                "_id" : "531f33fec65ac307001faf81",
                "ModifiedDate" : 1394553854177,
                "ModifiedBy" : "",
                "CreatedDate" : 1394553854177,
                "CreatedBy" : "",
                "hgId" : "0322d560-9ddb-11e3-a5f1-79c14a30cf88",
                "Questions" : [
                    {
                        "_id" : "531f33fec65ac307001faf76",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854180,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854180,
                        "CreatedBy" : "",
                        "hgId" : "0322d561-9ddb-11e3-a5f1-79c14a30cf88",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a23e",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23d",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23c",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23b",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a23a",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a239",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a238",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a237",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a236",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a235",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a234",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a233",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a232",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a231",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a230",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Growth Area #1"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf77",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854179,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854179,
                        "CreatedBy" : "",
                        "hgId" : "0322d562-9ddb-11e3-a5f1-79c14a30cf88",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a22f",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22e",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22d",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22c",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22b",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22a",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a229",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a228",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a227",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a226",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a225",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a224",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a223",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a222",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a221",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Growth Area #2"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf78",
                        "QuestionHelp" : "",
                        "ModifiedDate" : 1394553854177,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854177,
                        "CreatedBy" : "",
                        "hgId" : "0322d563-9ddb-11e3-a5f1-79c14a30cf88",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "530c1eee5ab6e3040015a22f",
                                "Text" : "Act Like a Pro",
                                "Value" : 1
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22e",
                                "Text" : "Deliver Quality Work",
                                "Value" : 2
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22d",
                                "Text" : "Be a Good Communicator",
                                "Value" : 3
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22c",
                                "Text" : "Just Do It (Don't Talk About It)",
                                "Value" : 4
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22b",
                                "Text" : "Foster a Positive Environment",
                                "Value" : 5
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a22a",
                                "Text" : "Manage Yourself",
                                "Value" : 6
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a229",
                                "Text" : "Be Fun",
                                "Value" : 7
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a228",
                                "Text" : "Solve Problems",
                                "Value" : 8
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a227",
                                "Text" : "Know Your Stuff",
                                "Value" : 9
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a226",
                                "Text" : "Think Service First",
                                "Value" : 10
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a225",
                                "Text" : "Do More Than the Bare Minimum",
                                "Value" : 11
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a224",
                                "Text" : "Take Ownership",
                                "Value" : 12
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a223",
                                "Text" : "Show Initiative",
                                "Value" : 13
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a222",
                                "Text" : "Think in Business Terms",
                                "Value" : 14
                            },
                            {
                                "_id" : "530c1eee5ab6e3040015a221",
                                "Text" : "Get Invested Into Sonoma Partners",
                                "Value" : 15
                            }
                        ],
                        "AnswerType" : "Option",
                        "AllowComments" : true,
                        "OptionalTo" : [
                            "Manager",
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Growth Area #3"
                    }
                ],
                "SortOrder" : 4,
                "Description" : "Please review the list of How to Be Awesome items and select up to 3 clear strengths and 3 growth areas for the employee.  When selecting growth areas, consider items in which additional focus/attention will be mutually beneficial for the employee and Sonoma, either because improvement is needed or because the additional attention will help the employee and/or other Sonomans add more value to Sonoma and its clients.",
                "Title" : "Growth Areas (Manager Selection)"
            },
            {
                "_id" : "531f33fec65ac307001faf82",
                "ModifiedDate" : 1394553854176,
                "ModifiedBy" : "",
                "CreatedDate" : 1394553854176,
                "CreatedBy" : "",
                "hgId" : "27c86ce0-a4b1-11e3-bcee-bfc59189e45e",
                "Questions" : [
                    {
                        "_id" : "531f33fec65ac307001faf79",
                        "QuestionHelp" : "Use this section to share progress on or completion of current goals as well as suggest goals for the next review cycle.",
                        "ModifiedDate" : 1394553854176,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854176,
                        "CreatedBy" : "",
                        "hgId" : "27c86ce1-a4b1-11e3-bcee-bfc59189e45e",
                        "NAText" : "N/A",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53179dcdd6e35a04008a0454",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Subject"
                        ],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Enter goals currently in progress or completed during this review cycle."
                    }
                ],
                "SortOrder" : 5,
                "Description" : "",
                "Title" : "Goals (Optional)"
            },
            {
                "_id" : "531f33fec65ac307001faf83",
                "ModifiedDate" : 1394553854171,
                "ModifiedBy" : "",
                "CreatedDate" : 1394553854171,
                "CreatedBy" : "",
                "hgId" : "0322fc70-9ddb-11e3-a5f1-79c14a30cf88",
                "Questions" : [
                    {
                        "_id" : "531f33fec65ac307001faf7a",
                        "QuestionHelp" : "Considerations for comment: overall level of satisfaction with your role, highlights of your recent accomplishments, peak experience(s), challenges you are facing, skills you want to learn or improve.",
                        "ModifiedDate" : 1394553854172,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854172,
                        "CreatedBy" : "",
                        "hgId" : "a8558307-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52fa35c3488e67070000011b",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Subject"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Employee Comments"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf7b",
                        "QuestionHelp" : "Considerations for comment: positive behavioral examples of Awesome List items, suggested behavioral changes that will improve measurement of goals and/or Awesome List items and/or highlighted feedback from project-based feedback program.",
                        "ModifiedDate" : 1394553854171,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854171,
                        "CreatedBy" : "",
                        "hgId" : "a8558308-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52fa35c3488e67070000011a",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 2,
                        "QuestionText" : "Manager Comments"
                    },
                    {
                        "_id" : "531f33fec65ac307001faf7c",
                        "QuestionHelp" : "Consider using the following SBIR method when providing your feedback, being as specific as possible: \nSituation — Describe the situation in which you observed the employee\nBehavior — Describe the behavior you observed\nImpact — Describe the impact of that behavior on you or others who were present in the situation\nRequest – Describe the desired behavior you want going forward",
                        "ModifiedDate" : 1394553854171,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854171,
                        "CreatedBy" : "",
                        "hgId" : "a8558309-9dd8-11e3-a6a4-09ad44eb1351",
                        "NAText" : "",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "52fa35c3488e670700000119",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [],
                        "ToBeAnsweredBy" : [
                            "Peer"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 3,
                        "QuestionText" : "Peer Comments - Please provide feedback for your colleague (both appreciative and constructive)"
                    }
                ],
                "SortOrder" : 6,
                "Description" : "",
                "Title" : "Comments"
            },
            {
                "_id" : "531f33fec65ac307001faf84",
                "ModifiedDate" : 1394553854165,
                "ModifiedBy" : "",
                "CreatedDate" : 1394553854165,
                "CreatedBy" : "",
                "hgId" : "a9f434c0-a4b0-11e3-a397-69dcbea6a80f",
                "Questions" : [
                    {
                        "_id" : "531f33fec65ac307001faf7d",
                        "QuestionHelp" : "Use this section if/when additional peer feedback is provided from peers not originally included in the cycle.",
                        "ModifiedDate" : 1394553854165,
                        "ModifiedBy" : "",
                        "CreatedDate" : 1394553854165,
                        "CreatedBy" : "",
                        "hgId" : "a9f45bd0-a4b0-11e3-a397-69dcbea6a80f",
                        "NAText" : "N/A",
                        "NAEnable" : false,
                        "Answers" : [],
                        "RecognitionFilter" : [],
                        "AnswerSelectors" : [
                            {
                                "_id" : "53179cfa0af56d06009fcfe7",
                                "Text" : "",
                                "Value" : 1
                            }
                        ],
                        "AnswerType" : "Paragraph",
                        "AllowComments" : false,
                        "OptionalTo" : [
                            "Manager"
                        ],
                        "ToBeAnsweredBy" : [
                            "Manager"
                        ],
                        "Confidential" : false,
                        "SortOrder" : 1,
                        "QuestionText" : "Additional Peer Feedback"
                    }
                ],
                "SortOrder" : 7,
                "Description" : "Only used if feedback is solicited from peers not originally included in cycle.",
                "Title" : "Additional Peer Feedback"
            }
        ],
        "Status" : "ReadyToAssign",
        "SubjectManagerOnly" : false,
        "Title" : "Mid-Cycle Performance Review",
        "Type" : "General",
        "__v" : 9,
        "_id" : "530c2199d2263a07007ad62f",
        "hgId" : "a8555bf0-9dd8-11e3-a6a4-09ad44eb1351"
    }];
guids=["9476c340-ab88-11e3-99b1-73f58747ac10","9476c341-ab88-11e3-99b1-73f58747ac10","9476c342-ab88-11e3-99b1-73f58747ac10","9476c343-ab88-11e3-99b1-73f58747ac10","9476c344-ab88-11e3-99b1-73f58747ac10","9476c345-ab88-11e3-99b1-73f58747ac10","9476c346-ab88-11e3-99b1-73f58747ac10","9476c347-ab88-11e3-99b1-73f58747ac10","9476c348-ab88-11e3-99b1-73f58747ac10","9476c349-ab88-11e3-99b1-73f58747ac10","9476c34a-ab88-11e3-99b1-73f58747ac10","9476c34b-ab88-11e3-99b1-73f58747ac10","9476c34c-ab88-11e3-99b1-73f58747ac10","9476c34d-ab88-11e3-99b1-73f58747ac10","9476c34e-ab88-11e3-99b1-73f58747ac10","9476c34f-ab88-11e3-99b1-73f58747ac10","9476c350-ab88-11e3-99b1-73f58747ac10","9476c351-ab88-11e3-99b1-73f58747ac10","9476c352-ab88-11e3-99b1-73f58747ac10","9476c353-ab88-11e3-99b1-73f58747ac10","9476c354-ab88-11e3-99b1-73f58747ac10","9476c355-ab88-11e3-99b1-73f58747ac10","9476c356-ab88-11e3-99b1-73f58747ac10","9476c357-ab88-11e3-99b1-73f58747ac10","9476c358-ab88-11e3-99b1-73f58747ac10","9476c359-ab88-11e3-99b1-73f58747ac10","9476c35a-ab88-11e3-99b1-73f58747ac10","9476c35b-ab88-11e3-99b1-73f58747ac10","9476c35c-ab88-11e3-99b1-73f58747ac10","9476c35d-ab88-11e3-99b1-73f58747ac10","9476c35e-ab88-11e3-99b1-73f58747ac10","9476c35f-ab88-11e3-99b1-73f58747ac10","9476c360-ab88-11e3-99b1-73f58747ac10","9476c361-ab88-11e3-99b1-73f58747ac10","9476c362-ab88-11e3-99b1-73f58747ac10","9476c363-ab88-11e3-99b1-73f58747ac10","9476c364-ab88-11e3-99b1-73f58747ac10","9476c365-ab88-11e3-99b1-73f58747ac10","9476c366-ab88-11e3-99b1-73f58747ac10","9476c367-ab88-11e3-99b1-73f58747ac10","9476c368-ab88-11e3-99b1-73f58747ac10","9476c369-ab88-11e3-99b1-73f58747ac10","9476c36a-ab88-11e3-99b1-73f58747ac10","9476c36b-ab88-11e3-99b1-73f58747ac10","9476c36c-ab88-11e3-99b1-73f58747ac10","9476c36d-ab88-11e3-99b1-73f58747ac10","9476c36e-ab88-11e3-99b1-73f58747ac10","9476c36f-ab88-11e3-99b1-73f58747ac10","9476c370-ab88-11e3-99b1-73f58747ac10","9476c371-ab88-11e3-99b1-73f58747ac10","9476c372-ab88-11e3-99b1-73f58747ac10","9476c373-ab88-11e3-99b1-73f58747ac10","9476c374-ab88-11e3-99b1-73f58747ac10","9476c375-ab88-11e3-99b1-73f58747ac10","9476c376-ab88-11e3-99b1-73f58747ac10","9476c377-ab88-11e3-99b1-73f58747ac10","9476c378-ab88-11e3-99b1-73f58747ac10","9476c379-ab88-11e3-99b1-73f58747ac10","9476c37a-ab88-11e3-99b1-73f58747ac10","9476c37b-ab88-11e3-99b1-73f58747ac10","9476c37c-ab88-11e3-99b1-73f58747ac10","9476c37d-ab88-11e3-99b1-73f58747ac10","9476c37e-ab88-11e3-99b1-73f58747ac10","9476c37f-ab88-11e3-99b1-73f58747ac10","9476c380-ab88-11e3-99b1-73f58747ac10","9476c381-ab88-11e3-99b1-73f58747ac10","9476c382-ab88-11e3-99b1-73f58747ac10","9476c383-ab88-11e3-99b1-73f58747ac10","9476c384-ab88-11e3-99b1-73f58747ac10","9476c385-ab88-11e3-99b1-73f58747ac10","9476c386-ab88-11e3-99b1-73f58747ac10","9476c387-ab88-11e3-99b1-73f58747ac10","9476c388-ab88-11e3-99b1-73f58747ac10","9476c389-ab88-11e3-99b1-73f58747ac10","9476c38a-ab88-11e3-99b1-73f58747ac10","9476c38b-ab88-11e3-99b1-73f58747ac10","9476c38c-ab88-11e3-99b1-73f58747ac10","9476c38d-ab88-11e3-99b1-73f58747ac10","9476c38e-ab88-11e3-99b1-73f58747ac10","9476c38f-ab88-11e3-99b1-73f58747ac10","9476c390-ab88-11e3-99b1-73f58747ac10","9476c391-ab88-11e3-99b1-73f58747ac10","9476c392-ab88-11e3-99b1-73f58747ac10","9476c393-ab88-11e3-99b1-73f58747ac10","9476c394-ab88-11e3-99b1-73f58747ac10","9476c395-ab88-11e3-99b1-73f58747ac10","9476c396-ab88-11e3-99b1-73f58747ac10","9476c397-ab88-11e3-99b1-73f58747ac10","9476c398-ab88-11e3-99b1-73f58747ac10","9476c399-ab88-11e3-99b1-73f58747ac10","9476c39a-ab88-11e3-99b1-73f58747ac10","9476c39b-ab88-11e3-99b1-73f58747ac10","9476c39c-ab88-11e3-99b1-73f58747ac10","9476c39d-ab88-11e3-99b1-73f58747ac10","9476c39e-ab88-11e3-99b1-73f58747ac10","9476c39f-ab88-11e3-99b1-73f58747ac10","9476c3a0-ab88-11e3-99b1-73f58747ac10","9476c3a1-ab88-11e3-99b1-73f58747ac10","9476c3a2-ab88-11e3-99b1-73f58747ac10","9476c3a3-ab88-11e3-99b1-73f58747ac10","aa810150-ab88-11e3-8a2e-a314510b1049","aa812860-ab88-11e3-8a2e-a314510b1049","aa812861-ab88-11e3-8a2e-a314510b1049","aa812862-ab88-11e3-8a2e-a314510b1049","aa812863-ab88-11e3-8a2e-a314510b1049","aa812864-ab88-11e3-8a2e-a314510b1049","aa812865-ab88-11e3-8a2e-a314510b1049","aa812866-ab88-11e3-8a2e-a314510b1049","aa812867-ab88-11e3-8a2e-a314510b1049","aa812868-ab88-11e3-8a2e-a314510b1049"];
guidIndex=0;
groupId='01bce2e0-aab7-11e3-8d63-6f16b29e32cc';
groupName='Sonoma Partners';
createdBy='70d1abb0-e7cc-11e2-a03d-877f931d8db4';
props=['_id','__v','hgId','GroupId','GroupName','CreatedBy','ModifiedBy'];
function replaceHgid(obj){
    if (typeof obj=='object'){
        for(key in obj){
            if(obj.hasOwnProperty(key)){
                if(props.indexOf(key)>-1){
                    switch(key){
                        case '_id':
                            delete obj[key];
                            break;
                        case '__v':
                            delete obj[key];
                            break;
                        case 'hgId':
                            obj[key]=guids[guidIndex];
                            guidIndex+=1;
                            break;
                        case 'GroupId':
                            obj[key]=groupId;
                            break;
                        case 'GroupName':
                            obj[key]=groupName;
                            break;
                        case 'CreatedBy':
                            obj[key]=createdBy;
                            break;
                        case 'ModifiedBy':
                            obj[key]=createdBy;
                            break;
                    }

                }else if(typeof obj[key]=='object'){
                    console.log(obj[key]);
                    replaceHgid(obj[key]);
                }
            }
        }
    }
    return guidIndex;
}
function outputCards(){
    for(i=0;i<cards.length;i+=1){
        console.log(JSON.stringify(cards[i]));
    }
}
replaceHgid(cards);
outputCards();


{"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1386782824885,"Description":"Project-based Feedback for Developers","ExpireDate":1418318824901,"GroupId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","GroupName":"Sonoma Partners","IsTemplate":false,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","ModifiedDate":1393353781376,"OriginalId":"74179130-6289-11e3-9338-31c787f5f5ee","PeopleTypes":[{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Manager"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":false,"PeopleTypeName":"Subject"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Peer"}],"Sections":[{"ModifiedDate":1393353781283,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781283,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c340-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1393353781349,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781349,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c341-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":1,"QuestionText":"Work well with team members (offered to help others complete items,committed code frequently, adhered to project-specific process, etc.)?"},{"QuestionHelp":"","ModifiedDate":1393353781348,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781348,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c342-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":2,"QuestionText":"Understand the customer's needs to ensure the right problems were solved in the right way (questioned requirements when appropriate and demonstrated forethought into how the system would actually be used)?"},{"QuestionHelp":"","ModifiedDate":1393353781348,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781348,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c343-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":3,"QuestionText":"Proactively communicate status, delays, challenges and/or potential perf problems in a timely manner?"},{"QuestionHelp":"","ModifiedDate":1393353781347,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781347,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c344-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":4,"QuestionText":"Do what it takes to get the job done, included working late or on weekends when necessary?"},{"QuestionHelp":"","ModifiedDate":1393353781288,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781288,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c345-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":5,"QuestionText":"Handle item complexity equivalent with their role?"},{"QuestionHelp":"","ModifiedDate":1393353781287,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781287,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c346-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":6,"QuestionText":"Complete items within agreed upon estimates and deadlines?"},{"QuestionHelp":"","ModifiedDate":1393353781287,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781287,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c347-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":7,"QuestionText":"Spend an appropriate amount of time seeking solutions on their own before asking for help and then apply the help effectively?"},{"QuestionHelp":"","ModifiedDate":1393353781286,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781286,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c348-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":8,"QuestionText":"Write respectful and explainable code (problems were solved efficiently, follows Sonoma standards and it's clear such that others can maintain it later)?"},{"QuestionHelp":"","ModifiedDate":1393353781285,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781285,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c349-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":9,"QuestionText":"Balance multiple projects and effectively prioritize project work?"},{"QuestionHelp":"","ModifiedDate":1393353781284,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781284,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c34a-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":10,"QuestionText":"Conduct good QA (tested code to make sure it works before going to QA and had complex code reviewed)?"},{"QuestionHelp":"","ModifiedDate":1393353781284,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781284,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c34b-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":11,"QuestionText":"Please use the space below to provide additional feedback."},{"QuestionHelp":"By entering your name, the reviewee will know which feedback is yours.","ModifiedDate":1393353781283,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781283,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c34c-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"ShortText","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":true,"SortOrder":12,"QuestionText":"Enter your name here:"}],"SortOrder":1,"Description":"","Title":"To what extent did the Developer..."},{"ModifiedDate":1393353781281,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781281,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c34d-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1393353781281,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1393353781281,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c34e-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Reviewed by Coach","Value":1}],"AnswerType":"CheckBox","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":1,"QuestionText":"Coach Review is complete and ready to send to Reviewee"}],"SortOrder":2,"Description":"Acknowledgement that review is ready to share","Title":"Coach Review"}],"Status":"ReadyToAssign","SubjectManagerOnly":false,"Title":"Developer","Type":"Project","hgId":"9476c34f-ab88-11e3-99b1-73f58747ac10"}

{"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1386782824885,"Description":"Project-based Feedback for Tech Leads","ExpireDate":1418318824901,"GroupId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","GroupName":"Sonoma Partners","IsTemplate":false,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","ModifiedDate":1392914019824,"OriginalId":"fb244c70-7f78-11e3-b0ed-a70f560364d2","PeopleTypes":[{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Manager"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":false,"PeopleTypeName":"Subject"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Peer"}],"Sections":[{"ModifiedDate":1392914019783,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019783,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c350-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1392914019794,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019794,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c351-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":1,"QuestionText":"Set and abide by deadlines and estimates?"},{"QuestionHelp":"","ModifiedDate":1392914019794,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019794,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c352-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":2,"QuestionText":"Write quality items, design documentation and release notes?"},{"QuestionHelp":"","ModifiedDate":1392914019792,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019792,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c353-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":3,"QuestionText":"Distribute interesting work and not keep the all difficult challenges for him/herself?"},{"QuestionHelp":"","ModifiedDate":1392914019790,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019790,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c354-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":4,"QuestionText":"Demonstrate expertise at developing for and customizing CRM/SFDC?"},{"QuestionHelp":"","ModifiedDate":1392914019789,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019789,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c355-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":5,"QuestionText":"Offer solutions to client problems instead of just taking tasks?"},{"QuestionHelp":"","ModifiedDate":1392914019788,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019788,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c356-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":6,"QuestionText":"Speak up/participate during client meetings?"},{"QuestionHelp":"","ModifiedDate":1392914019787,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019787,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c357-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":7,"QuestionText":"Present a united front with the Project Manager (to both the client and Sonoman project team members)?"},{"QuestionHelp":"","ModifiedDate":1392914019786,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019786,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c358-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":8,"QuestionText":"Communicate what he/she will do and follow through?"},{"QuestionHelp":"","ModifiedDate":1392914019786,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019786,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c359-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":9,"QuestionText":"Please use the space below to provide additional feedback."},{"QuestionHelp":"","ModifiedDate":1392914019785,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019785,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c35a-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Reviewed by Coach","Value":1}],"AnswerType":"CheckBox","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":10,"QuestionText":"Coach Review is complete and ready to send to Reviewee"},{"QuestionHelp":"By entering your name, the reviewee will know which feedback is yours.","ModifiedDate":1392914019783,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392914019783,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c35b-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"ShortText","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":11,"QuestionText":"Enter your name here:"}],"SortOrder":1,"Description":"","Title":"To what extent did the Tech Lead..."}],"Status":"ReadyToAssign","SubjectManagerOnly":false,"Title":"Tech Lead","Type":"Project","hgId":"9476c35c-ab88-11e3-99b1-73f58747ac10"}

{"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1386782824885,"Description":"Project-based Feedback for QA","ExpireDate":1418318824901,"GroupId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","GroupName":"Sonoma Partners","IsTemplate":false,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","ModifiedDate":1392913960858,"OriginalId":"fb244c70-7f78-11e3-b0ed-a70f560364d2","PeopleTypes":[{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Manager"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":false,"PeopleTypeName":"Subject"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Peer"}],"Sections":[{"ModifiedDate":1392913960654,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960654,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c35d-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1392913960696,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960696,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c35e-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":1,"QuestionText":"Test beyond what's on the test plan and/or in the functional spec (e.g. think of alternate flows, exercise destructive type thinking)?"},{"QuestionHelp":"","ModifiedDate":1392913960694,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960694,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c35f-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":2,"QuestionText":"Identify conflicting or missing requirements and collaborate on solutions?"},{"QuestionHelp":"","ModifiedDate":1392913960689,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960689,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c360-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":3,"QuestionText":"Write detailed, well-written test plans with client usage in mind and update them as needed?"},{"QuestionHelp":"","ModifiedDate":1392913960686,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960686,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c361-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":4,"QuestionText":"Do what it takes to get the job done, included working late or on weekends when necessary?"},{"QuestionHelp":"","ModifiedDate":1392913960682,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960682,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c362-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":5,"QuestionText":"Work effectively with project team members (e.g. help drive deadlines, schedule test plan reviews and challenge development when appropriate)?"},{"QuestionHelp":"","ModifiedDate":1392913960678,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960678,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c363-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":6,"QuestionText":"Capture and write very detailed items/defects (e.g. provide specific examples, steps to reproduce and screen shots where applicable)?"},{"QuestionHelp":"","ModifiedDate":1392913960675,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960675,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c364-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":7,"QuestionText":"Work autonomously with minimal direction?"},{"QuestionHelp":"","ModifiedDate":1392913960670,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960670,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c365-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":8,"QuestionText":"Proactively communicate status, delays, challenges and/or risks in a timely manner?"},{"QuestionHelp":"","ModifiedDate":1392913960666,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960666,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c366-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":9,"QuestionText":"Functionally test the requirements based on the functional spec and supporting documents (e.g. actually log in as each security role instead of just reviewing the security matrix)?"},{"QuestionHelp":"","ModifiedDate":1392913960665,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960664,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c367-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":10,"QuestionText":"Please use the space below to provide additional feedback."},{"QuestionHelp":"","ModifiedDate":1392913960662,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960662,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c368-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Reviewed by Coach","Value":1}],"AnswerType":"CheckBox","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":11,"QuestionText":"Coach Review is complete and ready to send to Reviewee"},{"QuestionHelp":"By entering your name, the reviewee will know which feedback is yours.","ModifiedDate":1392913960655,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913960655,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c369-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"ShortText","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":12,"QuestionText":"Enter your name here:"}],"SortOrder":1,"Description":"","Title":"To what extent did the QA..."}],"Status":"ReadyToAssign","SubjectManagerOnly":false,"Title":"QA","Type":"Project","hgId":"9476c36a-ab88-11e3-99b1-73f58747ac10"}

{"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1389553007796,"Description":"Project-based Feedback for Project Managers","ExpireDate":1421089007798,"GroupId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","GroupName":"Sonoma Partners","IsTemplate":false,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","ModifiedDate":1392913881783,"OriginalId":"705b3e60-8468-11e3-bec2-71481195ed0c","PeopleTypes":[{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Manager"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":false,"PeopleTypeName":"Subject"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Peer"}],"Sections":[{"ModifiedDate":1392913881756,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881756,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c36b-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"•\tIs aware of project goals and sets item deadlines and estimates accordingly.\n•\tMakes development team aware of code complete due date and treats it as a real deadline.\n•\tEffectively conveys technical requirements to development team","ModifiedDate":1392913881764,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881764,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c36c-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":1,"QuestionText":"To what extent did the Project Manager exhibit \"Be a Good Communicator\"?"},{"QuestionHelp":"•\tDemonstrates ability to push back on client or team member(s) when needed.\n•\tEffectively aligns/partners with Tech Lead.\n•\tGets the right folks involved / escalates issues appropriately, as needed.\n•\tDemonstrates appropriate sense of urgency/level of responsiveness.\n•\tAdapts well to unforeseen changes in scope/direction.\n•\tDemonstrates a consultative approach (offers solutions beyond being a tasktaker; challenges client and team members appropriately).","ModifiedDate":1392913881763,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881763,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c36d-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":2,"QuestionText":"To what extent did the Project Manager exhibit \"Think Service First\"?"},{"QuestionHelp":"•\tPays attention to details.\n•\tProvides client presentable documentation.\n•\tEnsures that the final deliverables are tested thoroughly and meet the client’s expectations.","ModifiedDate":1392913881762,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881762,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c36e-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":3,"QuestionText":"To what extent did the Project Manager exhibit \"Deliver Quality Work\"?"},{"QuestionHelp":"•\tDemonstrates ability to fight fires (server crashes, production down, urgent issues, unhappy clients, etc.) by remaining calm, prioritizing tasks, troubleshooting tough problems, communicating well with clients and team members and being available even when inconvenient like nights and weekends.\n•\tRemains committed to seeing the project through to completion.\n•\tEffectively manages resources, expectations and timelines; Understands what’s going on at all times during the project with the right amount of detail.","ModifiedDate":1392913881761,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881761,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c36f-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":4,"QuestionText":"To what extent did the Project Manager exhibit \"Take Ownership\"?"},{"QuestionHelp":"•\tFollows through on commitments (says what they’ll do then does it).\n\t- If they say they’ll email a file “by 5:00 today”, it happens.\n\t- If they don’t know an answer, they reply stating they’ll get back to the individual/team with an update by X date and do so.\n•\tWillingness to get into the weeds and be hands on when needed.","ModifiedDate":1392913881760,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881760,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c370-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":[],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":5,"QuestionText":"To what extent did the Project Manager exhibit \"Just Do It (Don't Talk About It)\"?"},{"QuestionHelp":"•\tProactively engages and motivates team members; Fosters team unity \n•\tProvides the right balance of positive feedback/encouragement and constructive feedback.\n•\tAttentive to feedback/approachable to team members \n•\tDemonstrates awareness of individual’s workloads to prevent or minimize burnout among team members (strikes right balance between task-focus/person-focus).","ModifiedDate":1392913881758,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881758,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c371-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":6,"QuestionText":"To what extent did the Project Manager exhibit \"Foster a Positive Environment\"?"},{"QuestionHelp":"","ModifiedDate":1392913881758,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881758,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c372-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":7,"QuestionText":"Please use the space below to provide additional feedback."},{"QuestionHelp":"","ModifiedDate":1392913881758,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881758,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c373-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Reviewed by Coach","Value":1}],"AnswerType":"CheckBox","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":8,"QuestionText":"Coach Review is complete and ready to send to Reviewee"},{"QuestionHelp":"By entering your name, the reviewee will know which feedback is yours.","ModifiedDate":1392913881757,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913881757,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c374-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"ShortText","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":true,"SortOrder":9,"QuestionText":"Enter your name here:"}],"SortOrder":1,"Description":"","Title":""}],"Status":"ReadyToAssign","SubjectManagerOnly":false,"Title":"Project Manager","Type":"Project","hgId":"9476c375-ab88-11e3-99b1-73f58747ac10"}

{"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1389553007796,"Description":"Project-based Feedback for Discovery Projects","ExpireDate":1421089007798,"GroupId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","GroupName":"Sonoma Partners","IsTemplate":false,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","ModifiedDate":1392913835140,"OriginalId":"705b3e60-8468-11e3-bec2-71481195ed0c","PeopleTypes":[{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Manager"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":false,"PeopleTypeName":"Subject"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Peer"}],"Sections":[{"ModifiedDate":1392913835009,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835009,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c376-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"•\tIs aware of project goals and sets project deadlines and estimates accordingly.\n•\tInstills confidence in the customer (articulates their needs well, delivers appropriate message, and responds in a timely manner).\n•\tFacilitates requirements gathering effectively (manages conversation well, involves customer appropriately and collects appropriate level of detail).\n•\tManages client expectations effectively (presents right-sized solutions with sensitivity to budget and clearly communicates milestones and any challenges effectively).\n•\tCommunicates with all interested parties as appropriate (Sonoma, client and/or vendor resources).\n•\tComplements sales efforts effectively by reinforcing value proposition.","ModifiedDate":1392913835021,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835021,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c377-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":1,"QuestionText":"To what extent did the Sonoman exhibit \"Be a Good Communicator\"?"},{"QuestionHelp":"•\tDemonstrates ability to push back on client and/or team member(s) regarding budget, scope timeline, etc. when needed.\n•\tDemonstrates appropriate sense of urgency/level of responsiveness.\n•\tAdapts well to unforeseen changes in scope/direction.\n•\tDemonstrates a consultative approach by offering solutions beyond being a task-taker and challenging client/team members appropriately.","ModifiedDate":1392913835020,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835020,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c378-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":2,"QuestionText":"To what extent did the Sonoman exhibit \"Think Service First\"?"},{"QuestionHelp":"•\tPays attention to details.\n•\tProvides client presentable documentation (proper grammar, consistent formatting).\n•\tEnsures that the final deliverables meet the client’s expectations.\n•\tAccurately captures/documents business and technical requirements and with the right amount of detail.","ModifiedDate":1392913835019,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835019,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c379-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":3,"QuestionText":"To what extent did the Sonoman exhibit \"Deliver Quality Work\"?"},{"QuestionHelp":"•\tDemonstrates ability to handle challenging/sensitive conversations well (server crashes, production down, urgent issues, unhappy clients, etc.) by remaining calm, prioritizing tasks, troubleshooting tough problems and communicating well with clients and team members.\n•\tMakes oneself available even when inconvenient like nights and weekends.\n•\tRemains committed to seeing the project through to completion.\n•\tEffectively manages resources, expectations and timelines; Understands what’s going on at all times during the project","ModifiedDate":1392913835018,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835018,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c37a-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":4,"QuestionText":"To what extent did the Sonoman exhibit \"Take Ownership\"?"},{"QuestionHelp":"•\tFollows through on commitments (says what they’ll do then does it).\n\t- If they say they’ll email a file “by 5:00 today”, it happens.\n\t- If they don’t know an answer, they reply stating they’ll get back to the individual/team with an update by X date and do so.\n•\tWillingness to get into the weeds and be hands on when needed.","ModifiedDate":1392913835017,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835017,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c37b-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":5,"QuestionText":"To what extent did the Sonoman exhibit \"Just Do It (Don't Talk About It)\"?"},{"QuestionHelp":"•\tUnderstands the client’s business, challenges and goals for the project (not just what’s captured in the SOW) and has a deep understanding of their business processes.\n•\tPresents feasible solutions that meet the client’s business needs.\n•\tEffectively conveys industry and product expertise, represents Sonoma as a SME and presents oneself as a Trusted Advisor (offers best practices, lessons learned, industry and/or technical knowledge).","ModifiedDate":1392913835014,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835014,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c37c-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":6,"QuestionText":"To what extent did the Sonoman exhibit \"Think in Business Terms\"?"},{"QuestionHelp":"","ModifiedDate":1392913835013,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835013,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c37d-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":7,"QuestionText":"Please use the space below to provide additional feedback."},{"QuestionHelp":"","ModifiedDate":1392913835012,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835012,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c37e-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Reviewed by Coach","Value":1}],"AnswerType":"CheckBox","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":8,"QuestionText":"Coach Review is complete and ready to send to Reviewee"},{"QuestionHelp":"By entering your name, the reviewee will know which feedback is yours.","ModifiedDate":1392913835009,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913835009,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c37f-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"ShortText","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":true,"SortOrder":9,"QuestionText":"Enter your name here:"}],"SortOrder":1,"Description":"","Title":""}],"Status":"ReadyToAssign","SubjectManagerOnly":false,"Title":"Discovery Projects","Type":"Project","hgId":"9476c380-ab88-11e3-99b1-73f58747ac10"}

{"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1389553007796,"Description":"Project-based Feedback for Business Analysts","ExpireDate":1421089007798,"GroupId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","GroupName":"Sonoma Partners","IsTemplate":false,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","ModifiedDate":1392913762735,"OriginalId":"705b3e60-8468-11e3-bec2-71481195ed0c","PeopleTypes":[{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Manager"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":false,"PeopleTypeName":"Subject"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Peer"}],"Sections":[{"ModifiedDate":1392913762680,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762680,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c381-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"•\tIs aware of project goals and adheres to deadlines and estimates accordingly.\n•\tProactively keeps PM and Tech Lead informed of status and issues with deadlines/estimates.\n•\tHelps keep development team aware of code complete due date and assists in planning timeline of features and items accordingly.\n•\tEffectively conveys/clarifies business and/or technical requirements to development team.","ModifiedDate":1392913762693,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762693,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c382-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":1,"QuestionText":"To what extent did the Business Analyst exhibit \"Be a Good Communicator\"?"},{"QuestionHelp":"•\tDemonstrates ability to push back on client and/or team member(s) when needed.\n•\tGets the right folks involved/escalates issues appropriately.\n•\tDemonstrates appropriate sense of urgency/level of responsiveness.\n•\tAdapts well to unforeseen changes in scope/direction.\n•\tDemonstrates a consultative approach (offers solutions beyond being a task taker; challenges client and/or team members appropriately).","ModifiedDate":1392913762692,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762692,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c383-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":2,"QuestionText":"To what extent did the Business Analyst exhibit \"Think Service First\"?"},{"QuestionHelp":"•\tMaintains strong attention to detail throughout the entire project.\n•\tCreates client presentable documentation (proper grammar, consistent formatting).\n•\tWrites documentation that clearly captures client requirements, both functionally and technically; makes sure all documents are updated as needed.\n•\tTakes good notes.\n•\tEnsures that the final deliverables are tested thoroughly and meet the client’s expectations.","ModifiedDate":1392913762691,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762691,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c384-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":3,"QuestionText":"To what extent did the Business Analyst exhibit \"Deliver Quality Work\"?"},{"QuestionHelp":"•\tAssists Project Manager in fighting fires (server crashes, production down, urgent issues, unhappy clients, etc.) by remaining calm, prioritizing tasks, troubleshooting tough problems, communicating well with clients and team members and being available even when inconvenient like nights and weekends.\n•\tRemains committed to seeing the project through to completion.\n•\tProactively supports Project Manager (understands what’s going on at all times during the project and seeks out ways to help balance work load; takes ownership of larger deliverables, takes on work they may not typically do).\n•\tEnsures deliverables meet the overall business needs of the client.","ModifiedDate":1392913762688,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762688,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c385-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":4,"QuestionText":"To what extent did the Business Analyst exhibit \"Take Ownership\"?"},{"QuestionHelp":"•\tFollows through on commitments (says what they’ll do then does it).\n\t- If they say they’ll email a file “by 5:00 today”, it happens.\n\t- If they don’t know an answer, they reply stating they’ll get back to the individual/team with an update by X date and do so.\n•\tWillingness to get into the weeds and be hands.\n•\tFollows project process and adheres to documentation standards.\n•\tWorks autonomously with minimal direction from Project Manager.\n•\tFinds ways to facilitate smoother development and/or helps client understand system better through anticipating development questions and providing detailed documentation (e.g. security role matrix or other non-standard documentation).\n•\tDoes high quality work; doesn’t just check a box as done.","ModifiedDate":1392913762685,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762685,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c386-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Often","Value":2},{"Text":"Sometimes","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":5,"QuestionText":"To what extent did the Business Analyst exhibit \"Just Do It (Don't Talk About It)\"?"},{"QuestionHelp":"•\tProactively engages and motivates team members; fosters team unity.\n•\tProvides the right balance of positive feedback/encouragement and constructive feedback.\n•\tIs responsive to feedback/approachable to team members.\n•\tDemonstrates awareness of individual’s workloads to prevent or minimize burnout among team members (strikes right balance between task-focus/person-focus) and communicates concerns to Project Manager as necessary.","ModifiedDate":1392913762684,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762684,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c387-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Not Enough","Value":1},{"Text":"Sometimes","Value":2},{"Text":"Often","Value":3},{"Text":"Always","Value":4}],"AnswerType":"ScaleRating","AllowComments":true,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":6,"QuestionText":"To what extent did the Business Analyst exhibit \"Foster a Positive Environment\"?"},{"QuestionHelp":"","ModifiedDate":1392913762683,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762683,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c388-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":7,"QuestionText":"Please use the space below to provide additional feedback."},{"QuestionHelp":"","ModifiedDate":1392913762682,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762682,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c389-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"Reviewed by Coach","Value":1}],"AnswerType":"CheckBox","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":8,"QuestionText":"Coach Review is complete and ready to send to Reviewee"},{"QuestionHelp":"By entering your name, the reviewee will know which feedback is yours.","ModifiedDate":1392913762681,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392913762681,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c38a-ab88-11e3-99b1-73f58747ac10","Answers":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"ShortText","AllowComments":false,"OptionalTo":["Peer"],"ToBeAnsweredBy":["Peer"],"Confidential":true,"SortOrder":9,"QuestionText":"Enter your name here:"}],"SortOrder":1,"Description":"","Title":""}],"Status":"ReadyToAssign","SubjectManagerOnly":false,"Title":"Business Analyst","Type":"Project","hgId":"9476c38b-ab88-11e3-99b1-73f58747ac10"}

{"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1392129475423,"Description":"","ExpireDate":1423665475428,"GroupId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","GroupName":"Sonoma Partners","IsTemplate":false,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","ModifiedDate":1394553854373,"OriginalId":"248a38c0-9dd5-11e3-a6a4-09ad44eb1351","PeopleTypes":[{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Manager"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Subject"},{"AllowMultiple":false,"Required":false,"ContainQuestionForMe":true,"PeopleTypeName":"Peer"}],"Sections":[{"ModifiedDate":1394553854217,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854217,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c38c-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1394553854221,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854221,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c38d-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":[],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":1,"QuestionText":"Clear Strength #1"},{"QuestionHelp":"","ModifiedDate":1394553854219,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854219,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c38e-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Subject"],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":2,"QuestionText":"Clear Strength #2"},{"QuestionHelp":"","ModifiedDate":1394553854218,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854218,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c38f-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Subject"],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":3,"QuestionText":"Clear Strength #3"}],"SortOrder":1,"Description":"Please select up to 3 clear strengths from the How to Be Awesome list (found on Sharepoint at Operations > HR > Employee Development).","Title":"Clear Strengths (Employee Selection)"},{"ModifiedDate":1394553854200,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854200,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c390-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1394553854215,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854215,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c391-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":1,"QuestionText":"Clear Strength #1"},{"QuestionHelp":"","ModifiedDate":1394553854214,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854214,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c392-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":2,"QuestionText":"Clear Strength #2"},{"QuestionHelp":"","ModifiedDate":1394553854201,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854201,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c393-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":3,"QuestionText":"Clear Strength #3"}],"SortOrder":2,"Description":"Please select up to 3 clear strengths from the How to Be Awesome list.","Title":"Clear Strengths (Manager Selection)"},{"ModifiedDate":1394553854185,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854185,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c394-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1394553854198,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854198,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c395-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":1,"QuestionText":"Growth Area #1"},{"QuestionHelp":"","ModifiedDate":1394553854187,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854187,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c396-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":2,"QuestionText":"Growth Area #2"},{"QuestionHelp":"","ModifiedDate":1394553854186,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854186,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c397-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":3,"QuestionText":"Growth Area #3"}],"SortOrder":3,"Description":"Please select up to 3 growth areas from the How to Be Awesome list.  When selecting growth areas, consider items in which additional focus/attention will be mutually beneficial to you and Sonoma, either because you know improvement is needed or you know the additional attention will help you and/or other Sonomans add more value to Sonoma and its clients.","Title":"Growth Areas (Employee Selection)"},{"ModifiedDate":1394553854177,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854177,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c398-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"","ModifiedDate":1394553854180,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854180,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c399-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":1,"QuestionText":"Growth Area #1"},{"QuestionHelp":"","ModifiedDate":1394553854179,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854179,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c39a-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":2,"QuestionText":"Growth Area #2"},{"QuestionHelp":"","ModifiedDate":1394553854177,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854177,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c39b-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"Act Like a Pro","Value":1},{"Text":"Deliver Quality Work","Value":2},{"Text":"Be a Good Communicator","Value":3},{"Text":"Just Do It (Don't Talk About It)","Value":4},{"Text":"Foster a Positive Environment","Value":5},{"Text":"Manage Yourself","Value":6},{"Text":"Be Fun","Value":7},{"Text":"Solve Problems","Value":8},{"Text":"Know Your Stuff","Value":9},{"Text":"Think Service First","Value":10},{"Text":"Do More Than the Bare Minimum","Value":11},{"Text":"Take Ownership","Value":12},{"Text":"Show Initiative","Value":13},{"Text":"Think in Business Terms","Value":14},{"Text":"Get Invested Into Sonoma Partners","Value":15}],"AnswerType":"Option","AllowComments":true,"OptionalTo":["Manager","Subject"],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":3,"QuestionText":"Growth Area #3"}],"SortOrder":4,"Description":"Please review the list of How to Be Awesome items and select up to 3 clear strengths and 3 growth areas for the employee.  When selecting growth areas, consider items in which additional focus/attention will be mutually beneficial for the employee and Sonoma, either because improvement is needed or because the additional attention will help the employee and/or other Sonomans add more value to Sonoma and its clients.","Title":"Growth Areas (Manager Selection)"},{"ModifiedDate":1394553854176,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854176,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c39c-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"Use this section to share progress on or completion of current goals as well as suggest goals for the next review cycle.","ModifiedDate":1394553854176,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854176,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c39d-ab88-11e3-99b1-73f58747ac10","NAText":"N/A","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Subject"],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":1,"QuestionText":"Enter goals currently in progress or completed during this review cycle."}],"SortOrder":5,"Description":"","Title":"Goals (Optional)"},{"ModifiedDate":1394553854171,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854171,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c39e-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"Considerations for comment: overall level of satisfaction with your role, highlights of your recent accomplishments, peak experience(s), challenges you are facing, skills you want to learn or improve.","ModifiedDate":1394553854172,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854172,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c39f-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Subject"],"Confidential":false,"SortOrder":1,"QuestionText":"Employee Comments"},{"QuestionHelp":"Considerations for comment: positive behavioral examples of Awesome List items, suggested behavioral changes that will improve measurement of goals and/or Awesome List items and/or highlighted feedback from project-based feedback program.","ModifiedDate":1394553854171,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854171,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c3a0-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":2,"QuestionText":"Manager Comments"},{"QuestionHelp":"Consider using the following SBIR method when providing your feedback, being as specific as possible: \nSituation — Describe the situation in which you observed the employee\nBehavior — Describe the behavior you observed\nImpact — Describe the impact of that behavior on you or others who were present in the situation\nRequest – Describe the desired behavior you want going forward","ModifiedDate":1394553854171,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854171,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c3a1-ab88-11e3-99b1-73f58747ac10","NAText":"","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":[],"ToBeAnsweredBy":["Peer"],"Confidential":false,"SortOrder":3,"QuestionText":"Peer Comments - Please provide feedback for your colleague (both appreciative and constructive)"}],"SortOrder":6,"Description":"","Title":"Comments"},{"ModifiedDate":1394553854165,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854165,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c3a2-ab88-11e3-99b1-73f58747ac10","Questions":[{"QuestionHelp":"Use this section if/when additional peer feedback is provided from peers not originally included in the cycle.","ModifiedDate":1394553854165,"ModifiedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","CreatedDate":1394553854165,"CreatedBy":"70d1abb0-e7cc-11e2-a03d-877f931d8db4","hgId":"9476c3a3-ab88-11e3-99b1-73f58747ac10","NAText":"N/A","NAEnable":false,"Answers":[],"RecognitionFilter":[],"AnswerSelectors":[{"Text":"","Value":1}],"AnswerType":"Paragraph","AllowComments":false,"OptionalTo":["Manager"],"ToBeAnsweredBy":["Manager"],"Confidential":false,"SortOrder":1,"QuestionText":"Additional Peer Feedback"}],"SortOrder":7,"Description":"Only used if feedback is solicited from peers not originally included in cycle.","Title":"Additional Peer Feedback"}],"Status":"ReadyToAssign","SubjectManagerOnly":false,"Title":"Mid-Cycle Performance Review","Type":"General","hgId":"aa810150-ab88-11e3-8a2e-a314510b1049"}
