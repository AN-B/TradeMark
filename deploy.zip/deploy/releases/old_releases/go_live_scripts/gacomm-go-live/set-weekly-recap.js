group = db.Group.findOne({GroupName:"GA Communication"});
if (group && group.hgId) {
    db.Member.update({'GroupId' : group.hgId}, {$set : {'Preference.RecapType' : 'Weekly'}}, {multi : true});
}