// this script checks if the username equals the primary email address
load("../../db-scripts/commonDB.js");
setEnv("prod");

switchDB("hgcommon");
group=db.Group.findOne({GroupName:'Keno Kozie'});
if (group && group.hgId) {
    members=db.UserInfo.find({"Preference.DefaultGroupId":group.hgId},{_id:0,UserName:1,"UserPersonal.PrimaryEmail":1});
    if (members && members.length) {
        members.map(function(mem){
            if (mem.UserName !== mem.UserPersonal.PrimaryEmail) {
                print(mem.UserName);
            }
        });
    }
}