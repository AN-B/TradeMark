group=db.Group.findOne({GroupName:'Spring Venture Group'});
if (group && group.hgId) {
    db.Member.update({GroupId:group.hgId},{$inc:{StartingDate:21600000}},{multi:true});
    db.UserInfo.update({"Preference.DefaultGroupId":group.hgId},{$inc:{"UserPersonal.Birthdate":21600000}},{multi:true});
    db.UserInfoWithToken.update({"Preference.DefaultGroupId":group.hgId},{$inc:{"UserPersonal.Birthdate":21600000}},{multi:true});
}
