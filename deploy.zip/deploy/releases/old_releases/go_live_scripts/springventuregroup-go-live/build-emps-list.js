group=db.Group.findOne({GroupName:'Spring Venture Group'});
if (group && group.hgId) {
    members=db.Member.aggregate({$match:{GroupId:group.hgId}},{$project:{_id:0,FirstName:1,LastName:1,UserId:1}}).result;
    for(i=0;i<members.length;i++){
        print (members[i].FirstName + members[i].LastName + '.jpg:' + members[i].UserId + '.jpg');
    }
}
