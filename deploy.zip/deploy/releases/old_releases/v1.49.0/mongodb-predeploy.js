load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");
/* 
remove all the tag documents that are not associated to any tracks or reviews
*/
db.Tag.remove({"Entity":{$size:0}});


//Fix Bad Team Data in uat
var query = {};
var badTeamIdsWithNull = {};
// var badTeamIdsWithNullMembers = {};
db.Team.find(query).forEach(function(item) {
    var tMemebers = item.TeamMembers;
    tMemebers.forEach(function(member) {
        if (member === null) {
            if (!badTeamIdsWithNull[item.hgId]) {
                badTeamIdsWithNull[item.hgId] = item.hgId;
            }
        } 
        // Section does not exist
        // else if (member.MemberId === undefined || member.MemberId === null ||
        //             member.TeamId === undefined ||  member.TeamId === null) {
        //         if (!badTeamIdsWithNullMembers[item.hgId]) {
        //             badTeamIdsWithNullMembers[item.hgId] = item.hgId;
        //         }
        // }
    });
});

print('Teams with Null Member Records');
printjson(badTeamIdsWithNull);

for (key in badTeamIdsWithNull) {
    if (badTeamIdsWithNull.hasOwnProperty(key)) {
        team = db.Team.findOne({hgId : badTeamIdsWithNull[key]});
        var result = team.TeamMembers.filter(function (item) {
        	return (item !== null && item !== undefined);
        });
        team.TeamMembers = result;
		db.Team.save(team);
    }
}


//After Release Need to Upload 
// New Tango Card Provision Files
// hgapp/Provision/TangoCards_Groupon.xlsx
// hgapp/Provision/TangoCards_0723_prod.xlsx (bass shop pro canada and boscov's card)