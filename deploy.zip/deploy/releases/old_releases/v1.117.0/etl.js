/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addReportIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.Report.db.collections.Report.ensureIndex({
                    _id: 1,
                    Status: 1,
                    ExpireDate: 1,
                    RequesterGroupId: 1,
                    RequesterMemberId: 1,
                    CreatedDate: 1
                }, {name: 'CoreDocIndex', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.Report.db.collections.Report.ensureIndex({
                    _id: 1,
                    RequesterUserId: 1,
                    Status: 1,
                    ReportTypeName: 1,
                    CreatedDate: -1
                }, {name: 'SearchIndex', background: true }, callback);
            })
        ], fcallback);
    }

    function updateUnProcessedReports(callback) {
        EntityCache.Report.aggregate([
            {$match: {
                Status: 'Processing'
            }},
            {$group: {
                _id: {
                    hgId: "$hgId",
                    RequesterMemberId: '$RequesterMemberId',
                    ReportName: '$ReportTypeName',
                    Diff:  {"$subtract": [Date.now(),  "$CreatedDate" ]}
                }
            }},
            { $match: { '_id.Diff': { $gte: 3600000}}} // 1 hour
        ], function (error, data) {
            if (error || !data || !data.length) {
                return callback(error);
            }
            EntityCache.Report.update({
                hgId: {$in: data.map(function (item) {
                    return item._id.hgId;
                })}
            }, {
                $set: {
                    ModifiedDate: Date.now(),
                    Status: 'Expired'
                }
            }, {
                multi: true
            }, callback);
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            addReportIndex,
            updateUnProcessedReports
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
