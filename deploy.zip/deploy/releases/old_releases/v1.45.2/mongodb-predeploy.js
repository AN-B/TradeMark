load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");
//Remove EndingDate from All Active Members
db.Member.update({MembershipStatus : 'Active'}, {$unset : { 'EndingDate' : ''}}, {multi : true})