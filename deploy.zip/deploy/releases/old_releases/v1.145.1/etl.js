/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addSuccessionPlanningQuestion(callback) {
        EntityCache.FeedbackCard.remove({
            Type: "SuccessionPlanning",
            Category: "System"
        }, function (error, card) {
            if (error) {
                return callback(error);
            }
            var feedbackCard = new EntityCache.FeedbackCard({
                "hgId" : "c0e06236-2e79-11e6-af1e-6f4f73991fa2",
                "Category" : "System",
                "Type" : "SuccessionPlanning",
                "Status" : "Active",
                "CreatedDate" : Date.now(),
                "CreatedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                "SinglePageQuestion" : false,
                "UseSections" : false,
                "Sections" : [ 
                    {
                        "Type" : "Generic",
                        "hgId" : "c0e06230-2e79-11e6-af1e-6f4f73991fa2",
                        "Questions" : [ 
                            {
                                "Tag" : "Performance",
                                "NotApplicableOptionText" : "",
                                "QuestionHelp" : "",
                                "Question" : "Has performance problem",
                                "ModifiedDate" : Date.now(),
                                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "CreatedDate" : Date.now(),
                                "CreatedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "hgId" : "c0e06231-2e79-11e6-af1e-6f4f73991fa2",
                                "ToBeAnsweredBy" : [],
                                "SortOrder" : 0,
                                "AnswerSelector" : [ 
                                    {
                                        "Order" : 0,
                                        "Value" : 4,
                                        "Text" : "Disagree"
                                    }, 
                                    {
                                        "Order" : 1,
                                        "Value" : 3,
                                        "Text" : "Slightly Disagree"
                                    }, 
                                    {
                                        "Order" : 2,
                                        "Value" : 2,
                                        "Text" : "Neutral"
                                    }, 
                                    {
                                        "Order" : 3,
                                        "Value" : 1,
                                        "Text" : "Slightly Agree"
                                    }, 
                                    {
                                        "Order" : 4,
                                        "Value" : 0,
                                        "Text" : "Agree"
                                    }
                                ],
                                "Answers" : [],
                                "OptionalComment" : false,
                                "Required" : true,
                                "Type" : "RatingScale"
                            }, 
                            {
                                "Tag" : "FlightRisk",
                                "NotApplicableOptionText" : "",
                                "QuestionHelp" : "",
                                "Question" : "Is a flight risk",
                                "ModifiedDate" : Date.now(),
                                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "CreatedDate" : Date.now(),
                                "CreatedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "hgId" : "c0e06232-2e79-11e6-af1e-6f4f73991fa2",
                                "ToBeAnsweredBy" : [],
                                "SortOrder" : 1,
                                "AnswerSelector" : [ 
                                    {
                                        "Order" : 0,
                                        "Value" : 0,
                                        "Text" : "Disagree"
                                    }, 
                                    {
                                        "Order" : 1,
                                        "Value" : 1,
                                        "Text" : "Slightly Disagree"
                                    }, 
                                    {
                                        "Order" : 2,
                                        "Value" : 2,
                                        "Text" : "Neutral"
                                    }, 
                                    {
                                        "Order" : 3,
                                        "Value" : 3,
                                        "Text" : "Slightly Agree"
                                    }, 
                                    {
                                        "Order" : 4,
                                        "Value" : 4,
                                        "Text" : "Agree"
                                    }
                                ],
                                "Answers" : [],
                                "OptionalComment" : false,
                                "Required" : true,
                                "Type" : "RatingScale"
                            }, 
                            {
                                "Tag" : "Promotable",
                                "NotApplicableOptionText" : "",
                                "QuestionHelp" : "",
                                "Question" : "Would promote in six months",
                                "ModifiedDate" : Date.now(),
                                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "CreatedDate" : Date.now(),
                                "CreatedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "hgId" : "c0e06233-2e79-11e6-af1e-6f4f73991fa2",
                                "ToBeAnsweredBy" : [],
                                "SortOrder" : 2,
                                "AnswerSelector" : [ 
                                    {
                                        "Order" : 0,
                                        "Value" : 0,
                                        "Text" : "No"
                                    }, 
                                    {
                                        "Order" : 1,
                                        "Value" : 1,
                                        "Text" : "Yes"
                                    }
                                ],
                                "Answers" : [],
                                "OptionalComment" : false,
                                "Required" : true,
                                "Type" : "RatingScale"
                            }, 
                            {
                                "Tag" : "KeyToSuccess",
                                "NotApplicableOptionText" : "",
                                "QuestionHelp" : "",
                                "Question" : "Is a key to my team's success",
                                "ModifiedDate" : Date.now(),
                                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "CreatedDate" : Date.now(),
                                "CreatedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "hgId" : "c0e06234-2e79-11e6-af1e-6f4f73991fa2",
                                "ToBeAnsweredBy" : [],
                                "SortOrder" : 3,
                                "AnswerSelector" : [ 
                                    {
                                        "Order" : 0,
                                        "Value" : 0,
                                        "Text" : "Never"
                                    }, 
                                    {
                                        "Order" : 1,
                                        "Value" : 1,
                                        "Text" : "Rarely"
                                    }, 
                                    {
                                        "Order" : 2,
                                        "Value" : 2,
                                        "Text" : "Sometimes"
                                    }, 
                                    {
                                        "Order" : 3,
                                        "Value" : 3,
                                        "Text" : "Consistently"
                                    }, 
                                    {
                                        "Order" : 4,
                                        "Value" : 4,
                                        "Text" : "Always"
                                    }
                                ],
                                "Answers" : [],
                                "OptionalComment" : false,
                                "Required" : true,
                                "Type" : "RatingScale"
                            }, 
                            {
                                "Tag" : "Replaceable",
                                "NotApplicableOptionText" : "",
                                "QuestionHelp" : "",
                                "Question" : "Would be difficult to replace",
                                "ModifiedDate" : Date.now(),
                                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "CreatedDate" : Date.now(),
                                "CreatedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                                "hgId" : "c0e06235-2e79-11e6-af1e-6f4f73991fa2",
                                "ToBeAnsweredBy" : [],
                                "SortOrder" : 4,
                                "AnswerSelector" : [ 
                                    {
                                        "Order" : 0,
                                        "Value" : 0,
                                        "Text" : "Easy"
                                    }, 
                                    {
                                        "Order" : 1,
                                        "Value" : 1,
                                        "Text" : "Not Difficult"
                                    }, 
                                    {
                                        "Order" : 2,
                                        "Value" : 2,
                                        "Text" : "Somewhat"
                                    }, 
                                    {
                                        "Order" : 3,
                                        "Value" : 3,
                                        "Text" : "Very Difficult"
                                    }, 
                                    {
                                        "Order" : 4,
                                        "Value" : 4,
                                        "Text" : "Impossible"
                                    }
                                ],
                                "Answers" : [],
                                "OptionalComment" : false,
                                "Required" : true,
                                "Type" : "RatingScale"
                            }
                        ]
                    }
                ],
                "Description" : "",
                "Title" : "Succession Planning Template",
                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                "ModifiedDate" : Date.now()
            });
            feedbackCard.save(callback);
        });
    }
    function addFeedbackRequestExpiringReminderJob(callback) {
        var job = new EntityCache.Job({
            hgId: 'c873f260-07d1-11e6-a58d-57191decee5d',
            JobName: 'FeedbackRequestExpiringReminder',
            MethodName: 'FeedbackRequestExpiringReminder',
            PeriodType: 'Daily',
            Hour : 7,
            LatestTriggerDate : 0
        });
        EntityCache.Job.findOne({JobName: 'FeedbackRequestExpiringReminder'}, function (error, jobRecap) {
            if (error) {
                return callback(error);
            }
            if (jobRecap) {
                console.log("Already exist");
                return callback();
            }
            job.save(callback);
        });
    }

    function addExpireFeedbackRequestJob(callback) {
        var job = new EntityCache.Job({
            hgId: 'c873f267-07d1-11e6-a58d-57191decee5d',
            JobName: 'ExpireFeedbackRequest',
            MethodName: 'ExpireFeedbackRequest',
            PeriodType: 'Daily',
            Hour : 5,
            LatestTriggerDate : 0
        });
        EntityCache.Job.findOne({JobName: 'ExpireFeedbackRequest'}, function (error, jobRecap) {
            if (error) {
                return callback(error);
            }
            if (jobRecap) {
                console.log("Already exist");
                return callback();
            }
            job.save(callback);
        });
    }

    function addIndexes(callback) {
        Async.series([
            (function (callback) {
                EntityCache.FeedbackCycle.db.collections.FeedbackCycle.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackCycle.db.collections.FeedbackCycle.ensureIndex({
                    GroupId: 1,
                    Status: 1,
                    Type: 1,
                    Title: 1,
                    Description: 1
                }, {name: 'CoreDocIndex', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackCycleInitiator.db.collections.FeedbackCycleInitiator.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackCycleInitiator.db.collections.FeedbackCycleInitiator.ensureIndex({
                    CycleId: 1,
                    MemberId: 1,
                    DeliveryDate: 1,
                    Status: 1,
                    CycleType: 1,
                    GroupId: 1,
                    DepartmentId: 1,
                    LocationId: 1,
                    Role: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackSession.db.collections.FeedbackSession.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackSession.db.collections.FeedbackSession.ensureIndex({
                    InitiatorId: 1,
                    Status: 1,
                    'Participants.MemberId': 1,
                    GroupId: 1
                }, {name: 'CoreDocIndex', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackSession.db.collections.FeedbackSession.ensureIndex({
                    CycleId: 1,
                    Status: 1,
                    GroupId: 1
                }, {name: 'CycleIndex', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackSession.db.collections.FeedbackSession.ensureIndex({
                    GroupId: 1,
                    CycleType: 1,
                    Status: 1,
                    'Participants.MemberId': 1,
                    'Participants.ParticipantType': 1
                }, {name: 'CheckInIndex', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackSession.db.collections.FeedbackSession.ensureIndex({
                    Status: 1,
                    ExpirationDate: 1
                }, {name: 'ExpirationIndex', background: true, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackCycleCluster.db.collections.FeedbackCycleCluster.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackCycleCluster.db.collections.FeedbackCycleCluster.ensureIndex({
                    GroupId: 1,
                    CycleId: 1,
                    Status: 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackCard.db.collections.FeedbackCard.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.FeedbackCard.db.collections.FeedbackCard.ensureIndex({
                    GroupId: 1,
                    Status: 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            })
        ], callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addFeedbackRequestExpiringReminderJob,
            addExpireFeedbackRequestJob,
            addIndexes,
            addSuccessionPlanningQuestion
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
