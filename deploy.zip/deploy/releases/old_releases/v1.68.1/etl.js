load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgperka');

// script to update existing records for ProductItem
db.ProductItem.update({ProductType: { $exists: false }}, { $set : {ProductType : 'Store'}}, {multi: true});

// change all the blank scale rating answer selection text to display a period for fooda's reviews
switchDB('hgperform');
var reviews = db.PerformanceReview.find({CycleId:"c25ed480-7c9a-11e4-968e-cb70e04ca53b"});
if (reviews && reviews.length) {
    reviews.forEach(function (review) {
        review.Card.Sections.forEach(function (section) {
            section.Questions.filter(function (question) {
                return question.AnswerType == 'ScaleRating';
            }).forEach(function (question) {
                question.AnswerSelectors.filter(function (ansel) {
                    return ansel.Text == '';
                }).forEach(function (ansel) {
                    ansel.Text = '.';
                });
            });
        });
        db.PerformanceReview.save(review);
    })
}

// fix for sales demo sentiment
switchDB('hgcommon');
var groups = db.Group.find({"Preference.FeatureFlags.FeatureName":"ForSalesDemo"});
if (groups && groups.length) {
    groups.forEach(function (group) {
        print(group.GroupName);
        db.Sentiment.update({GroupId:group.hgId},{$set:{Status:"Pending",ExpireDate:4102466400000}},{multi:true});
        group.Preference.FeatureFlags.forEach(function (feature) {
            if (feature.FeatureName == 'EnableSentiment') {
                feature.FeatureEnabled = false;
            } else {
                group.Preference.FeatureFlags.push({
                    FeatureName: 'EnableSentiment',
                    FeatureEnabled: false
                });
            }
            db.Group.save(group);
        });
    });
}
