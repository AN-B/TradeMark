var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addRecognitionIndexes(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "hgId" : 1
                }, {name: 'hgIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "Template.GroupId" : 1,
                    "Status": 1,
                    "SuppressInFeed" : 1,
                    "ModifiedDate" : 1
                }, {name: 'FeedIndex_Part1', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "BatchId": 1
                }, {name: 'BatchIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "VisibilityLocations.hgId" : 1
                }, {name: 'LocationVisibility', background: true, check_keys: false, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "VisibilityMemberIds" : 1
                }, {name: 'MemberVisibility', background: true, check_keys: false, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "Sticky" : 1,
                    "Status" : 1,
                    "Template.GroupId" : 1,
                    "Template.Type" : 1
                }, {name: 'FeedNewsIndex', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "MemberId" : 1
                }, {name: 'MemberBookmarkIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.GroupRolePermissions.db.collections.GroupRolePermissions.ensureIndex({
                    "GroupId" : 1,
                    "RoleName" : 1
                }, {name: 'RolePermissionIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.CreditAccount.db.collections.CreditAccount.ensureIndex({
                    "OwnerId" : 1,
                    "AccountType" : 1
                }, {name: 'AccountTypeIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Comment.db.collections.Comment.ensureIndex({
                    "EntityId" : 1,
                    "Status" : 1,
                    "Type" : 1,
                    "CreateDate" : -1
                }, {name: 'CommentEntityIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Poll.db.collections.Poll.ensureIndex({
                    "MemberId" : 1,
                    "Status" : 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.PollQuestion.db.collections.PollQuestion.ensureIndex({
                    CreatedBy: 1,
                    Status: 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Team.db.collections.Team.ensureIndex({
                    "TeamMembers.MemberId" : 1,
                    "Status" : 1,
                    "Type" : 1
                }, {name: 'TeamMemberIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.MetricsUserActivity.db.collections.MetricsUserActivity.ensureIndex({
                   m: 1,
                   p: 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.MetricsMember.db.collections.MetricsMember.ensureIndex({
                   m: 1,
                   c: 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.MetricsMember.db.collections.MetricsMember.ensureIndex({
                    "GroupId" : 1,
                    "Status" : 1,
                    "IsPublic" : 1
                }, {name: 'GroupCommentIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "RecipientMember.hgId" : 1,
                    "Status" : 1,
                    "Template.Category" : 1,
                    "Template.Type" : 1
                }, {name: 'AchievementRoomIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.RecognitionTemplate.db.collections.RecognitionTemplate.ensureIndex({
                    "Category" : 1,
                    "GroupId" : 1,
                    "Type" : 1,
                    "DefaultBadge" : 1
                }, {name: 'SystemBadgeIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "RandCId" : 1,
                    "Status" : 1,
                    "Template.AccessLevel" : 1,
                    "SuppressInFeed" : 1
                }, {name: 'ProfileFeedIndex', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "ItemId" : 1
                }, {name: 'ProductItemIndex', background: true, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "NewsId" : 1
                }, {name: 'NewsIndex', background: true, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "GoalId" : 1
                }, {name: 'GoalIndex', background: true, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "PollQuestionId" : 1
                }, {name: 'PollIndex', background: true, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    "RecipientMember.hgId" : 1,
                    "Template.GroupId" : 1,
                    "Status" : 1,
                    "SuppressInFeed" : 1,
                    "Template.Category" : 1,
                    "Template.Type" : 1,
                    "ModifiedDate" : 1
                }, {name: 'FeedQuerySearchIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.UserInfo.db.collections.UserInfo.ensureIndex({
                    "Preference.DefaultGroupId" : 1,
                    "Preference.SuppressAnniversary" : 1
                }, {name: 'GroupIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.SurveyAnswer.db.collections.SurveyAnswer.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.SurveyAnswer.db.collections.SurveyAnswer.ensureIndex({
                    CurrentRoundId: 1,
                    Status: 1,
                    ExpireDate: 1
                }, {name: 'RoundIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Petition.db.collections.Petition.ensureIndex({
                    'Approvers.MemberId': 1,
                    EntityType: 1,
                    Status: 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            })
        ], fcallback);
    }
    function dropIndexes(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.dropIndexes({});
                callback();
            }),
            (function (callback) {
                EntityCache.CreditAccount.db.collections.CreditAccount.dropIndex("AccountType_1_OwnerId_1", function () {
                    callback();
                });
            }),
            (function (callback) {
                EntityCache.Comment.db.collections.Comment.dropIndex("EntityId_1_Type_1_CreateDate_-1", function () {
                    callback();
                });
            }),
            (function (callback) {
                EntityCache.Team.db.collections.Team.dropIndex("TeamMemberIndex", function () {
                    callback();
                });
            }),
            (function (callback) {
                EntityCache.Team.db.collections.Team.dropIndex("IsPublic_1_Status_1_CreatedDate_1_EntityId_1", function () {
                    callback();
                });
            }),
            (function (callback) {
                EntityCache.RecognitionTemplate.db.collections.RecognitionTemplate.dropIndex("SystemBadgeIndex", function () {
                    callback();
                });
            })
        ], fcallback);
    }
    this.Run = function (callback) {
        async.series([
            dropIndexes,
            addRecognitionIndexes
        ], callback);
    };
};

module.exports = new HgMigrationFile();
