load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgthanka');
// Visibility Fields moved top level

var query = {
    'Visibility.RestrictByLocation': true
};
db.Recognition.find(query).forEach(function (item) {
    item.VisibilityLocations = item.Visibility.Locations;
    db.Recognition.save(item);
});

var query = {
    'Visibility.RestrictByMember': true
};
db.Recognition.find(query).forEach(function (item) {
    item.VisibilityMemberIds = item.Visibility.MemberIds;
    db.Recognition.save(item);
});

//Remove Visibility script
db.Recognition.update({
    Visibility: {$exists: true}
}, {
    $unset: {
        Visibility: 1
    }
}, {
    multi: true
});

//defrag collection
db.runCommand ({compact: 'Recognition', force: true});
