//To change local time to UTC :
sudo ln -sf /usr/share/zoneinfo/UTC /etc/localtime

//To change UTC to local time:
sudo ln -sf /usr/share/zoneinfo/America/Chicago /etc/localtime