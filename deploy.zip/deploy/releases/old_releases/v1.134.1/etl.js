var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addGoalIndexs(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.Goal.db.collections.Goal.ensureIndex({
                    GroupId: 1,
                    Status: 1,
                    'AlignedGoal.GoalId': 1
                }, {name: 'AlignedIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.MetricsGoalActivity.db.collections.MetricsGoalActivity.ensureIndex({
                    d: 1,
                    g: 1,
                    c: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            })
        ], fcallback);
    }
    function removeAllGoalActivityMetrics(callback) {
        EntityCache.MetricsGoalActivity.remove({}, callback);
    }
    function saveGoalUpdateMetric(params, callback) {
        var query = {
            p: params.Date,
            g: params.GroupId,
            m: params.MemberId,
            d: params.DepartmentId,
            s: params.Source
        };
        if (params.CycleId) {
            query.c = params.CycleId;
        }
        EntityCache.MetricsGoalActivity.update(query, {$inc: {t: 1}}, {upsert: true}, callback);
    }
    function migrateGoalActivityData(callback) {
        var getJustUTCDate = function(d) {
                return new Date(new Date(d).toString().substring(0, 15));   
            };
        async.parallel({
            goals: function (fcallback) {
                var goalCycleHash = {};
                EntityCache.Goal.find({}, {hgId: 1, CycleId: 1}, function (error, goals) {
                    if (error) {
                        return callback(error);
                    }
                    goals.forEach(function (item) {
                        goalCycleHash[item.hgId] = item.CycleId;
                    });
                    fcallback(null, goalCycleHash);
                });
            },
            members: function (fcallback) {
                var memberDepartmentHash = {};
                EntityCache.Member.find({}, {hgId: 1, GroupDepartmentId: 1}, function (error, members) {
                    if (error) {
                        return callback(error);
                    }
                    members.forEach(function (item) {
                        memberDepartmentHash[item.hgId] = item.GroupDepartmentId;
                    });
                    fcallback(null, memberDepartmentHash);
                });
            }
        }, function (error, results) {
            if (error) {
                return callback(error);
            }
            EntityCache.EntityActivity.find({ActivityType: "KeyResultUpdate"}, function (error, activities) {
                if (error) {
                    return callback(error);
                }
                async.each(activities, function (activity, activityCallback) {
                    if (error) {
                        return activityCallback(error);
                    }
                    EntityCache.Comment.findOne({hgId: activity.BatchId}, function (error, comment) {
                        if (error || !comment) {
                            return activityCallback(error);
                        }
                        saveGoalUpdateMetric({
                            Date: getJustUTCDate(activity.CreatedDate),
                            GroupId: activity.GroupId,
                            MemberId: activity.MemberId,
                            Source: 'Web',
                            DepartmentId: results.members[activity.MemberId] || '',
                            CycleId: results.goals[comment.EntityId]
                        }, activityCallback);
                    });
                }, callback);
            });
        });
    }
    function setDefaultProgressStatus(callback) {
        async.parallel({
            cycleGoals: function (gCallback) {
                EntityCache.Goal.update({
                    CycleId: {$exists: true},
                    Status: {$in: ['InProgress', 'PendingClosure', 'SubmittedForClosure']}
                }, {
                    $set: {
                        ProgressStatus: 'OnTrack'
                    }   
                }, {
                    multi: true
                }, gCallback);
            },
            personalGoals: function (gCallback) {
                EntityCache.Goal.update({
                    CycleId: {$exists: false},
                    Approver: {$exists: false},
                    Status: {$ne: 'Archived'}
                }, {
                    $set: {
                        ProgressStatus: 'OnTrack'
                    }   
                }, {
                    multi: true
                }, gCallback);
            },
            inProgressPersonalGoals: function (gCallback) {
                EntityCache.Goal.update({
                    CycleId: {$exists: false},
                    Status: {$in: 'InProgress'}
                }, {
                    $set: {
                        ProgressStatus: 'OnTrack'
                    }   
                }, {
                    multi: true
                }, gCallback);
            }
        }, callback);
    }
    function addMobileDeviceIndex(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.UserInfoWithToken.db.collections.UserInfoWithToken.ensureIndex({
                    DeviceUuid: 1
                }, {
                    name: 'DeviceUuidIndex',
                    background: true,
                    sparse: true
                }, callback);
            }),
            (function (callback) {
                EntityCache.UserInfoWithToken.db.collections.UserInfoWithToken.ensureIndex({
                    DeviceToken: 1
                }, {
                    name: 'DeviceTokenIndex',
                    background: true,
                    sparse: true
                }, callback);
            }),
            (function (callback) {
                EntityCache.UserInfoWithToken.db.collections.UserInfoWithToken.ensureIndex({
                    RegistrationId: 1
                }, {
                    name: 'RegistrationIdIndex',
                    background: true,
                    sparse: true
                }, callback);
            })
        ], fcallback);
    }

    this.Run = function (callback) {
        async.series([
            setDefaultProgressStatus,
            addGoalIndexs,
            removeAllGoalActivityMetrics,
            migrateGoalActivityData,
            addMobileDeviceIndex
        ], callback);
    };
};

module.exports = new HgMigrationFile();