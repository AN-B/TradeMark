/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        guid = require('node-uuid');

    function addTalentInsightQuestions(callback) {
        var questions = [{
                Tag: "KeyToSuccess",
                Question: "Key to team's success",
                Category: "Compensation",
                SortOrder: 0
            }, {
                Tag: "Promotable",
                Question: "Promotable",
                Category: "Compensation",
                SortOrder: 1
            }, {
                Tag: "Scarcity",
                Question: "Difficult to replace",
                Category: "Compensation",
                SortOrder: 2
            }, {
                Tag: "FlightRisk",
                Question: "Flight risk",
                Category: "Compensation",
                SortOrder: 3
            }, {
                Tag: "Performance",
                Question: "Has a performance problem ",
                Category: "Compensation",
                SortOrder: 4
            }, {
                Tag: "Replaceable",
                Category: "Mobility",
                Question: "It's possible to find someone else to perform this role better, for the same pay",
                SortOrder: 0
            }, {
                Tag: "Capacity",
                Category: "Mobility",
                Question: "Capacity to take on an expanded or more complex role",
                SortOrder: 1
            }, {
                Tag: "Speed",
                Category: "Mobility",
                Question: "How fast can they take on an expanded or more complex role",
                SortOrder: 2
            }];
        EntityCache.FeedbackCard.remove({
            Type: "TalentInsight",
            Category: "System"
        }, function (error, card) {
            if (error) {
                return callback(error);
            }
            var feedbackCard = new EntityCache.FeedbackCard({
                hgId: guid.v1(),
                Category: "System",
                Title: "Talent Insight Template",
                Type: "TalentInsight",
                Status: "Active",
                CreatedDate: Date.now(),
                UseSections: false,
                SinglePageQuestion: true,
                CardType: 'TalentInsight',
                Sections: [ 
                    {
                        Title: 'Compensation',
                        Type: "Generic",
                        hgId: guid.v1(),
                        Questions: questions.filter(function (aitem) {
                            return aitem.Category === 'Compensation';
                        }).map(function (item) {
                            return {
                                Question: item.Question,
                                hgId: guid.v1(),
                                Type: "Slider",
                                MinRange: 0,
                                MaxRange: 4,
                                SortOrder: item.SortOrder,
                                Required: true,
                                Tag: item.Tag
                            }
                        })
                    },
                    {
                        Title: 'Mobility',
                        Type: "Generic",
                        hgId: guid.v1(),
                        Questions: questions.filter(function (aitem) {
                            return aitem.Category === 'Mobility';
                        }).map(function (item) {
                            return {
                                Question: item.Question,
                                hgId: guid.v1(),
                                Type: "Slider",
                                MinRange: 0,
                                MaxRange: 4,
                                SortOrder: item.SortOrder,
                                Required: true,
                                Tag: item.Tag
                            }
                        })
                    }
                ]
            });
            feedbackCard.save(callback);
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            addTalentInsightQuestions
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
