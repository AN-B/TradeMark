load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgfinance");
db.Transaction.find({Info : /additional null credits/i, Type: 'Recognition' }).forEach(function (transaction)
    {
        var info = transaction.Info;
        info = info.replace('additional null credits', 'no additional credits');
        db.Transaction.update({'hgId' : transaction.hgId}, {$set : {Info : info}});
        print(info);
    }
);

//remove Standing Ovation per Miriam request
switchDB("hgthanka");
db.Badge.update({'BadgeName' : 'Standing Ovation'}, {$set : {'Archive' : true}}, {multi : true});