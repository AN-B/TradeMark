/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addEsbTurkIdIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.EventBusItem.db.collections.EventBusItem.ensureIndex({
                    "Status": 1,
                    "TurkId": 1
                }, {name : 'StatusTurkId', background: true }, callback);
            })
        ], fcallback);
    }
    this.Run = function (fcallback) {
        Async.series([
            addEsbTurkIdIndex
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
