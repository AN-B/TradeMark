/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');


    function setRecognitionVisibility(callback) {
        var query = {
            Status : 'Active',
            'Visibility.RestrictByLocation' : null 
        }, update = {
            $set : {
                Visibility : {
                    RestrictByLocation : false,
                    Locations : []
                }
            }
        };
        EntityCache.Recognition.update(query, update, {multi : true}, function (error) {
            if (error) {
                console.log(error);
                return callback(error);
            }
            callback();
        });
    }

    this.Run = function (callback) {
        Async.series([
            setRecognitionVisibility
        ], callback);
    };
};
module.exports = new HgMigrationFile();
