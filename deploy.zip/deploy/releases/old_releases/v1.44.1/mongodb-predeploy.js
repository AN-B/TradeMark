load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

db.Recognition.ensureIndex({'hgId' : 1,  Status : 1});
db.Recognition.ensureIndex({'BatchId' : 1,  Status : 1});
