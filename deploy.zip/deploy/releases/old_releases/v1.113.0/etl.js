/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addTeamTabOKRIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.ManagerAlert.db.collections.ManagerAlert.ensureIndex({
                    _id: 1,
                    ManagerMemberId: 1,
                    ReportMemberId: 1,
                    'Data.GoalId': 1,
                    'Data.CycleId': 1,
                    'Data.ParticipantHgId': 1
                }, {name: 'OkrIndex', background: true, sparse: true }, callback);
            })
        ], fcallback);
    }
    function updateUserInfoRecord(params, callback) {
        EntityCache.UserInfo.update({
            'Preference.DefaultGroupId': params._id.GroupId,
            hgId: {$in: params.UserIds}
        }, {
            $set: {
                AvatarUploaded: true
            }
        }, {
            multi: true
        }, callback);
    }
    function migrateUserAvatarData(callback) {
        EntityCache.UserActivityAudit.aggregate([
            {$match: {
                $or: [
                    {ServiceName: 'UserSelf', MethodName: 'UpdateAvatarVersion'},
                    {ServiceName: 'Provision', MethodName: 'UploadMassMemberAvatars'}
                ]
            }},
            {$group: {
                _id: {
                    GroupId: "$GroupId",
                },
                UserIds:{ $addToSet:  "$UserId"}
            }}
        ], function (error, result) {
            if (error || !result || !result.length) {
                return callback(error);
            }
            Async.each(result, updateUserInfoRecord, callback);
        });
    }
    function updateSurveyResult(params, callback) {
        EntityCache.SurveyResult.update({
            hgId: params.SurveyResult.hgId,
        }, {
            $set: {
                Completed: params.CompletedCount,
                Question: 'How do you feel about work today?',
                Summary: {
                    Type: 'Mood',
                    Average: params.Average,
                    HighestOptionVote: params.HighestOptionVote
                }
            }
        }, callback);
    }
    function getResultAverage(surveyResult, callback) {
        Async.parallel({
            completedCount: function (fcallback) {
                EntityCache.SurveyAnswer.count({
                    GroupId: surveyResult.GroupId,
                    SurveyId: surveyResult.SurveyId,
                    RecurrenceId: surveyResult.RecurrenceId,
                    CurrentRoundId: surveyResult.CurrentRoundId,
                    Status: 'Completed'
                }, fcallback);
            },
            highestVotes: function (fcallback) {
                EntityCache.SurveyAnswer.aggregate([
                    {$match: {
                        GroupId: surveyResult.GroupId,
                        SurveyId: surveyResult.SurveyId,
                        RecurrenceId: surveyResult.RecurrenceId,
                        CurrentRoundId: surveyResult.CurrentRoundId,
                        Status: 'Completed'
                    }},
                    {$unwind: "$QandA"},
                    {$group: {
                        _id: {
                            AnswerValue: "$QandA.AnswerValue"
                        },
                        total: {$sum : 1}
                    }},
                    {$sort: {
                        total: -1
                    }},
                    {$limit: 1}
                ], function (error, result) {
                    if (error) {
                        return fcallback(error);
                    }
                    fcallback(null, result.length ? result[0]._id.AnswerValue : '');
                });
            },
            average: function (fcallback) {
                EntityCache.SurveyAnswer.aggregate([
                    {$match: {
                        GroupId: surveyResult.GroupId,
                        SurveyId: surveyResult.SurveyId,
                        RecurrenceId: surveyResult.RecurrenceId,
                        CurrentRoundId: surveyResult.CurrentRoundId,
                        Status: 'Completed'
                    }},
                    {$unwind: "$QandA"},
                    {$group: {
                        _id: {
                            AnswerValue: "$QandA.QuestionId"
                        },
                        average: { $avg: "$QandA.ScaledAnswerValue"},
                    }}
                ], function (error, result) {
                    if (error) {
                        return fcallback(error);
                    }
                    fcallback(null, result.length ? result[0].average : 0);
                });
            }
        }, function (error, result) {
            if (error) {
                return callback(error);
            }
            updateSurveyResult({
                SurveyResult: surveyResult,
                CompletedCount: result.completedCount || 0,
                Average: result.average || 0,
                HighestOptionVote: result.highestVotes || 0
            }, callback);
        });
    }
    function savePulseResultSummary(callback) {
        var query = {
            Type: 'Pulse'
        };
        EntityCache.SurveyResult.find(query, function (error, surveyResults) {
            if (error || !surveyResults.length) {
                return callback(error);
            }
            Async.each(surveyResults, getResultAverage, callback);
        });
    }
    function populateOneCycleOwnerAndSave(cycleAndAdminMemberPair, callback) {
        if (!cycleAndAdminMemberPair.AdminMember.length) {
            console.log(cycleAndAdminMemberPair.Cycle.Title + ' does not have admin, somethign is wrong');
            return callback();
        }
        cycleAndAdminMemberPair.Cycle.CycleOwner = {
            MemberId: cycleAndAdminMemberPair.AdminMember[0].hgId,
            UserId: cycleAndAdminMemberPair.AdminMember[0].UserId,
            FullName: cycleAndAdminMemberPair.AdminMember[0].FullName
        };
        console.log(cycleAndAdminMemberPair.Cycle.CycleOwner);
        cycleAndAdminMemberPair.Cycle.save(callback);
    }

    function populateGoalCycleOwner(callback) {
        EntityCache.GoalCycle.find({}, function (error, cycles) {
            if (error) {
                console.log('Error getting cycles');
                return callback(error);
            }
            var userIds = cycles.map(function (cycle) {
                return cycle.CreatedBy;
            });
            EntityCache.Member.find({UserId: {$in: userIds}}, function (error, members) {
                if (error || !cycles) {
                    console.log('Error getting cycles');
                    return callback(error);
                }
                var cycleAndAdminMemberPairs = cycles.map(function (cycle) {
                    return {
                        Cycle: cycle,
                        AdminMember: members.filter(function (member) {
                            return member.UserId === cycle.CreatedBy && member.GroupId === cycle.GroupId;
                        })
                    };
                });
                Async.each(cycleAndAdminMemberPairs, populateOneCycleOwnerAndSave, callback);
            });
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            populateGoalCycleOwner,
            savePulseResultSummary,
            migrateUserAvatarData,
            addTeamTabOKRIndex
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
