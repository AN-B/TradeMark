load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hglog");

var dryRun = true;

//ETL Script in this folder needs to be RUN FIRST
//This needs to be run in STEPS

//Step 0. DROP existing indexes to speed up date
db.UnAuthorizedActivity.dropIndexes();
db.UserActivityAudit.dropIndexes();

//Step 1. Need to add a Date field to identify records to archive anything before 8/1/2015
var query = {
    _id: { $lt: ObjectId(Math.floor(new Date(Date.UTC(2015, 7, 1, 0, 0, 0, 0))/1000).toString(16) + "0000000000000000") }
};
if (!dryRun) {
	db.UserActivityAudit.update(query, { $set: { CreatedDate: new Date(Date.UTC(2015, 7, 1, 0, 0, 0, 0))}}, {multi: true});
}


//Step 2. Create Temp Archive Index just for today.
if (!dryRun) {
	db.UserActivityAudit.createIndex({CreatedDate: 1}, {name: 'TempArchiveIndex', expireAfterSeconds: 0});
}


//Step 3. When all records are archived then remove TempArchiveIndex
var query = {
    _id: { $lt: ObjectId(Math.floor(new Date(Date.UTC(2015, 7, 1, 0, 0, 0, 0))/1000).toString(16) + "0000000000000000") }
};
db.UserActivityAudit.count(query);
//db.UserActivityAudit.dropIndex('TempArchiveIndex') //<----- RUN THIS When QUERY count above is ZERO


//Step 4 Set CreatedDate for current log records
db.UserActivityAudit.find().forEach(function (item) {
	item.CreatedDate = item._id.getTimestamp();
	if (!dryRun) {
		db.UserActivityAudit.save(item);
	}
});
db.UnAuthorizedActivity.find().forEach(function (item) {
	item.CreatedDate = item._id.getTimestamp();
	if (!dryRun) {
		db.UnAuthorizedActivity.save(item);
	}
});

//Step 5
// C. Enable Real Auto Archive 8380800 = 3 months and 7 days
if (!dryRun) {
	db.UserActivityAudit.createIndex({
		CreatedDate: 1
	}, { name: 'ArchiveIndex', expireAfterSeconds: 8380800, background: true});

	db.UnAuthorizedActivity.createIndex({
		CreatedDate: 1
	}, { name: 'ArchiveIndex', expireAfterSeconds: 8380800, background: true});

	db.UnAuthorizedActivity.createIndex({
	    ServiceName: 1,
	    MethodName: 1
	}, {name: 'CoreDocIndex', background: true, sparse: true});

	db.UserActivityAudit.createIndex({
	    ServiceName: 1,
	    MethodName: 1,
	    UserId: 1,
	    BrowserFingerPrint: 1
	}, {name: 'CoreDocIndex', background: true, sparse: true});

}

//Step 6 compact collection one last time after all the pruning is done
if (!dryRun) {
    db.runCommand({compact: 'UserActivityAudit', force: true});
    db.runCommand({compact: 'UnAuthorizedActivity', force: true});
} 


