load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

// db.Recognition.update({'Template.IsPublic' : {$ne : true}, 'Template.Publicity' : {$exists : false}}, {$set : {'Template.Publicity' : 'Private'}}, {multi: true});
db.Recognition.update({'Template.IsPublic' : true, 'Template.Publicity' : {$exists : false}}, {$set : {'Template.Publicity' : 'Both'}}, {multi: true});

