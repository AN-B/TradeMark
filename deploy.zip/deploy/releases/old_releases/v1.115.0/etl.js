/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addBatchDailyRecapJob(callback) {
        var job = new EntityCache.Job({
            hgId: 'b66fff40-86f9-11e5-afd9-95885f904802',
            JobName: 'BatchDailyRecap',
            MethodName: 'BatchDailyRecap',
            PeriodType: 'Daily',
            Hour : 7,
            LatestTriggerDate : 0
        });
        EntityCache.Job.findOne({JobName: 'BatchDailyRecap'}, function (error, jobRecap) {
            if (error) {
                return callback(error);
            }
            if (jobRecap) {
                console.log("Already exist");
                return callback();
            }
            job.save(callback);
        });
    }

    function addBatchWeeklyRecapJob(callback) {
        var job = new EntityCache.Job({
            hgId: 'f983bf79-8707-11e5-9d0a-abf6de9e6e99',
            JobName: 'BatchWeeklyRecap',
            MethodName: 'BatchWeeklyRecap',
            PeriodType: 'Daily',
            Hour : 4,
            LatestTriggerDate : 0
        });
        EntityCache.Job.findOne({JobName: 'BatchWeeklyRecap'}, function (error, jobRecap) {
            if (error) {
                return callback(error);
            }
            if (jobRecap) {
                console.log("Already exist");
                return callback();
            }
            job.save(callback);
        });
    }

    function addMemberIndexGroupName(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.Member.db.collections.Member.ensureIndex({
                    "GroupName" : 1
                }, {name : 'GroupName', background: true }, callback);
            })
        ], fcallback);
    }

    function populateRecapType(fcallback) {
        EntityCache.Member.update({
            "Preference.RecapType": {$exists: false}
        }, {
            $set: {"Preference.RecapType": "Daily"}
        }, {
            multi: true
        }, fcallback);
    }

    function addRulesEngineEventTypes(callback) {
        var groupEventType = {
            GroupName: 'Mercury Industries',
            EventTypes: ['CsNewClientLaunched', 'CsClientRenewed', 'CsAdditionalClientModule']
        };
        EntityCache.Group.findOne({GroupName : groupEventType.GroupName}, function (error, group) {
            if (error) {
                return callback('error loading group:' + error);
            }
            if (!group) {
                console.log('Group:' + groupEventType.GroupName + ' does not Exist');
                return callback();
            }
            groupEventType.EventTypes.forEach(function (type) {
                if (group.RulesEngineEventTypes.indexOf(type) === -1) {
                    group.RulesEngineEventTypes.push(type);
                }
            });
            group.save(callback);
        });
    }


    this.Run = function (fcallback) {
        Async.series([
            addRulesEngineEventTypes,
            addBatchDailyRecapJob,
            addBatchWeeklyRecapJob,
            addMemberIndexGroupName,
            populateRecapType
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
