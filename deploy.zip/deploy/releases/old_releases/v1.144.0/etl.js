'use strict';
var HgMigrationFile = function () {
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addMiscIndexes(fcallback) {
        async.series([
            (function (callback) {
               EntityCache.EventBusItem.db.collections.EventBusItem.dropIndex("CoreDocIndex", function () {
                    callback();
                });
            }),
            (function (callback) {
                EntityCache.EventBusItem.db.collections.EventBusItem.ensureIndex({
                    "Status" : 1,
                    "TurkId": 1,
                    "CreatedDate" : 1
                }, {name: 'CoreDocIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recurrence.db.collections.Recurrence.ensureIndex({
                    "Status" : 1,
                    "NextTriggerDate" : 1
                }, {name: 'NextTriggerDateStatusIndex', background: true}, callback);
            })
        ], fcallback);
    }

    function populateLastDailyRecapSentDate(fcallback) {
        EntityCache.Member.update({
            LastDailyRecapSentDate: null
        }, {
            $set: {LastDailyRecapSentDate: 0}
        }, {
            multi: true
        }, fcallback);
    }

    function addIndexForMemberCollection(fcallback) {
        EntityCache.Member.db.collections.Member.ensureIndex({
            "MembershipStatus" : 1,
            "GroupId": 1,
            "Preference.RecapType": 1,
            "LastDailyRecapSentDate" : 1
        }, {name: 'RecapIndex', background: true}, fcallback);
    }

    function dropGorupNameIndexInMember(fcallback) {
        EntityCache.Member.db.collections.Member.dropIndex("GroupName", fcallback);
    }


    this.Run = function (callback) {
        async.series([
            addMiscIndexes,
            populateLastDailyRecapSentDate,
            addIndexForMemberCollection,
            dropGorupNameIndexInMember
        ], callback);
    };
};

module.exports = new HgMigrationFile();
