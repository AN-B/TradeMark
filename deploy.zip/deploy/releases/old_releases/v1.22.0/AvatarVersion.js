
// 1 // load all avatar and check if the md5 hash matches the default avatar
// 2 // Visual Confirm listed avatars
// 3 // set avatar version back to the created date

var fs = require('fs'),
	crypto = require('crypto'),
	dir = '/Projects/Test/user/e/',
	files = fs.readdirSync(dir),
	defaultAvatarFilePath = '/Projects/hgapp/static/img/mocks/Test.jpg',
	defaultAvatartFileHash;

function getFileHash(dir, file, callback) {
	var stream = fs.ReadStream(dir + file),
		md5sum = crypto.createHash('md5');
	stream.on('data', function(d) { md5sum.update(d); });
	stream.on('end', function() {
	    callback({ File: file, Hash : md5sum.digest('hex')});
	});
	stream.on('error', function(err) {
		console.log(err);
	});
}

function getUnChangedAvatars(callback) {
	var avatarData = {
		lstUnChangedAvatars : [],
		HashUnChangedAvatars : {}
	};
	getFileHash('', defaultAvatarFilePath, function (data) {
		defaultAvatartFileHash = data.Hash;
		for (j = 0, i = 0, jlen  = files.length, len  = files.length; i < len; i += 1) {
			if (files[i].length > 3 && (files[i].substring(files[i].length - 4, files[i].length) === '.jpg')) {
				getFileHash(dir, files[i], function (data) {
					j += 1;
					if (defaultAvatartFileHash === data.Hash) {
						avatarData.lstUnChangedAvatars.push(data.File.replace('.jpg', ''));
					}
					if (jlen === j) {
						callback(avatarData);
					}
				});
			} else {
				jlen -= 1;
			}
		}
	});	
}
getUnChangedAvatars(function (fdata) {
	console.log(fdata);
	console.log('Total Files:' + files.length);
	console.log('Total Unchanged Avatar:' + fdata.lstUnChangedAvatars.length);
});

