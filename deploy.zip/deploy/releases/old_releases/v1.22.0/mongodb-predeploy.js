load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

//Set HgIDs
var unchangedAvatarHash = [];
var userInfo = db.UserInfo.aggregate([{$match : { hgId : { $in : unchangedAvatarHash}}}, {$project : {"UserPersonal.FullName" : 1 , "hgId" : 1, "CreatedDate" : 1, "AvatarVersion" : 1}}]).result
// Visually Verify
for(i=0;i<userInfo.length;i++){print('<span>'+userInfo[i].UserPersonal.FullName+'</span><img src=https://hgprod.s3.amazonaws.com/user/'+userInfo[i].hgId+'.jpg><br>');}

// Update Avatars
for(j=0;j<userInfo.length;j++){db.UserInfo.update({'hgId' : userInfo[j].hgId}, {$set : {'AvatarVersion' : userInfo[j].CreatedDate}});}



