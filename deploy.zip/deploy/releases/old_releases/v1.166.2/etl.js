/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        paramsUtil = require('../../../hgnode/util/params.js'),
        async = require('async');

    function addSurveyIndexes(callback) {
        async.series([
            (function(fcallback) {
                EntityCache.SurveyAnswer.db.collections.SurveyAnswer.ensureIndex({
                    "CurrentRoundId": 1,
                    "LocationName": 1,
                    "DepartmentName": 1
                }, {name: 'LocationDepartmentIndex', background: true}, fcallback);
            })
        ], callback);
    }

    function addSearchIndex(callback) {
        async.series([
            (function(fcallback) {
                EntityCache.Member.db.collections.Member.ensureIndex({
                    SearchField: 1.0,
                    MembershipStatus: 1.0,
                    GroupId: 1.0
                }, {name: 'MemberSearchFieldIndex', background: true}, fcallback);
            })
        ], callback);
    }

    function setSearchField(members, callback) {
        async.each(members, function(member, mCallback) {
            member.SearchField = paramsUtil.GetSearchField(member.SearchName || member.FullName, true);
            member.save(mCallback);
        }, callback);
    }
    function migrateSearchFieldValue(callback) {
        var dataReturned = 1,
            skip = 0;
        async.whilst(
            function () {
                return dataReturned;
            },
            function (scallback) {
                EntityCache.Member.find({})
                    .skip(skip)
                    .limit(1000)
                    .exec(function (error, members) {
                        if (error) {
                            return scallback(error);
                        }
                        skip += members.length;
                        dataReturned = members.length;
                        if (!members.length) {
                            return scallback();
                        }
                        setSearchField(members, scallback);
                    });
            },
            callback
        );
    }

    this.Run = function (fcallback) {
        async.series([
            addSurveyIndexes,
            addSearchIndex,
            migrateSearchFieldValue
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();