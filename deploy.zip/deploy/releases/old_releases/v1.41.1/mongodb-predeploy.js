load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Group.update({Status : null}, {$set : {Status : 'Active'}}, {multi : true});
