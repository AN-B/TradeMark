load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgperka");

//Set Name correct
db.TangoCard.update({CardName : /^Amazon.COM$/i}, { $set : {CardName : 'Amazon'}}, {$multi : false});

switchDB("hgthanka");
db.Comment.update(
    {'EntityType' : 'Coaching'},
    {$set : {
        Type : 'Coaching'

    }},
    {multi : true}
);

//Run Recognition Migration Script 
//---> Deploy/Analytics/migratedata.js