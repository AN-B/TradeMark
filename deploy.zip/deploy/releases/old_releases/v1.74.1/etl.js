/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
      Async = require('async');

    function removeDuplicateDependingAlerts(callback) {
    	/*
		No need for this query at the moment might come in handy later.
		Their is only one record in prod with a duplicate active entry
		so I am just going to update the single record
    	var query = {
		    Category : 'Perform',
		    AlertType : 'PerformPendingReview'
		},
		group = {
		    _id :'$Data.ReviewId',
		    record : {$push : {
                'hgId' : '$hgId',
                'status' : '$Status',
                'alertType': '$AlertType'
            }}
		};
		EntityCache.ManagerAlert.aggregate([
		    {$match: query},
		    {$group : group},
		    {$match : { 'record' : { $exists : true}, record : {$size : 2} } }
		], function (error, data) {
			if (error) {
				return callback(error);
			}
			// I already checked the data some records with 3 entries but they are all already completed.
			// so only looking for records with 2 entries
		});*/
		var  query = {
			hgId : "bad21eb0-ab30-11e4-92a2-491f2cc99f9e",
			Status : 'Active'
		}, update = {
			$set : {
				Status : 'Completed',
				ModifiedDate : new Date().getTime()
			}
		};
		EntityCache.ManagerAlert.update(query, update, callback);
    }
    this.Run = function (fcallback) {
      Async.series([
          removeDuplicateDependingAlerts
      ], function (error, results) {
        fcallback(error, results);
      });
    };
};
module.exports = new HgMigrationFile();


