load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgthanka');

// get the TeamId property of achievement recognition templates and place it into RestrictDepartmentIds array

var recTemps = db.RecognitionTemplate.find({Category:"Achievement",TeamId:{$ne:""},AccessLevel:"WithinTeam"});
if (recTemps) {
    recTemps.forEach(function (rt) {
        if (rt.TeamId) {
            if (!rt.RestrictDepartmentIds) {
                rt.RestrictDepartmentIds = [
                    rt.TeamId
                ];
            } else if (rt.RestrictDepartmentIds.map && rt.RestrictDepartmentIds.filter) {
                rt.RestrictDepartmentIds.push(rt.TeamId);
            }
            db.RecognitionTemplate.save(rt);
            print(rt.GroupName + ': ' + rt.RestrictDepartmentIds);
        }
    });
}
