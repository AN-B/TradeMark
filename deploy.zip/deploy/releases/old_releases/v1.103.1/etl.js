var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../../hgnode/framework/EntityCache'),
        SAMLEnums = require('../../../../hgnode/enums/SAMLEnums'),
        uuid = require('node-uuid'),
        async = require('async');

    function migrateGroupSSO(callback) {
        //get groups
        EntityCache.Group.find({}, function (err, groups) {
            if (err) {
                return callback(err);
            }
            //for each group
            async.each(groups, function (group, callback) {
                EntityCache.GroupSSO.findOne({GroupId: group.hgId}, function (err, existingSSO) {
                    if (err) {
                        return callback(err);
                    }
                    if (existingSSO) {
                        console.log('Group SSO exists for ' + group.GroupName + '. Skipping.');
                        return callback();
                    }

                    group = group.toObject();
                    var groupSSO = {
                        GroupId: group.hgId,
                        hgId: uuid.v1()
                    };

                    //if they have SAML, move to new schema
                    if (group.SSO && group.SSO.SAML) {
                        groupSSO.SAML = group.SSO.SAML;
                    }

                    //if they have one login, move to new schema
                    if (group.SSO && group.SSO.OneLogin && group.SSO.OneLogin.cert) {
                        groupSSO.SAML = group.SSO.OneLogin;
                        groupSSO.SAML.type = SAMLEnums.OneLogin.name;
                        groupSSO.SAML.issuer = SAMLEnums.OneLogin.issuer;
                        groupSSO.SAML.entryPoint = SAMLEnums.OneLogin.entryPoint;
                    }

                    //if they have yammer, move to new schema
                    if (group.SSO && group.SSO.Yammer) {
                        groupSSO.Yammer = group.SSO.Yammer;
                    }

                    EntityCache.GroupSSO(groupSSO).save(function (err, data) {
                        if (err) {
                            return callback(err);
                        }
                        console.log('migrated group SSO for ' + group.GroupName);
                        callback();
                    });
                });
            }, callback);
        });
    }

    function addEsbArchiveIndex(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.EventBusItemArchive.db.collections.EventBusItemArchive.ensureIndex({
                    "hgId" : 1
                }, {name : 'hgId', background: true }, callback);
            })
        ], fcallback);
    }

    this.Run = function (callback) {
        async.series([
            migrateGroupSSO,
            addEsbArchiveIndex
        ], callback);
    };
};

module.exports = new HgMigrationFile();