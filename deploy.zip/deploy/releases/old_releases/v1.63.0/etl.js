load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");
//Set Default Team Status
var query = {
	Status : { $ne : 'Deleted'}
}, update = {
	$set : {
            Status : 'Active'
        }
};
db.Team.update(query, update, {multi : true})

// Re-migrate Department data
// 1) Recognition
// 2) Comments, Likes
// 3) Tracks
// 4) Perform
// 5) Coaching
/*
switchDB("hgcommon");
var groupId = '7bc84a10-ac49-11e2-816a-81fd71297a71';
var query = {
    GroupDepartmentName : { $ne : ''},
    GroupId : groupId
};
var matchQuery = {
    $match : query
};
var groupQuery = {
    $group : {
        _id : {GroupId : '$GroupId', GroupName : '$GroupName'},
        departments : { '$addToSet' : "$GroupDepartmentName" }
    }
};
var memberDepartment = db.Member.aggregate([matchQuery, groupQuery]);
var mgroup = {};
memberDepartment.result.forEach(function (item) {
	if (!mgroup[item._id.GroupId]) {
		mgroup[item._id.GroupId] = item.departments;
	}
});
var query = { 
    Type : 'Department',
   "GroupId" : groupId
};
var matchQuery = {
    $match : query
};
var groupQuery = {
    $group : {
        _id : {GroupId : '$GroupId'},
        departments : { '$addToSet' : "$Name" }
    }
};
var teamDepartment = db.Team.aggregate([matchQuery, groupQuery]);
teamDepartment.result.forEach(function (item) {
	if (mgroup[item._id.GroupId]) {
		if (mgroup[item._id.GroupId].length !== item.departments.length) {
			// print('*****************');
			print(item._id.GroupId);
			print('members');
			print(mgroup[item._id.GroupId]);
			print('team');
			print(item.departments);
			print('================')
		}
		
		// print( 'GroupId: ' + item.GroupId + ' : has the same length ' + (mgroup[item.GroupId].length() === item.departments.length()));
	}
});



switchDB("hgcommon");
// for every member do they map to an existing department
var query = {};

db.Member.find(query);


switchDB("hgthanka");
// Get Internal Recognitions
var query = {
	'PublicCreatorInfo.FullName' : '',
	 Status : "Active"
};
var recognitions  = db.Recognition.find(query);

switchDB("hgreports");

function getJustUTCDate(d) {
 	return new Date(new Date(d).toString().substring(0, 15)); 	
}

function saveRecDepartment(params) {
	var query = {p : params.Date, g : params.GroupId, d : params.Department, c : params.Category, s : 'Web'};
	var options = {upsert: true};
	var update = {$inc : { t : 1}};
	printjson(query);
	printjson(update);   
	db.MetricsDepartment.update(query, update, options);
}

// This should use the new department
// What happens to recognition given by users in departments that no longer exist
function getDepartment(rec) {
	var dept = (rec.CreatorMember && 
				rec.CreatorMember.GroupDepartmentName && 
				rec.CreatorMember.GroupDepartmentName !== '') ? rec.CreatorMember.GroupDepartmentName : 'Other';
	if (dept === 'Other') {
		print('Recognition given by a user without a Department: ' + rec.hgId);
	}
	return dept;
}
function extractRecInfo(rec) {
	var createdDate = getJustDate(rec.CreatedDate),
		groupId = rec.RecipientMember.GroupId;
	saveRecDepartment({
		Department :getDepartment(rec),
		Date : createdDate,
		Category : 'RecognitionGiven',
		GroupId : groupId
	});
}

for (i = 0; i < recognitions.length(); i += 1) {
	extractRecInfo(recognitions[i]);
}
*/

