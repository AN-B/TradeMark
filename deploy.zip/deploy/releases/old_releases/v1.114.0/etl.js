/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function updateSurvey(survey, callback) {
        if (!survey.Template || !survey.Template.PulseQuestions || !survey.Template.PulseQuestions.length) {
            return callback();
        }
        EntityCache.Survey.update({
            hgId: survey.hgId
        }, {
            $set: {
                CurrentQuestionId: survey.Template.PulseQuestions[0].hgId
            }
        }, callback);
    }
    function saveCurrentPulseQuestion(callback) {
        var query = {
            'Template.Type': 'Pulse'
        };
        EntityCache.Survey.find(query, function (error, survey) {
            if (error || !survey.length) {
                return callback(error);
            }
            Async.each(survey, updateSurvey, callback);
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            saveCurrentPulseQuestion
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
