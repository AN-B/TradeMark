load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Environment.remove();
db.Environment.insert({
    Name : 'POC Server',
    api : 'http://mopoc.highground.com/',
    s3 : "http://hgpoc.s3.amazonaws.com",
    Enabled : true,
    PermissionRequired : ['SwitchEnvironmentQA', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'QA Server',
    api : 'https://moqa.highground.com/',
    s3 : "https://hgqa1.s3.amazonaws.com",
    Enabled : true,
    PermissionRequired : ['SwitchEnvironmentQA', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'Staging Server',
    api : 'http://most.highground.com/',
    s3 : 'http://hgstage.s3.amazonaws.com',
    Enabled : true,
    PermissionRequired : ['SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'UAT Server',
    api : 'http://mouat.highground.com/',
    s3 : 'http://hguat.s3.amazonaws.com',
    Enabled : true,
    PermissionRequired : ['SwitchEnvironmentSales', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'Demo Server',
    api : 'http://modemo.highground.com/',
    s3 : 'http://hgdemo.s3.amazonaws.com',
    Enabled : true,
    PermissionRequired : ['SwitchEnvironmentSales', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'Production Server',
    api : 'https://mo.highground.com/',
    s3 : 'https://hguat.s3.amazonaws.com',
    Enabled : true,
    PermissionRequired : ['SwitchEnvironmentQA', 'SwitchEnvironmentSales', 'SwitchEnvironmentHG']
});

db.Member.update({EmployeeId: {$in: ["HG002", "HG003", "HG007"]}}, {$addToSet: {AddedPermissions: "SwitchEnvironmentHG"}}, {multi: true});
db.Member.update({EmployeeId: {$in: ["HG001"]}}, {$addToSet: {AddedPermissions: "SwitchEnvironmentSales"}}, {multi: true});
db.Member.update({EmployeeId: {$in: ["HG009"]}}, {$addToSet: {AddedPermissions: "SwitchEnvironmentQA"}}, {multi: true});

switchDB("hgperka");
// Add default excluded groupId field
db.TangoCard.update({}, {$set  : {ExcludedGroupIds : []}}, {multi : true});

switchDB("hgthanka");
//Set Default Congrat Status to Active
db.Congrat.update({}, {$set : {Status : 'Active'}}, {multi : true});

//For Deleted Recognitions
var deletedRecognitions = db.Recognition.find({ Status : 'Deleted'}, {hgId : 1, BatchId : 1});
var delRecIds = [], batchIds = [];

for (i = 0; i < deletedRecognitions.length(); i += 1) {
    delRecIds.push(deletedRecognitions[i].hgId);
    batchIds.push(deletedRecognitions[i].BatchId);
}

//Mark deleted recognition comments
db.Comment.update({EntityId : {$in : batchIds}}, {$set : {Status : 'Deleted'}}, {multi : true});

//Mark Deleted recognition congrats
db.Congrat.update({RecognitionIds : {$in : delRecIds}}, {$set : {Status : 'Deleted'}}, {multi : true});

//Script to Add type property comments made before schema change
db.Comment.update({Type : {$exists : false}}, { $set : {Type : 'Comment'}}, {multi : true});

//Script to Add missing comment status field, defaulting to Active
db.Comment.update({Status : {$exists : false}}, {$set : {Status : 'Active'}}, {multi : true});

//Script to set Missing GroupId
switchDB("hgcommon");
var UserIdGroup = {}, mercuryGroupId;
mercuryGroupId = db.Group.findOne({GroupName : 'Mercury Industries'}, {hgId : 1});
db.Member.find({}).forEach(function (item) {
    if (!UserIdGroup[item.UserId]) {
        UserIdGroup[item.UserId] = item.GroupId;
    } else {
        UserIdGroup[item.UserId] = mercuryGroupId.hgId;
    }
});

switchDB("hgthanka");
db.Comment.find({'GroupId' : {$exists : false}}).forEach(function (item) {
    if (UserIdGroup[item.CommenterUserhgId] !== undefined) {
        db.Comment.update({hgId : item.hgId}, {$set : {GroupId : UserIdGroup[item.CommenterUserhgId]}});
    }
});


// ---> Run Analytics/migration.js
// It includes fix for utc date
// setup to include activity source ( web, mobile)