load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

var departmentsToDelete = [
    'Business Office',
    'Central Office',
    'Construction',
    'Help Desk',
    'Installation & Repair',
    'Installation and Repair',
    'Internet Helpdesk',
    'NOC Technician',
    'Warehouse'
],
query = {
   GroupName : 'Fidelity Communications',
   Type : 'Department',
   Status : "Active",
   Name : { $in : departmentsToDelete},
   ChildTeams : {$size : 0}
},
update = {
  $set :{
    ModifiedDate : new Date().getTime(),
    Status : 'Deleted'
  }
};

db.Team.update(query, update, {multi : true});

//add index on Notification
db.Notification.ensureIndex({
  Deleted : 1,
  RecipientId : 1,
  ActionUrl: 1
});
  