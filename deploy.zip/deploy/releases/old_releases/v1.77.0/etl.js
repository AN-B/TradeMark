var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        guid = require('node-uuid'),
        Async = require('async');

    // to generate more guids for the guidMap, use each enviornment to generate the guids, for example for uat:
    // https://uat.highground.com/svc/Provision/GenerateGuids/30
    // the last part of the route is the number of guids to generate, with a maximum of 100

    function tutorialSetup(callback) {
        var tutorialMappings = [
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 1, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-1.html', ExitURL: '', Permissions: 'Basic', TargetSelector: ''},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 2, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-2.html', ExitURL: '', Permissions: 'Basic', TargetSelector: ''},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 3, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-3.html', ExitURL: '', Permissions: 'Basic', TargetSelector: '[ng-href="#/User/Account"]'},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 4, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-4.html', ExitURL: '', Permissions: 'Basic', TargetSelector: ''},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 5, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-5.html', ExitURL: '', Permissions: 'Basic', TargetSelector: '[translate="common.fst"]'},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 6, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-6.html', ExitURL: '', Permissions: 'Basic', TargetSelector: '[translate="users.ac.pr.cp"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'CompanyFeed', TutorialNumber: 1, Step: 1, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/Recognize-CompanyFeed-1.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[ translate="common.rec"]', EventName: ''},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'CompanyFeed', TutorialNumber: 1, Step: 2, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/Recognize-CompanyFeed-2.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '.meta', EventName: ''},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'CompanyFeed', TutorialNumber: 1, Step: 3, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/Recognize-CompanyFeed-3.html', ExitURL: '/Company/Filter/All', Permissions: 'GiveRecognition', TargetSelector: '.search-container', EventName: ''},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 1, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-1.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: ''},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 2, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-2.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[translate="common.recw"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 3, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-3.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[translate="common.chob"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 4, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-4.html', ExitURL: '', Permissions: 'CustomizedRecognition', TargetSelector: '[ng-if="isCustom"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 5, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-5.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[translate="common.wri"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 6, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-6.html', ExitURL: '', Permissions: 'SendPointsInRecognition', TargetSelector: '[ng-click="request.MoreOptions.pointValueClicked = !request.MoreOptions.pointValueClicked"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 7, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-7.html', ExitURL: '', Permissions: 'AddGiftToNewRecognition', TargetSelector: '[ng-click="openGiftDialog()"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 8, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-8.html', ExitURL: '', Permissions: 'HideRecognition', TargetSelector: '[ng-if="!request.MoreOptions.suppressFeed"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 9, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-9.html', ExitURL: '/Company/Filter/All', Permissions: 'GiveRecognition', TargetSelector: '.btn-close.btn-close-success.pull-right'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 3, Step: 1, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/VirtualCurrency-1.html', ExitURL: '', Permissions: 'PointStore', TargetSelector: ''},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 3, Step: 2, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/VirtualCurrency-2.html', ExitURL: '', Permissions: 'PointStore', TargetSelector: '.currency.ng-scope.divider'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 3, Step: 3, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/VirtualCurrency-3.html', ExitURL: '', Permissions: 'PointStore', TargetSelector: '.meta'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 3, Step: 4, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/VirtualCurrency-4.html', ExitURL: '', Permissions: 'PointStore', TargetSelector: '[ng-href="#/Motivate/Rewards"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 3, Step: 5, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/VirtualCurrency-5.html', ExitURL: '', Permissions: 'PointStore', TargetSelector: '.gift-attached'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 4, Step: 1, RouteURL: '/Motivate/Rewards', TemplateURL: '/Company/VirtualCurrency-6.html', ExitURL: '', Permissions: 'suggestRewardIdea', TargetSelector: '[ng-if="flags.canSuggestReward"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 5, Step: 1, RouteURL: '', TemplateURL: '/Company/VirtualCurrency-7.html', ExitURL: '', Permissions: 'PointStore', TargetSelector: '.currency.ng-scope.divider'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Points', Feature: 'Virtual Currency', TutorialNumber: 6, Step: 1, RouteURL: '', TemplateURL: '/Company/VirtualCurrency-8.html', ExitURL: '', Permissions: 'PointStore', TargetSelector: '.rays', EventName: 'HgAppRecognitionReceived'},
                { PrimaryCategory: 'Profile', SecondaryCategory: 'Perform', Feature: '', TutorialNumber: 7, Step: 1, RouteURL: '/Profile/Perform', TemplateURL: '/Profile/Perform-1.html', ExitURL: '', Permissions: 'perform', TargetSelector: '[ng-repeat="review in pendingReviews | limitTo: pendingLimitTo"]', EventName: ''},
                { PrimaryCategory: 'Profile', SecondaryCategory: 'Perform', Feature: '', TutorialNumber: 8, Step: 1, RouteURL: '/Profile/Perform', TemplateURL: '/Profile/Perform-2.html', ExitURL: '', Permissions: 'perform', TargetSelector: '', EventName: ''},
                { PrimaryCategory: 'Profile', SecondaryCategory: 'Perform', Feature: '', TutorialNumber: 8, Step: 2, RouteURL: '/Profile/Perform', TemplateURL: '/Profile/Perform-3.html', ExitURL: '', Permissions: 'perform', TargetSelector: '[translate="profile.per.rev.vio"]', EventName: ''},
                { PrimaryCategory: 'Profile', SecondaryCategory: 'Perform', Feature: '', TutorialNumber: 9, Step: 1, RouteURL: '/Profile/Perform', TemplateURL: '/Profile/Perform-4.html', ExitURL: '', Permissions: 'perform', TargetSelector: '[ng-click="review.showReqEdit=true"]', EventName: ''}
            ],
            guidMap = {
                uat:     ["2861ae50-9c04-11e4-a4de-a15bf404e311","2861ae51-9c04-11e4-a4de-a15bf404e311","2861ae52-9c04-11e4-a4de-a15bf404e311","2861ae53-9c04-11e4-a4de-a15bf404e311","2861ae54-9c04-11e4-a4de-a15bf404e311","2861ae55-9c04-11e4-a4de-a15bf404e311","2861ae56-9c04-11e4-a4de-a15bf404e311","2861ae57-9c04-11e4-a4de-a15bf404e311","2861ae58-9c04-11e4-a4de-a15bf404e311","2861ae59-9c04-11e4-a4de-a15bf404e311","2861ae5a-9c04-11e4-a4de-a15bf404e311","2861ae5b-9c04-11e4-a4de-a15bf404e311","2861ae5c-9c04-11e4-a4de-a15bf404e311","2861ae5d-9c04-11e4-a4de-a15bf404e311","2861ae5e-9c04-11e4-a4de-a15bf404e311","2861ae5f-9c04-11e4-a4de-a15bf404e311","2861ae60-9c04-11e4-a4de-a15bf404e311","2861ae61-9c04-11e4-a4de-a15bf404e311","2861ae62-9c04-11e4-a4de-a15bf404e311","2861ae63-9c04-11e4-a4de-a15bf404e311","2861ae64-9c04-11e4-a4de-a15bf404e311","95217f50-be02-11e4-9a42-4fc0afd6d8ca","95217f51-be02-11e4-9a42-4fc0afd6d8ca","95217f52-be02-11e4-9a42-4fc0afd6d8ca","95217f53-be02-11e4-9a42-4fc0afd6d8ca","95217f54-be02-11e4-9a42-4fc0afd6d8ca","95217f55-be02-11e4-9a42-4fc0afd6d8ca","95217f56-be02-11e4-9a42-4fc0afd6d8ca","95217f57-be02-11e4-9a42-4fc0afd6d8ca","95217f58-be02-11e4-9a42-4fc0afd6d8ca"],
                demo:    ["6c2b5530-9c0b-11e4-ae29-8d81d558fe40","6c2b5531-9c0b-11e4-ae29-8d81d558fe40","6c2b5532-9c0b-11e4-ae29-8d81d558fe40","6c2b5533-9c0b-11e4-ae29-8d81d558fe40","6c2b5534-9c0b-11e4-ae29-8d81d558fe40","6c2b5535-9c0b-11e4-ae29-8d81d558fe40","6c2b5536-9c0b-11e4-ae29-8d81d558fe40","6c2b5537-9c0b-11e4-ae29-8d81d558fe40","6c2b5538-9c0b-11e4-ae29-8d81d558fe40","6c2b5539-9c0b-11e4-ae29-8d81d558fe40","6c2b553a-9c0b-11e4-ae29-8d81d558fe40","6c2b553b-9c0b-11e4-ae29-8d81d558fe40","6c2b553c-9c0b-11e4-ae29-8d81d558fe40","6c2b553d-9c0b-11e4-ae29-8d81d558fe40","6c2b553e-9c0b-11e4-ae29-8d81d558fe40","6c2b553f-9c0b-11e4-ae29-8d81d558fe40","6c2b5540-9c0b-11e4-ae29-8d81d558fe40","6c2b5541-9c0b-11e4-ae29-8d81d558fe40","6c2b5542-9c0b-11e4-ae29-8d81d558fe40","6c2b5543-9c0b-11e4-ae29-8d81d558fe40","6c2b5544-9c0b-11e4-ae29-8d81d558fe40","fcf73930-be02-11e4-a51f-d3af1a34d90e","fcf73931-be02-11e4-a51f-d3af1a34d90e","fcf73932-be02-11e4-a51f-d3af1a34d90e","fcf73933-be02-11e4-a51f-d3af1a34d90e","fcf73934-be02-11e4-a51f-d3af1a34d90e","fcf73935-be02-11e4-a51f-d3af1a34d90e","fcf73936-be02-11e4-a51f-d3af1a34d90e","fcf73937-be02-11e4-a51f-d3af1a34d90e","fcf73938-be02-11e4-a51f-d3af1a34d90e"],
                prod:    ["767b4180-9c0b-11e4-808a-d3147cb7b801","767b4181-9c0b-11e4-808a-d3147cb7b801","767b4182-9c0b-11e4-808a-d3147cb7b801","767b4183-9c0b-11e4-808a-d3147cb7b801","767b4184-9c0b-11e4-808a-d3147cb7b801","767b4185-9c0b-11e4-808a-d3147cb7b801","767b4186-9c0b-11e4-808a-d3147cb7b801","767b4187-9c0b-11e4-808a-d3147cb7b801","767b4188-9c0b-11e4-808a-d3147cb7b801","767b4189-9c0b-11e4-808a-d3147cb7b801","767b418a-9c0b-11e4-808a-d3147cb7b801","767b418b-9c0b-11e4-808a-d3147cb7b801","767b418c-9c0b-11e4-808a-d3147cb7b801","767b418d-9c0b-11e4-808a-d3147cb7b801","767b418e-9c0b-11e4-808a-d3147cb7b801","767b418f-9c0b-11e4-808a-d3147cb7b801","767b4190-9c0b-11e4-808a-d3147cb7b801","767b4191-9c0b-11e4-808a-d3147cb7b801","767b4192-9c0b-11e4-808a-d3147cb7b801","767b4193-9c0b-11e4-808a-d3147cb7b801","767b4194-9c0b-11e4-808a-d3147cb7b801","0a19f490-be03-11e4-b306-77dd5a3064be","0a19f491-be03-11e4-b306-77dd5a3064be","0a19f492-be03-11e4-b306-77dd5a3064be","0a19f493-be03-11e4-b306-77dd5a3064be","0a1a1ba0-be03-11e4-b306-77dd5a3064be","0a1a1ba1-be03-11e4-b306-77dd5a3064be","0a1a1ba2-be03-11e4-b306-77dd5a3064be","0a1a1ba3-be03-11e4-b306-77dd5a3064be","0a1a1ba4-be03-11e4-b306-77dd5a3064be"],
                st:      ["c57bdd80-9c0b-11e4-acb9-b7fa12cd730a","c57bdd81-9c0b-11e4-acb9-b7fa12cd730a","c57bdd82-9c0b-11e4-acb9-b7fa12cd730a","c57bdd83-9c0b-11e4-acb9-b7fa12cd730a","c57bdd84-9c0b-11e4-acb9-b7fa12cd730a","c57bdd85-9c0b-11e4-acb9-b7fa12cd730a","c57bdd86-9c0b-11e4-acb9-b7fa12cd730a","c57bdd87-9c0b-11e4-acb9-b7fa12cd730a","c57bdd88-9c0b-11e4-acb9-b7fa12cd730a","c57bdd89-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8a-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8b-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8c-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8d-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8e-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8f-9c0b-11e4-acb9-b7fa12cd730a","c57bdd90-9c0b-11e4-acb9-b7fa12cd730a","c57bdd91-9c0b-11e4-acb9-b7fa12cd730a","c57bdd92-9c0b-11e4-acb9-b7fa12cd730a","c57bdd93-9c0b-11e4-acb9-b7fa12cd730a","c57bdd94-9c0b-11e4-acb9-b7fa12cd730a","1ece3f90-be03-11e4-8a15-65444ecdd73d","1ece3f91-be03-11e4-8a15-65444ecdd73d","1ece66a0-be03-11e4-8a15-65444ecdd73d","1ece66a1-be03-11e4-8a15-65444ecdd73d","1ece66a2-be03-11e4-8a15-65444ecdd73d","1ece66a3-be03-11e4-8a15-65444ecdd73d","1ece66a4-be03-11e4-8a15-65444ecdd73d","1ece66a5-be03-11e4-8a15-65444ecdd73d","1ece66a6-be03-11e4-8a15-65444ecdd73d"],
                poc:     ["dc9a98d0-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe0-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe1-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe2-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe3-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe4-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe5-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe6-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe7-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe8-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe9-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfea-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfeb-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfec-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfed-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfee-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfef-9c0b-11e4-81cc-c91ee3d78d7e","dc9abff0-9c0b-11e4-81cc-c91ee3d78d7e","dc9abff1-9c0b-11e4-81cc-c91ee3d78d7e","dc9abff2-9c0b-11e4-81cc-c91ee3d78d7e","dc9abff3-9c0b-11e4-81cc-c91ee3d78d7e","2bbacfc0-be03-11e4-b6c1-a777a0a0ff3d","2bbc0840-be03-11e4-b6c1-a777a0a0ff3d","2bbc0841-be03-11e4-b6c1-a777a0a0ff3d","2bbc0842-be03-11e4-b6c1-a777a0a0ff3d","2bbc0843-be03-11e4-b6c1-a777a0a0ff3d","2bbc0844-be03-11e4-b6c1-a777a0a0ff3d","2bbc0845-be03-11e4-b6c1-a777a0a0ff3d","2bbc0846-be03-11e4-b6c1-a777a0a0ff3d","2bbc0847-be03-11e4-b6c1-a777a0a0ff3d"],
                tron:    ["30bada10-9c0c-11e4-ac8e-c1ad1385e716","30d93780-9c0c-11e4-ac8e-c1ad1385e716","30d93781-9c0c-11e4-ac8e-c1ad1385e716","30d93782-9c0c-11e4-ac8e-c1ad1385e716","30d93783-9c0c-11e4-ac8e-c1ad1385e716","30d93784-9c0c-11e4-ac8e-c1ad1385e716","30d93785-9c0c-11e4-ac8e-c1ad1385e716","30d93786-9c0c-11e4-ac8e-c1ad1385e716","30d93787-9c0c-11e4-ac8e-c1ad1385e716","30d93788-9c0c-11e4-ac8e-c1ad1385e716","30d93789-9c0c-11e4-ac8e-c1ad1385e716","30d9378a-9c0c-11e4-ac8e-c1ad1385e716","30d9378b-9c0c-11e4-ac8e-c1ad1385e716","30d9378c-9c0c-11e4-ac8e-c1ad1385e716","30d9378d-9c0c-11e4-ac8e-c1ad1385e716","30d9378e-9c0c-11e4-ac8e-c1ad1385e716","30d9378f-9c0c-11e4-ac8e-c1ad1385e716","30d93790-9c0c-11e4-ac8e-c1ad1385e716","30d93791-9c0c-11e4-ac8e-c1ad1385e716","30d93792-9c0c-11e4-ac8e-c1ad1385e716","30d93793-9c0c-11e4-ac8e-c1ad1385e716","39a32510-be03-11e4-8db6-bfb337ed1661","39a32511-be03-11e4-8db6-bfb337ed1661","39a32512-be03-11e4-8db6-bfb337ed1661","39a32513-be03-11e4-8db6-bfb337ed1661","39a32514-be03-11e4-8db6-bfb337ed1661","39a32515-be03-11e4-8db6-bfb337ed1661","39a32516-be03-11e4-8db6-bfb337ed1661","39a32517-be03-11e4-8db6-bfb337ed1661","39a32518-be03-11e4-8db6-bfb337ed1661"],
                borg:    ["38249660-9c0c-11e4-8e70-fb5ae53d6955","38249661-9c0c-11e4-8e70-fb5ae53d6955","38249662-9c0c-11e4-8e70-fb5ae53d6955","38249663-9c0c-11e4-8e70-fb5ae53d6955","38249664-9c0c-11e4-8e70-fb5ae53d6955","38249665-9c0c-11e4-8e70-fb5ae53d6955","38249666-9c0c-11e4-8e70-fb5ae53d6955","38249667-9c0c-11e4-8e70-fb5ae53d6955","38249668-9c0c-11e4-8e70-fb5ae53d6955","38249669-9c0c-11e4-8e70-fb5ae53d6955","3824966a-9c0c-11e4-8e70-fb5ae53d6955","3824966b-9c0c-11e4-8e70-fb5ae53d6955","3824966c-9c0c-11e4-8e70-fb5ae53d6955","3824966d-9c0c-11e4-8e70-fb5ae53d6955","3824966e-9c0c-11e4-8e70-fb5ae53d6955","3824966f-9c0c-11e4-8e70-fb5ae53d6955","38249670-9c0c-11e4-8e70-fb5ae53d6955","38249671-9c0c-11e4-8e70-fb5ae53d6955","38249672-9c0c-11e4-8e70-fb5ae53d6955","38249673-9c0c-11e4-8e70-fb5ae53d6955","38249674-9c0c-11e4-8e70-fb5ae53d6955","481a25d0-be03-11e4-8444-9bf72b0cb527","481a4ce0-be03-11e4-8444-9bf72b0cb527","481a4ce1-be03-11e4-8444-9bf72b0cb527","481a4ce2-be03-11e4-8444-9bf72b0cb527","481a4ce3-be03-11e4-8444-9bf72b0cb527","481a4ce4-be03-11e4-8444-9bf72b0cb527","481a4ce5-be03-11e4-8444-9bf72b0cb527","481a4ce6-be03-11e4-8444-9bf72b0cb527","481a4ce7-be03-11e4-8444-9bf72b0cb527"],
                cylon:   ["42b55c40-9c0c-11e4-9766-a1d7a8979156","42b55c41-9c0c-11e4-9766-a1d7a8979156","42b55c42-9c0c-11e4-9766-a1d7a8979156","42b55c43-9c0c-11e4-9766-a1d7a8979156","42b55c44-9c0c-11e4-9766-a1d7a8979156","42b55c45-9c0c-11e4-9766-a1d7a8979156","42b55c46-9c0c-11e4-9766-a1d7a8979156","42b55c47-9c0c-11e4-9766-a1d7a8979156","42b55c48-9c0c-11e4-9766-a1d7a8979156","42b55c49-9c0c-11e4-9766-a1d7a8979156","42b55c4a-9c0c-11e4-9766-a1d7a8979156","42b55c4b-9c0c-11e4-9766-a1d7a8979156","42b55c4c-9c0c-11e4-9766-a1d7a8979156","42b55c4d-9c0c-11e4-9766-a1d7a8979156","42b55c4e-9c0c-11e4-9766-a1d7a8979156","42b55c4f-9c0c-11e4-9766-a1d7a8979156","42b55c50-9c0c-11e4-9766-a1d7a8979156","42b55c51-9c0c-11e4-9766-a1d7a8979156","42b55c52-9c0c-11e4-9766-a1d7a8979156","42b55c53-9c0c-11e4-9766-a1d7a8979156","42b55c54-9c0c-11e4-9766-a1d7a8979156","5e3ad210-be03-11e4-b6e7-5d53ab0d9125","5e3ad211-be03-11e4-b6e7-5d53ab0d9125","5e3ad212-be03-11e4-b6e7-5d53ab0d9125","5e3ad213-be03-11e4-b6e7-5d53ab0d9125","5e3ad214-be03-11e4-b6e7-5d53ab0d9125","5e3ad215-be03-11e4-b6e7-5d53ab0d9125","5e3ad216-be03-11e4-b6e7-5d53ab0d9125","5e3ad217-be03-11e4-b6e7-5d53ab0d9125","5e3ad218-be03-11e4-b6e7-5d53ab0d9125"],
                ripley:  ["4c60cb30-9c0c-11e4-afab-efb76eb69e55","4c60cb31-9c0c-11e4-afab-efb76eb69e55","4c60cb32-9c0c-11e4-afab-efb76eb69e55","4c60cb33-9c0c-11e4-afab-efb76eb69e55","4c60cb34-9c0c-11e4-afab-efb76eb69e55","4c60cb35-9c0c-11e4-afab-efb76eb69e55","4c60cb36-9c0c-11e4-afab-efb76eb69e55","4c60cb37-9c0c-11e4-afab-efb76eb69e55","4c60cb38-9c0c-11e4-afab-efb76eb69e55","4c60cb39-9c0c-11e4-afab-efb76eb69e55","4c60cb3a-9c0c-11e4-afab-efb76eb69e55","4c60cb3b-9c0c-11e4-afab-efb76eb69e55","4c60cb3c-9c0c-11e4-afab-efb76eb69e55","4c60cb3d-9c0c-11e4-afab-efb76eb69e55","4c60cb3e-9c0c-11e4-afab-efb76eb69e55","4c60cb3f-9c0c-11e4-afab-efb76eb69e55","4c60cb40-9c0c-11e4-afab-efb76eb69e55","4c60cb41-9c0c-11e4-afab-efb76eb69e55","4c60cb42-9c0c-11e4-afab-efb76eb69e55","4c60cb43-9c0c-11e4-afab-efb76eb69e55","4c60cb44-9c0c-11e4-afab-efb76eb69e55","6fd84020-be03-11e4-a641-959c34aae534","6fd84021-be03-11e4-a641-959c34aae534","6fd84022-be03-11e4-a641-959c34aae534","6fd84023-be03-11e4-a641-959c34aae534","6fd84024-be03-11e4-a641-959c34aae534","6fd84025-be03-11e4-a641-959c34aae534","6fd84026-be03-11e4-a641-959c34aae534","6fd84027-be03-11e4-a641-959c34aae534","6fd84028-be03-11e4-a641-959c34aae534"],
                dev:     ["663111f0-9c0c-11e4-90f9-71eb2b22503e","663111f1-9c0c-11e4-90f9-71eb2b22503e","663111f2-9c0c-11e4-90f9-71eb2b22503e","663111f3-9c0c-11e4-90f9-71eb2b22503e","663111f4-9c0c-11e4-90f9-71eb2b22503e","663111f5-9c0c-11e4-90f9-71eb2b22503e","663111f6-9c0c-11e4-90f9-71eb2b22503e","663111f7-9c0c-11e4-90f9-71eb2b22503e","663111f8-9c0c-11e4-90f9-71eb2b22503e","663111f9-9c0c-11e4-90f9-71eb2b22503e","663111fa-9c0c-11e4-90f9-71eb2b22503e","663111fb-9c0c-11e4-90f9-71eb2b22503e","663111fc-9c0c-11e4-90f9-71eb2b22503e","663111fd-9c0c-11e4-90f9-71eb2b22503e","663111fe-9c0c-11e4-90f9-71eb2b22503e","663111ff-9c0c-11e4-90f9-71eb2b22503e","66311200-9c0c-11e4-90f9-71eb2b22503e","66311201-9c0c-11e4-90f9-71eb2b22503e","66311202-9c0c-11e4-90f9-71eb2b22503e","66311203-9c0c-11e4-90f9-71eb2b22503e","66311204-9c0c-11e4-90f9-71eb2b22503e","8d573700-be03-11e4-a7e2-ebf7fda9347f","8d573701-be03-11e4-a7e2-ebf7fda9347f","8d573702-be03-11e4-a7e2-ebf7fda9347f","8d573703-be03-11e4-a7e2-ebf7fda9347f","8d573704-be03-11e4-a7e2-ebf7fda9347f","8d573705-be03-11e4-a7e2-ebf7fda9347f","8d573706-be03-11e4-a7e2-ebf7fda9347f","8d573707-be03-11e4-a7e2-ebf7fda9347f","8d573708-be03-11e4-a7e2-ebf7fda9347f"],
                qa:      ["a26fe920-be03-11e4-81cb-0b88435d5397","a26fe921-be03-11e4-81cb-0b88435d5397","a2701030-be03-11e4-81cb-0b88435d5397","a2701031-be03-11e4-81cb-0b88435d5397","a2701032-be03-11e4-81cb-0b88435d5397","a2701033-be03-11e4-81cb-0b88435d5397","a2701034-be03-11e4-81cb-0b88435d5397","a2701035-be03-11e4-81cb-0b88435d5397","a2701036-be03-11e4-81cb-0b88435d5397","a2701037-be03-11e4-81cb-0b88435d5397","a2701038-be03-11e4-81cb-0b88435d5397","a2701039-be03-11e4-81cb-0b88435d5397","a270103a-be03-11e4-81cb-0b88435d5397","a270103b-be03-11e4-81cb-0b88435d5397","a270103c-be03-11e4-81cb-0b88435d5397","a270103d-be03-11e4-81cb-0b88435d5397","a270103e-be03-11e4-81cb-0b88435d5397","a270103f-be03-11e4-81cb-0b88435d5397","a2701040-be03-11e4-81cb-0b88435d5397","a2701041-be03-11e4-81cb-0b88435d5397","a2701042-be03-11e4-81cb-0b88435d5397","a2701043-be03-11e4-81cb-0b88435d5397","a2701044-be03-11e4-81cb-0b88435d5397","a2701045-be03-11e4-81cb-0b88435d5397","a2701046-be03-11e4-81cb-0b88435d5397","a2701047-be03-11e4-81cb-0b88435d5397","a2701048-be03-11e4-81cb-0b88435d5397","a2701049-be03-11e4-81cb-0b88435d5397","a270104a-be03-11e4-81cb-0b88435d5397","a270104b-be03-11e4-81cb-0b88435d5397"],
                scully:  ["d01390c0-be03-11e4-8fdf-d9f80b59ca9d","d01390c1-be03-11e4-8fdf-d9f80b59ca9d","d01390c2-be03-11e4-8fdf-d9f80b59ca9d","d01390c3-be03-11e4-8fdf-d9f80b59ca9d","d01390c4-be03-11e4-8fdf-d9f80b59ca9d","d01390c5-be03-11e4-8fdf-d9f80b59ca9d","d01390c6-be03-11e4-8fdf-d9f80b59ca9d","d01390c7-be03-11e4-8fdf-d9f80b59ca9d","d01390c8-be03-11e4-8fdf-d9f80b59ca9d","d01390c9-be03-11e4-8fdf-d9f80b59ca9d","d01390ca-be03-11e4-8fdf-d9f80b59ca9d","d01390cb-be03-11e4-8fdf-d9f80b59ca9d","d01390cc-be03-11e4-8fdf-d9f80b59ca9d","d01390cd-be03-11e4-8fdf-d9f80b59ca9d","d01390ce-be03-11e4-8fdf-d9f80b59ca9d","d01390cf-be03-11e4-8fdf-d9f80b59ca9d","d01390d0-be03-11e4-8fdf-d9f80b59ca9d","d01390d1-be03-11e4-8fdf-d9f80b59ca9d","d01390d2-be03-11e4-8fdf-d9f80b59ca9d","d01390d3-be03-11e4-8fdf-d9f80b59ca9d","d01390d4-be03-11e4-8fdf-d9f80b59ca9d","d01390d5-be03-11e4-8fdf-d9f80b59ca9d","d01390d6-be03-11e4-8fdf-d9f80b59ca9d","d01390d7-be03-11e4-8fdf-d9f80b59ca9d","d01390d8-be03-11e4-8fdf-d9f80b59ca9d","d01390d9-be03-11e4-8fdf-d9f80b59ca9d","d01390da-be03-11e4-8fdf-d9f80b59ca9d","d01390db-be03-11e4-8fdf-d9f80b59ca9d","d01390dc-be03-11e4-8fdf-d9f80b59ca9d","d01390dd-be03-11e4-8fdf-d9f80b59ca9d"],
                trinity: ["d9bed8a0-be03-11e4-b088-1b1f124042dd","d9bed8a1-be03-11e4-b088-1b1f124042dd","d9beffb0-be03-11e4-b088-1b1f124042dd","d9beffb1-be03-11e4-b088-1b1f124042dd","d9beffb2-be03-11e4-b088-1b1f124042dd","d9beffb3-be03-11e4-b088-1b1f124042dd","d9beffb4-be03-11e4-b088-1b1f124042dd","d9beffb5-be03-11e4-b088-1b1f124042dd","d9beffb6-be03-11e4-b088-1b1f124042dd","d9beffb7-be03-11e4-b088-1b1f124042dd","d9beffb8-be03-11e4-b088-1b1f124042dd","d9beffb9-be03-11e4-b088-1b1f124042dd","d9beffba-be03-11e4-b088-1b1f124042dd","d9beffbb-be03-11e4-b088-1b1f124042dd","d9beffbc-be03-11e4-b088-1b1f124042dd","d9beffbd-be03-11e4-b088-1b1f124042dd","d9beffbe-be03-11e4-b088-1b1f124042dd","d9beffbf-be03-11e4-b088-1b1f124042dd","d9beffc0-be03-11e4-b088-1b1f124042dd","d9beffc1-be03-11e4-b088-1b1f124042dd","d9beffc2-be03-11e4-b088-1b1f124042dd","d9beffc3-be03-11e4-b088-1b1f124042dd","d9beffc4-be03-11e4-b088-1b1f124042dd","d9beffc5-be03-11e4-b088-1b1f124042dd","d9beffc6-be03-11e4-b088-1b1f124042dd","d9beffc7-be03-11e4-b088-1b1f124042dd","d9beffc8-be03-11e4-b088-1b1f124042dd","d9beffc9-be03-11e4-b088-1b1f124042dd","d9beffca-be03-11e4-b088-1b1f124042dd","d9beffcb-be03-11e4-b088-1b1f124042dd"],
                local: [
                    '1364e3e0-b44f-4627-a729-8c13ac78ad5e',
                    '4f891c5c-0764-4e5a-9ff1-4d173e531206',
                    '13dc141f-c5c8-4181-91b9-9a4c8a6d4d40',
                    '34b8d4fe-2777-4de6-9125-b9d9de6a6d9a',
                    '775eca24-d9bc-4c70-9995-bb33da6f03fa',
                    'ea0dfc47-0afc-4aec-88b6-1e428d269a7a',
                    '639ea0f1-340c-4beb-ab1d-b3410cca061d',
                    'c224bfce-9e61-4b0f-9968-6401d638e91c',
                    '022c4bc7-93cd-4327-945c-e58544fe7f98',
                    '447cb421-0522-461d-8518-f966f30b7916',
                    'c249438b-0cf8-4363-8db9-3433edc8434f',
                    '73ca27d5-0e6d-413f-b60b-bca86057c0b8',
                    'cc0169a0-4fb2-412c-94ed-35dfd9e8bafa',
                    'ee070dac-5f10-47ba-bbe2-c20a8ad3d48c',
                    'd1d05993-7d61-4c8e-86bb-7f66b022dda2',
                    '434c3003-134f-40c2-b290-839c2ffa984f',
                    '6db388f6-dc67-4fa6-b87c-2de797f174c8',
                    'cbf07b41-05e1-4f60-9793-97161785c2ed',
                    'd45fc3fb-39a5-4035-ad5f-1bdd7e30a28e',
                    '541f369b-f519-4126-91ab-8b978b8031af',
                    'af639496-0099-42ab-ae95-a2d532a62a83',
                    '3f6a4c57-a2ba-4514-bd42-5659991f0272',
                    'ea11b4d6-e90a-4b91-85bb-1faafd02872e',
                    '38092c9a-1151-4bc5-a5ab-e9e7637cbbc1',
                    '44b7d127-6637-4835-b4b1-b7c44d71929b',
                    'e0e8cb3a-28cb-4a76-a54d-c88cf78dbd1f',
                    '8211b9aa-7cf4-489f-aadf-11a7b4a6f418',
                    '802de31c-bbd0-433f-aad6-4cf4d0acf828',
                    '370ffa58-32d6-4f30-9879-94b8222afff5',
                    'c3a81e0f-7348-4ff0-ab15-c62a4881f4ed'
                ]
            },
            tutorialIds = guidMap[process.env.BUILD_ENV],
            i,
            len,
            fullCategoryString,
            tutorialMapping,
            allTutorials = [];
        if (!tutorialIds) {
            tutorialIds = guidMap.local;
        }
        for (i = 0, len = tutorialMappings.length; i < len; i += 1) {
            tutorialMapping = tutorialMappings[i];
            fullCategoryString = tutorialMapping.PrimaryCategory + ':' + tutorialMapping.SecondaryCategory + (tutorialMapping.Feature ? ':' + tutorialMapping.Feature : '');
            allTutorials.push({
                hgId: tutorialIds[i],
                FullCategory: fullCategoryString.replace(/\s+/g, ''),
                PrimaryCategory: tutorialMapping.PrimaryCategory,
                SecondaryCategory: tutorialMapping.SecondaryCategory,
                Feature: tutorialMapping.Feature,
                TutorialNumber: tutorialMapping.TutorialNumber,
                Step: tutorialMapping.Step,
                RouteURL: tutorialMapping.RouteURL,
                TemplateURL: tutorialMapping.TemplateURL,
                ExitURL: tutorialMapping.ExitURL,
                Permissions: tutorialMapping.Permissions || 'Basic',
                TargetSelector: tutorialMapping.TargetSelector,
                EventName: tutorialMapping.EventName || '',
            });
        }
        // remove all tutorials
        EntityCache.Tutorial.remove({}, function (error) {
            if (!error) {
                console.log('Removed tutorial records.');
                EntityCache.Tutorial.create(allTutorials, function(error) {
                    if (error) {
                        callback(error);
                    } else {
                        console.log('Tutorials records created.');
                        callback();
                    }
                });
            } else {
                callback(error);
            }
        });
    }

    function setMemberDepartment(fcallback) {
        function updateMemberDepartment(request, callback) {
            var query = {
                Name : request.GroupDepartmentName,
                'TeamMembers.MemberId' : request.hgId,
                Type : 'Department'
            };
            EntityCache.Team.findOne(query, function (error, department) {
                if (error) {
                    callback(error);
                } else if (!department) {
                    callback();
                } else {
                    var update = {
                        $set : {
                            ModifiedDate : new Date().getTime(),
                            GroupDepartmentId : department.hgId
                        }
                    };
                    EntityCache.Member.update({hgId : request.hgId}, update, function (error, members) {
                        if (error) {
                            return callback(error);
                        }
                        callback();
                    });
                }
            });
        }
        var query = {
            MembershipStatus : 'Active',
            $and : [
                {GroupDepartmentName : { $exists : true}},
                {GroupDepartmentName : { $ne : ''}}
            ]
        };
        EntityCache.Member.find(query, function (error, members) {
            if (error) {
                return fcallback(error);
            }
            Async.each(members, updateMemberDepartment, fcallback);
        });
    }

    function addStruckMissingAlert(callback) {
        var alert = {
            "GroupId" : "28c6a300-d0a3-11e3-9876-450840dd7df6",
            "Status" : "Active",
            "ReportMemberId" : "28d79324-d0a3-11e3-9876-450840dd7df6", // Ethan Heugly 
            "ManagerMemberId" : "28d79357-d0a3-11e3-9876-450840dd7df6", // Matt Anderson
            "Category" : "Perform",
            "AlertType" : "PerformPendingReview",
            "Severity" : "Urgent",
            "Data" : {
                "ReviewId" : "7bc55170-abca-11e4-93f9-91f264273cd1",
                "CycleName" : "Annual Review 2014"
            },
            "ModifiedDate" : 1422984710582,
            "ModifiedBy" : "",
            "CreatedDate" : 1422984710582,
            "CreatedBy" : "",
            "hgId" : guid.v1()
        };
        EntityCache.Group.findOne({hgId : "28c6a300-d0a3-11e3-9876-450840dd7df6"}, function (error, result) {
            if (error) {
                callback(error);
            } else if (!result) {
                callback();
            } else { // add record
                EntityCache.ManagerAlert.create([alert], callback);
            }
        });
    }

    this.Run = function (callback) {
        Async.series([
            addStruckMissingAlert,
            tutorialSetup,
            setMemberDepartment
        ], callback);
    }
};
module.exports = new HgMigrationFile();
