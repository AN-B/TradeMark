var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function removeCheckTangoAccountBalanceJob(callback) {
        EntityCache.Job.remove({JobName: "CheckTangoAccountBalance"}, callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            removeCheckTangoAccountBalanceJob
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();