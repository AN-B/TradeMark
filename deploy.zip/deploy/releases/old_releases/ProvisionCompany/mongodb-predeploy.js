load("db-scripts/commonDB.js");

switchDB("hgcommon");

//RollbackScript
var groupId = db.Group.findOne({'GroupName' : 'Dynamic'}, {_id : 0, hgId : 1});
if (groupId !== null) {
	groupId = groupId.hgId;
	db.UserInfo.remove({'Preference.DefaultGroupId' : groupId});  
	db.Member.remove({"GroupId": groupId});
	db.Team.remove({"GroupId": groupId});
	db.ProvisionActivity.remove({'EntityValue' : groupId});
}

var batchId = db.ProvisionBatch.findOne({"FileName": "Dynamic_Core.xlsx"},  {_id : 0, hgId : 1});
if (batchId !== null) {
	batchId = batchId.hgId;
	db.ProvisionActivity.remove({BatchId : batchId}, false);
}
db.Group.remove({'GroupName' : 'Dynamic'});
db.Team.remove({'GroupName' : 'Dynamic'});
db.Member.remove({'GroupName' : 'Dynamic'});
db.ProvisionBatch.remove({"FileName": "Dynamic_Core.xlsx"});

// need batchId to all provision activity
db.ProvisionActivity.remove({"Summary" : {$regex : '.* Dynamic.*'}}, false);
db.ProvisionActivity.remove({"Summary" : {$regex : '.*dynamic.com.*'}}, false);

switchDB("hgsecurity");
db.ActionToken.remove({});
db.UserSecurity .remove({UserName : {$regex : '.*dynamic.com.*'}}, false);

//To-Do
//Need script to set all group status to Active