/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function createOkrUpdateBadge(callback) {
        var badge = new EntityCache.Badge({
            "ModifiedDate" : Date.now(),
            "ModifiedBy" : "db-script",
            "CreatedDate" : Date.now(),
            "CreatedBy" : "db-script",
            "SpecialUsages" : [
                "Everyday"
            ],
            "Federated" : false,
            "GroupId" : "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
            "Archive" : false,
            "Category" : "Goal",
            "Tags" : "goal key result,okr",
            "Filename" : "goalupdateicon.svg",
            "BadgeName" : "Goal Key result update",
            "hgId" : "141911d0-9d2b-11e5-938e-b9ed166478ea"
        });
        EntityCache.Badge.findOne({
            Filename : "goalupdateicon.svg"
        }, function (error, existingBadge) {
            if (error) {
                return callback(error);
            }
            if (existingBadge) {
                console.log('Already exist, skipping');
                return callback();
            }
            badge.save(callback);
        });
    }
    this.Run = function (fcallback) {
        Async.series([
            createOkrUpdateBadge,
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
