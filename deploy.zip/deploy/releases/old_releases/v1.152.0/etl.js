/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        guid = require('node-uuid');

    function addGoalSortIndex(callback) {
        EntityCache.Goal.db.collections.Goal.dropIndex('CycleSearchIndex', function () {
            EntityCache.Goal.db.collections.Goal.ensureIndex({
                Name: 1,
                'Owner.FullName': 1,
                PercentCompletion: 1,
                Status: 1,
                'Participant.ParticipantType': 1,
                CycleTitle: 1,
                GroupId: 1
            }, {name: 'CycleSearchIndex', background: true}, callback);
        });
    }
    function addPatagoniaCheckInGuide(callback) {
        EntityCache.Group.findOne({GroupName: 'Patagonia'}, {hgId: 1}, function (error, group) {
            if (error || !group) {
                return callback(error);
            }
            EntityCache.FeedbackGuide.remove({GroupId: group.hgId, Type: 'SelfEvaluation'}, function (error) {
                if (error) {
                    return callback(error);
                }
                var guide = new EntityCache.FeedbackGuide({
                    hgId: guid.v1(),
                    GroupId: group.hgId,
                    Type: 'SelfEvaluation',
                    FileName: '59_Check_In_Guide.pdf'
                });
                guide.save(callback);
            });
        });
    }
    this.Run = function (fcallback) {
        Async.series([
            addGoalSortIndex,
            addPatagoniaCheckInGuide
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();