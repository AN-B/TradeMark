load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

// this is to test the automated database script deployment
db.Group.find({},{GroupName:1,_id:0}).forEach(function (group) {
    print(group);
});
