/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');


    function addProductItemIndex(callback) {
        EntityCache.ProductItem.db.collections.ProductItem.ensureIndex({
            GroupId : 1,
            Status : 1,
            ExpireDate : 1,
            'Accessibility.Locations.hgId' : 1
        }, {name : 'ProductItemDocIndex' }, callback);
    }

    function defaultProductItemAccessibility(callback) {
        var set = {
                Accessibility : {
                    RestrictByLocation : false,
                    RestrictByDept : false
                }
            };
        EntityCache.ProductItem.update({Accessibility : {$exists : false}}, {$set : set}, {multi : true}, function (error) {
            callback(error);
        });
    }

    function removeFieldsInProductItem(callback) {
        EntityCache.ProductItem.update({}, {$unset: {TeamId: true, TeamName : true}}, {multi : true}, function (error) {
            callback(error);
        });
    }

    this.Run = function (callback) {
        Async.series([
            defaultProductItemAccessibility,
            addProductItemIndex,
            removeFieldsInProductItem
        ], callback);
    };
};
module.exports = new HgMigrationFile();
