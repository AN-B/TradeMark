// Fix Comment Section
// 1) Change all MileStone to Milestone
db.Comment.update({'EntityType' : 'MileStone'}, { $set : {'EntityType' : 'Milestone'}}, {multi: true});

// 2) Update Missing EntityType Fields
comments = db.Comment.aggregate({$match :{"EntityType": { $nin : ["Milestone", "Recognition", "Coaching"]}}}).result;
for(i = 0; i < comments.length; i++) {
	recognition = db.Recognition.aggregate({$match :{hgId:comments[i].EntityId}}).result;
	if (recognition.length > 0) {
		db.Comment.update({'EntityId' : comments[i].EntityId}, { $set : {'EntityType' : 'Recognition'}}, {multi: true});
	} else { 
		db.Comment.update({'EntityId' : comments[i].EntityId}, { $set : {'EntityType' : 'Milestone'}}, {multi: true});
	}
}	

// 3 For all Comments Add GroupId to the collection
comments = db.Comment.aggregate({$match :{}}).result;
badRecog = [];
for(i = 0; i < comments.length; i++) {
	if (comments[i].EntityType === 'Recognition') {
		rec = db.Recognition.aggregate({$match : {hgId : comments[i].EntityId}}).result;
		if (rec.length > 0) {
			db.Comment.update({'EntityId' : comments[i].EntityId}, { $set : {'GroupId' : rec[0].Template.GroupId}}, {multi: true});
		} else {
			badRecog.push(comments[i].EntityId);
			//print(comments[i].EntityId)
		}
	} else if (comments[i].EntityType === 'Milestone') {
		rec = db.CareerTrack.aggregate({$match: {"CareerTrackTemplate.MileStones.hgId" : comments[i].EntityId}}).result;
		if (rec.length > 0) {
			db.Comment.update({'EntityId' : comments[i].EntityId}, { $set : {'GroupId' : rec[0].CareerTrackTemplate.GroupId}}, {multi: true});
		} else {
			rec = db.CareerTrack.aggregate({$match: {"CareerTrackTemplate.Goal.hgId" : comments[i].EntityId}}).result;
			if (rec.length > 0) {
				db.Comment.update({'EntityId' : comments[i].EntityId}, { $set : {'GroupId' : rec[0].CareerTrackTemplate.GroupId}}, {multi: true});
			}
		}
	} else if (comments[i].EntityType === 'Coaching') {
		rec = db.CareerTrack.aggregate({$match: {"CareerTrackTemplate.Goal.hgId" : comments[i].EntityId}}).result;
		if (rec.length > 0) {
			db.Comment.update({'EntityId' : comments[i].EntityId}, { $set : {'GroupId' : rec[0].CareerTrackTemplate.GroupId}}, {multi: true});
		}
	}
}

if (badRecog.length > 0) {
	print('# of Recognition Comments that do not match Recognition.hgId: ' + badRecog.length);
	verify = db.Recognition.aggregate({$match : { hgId : { $in : badRecog}}}).result;
	if (verify.length === 0) {
		// Remove bad Comments
		db.Comment.remove({EntityId : { $in : badRecog}});
	}
}

// Fix for Congrats - adding groupid
badCongrats = [];
congrats = db.Congrat.aggregate({$match:{}}).result;
for(i = 0; i < congrats.length; i++) {
	rec = db.Recognition.aggregate({$match : {hgId : congrats[i].RecognitionIds[0]}}).result;
	if (rec.length > 0) {
		db.Congrat.update({'RecognitionIds' : { $in : [congrats[i].RecognitionIds[0]]}}, { $set : {'GroupId' : rec[0].Template.GroupId}}, {multi: true});
	} else {
		badCongrats.push(congrats[i].RecognitionIds[0]);
	}
}

// Remove bad congrats recognitions
db.Congrat.remove({'RecognitionIds' : {$in : badCongrats}});

/************************************************/
// 1. Create a new database on Prod call hgreports
// 2. Add a new environment variable called MONGO_HGREPORTS pointing to the new hgreports database connection string
// 3. Add a new environment variable called REPORT_HGREPORTS pointing to the new hgreports database connection string
// 4. Call Report Service to load report aggregated data
// https://app.highground.com/svc/Report/BuildTrackActivityReport?StartDate=1357020000000&EndDate=1388469600000
// https://app.highground.com/svc/Report/BuildRecognitionActivityReport?StartDate=1357020000000&EndDate=1388469600000
// https://app.highground.com/svc/Report/BuildCommentActivityReport?StartDate=1357020000000&EndDate=1388469600000

