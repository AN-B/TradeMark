var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        guid = require('node-uuid'),
        Async = require('async');

    function tutorialSetup(callback) {
        var tutorialMappings = [
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 1, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-1.html', ExitURL: '', Permissions: 'Basic', TargetSelector: ''},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 2, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-2.html', ExitURL: '', Permissions: 'Basic', TargetSelector: ''},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 3, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-3.html', ExitURL: '', Permissions: 'Basic', TargetSelector: '[ng-href="#/User/Account"]'},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 4, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-4.html', ExitURL: '', Permissions: 'Basic', TargetSelector: ''},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 5, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-5.html', ExitURL: '', Permissions: 'Basic', TargetSelector: '[translate="common.fst"]'},
                { PrimaryCategory: 'Introduction', SecondaryCategory: 'LoginOrRefresh', Feature: '', TutorialNumber: 0, Step: 6, RouteURL: '/User/Account', TemplateURL: '/Introduction/LoginOrRefresh-6.html', ExitURL: '', Permissions: 'Basic', TargetSelector: '[translate="users.ac.pr.cp"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'CompanyFeed', TutorialNumber: 1, Step: 1, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/Recognize-CompanyFeed-1.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[ translate="common.rec"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'CompanyFeed', TutorialNumber: 1, Step: 2, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/Recognize-CompanyFeed-2.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[ng-click="congrats(feed)"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'CompanyFeed', TutorialNumber: 1, Step: 3, RouteURL: '/Company/Filter/All', TemplateURL: '/Company/Recognize-CompanyFeed-3.html', ExitURL: '/Company/Filter/All', Permissions: 'GiveRecognition', TargetSelector: '.search-container'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 1, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-1.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: ''},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 2, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-2.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[translate="common.recw"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 3, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-3.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[translate="common.chob"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 4, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-4.html', ExitURL: '', Permissions: 'CustomizedRecognition', TargetSelector: '[ng-if="isCustom"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 5, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-5.html', ExitURL: '', Permissions: 'GiveRecognition', TargetSelector: '[translate="common.wri"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 6, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-6.html', ExitURL: '', Permissions: 'HideRecognition', TargetSelector: '[ng-if="!request.MoreOptions.suppressFeed"]'},
                { PrimaryCategory: 'Company', SecondaryCategory: 'Recognize', Feature: 'GiveRecognition', TutorialNumber: 2, Step: 7, RouteURL: '/Recognize/Company/GiveEveryday', TemplateURL: '/Company/Recognize-GiveRecognition-7.html', ExitURL: '/Company/Filter/All', Permissions: 'GiveRecognition', TargetSelector: '.btn-close.btn-close-success.pull-right'}
            ],
            guidMap = {
                uat:    ["2861ae50-9c04-11e4-a4de-a15bf404e311","2861ae51-9c04-11e4-a4de-a15bf404e311","2861ae52-9c04-11e4-a4de-a15bf404e311","2861ae53-9c04-11e4-a4de-a15bf404e311","2861ae54-9c04-11e4-a4de-a15bf404e311","2861ae55-9c04-11e4-a4de-a15bf404e311","2861ae56-9c04-11e4-a4de-a15bf404e311","2861ae57-9c04-11e4-a4de-a15bf404e311","2861ae58-9c04-11e4-a4de-a15bf404e311","2861ae59-9c04-11e4-a4de-a15bf404e311","2861ae5a-9c04-11e4-a4de-a15bf404e311","2861ae5b-9c04-11e4-a4de-a15bf404e311","2861ae5c-9c04-11e4-a4de-a15bf404e311","2861ae5d-9c04-11e4-a4de-a15bf404e311","2861ae5e-9c04-11e4-a4de-a15bf404e311","2861ae5f-9c04-11e4-a4de-a15bf404e311"],
                demo:   ["6c2b5530-9c0b-11e4-ae29-8d81d558fe40","6c2b5531-9c0b-11e4-ae29-8d81d558fe40","6c2b5532-9c0b-11e4-ae29-8d81d558fe40","6c2b5533-9c0b-11e4-ae29-8d81d558fe40","6c2b5534-9c0b-11e4-ae29-8d81d558fe40","6c2b5535-9c0b-11e4-ae29-8d81d558fe40","6c2b5536-9c0b-11e4-ae29-8d81d558fe40","6c2b5537-9c0b-11e4-ae29-8d81d558fe40","6c2b5538-9c0b-11e4-ae29-8d81d558fe40","6c2b5539-9c0b-11e4-ae29-8d81d558fe40","6c2b553a-9c0b-11e4-ae29-8d81d558fe40","6c2b553b-9c0b-11e4-ae29-8d81d558fe40","6c2b553c-9c0b-11e4-ae29-8d81d558fe40","6c2b553d-9c0b-11e4-ae29-8d81d558fe40","6c2b553e-9c0b-11e4-ae29-8d81d558fe40","6c2b553f-9c0b-11e4-ae29-8d81d558fe40"],
                prod:   ["767b4180-9c0b-11e4-808a-d3147cb7b801","767b4181-9c0b-11e4-808a-d3147cb7b801","767b4182-9c0b-11e4-808a-d3147cb7b801","767b4183-9c0b-11e4-808a-d3147cb7b801","767b4184-9c0b-11e4-808a-d3147cb7b801","767b4185-9c0b-11e4-808a-d3147cb7b801","767b4186-9c0b-11e4-808a-d3147cb7b801","767b4187-9c0b-11e4-808a-d3147cb7b801","767b4188-9c0b-11e4-808a-d3147cb7b801","767b4189-9c0b-11e4-808a-d3147cb7b801","767b418a-9c0b-11e4-808a-d3147cb7b801","767b418b-9c0b-11e4-808a-d3147cb7b801","767b418c-9c0b-11e4-808a-d3147cb7b801","767b418d-9c0b-11e4-808a-d3147cb7b801","767b418e-9c0b-11e4-808a-d3147cb7b801","767b418f-9c0b-11e4-808a-d3147cb7b801"],
                st:     ["c57bdd80-9c0b-11e4-acb9-b7fa12cd730a","c57bdd81-9c0b-11e4-acb9-b7fa12cd730a","c57bdd82-9c0b-11e4-acb9-b7fa12cd730a","c57bdd83-9c0b-11e4-acb9-b7fa12cd730a","c57bdd84-9c0b-11e4-acb9-b7fa12cd730a","c57bdd85-9c0b-11e4-acb9-b7fa12cd730a","c57bdd86-9c0b-11e4-acb9-b7fa12cd730a","c57bdd87-9c0b-11e4-acb9-b7fa12cd730a","c57bdd88-9c0b-11e4-acb9-b7fa12cd730a","c57bdd89-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8a-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8b-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8c-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8d-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8e-9c0b-11e4-acb9-b7fa12cd730a","c57bdd8f-9c0b-11e4-acb9-b7fa12cd730a"],
                poc:    ["dc9a98d0-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe0-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe1-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe2-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe3-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe4-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe5-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe6-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe7-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe8-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfe9-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfea-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfeb-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfec-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfed-9c0b-11e4-81cc-c91ee3d78d7e","dc9abfee-9c0b-11e4-81cc-c91ee3d78d7e"],
                tron:   ["30bada10-9c0c-11e4-ac8e-c1ad1385e716","30d93780-9c0c-11e4-ac8e-c1ad1385e716","30d93781-9c0c-11e4-ac8e-c1ad1385e716","30d93782-9c0c-11e4-ac8e-c1ad1385e716","30d93783-9c0c-11e4-ac8e-c1ad1385e716","30d93784-9c0c-11e4-ac8e-c1ad1385e716","30d93785-9c0c-11e4-ac8e-c1ad1385e716","30d93786-9c0c-11e4-ac8e-c1ad1385e716","30d93787-9c0c-11e4-ac8e-c1ad1385e716","30d93788-9c0c-11e4-ac8e-c1ad1385e716","30d93789-9c0c-11e4-ac8e-c1ad1385e716","30d9378a-9c0c-11e4-ac8e-c1ad1385e716","30d9378b-9c0c-11e4-ac8e-c1ad1385e716","30d9378c-9c0c-11e4-ac8e-c1ad1385e716","30d9378d-9c0c-11e4-ac8e-c1ad1385e716","30d9378e-9c0c-11e4-ac8e-c1ad1385e716"],
                borg:   ["38249660-9c0c-11e4-8e70-fb5ae53d6955","38249661-9c0c-11e4-8e70-fb5ae53d6955","38249662-9c0c-11e4-8e70-fb5ae53d6955","38249663-9c0c-11e4-8e70-fb5ae53d6955","38249664-9c0c-11e4-8e70-fb5ae53d6955","38249665-9c0c-11e4-8e70-fb5ae53d6955","38249666-9c0c-11e4-8e70-fb5ae53d6955","38249667-9c0c-11e4-8e70-fb5ae53d6955","38249668-9c0c-11e4-8e70-fb5ae53d6955","38249669-9c0c-11e4-8e70-fb5ae53d6955","3824966a-9c0c-11e4-8e70-fb5ae53d6955","3824966b-9c0c-11e4-8e70-fb5ae53d6955","3824966c-9c0c-11e4-8e70-fb5ae53d6955","3824966d-9c0c-11e4-8e70-fb5ae53d6955","3824966e-9c0c-11e4-8e70-fb5ae53d6955","3824966f-9c0c-11e4-8e70-fb5ae53d6955"],
                cylon:  ["42b55c40-9c0c-11e4-9766-a1d7a8979156","42b55c41-9c0c-11e4-9766-a1d7a8979156","42b55c42-9c0c-11e4-9766-a1d7a8979156","42b55c43-9c0c-11e4-9766-a1d7a8979156","42b55c44-9c0c-11e4-9766-a1d7a8979156","42b55c45-9c0c-11e4-9766-a1d7a8979156","42b55c46-9c0c-11e4-9766-a1d7a8979156","42b55c47-9c0c-11e4-9766-a1d7a8979156","42b55c48-9c0c-11e4-9766-a1d7a8979156","42b55c49-9c0c-11e4-9766-a1d7a8979156","42b55c4a-9c0c-11e4-9766-a1d7a8979156","42b55c4b-9c0c-11e4-9766-a1d7a8979156","42b55c4c-9c0c-11e4-9766-a1d7a8979156","42b55c4d-9c0c-11e4-9766-a1d7a8979156","42b55c4e-9c0c-11e4-9766-a1d7a8979156","42b55c4f-9c0c-11e4-9766-a1d7a8979156"],
                ripley: ["4c60cb30-9c0c-11e4-afab-efb76eb69e55","4c60cb31-9c0c-11e4-afab-efb76eb69e55","4c60cb32-9c0c-11e4-afab-efb76eb69e55","4c60cb33-9c0c-11e4-afab-efb76eb69e55","4c60cb34-9c0c-11e4-afab-efb76eb69e55","4c60cb35-9c0c-11e4-afab-efb76eb69e55","4c60cb36-9c0c-11e4-afab-efb76eb69e55","4c60cb37-9c0c-11e4-afab-efb76eb69e55","4c60cb38-9c0c-11e4-afab-efb76eb69e55","4c60cb39-9c0c-11e4-afab-efb76eb69e55","4c60cb3a-9c0c-11e4-afab-efb76eb69e55","4c60cb3b-9c0c-11e4-afab-efb76eb69e55","4c60cb3c-9c0c-11e4-afab-efb76eb69e55","4c60cb3d-9c0c-11e4-afab-efb76eb69e55","4c60cb3e-9c0c-11e4-afab-efb76eb69e55","4c60cb3f-9c0c-11e4-afab-efb76eb69e55"],
                dev:    ["663111f0-9c0c-11e4-90f9-71eb2b22503e","663111f1-9c0c-11e4-90f9-71eb2b22503e","663111f2-9c0c-11e4-90f9-71eb2b22503e","663111f3-9c0c-11e4-90f9-71eb2b22503e","663111f4-9c0c-11e4-90f9-71eb2b22503e","663111f5-9c0c-11e4-90f9-71eb2b22503e","663111f6-9c0c-11e4-90f9-71eb2b22503e","663111f7-9c0c-11e4-90f9-71eb2b22503e","663111f8-9c0c-11e4-90f9-71eb2b22503e","663111f9-9c0c-11e4-90f9-71eb2b22503e","663111fa-9c0c-11e4-90f9-71eb2b22503e","663111fb-9c0c-11e4-90f9-71eb2b22503e","663111fc-9c0c-11e4-90f9-71eb2b22503e","663111fd-9c0c-11e4-90f9-71eb2b22503e","663111fe-9c0c-11e4-90f9-71eb2b22503e","663111ff-9c0c-11e4-90f9-71eb2b22503e"],
                qa:     ["e3edc960-a1bd-11e4-8ad6-63ef2a43a63a","e3edc961-a1bd-11e4-8ad6-63ef2a43a63a","e3edc962-a1bd-11e4-8ad6-63ef2a43a63a","e3edc963-a1bd-11e4-8ad6-63ef2a43a63a","e3edc964-a1bd-11e4-8ad6-63ef2a43a63a","e3edc965-a1bd-11e4-8ad6-63ef2a43a63a","e3edc966-a1bd-11e4-8ad6-63ef2a43a63a","e3edc967-a1bd-11e4-8ad6-63ef2a43a63a","e3edc968-a1bd-11e4-8ad6-63ef2a43a63a","e3edc969-a1bd-11e4-8ad6-63ef2a43a63a","e3edc96a-a1bd-11e4-8ad6-63ef2a43a63a","e3edc96b-a1bd-11e4-8ad6-63ef2a43a63a","e3edc96c-a1bd-11e4-8ad6-63ef2a43a63a","e3edc96d-a1bd-11e4-8ad6-63ef2a43a63a","e3edc96e-a1bd-11e4-8ad6-63ef2a43a63a","e3edc96f-a1bd-11e4-8ad6-63ef2a43a63a"],
                local:  [
                    '1364e3e0-b44f-4627-a729-8c13ac78ad5e',
                    '4f891c5c-0764-4e5a-9ff1-4d173e531206',
                    '13dc141f-c5c8-4181-91b9-9a4c8a6d4d40',
                    '34b8d4fe-2777-4de6-9125-b9d9de6a6d9a',
                    '775eca24-d9bc-4c70-9995-bb33da6f03fa',
                    'ea0dfc47-0afc-4aec-88b6-1e428d269a7a',
                    '639ea0f1-340c-4beb-ab1d-b3410cca061d',
                    'c224bfce-9e61-4b0f-9968-6401d638e91c',
                    '022c4bc7-93cd-4327-945c-e58544fe7f98',
                    '447cb421-0522-461d-8518-f966f30b7916',
                    'c249438b-0cf8-4363-8db9-3433edc8434f',
                    '73ca27d5-0e6d-413f-b60b-bca86057c0b8',
                    'cc0169a0-4fb2-412c-94ed-35dfd9e8bafa',
                    'ee070dac-5f10-47ba-bbe2-c20a8ad3d48c',
                    'd1d05993-7d61-4c8e-86bb-7f66b022dda2',
                    '434c3003-134f-40c2-b290-839c2ffa984f'
                ]
            },
            tutorialIds = guidMap[process.env.BUILD_ENV],
            i,
            len,
            fullCategoryString,
            tutorialMapping,
            allTutorials = [];
        if (!tutorialIds) {
            tutorialIds = guidMap.local;
        }
        for (i = 0, len = tutorialMappings.length; i < len; i += 1) {
            tutorialMapping = tutorialMappings[i];
            fullCategoryString = tutorialMapping.PrimaryCategory + ':' + tutorialMapping.SecondaryCategory + (tutorialMapping.Feature ? ':' + tutorialMapping.Feature : '');
            allTutorials.push({
                hgId: tutorialIds[i],
                FullCategory: fullCategoryString.replace(/\s+/g, ''),
                PrimaryCategory: tutorialMapping.PrimaryCategory,
                SecondaryCategory: tutorialMapping.SecondaryCategory,
                Feature: tutorialMapping.Feature,
                TutorialNumber: tutorialMapping.TutorialNumber,
                Step: tutorialMapping.Step,
                RouteURL: tutorialMapping.RouteURL,
                TemplateURL: tutorialMapping.TemplateURL,
                ExitURL: tutorialMapping.ExitURL,
                Permissions: tutorialMapping.Permissions,
                TargetSelector: tutorialMapping.TargetSelector
            });
        }
        EntityCache.Tutorial.remove({hgId:{$in:tutorialIds}}, function (error) {
            if (!error) {
                console.log('Removed tutorial records.');
                EntityCache.Tutorial.create(allTutorials, function(error) {
                    if (error) {
                        callback(error);
                    } else {
                        console.log('Tutorials records created.');
                        callback();
                    }
                });
            } else {
                callback(error);
            }
        });
    }

    function reSyncMemberFullName(fcallback) {
        function dataNameChange(member, scallback) {
            Async.parallel({
                mangerName : function (managerCallback) {
                    var update = {
                        $set : {
                            ModifiedDate : new Date().getTime(),
                            MyManagers : [{
                                MemberId : member.hgId,
                                UserId : member.UserId,
                                FullName : member.FullName
                            }]
                        }
                    };
                    EntityCache.Member.update({ GroupId : member.GroupId, 'MyManagers.MemberId' : member.hgId}, update, { multi: true}, managerCallback);
                }
            }, scallback);
        }
        EntityCache.Member.find({MembershipStatus : 'Active'}, function (error, members) {
            if (error) {
                return fcallback(error);
            }
            Async.each(members, dataNameChange, fcallback);
        });
    }

    function addMemberIndex(callback) {
        EntityCache.Member.db.collections.Member.ensureIndex({
            GroupId : 1,
            MembershipStatus : 1,
            RolesInGroup : 1
        }, {name : 'CoreDocIndex' }, callback);
    }

    function addExpireReportsJob(callback) {
        EntityCache.Job.remove({JobName : 'ExpireReports'}, function (error) {
            if (error) {
                return callback(error);
            }
            var job = new EntityCache.Job({
                hgId : '7dd5e5ea-cfc1-41f6-ab1d-a2676fe02f0c',
                JobName : 'ExpireReports',
                MethodName : 'ExpireReports',
                PeriodType : 'Daily',
                Hour : 2,
                LatestTriggerDate : 0
            });
            job.save(function (error) {
                if (error){
                    return callback(error);
                }
                callback();
            });
        });
    }

    function createVRITeams(fcallback) {
        var query = {GroupName : 'VRI'};
        function createTeam(department, callback) {
            EntityCache.Team.findOne({Name : department.Name, Type : 'Pod', Status : 'Active'}, function (error, data) {
                if (error) {
                    callback(error);
                } else if (data) {
                    callback();
                } else { // team does not exist so create
                    var teamId = guid.v1(),
                        team = new EntityCache.Team({
                        ChildTeams: department.ChildTeams,
                        TeamMembers: department.TeamMembers,
                        Type: 'Pod',
                        Status: 'Active',
                        OwnerFullName: department.OwnerFullName,
                        OwnerId: department.OwnerId,
                        IsPublic: true,
                        Description: department.Description,
                        GroupName: department.GroupName,
                        GroupId: department.GroupId,
                        Name: department.Name,
                        hgId : teamId,
                        CreatedBy : department.CreatedBy,
                        ModifiedBy : department.ModifiedBy
                    });
                    team.TeamMembers.forEach(function (item) {
                        item.TeamId = teamId;
                    });
                    if (team.ChildTeams.length > 0) {
                        console.log('WE HAVE CHILD TEAMS');
                    }
                    team.save(function (error) {
                        if (error) {
                            callback(error);
                        } else {
                            callback();
                        }
                    });
                }
            });
            
        }
        EntityCache.Group.findOne(query, function (error, vriGroup) {
            if (error) {
                return fcallback(error);
            } else if (!vriGroup) {
                return fcallback();
            } else {
                EntityCache.Team.find({GroupId : vriGroup.hgId, Type : 'Department', Status : 'Active'}, function (error, departments) {
                    if (error) {
                        return fcallback(error);
                    }
                    Async.each(departments, createTeam, fcallback);
                });
            }
        });
    }
    
    this.Run = function (callback) {
        Async.series([
            addMemberIndex,
            tutorialSetup,
            reSyncMemberFullName,
            addExpireReportsJob,
            createVRITeams
        ], callback);
    }
};
module.exports = new HgMigrationFile();
