var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addRelevancyIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.MemberRelevancy.db.collections.MemberRelevancy.ensureIndex({
                    "MemberId": 1,
                    "GroupId": 1,
                    "Status": 1
                }, {name : 'CoreDocIndex', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.MemberRelevancy.db.collections.MemberRelevancy.ensureIndex({
                    "hgId": 1
                }, {name: 'hgIdIndex', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.MemberRelevancy.db.collections.MemberRelevancy.ensureIndex({
                    "Relevants" : 1
                }, {name : 'RelevantsIndex', background: true }, callback);
            })
        ], fcallback);
    }
    function addInteractionIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.MemberInteraction.db.collections.MemberInteraction.ensureIndex({
                    "GroupId" : 1,
                    "SubjectMemberId" : 1,
                    "ObjectMemberId" : 1
                }, {name : 'CoreDocIndex', background: true }, callback);
            })
        ], fcallback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addRelevancyIndex,
            addInteractionIndex
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();