load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

//Set Default Date value for new Date field added
db.Notification.find().forEach(function(item) {
   db.Notification.update({hgId : item.hgId}, { $set : {Date : new Date(item.CreatedDate)}});
});

switchDB("hgthanka");
var query = {
    Category: 'Achievement'
};
db.RecognitionTemplate.find(query).forEach(function(item) {
    if ((item.RestrictUsers && item.RestrictUsers.MemberIds.length > 0) || (item.RestrictUsers && item.RestrictUsers.TeamIds.length > 0)) {
        db.RecognitionTemplate.update({hgId : item.hgId}, {$set : {AccessLevel : 'WithinTeam'}})
    }
});