load("../../db-scripts/commonDB.js");
setEnv("local");

// add the service fee to the tango visa card
switchDB("hgperka");

var query = {
    "CardName" : "Visa",
},
update = {
	$set : {
		ServiceFee : 2
	}
};
db.TangoCard.update(query, update);

// remove the unused ProfanityFilter property
switchDB("hgcommon");

db.Group.update({},{$unset:{"ExperienceSetting.ProfanityFilter":""}},{multi:true});
