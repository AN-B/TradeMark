// this script is to add a sentiment topic to all sales demo companies
load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgcommon');

var groups = db.Group.find({"Preference.FeatureFlags.FeatureName":"ForSalesDemo"}),
    guids = ["45d804a0-8545-11e4-9be1-95cf3dc0770c","45d804a1-8545-11e4-9be1-95cf3dc0770c","45d804a2-8545-11e4-9be1-95cf3dc0770c","45d804a3-8545-11e4-9be1-95cf3dc0770c","45d804a4-8545-11e4-9be1-95cf3dc0770c","45d804a5-8545-11e4-9be1-95cf3dc0770c","45d804a6-8545-11e4-9be1-95cf3dc0770c","45d804a7-8545-11e4-9be1-95cf3dc0770c","45d804a8-8545-11e4-9be1-95cf3dc0770c","45d804a9-8545-11e4-9be1-95cf3dc0770c","45d804aa-8545-11e4-9be1-95cf3dc0770c","45d804ab-8545-11e4-9be1-95cf3dc0770c","45d804ac-8545-11e4-9be1-95cf3dc0770c","45d804ad-8545-11e4-9be1-95cf3dc0770c","45d804ae-8545-11e4-9be1-95cf3dc0770c","45d804af-8545-11e4-9be1-95cf3dc0770c","45d804b0-8545-11e4-9be1-95cf3dc0770c","45d804b1-8545-11e4-9be1-95cf3dc0770c","45d804b2-8545-11e4-9be1-95cf3dc0770c","45d804b3-8545-11e4-9be1-95cf3dc0770c"],
    index = 0;
if (groups && groups.length) {
    groups.forEach(function (group) {
        var sentimentTopicId,
            recurrenceId,
            sentiment,
            forSalesDemoEnabled = group.Preference.FeatureFlags.filter(function (feature) {
                return feature.FeatureName == "ForSalesDemo" && feature.FeatureEnabled;
            });
        if (forSalesDemoEnabled && forSalesDemoEnabled.length) {
            sentiment = db.SentimentTopic.findOne({GroupId:group.hgId});
            if (!sentiment || !sentiment.GroupId) {
                print(group.GroupName);
                sentimentTopicId = guids[index++];
                recurrenceId = guids[index++];
                db.SentimentTopic.remove({hgId: sentimentTopicId});
                db.SentimentTopic.insert({
                    hgId: sentimentTopicId,
                    QuestionText: 'How do you feel about work today?',
                    AnswerType: 'ScaleRating',
                    AnswerSelectors: [
                        {
                            Value: 0,
                            Text: 'Horrible'
                        },
                        {
                            Value: 1,
                            Text: 'Poor'
                        },
                        {
                            Value: 2,
                            Text: 'Fair'
                        },
                        {
                            Value: 3,
                            Text: 'Good'
                        },
                        {
                            Value: 4,
                            Text: 'Excellent'
                        }
                    ],
                    GroupId: group.hgId,
                    GroupName: group.GroupName,
                    Status: 'Active',
                    DaysToLive: 365,
                    CreatedDate: new Date().getTime(),
                    ModifiedDate: new Date().getTime()
                });
                db.Recurrence.remove({hgId: recurrenceId});
                db.Recurrence.insert({
                    hgId: recurrenceId,
                    EntityType: 'SentimentTopic',
                    EntityId: sentimentTopicId,
                    PeriodType: 'Yearly',
                    NumPeriod: 1,
                    Status: 'Active',
                    FirstTriggerDate: new Date().getTime(),
                    CreatedDate: new Date().getTime(),
                    ModifiedDate: new Date().getTime()
                });
            }
        }
    });
}
