/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');
    function updateGoalAlerts(callback) {
        var nGoalRetreived = 1,
            skip = 0,
            cycleIds,
            cycle;
        Async.whilst(
            function () {
                return nGoalRetreived > 0;
            },
            function (scallback) {
                EntityCache.ManagerAlert.find({
                    Status: {$in: ['Active', 'Processing']},
                    AlertType: {$in: [
                    'GoalCreationOverdue',
                    'GoalPendingCreationApproval',
                    'GoalCloseOverdue',
                    'GoalPendingCloseApproval']},
                    'Data.CycleId': {$exists: true},
                    'Data.CycleName': {$exists: false}})
                    .skip(skip)
                    .limit(1000)
                    .exec(function (error, alerts) {
                        if (error) {
                            return callback(error);
                        }
                        if (!alerts.length) {
                            return callback();
                        }
                        skip += alerts.length;
                        nGoalRetreived = alerts.length;
                        cycleIds = alerts.map(function (alert) {
                            return alert.Data.CycleId;
                        });
                        if (cycleIds.length) {
                            EntityCache.GoalCycle.find({hgId: {$in: cycleIds}}, function (error, cycles) {
                                if (!error) {
                                     Async.each(alerts, function (alert, alertCallback) {
                                        cycle = cycles.filter(function(c) { return c.hgId === alert.Data.CycleId;})[0];
                                        EntityCache.ManagerAlert.update({hgId: alert.hgId},
                                        {
                                            $set: {'Data.CycleName': cycle.Title}
                                        }, alertCallback);
                                    }, scallback);
                                }
                            });
                        } else {
                            scallback();
                        }
                    });
            }, callback);
    };
    function deleteUnusedAlerts (callback) {
        EntityCache.ManagerAlert.update({
            AlertType: {$in: [
            'PerformLastReview',
            'PerformUpcomingReview',
            'GoalUpdateOverdue',
            'CoachingLastReceived',
            'CoachingLastGiven',
            'RecognitionLastReceived',
            'RecognitionLastGiven']}},
            {$set: {Status: 'Deleted'}}).exec();
        callback();
    };
    function addIndexes(callback) {
        Async.series([
            (function (callback) {
                EntityCache.EventBusItemArchive.db.collections.EventBusItemArchive.ensureIndex({
                    'EventType': 1,
                    'EntityId': 1,
                    'EntityType': 1
                }, {name: 'UniquenessIdnex', background: true, check_keys: false, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.GoalCollaborator.db.collections.GoalCollaborator.ensureIndex({
                    'GoalId': 1,
                    'MemberId': 1,
                    'GroupId': 1
                }, {name: 'collaboratorIndex', background: true, check_keys: false, sparse: true}, callback);
            })
        ], callback);
    }

    function addPastSfItem(callback) {
        var itemHgIds = [
            "29bc8ad0-4dcf-11e6-af27-9531b50f35b2","29bc8ad1-4dcf-11e6-af27-9531b50f35b2","29bc8ad2-4dcf-11e6-af27-9531b50f35b2","29bc8ad3-4dcf-11e6-af27-9531b50f35b2","29bc8ad4-4dcf-11e6-af27-9531b50f35b2","29bc8ad5-4dcf-11e6-af27-9531b50f35b2","29bc8ad6-4dcf-11e6-af27-9531b50f35b2","29bc8ad7-4dcf-11e6-af27-9531b50f35b2","29bc8ad8-4dcf-11e6-af27-9531b50f35b2","29bc8ad9-4dcf-11e6-af27-9531b50f35b2","29bc8ada-4dcf-11e6-af27-9531b50f35b2","29bc8adb-4dcf-11e6-af27-9531b50f35b2","29bc8adc-4dcf-11e6-af27-9531b50f35b2","29bc8add-4dcf-11e6-af27-9531b50f35b2","29bc8ade-4dcf-11e6-af27-9531b50f35b2","29bc8adf-4dcf-11e6-af27-9531b50f35b2","29bc8ae0-4dcf-11e6-af27-9531b50f35b2","29bc8ae1-4dcf-11e6-af27-9531b50f35b2","29bc8ae2-4dcf-11e6-af27-9531b50f35b2","29bc8ae3-4dcf-11e6-af27-9531b50f35b2","29bc8ae4-4dcf-11e6-af27-9531b50f35b2","29bc8ae5-4dcf-11e6-af27-9531b50f35b2","29bc8ae6-4dcf-11e6-af27-9531b50f35b2","29bc8ae7-4dcf-11e6-af27-9531b50f35b2","29bc8ae8-4dcf-11e6-af27-9531b50f35b2","29bc8ae9-4dcf-11e6-af27-9531b50f35b2","29bc8aea-4dcf-11e6-af27-9531b50f35b2","29bc8aeb-4dcf-11e6-af27-9531b50f35b2","29bc8aec-4dcf-11e6-af27-9531b50f35b2","29bc8aed-4dcf-11e6-af27-9531b50f35b2","29bc8aee-4dcf-11e6-af27-9531b50f35b2","29bc8aef-4dcf-11e6-af27-9531b50f35b2","29bc8af0-4dcf-11e6-af27-9531b50f35b2","29bc8af1-4dcf-11e6-af27-9531b50f35b2","29bc8af2-4dcf-11e6-af27-9531b50f35b2","29bc8af3-4dcf-11e6-af27-9531b50f35b2","29bc8af4-4dcf-11e6-af27-9531b50f35b2","29bc8af5-4dcf-11e6-af27-9531b50f35b2","29bc8af6-4dcf-11e6-af27-9531b50f35b2","29bc8af7-4dcf-11e6-af27-9531b50f35b2","29bc8af8-4dcf-11e6-af27-9531b50f35b2","29bc8af9-4dcf-11e6-af27-9531b50f35b2","29bc8afa-4dcf-11e6-af27-9531b50f35b2","29bc8afb-4dcf-11e6-af27-9531b50f35b2","29bc8afc-4dcf-11e6-af27-9531b50f35b2","29bc8afd-4dcf-11e6-af27-9531b50f35b2","29bc8afe-4dcf-11e6-af27-9531b50f35b2","29bc8aff-4dcf-11e6-af27-9531b50f35b2","29bc8b00-4dcf-11e6-af27-9531b50f35b2","29bc8b01-4dcf-11e6-af27-9531b50f35b2","29bc8b02-4dcf-11e6-af27-9531b50f35b2","29bc8b03-4dcf-11e6-af27-9531b50f35b2","29bc8b04-4dcf-11e6-af27-9531b50f35b2","29bc8b05-4dcf-11e6-af27-9531b50f35b2","29bc8b06-4dcf-11e6-af27-9531b50f35b2","29bc8b07-4dcf-11e6-af27-9531b50f35b2","29bc8b08-4dcf-11e6-af27-9531b50f35b2","29bc8b09-4dcf-11e6-af27-9531b50f35b2","29bc8b0a-4dcf-11e6-af27-9531b50f35b2","29bc8b0b-4dcf-11e6-af27-9531b50f35b2","29bc8b0c-4dcf-11e6-af27-9531b50f35b2","29bc8b0d-4dcf-11e6-af27-9531b50f35b2","29bc8b0e-4dcf-11e6-af27-9531b50f35b2","29bc8b0f-4dcf-11e6-af27-9531b50f35b2","29bc8b10-4dcf-11e6-af27-9531b50f35b2","29bc8b11-4dcf-11e6-af27-9531b50f35b2","29bc8b12-4dcf-11e6-af27-9531b50f35b2","29bc8b13-4dcf-11e6-af27-9531b50f35b2","29bc8b14-4dcf-11e6-af27-9531b50f35b2","29bc8b15-4dcf-11e6-af27-9531b50f35b2","29bc8b16-4dcf-11e6-af27-9531b50f35b2","29bc8b17-4dcf-11e6-af27-9531b50f35b2","29bc8b18-4dcf-11e6-af27-9531b50f35b2","29bc8b19-4dcf-11e6-af27-9531b50f35b2","29bc8b1a-4dcf-11e6-af27-9531b50f35b2","29bc8b1b-4dcf-11e6-af27-9531b50f35b2","29bc8b1c-4dcf-11e6-af27-9531b50f35b2","29bc8b1d-4dcf-11e6-af27-9531b50f35b2","29bc8b1e-4dcf-11e6-af27-9531b50f35b2","29bc8b1f-4dcf-11e6-af27-9531b50f35b2","29bc8b20-4dcf-11e6-af27-9531b50f35b2","29bc8b21-4dcf-11e6-af27-9531b50f35b2","29bc8b22-4dcf-11e6-af27-9531b50f35b2","29bc8b23-4dcf-11e6-af27-9531b50f35b2","29bc8b24-4dcf-11e6-af27-9531b50f35b2","29bc8b25-4dcf-11e6-af27-9531b50f35b2","29bc8b26-4dcf-11e6-af27-9531b50f35b2","29bc8b27-4dcf-11e6-af27-9531b50f35b2","29bc8b28-4dcf-11e6-af27-9531b50f35b2","29bc8b29-4dcf-11e6-af27-9531b50f35b2","29bc8b2a-4dcf-11e6-af27-9531b50f35b2","29bc8b2b-4dcf-11e6-af27-9531b50f35b2","29bc8b2c-4dcf-11e6-af27-9531b50f35b2","29bc8b2d-4dcf-11e6-af27-9531b50f35b2","29bc8b2e-4dcf-11e6-af27-9531b50f35b2","29bc8b2f-4dcf-11e6-af27-9531b50f35b2","29bc8b30-4dcf-11e6-af27-9531b50f35b2","29bc8b31-4dcf-11e6-af27-9531b50f35b2","29bc8b32-4dcf-11e6-af27-9531b50f35b2","29bc8b33-4dcf-11e6-af27-9531b50f35b2",
            "32722810-4dcf-11e6-bcf2-9fa51cbf13a7","32722811-4dcf-11e6-bcf2-9fa51cbf13a7","32722812-4dcf-11e6-bcf2-9fa51cbf13a7","32722813-4dcf-11e6-bcf2-9fa51cbf13a7","32722814-4dcf-11e6-bcf2-9fa51cbf13a7","32722815-4dcf-11e6-bcf2-9fa51cbf13a7","32722816-4dcf-11e6-bcf2-9fa51cbf13a7","32722817-4dcf-11e6-bcf2-9fa51cbf13a7","32722818-4dcf-11e6-bcf2-9fa51cbf13a7","32722819-4dcf-11e6-bcf2-9fa51cbf13a7","3272281a-4dcf-11e6-bcf2-9fa51cbf13a7","3272281b-4dcf-11e6-bcf2-9fa51cbf13a7","3272281c-4dcf-11e6-bcf2-9fa51cbf13a7","3272281d-4dcf-11e6-bcf2-9fa51cbf13a7","3272281e-4dcf-11e6-bcf2-9fa51cbf13a7","3272281f-4dcf-11e6-bcf2-9fa51cbf13a7","32722820-4dcf-11e6-bcf2-9fa51cbf13a7","32722821-4dcf-11e6-bcf2-9fa51cbf13a7","32722822-4dcf-11e6-bcf2-9fa51cbf13a7","32722823-4dcf-11e6-bcf2-9fa51cbf13a7","32722824-4dcf-11e6-bcf2-9fa51cbf13a7","32722825-4dcf-11e6-bcf2-9fa51cbf13a7","32722826-4dcf-11e6-bcf2-9fa51cbf13a7","32722827-4dcf-11e6-bcf2-9fa51cbf13a7","32722828-4dcf-11e6-bcf2-9fa51cbf13a7","32722829-4dcf-11e6-bcf2-9fa51cbf13a7","3272282a-4dcf-11e6-bcf2-9fa51cbf13a7","3272282b-4dcf-11e6-bcf2-9fa51cbf13a7","3272282c-4dcf-11e6-bcf2-9fa51cbf13a7","3272282d-4dcf-11e6-bcf2-9fa51cbf13a7","3272282e-4dcf-11e6-bcf2-9fa51cbf13a7","3272282f-4dcf-11e6-bcf2-9fa51cbf13a7","32722830-4dcf-11e6-bcf2-9fa51cbf13a7","32722831-4dcf-11e6-bcf2-9fa51cbf13a7","32722832-4dcf-11e6-bcf2-9fa51cbf13a7","32722833-4dcf-11e6-bcf2-9fa51cbf13a7","32722834-4dcf-11e6-bcf2-9fa51cbf13a7","32722835-4dcf-11e6-bcf2-9fa51cbf13a7","32722836-4dcf-11e6-bcf2-9fa51cbf13a7","32722837-4dcf-11e6-bcf2-9fa51cbf13a7","32722838-4dcf-11e6-bcf2-9fa51cbf13a7","32722839-4dcf-11e6-bcf2-9fa51cbf13a7","3272283a-4dcf-11e6-bcf2-9fa51cbf13a7","3272283b-4dcf-11e6-bcf2-9fa51cbf13a7","3272283c-4dcf-11e6-bcf2-9fa51cbf13a7","3272283d-4dcf-11e6-bcf2-9fa51cbf13a7","3272283e-4dcf-11e6-bcf2-9fa51cbf13a7","3272283f-4dcf-11e6-bcf2-9fa51cbf13a7","32722840-4dcf-11e6-bcf2-9fa51cbf13a7","32722841-4dcf-11e6-bcf2-9fa51cbf13a7","32722842-4dcf-11e6-bcf2-9fa51cbf13a7","32722843-4dcf-11e6-bcf2-9fa51cbf13a7","32722844-4dcf-11e6-bcf2-9fa51cbf13a7","32722845-4dcf-11e6-bcf2-9fa51cbf13a7","32722846-4dcf-11e6-bcf2-9fa51cbf13a7","32722847-4dcf-11e6-bcf2-9fa51cbf13a7","32722848-4dcf-11e6-bcf2-9fa51cbf13a7","32722849-4dcf-11e6-bcf2-9fa51cbf13a7","3272284a-4dcf-11e6-bcf2-9fa51cbf13a7","3272284b-4dcf-11e6-bcf2-9fa51cbf13a7","3272284c-4dcf-11e6-bcf2-9fa51cbf13a7","3272284d-4dcf-11e6-bcf2-9fa51cbf13a7","3272284e-4dcf-11e6-bcf2-9fa51cbf13a7","3272284f-4dcf-11e6-bcf2-9fa51cbf13a7","32722850-4dcf-11e6-bcf2-9fa51cbf13a7","32722851-4dcf-11e6-bcf2-9fa51cbf13a7","32724f20-4dcf-11e6-bcf2-9fa51cbf13a7","32724f21-4dcf-11e6-bcf2-9fa51cbf13a7","32724f22-4dcf-11e6-bcf2-9fa51cbf13a7","32724f23-4dcf-11e6-bcf2-9fa51cbf13a7","32724f24-4dcf-11e6-bcf2-9fa51cbf13a7","32724f25-4dcf-11e6-bcf2-9fa51cbf13a7","32724f26-4dcf-11e6-bcf2-9fa51cbf13a7","32724f27-4dcf-11e6-bcf2-9fa51cbf13a7","32724f28-4dcf-11e6-bcf2-9fa51cbf13a7","32724f29-4dcf-11e6-bcf2-9fa51cbf13a7","32724f2a-4dcf-11e6-bcf2-9fa51cbf13a7","32724f2b-4dcf-11e6-bcf2-9fa51cbf13a7","32724f2c-4dcf-11e6-bcf2-9fa51cbf13a7","32724f2d-4dcf-11e6-bcf2-9fa51cbf13a7","32724f2e-4dcf-11e6-bcf2-9fa51cbf13a7","32724f2f-4dcf-11e6-bcf2-9fa51cbf13a7","32724f30-4dcf-11e6-bcf2-9fa51cbf13a7","32724f31-4dcf-11e6-bcf2-9fa51cbf13a7","32724f32-4dcf-11e6-bcf2-9fa51cbf13a7","32724f33-4dcf-11e6-bcf2-9fa51cbf13a7","32724f34-4dcf-11e6-bcf2-9fa51cbf13a7","32724f35-4dcf-11e6-bcf2-9fa51cbf13a7","32724f36-4dcf-11e6-bcf2-9fa51cbf13a7","32724f37-4dcf-11e6-bcf2-9fa51cbf13a7","32724f38-4dcf-11e6-bcf2-9fa51cbf13a7","32724f39-4dcf-11e6-bcf2-9fa51cbf13a7","32724f3a-4dcf-11e6-bcf2-9fa51cbf13a7","32724f3b-4dcf-11e6-bcf2-9fa51cbf13a7","32724f3c-4dcf-11e6-bcf2-9fa51cbf13a7","32724f3d-4dcf-11e6-bcf2-9fa51cbf13a7","32724f3e-4dcf-11e6-bcf2-9fa51cbf13a7","32724f3f-4dcf-11e6-bcf2-9fa51cbf13a7","32724f40-4dcf-11e6-bcf2-9fa51cbf13a7","32724f41-4dcf-11e6-bcf2-9fa51cbf13a7"
        ],
        accountIds = [
            '0014000000pHjMm',
            '0014000000pID0x',
            '0014000000pID3L',
            '0014000000pID6j',
            '0014000000pIDAT',
            '0014000000qTLia',
            '0014000000rsGRn',
            '0014000000sALVB',
            '0014000000sX2nN',
            '0014000000sX3Cw',
            '0014000000sXpvd',
            '0014000000sah83',
            '0014000000t0jKz',
            '0014000000uR2Ly',
            '0014000000v7ATD',
            '0014000000v89Eo',
            '0014000000v8KwV',
            '0014000000voJrP',
            '0014000000voJrP',
            '0014000000vpBuM',
            '0014000000wFfjz',
            '0014000000xXxin',
            '0014000000y26Ry',
            '0014000000ylzgz',
            '0014000000ymrhi',
            '00140000010eYXr',
            '00140000010h6U0',
            '00140000010iHhU',
            '00140000012AaYJ',
            '00140000013iIXj',
            '00140000013iZej',
            '00140000013jANb',
            '00140000013jAPS',
            '00140000013jEoF',
            '00140000013jX08',
            '00140000013jX6H',
            '00140000013jnHU',
            '00140000014Tyv8',
            '00140000016CxcY',
            '00140000016DZz8',
            '00140000018f2eK',
            '00140000018gEVa',
            '0014000001CY1rr',
            '0014000001ERtHB',
            '0014000001HQ7bm',
            '0014000001Kk05d',
            '0014000001Qqp6v',
            '0014000001Vrt3s',
            '0014000001VuMgt',
            '0014000001WNKko',
            '0014000001WNln9',
            '0014000001X3ddK',
            '0014000001XkZCk',
            '0014000001XlA53',
            '0014000001Xnwg2',
            '0014000001YmLrv',
            '0014000001Ymfhn',
            '0014000001YoLuY',
            '0014000001YoRep',
            '0014000001Zr7AC',
            '0014000001ZsF0y',
            '0014000001aq34Y',
            '0014000001avlHe',
            '0014000001bMLfS',
            '0014000001bOjXb',
            '0014000001cW6Nt',
            '0014000001co1vn',
            '0014000001dqZDX',
            '0014000001fEHZD',
            '0014000001fnj4S',
            '0014000001foDCc',
            '0014000001g3zVM',
            '0014000001gh8sJ'
        ],
        opportunityIds = [
            '0064000000fobQJ',
            '0064000000Rf8P9',
            '0064000000fobL4',
            '0064000000fnife',
            '0064000000jFTgq',
            '0064000000grLSU',
            '0064000000SUHoH',
            '0064000000fobLJ',
            '0064000000RhyV7',
            '0064000000fpsMO',
            '0064000000i1OUc',
            '0064000000STPtJ',
            '0064000000STvwi',
            '0064000000i4MxN',
            '0064000000TohHA',
            '0064000000j1uVv',
            '0064000000gHGHE',
            '0064000000aMBZi',
            '0064000000jFKb7',
            '0064000000UHeRe',
            '0064000000UKFhR',
            '0064000000fobMv',
            '0064000000V3UNi',
            '0064000000j1uWU',
            '0064000000Vi3yn',
            '0064000000WNdpX',
            '0064000000ay8ue',
            '0064000000WPpsD',
            '0064000000WQwHJ',
            '0064000000fq5ki',
            '0064000000fARLH',
            '0064000000YWEN9',
            '0064000000Y3ClD',
            '0064000000gw9CK',
            '0064000000f75UI',
            '0064000000Yized',
            '0064000000gJ90Y',
            '0064000000iXs4O',
            '0064000000ZZGpt',
            '0064000000gJp9k',
            '0064000000YUVDE',
            '0064000000eMPAd',
            '0064000000bl3eQ',
            '0064000000ZbS1c',
            '0064000000aJSxn',
            '0064000000bj2Jl',
            '0064000000foIeg',
            '0064000000YWjBE',
            '0064000000avIzW',
            '0064000000i20Gk',
            '0064000000ayf95',
            '0064000000eJCSU',
            '0064000000bnBGh',
            '0064000000gHGyc',
            '0064000000gIShX',
            '0064000000d1fl2',
            '0064000000gHANy',
            '0064000000YXCJ5',
            '0064000000f7B1s',
            '0064000000YXAuO',
            '0064000000eLaUU',
            '0064000000eMLMs',
            '0064000000eL1p2',
            '0064000000i4t0L',
            '0064000000f8vHm',
            '0064000000fqP6f',
            '0064000000gH5vr',
            '0064000000gx35u',
            '0064000000hY2vf',
            '0064000000i2w0E',
            '0064000000i2cqb',
            '0064000000iUbjS',
            '0064000000iX9Ua'
        ],
        items = [],
        i = 0;

        accountIds.forEach(function (accountId) {
            var item = new EntityCache.EventBusItemArchive({
                hgId: itemHgIds[i],
                EventType: 'CsNewClientLaunched',
                Status: 'Processed',
                Payload: {},
                EntityId: accountId,
                EntityType: 'SalesforceAccount'
            });
            items.push(item);
        });

        opportunityIds.forEach(function (accountId) {
            var item = new EntityCache.EventBusItemArchive({
                hgId: itemHgIds[i],
                EventType: 'BDContractSold',
                Status: 'Processed',
                Payload: {},
                EntityId: accountId,
                EntityType: 'SalesforceOpportunity'
            });
            items.push(item);
        });
        console.log(items.length);
        EntityCache.EventBusItemArchive.create(items, function (error, data) {
            console.log(error);
            console.log(data);
            callback();
        });
    }

    function updateSingleUserFirstLogin(record, callback) {
        EntityCache.UserInfo.update({
            hgId: record.hgId
        }, {
            $set: {
                FirstLogin: [{
                    Source: 'Web',
                    LoginTime: record.LastLoginTime
                }]
            }
        }, callback);
    }
    function updateFirstLoginDate(callback) {
        var nMemberRetreived = 1,
            skip = 0;
        Async.whilst(
            function () {
                return nMemberRetreived > 0;
            },
            function (scallback) {
                EntityCache.UserInfo.find({LastLoginTime: {$gt: 0}})
                    .select('hgId LastLoginTime')
                    .skip(skip)
                    .limit(1000)
                    .exec(function (error, userInfos) {
                        if (error) {
                            return scallback(error);
                        }
                        skip += userInfos.length;
                        console.log('processing:', skip);
                        nMemberRetreived = userInfos.length;
                        if (!userInfos.length) {
                            return scallback();
                        }
                        Async.each(userInfos, updateSingleUserFirstLogin, scallback);
                    });
            },
            callback
        );
    }
    function deleteClosureOverdueAlerts(callback) {
        EntityCache.ManagerAlert.find({
            AlertType: 'GoalCreationOverdue',
            Status: {$in: ['Active', 'Processing']}
        }, function (error, alerts) {
            if (error) {
                return callback(error);
            }
            Async.each(alerts, function (alert, alertCallback) {
                EntityCache.ManagerAlert.update({
                    AlertType: 'GoalCloseOverdue',
                    Status: {$in: ['Active', 'Processing']},
                    ReportMemberId: alert.ReportMemberId,
                    ManagerMemberId: alert.ManagerMemberId
                },
                {$set: {Status: 'Deleted'}}, alertCallback);
            }, callback);
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            addIndexes,
            addPastSfItem,
            updateFirstLoginDate,
            updateGoalAlerts,
            deleteUnusedAlerts,
            deleteClosureOverdueAlerts
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
