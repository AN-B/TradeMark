load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

var groupId =  db.Group.findOne({GroupName : 'Mercury Industries'}).hgId;

switchDB("hgsecurity");

// remove old Highground key

db.ClientProfile.remove({ ClientName : "HighGround"});

//set version to 1.0
var update = {
	$set : {
		GroupId : groupId,
		APIKeyVersion : '1.0'
	}
};
db.ClientProfile.update({}, update, {multi: true});
