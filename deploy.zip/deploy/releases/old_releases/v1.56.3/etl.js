load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

print('Add Index');
db.Recognition.ensureIndex({"CreatorMember.hgId" : 1});

print('Rebuild Index');
db.Recognition.reIndex();