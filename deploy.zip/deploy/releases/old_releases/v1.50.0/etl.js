load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

// add the new property ProgramName into the Group collection
db.Group.update({ProgramName:null},{$set:{ProgramName:""}},{multi:true});
// add missing property PublicDispalyName into the Group collection
db.Group.update({PubicDisplayName:null},{$set:{PublicDisplayName:""}},{multi:true});

// update all program names for current companies
db.Group.update({GroupName:"Keno Kozie"},{$set:{ProgramName:"K2 Engage"}});
db.Group.update({GroupName:"Rightpoint"},{$set:{ProgramName:"The Right Stuff"}});
db.Group.update({GroupName:"GiveForward"},{$set:{ProgramName:"Karma Connection"}});
db.Group.update({GroupName:"Spring Venture Group"},{$set:{ProgramName:"Springboard"}});
db.Group.update({GroupName:"Fidelity Communications"},{$set:{ProgramName:"Team Fidelity"}});
db.Group.update({GroupName:"VRI"},{$set:{ProgramName:"Recognize Awesome"}});
db.Group.update({GroupName:"Acquirent"},{$set:{ProgramName:"ACQnowledge"}});
db.Group.update({GroupName:"Critical Signal Technologies"},{$set:{ProgramName:"Pace. Purpose. Performance."}});
db.Group.update({GroupName:"GA Communication"},{$set:{ProgramName:"GA Works"}});
db.Group.update({GroupName:"Struck"},{$set:{ProgramName:"Podium"}});
db.Group.update({GroupName:"Sequent"},{$set:{ProgramName:"RAVE"}});
db.Group.update({GroupName:"Echo Global Logistics"},{$set:{ProgramName:"Engage"}});
