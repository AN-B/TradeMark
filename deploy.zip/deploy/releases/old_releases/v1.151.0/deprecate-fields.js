load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgfinance");

db.CreditAccount.update({}, {
    $unset: {
        IsLocked: ""
    }
}, {multi: true});


db.runCommand({compact: 'CreditAccount', force: true})
