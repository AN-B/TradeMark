/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');
    
    function getMemberEmployeeId(params, callback) {
        EntityCache.Member.find({
            hgId: {$in: Object.keys(params.MemberMap)}
        }, {
            hgId: 1,
            EmployeeId: 1,
            _id: 0
        }, function (error, members) {
            if (error) {
                return scallback(error);
            }
            members.forEach(function (item) {
                if (params.MemberMap[item.hgId]) {
                    params.MemberMap[item.hgId] = item.EmployeeId;
                }
            });
            callback();
        });
    }
    function getFeedbackMemberId(callback) {
        Async.parallel({
            initiator: function (fcallback) {
                EntityCache.FeedbackCycleInitiator.aggregate([
                    {$match:{}},
                    {$group: {
                        _id: 0,
                        mIds: {$addToSet: "$MemberId"}
                    }}
                ], function (error, data) {
                    if (error) {
                        return fcallback();
                    }
                    fcallback(null, data.length ? data[0].mIds : []);
                });
            },
            session: function (fcallback) {
                EntityCache.FeedbackSession.aggregate([
                    {$match:{}},
                    {$unwind: "$Participants"},
                    {$group: {
                        _id: 0,
                        mIds: {$addToSet: "$Participants.MemberId"}
                    }}
                ], function (error, data) {
                    if (error) {
                        return fcallback();
                    }
                    fcallback(null, data.length ? data[0].mIds : []);
                });
            }
        }, function (error, result) {
            var memberIdMap = {};
            if (error) {
                return callback(error);
            }
            result.initiator.forEach(function (item) {
                if (!memberIdMap[item]) {
                    memberIdMap[item] = item;
                }
            });
            result.session.forEach(function (item) {
                if (!memberIdMap[item]) {
                    memberIdMap[item] = item;
                }
            });
            callback(null, memberIdMap);
        });
    }

    function setFeedbackEmployeeId(callback) {
        getFeedbackMemberId(function (error, memberMap) {
            if (error) {
                return callback(error);
            }
            getMemberEmployeeId({MemberMap: memberMap}, function (error) {
                if (error) {
                    return callback(error);
                }
                Async.parallel({
                    initiator: function (fcallback) {
                        Async.each(Object.keys(memberMap), function (memberId, iCallback) {
                            EntityCache.FeedbackCycleInitiator.update({
                                MemberId: memberId
                            }, {
                                $set: {
                                    EmployeeId: memberMap[memberId] || ''
                                }
                            }, {
                                multi: true
                            }, iCallback);
                        }, fcallback);
                    },
                    session: function (fcallback) {
                        var nCount = 1,
                            skip = 0;
                        Async.whilst(
                            function () {
                                return nCount > 0;
                            },
                            function (scallback) {
                                EntityCache.FeedbackSession.find({})
                                    .skip(skip)
                                    .limit(400)
                                    .exec(function (error, sessions) {
                                        if (error) {
                                            return scallback(error);
                                        }
                                        skip += sessions.length;
                                        console.log('processing:', skip);
                                        nCount = sessions.length;
                                        if (!sessions.length) {
                                            return scallback();
                                        }
                                        Async.each(sessions, function (session, sesCallback) {
                                            var reviewer = session.Participants.find(function (p) {
                                                return p.ParticipantType === 'Reviewer';
                                            }),
                                            subject = session.Participants.find(function (p) {
                                                return p.ParticipantType === 'Subject';
                                            });
                                            if (subject) {
                                                subject.EmployeeId = memberMap[subject.MemberId];
                                            }
                                            if (reviewer) {
                                                reviewer.EmployeeId = memberMap[reviewer.MemberId];
                                            }
                                            session.save(sesCallback);
                                        }, scallback);
                                    });
                            },
                            fcallback
                        );
                    }
                }, callback);
            });
        });
    }

    function updateCreditAccount (params, callback) {
        var query = {};
        if (params.Type === 'userId') {
            query.UserId = params.OwnerId;
        } else {
            query.hgId = params.OwnerId;
        }
        EntityCache.Member.findOne(query, {GroupId: 1, MembershipStatus: 1}, function (error, member) {
            if (error || !member) {
                return callback();
            }
            EntityCache.CreditAccount.update({
                OwnerId: params.OwnerId
            }, {
                $addToSet: {
                    GroupId: member.GroupId
                },
                $set: {
                    IsActive: member.MembershipStatus === 'Active'
                }
            }, {
                multi: true
            }, callback);
        });
    }

    function loadCreditAccounts(params, callback) {
        EntityCache.CreditAccount.aggregate([
            {$match: {
                AccountType: {$in: params.accountType},
                OwnerId: {$ne: ''}
            }},
            {$group: {
                _id: 0,
                OwnerIds: {$addToSet:"$OwnerId"}
            }}
        ], function (error, data) {
            if (error || !data.length || !data[0].OwnerIds.length) {
                return callback(error);
            }
            Async.each(data[0].OwnerIds, function (data, cCallback) {
                updateCreditAccount({Type: params.type, OwnerId: data}, cCallback);
            }, callback);
        });
    }

    function updateCreditAccounts (callback) {
        Async.each([{
            type: 'UserId',
            accountType: ['ESPN', 'SPND']
        }, {
            type: 'MemberId',
            accountType: ['PointTransfer', 'PointSpend', 'ETFR', 'ETRF', 'TRFR']
        }], loadCreditAccounts, callback);
    }

    function addIndexes(callback) {
        Async.series([
            (function (callback) {
                EntityCache.CreditAccount.db.collections.CreditAccount.ensureIndex({
                    GroupId: 1
                }, {name: 'CreditAccountGroupIndex', background: true}, callback);
            })
        ], callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            setFeedbackEmployeeId,
            addIndexes,
            updateCreditAccounts
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
