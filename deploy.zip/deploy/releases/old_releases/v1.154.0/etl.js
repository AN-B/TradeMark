var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function convertCountryCodes(callback) {
        EntityCache.TangoCard.update({Country: "CAN"}, {$set: {Country:"CA"}}, {multi: true}, function (err) {
            if (err) {
                return callback(err);
            }
            EntityCache.TangoCard.update({Country: "USA"}, {$set: {Country:"US"}}, {multi: true}, function (err) {
                if (err) {
                    return callback(err);
                }
                callback();
            });
        });
    }

    function addFulfillmentProperty(callback) {
        EntityCache.TangoCard.update({}, {$set: {Fulfillment: 'Auto'}}, {multi: true}, function (err) {
            if (err) {
                return callback(err);
            }
            callback();
        });
    }

    function provisionBrazilCards(callback) {
        var config = require('../../../hgnode/configurations/config.js'),
            cdnCount = config.cdn ? config.cdn.length : 1,
            i = 0,
            protocol = config.s3store.s3bucket ? 'https:' : '',
            // guids were generated from production
            guids = ["8bdaa340-631a-11e6-ad4d-d113b7ffb02c","8bdaa341-631a-11e6-ad4d-d113b7ffb02c","8bdaa342-631a-11e6-ad4d-d113b7ffb02c","8bdaa343-631a-11e6-ad4d-d113b7ffb02c"],
            createdBy = "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
            // replace the testCompany id with one on your local test account, or go through provisioning to activate the new cards manually
            testCompany = [],
            //testCompany = ["3cf21720-9cd2-11e2-a3a4-25024474fe63"],
            newCards = [
                {
                    "CardName": "Americanas.com",
                    "Country": "BR",
                    "CreatedBy": createdBy,
                    "CreatedDate": Date.now(),
                    "Denominations": [
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 3000,
                            "SKU": "ANAS-E-3000-STD",
                            "Description": "Americanas.com E-Gift cartão R$30",
                            "Denomination": 3000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 4000,
                            "SKU": "ANAS-E-4000-STD",
                            "Description": "Americanas.com E-Gift cartão R$40",
                            "Denomination": 4000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 6000,
                            "SKU": "ANAS-E-6000-STD",
                            "Description": "Americanas.com E-Gift cartão R$60",
                            "Denomination": 6000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 8000,
                            "SKU": "ANAS-E-8000-STD",
                            "Description": "Americanas.com E-Gift cartão R$80",
                            "Denomination": 8000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 10000,
                            "SKU": "ANAS-E-10000-STD",
                            "Description": "Americanas.com E-Gift cartão R$100",
                            "Denomination": 10000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 20000,
                            "SKU": "ANAS-E-20000-STD",
                            "Description": "Americanas.com E-Gift cartão R$200",
                            "Denomination": 20000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 40000,
                            "SKU": "ANAS-E-40000-STD",
                            "Description": "Americanas.com E-Gift cartão R$400",
                            "Denomination": 40000
                        }
                    ],
                    "EmailTemplateId": "166949",
                    "Fulfillment": "Manual",
                    "ExcludedGroupIds": [],
                    "GroupIds": testCompany,
                    "ModifiedBy": createdBy,
                    "ModifiedDate": Date.now(),
                    "Type": "giftcard",
                    "hgId": guids[i],
                    "ImageUrl": protocol + config.s3store.imageStore[++i % cdnCount] + "/giftcard/americanas-brl-gift-card.png"
                },
                {
                    "CardName": "Netshoes",
                    "Country": "BR",
                    "CreatedBy": createdBy,
                    "CreatedDate": Date.now(),
                    "Denominations": [
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 2000,
                            "SKU": "NETS-E-2000-STD",
                            "Description": "Netshoes E-Gift cartão R$20",
                            "Denomination": 2000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 3000,
                            "SKU": "NETS-E-3000-STD",
                            "Description": "Netshoes E-Gift cartão R$30",
                            "Denomination": 3000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 4000,
                            "SKU": "NETS-E-4000-STD",
                            "Description": "Netshoes E-Gift cartão R$40",
                            "Denomination": 4000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 6000,
                            "SKU": "NETS-E-6000-STD",
                            "Description": "Netshoes E-Gift cartão R$60",
                            "Denomination": 6000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 8000,
                            "SKU": "NETS-E-8000-STD",
                            "Description": "Netshoes E-Gift cartão R$80",
                            "Denomination": 8000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 10000,
                            "SKU": "NETS-E-10000-STD",
                            "Description": "Netshoes E-Gift cartão R$100",
                            "Denomination": 10000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 20000,
                            "SKU": "NETS-E-20000-STD",
                            "Description": "Netshoes E-Gift cartão R$200",
                            "Denomination": 20000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 40000,
                            "SKU": "NETS-E-40000-STD",
                            "Description": "Netshoes E-Gift cartão R$400",
                            "Denomination": 40000
                        }
                    ],
                    "EmailTemplateId": "166949",
                    "Fulfillment": "Manual",
                    "ExcludedGroupIds": [],
                    "GroupIds": testCompany,
                    "ModifiedBy": createdBy,
                    "ModifiedDate": Date.now(),
                    "Type": "giftcard",
                    "hgId": guids[i],
                    "ImageUrl": protocol + config.s3store.imageStore[++i % cdnCount] + "/giftcard/netshoes-brl-gift-card.png"
                },
                {
                    "CardName": "Submarino.com",
                    "Country": "BR",
                    "CreatedBy": createdBy,
                    "CreatedDate": Date.now(),
                    "Denominations": [
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 3000,
                            "SKU": "SBMO-E-3000-STD",
                            "Description": "Submarino.com E-Gift cartão R$30",
                            "Denomination": 3000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 4000,
                            "SKU": "SBMO-E-4000-STD",
                            "Description": "Submarino.com E-Gift cartão R$40",
                            "Denomination": 4000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 6000,
                            "SKU": "SBMO-E-6000-STD",
                            "Description": "Submarino.com E-Gift cartão R$60",
                            "Denomination": 6000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 8000,
                            "SKU": "SBMO-E-8000-STD",
                            "Description": "Submarino.com E-Gift cartão R$80",
                            "Denomination": 8000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 10000,
                            "SKU": "SBMO-E-10000-STD",
                            "Description": "Submarino.com E-Gift cartão R$100",
                            "Denomination": 10000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 20000,
                            "SKU": "SBMO-E-20000-STD",
                            "Description": "Submarino.com E-Gift cartão R$200",
                            "Denomination": 20000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 40000,
                            "SKU": "SBMO-E-40000-STD",
                            "Description": "Submarino.com E-Gift cartão R$400",
                            "Denomination": 40000
                        }
                    ],
                    "EmailTemplateId": "166949",
                    "Fulfillment": "Manual",
                    "ExcludedGroupIds": [],
                    "GroupIds": testCompany,
                    "ModifiedBy": createdBy,
                    "ModifiedDate": Date.now(),
                    "Type": "giftcard",
                    "hgId": guids[i],
                    "ImageUrl": protocol + config.s3store.imageStore[++i % cdnCount] + "/giftcard/submarino-brl-gift-card.png"
                },
                {
                    "CardName": "Zattini",
                    "Country": "BR",
                    "CreatedBy": createdBy,
                    "CreatedDate": Date.now(),
                    "Denominations": [
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 3000,
                            "SKU": "ZTNI-E-3000-STD",
                            "Description": "Zattini E-Gift cartão R$30",
                            "Denomination": 3000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 4000,
                            "SKU": "ZTNI-E-4000-STD",
                            "Description": "Zattini E-Gift cartão R$40",
                            "Denomination": 4000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 6000,
                            "SKU": "ZTNI-E-6000-STD",
                            "Description": "Zattini E-Gift cartão R$60",
                            "Denomination": 6000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 8000,
                            "SKU": "ZTNI-E-8000-STD",
                            "Description": "Zattini E-Gift cartão R$80",
                            "Denomination": 8000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 10000,
                            "SKU": "ZTNI-E-10000-STD",
                            "Description": "Zattini E-Gift cartão R$100",
                            "Denomination": 10000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 20000,
                            "SKU": "ZTNI-E-20000-STD",
                            "Description": "Zattini E-Gift cartão R$200",
                            "Denomination": 20000
                        },
                        {
                            "CurrencyType": "BRL",
                            "MaxPrice": 0,
                            "MinPrice": 0,
                            "UnitPrice": 40000,
                            "SKU": "ZTNI-E-40000-STD",
                            "Description": "Zattini E-Gift cartão R$400",
                            "Denomination": 40000
                        }
                    ],
                    "EmailTemplateId": "166949",
                    "Fulfillment": "Manual",
                    "ExcludedGroupIds": [],
                    "GroupIds": testCompany,
                    "ModifiedBy": createdBy,
                    "ModifiedDate": Date.now(),
                    "Type": "giftcard",
                    "hgId": guids[i],
                    "ImageUrl": protocol + config.s3store.imageStore[++i % cdnCount] + "/giftcard/zattini-brl-gift-card.png"
                }
            ];
        EntityCache.TangoCard.remove({Country:"BR"}, function (err) {
            if (err) {
                return callback(err);
            }
            EntityCache.TangoCard.create(newCards, function (err) {
                if (err) {
                    return callback(err);
                }
                callback();
            });
        });

    }

    function addProfanityIndex(callback) {
        Async.series([
            (function (callback) {
                EntityCache.Profanity.db.collections.Profanity.ensureIndex({
                    GroupId: 1,
                    Lang: 1,
                    Word: 1,
                    Status: 1,
                    ExcludedGroupIds: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            })
        ], callback);
    }

    function migrateData(fcallback) {
        var pFilter = require('../../../hgnode/util/WordFilter.js'),
            guid = require('node-uuid'),
            obsencePortugueseWords = [
                'aborto',
                'amador',
                'ânus',
                'aranha',
                'ariano',
                'balalao',
                'bastardo',
                'bicha',
                'biscate',
                'bissexual',
                'boceta',
                'boob',
                'bosta',
                'braulio de borracha',
                'bumbum',
                'burro',
                'cabrao',
                'cacete',
                'cagar',
                'camisinha',
                'caralho',
                'cerveja',
                'chochota',
                'chupar',
                'clitoris',
                'cocaína',
                'colhoes',
                'comer',
                'cona',
                'consolo',
                'corno',
                'cu',
                'dar o rabo',
                'dum raio',
                'esporra',
                'fecal',
                'filho da puta',
                'foda',
                'foda-se',
                'foder',
                'frango assado',
                'gozar',
                'grelho',
                'heroína',
                'heterosexual',
                'homem gay',
                'homoerótico',
                'homosexual',
                'inferno',
                'lésbica',
                'lolita',
                'mama',
                'merda',
                'paneleiro',
                'passar um cheque',
                'pau',
                'peidar',
                'pênis',
                'pinto',
                'porra',
                'puta',
                'puta que pariu',
                'puta que te pariu',
                'queca',
                'sacanagem',
                'saco',
                'torneira',
                'transar',
                'vai-te foder',
                'vai tomar no cu',
                'veado',
                'vibrador',
                'xana',
                'xochota'
            ];
        //Portuguese Words from
        //https://github.com/shutterstock/List-of-Dirty-Naughty-Obscene-and-Otherwise-Bad-Words
        EntityCache.Profanity.remove({}, function (error) {
            if (error) {
                return fcallback(error);
            }
            var list = [];
            Object.keys(pFilter.WordList).forEach(function (item) {
                list.push({
                    hgId: guid.v1(),
                    Lang: 'en',
                    Word: item,
                    Level: pFilter.WordList[item],
                    Status: 'Active'
                });
            });
            obsencePortugueseWords.forEach(function (word) {
                list.push({
                    hgId: guid.v1(),
                    Lang: 'pt-br',
                    Word: word,
                    Level: 1,
                    Status: 'Active'
                });
            });
            EntityCache.Profanity.create(list, fcallback);
        });
    }

    function archiveOldNotificationItems(callback) {
        EntityCache.NotificationQueueItem.find({
            LockedForDispatching: true,
            CreatedDate: {
                $lt: Date.now() - 86400000
            }
        })
            .exec(function (error, items) {
                if (error) {
                    return callback(error);
                }
                items.forEach(function (item) {
                    delete item._id;
                    item.Action = 'FailedAndRemove';
                    item.ServerResponse = "Archived by etl.js of 7444";
                });
                EntityCache.NotificationAudit.create(items, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    EntityCache.NotificationQueueItem.remove({
                        hgId: {
                            $in: items.map(function (item) {
                                return item.hgId;
                            })
                        }
                    }, callback);
                });
            });
    }

    this.Run = function (fcallback) {
        Async.series([
            convertCountryCodes,
            addFulfillmentProperty,
            provisionBrazilCards,
            addProfanityIndex,
            migrateData,
            archiveOldNotificationItems
        ], fcallback);
    };


};

module.exports = new HgMigrationFile();