var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');
    Array.prototype.equals = function (array) {
        // if the other array is a falsy value, return
        if (!array)
            return false;

        // compare lengths - can save a lot of time 
        if (this.length != array.length)
            return false;

        for (var i = 0, l=this.length; i < l; i++) {
            // Check if we have nested arrays
            if (this[i] instanceof Array && array[i] instanceof Array) {
                // recurse into the nested arrays
                if (!this[i].equals(array[i]))
                    return false;       
            }           
            else if (this[i] != array[i]) { 
                // Warning - two different object instances will never be equal: {x:20} != {x:20}
                return false;   
            }           
        }       
        return true;
    };
    function addEntityActivityIndex(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.EntityActivity.db.collections.EntityActivity.ensureIndex({
                    BatchId: 1,
                    Entities: 1
                }, {
                    name: 'EntitiesIndex',
                    background: true,
                    sparse: true
                }, callback);
            }),
            (function (callback) {
                EntityCache.EntityActivity.db.collections.EntityActivity.ensureIndex({
                    EntityId: 1
                }, {
                    name: 'EntityIdIndex',
                    background: true,
                    sparse: true
                }, callback);
            })
        ], fcallback);
    }

    function updateRecognition(params, callback) {
        //unpack Gifts
        async.each(params.Gifts, function (gift, giftCallback) {
            //unpack orders in a gift
            EntityCache.ProductOrder.find({ hgId: {$in: gift.OrderIds}}, function (error, order) {
                if (error) {
                    return orderCallback(error);
                }
                var recipientIds = order.map(function (item) {
                    return item.Recipient.MemberId;
                });
                EntityCache.Recognition.findOne({hgId: params.hgId}, function (error, rec) {
                    if (error) {
                        return orderCallback(error);
                    }
                    rec.Gifts.forEach(function (recgift) {
                        if (recgift.OrderIds.equals(gift.OrderIds)) {
                            if (!recgift.RecipientIds.equals(recipientIds)) {
                                recipientIds.forEach(function (memberId) {
                                    if (recgift.RecipientIds.indexOf(memberId) === -1) {
                                        recgift.RecipientIds.push(memberId);
                                    }
                                });
                            } 
                        }
                    });
                    rec.save(giftCallback);
                });
            });
        }, callback);
    }

    function addGiftRecipientsToRecognition(callback) {
        EntityCache.Recognition.find({'Gifts.OrderIds': {$exists: true}}, {hgId: 1, Gifts: 1}, function (error, recognitions) {
            if (error) {
                return callback(error);
            }
            console.log('recognitions length', recognitions.length);
            async.each(recognitions, function (recognition, regCallback) {
                updateRecognition(recognition, regCallback);
            }, callback);
        });
    }

    this.Run = function (callback) {
        async.series([
            addEntityActivityIndex,
            addGiftRecipientsToRecognition
        ], callback);
    };
};

module.exports = new HgMigrationFile();