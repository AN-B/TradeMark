// load('../../db-scripts/commonDB.js');
// setEnv("local");

// switchDB('hgcommon');

// db.Sentiment.update({Status : 'Pending'}, {$set : {RemindSent : false}}, {multi : true});


/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        EntityEnums = require('../../../hgnode/enums/EntityEnums.js'),
        Async = require('async'),
        guid = require('node-uuid'),
        memberManagerMapping = {};
    /*
     *  Migration Script Template
     *  You need a run function with callback parameter
     *  Must call the callback function when done.
     */
    function getMemberManagerMapping(callback) {
        var userMemberMapping = {};
        EntityCache.Member.find({MembershipStatus : 'Active'}, null, function (error, members) {
            if (error) {
                return callback(error);
            }
            EntityCache.UserInfo.find({}, function (error, userinfos) {
                if (error) {
                    return callback(error);
                }
                userinfos.forEach(function (user) {
                    userMemberMapping[user.hgId] = {
                        SuppressBirthday : user.Preference.SuppressBirthday,
                        SuppressAnniversary : user.Preference.SuppressAnniversary,
                        Birthdate : user.UserPersonal.Birthdate
                    };
                });
                members.forEach(function (member) {
                    if (userMemberMapping[member.UserId]) {
                        memberManagerMapping[member.hgId] = {
                            ManagerId : (member.MyManagers && member.MyManagers[0] && member.MyManagers[0].MemberId) ? member.MyManagers[0].MemberId : '',
                            MemberId : member.hgId,
                            GroupId : member.GroupId,
                            FullName : member.FullName,
                            UserId : member.UserId,
                            Startdate : member.StartingDate,
                            Birthdate : userMemberMapping[member.UserId].Birthdate,
                            SuppressBirthday : userMemberMapping[member.UserId].SuppressBirthday,
                            SuppressAnniversary : userMemberMapping[member.UserId].SuppressAnniversary
                        };
                    }
                });
                callback(null, memberManagerMapping);
            });
        });
    }
    function getMetricData(params, callback) {
        var matchQuery = { $match : { c : { $in : params.MetricDataCategory } }},
            groupQuery = { $group : { _id : {m : '$m'}, Date : { $max: "$p"} } };
        EntityCache.MetricsMember.aggregate([matchQuery, groupQuery], callback);
    }
    function saveManagerAlert(data) {
        var query = {
            ManagerMemberId : data.ManagerMemberId,
            ReportMemberId : data.ReportMemberId,
            AlertType : data.AlertType
        };
        EntityCache.ManagerAlert.update(query, { $set : data}, {upsert : true}).exec();
    }
    function migrateData(params, callback) {
        getMetricData(params, function (error, metricData) {
            if (error) {
                return callback(error);
            }
            metricData.forEach(function (item) {
                if (memberManagerMapping[item._id.m] && memberManagerMapping[item._id.m].GroupId) {
                    saveManagerAlert({
                        hgId : guid.v1(),
                        CreatedDate : new Date().getTime(),
                        ModifiedDate : new Date().getTime(),
                        Status : 'Active',
                        GroupId : memberManagerMapping[item._id.m].GroupId,
                        ManagerMemberId : memberManagerMapping[item._id.m] ? memberManagerMapping[item._id.m].ManagerId : '',
                        ReportMemberId : item._id.m,
                        Category : params.AlertCategory,
                        AlertType : params.AlertType,
                        Severity : params.Severity,
                        Data : {
                            LastActivity : item.Date
                        }
                    });
                }
            });
            return callback(null, 'Migration done.');
        });
    }
    function addUpdateManagerAlert(params, callback) {
        EntityCache.ManagerAlert.findOne(params.Query, function (error, managerAlertRecord) {
            if (error) {
                return callback(error);
            }
            if (!managerAlertRecord) {
                managerAlertRecord = new EntityCache.ManagerAlert();
                managerAlertRecord.hgId = guid.v1();
                managerAlertRecord.CreatedDate = new Date().getTime();
            }
            managerAlertRecord.GroupId = params.GroupId;
            managerAlertRecord.Status = params.Status || EntityEnums.ManagerAlertStatus.Active;
            managerAlertRecord.ManagerMemberId = params.ManagerMemberId;
            managerAlertRecord.ReportMemberId = params.ReportMemberId;
            managerAlertRecord.ModifiedDate = new Date().getTime();
            managerAlertRecord.Category = params.Category;
            managerAlertRecord.AlertType = params.AlertType;
            managerAlertRecord.Severity = params.Severity;
            managerAlertRecord.Data = params.Data;
            managerAlertRecord.save(function (error) {
                if (error) {
                    callback(error);
                } else {
                    callback(null, 'saved');
                }
            });
        });
    }
    function getPeopleType(review, type) {
        return review.Peoples.filter(function (people) {
            return people.PeopleType === type;
        });
    }
    //teamtab Migration
    function migrateRecognitionReceived(callback) {
        migrateData({
            AlertCategory : 'Recognition',
            AlertType : 'RecognitionLastReceived',
            Severity : 'Warning',
            MetricDataCategory : ['RecognitionReceived']
        }, callback);
    }
    function migrateRecognitionGiven(callback) {
        migrateData({
            AlertCategory : 'Recognition',
            AlertType : 'RecognitionLastGiven',
            Severity : 'Warning',
            MetricDataCategory : ['RecognitionGiven']
        }, callback);
    }
    function migrateCoachingGiven(callback) {
        migrateData({
            AlertCategory : 'Coaching',
            AlertType : 'CoachingLastGiven',
            Severity : 'Warning',
            MetricDataCategory : ['CoachingPlainNotes', 'CoachingTrackLinkedNotes']
        }, callback);
    }
    function migrateCoachingReceived(callback) {
        migrateData({
            AlertCategory : 'Coaching',
            AlertType : 'CoachingLastReceived',
            Severity : 'Warning',
            MetricDataCategory : ['CoachingReceived']
        }, callback);
    }
    function migratePeformReviewed(callback) {
        migrateData({
            AlertCategory : 'Perform',
            AlertType : 'PerformLastReview',
            Severity : 'Warning',
            MetricDataCategory : ['Reviewed']
        }, callback);
    }
    function migrateProfile(fcallback) {
        var key, memberList = []
        for (key in memberManagerMapping) {
            if (memberManagerMapping.hasOwnProperty(key)) {
                memberList.push(memberManagerMapping[key]);
            }
        }
        function migrateOneProfile(params, scallback) {
             Async.parallel({
                birthday : function (callback) {
                    addUpdateManagerAlert({
                        GroupId : params.GroupId,
                        ReportMemberId : params.MemberId,
                        Query : {
                            GroupId : params.GroupId,
                            ReportMemberId : params.MemberId,
                            AlertType : EntityEnums.ManagerAlertType.ProfileUpcomingBirthday
                        },
                        Status : (!params.SuppressBirthday) ? EntityEnums.ManagerAlertStatus.Active : EntityEnums.ManagerAlertStatus.Deleted,
                        Category : EntityEnums.ManagerAlertCategory.Profile,
                        AlertType : EntityEnums.ManagerAlertType.ProfileUpcomingBirthday,
                        Severity : EntityEnums.ManagerAlertSeverity.Upcoming,
                        Data : {
                            FullName : params.FullName,
                            Birthday : params.Birthdate
                        },
                        ManagerMemberId : params.ManagerId
                    }, callback);
                },
                anniversary : function (callback) {
                    addUpdateManagerAlert({
                        GroupId : params.GroupId,
                        ReportMemberId : params.MemberId,
                        Query : {
                            GroupId : params.GroupId,
                            ReportMemberId : params.MemberId,
                            AlertType : EntityEnums.ManagerAlertType.ProfileUpcomingAnniversary
                        },
                        Status : (!params.SuppressAnniversary) ? EntityEnums.ManagerAlertStatus.Active : EntityEnums.ManagerAlertStatus.Deleted,
                        Category : EntityEnums.ManagerAlertCategory.Profile,
                        AlertType : EntityEnums.ManagerAlertType.ProfileUpcomingAnniversary,
                        Severity : EntityEnums.ManagerAlertSeverity.Upcoming,
                        Data : {
                            FullName : params.FullName,
                            Startdate : params.Startdate
                        },
                        ManagerMemberId : params.ManagerId
                    }, callback);
                }
            }, scallback);
        }
        Async.each(memberList, migrateOneProfile, fcallback);
    }
    function migrateUpcomingReviews(fcallback) {
        function oneReviewScheduled(review, callback) {
            var subject = getPeopleType(review, 'Subject'),
                manager = getPeopleType(review, 'Manager');
            if (subject.length === 0 || manager.length === 0 || !memberManagerMapping[subject[0].MemberId] ||
                    (memberManagerMapping[subject[0].MemberId].ManagerId !== manager[0].MemberId)) {
                return callback();
            }
            var managerAlert = new EntityCache.ManagerAlert({
                hgId : guid.v1(),
                GroupId : review.Card.GroupId,
                CreatedDate : new Date().getTime(),
                ModifiedDate : new Date().getTime(),
                Status : EntityEnums.ManagerAlertStatus.Active,
                ReportMemberId : subject[0].MemberId,
                ManagerMemberId : manager[0].MemberId,
                Category : 'Perform',
                AlertType : EntityEnums.ManagerAlertType.PerformUpcomingReview,
                Severity : EntityEnums.ManagerAlertSeverity.Urgent,
                Data : {
                    CycleName : review.CycleName,
                    CycleId : review.CycleId,
                    DeliveryDate : manager[0].DeliveryDate
                }
            });
            managerAlert.save(function (error) {
                callback(error);
            });
        }
        var query = { 
                StatusByAdminView : { $nin : ['Submitted', 'WaitingForSignOff', 'Overdue', 'Archived', 'Closed']},
               'Peoples' : { $elemMatch : { PeopleType : 'Manager', StatusInCurrentReview : 'PendingDelivery'}}
        };
        EntityCache.PerformanceReview.find(query, function (error, reviews) {
            if (error) {
                return fcallback(error);
            }
            Async.each(reviews, oneReviewScheduled, fcallback);
        });
    }
    function migratePendingReviews(fcallback) {
        function onePendingReview(review, callback) {
            var subject = getPeopleType(review, 'Subject'),
                manager = getPeopleType(review, 'Manager');
            if (subject.length === 0 || manager.length === 0 || !memberManagerMapping[subject[0].MemberId] ||
                    (memberManagerMapping[subject[0].MemberId].ManagerId !== manager[0].MemberId)) {
                return callback();
            }
            var managerAlert = new EntityCache.ManagerAlert({
                hgId : guid.v1(),
                GroupId : review.Card.GroupId,
                CreatedDate : new Date().getTime(),
                ModifiedDate : new Date().getTime(),
                Status : EntityEnums.ManagerAlertStatus.Active,
                ReportMemberId : subject[0].MemberId,
                ManagerMemberId : manager[0].MemberId,
                Category : 'Perform',
                AlertType : EntityEnums.ManagerAlertType.PerformPendingReview,
                Severity : EntityEnums.ManagerAlertSeverity.Urgent,
                Data : {
                    CycleName : review.CycleName,
                    ReviewId : review.hgId
                }
            });
            managerAlert.save(function (error) {
                callback(error);
            });
        }
        var query = { 
                StatusByAdminView : { $nin : ['Submitted', 'WaitingForSignOff', 'Overdue', 'Archived', 'Closed']},
                'Peoples' : { $elemMatch : { PeopleType : 'Manager', StatusInCurrentReview : { $in : ['NotStarted', 'InProgress', 'ReadyToSubmit']}}}
        };
        EntityCache.PerformanceReview.find(query, function (error, reviews) {
            if (error) {
                return fcallback(error);
            }
            Async.each(reviews, onePendingReview, fcallback);
        });
    }
    function setRemindSentForSentiment(callback) {
        EntityCache.Sentiment.update({Status : 'Pending'}, {$set : {RemindSent : false}}, {multi : true}, function (error) {
            callback(error);
        });
    }
    //Indexes
    function addMemberIndex(callback) {
       EntityCache.Member.db.collections.Member.ensureIndex({
            GroupId : 1,
            MembershipStatus : 1,
            'MyManagers.MemberId' : 1
        }, { name : 'MemberManagerIndex'}, callback);
    }
    function addManagerAlertIndex(callback) {
        EntityCache.ManagerAlert.db.collections.ManagerAlert.ensureIndex({
            GroupId : 1,
            ManagerMemberId : 1,
            ReportMemberId : 1,
            Status : 1,
            AlertType : 1
        }, { name : 'AlertCompoundInex'}, callback);
    }

    //Execute Query
    this.Run = function (fcallback) {
        getMemberManagerMapping(function (error, data) {
            if (error) {
                return fcallback(error);
            }
            Async.series([
                addMemberIndex,
                addManagerAlertIndex,
                migrateRecognitionReceived,
                migrateRecognitionGiven,
                migrateCoachingGiven,
                migrateCoachingReceived,
                migratePeformReviewed,
                migrateProfile,
                migrateUpcomingReviews,
                migratePendingReviews,
                setRemindSentForSentiment
            ], fcallback);
        });
    };
};
module.exports = new HgMigrationFile();