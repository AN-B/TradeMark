/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addIndexes(callback) {
        async.series([
            (function (callback) {
                EntityCache.PerformanceCard.db.collections.PerformanceCard.ensureIndex({
                    GroupId: 1,
                    'RestrictUsers.MemberId': 1,
                    Status: 1,
                    Type: 1,
                    Title: 1
                }, {name: 'CoreDocIndex', background: true, check_keys: false, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.dropIndex("MemberBookmarkIndex", function () {
                    callback();
                });
            })
        ], callback);
    }

    this.Run = function (fcallback) {
        async.series([
            addIndexes
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
