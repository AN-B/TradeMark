load("../../db-scripts/commonDB.js");
setEnv("local");

//GW -- closed tracks for offboarded members. THis is only for historical data
//new offboarded members' tracks will be automatically closed by service bus
switchDB("hgcommon");
var offboardedMemberIds = [],
    offboardedMembers = db.Member.aggregate({$match : {MembershipStatus : 'OffBoarded'}}).result;

offboardedMembers.forEach(function (member) {
    offboardedMemberIds.push(member.hgId);
});

//JM -- Script to add additional banner properties to group collection
var Data = [
    {"GroupName":"A Safe Haven","hgId":"8ce32810-932f-11e3-bc4e-132d5a24704f","BrandColor":"#000","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"Acquirent","hgId":"f7c50ed0-8f71-11e3-83de-21f00c0936e3","BrandColor":"#1444af","BrandMotif":"Dark", "BannerUrl": true},
    {"GroupName":"Adage Technologies","hgId":"a951d3d0-1a43-11e3-b544-b5fd63eafa89","BrandColor":"#000","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"Allianz","hgId":"0d8c43c0-78a5-11e3-a321-c13e2a754199","BrandColor":"#005399","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"CC Test","hgId":"5dea7490-ae06-11e3-8449-4742ea3683b2","BrandColor":"#000","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"Critical Signal Technologies","hgId":"fb496c90-c1a3-11e3-bb0d-49bd56e7730e","BrandColor":"#e5e4df","BrandMotif":"Light", "BannerUrl": false},
    {"GroupName":"Edge Communications","hgId":"700f4a20-8ce0-11e3-9af3-990151e7c9d7","BrandColor":"#224b7b","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"Fidelity Communications","hgId":"00198240-dd2f-11e3-93df-ed2289aa62ed","BrandColor":"#ddd","BrandMotif":"Light", "BannerUrl": false},
    {"GroupName":"Fooda","hgId":"7bc84a10-ac49-11e2-816a-81fd71297a71","BrandColor":"#000","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"GA Communication","hgId":"67fe3480-9808-11e3-84fb-257f0d28f9f7","BrandColor":"#16216a","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"GiveForward","hgId":"dee8de90-172c-11e3-8e6a-11fc2f75ffee","BrandColor":"#f1f1e4","BrandMotif":"Light", "BannerUrl": false},
    {"GroupName":"InnerWorkings","hgId":"00474e30-c93c-11e2-aedf-47638bb1c36d","BrandColor":"#bcbcb1","BrandMotif":"Light", "BannerUrl": false},
    {"GroupName":"Keno Kozie","hgId":"93c913a0-bdf2-11e2-9666-cb9e9195cb36","BrandColor":"#000","BrandMotif":"Dark", "BannerUrl": true},
    {"GroupName":"Mercury Industries","hgId":"1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde","BrandColor":"#000","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"Rightpoint","hgId":"2256eb90-7df8-11e3-b640-41ab095dfa98","BrandColor":"#E5E5E0","BrandMotif":"Light", "BannerUrl": false},
    {"GroupName":"Sonoma Partners","hgId":"01bce2e0-aab7-11e3-8d63-6f16b29e32cc","BrandColor":"#0b5176","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"Spring Venture Group","hgId":"51193440-a0c3-11e3-a081-8f99ce572ffe","BrandColor":"#f1eadc","BrandMotif":"Light", "BannerUrl": false},
    {"GroupName":"Struck","hgId":"28c6a300-d0a3-11e3-9876-450840dd7df6","BrandColor":"#ef4135","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"Test Company","hgId":"be4df920-31f0-11e3-a07d-35d3ec1dc984","BrandColor":"#000","BrandMotif":"Dark", "BannerUrl": false},
    {"GroupName":"VRI","hgId":"53442a10-edb0-11e3-8082-df8151173dcb","BrandColor":"#104c8a","BrandMotif":"Dark", "BannerUrl": false}];



function setDefaultBannerProps() {
    db.Group.update(
        {},
        { $set: {
            BannerColor: '#000',
            BannerMotif: 'Dark',
            BannerUrl: ''}
        },
        {multi: true}
    );
}

function setBannerPropsByGroup() {
    var group,
        bannerUrl,
        count = 0,
        skip = 0;
    Data.forEach(function (dataRow) {
        group = db.Group.findOne({hgId: dataRow.hgId});
        if (group) {
            count++;
            if (dataRow.BannerUrl) {
                bannerUrl = dataRow.hgId + '.html';
                print('Updating ' + dataRow.GroupName + ' with banner color ' + dataRow.BrandColor + ', motif ' + dataRow.BrandMotif + ', and Url ' + bannerUrl);
            } else {
                print('Updating ' + dataRow.GroupName + ' with banner color ' + dataRow.BrandColor + ' and motif ' + dataRow.BrandMotif);
                bannerUrl = '';
            }

            db.Group.update(
                {hgId: dataRow.hgId},
                { $set: {
                    BannerColor: dataRow.BrandColor,
                    BannerMotif: dataRow.BrandMotif,
                    BannerUrl: bannerUrl}
                }
            );
        } else {
            skip++;
            print('Unable to find group ' + dataRow.GroupName + ' by hgId. Skipping.');
        }
    });
    print('Groups updated: ' + count + ", Groups skipped: " + skip);
}

print('Banner Property Migration Task: Production');
print('Setting Default Values for all groups...');
setDefaultBannerProps();
print('complete.');
print('Applying Group-specific values...');
setBannerPropsByGroup();
print('Banner property migration task complete.');

switchDB("hgthanka");
db.CareerTrack.update(
    {'AssignedMember.hgId' : {$in : offboardedMemberIds}},
    {$set : {Status : 'Closed', 'CareerTrackTemplate.Goal.Status' : 'Closed', 'CareerTrackTemplate.Goal.ClosedDate' : new Date().getTime()}},
    {multi : true});

//Add Index if needed
//db.Recognition.ensureIndex({'RecipientMember.hgId' : 1});
//db.Recognition.ensureIndex({'CreatorMember.hgId' : 1});

// Add Key manually and rebuild index.
// {
//     "Status" : 1,
//     "RecipientMember.hgId" : 1,
//     "CreatorMember.hgId" : 1,
//     "Template.AccessLevel" : 1,
//     "Template.Type" : 1,
//     "SuppressInFeed" : 1
// };
// db.Recognition.reIndex();
