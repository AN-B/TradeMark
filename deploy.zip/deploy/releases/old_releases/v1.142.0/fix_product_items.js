var productItems = [
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Relax</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Massage Envy Spa gift card. Massage therapy can be a powerful ally in your wellness program.\n\nAt Massage Envy Spa, we work hard to make massage therapy available to everybody. That's why we provide therapeutic massages as late as 10 pm, seven days a week. It's why we offer over 1000 locations nationwide. It's why our massage services range from Swedish Massage and Sports Massage to Prenatal Massage and Geriatric Massage. It's also why our affordable massages and memberships are usually half of most day spa prices. Need more convincing? Get started with your first massage and feel for yourself.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/76068db0-cf03-11e4-9453-3f2657c1c301.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "fe0b8980-da08-11e4-82d4-0fab2c5702be"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Connected!</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Your choice of an Apple iPad, iPhone or other comparable electronics for up to a $700 value.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/41b69ce0-ce80-11e4-86d1-1b685b7543a5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0c6099a0-da25-11e4-acec-7b75a30f07c6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"mar-bot10\">500 credits to purchase a $50 gift card of your choice from the gift cards tab.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/bc09e1a0-d8b2-11e4-929f-4dd63b950082.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "96b98d80-da27-11e4-9e60-659660705e20"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Play at Scene 75</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Gift Certificate for Scene75.  Voted Best In Ohio and An International Award-Winning Entertainment Center!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/374a1150-cf03-11e4-923f-3ffd44e7238a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "72ed6d10-da57-11e4-911a-4f557a43ccab"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cruise the River</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Enjoy a $100 RiverBoat Cruise Gift Card for dinner on the river. What's your perfect riverboat adventure? Maybe it's a romantic evening for two under the stars, or a leisurely Sunday brunch with the family. Perhaps you and your friends are looking to experience something tropical. http://www.bbriverboats.com/</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/a115ced0-cf03-11e4-9761-c5353cbb3d87.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f7c1ab80-db0d-11e4-911a-4f557a43ccab"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get the Green!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$200 Cash, Bills, Bones, Bread, Bucks, Cabbage, Cheddar, Clams, Coin, Cs, Dead Presidents, Dough, Stacks, Scratch, Shekels, Moola...you get the picture.   BTW, you can only choose cash once.  If you have selected it on a different level, your points will be returned.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/af8ffac0-ce7d-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5407cb50-db49-11e4-8b50-d986bf83e10e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cheer the Dragons!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$50 Gift Certificate to the Dayton Dragons for you to pick your game, your seats, your FUN!  Dayton Dragons 2015 single-game tickets will go on sale to the general public on Wednesday, March 18 at 10:00 a.m. Tickets can be purchased at the Dragons Box Office located next to the main entry gates at Fifth Third Field, on-line at daytondragons.com, and at any Ticketmaster outlet.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/90dfda10-ce81-11e4-869e-d757aface84a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d9038d60-db9b-11e4-8b50-d986bf83e10e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make it a Date Night</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$300 gift certificate at Fleming's at The Greene or Jeff Ruby’s Steakhouse. High-end steakhouse chain with aged prime beef & classics such as lobster tails & pork chops.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/fc24bc50-ce7c-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c3e7b8d0-dc5d-11e4-88be-71421482f165"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take Flight!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Two round trip plane tickets (up to $350 value each) for a total value of $700.00.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/a263dea0-ce7f-11e4-86d1-1b685b7543a5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2fa62ce0-dcd2-11e4-9e75-85f2f1ff3ed1"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go to the Races</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Enjoy a $300 gift card for the luxury and excitement at Belterra Park. Enjoy the experience and all of the amenities that Belterra Park has to offer. Please note: Gift cards are not redeemable for cash or gaming purposes. http://www.belterrapark.com/</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/adb480d0-ce79-11e4-b1b5-bf10d414ef74.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1ac5eed0-e283-11e4-aa52-894ef13f460c"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Thinking</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Become a VRI Ambassador for Company events and be part of the “Innovation Nation” and attend quarterly Brainstorming Luncheons to brainstorm ideas for innovating VRI.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/7a5a2410-ce79-11e4-b1b5-bf10d414ef74.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "9234f470-e2a6-11e4-aa52-894ef13f460c"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take in a Show...or 4 with a friend!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">2014-2015 DPAA New Horizon Season Flex Pass Subscription of 2 flex pass 4-packs to Dayton Opera, Ballet and Philharmonic. Flex passes allows the maximum flexibility. We will purchase a pack of vouchers that you can exchange for live tickets within 30 days of the performance date. Select from the best seats available at that time. The bigger the subscription package, the better the savings.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/ba619160-cf05-11e4-b05f-370aa8a168d9.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "26280ca0-e2be-11e4-b74a-8d53c2eeda82"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Eat Fresh & Cook Gourmet</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">$1200 Gift Certificate for Plated, Blue Apron or HelloFresh to receive weekly delivery of fresh ingredients and chef-designed recipes.\n\nEat fresh, try new recipes, enjoy something new. Treat yourself or your family to something different!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>12000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/9c7b9380-d946-11e4-a1d6-03d530fcf53d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "11e4e2e0-e2d2-11e4-8952-03ae6661bc16"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$100 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"mar-bot10\">1000 credits to purchase a $100 gift card of your choice from the gift cards tab.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/db93c3b0-d8b2-11e4-98f4-7f3e7d34ef75.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "eda72510-d8b2-11e4-a9c0-493e264361b8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Shop or Dine at The Greene</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 gift card to the Greene for Dining or Shopping. The Greene offers visitors the ultimate shopping experience. You’re sure to find what you’re looking for among more than 75 top retailers who bring you outstanding brand names and stellar customer service.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/61ac2c50-ce70-11e4-91c2-1d7bcc577382.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ea478530-d9f8-11e4-acec-7b75a30f07c6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Snack Healthy!</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">12-week Subscription for Graze Healthy Snacks delivered once per week to the office for you to have a healthy snack.\n\nWe have a range of over ninety tasty snacks (each with a specific benefit to you), including nuts, seeds, juicy dried fruits, tasty crackers, dips and dippers, and natural treats. \n\nGraze is not suitable for people with allergies. All of our food is packed in the same place, so cross-contamination between any of our ingredients is likely to occur. Our snacks may contain traces of gluten, wheat, eggs, nuts, peanuts, soy and milk.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/85f62010-d948-11e4-8e2e-07c81e850e0f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "37ea8d00-d9f9-11e4-acec-7b75a30f07c6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Volunteer, Help Others, Saves Lives</strong> was recently added to the store!</h4><div class=\"mar-bot10\">1 Paid Day Off to Volunteer at a charity of your choice, and 3-months of free monitoring service to give to someone (current or new client) to help people Be Safe and Live Well.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/46530c90-ce79-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "035fd350-da09-11e4-9e60-659660705e20"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Be the King!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">2 Gold Season Passes to Kings Island. With a Gold Season Pass you'll enjoy unlimited visits all season long, free parking, early ride times on the record breaking Banshee, and much more!!!\n\nThese no longer are available for purchase after May 20. The park stops selling them around May 25.  We need the 5 days to buy them.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/516ae750-ce7a-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "22f415a0-da09-11e4-acec-7b75a30f07c6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fish are Friends!!</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Enjoy 2 Adult and 2 Children (2-12) Annual Passes giving you unlimited admission to the Newport Aquarium for 365 days, access to exclusive passholder events, and great discounts throughout the Aquarium.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/3523b640-cf00-11e4-b7f2-e9b630b85821.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2a40c350-da25-11e4-945e-0f5a19e8d5b1"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dream, Learn, Lead</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Participate in a Strength Finder Skills/Dreams Assessment and Attend a 2 to 4-hour workshop on leadership or skills development.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/020e3480-ce6d-11e4-91c2-1d7bcc577382.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f237e580-dadb-11e4-b193-93dab99d9ab1"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Snack Vegan All Year</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">12 Month Subscription from Vegan Cuts snack box. From chips to cookies and sodas to teas, each month we'll send 7-10 vegan goodies straight to your door.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/c46b8be0-d949-11e4-a1d6-03d530fcf53d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "24a58730-dd1f-11e4-9f10-7d2814bc44fa"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get some Bling!</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Citizen or G Shock Watch or other select jewelry up to $700 total value.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/64f6dac0-ce81-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "cbe0dd70-df8a-11e4-b3dd-935e25e99322"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go See the Reds</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$200 Reds Gift Certificate for you to choose your game, your seats, your day! While poised to make his fourth consecutive Opening Day start when he pitches for the Reds Monday vs. the Pirates, ace Johnny Cueto could be beginning his final season in Cincinnati.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/815fa6b0-ce81-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "90e3e670-df50-11e4-9996-cb017130b556"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go On a Cruise!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$1,000 Carnival Cruise Line Gift Card. Carnival Gift Cards can be used on almost anything: towards the purchase of a Carnival cruise and redeemed onboard toward the Sail & Sign account for gifts, drinks, and fun.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/1446c390-dfa4-11e4-bc1f-e5d8f458bf34.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "557f8000-dfa3-11e4-b3dd-935e25e99322"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$100 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">1000 credits to purchase a $100 gift card of your choice from the gift cards tab.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/db93c3b0-d8b2-11e4-98f4-7f3e7d34ef75.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2d014500-dfda-11e4-849d-1779fe5bb128"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dream, Shadow, Lead</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Strength Finder Skills/Dreams Assessment and four 2-hour sessions Job Shadowing in a different department/job of interest; And attend a 2- to 4-hour workshop on leadership or skills development.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/15446e30-ce71-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e5811070-e06f-11e4-b3ae-c396c2f3fcdb"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get VRI Gear</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 towards the purchase of VRI Gear from the VRI Store.\n\nGo to the VRI store link, write down what you want and send it to Kim in HR.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/7a532950-0021-11e6-bb17-732c7f3c82aa.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f779e4f0-e06f-11e4-8d6f-41c098508411"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take in a Show or two</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$250 Cincinnati Arts Association Gift Certificate valid for the terrific variety of performances at the Aronoff Center and Music Hall, and for CAA Memberships – offering great shows, great seats, and great service at the best prices.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/cce18cb0-cf04-11e4-b7f2-e9b630b85821.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "beb7bb80-deb0-11e4-b464-69e72af093e9"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cheer the Dragons More!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Gift Certificate to the Dayton Dragons for you to pick your game, your seats, your FUN!  Dayton Dragons 2015 single-game tickets will go on sale to the general public on Wednesday, March 18 at 10:00 a.m. Tickets can be purchased at the Dragons Box Office located next to the main entry gates at Fifth Third Field, on-line at daytondragons.com, and at any Ticketmaster outlet.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/a76a1a80-db9b-11e4-bd88-a76b07dbcc0f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8e613d30-e153-11e4-b886-732df47bb822"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Play</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Paintball or Golf experience. If you have a preferred course in the local area, we will acquire a gift certificate so that you can go play.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/ea6a7970-ce66-11e4-93de-bb9bc50dade1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "a09d6560-e1d9-11e4-9474-719cfc396590"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Enjoy!</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">$200 Stub Hub or TicketMaster Gift Certificate for you to choose your event, your dates, your seats, your FUN!!! All kinds of concerts, shows and activities for you to choose from.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/3a3527f0-ce82-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "feefec40-e1ee-11e4-9474-719cfc396590"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Fish...Kind of.....</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Well, go see fish at Newport Aquarium.  This is a Family 4-pack - two adults and two children passes for General Admission.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/6456fe90-cf00-11e4-b05f-370aa8a168d9.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "26106b60-e20d-11e4-839b-9f2c7418972e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Charity, Help Others, Save Lives</strong> was recently added to the store!</h4><div class=\"mar-bot10\">VRI will donate $200 to a charity of their choosing in their name and 3-months of free monitoring service to give to someone (current or new client) to help people Be Safe and Live Well.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/0e939610-ce7b-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4ae6e460-e234-11e4-8952-03ae6661bc16"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help Others, Save Lives, Make a Difference</strong> was recently added to the store!</h4><div class=\"mar-bot10\">3 months of monitoring service to give to someone you choose (current client or someone new) and VRI will donate $100 to a charity of their choosing in your name to help people Be Safe and Live Well.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/846f84b0-cf03-11e4-ad46-db9ed259b01c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "836fe2d0-db97-11e4-9d17-0f01c9bb44a1"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cheer on the Company!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Become a VRI Ambassador for Company events, and Attend a Company Recognition Event with a guest if VRI is selected (i.e. Best Places to Work, Business of the Year, etc.). Helps us become the Best and Come with Us when we are recognized for being Best in Class.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/8cd09030-ce7d-11e4-93de-bb9bc50dade1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "71da7f70-ded6-11e4-9b15-c79882a1fd99"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Act Like Animals - Go to the Zoo</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Gold Family Cincinnati Zoo Membership. For our friends who don't work or live in Franklin, Ohio we will send you to the zoo near you!!! Annual memberships vary per zoo.  We will adjust the points as necessary for the package. (10 points per dollar)\n\nYou get a Standard Family membership benefits for two named adults and children in the same household or grandchildren 18 and under, FREE Parking for one vehicle per day, One FREE guest per visit, Unlimited rides on the Zoo Train and Carousel, and 6 FREE 4-D Theater Tickets.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/6546b730-ce7b-11e4-8007-7d9ceca5b65f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "bb352c30-dc86-11e4-aed2-ad6f796de904"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Snack Vegan</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">6 Month Subscription from Vegan Cuts snack box. From chips to cookies and sodas to teas, each month we'll send 7-10 vegan goodies straight to your door.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/5a7175f0-d94a-11e4-9032-3b79cb2f49bc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "041faeb0-de2c-11e4-8f39-0b9a693c629f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Snack Healthy Longer!</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">26-week weekly Graze Healthy Snacks delivered once per week to the office for you to have a healthy snack.\n\nWe have a range of over ninety tasty snacks (each with a specific benefit to you), including nuts, seeds, juicy dried fruits, tasty crackers, dips and dippers, and natural treats. \n\nGraze is not suitable for people with allergies. All of our food is packed in the same place, so cross-contamination between any of our ingredients is likely to occur. Our snacks may contain traces of gluten, wheat, eggs, nuts, peanuts, soy and milk.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/a9086590-d948-11e4-8e2e-07c81e850e0f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d60b4da0-de5c-11e4-9462-43373d30956d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Learn to Lead</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Become a VRI Ambassador for Company events and join a member of the Leadership Team at a customer meeting or function.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/39804920-ce7d-11e4-91c2-1d7bcc577382.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "71cb8b50-ded6-11e4-9b15-c79882a1fd99"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Your very own emoticon!</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\"></div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/17/3bbedcd0-def7-11e4-932f-df6f3342854d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4f9dfd80-def7-11e4-8c44-550f5232d331"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Portable Laptop Desk</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\"></div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/17/62818020-def7-11e4-bc20-cb7d9b45c0d8.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6d86d9c0-def7-11e4-87d0-35521b7e2b37"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Plush Goat</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\"></div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/17/81acc770-def7-11e4-b259-034936d103ad.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8b2ba820-def7-11e4-87d0-35521b7e2b37"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Be Fit! Live Well!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Annual Membership Gift Certificate for GAC Fitness in Springboro; G.A.C. Fitness is Springboro, Ohio's newest and cleanest fitness facility!!! Our state of the art facility offers Speed/Agility/Strength & Conditioning for athletes of all ages, personal training, group exercise room, small group training, smoothie bar, and locker rooms, complete with towel service. And while Mom and Dad are working out in our general fitness area of brand new, top of the line equipment you can rest assured your child will be safe and having fun in our kids care room.  Offering 30 classes that are free with membership.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/685ee7b0-ceff-11e4-9453-3f2657c1c301.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f134e9f0-def8-11e4-827a-29816f6c119c"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Stay in the Woods and Take a Hike!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">A 3-Day/ 2-Night Cabin Package (Examples Vary): \n- Hocking Hills\n- Indian Lake\n- Put in Bay\n- Pigeon Forge\n- Gatlinburg\n\nUp to a $700 value</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/d0d27760-ce7f-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "84ee35e0-de3e-11e4-8f39-0b9a693c629f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fitbit</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">What's the best way to avoid laziness? Personal trainer? Self-discipline? NOPE--think again, grandpa. It's an electronic wrist thing that tracks your activity. And then some. Welcome to a new world of health-filled competition with your friends and, of course, the greatest opponent of all: yourself.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/3bd7a8f0-2700-11e4-b822-0b65057b3394.jpg\"  /></div>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "594c66a0-2700-11e4-950d-891a1bffe38a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Day Visit to Another Struck Office</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Make a day trip to L.A, SLC, or PDX!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/19/c1acde50-32c7-11e4-aea4-2504378ad44e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "4926baf0-3376-11e4-8aee-17282f081c12"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fooda Pop-up Vouchers</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Fooda Select is great and all, but what if you want to \"select\" your food(a) in the morning? You're a grown adult who can eat lunch whenever you darn well please. So what if it's 10:58am? You're hungry so you're going to head to a Fooda pop-up, and nobody can stop you. Well now you can do it on HighGround's dime with this Fooda pop-up voucher. Heck, combine it with the Fooda select reward if you want; we're not your dad.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/24d43a80-3e7d-11e4-8e88-790b94a4741e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "15563490-3e7e-11e4-aa3a-593551cc35ff"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help your Household!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Kroger Card.  2,625 Stores in 34 States.  The Kroger Co. spans many states with store formats that include grocery and multi-department stores, convenience stores and jewelry stores.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/685b1ef0-ce82-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "de590410-d9f8-11e4-82d4-0fab2c5702be"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Be the Big Kahuna</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">2015 The Beach Big Kahuna Package\n(4) 2015 Season Passes\n(4) Bring-A-Friend Day Admissions\n(1) 2015 Weekday Shoreline Cabana Rental\n\nPlus, enjoy a one-time bonus gift of 2 FREE Zip Line Rides and Discounted Snow Tubing at Beach Mountain during every visit!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/5706e710-ceff-11e4-b7f2-e9b630b85821.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c03ad360-dd8f-11e4-b900-455109b0738e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dream, Develop, Learn, Lead</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Attend a Full-day Leadership or Industry Conference, and Strength Finder Skills/Dreams Assessment, and Join the VRI Mentor Program, and Receive Leadership Skills Development Pack.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/2ca880d0-ce7a-11e4-869e-d757aface84a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "202056b0-ddef-11e4-9cde-793b22b4db18"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Your Very Own Emoticon</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Yep. No big deal.\n\nOk, it's a HUGE DEAL. Whatever you want... emoticon'd. You face? Sure. A picture of a fancy looking cat? Of course. ANOTHER Chompy (just 'cuz)? Yep, we can do that.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>750</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/7399e460-5018-11e4-a54e-af35e5e0cb37.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "42607660-5019-11e4-812e-d954da2e1b1b"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Blair's Skull</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Useful for commemorating hot sauce achievements.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/97f567d0-54af-11e4-9ded-bd0b0be73c9c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "b5f79870-54af-11e4-a043-91e3756914c6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>An hour of lies, half truths, and storytelling with Moose</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Plus a delicious cupcake.  Executive development course for 1-1 coaching & career management, complete with political commentary, delicious pastry, style tips for the portly male, and moral turpitude (okay maybe leave off that last one).</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/506c8a40-5551-11e4-88a4-4f9e73775174.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "e98ecf80-5551-11e4-94ad-41e2453d186a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Race Car Mouse</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">So you have an important deadline approaching and you're running out of time. What are you going to do? You have so much work and so little time! But wait, what if there was a way to get your work done FASTER? We've got something for that ... a 6.5L, 661 HP, performance tuned RACING MOUSE. Guaranteed to move your pointer from 0-60 (pixels) in less than 3 seconds. In addition to the pictured Mousielago (see what I did there?) we have a variety of 'Merican muscle cars to choose from as well.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/8a94f0a0-5a14-11e4-8b9f-998fe8d5f755.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "e94b4ef0-5a14-11e4-8eb5-d5df7ba615fc"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Custom Coaster Designed by George</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Tired of ugly water rings marring your pristine desktop? Of course you are. Well now you can protect your workspace in style! These coasters come with original artwork from our critically-acclaimed in house illustrator, George. That's right, some day this thing will be worth hundreds of millions of dollars in the art world ... so for a couple hundred points you would be a FOOL not to get one. You're not a fool, right?</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/b13dcfa0-5e20-11e4-b319-71b82f5e6f90.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "a6993e30-5e21-11e4-9500-ade8f09e5620"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Your Very Own Emoticon</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Yep. No big deal.\n\nOk, it's a HUGE DEAL. Whatever you want... emoticon'd. Your face? Sure. A picture of a fancy looking cat? Of course. ANOTHER Chompy (just 'cuz)? Yep, we can do that.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/7399e460-5018-11e4-a54e-af35e5e0cb37.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "b853cd80-691f-11e4-891a-2b176ff15723"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Instant Access to RobinHood</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">RobinHood is a highly anticipated $0 commission trading app. It currently has a long waitlist to get access, but not for you!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/e78e84f0-6b45-11e4-907e-3f40870817c6.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "203ed930-6b46-11e4-89cc-57ae6fb8de07"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HG Bottle Breacher</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">\"Kock knock\"\n\n\"Who's there?\" \n\n\"FREEDOM\"\n\nThat's the sound of your bottle being \"breached\" by this .50 cal customized bottle opener. You can thank our very own Scott for this product addition.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/e5e7fcc0-6a88-11e4-b278-23b384cd6141.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "b0db7790-6b56-11e4-bba8-69e903345cd6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dream, Learn, Lead</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Participate in a Strength Finder Skills/Dreams Assessment, and Join the VRI Mentor Program, and Attend a 2 to 4-hour workshop on leadership or skills development.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/020e3480-ce6d-11e4-91c2-1d7bcc577382.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "12d93760-ce6d-11e4-b82a-db5cfb1049fd"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help Others, Save Lives, Make a Difference</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">3 months of monitoring service to give to someone they choose (current client or someone new) and VRI will donate $100 to a charity of their choosing in their name and participate in the VRI Care Corp Luncheon twice per year to discuss opportunities for VRI to participate in helping people Be Safe and Live Well.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/846f84b0-cf03-11e4-ad46-db9ed259b01c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "423b7ef0-ce6d-11e4-b86e-7d230e15199a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Manager of Your Choice Wears a Banana Suit</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Let's be honest, you already know exactly who you would force to into this hilarious banana suit. You might say they're \"ripe\" for it. Perhaps you would say it's an ap-\"pealing\" concept. You may even say \"stop making banana puns.\"</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/0b98ad00-fe2f-11e3-849b-378408f25c4f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "4592eb80-7411-11e4-9094-499672282fbc"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>1 month free David Barton Gym membership</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Use David Barton gym free for 1 month before we move out of the building!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/406e2be0-7ff3-11e4-9a64-1954da01ce9c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "9fa6bd10-7ff4-11e4-a02f-7596b216dcac"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>1 Month Free David Barton Gym Membership</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Look better naked</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/132ec0f0-823b-11e4-93f7-939b4e5945da.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "6d1794d0-823f-11e4-93f7-939b4e5945da"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Create Your Own Emoticon</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Yep. No big deal.\n\nOk, it's a HUGE DEAL. Whatever you want... emoticon'd. Your face? Sure. A picture of a fancy looking cat? Of course. ANOTHER Chompy (just 'cuz)? Yep, we can do that.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/41a64a40-e3aa-11e4-b995-67e0d22c24a1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "370266f0-a011-11e4-abeb-31c844478305"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Culture Building Activity</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Get out and hang out with your co-workers! do something fun bowling, mini golf, pedicures anyone?\nEmployees can add points to the pot to make this happen. Company will Match up to $100 for the activity!\n4+ employees to contribute\n1,000 points total! \nAny questions ask Tami!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/19/6baf5190-32c7-11e4-9e1c-bf524d292362.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "03770840-a89a-11e4-988d-a1409c1440ad"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>An Hour of Lies, Half Truths, and Storytelling with Moose</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Plus a delicious cupcake.  Executive development course for 1-1 coaching & career management, complete with political commentary, delicious pastry, style tips for the portly male, and moral turpitude (okay maybe leave off that last one).</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/506c8a40-5551-11e4-88a4-4f9e73775174.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ab04ae80-a8e7-11e4-8c93-370f6af5ea1e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>60 minute massage from Allyu</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">60 minute massage to Allyu spa...located in the 600 W building.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/6750a570-80b2-11e4-9231-f711e21f24f5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "caa4adb0-cce3-11e4-93d7-752cd0d8d63b"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Sip with Vip</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Get your Vipon. A 15 minute one-on-one from our fearless leader.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/9d41d820-b393-11e4-90f2-b9f758f08a27.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2769ed70-b395-11e4-9134-81882a9c9696"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Portable Laptop Desk</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">The workspace is more mobile, social, and connected. Well, mostly mobile with this nifty gadget. Get comfortable in that bean bag chair...get cozy on that brown couch...wherever you go, make sure you're all ergonomical and stuff.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/37fda3e0-b6db-11e4-86f2-f553a4d6f543.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5b9ce720-b6db-11e4-937b-fbc219818588"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Out of Timesheet Jail Free Card</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Hey why not take one offense off your record to keep you eligible for the company incentive.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/19/2b5db640-32c7-11e4-9559-e9b2bc08c822.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "42fd46d0-3376-11e4-bd25-fddc43234b3f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Day and Night Visit to Another Struck Office</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Take a night to think about Struck's other locations and stay the night!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/19/e292f500-32c7-11e4-be16-a7841723f18f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "4914b990-3376-11e4-8aee-17282f081c12"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Culture Building Activity</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Get out and hang out with your co-workers! do something fun bowling, mini golf, pedicures anyone?</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/19/6baf5190-32c7-11e4-9e1c-bf524d292362.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "49157ce0-3376-11e4-8aee-17282f081c12"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch/Dinner on Struck</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Lunch/ Dinner up to $15.00! \nSubmit receipt through workamajig.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>150</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/19/09545fd0-32c8-11e4-9559-e9b2bc08c822.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "4927cc60-3376-11e4-8aee-17282f081c12"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Breakfast and Coffee on Struck</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Submit a receipt in workamajig and get reimbursed up to $10.00 for one breakfast!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/19/d7f4de20-32c6-11e4-9559-e9b2bc08c822.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "4efb5850-3376-11e4-bd25-fddc43234b3f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Continuing Education Class</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Treehouse/Udemy/SkillShare you name it! \nGet reimbursed up to $25.00 \nSubmit through workamajig</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/19/b458a820-32c6-11e4-bb0f-5da8b1da6631.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "4efc1ba0-3376-11e4-bd25-fddc43234b3f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Men's Bathroom Key (one month)</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">What's the #1 problem with the bathroom? I know, the wifi isn't strong enough. Can't help 'ya there. But we can help you with the #2 problem which, incidentally, IS #2. The lines crazy long. So that's why we're offering a golden key to the prestigious alternative bathroom. Redeem this reward and that bad boy is yours for a full month.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"is-relativeParent product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/bb2ef210-3f7f-11e4-a410-f9a0e963ae7f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "e662a3c0-3f82-11e4-af07-7fa0f389637a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Turn Your Emoticon Into Stickers</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">So now you have your own custom emoticon! Congratulations, you've officially made it in this crazy game we call life. Beware, though, it's lonely at the top. You may be asking yourself, what's left to achieve? Is this it?\n\nLuckily, no. It's not. The key to ultimate professional/physical/spiritual fulfillment is turning that emoticon into stickers and plastering them all over errrrrrythang!!! Mind blown? Thought so. I'll give you a minute.\n\nStill there? Great. So for a cool 1K points a booklet  containing 90 stickable versions of your emoticon goodness will be delivered to your desk. Don't over think this. The \"buy\" button is right there.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/333e6910-562e-11e4-9cfd-3b328ad90c63.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "926bd6b0-562f-11e4-ab9e-6168f2b13710"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Socks-as-a-Service</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Our in-house sock stylist, Corey Rutledge, understands the demands of foot attire in a dynamic start-up culture. He has gone through extensive training and has the hands-on experience to know which patterns, colors, and comedic references, will look best on you. Choose this SaaS solution to make your stocking dreams come true (and all but ensure a victory at the weekly sock competition).</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>700</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/acb543b0-86c4-11e4-b898-bfbb5b21f37e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<strong>A new reward is available in the store!</strong>"
},
    "hgId" : "cf952e90-86c4-11e4-a2bf-5162024e1c00"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Plush Goat</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">We scoured the internet to offer the cutest stuffed goat mankind has been able to produce. Be warned: this cuddly version of Gus is in limited supply.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/0db2e930-fe29-11e3-8462-1fef1dc3f7dc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "630a0ea0-b395-11e4-932b-1f2d338ad139"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Your Very Own Emoticon</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Yep. No big deal.\n\nOk, it's a HUGE DEAL. Whatever you want... emoticon'd. Your face? Sure. A picture of a fancy looking cat? Of course. ANOTHER Chompy (just 'cuz)? Yep, we can do that.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/7399e460-5018-11e4-a54e-af35e5e0cb37.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "9eb3f3d0-b395-11e4-932b-1f2d338ad139"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Totes MaGoats Tee Shirt</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Do you like Gus? Are you a fan of HighGround? Do you frequently champion the 'Witty' Tee?\n\nIf you answered \"totes\" to any of the above questions, then look no further. It's time to bring the World to its knees and rock your very own Totes Ma Goats tee!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/af110b30-c413-11e4-9099-cbb81739f8f5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f5922330-c415-11e4-932d-3de72f4dec63"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Plush Goat</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">We scoured the internet to offer the cutest stuffed goat mankind has been able to produce. Be warned: this cuddly version of Gus is in limited supply.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/0db2e930-fe29-11e3-8462-1fef1dc3f7dc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "260f3970-c75f-11e4-86d7-13abc077e948"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Goat Tote</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Have a lot of stuff to carry? Tote your groceries, gym shoes or hot sauce collection in this stylish goat tote. See Libby to claim yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/c8f29da0-c811-11e4-b241-b90269b1ac83.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6cea9670-c811-11e4-98e6-f56b80a9dd5b"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fitbit Flex</strong> was recently added to the store!</h4><div class=\"mar-bot10\">What's the best way to avoid laziness? Personal trainer? Self-discipline? NOPE--think again, Grandpa. It's an electronic wrist thing that tracks your activity. And then some. Welcome to a new world of health-filled competition with your friends and, of course, the greatest opponent of all: yourself.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e1cdbda0-e3aa-11e4-80bc-6d91a5578a59.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4e60eeb0-cce5-11e4-98da-7b5009dec32e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Role Model - His & Hers</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">His & Hers Citizen or G Shock Watch or other select jewelry up to $700 value.\n\nEmployees earning Role Model Rewards will be invited to attend an Achievement Dinner with a guest to celebrate their achievement. This attendance will allow the members of this group to see who their fellow Role Models are and to be recognized as one. Additionally, each employee may select a package of Achiever & Rising Star rewards that appeals most to them and make a selection from the list below (valued at approximately $1100 total for all packages selected).\n\nYou can only choose cash once.  If you have selected it on a different level, your points will be returned.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/0c9c9920-ce5c-11e4-91c2-1d7bcc577382.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ce6ad090-ce5b-11e4-9b3c-d90c23755251"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Food!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$50 Kroger Card.  2,625 Stores in 34 States.  The Kroger Co. spans many states with store formats that include grocery and multi-department stores, convenience stores and jewelry stores.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/e4397320-e20d-11e4-9c30-b913bf89da40.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "15a6f950-e2e5-11e4-8952-03ae6661bc16"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Carried Away!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">This gorgeous, relaxing sunrise or sunset hot air balloon flight in the beautiful Cincinnati/Dayton corridor lasts approximately 45-60 minutes. Please allow up to 3 hours for the complete experience with our crew including: a personalized pre-flight orientation, inflation, flight, landing, and post-flight celebration!!  You may be onboard with other passengers who have also made Non-Exclusive Flight reservations. Flights include complimentary Bella glass champagne flutes, local champagne from Valley Vineyards of Morrow, OH, or sparkling wine toast. Upgradable.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/0fabf1a0-ce80-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "49c9d770-dd59-11e4-99cd-5937780bbfa9"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take a Leap of Faith!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Last year thousands of people of all ages and professions ventured forth into the world of sport parachuting. Many have since embraced it as their favorite sport. Some will go on to become professional competitors and instructors. Others simply found it is a terrific way to spend a weekend.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/08a97060-e36d-11e4-80bc-6d91a5578a59.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c6fef6a0-e37e-11e4-8224-6798fef668de"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Be Fit. Live Well. Exercise.</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Participate in two \"made for VRI\" Fitness Classed designed to help you Be Fit and Live Well.  Sessions yet to be determined. You will have your choice of designed classes. 4-6 will be offered over the year.  Classes will be held at GAC and will have limited availability for First Come, First Serve.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/6ac69590-d7d6-11e4-aeb1-53c68641e2d5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c83117c0-e3af-11e4-9a97-5f811d9d5d83"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go FAST with a Friend!!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">3 Lap Ride Along for 2 People - Experience real life racing thrills by riding as a passenger with a professional driver in a meticulously prepared 600 horse power Sprint Cup style NASCAR stock car.\n\nFull size, Sprint Cup stock cars that have been raced by the likes of Jimmie Johnson, Jeff Gordon, Carl Edwards and Dale JR. Race with a professional instructor and top speeds of 160 MPH!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/2a1c99f0-e36f-11e4-bde5-75a03228c253.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "a809d1e0-e42b-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Work Offsite with the CEO</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Spend the day with Vip at a local coffee shop.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>20000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/fd4aa620-e3ae-11e4-87ca-8bac8ae77b8a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f7d1dfc0-e42f-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Executive Mentorship with Moose</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Spend one-on-one time with Moose every other week for 2 months (total of 4 sessions).</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/11898f80-e3ae-11e4-b456-79e6926989d5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f7d31840-e42f-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Executive Mentorship with Chris</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Spend one-on-one time with Chris every other week for 2 months (total of 4 sessions).</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e38ec730-e3ad-11e4-99f4-f7a357c22de4.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "fdc06dc0-e42f-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Executive Mentorship with Vip</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Spend one-on-one time with Vip every other week for 2 months (total of 4 sessions).</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/bb91cf20-e3ad-11e4-99f4-f7a357c22de4.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "fdc1cd50-e42f-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Continuing Education or Certification</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Select the continuing education course or certification that will get you to that next level. Up to a $500 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e0bbc680-e3ac-11e4-9fe1-176c0f89b5cf.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "03cfa320-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make a Manager Bring You Coffee for a Week</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">No description needed.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/05721ae0-e3b4-11e4-b789-97588426b8aa.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "03d03f60-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Commuter Benefits for a Month</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Whether you put it towards the Metra, CTA, gas, or parking, we'll cover up to $200 towards commuter benefits.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>20000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/0e2e6bb0-e3b0-11e4-9b90-177842d0af43.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "09bd6dd0-e430-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>All Expenses Paid to Attend a Conference</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Have an event in mind that you would love to attend? Dreamforce? SHRM Conference? Bersin? Here's your chance!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/6d3753a0-e3ac-11e4-b456-79e6926989d5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "09be3120-e430-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Wings with Cu</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Grab lunch with Cu at the best wing spot in town.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/2d685c30-e3b4-11e4-87ca-8bac8ae77b8a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "09bfded0-e430-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Full Day for Service Project</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Take the day to give back the community. Remember to submit a picture and a quick story of your good deeds!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/4ba92b30-e3ae-11e4-9fe1-176c0f89b5cf.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0fad3450-e430-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Ravinia Tickets</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Enjoy 2 tickets to a show at Ravinia! Up to a $200 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>20000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/35fde090-e3af-11e4-9b90-177842d0af43.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0fac49f0-e430-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Half Day of Shopping on Michigan Ave.</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Hit up the Mag Mile with a $250 gift card courtesy of HighGround. Totes amaze! \n\nRemember to submit a story and picture afterwards!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/bcda5f40-e3ae-11e4-99f4-f7a357c22de4.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0faf0910-e430-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Half Day of Awesomeness</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Take the afternoon to go be awesome. The catch? You have to wear HighGround gear and submit a picture of what you did.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>15000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/b82b9250-e3b0-11e4-87ca-8bac8ae77b8a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "159be960-e430-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2 Cubs or Sox Tickets</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Baseball season is upon us! Attend a Cubs or Sox game of your choice with a friend or family member. Up to a $75 value.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e37d0c90-e3b0-11e4-b456-79e6926989d5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "15ab2ba0-e430-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Half Day for Service Project</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Take a half day to give back the community. Remember to submit a picture and a quick story of your good deeds!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>12500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/6f0c2160-e3b1-11e4-9b90-177842d0af43.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1ba886b0-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Shadow a Fellow HighGrounder</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Ever wonder how to sell or what it takes to deploy a release? Now you can shadow a fellow HighGrounder for a half day!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/44766090-e3b2-11e4-9b90-177842d0af43.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1ba7c360-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Spa Certificate</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Sit back, relax and pamper yourself with a spa service up to a $50 value of your choice at your favorite salon. See Libby to schedule and purchase your services</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e6d060d0-e3b1-11e4-8b37-95bd8380dfc5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1ba8fbe0-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Shake Shack for 2</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Head to Shake Shack with a plus one via uber. It's all on us. You'll just be required to submit a picture of the two of you at lunch!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/7b766cc0-e3b2-11e4-9fe1-176c0f89b5cf.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "21973bc0-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Big Star for 2</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Head to Big Star with a plus one via uber. It's all on us. You'll just be required to submit a picture of the two of you at lunch!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/bb144870-e3b2-11e4-9fe1-176c0f89b5cf.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "21a67e00-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Monthly Gym Membership Dues</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Get swole on a discount when we cover your monthly membership dues. Up to a $75 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/9f946070-e3b3-11e4-8b37-95bd8380dfc5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "279de5a0-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Eataly for 2</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Head to Eataly with a plus one via uber. It's all on us. You'll just be required to submit a picture of the two of you at lunch!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e9d59510-e3b2-11e4-99f4-f7a357c22de4.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "279ed000-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Mani / Pedi</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Enjoy a little pampering with a manicure and pedicure. Wedge season!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/38d21260-e3b3-11e4-9b90-177842d0af43.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "279f9350-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch on HighGround</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Enjoy lunch from anywhere you'd like. Up to a $20 value.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/ca8a7ed0-e3b4-11e4-9b90-177842d0af43.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2d8e9680-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Enrollment to Chase Corporate Challenge</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Cover the enrollment cost for this year's Chase Corporate Challenge! Up to a $50 value.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/eef6eac0-e430-11e4-b789-97588426b8aa.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2d9f1140-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Spotify Membership for 3 Months</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Upgrade to no commercials for 3 months!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/9d45c010-e3b4-11e4-8b37-95bd8380dfc5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2da24590-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HighGround T-Shirt</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Your very own HighGround t-shirt!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/fcbcfd60-e3b4-11e4-9fe1-176c0f89b5cf.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "395c7040-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Create Your Own Coozie</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Your very own coozie for beer o'clock!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/5eefd840-e3b5-11e4-8b37-95bd8380dfc5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4b81d300-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Choose the Next Food Vendor</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Tired of not knowing (or not liking) the food vendor at our company events? You can choose the next one!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/3ccb4e20-e3b5-11e4-b789-97588426b8aa.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4b8618c0-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$5 to Walgreens</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">A fan favorite, you'll ACTUALLY get $5 to Walgreens. But, you have to share with fellow HighGrounders what you bought!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/8f78ec90-e3b5-11e4-87ca-8bac8ae77b8a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "514e8120-e430-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Create Your Own Emoticon</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Yep. No big deal.\n\nOk, it's a HUGE DEAL. Whatever you want... emoticon'd. Your face? Sure. A picture of a fancy looking cat? Of course. ANOTHER Chompy (just 'cuz)? Yep, we can do that.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/41a64a40-e3aa-11e4-b995-67e0d22c24a1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6356e600-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make it a Carnival!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$500 Carnival Cruise Line Gift Card. Carnival Gift Cards can be used on almost anything: towards the purchase of a Carnival cruise and redeemed onboard toward the Sail & Sign account for gifts, drinks, and fun.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/71bde090-dfa3-11e4-8644-8ff1146f9260.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7667b1d0-e43e-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Play Together!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">2000 credits to purchase $200 of Family Entertainment Gift Cards of your choice from our Gift Cards tab. Choose from dinner out, places to go shop or play, or to go see a movie!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/160bbc30-ce79-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6e5720a0-e45e-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get More Gear!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$200 to spend in the VRI Store!!!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/5e9d9810-cf05-11e4-bfc6-eda0a18b0b3d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1694bf20-e46e-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Away!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Enjoy a Stay at a Marriott or Great Wolf Lodge for a value of up to $700.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/6a947480-ce7f-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "17e24230-e478-11e4-889f-8b4c5c3d5b7f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Snack Healthy All Year</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">52 Weekly Deliveries of Graze Snack Boxes delivered to VRI for your convenience.\n\nWe have a range of over ninety tasty snacks (each with a specific benefit to you), including nuts, seeds, juicy dried fruits, tasty crackers, dips and dippers, and natural treats. \n\nGraze is not suitable for people with allergies. All of our food is packed in the same place, so cross-contamination between any of our ingredients is likely to occur. Our snacks may contain traces of gluten, wheat, eggs, nuts, peanuts, soy and milk.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/21/fa81a2b0-d948-11e4-9032-3b79cb2f49bc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0946c770-e070-11e4-b3ae-c396c2f3fcdb"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Play Hooky!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">3 EXTRA Days of PTO. A high school wise guy was determined to have a day off from school, despite what the principal thought of that. Well, this isn't High School - but our principal is OK with you earning 3 extras days of PTO!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/efbac240-ce7f-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "63c7ecd0-e36b-11e4-9a97-5f811d9d5d83"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take Flight!!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Discover the thrill of flying when you Learn to Fly a Cessna 172 near Cincinnati!\n\nBegin with a meet and greet with your instructor followed by a pre-flight inspection of the aircraft. Learn the basic controls and how to properly maneuver the plane prior to flight.\n\nTogether you'll taxi to the runway and prepare for take-off. Once airborne, you'll do most of the flying during the approximately 45-minute flight.\n\nTake in spectacular views of the Cincinnatti skyline and surrounding countryside when you fly with an experienced FAA Certified Instructor on this Learn to Fly experience.\n\nClermont County Airport - Batavia, OH \nYear-Round: Monday through Saturday - 8:00 AM to 6:00 PM; Sundays - 11:00 AM to 6:00 PM</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/0f4bac40-e394-11e4-b995-67e0d22c24a1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c67b1ea0-e394-11e4-a9f0-f9928f517e20"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go for the Green!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$500 Cash, Bills, Bones, Bread, Bucks, Cabbage, Cheddar, Clams, Coin, Cs, Dead Presidents, Dough, Stacks, Scratch, Shekels, Moola...you get the picture.   BTW, you can only choose cash once.  If you have selected it on a different level, your points will be returned.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/87b920f0-ce80-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "14197aa0-e3d9-11e4-a9f0-f9928f517e20"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Full Day of Awesomeness</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Not only will you get the day off but we'll give you $100 gift card to blow on whatever it is you do. The catch? You have to rock HighGround gear and submit a picture of what you did with the money.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>30000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/5c66b600-e3ad-11e4-9b90-177842d0af43.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "03ce91b0-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Plush Goat</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">We scoured the internet to offer the cutest stuffed goat mankind has been able to produce. Be warned: this cuddly version of Gus is in limited supply.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/0db2e930-fe29-11e3-8462-1fef1dc3f7dc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "573a9e20-e430-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Goat Tote</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Have a lot of stuff to carry?  Hate using a Trader Joes bag?  Tote your groceries, gym shoes or hot sauce collection in this stylish goat tote.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/c8f29da0-c811-11e4-b241-b90269b1ac83.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7b228320-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Socks-as-a-Service</strong> was recently added to the store!</h4><div class=\"mar-bot10\">It's time to add some wonderful stockings to your wardrobe, and with Socks as a Service, Libby is going to get you squared away today! She'll make sure that your feet are comfy AND stylish!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1200</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/acb543b0-86c4-11e4-b898-bfbb5b21f37e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "810fffb0-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">500 credits to purchase a $50 gift card of your choice from the gift cards tab.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/bc09e1a0-d8b2-11e4-929f-4dd63b950082.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "76dfe410-1f4f-11e5-8b75-a5b3b0000dce"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$100 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">1000 credits to purchase a $100 gift card of your choice from the gift cards tab.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/db93c3b0-d8b2-11e4-98f4-7f3e7d34ef75.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "80db6ed0-1f4f-11e5-8b75-a5b3b0000dce"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$100 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">1000 credits to purchase a $100 gift card of your choice from the gift cards tab.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/db93c3b0-d8b2-11e4-98f4-7f3e7d34ef75.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "89431320-1f4f-11e5-8b75-a5b3b0000dce"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go See the Reds</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">$200 Reds Gift Certificate for you to choose your game, your seats, your day! While poised to make his fourth consecutive Opening Day start when he pitches for the Reds Monday vs. the Pirates, ace Johnny Cueto could be beginning his final season in Cincinnati.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/815fa6b0-ce81-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5e9b0600-1f54-11e5-8b75-a5b3b0000dce"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make A Manager Bring You Coffee For A Week</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">No description needed.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/0ce161f0-264e-11e5-bbfa-69b379a2f777.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "196ff3a0-264e-11e5-8941-31fd127a310d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Standing Desk</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">For those who want to stay healthy and motivated while standing up.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>15000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/3f77f980-264e-11e5-bbfa-69b379a2f777.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "49c21970-264e-11e5-84aa-a9a9d46f41a5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Vodka in Volume with Andy</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Ever wondered how you could put away two bottles of vodka without blinking? Think no more. Spend some time with our seasoned Russian, Andy, killing time and brain cells while learning how to drink two bottles of vodka. No drunk texts included.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/29668b40-2bfb-11e5-9fe2-fd758d244ee1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "af386a11-264f-11e5-8941-31fd127a310d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Big Star for Two</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Head to Big Star with a plus one via Uber. It's all on us. You'll just be required to submit a picture of the two of you at lunch!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/62cd77a0-2650-11e5-9431-47703a567a4b.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7feb62c1-2650-11e5-8941-31fd127a310d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fitbit Flex</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">What's the best way to stay fit? Is it a personal trainer? Your ex's upcoming nuptials? Netflix asking if you're still there? NOPE. It's an electronic wrist thing that tracks your activity. Welcome to a new world of health-filled competition with your friends, colleagues, and of course, the greatest opponent of all, yourself.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/093063b0-2655-11e5-bbfa-69b379a2f777.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1125e540-2655-11e5-84aa-a9a9d46f41a5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch on New Corp</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Enjoy lunch from your restaurant of choice! Up to a $20 value.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/19825740-265b-11e5-8802-6b5775442ba5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "205d6820-265b-11e5-9a13-91dfbc8aa830"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Wrestle Tony the Bear</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Keep telling your colleagues about your Crossfit classes but want to show them how strong you actually are? Here's your opportunity. Get into the cage with New Corp's resident Bear Tony, and show your colleagues why you spend so much money on that protein powder.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/5d9c05c0-2bfb-11e5-8fa7-397fbdd1f872.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "9e0f2eb0-265c-11e5-84aa-a9a9d46f41a5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Design Your Own Coffee Mug or Pint Glass</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Coffee is for closers. Prove it.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/c0bce600-265c-11e5-bbfa-69b379a2f777.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c7d3a050-265c-11e5-84aa-a9a9d46f41a5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Learn How to Make A Turkey Club with Orazio</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Tired of all those PB&J's? Well, that only makes one of us, but we'll still help expand your culinary expertise with the help of Fooda CEO, Orazio Buzza. For one hour Orazio will dazzle you with his abilities to spread, layer, and create one of the most delicious turkey clubs you'll ever have in your life.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/48ef6e90-2efe-11e5-8aef-5b540ea2df5f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "72ca2750-2efe-11e5-b014-f113f4f74971"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Executive Mentorship with Moose</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Spend one-on-one time with Moose every other week for 2 months (total of 4 sessions</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/c22a2f70-264d-11e5-bbfa-69b379a2f777.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e3bf23c1-264d-11e5-8941-31fd127a310d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Bob's Dialect Neutralization Lessons</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Trying to make it in the States while making people think you're from the States? Look no further than Bob Ghoorah. Although originally from the streets of Mumbai, you'll easily mistake him for a Winnetka native. In your six monthly dialect neutralization lessons, you'll quickly have colleagues stumped as to where you grew up.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/49/3616fcd0-2bfb-11e5-9fe2-fd758d244ee1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2e8dee30-2654-11e5-8941-31fd127a310d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>A walk w/your manager</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Take a lap with the manager of your choosing!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/e23a0040-3478-11e5-b923-53aa0fff9d10.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ec3c41c0-3478-11e5-bef0-49fe4b246183"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Attend a fitness class</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Pilates? Yoga? Test out a fitness class of your choosing!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/065cf270-3479-11e5-8741-c3aad04b2c48.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0ffec470-3479-11e5-a6d2-cda5020121f5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Hit the Gym</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Titus will cover your gym membership for a month!  \n\n*Up to a $80 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>320</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/2d71fb80-3479-11e5-8c9e-6f49cddab3af.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "33cc1c91-3479-11e5-bef0-49fe4b246183"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>TED Talk Lunch</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Host a Lunch and Learn for your team - you pick the topic and TED Talks</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>700</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/4b5384c0-3479-11e5-931a-1d9b3b386142.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "51a03850-3479-11e5-a6d2-cda5020121f5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>3 Questions for CEO</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\"></div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/7cde51a0-3479-11e5-a326-af78857187ab.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8763a5d0-3479-11e5-bef0-49fe4b246183"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch on Titus</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Enjoy lunch from anywhere you'd like. \n\n*Up to a $20 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>80</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/814c44c0-7e54-11e5-9f35-756ea9792dbe.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ab27fd41-3479-11e5-bef0-49fe4b246183"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Feed your Addiction</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Enjoy your daily cup of joe...for a week...on us!  \n\n*Up to a $15 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>60</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/b17af260-3479-11e5-931a-1d9b3b386142.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "bd138b50-3479-11e5-a6d2-cda5020121f5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Compressed Workday</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Come in an hour late, leave an hour early</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/c910d980-3479-11e5-8c9e-6f49cddab3af.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "cf086830-3479-11e5-a6d2-cda5020121f5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Name it and Claim it</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Create a new everday badge for the company to give out</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/ea95c840-3479-11e5-b923-53aa0fff9d10.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "eccb1ed0-3479-11e5-a6d2-cda5020121f5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Subsicription to magazine or online site (netflix, prime) 3 month</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/e6110c90-3ec3-11e5-8c4b-89f709c9d5df.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ec769f50-3ec3-11e5-a998-4bc1211c6836"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Paid trip to attend vision tour event</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>12000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/0c1bd190-3ec4-11e5-8c4b-89f709c9d5df.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1036d810-3ec4-11e5-a998-4bc1211c6836"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Outdoor team picnic</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/2c12f460-3ec4-11e5-a049-2f64350f793a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2e1c31e0-3ec4-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take a friend to lunch on us - up to $40 Value</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/b8b1a470-3ec4-11e5-a049-2f64350f793a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c32f5780-3ec4-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$25 for Businessolver Apparel</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/c6abc480-6399-11e5-959e-6b5ce8336368.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "db202fe0-3ec4-11e5-a998-4bc1211c6836"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Access to your own conference room for the day</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>700</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/f2e25720-3ec4-11e5-8c4b-89f709c9d5df.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f8e61ad0-3ec4-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Profile of employee highlighted on company site</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/11f868c0-3ec5-11e5-a6cb-15a203acaedc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "16a32c20-3ec5-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>One hour Personal training class with Tracey</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/490a7650-3ec5-11e5-a049-2f64350f793a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "524c26f1-3ec5-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Park in main lot for a week</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/a521e6d0-3ec5-11e5-a049-2f64350f793a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "b7b26771-3ec5-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Two hour lunch break</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/d4d49850-3ec5-11e5-a049-2f64350f793a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "db811f21-3ec5-11e5-a998-4bc1211c6836"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cell phone bill paid for two months</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/ec3b5920-3ec5-11e5-b6b5-6773818061c0.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f3534bf1-3ec5-11e5-a998-4bc1211c6836"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Weekend getaway for two</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>15000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/0659e6f0-3ec6-11e5-b6b5-6773818061c0.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0b411710-3ec6-11e5-a998-4bc1211c6836"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Pick a name your team calls your boss for a week</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/681f8110-3ec6-11e5-a6dc-27824b624806.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6aa1bf20-3ec6-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Pay for dues to get life and health certified</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>900</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/90c16bb0-3ec6-11e5-b6b5-6773818061c0.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "949afc61-3ec6-11e5-a998-4bc1211c6836"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Ted talks luncheon for team</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/b7e800f0-3ec6-11e5-8c4b-89f709c9d5df.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "be3d18f0-3ec6-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Two tickets to local sporting event</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/e6af19f0-3ec6-11e5-a6cb-15a203acaedc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "edd6eb40-3ec6-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Pick a new desk</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/7f83db70-3ec7-11e5-ad60-85fe27907263.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1d8779e1-3ec7-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Movie party late afternoon</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/4177c350-3ec7-11e5-8c4b-89f709c9d5df.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4d5331a0-3ec7-11e5-b3d2-51476a3a0e72"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Test Group Store Item</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Please elect this item for testing purposes.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/cbac2070-563c-11e5-bcdb-ddd48ef71451.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ecd42220-563c-11e5-88dd-25ca44ab740f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Chicago Ideas Week Ticket</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Chicago Ideas is a movement built on one core belief: When a broad spectrum of thinkers and instigators share ideas, we have the power to transform our world. Chicago Idea's Week is October 12-18th. To get your ticket see Libby.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/d997c150-5bf3-11e5-8143-cdaf16cae2e8.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e5dc0390-5bf3-11e5-b6f2-d1ab36e73d88"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2 Hour Stress Free Lunch</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Take a 2 hour lunch on the house - no phone calls allowed!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/55/a8ef62d0-60a1-11e5-9102-4f7cdaf612e3.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "adc295c0-60a1-11e5-88eb-3b8a775058c1"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Friday Afternoon Off</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>600</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/55/e58d1de0-60a1-11e5-b5f5-efef85253c1e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e9794c30-60a1-11e5-8b27-11928e0eb128"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>\"Move it to the Top\" Card</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Purchase this card to move a file of your choice to the top of the list all the way through the process.  A handy thing to have!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/55/1b540dd0-60a2-11e5-9f31-f3457444bb58.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1f205810-60a2-11e5-8b27-11928e0eb128"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Apple Watch</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/b2b4bef0-63ad-11e5-85ce-3381905b9745.jpg\"  /></div></a>",
    "hgId" : "f01295b0-63ad-11e5-82ad-bfd4b2028bc7",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Bump it up!</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Mortgage Bankers: cash in this award to bump your file up one place in the underwriting queue!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/55/5cab1f10-63bf-11e5-85ce-3381905b9745.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "75464130-63bf-11e5-8658-b3d7d8f0bf1b"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Securus E-Store</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Visit the e-store to browse available products for purchase! \nhttp://www.securusbrandstore.com/</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/53/b7c07680-66ac-11e5-a501-7f551c45caa1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f9df09a0-66ac-11e5-8891-018e8785f9c8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HighGround Hoodie</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Keep warm in the office this fall with a comfy, Alternative HighGround hoodie. These are in high demand so get one before they run out! Actual image will be shared once our logo is complete. Thanks to Ian for being my model! See Libby to claim your hoodie.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/113abcb0-bb09-11e5-940d-41b005e90e3a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4b82bd60-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Donate 2 Goats to Families in Need!</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Lets spread the love and donate 2 goats to a family in need through World Vision. One goat can change everything. Her milk provides great protein to help children grow. The family can also sell any extra to earn money for medicines and other necessities.\n\nA healthy dairy goat can give up to 16 cups of milk a day. Goat's milk is easier to digest than cow's milk and is an excellent source of calcium, protein, and other essential nutrients that growing children need. Goats are practical animals — flourishing in harsh climates while producing valuable manure to fertilize crops and vegetable gardens. Lets all collectively help change a families life!</div><div class=\"is-bottom-padded product-item-label\">This item's funding goal is <h5><i class=\"icon icon-point\"></i>15000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it expires!</div><img src=\"//stcdn5.highground.com/product/1/bb370df0-d986-11e4-a122-534c1db787a1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>CAMPAIGN</strong> is available in the store!</div>"
},
    "hgId" : "e782c0f0-66c3-11e5-8891-018e8785f9c8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Suggest a Snack</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Don't keep it a secret any longer....let us know what your favorite snack or drink is so we can share it with the entire office! See Libby to put in your snack request.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/ce8b7540-50ef-11e5-9dba-717473d60d4a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1d42ac00-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Socks-as-a-Service</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">It's time to add some wonderful stockings to your wardrobe, and with Socks as a Service, Libby is going to get you squared away today! She'll make sure that your feet are comfy AND stylish!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/acb543b0-86c4-11e4-b898-bfbb5b21f37e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1d4766f0-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Chicago Ideas Week Ticket</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Chicago Ideas is a movement built on one core belief: When a broad spectrum of thinkers and instigators share ideas, we have the power to transform our world. Chicago Idea's Week is October 12-18th. To get your ticket see Libby.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/d997c150-5bf3-11e5-8143-cdaf16cae2e8.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "46efc510-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Name a Conference Room for a Week</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Have you ever dreamed of naming a conference room? Well, it is a pretty big deal. See Libby to plan the room unveiling.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/75dd31d0-5bef-11e5-92bb-7f745ccb3855.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "46f20f00-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Decorate your boss’ desk however you want!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Spend up to $20 on supplies to decorate your boss's desk however you want. Yes thats right, however you want....as long as it isn't offensive, derogatory or insulting of course. See Libby to plan the attack.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/c8a6f560-6232-11e5-b5d9-87e0f0a3065b.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4ce13940-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>I Ain't Afraid Of No Goats Tee (Only XL)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Who ain't afraid of no goats? You ain't! If you have a fetish for tees you will want to add this to your closet collection. See Libby to claim your gift.\n\nP.S. This is not the picture on the tee :)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/bba55730-66bf-11e5-a501-7f551c45caa1.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6aa0bb90-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>A Studly G.O.A.T tee</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">There aren't words to describe this tee. You just need it in your closet to be the coolest kid around. Only 5 lucky folks will get this tee so see Libby to order yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/dca16640-6232-11e5-aa88-195cdab03542.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "71062740-66c4-11e5-8891-018e8785f9c8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Plush Goat</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">We scoured the internet to offer the cutest stuffed goat mankind has been able to produce. Be warned: this cuddly version of Gus is in limited supply.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/0db2e930-fe29-11e3-8462-1fef1dc3f7dc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8e7cb9b0-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Girl and the Goat for 2 + Uber</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Spend up to $75 on a meal at Girl and the Goat in the West Loop. To sweeten the deal, your Uber to and from will be covered as well. Please keep your itemized receipt and submit the expense report to Kevin. Don't forget to take a photo of your fabulous feast and send it to Libby.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>11000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e781f9d0-6232-11e5-bb73-770346793e01.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "946db8b0-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Home Food Delivery Service for 1 Week</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Headquartered in Chicago, HomeChef's mission is to make cooking fresh food at home as easy as possible. Their chefs shop for you and plan your meals, allowing you to choose from a new menu every week. They offer a meal delivery service that includes all of the fresh ingredients and instructions needed to cook restaurant quality meals for 2, 4 or 6 people in the comfort of your own kitchen. They eliminate recipe and food hunting by sending you a flavor packed kit along with easy-to-follow, step-by-step instructions, turning you into a top chef. Get 1 week of food delivery for 2! See Libby to place your order.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>11500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/c957da60-6228-11e5-bb73-770346793e01.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "b2cb28b0-66c4-11e5-8891-018e8785f9c8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>1 Night at the Grand Geneva Resort</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Grand Geneva resort, conveniently located in Lake Geneva, Wisconsin near Chicago and Milwaukee, is a AAA Four Diamond resort. There are no shortage of activities to enjoy while at the resort, no matter the season! Get away for a night with a loved one or friend and enjoy the serenity of Lake Geneva. See Libby to book your stay.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>20000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/a3793b80-5bf3-11e5-913a-71f051b83d61.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "b2e874b0-66c4-11e5-8891-018e8785f9c8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HighGround Laptop Sleeve</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">We all hate when our electronics get scratched, so protect your laptop with this swanky laptop sleeve. Actually picture will be shown once our logo is complete. See Libby to claim your gift.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/b76ceef0-6230-11e5-b1b8-df4e4f8c4feb.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d0364970-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HighGround Beanie</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Keep warm during the frigid Chicago winters with this stylish HighGround beanie. Actual product image will be displayed once the logo has been finalized. See Libby to claim your gift.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/401457b0-6232-11e5-aa88-195cdab03542.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d0375ae0-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HighGround Hoodie</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Keep warm in the office this fall with a comfy, Alternative HighGround hoodie. These are in high demand so get one before they run out! Actual image will be shared once our logo is complete. See Libby to claim your hoodie.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/74dce6d0-e3b4-11e4-bc6a-05f5c85cb9c7.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d037f720-66c4-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$100 Continuing Education Credit</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Get reimbursed for a continuing education course of your choice, up to a $100 value. You could attend a webinar, class to expand your technical skills or buy a podcast about new subject matter. Nurture your inner curiosity with this continuing education gift! See Libby for more details.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/20d81a10-622a-11e5-bb73-770346793e01.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e8712320-66c4-11e5-8891-018e8785f9c8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Warby Parker Glasses</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Who doesn't love the trendy Warby Parker glasses AND their mission to donate a pair of glasses for each pair sold. Spend up to $125 on a new pair of glasses for you or a family member. How it works: You chose 5 pairs of glasses that get sent to your home and you have 5 days to make your pick. You only pay for the one you want to keep and send the others back! See Libby for more details.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>12500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/5cb68db0-6233-11e5-bb73-770346793e01.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f3e459c0-66c4-11e5-8891-018e8785f9c8"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Spa Certificate</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Sit back, relax and pamper yourself with a spa service up to a $50 value of your choice at your favorite salon. See Libby to schedule and purchase your services</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e6d060d0-e3b1-11e4-8b37-95bd8380dfc5.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "05b86830-66c5-11e5-9aea-7971556cd0b6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Click N' Sip Stainless Steel Tumbler</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">And what better way to celebrate a workiversary than with a nice hot drink in the morning? Or perhaps with a perfectly chilled drink in the afternoon? That's right, you can have both with your very own Click N' Sip Stainless Steel Tumbler!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/943e34a0-7db7-11e5-9f35-756ea9792dbe.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d415a000-6d26-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Camelbak Performance Bottle</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">What better way to celebrate your workiversary than with your very own 22 oz Camelbak Performance Bottle. That's right, never worry about spilling your drink ever again!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/7db7ea20-7432-11e5-981a-8f0787e413e6.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "b6c64f30-6d27-11e5-a746-cdf08aa1a6f9"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Jolt Premium Power Kit</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Make sure you don't miss a beat and stay charged up and ready to go with your handy dandy Jolt Premium Power Kit. No matter if you're at home, in the car, or on the go, this kit will make sure to keep your gadgets alive.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/84cf67c0-7432-11e5-bc2e-31fc2e081ece.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e134c700-6d28-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Knitted Winter Set</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Is it going to be winter soon? Is it cold already? Is it Chicago? Whatever the case for wherever you are, keep warm with this Knitted Winter Set. If you're in a warm climate office, you can wear this inside with A/C blasting to make everyone else feel bad too, whatever works.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/90a24a90-7432-11e5-981a-8f0787e413e6.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "4c6e1e40-6d29-11e5-a746-cdf08aa1a6f9"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Playful Plaid Picnic Blanket</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">A wise man once said that life is a picnic, so why not  celebrate your workiversary with an Echo Playful Plaid Picnic Blanket! No that's not a joke and the actual name of the blanket, quite a mouthful isn't it?</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/7e00eaf0-743b-11e5-bc2e-31fc2e081ece.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8ea9b9d0-6d2a-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>60\" Vented Golf Umbrella</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">When the sun shines we'll shine together, told you I'd be here forever. Now it's raining more than ever, know that we'll still have each other. You can stand under my Vented Golf Umbrella ella ella eh eh eh...</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/acaa7ff0-7432-11e5-a1b8-bdad9dfbf9c7.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2fac23e0-6d2b-11e5-a746-cdf08aa1a6f9"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Brick Bluetooth Speaker</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Newer is better in most cases, but sometimes the best music is the same music you were listening to back in the good ol' days. And what better way to listen to your favorite old school jams than with this Brick Bluetooth Speaker! Let the nostalgia wash over you.</div><div class=\"product-item-label clearfix\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn5.highground.com/product/24/883c8bf0-743b-11e5-aef0-37ca4ca6983a.jpg\"/></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "af0e1600-6d2d-11e5-a746-cdf08aa1a6f9"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Power Bank</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Hate it when your phone runs out of juice? How will you respond to that email? Or more importantly, how will you know what your best friend had for lunch? Keep the good times rolling with this Power Bank and never worry about missing a post about what your friends are eating ever again!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/b44e10f0-7432-11e5-8119-01cb1f5dae65.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2749cf60-6d2e-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Ice River Cooler</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Don't let appearances fool you, drinks go on the inside and people sit on the outside, magical isn't it? Be smooth, be cool, take a load off and have a cold beverage of your choosing, all with the help of your very own Ice River Cooler.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/994e5bd0-743b-11e5-bdc7-d5c05fc9de86.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c6e44f90-6d2f-11e5-bb87-dd2f9472f27e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Deluxe Lambswool Lounge Throw</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">What's better than pie? Not much, but I do know that pie is even better when you're wrapped up in a nice, warm, comfy Deluxe Lambswool Lounge Throw! Why did we start this description with pie? Because blankets are self-explanatory and pie is delicious, that is all.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/be5a8ba0-7432-11e5-aef0-37ca4ca6983a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "a3966b30-6d30-11e5-bb87-dd2f9472f27e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go-Anywhere Fold-Up Lounge Chair</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Every king or queen needs their throne, and even if this one isn't made out of swords it's definitely much comfier. I just realized that's a reference not everyone will get, so if you don't pick up on it just... ignore the blabbering. Anyways... people will always need to sit and what better way than with this Go-Anywhere Fold-Up Lounge Chair!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/a2107c30-743b-11e5-bc2e-31fc2e081ece.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "aaf4d580-6d33-11e5-bb87-dd2f9472f27e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Checkmate Backpack</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Too much to carry and not enough pockets? Too many pockets but nothing to carry? This will solve one of those two problems, yes we're talking about the amazing Checkmate Backpack. Specially designed to allow you to keep your laptop in the bag during security checks, your speed and efficiency through the checkpoint will be unmatched! If you're not a big traveler, just know that when you do go on a trip, your backpack will be ready to go.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/a3905320-7db7-11e5-8c6e-b38f7f778c9f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "344767d0-6d34-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>High Sierra 26\" Duffel</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Not a backpack type of person? No worries, we've got you covered (unless don't like duffel bags, then sorry that's all I got). If you're just going about your day, taking a trip to the beach, or swinging by the gym, you can always bring along your trusty High Sierra Duffel bag! Feel free to take a trip anywhere else, not sure why those two destinations were the first that popped up in my head but they kind of go together right?</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/b02d7610-743b-11e5-a1b8-bdad9dfbf9c7.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "16e3f2c0-6d35-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Bluetooth Connectivity Kit</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Here's a way to make your music listening experience a little better with this Bluetooth Connectivity Kit! Hook it up to the auxiliary port of your favorite stereo system or car, turn any pair of old regular headphones into bluetooth headphones, what else could you ask for?</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/d21c3940-7432-11e5-8119-01cb1f5dae65.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6a5a3860-6d35-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>8 Year Anniversary Award</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Congratulations on your 8th workiversary!\n\n8 years, great years, 8 great years is what we just shared. Comfortable but not complacent, take this opportunity to reflect on all of your experiences in the last 8 years and how far we've come. Few make it this far and we're glad to have you with us, thank you for everything you've done to make Echo the place it is today.\n\nLove hearing things but hate wires? How come wires get tangled no matter what you do to try and prevent it? Fear no more, Echo Wireless Headphones are here to save the day!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/d9548550-7432-11e5-981a-8f0787e413e6.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5f519880-6d37-11e5-bb87-dd2f9472f27e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Punchbox Bluetooth Speaker</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">What do you do when your phone speakers aren't loud enough? Miss having a boombox that you could carry on your shoulders? Well, it's not a boombox but it's a Punchbox Speaker! Time to turn up the volume and get the party started!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/b6df5410-743b-11e5-981a-8f0787e413e6.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c4c7de90-6d37-11e5-bb87-dd2f9472f27e"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>9 Year Anniversary Award</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Congratulations on your 9th workiversary! \n\nAnother year and another Milestone Anniversary, and I've always wondered about celebrating your 9 year anniversary. Does it feel like you're about to turn 21 with the world at your feet? Or is it more of a I'm 29 and turning 30 type of deal. Regardless of how you approach it, there's not much more out there more impressive than hitting your 9 year workiversary! And don't forget to start getting ready for the big double digit Milestone next year... it's always an extra special one.\n\nTiffany Blue, is there anything more that needs to be said? $125 bucks will get you something nice, or at least give you a head start on something REALLY nice.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>900</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/67789810-6d3c-11e5-959c-330ca3c8a267.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "73e83010-6d3c-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>iPad Mini</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Boom, pow, sparkle sparkle, yes that was a feeble attempt at sounding like fireworks. Just trying to help celebrate good times, but a brand new iPad mini is probably going to move the needle a bit more. In fact, I bet there's even an app for fireworks, yes, please download that app and reread this description, it'll make much more sense.. possibly...</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/72fb74f0-7796-11e5-ad7c-574cbf23781a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "afd0d680-6d3d-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cash Money... Actually Plastic Money</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">2,500 Engage Credits for you to have your pick from every gift card under the sun... well at least the ones that are on Echo Engage. Better yet, split up your credits and redeem more than one! Does it get better than this? Dubious.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/74df4530-7c2d-11e5-876b-0d01ba6d70ed.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "fd7abc20-6d3d-11e5-9ec7-21219e822023"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Call of Duty Black Ops 3</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">For all you gamers out there, pool your points together by October 30th for the new Call of Duty Black Ops 3 for the Game Room.</div><div class=\"is-bottom-padded product-item-label\">This item's funding goal is <h5><i class=\"icon icon-point\"></i>6000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it expires!</div><img src=\"//stcdn5.highground.com/product/1/52ce28a0-6cae-11e5-9865-032341b4b7ec.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>CAMPAIGN</strong> is available in the store!</div>"
},
    "hgId" : "4de568d0-6dd5-11e5-b6eb-03bc7e835c1b"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>KC Sports Tickets</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Pair of tickets to a KC sports event!  Sport varies based on the season this award is purchased (Football, Baseball, Basketball, etc).  *Available for KC3 employees only.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/55/a2c16bf0-71e6-11e5-a813-3ffe03adb735.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "aac62fc0-71e6-11e5-9cac-6b8d0ce6fece"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>3 Year Anniversary Award</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Congratulations on your 3rd workiversary!\n\nSnap, crackle, pop, 1, 2, 3 years checked off the list. You're getting that veteran swagger because you know what you're doing and you're good at it. Now it's just a matter of finding new ways to get even better at it and showing the ropes to the newcomers, yup, the student has graduated. \n\nWhen the sun shines we'll shine together, told you I'd be here forever. Now it's raining more than ever, know that we'll still have each other. You can stand under my Echo Umbrella ella ella eh eh eh...</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/acaa7ff0-7432-11e5-a1b8-bdad9dfbf9c7.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "a2cfeab0-7432-11e5-a54c-a34563594e8d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lifestyle 7-in-1 Desktop Game Set</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Up for a game of checkers? Maybe step up the difficulty and battle wits in a game of chess? How about trying to figure out backgammon since it feels like there's no one who actually knows how the game the played? All kidding aside, sometimes it helps to take a breath and refocus, and what better way than with a quick game on your Lifestyle 7-in-1 Desktop Game Set.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/b7e36b50-7db7-11e5-ae30-f98c58d070f2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8d2a4910-7cbd-11e5-8753-cfc882d7b9a6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Sonoma Automatic Wine Opener</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Are you still opening wine bottles the old fashioned way, with a twisty pointy thing and brute strength? Well, fear no more, for now the sweet delicious bottle wine you've been yearning for can be yours with just the press of a button. This Sonoma Automatic Wine Opener will be almost as impressive for your party guests as the whole slice the bottle with a knife deal, and much safer.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/c0e18340-7db7-11e5-9f64-9be642bc2928.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f2a45fb0-7cbd-11e5-8753-cfc882d7b9a6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Solace 5-in-1 Outdoor Game Set</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Do you fancy yourself to be a jack of all trades? Perhaps you're looking to display your dominance in all sports that require a net. Whatever the case may be, your time to shine is here with the Solace 5-in-1 Outdoor Game Set. You're on your way all the championships you could want, not 1, not 2, not 3, not 4...</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/397de2d0-7cbe-11e5-ac62-07242e585e1f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "93a08830-7cbe-11e5-be69-db5ce566f05a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>90 Watt Bluetooth Soundbar</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">A perfect partner in crime for everything that makes noise, this Bluetooth Soundbar will take your home cinema experience to the next level. After this, the only thing you'll need to turn your living room into a movie theater is a 150' screen and about 80 strangers talking through all your shows.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/17e094a0-7cbf-11e5-a5b4-339b30c6d5cd.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "28b88fd0-7cbf-11e5-8753-cfc882d7b9a6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Solace 5-in-1 Outdoor Game Set</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Do you fancy yourself to be a jack of all trades? Perhaps you're looking to display your dominance in all sports that require a net. Whatever the case may be, your time to shine is here with the Solace 5-in-1 Outdoor Game Set. You're on your way to all the championships you could want, not 1, not 2, not 3, not 4...</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/dd0c82e0-7db7-11e5-8c6e-b38f7f778c9f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5fb344d0-7cbf-11e5-be69-db5ce566f05a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>90 Watt Bluetooth Soundbar</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">A perfect partner in crime for everything that makes noise, this Bluetooth Soundbar will take your home cinema experience to the next level. After this, the only thing you'll need to turn your living room into a movie theater is a 150' screen and about 80 strangers talking through all your shows.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/c9b5cc10-7db7-11e5-8c6e-b38f7f778c9f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5fb62b00-7cbf-11e5-be69-db5ce566f05a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Brookstone Electric Wine Chiller</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">It's made by Brookstone, so you know this is a necessity and not at all a fun to have gadget.  Most people hate warm wine as much as they hate rabies, so make sure you're never forced to drink it ever again with this Electric Wine Chiller. It's even got different settings depending on what type of wine you're drinking, simply amazing.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/e5dfba40-7db7-11e5-8c6e-b38f7f778c9f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "b1e4ae60-7cbf-11e5-8753-cfc882d7b9a6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Giant Tailgating Grill</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Love sporting events? What about concerts? What about... standing around in a parking lot? Well if any of these descriptions are applicable for you then you're in for a treat. Now you can stand around before fun events and grill! This Giant Tailgating Grill (not actually for giants, normal people can use this without any issues) is portable, convenient, and will make food delicious for you. How great is that?</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/24/ed0cbbb0-7db7-11e5-ae30-f98c58d070f2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "b4434160-7ccb-11e5-b31d-f38843bf2309"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Apps and Music</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Do you want to be a dancing shadow person like the one shown on the card?  Then click \"Purchase\" now!  \n\n*Up to a $15 iTunes Gift card.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>60</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/527322c0-d469-11e5-973f-3134274b90ce.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "af2f49e0-7e55-11e5-95b2-b31b905a4b87"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Jawbone Wearable Device</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Purchase a Jawbone wearable to use during Step It Up 2015. Purchasing this product will get you a $40 credit to use towards any Jawbone device you want (https://usstore.jawbone.com/businessolver). In addition, Jawbone is throwing in a 25% discount to all Businessolver employees.\n\nPlease note: You will only be able to purchase one $40 credit towards one device, however you are able to use the 25% discount for up to five devices.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/2e91d610-832b-11e5-a5db-9369d2709d0b.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f43f9c30-832b-11e5-829c-e936c89e68df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch/Dinner on Struck</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Lunch/ Dinner up to $15.00! \nSubmit receipt through workamajig.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>150</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/19/09545fd0-32c8-11e4-9559-e9b2bc08c822.jpg\"  /></div></a>",
    "hgId" : "b5dc1cc0-92b7-11e5-be8c-8dc9f4908f77",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Out of Timesheet Jail Free Card</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Hey why not take one offense off your record to keep you eligible for the company incentive.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/19/2b5db640-32c7-11e4-9559-e9b2bc08c822.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2fe3a330-92bd-11e5-9c2e-497c61bc4501"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$05 for Businessolver Apparel</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/40bc3890-9879-11e5-a9ed-9f49bc670194.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1d10a3d0-987a-11e5-addc-35203780a2fe"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$10 for Businessolver Apparel</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/9ed6a500-9879-11e5-803a-8711df6285f8.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "29cc38f0-987a-11e5-bc1f-1f26a037eebf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$15 for Businessolver Apparel</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>150</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/cb557bb0-9879-11e5-803a-8711df6285f8.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "29ce34c0-987a-11e5-bc1f-1f26a037eebf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$20 for Businessolver Apparel</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/ed5da430-9879-11e5-8863-3995601eed3d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "2eeca180-987a-11e5-addc-35203780a2fe"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>{SMALL} Wave the Next Time You Fly Over - TShirt</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Size Small. Color same as picture shown.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/a7342b10-9cf6-11e5-81d7-214efe810db3.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ad11fac0-9cf7-11e5-bbb5-396ce2f1fda6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>{MEDIUM} Wave the Next Time You Fly Over - TShirt</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Size Medium. Color same as picture shown.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/db595c70-9cf7-11e5-81d7-214efe810db3.jpg\"  /></div></a>",
    "hgId" : "f48525d0-9cf7-11e5-8d07-95738e464579",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>{LARGE} Wave the Next Time You Fly Over TShirt</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Size Large. Color same as picture shown.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/10649d80-9cf8-11e5-9bc6-87101aef0afa.jpg\"  /></div></a>",
    "hgId" : "18a272b0-9cf8-11e5-8d07-95738e464579",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>{SMALL} Idawahio TShirt</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Size Small. Color is blue, not yellow like the picture shown.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/405ff0c0-9cf8-11e5-9942-13c47bc57eb6.jpg\"  /></div></a>",
    "hgId" : "4e074570-9cf8-11e5-a47d-55232a1186e6",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>{X-LARGE} Idawahio TShirt</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Size XL. Color is blue, not yellow like the picture shown.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/5c221c70-9cf8-11e5-81d7-214efe810db3.jpg\"  /></div></a>",
    "hgId" : "65f47450-9cf8-11e5-8d07-95738e464579",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HighGround Beanie</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Keep warm during the frigid Chicago winters with this stylish HighGround beanie. Actual product image will be displayed once the logo has been finalized. See Libby to claim your gift.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/401457b0-6232-11e5-aa88-195cdab03542.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "16c27f30-9f55-11e5-9f24-1fc57679332a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fitbit Flex</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">What's the best way to avoid laziness? Personal trainer? Self-discipline? NOPE--think again, Grandpa. It's an electronic wrist thing that tracks your activity. And then some. Welcome to a new world of health-filled competition with your friends and, of course, the greatest opponent of all: yourself.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e1cdbda0-e3aa-11e4-80bc-6d91a5578a59.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "728a2330-9f6f-11e5-8d62-817091251cf6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make-A-Wish® Iowa</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">\"Make-A-Wish® grants the wish of a child diagnosed with a life-threatening medical condition in the United States and its territories. We believe that a wish experience can be a game-changer. This one belief guides us in everything we do. It inspires us to grant wishes that change the lives of the kids we serve.\" - Make-A-Wish® \n\nJolly Holiday Lights, the annual fundraiser for Make-A-Wish® Iowa, is now closed for the season due to the flooding in Water Works Park.  Make-A-Wish® Iowa has estimated they will lose $200,000 in donations this year - that is equal to 20 kids who will not be granted wishes in 2016 because funding will not be there.  \n\nDue to the overwhelming Solver Spirit that has been kicked off by our own Jeff Anderson, and the numerous requests we have received, Businessolver will contribute up to $10,000 worth of swag donated through this campaign on behalf of all our employees.\n\n100 ROAD Points = $10</div><div class=\"is-bottom-padded product-item-label\">This item's funding goal is <h5><i class=\"icon icon-point\"></i>100000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it expires!</div><img src=\"//stcdn5.highground.com/product/52/d9b74b40-a344-11e5-b7a1-61a4710378ae.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>CAMPAIGN</strong> is available in the store!</div>"
},
    "hgId" : "dbd19fc0-a344-11e5-ad2c-d547e0ae5f51"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make-a-Wish Iowa</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Jolly Holiday Lights, the annual fundraiser for Make A Wish Iowa, is now closed for the season due to the flooding in Water Works Park.  Make A Wish Iowa has estimated they will lose $200,000 in donations this year - that is equal to 20 kids who will not be granted wishes in 2016 because funding will not there.  \n\nDue to the overwhelming Solver Spirit that has been kicked off by our own Jeff Anderson, and the numerous requests we have received, Businessolver will contribute up to $10,000 worth of swag donated through this campaign on behalf of all our employees.</div><div class=\"is-bottom-padded product-item-label\">This item's funding goal is <h5><i class=\"icon icon-point\"></i>100000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it expires!</div><img src=\"//stcdn5.highground.com/product/52/d9b74b40-a344-11e5-b7a1-61a4710378ae.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>CAMPAIGN</strong> is available in the store!</div>"
},
    "hgId" : "2a567d40-a35f-11e5-b45e-5178ba96cb25"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Spa Experience</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Hit the spa and enjoy! ($50 value)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/d4429970-b943-11e5-91bf-137989fc4f15.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f1bc6030-b943-11e5-8701-41cf8abf46a3"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>CEO Coaching Session</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Get some personal time with the Head Honcho in a one-on-one coaching session</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3750</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/09adfbe0-b944-11e5-9047-7528f5aea2bd.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0f794a70-b944-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take a Half Day</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Because you deserve it…take a half day off.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/30ede580-b944-11e5-900b-359f7acbae61.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "33560be0-b944-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch is on us!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Let us buy you lunch ($20 value)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>600</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/46504ad0-b944-11e5-96b6-3fecb8ebf323.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5cf1e6e0-b944-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Team Theme Day</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Have some fun with your team!  It's Theme Day!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1875</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/6cd8a440-b944-11e5-9cdf-ad4475c72f13.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6ee256f0-b944-11e5-8701-41cf8abf46a3"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go to the Movies!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">See a movie in theatres on us! ($40 value)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/83976540-b944-11e5-bd5b-23279f9c71d9.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8724d1c0-b944-11e5-a86c-b96e85c8ccb0"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Marketwired Water Bottle</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Stay hydrated with a stylish water bottle.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/90d53a00-bbc6-11e5-a218-bb7b9fffa6ef.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "9ea16480-b944-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Marketwired Tumbler</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\"></div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1125</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/a3ef1ea0-b944-11e5-bd5b-23279f9c71d9.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "aa8cd860-b944-11e5-a86c-b96e85c8ccb0"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Marketwired Mug</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Enjoy your favourite beverage in a cool coffee mug.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/5684ca50-bbc6-11e5-bc4f-87d35d3a174c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c25ede20-b944-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2 Hour Stress Free Lunch Break</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Take a two hour lunch!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/d36bf310-b944-11e5-874a-4364df5538a3.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "da4221f0-b944-11e5-8701-41cf8abf46a3"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Bring on the Java!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Your boss will bring you a coffee, just the way you like it,  each day for one week! ($20 value)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/f10b9150-b944-11e5-beae-63925be1e8d3.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f81ccd60-b944-11e5-a86c-b96e85c8ccb0"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dress Up Time!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Make your boss dress up in a fun outfit or costume for the day!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1875</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/1f0d1060-b945-11e5-874a-4364df5538a3.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "21d9ec00-b945-11e5-8701-41cf8abf46a3"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Arrive Late/Leave Early Ticket</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Come in late or leave early! You've earned it!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/309e7080-b945-11e5-9cdf-ad4475c72f13.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "3fa55530-b945-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Health Kick!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Attend a personal training or workout class of your choice! ($50 value)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/50360e30-b945-11e5-900b-359f7acbae61.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5ddf5eb0-b945-11e5-8701-41cf8abf46a3"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Profile an Employee on Applause! & Dinner for 2</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Quarterly - determined by Leader Board - highest points - Awarded by Admin</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>18750</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/75191c10-b945-11e5-900b-359f7acbae61.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7b54b8a0-b945-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Team Social</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Company Sponsored Happy Hour - Teams/EE's Pool Points max $300</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>9000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/93b087d0-b945-11e5-bd5b-23279f9c71d9.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "9930c3a0-b945-11e5-9a29-47e968c76d08"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Marketwired Notebook</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Never forget anything again!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/e4c172f0-bbc6-11e5-9006-23e809e7faae.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "b14131f0-b945-11e5-a86c-b96e85c8ccb0"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$10 Gift Card of your Choice!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Spend it where you like.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/63d34530-ba48-11e5-884d-1f3263855c35.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6ec1e280-ba48-11e5-8262-858b45446181"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$25 Giftcard of your choosing</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Redeem for a $25 gift card of your choosing!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/ec774800-ba48-11e5-af4c-31a0520f8e17.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f218c770-ba48-11e5-8bb8-713ce76f49a1"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Gift Card of your Choice</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Spend it where you like.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/07a8f380-ba49-11e5-af4c-31a0520f8e17.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "09e6d590-ba49-11e5-8bb8-713ce76f49a1"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Goat Bow Ties</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Sometimes goats like to be fancy too. Dress your goat up in a fancy blue, orange, yellow or gray bowtie. #YouSoFancy.  See Libby to claim yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/3a0c9520-bb02-11e5-9924-35af29778f1b.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5926c570-bb02-11e5-a171-25bee9dc3f4f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Relax...I Goat This Tee (Only S and M)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">The Relax....You Goat This Tee is super soft and a must have for your GusWear Closet. Shirts are screen printed on a vintage navy tee. These are in limited supply so see Libby to claim your prize today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/80038240-bac7-11e5-9d3e-5f190a292d6d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "a59b6130-bac7-11e5-b12b-718ba4f235df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Shadow Any Team For A Day</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Have you ever wondered what our QA team does or what a line of code looks like? This is your opportunity to find out! Shadow any HighGround team for the day to learn more about our business and the various teams that make us tick. See Libby to organize your shadow day.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/7b7be330-bb07-11e5-a4f0-1f0e7eee148c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "854365a0-bb07-11e5-ae3a-a940b8ab612d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>One Month of Stitch Fix</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Ladies, if your wardrobe needs some spicing up this winter take advantage of this Stitch Fix deal. Simply fill out the Stitch Fix Style Profile and their personal stylists will handpick a selection of five clothing items and accessories unique to your taste, budget and lifestyle. You can buy what you like and return the rest! See Libby to get your free month today!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/15331570-bb08-11e5-a55e-fbc3310c87f6.jpg\"  /></div></a>",
    "hgId" : "20c39810-bb08-11e5-a171-25bee9dc3f4f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Home Brewing Kit</strong> was recently added to the store!</h4><div class=\"mar-bot10\">As tempting for hop-heads as for the ones who love them, this well-balanced citrusy IPA gets its bitterness from Columbus hops and its fragrant citrus aroma from super aromatic hops. And at 6.8%, it will make every day a good one. See Libby to place your home brewing kit order today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/a6f932f0-bb08-11e5-ba31-91527795cbf4.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "af76f750-bb08-11e5-a171-25bee9dc3f4f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Goat Clothes</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Pick attire under $20 for your plush goat to rock in the office. #NoNakedGoats. See Libby to place your order today.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/f5cf0920-e3a6-11e4-bb38-f541f8383ccf.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "81218480-bb0b-11e5-b12b-718ba4f235df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>GOAT Mug</strong> was recently added to the store!</h4><div class=\"mar-bot10\">GOAT Mug is a one-of-a-kind coffee mug that was inspired by the first coffee discovery. Its horn shape is a dedication to goats that discovered this elixir of life and it also lets you drink the very last sip. It comes with a set of 2 straps that allow you to carry your coffee, but at the same time reply to a couple of e-mails and carry around your newspaper. Check out their site for more info: http://www.goat-story.com/ then see Libby to order yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/db1096c0-bb0b-11e5-938d-0187c51d8787.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ec7fc8e0-bb0b-11e5-b12b-718ba4f235df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Drive by Daniel Pink</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">\"Most people believe that the best way to motivate is with rewards like money—the carrot-and-stick approach. That's a mistake, says Daniel H. Pink (author of To Sell Is Human: The Surprising Truth About Motivating Others). In this provocative and persuasive new book, he asserts that the secret to high performance and satisfaction-at work, at school, and at home—is the deeply human need to direct our own lives, to learn and create new things, and to do better by ourselves and our world.\n\nDrawing on four decades of scientific research on human motivation, Pink exposes the mismatch between what science knows and what business does—and how that affects every aspect of life. He examines the three elements of true motivation—autonomy, mastery, and purpose-and offers smart and surprising techniques for putting these into action in a unique book that will change how we think and transform how we live. See Libby to get your copy today!\"</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/3701e1a0-bb0c-11e5-8801-cd88244027aa.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ab612420-bb0c-11e5-ae3a-a940b8ab612d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Indoor SkyDiving Experience @ iFLY for 2</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">iFLY makes the dream of flight a reality with indoor skydiving in a safe and fun environment. Take a friend and visit their Naperville or Rosemont location for a once in a lifetime experience. See Libby to organize your visit today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>14200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/06f581f0-bb0d-11e5-938d-0187c51d8787.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "10edb150-bb0d-11e5-b12b-718ba4f235df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch @ Au Cheval for 2 + Uber</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Escape during the work day to a neighborhood favorite, Au Cheval. Spend up to $50 on lunch + Uber to and from the restaurant. See Libby to make a reservation.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/49177070-bb0d-11e5-938d-0187c51d8787.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "584fc560-bb0d-11e5-b12b-718ba4f235df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Spa Certificate</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Sit back, relax and pamper yourself with a spa service up to a $50 value of your choice at your favorite salon. See Libby to schedule and purchase your services</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e6d060d0-e3b1-11e4-8b37-95bd8380dfc5.jpg\"  /></div></a>",
    "hgId" : "7e18a290-bb11-11e5-b12b-718ba4f235df",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cooking Class @ Whole Foods For 2</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Invite a friend and take a cooking class at Whole Foods in Lincoln Park. There are a wide variety of options for all cooking levels, no matter what kind of food lifestyle you live. Up to total value of $60. See Libby to make your reservation today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/d65745b0-bb11-11e5-8f51-bde3cd07380f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e38524a0-bb11-11e5-b12b-718ba4f235df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Gym Membership Credit</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">New Years Resolutions are here, so use this $50 credit towards the gym membership of your choice to ensure you hit your fitness goals in 2016. See Libby to receive your credit today!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/1ddbaed0-bb12-11e5-9877-11997d223a92.jpg\"  /></div></a>",
    "hgId" : "251c8660-bb12-11e5-ae3a-a940b8ab612d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Volunteer For A 1/2 Day With a Coworker</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Grab a coworker and volunteer for a 1/2 day at the organization of your choice. With busy lives, it can be hard to find time to volunteer, so why not do it during work hours! The benefits of volunteering are enormous to you, your family, and your community, so use this as a way to find an organization to give back to. See Libby to plan your 1/2 day of volunteering.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/ee757a30-bb12-11e5-a4f0-1f0e7eee148c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0dcbc920-bb13-11e5-b12b-718ba4f235df"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Chicago Food Planet Food Tour</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Escape with a coworker to play tourist for half a day by taking a Chicago Food Planet Food Tour. The Food Tasting and Cultural Walking Tours include tasty food and drink tastings with some serious fun in Chicago’s most delicious, off-the-beaten-path neighborhoods. You’ll experience delectable foods from one-of-a-kind specialty food stores, famous local restaurants and ethnic eateries while receiving an insiders view into the culture, history and architecture that defines the Windy City. Walk away with new culinary perspectives, big smiles, satisfied taste buds and the confidence to continue exploring new areas. See Libby to schedule yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>9000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/6ce38150-bb13-11e5-a3cd-e77e055e816e.jpg\"  /></div></a>",
    "hgId" : "735e22b0-bb13-11e5-a171-25bee9dc3f4f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Goat Tote</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Have a lot of stuff to carry? Tote your groceries, gym shoes or hot sauce collection in this stylish goat tote. See Libby to claim yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/c8f29da0-c811-11e4-b241-b90269b1ac83.jpg\"  /></div></a>",
    "hgId" : "86384490-bb15-11e5-b12b-718ba4f235df",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Indoor Golf @ Fairways for 2</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Are the bitter cold Chicago winters making you wish spring were here so you could be out on the links? Visit Fairways in Lincoln Park where golf meets gastropub in this unique, rustic chic bilevel restaurant and bar, and upstairs indoor golf club. Good for up to $60 of food and drink.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/5318b170-bb16-11e5-938d-0187c51d8787.jpg\"  /></div></a>",
    "hgId" : "57135eb0-bb16-11e5-ae3a-a940b8ab612d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Use Vip's Office For A Day</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Want to see what it's like to sit in the corner office? Or just want a quiet place to escape for a day? If so, then use this gift to swap desks with Vip for a day. See Libby to make arrangements!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/cefae820-bb17-11e5-a4f0-1f0e7eee148c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d4d4b5a0-bb17-11e5-a171-25bee9dc3f4f"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2 Hour Stress Free Lunch!</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Take a bit of extra time for lunch!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/cdac47f0-bf10-11e5-8ef9-e98777b591dd.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d1e42540-bf10-11e5-9373-03cb7805dd38"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Corner Office</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Exchange offices/cubes with your manager!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>750</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/126eaae0-bf11-11e5-9ee9-61d700e7d98e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "1f92c5d0-bf11-11e5-9373-03cb7805dd38"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Manager Brings you Coffee</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Have your manager bring you coffee!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/4cc8b780-bf11-11e5-9b3e-bbaef488364b.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5b74aaf0-bf11-11e5-873a-674a60354a31"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Meeting on the Move</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Hold a Team Meeting Outside or On the Go!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/b3133d80-bf11-11e5-8111-eb28362e6435.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "baad7fb0-bf11-11e5-9373-03cb7805dd38"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch and Learn!</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Select a peer or select TED talks to play during a lunch and learn session with your team!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/0297d690-bf12-11e5-8111-eb28362e6435.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "082cabd0-bf12-11e5-9373-03cb7805dd38"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift Card of Your Choosing - $10</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select from the catalog within the gift card store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/4e524840-bf12-11e5-a67b-bf41110a1508.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "55cbe310-bf12-11e5-b40b-5f5919a90e39"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift Card of Your Choosing - $25</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select from the catalog within the gift card store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/688cc280-bf12-11e5-bd3c-a959d6eed5f6.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6e22a930-bf12-11e5-873a-674a60354a31"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift Card of Your Choosing - $50</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select from the catalog within the gift card store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/893274d0-bf12-11e5-854d-99f7596fa0e2.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8b5fb510-bf12-11e5-873a-674a60354a31"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift Card of Your Choosing - $75</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select from the catalog within the gift card store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>750</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/a0e1b050-bf12-11e5-8ef9-e98777b591dd.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "a3443160-bf12-11e5-9373-03cb7805dd38"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>DQ NB Contest SAMPLE USER 1</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Point System\nNBA’s\nRe-activated LTL account – 2 points\nRe-activated TL/IMDL/Partial account – 5 points\nLTL NBA – 3 points\nTL/IMDL/Partial NBA – 7 points\n\nGP $\nNew account with at least $500 in GP/month – 10 points\nNew account with at least $1000 in GP/month – 20 points\n \nMinimum Requirements for accounts to be eligible for points – (I can manage this so that these minimums are met)\nRe-activated Account hasn’t shipped with Echo in the past 6 months\nLTL min = $50 or 26%, whichever is larger\nPartial min = $150 or 10%, whichever is larger\nTL min = $100 or 11%, whichever is larger\nIMDL min = $200 or 10%, whichever is larger\n \nRequirements to be eligible for award – (I can manage this so the minimums are met)\nRep must re-activate or close at least $1000 GP in new business for the month they won to be eligible for monthly award\nRep must re-activate or close at least $2000 GP in new business overall (Feb & March) to eligible for overall award\n \nMonthly Winner\nMost Points for February wins $250 in Gift Cards\nMost Points in March wins $250 in Gift Cards\n \nOverall winner\nMost points overall wins $250 in Gift Cards</div><div class=\"is-bottom-padded product-item-label\">This item's funding goal is <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it expires!</div><img src=\"//stcdn5.highground.com/product/24/2ac39990-c522-11e5-8ecc-13db6199ca74.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>CAMPAIGN</strong> is available in the store!</div>"
},
    "hgId" : "3d871110-c522-11e5-82a4-5932698ffef4"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>DQ NB Contest SAMPLE USER2</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Point System\nNBA’s\nRe-activated LTL account – 2 points\nRe-activated TL/IMDL/Partial account – 5 points\nLTL NBA – 3 points\nTL/IMDL/Partial NBA – 7 points\n\nGP $\nNew account with at least $500 in GP/month – 10 points\nNew account with at least $1000 in GP/month – 20 points\n \nMinimum Requirements for accounts to be eligible for points – (I can manage this so that these minimums are met)\nRe-activated Account hasn’t shipped with Echo in the past 6 months\nLTL min = $50 or 26%, whichever is larger\nPartial min = $150 or 10%, whichever is larger\nTL min = $100 or 11%, whichever is larger\nIMDL min = $200 or 10%, whichever is larger\n \nRequirements to be eligible for award – (I can manage this so the minimums are met)\nRep must re-activate or close at least $1000 GP in new business for the month they won to be eligible for monthly award\nRep must re-activate or close at least $2000 GP in new business overall (Feb & March) to eligible for overall award\n \nMonthly Winner\nMost Points for February wins $250 in Gift Cards\nMost Points in March wins $250 in Gift Cards\n \nOverall winner\nMost points overall wins $250 in Gift Cards</div><div class=\"is-bottom-padded product-item-label\">This item's funding goal is <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it expires!</div><img src=\"//stcdn5.highground.com/product/24/4f0fbea0-c522-11e5-aca7-9f075ac50d65.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>CAMPAIGN</strong> is available in the store!</div>"
},
    "hgId" : "5b5f99a0-c522-11e5-a71f-1f4f9d67709a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>\"Talk Time On Us\"</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Have Burns pay your monthly cell phone bill, up to $100.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/b9af88a0-c55c-11e5-80db-776ab5829fda.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c1d960a0-c55c-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Breakfast Or Lunch With Matt Burns</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Employee gets pick of either breakfast or lunch with Matt Burns</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/e4455400-c55c-11e5-891c-39bb0b6c7716.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "eb46b190-c55c-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Burns Polo Shirt</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Employee can obtain an additional Burns polo shirt from HR.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>20</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/05f60db0-c55d-11e5-aca7-9f075ac50d65.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "091e4fc0-c55d-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Drive a Stock Car</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Are you ready for the driving experience of a lifetime? Take the wheel and hit top speeds.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>600</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/535025a0-c55d-11e5-a9a6-a3692d16057e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "629c50b0-c55d-11e5-a516-cb2be81b31e5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Food Tour For Two</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Indulge in food, history, culture and fun with the Best of City Food Tours!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/7b2e4b10-c55d-11e5-9fd3-35acdbc0fd90.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "86578060-c55d-11e5-a516-cb2be81b31e5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Golf Lesson With A PGA Pro</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Improve career best rounds and overall golf games with golf lessons from a PGA Professional.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>130</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/c58a8c50-c55d-11e5-b77f-39bdd28ab206.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "cdff7710-c55d-11e5-a516-cb2be81b31e5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Happy Hour With John Burns</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Employee gets to host a happy hour with John Burns and five friends</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>150</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/f5e7fcc0-c55d-11e5-aca7-9f075ac50d65.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "fdaafca0-c55d-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Helicopter Experience</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Learn how to fly a helicopter for the day</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/102b9ec0-c55e-11e5-b77f-39bdd28ab206.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "21728860-c55e-11e5-a516-cb2be81b31e5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Hot Air Ballon Ride For Two</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Hot air ballon ride for two (available in Philadelphia, D.C., NYC, LA, Denver, Dallas, and Orlando)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/366785e0-c55e-11e5-96c9-e3608a4272d6.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "3f4dd010-c55e-11e5-b9d0-23c2985b3306"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Ice Cream Social For You And 10 Teammates</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Ice cream sundae bar in the office for the employee and 5 teammates</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/5c0928d0-c55e-11e5-9fd3-35acdbc0fd90.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "630e2fe0-c55e-11e5-b9d0-23c2985b3306"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Learn How To Fly!</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Introductory flight lesson, a dream come true for anyone who's ever dreamed of flying</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/7312d580-c55e-11e5-afe0-853879a72e4f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7b0263a0-c55e-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Personal Chef For The Evening</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Host a party in the comfort of your own home without lifting a finger.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/920c5e70-c55e-11e5-9305-2fc4cb0fd17d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "98c54150-c55e-11e5-b9d0-23c2985b3306"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Pizza Party For You And 5 Teammates</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Pizza party during lunch in the office for employee and five teammates of their choosing.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/d8352f30-c55e-11e5-891c-39bb0b6c7716.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "ec3ce680-c55e-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Round Of Golf With A PGA Pro</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Spend a round playing with a Pro and learn the skills to help you score better and get more enjoyment out of golf!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/17775650-c55f-11e5-aca7-9f075ac50d65.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "221e3c40-c55f-11e5-a516-cb2be81b31e5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Sceanic Dining Cruise</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Enjoy a dining cruise experiencee for you and a guest through a metropolitan area of your choice</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/31259620-c55f-11e5-891c-39bb0b6c7716.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "3fdcd430-c55f-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take A Half Day Friday</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Four (4) offered per calendar year, employee can take a paid half day on a Friday of their choosing and manager approval.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/7415d120-c55f-11e5-891c-39bb0b6c7716.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "876498b0-c55f-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take The Day Off</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Two (2) offered per calendar year, employee can take an entire paid day off of their choosing and manager approval.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>600</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/d7210aa0-c55f-11e5-80db-776ab5829fda.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "e70704b0-c55f-11e5-a516-cb2be81b31e5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Tandem Skydiving</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Experience the thrill of sky diving!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/ef3374c0-c55f-11e5-9305-2fc4cb0fd17d.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f2df17a0-c55f-11e5-bf0f-a95410d10f1a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Pamper Yourself</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">As Aaron Rodgers would say...Relax.  Go treat yourself to a Manicure or Pedicure and expense the heck out of it.\n\n*Up to a $30 Value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>120</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/988521d0-d024-11e5-b76a-fd87d4a5a31a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d56bd750-d025-11e5-9ca8-0d5864b4e01a"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Plush Goat</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">We scoured the internet to offer the cutest stuffed goat mankind has been able to produce. Be warned: this cuddly version of Gus is in limited supply.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/0db2e930-fe29-11e3-8462-1fef1dc3f7dc.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "437225b0-d030-11e5-a13b-75173eeca0e6"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take Me to Your Leader</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Not only will you enjoy some quality time with our CEO, Jonathan Reynolds, but he will even buy you lunch!  These are limited, so snatch one up while you still can!  \n\n*Up to a $20 Value for the meal\n*Time with Jonathan = Priceless</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/a139b9a0-7f0f-11e5-b59f-1d967036e7ee.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "d47bef40-3478-11e5-bef0-49fe4b246183"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Suggest a Snack</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Don't keep it a secret any longer....let us know what your favorite snack or drink is so we can share it with the entire office! See Libby to put in your snack request.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/ce8b7540-50ef-11e5-9dba-717473d60d4a.jpg\"  /></div></a>",
    "hgId" : "13eba450-d0e0-11e5-b190-e355d06541bb",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Half Day!</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Kick your feet up and enjoy a half day of work</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/a1f39a70-bf9f-11e5-8111-eb28362e6435.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "a438a870-bf9f-11e5-a2ca-dfaeaf704a7b"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Send A Singing Telegram To A Co-Worker Of Your Choice</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Employee may send a singing telegram to a teammate with an encouraging message of their choice (reviewed and ordered by HR).</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/4a6f47c0-c55f-11e5-891c-39bb0b6c7716.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5daa3930-c55f-11e5-b9d0-23c2985b3306"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>iPad</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">You know you want it.  iDo.  \n\n*Up to a $500 Value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/50/86b92290-d46a-11e5-ab42-b3518ca7a86a.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "c508d360-d46a-11e5-87f6-213970290475"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Folding Stand-Up Desk</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">This folding (yes, literally folding) stand-up desk for your laptop is made in the USA, ergonomic, recyclable (if you decide you don't like it I guess) and easy to use. Check it out here (https://oristand.co/product/oristand/) and see Libby to claim yours today!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/ce7f2940-d0e0-11e5-a36e-0177dedf07f7.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "f6ae7bf0-d0e0-11e5-b9bc-7bc7635ded20"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>LinkedIn Recommendation</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">You've done the work and earned the points.  Now cash in to have your supervisor type you up a recommendation on LinkedIn!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/55/802f5420-dfdd-11e5-9924-77b187375237.jpg\"  /></div></a>",
    "hgId" : "9015ea70-dfdd-11e5-9c03-73c1dff36076",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cold Run for Warm Meals Registration</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Saturday March 26\n9:30 - 11:30\nThe National AgriMarketing Association Iowa Chapter is proud to introduce the Cold Run for Warm Meals, a 2.5 mile run or walk benefitting WesleyLife Meals on Wheels. Food insecurity is a challenge that affects an incredible amount of Iowans – over 83,000 seniors in Iowa are threatened by hunger. We ask that you join us to stand against hunger in Iowa by participating in the Cold Run for Warm Meals. Register today! \n\n*Source: Meals on Wheels Assocation of America, February 2015. (Latest available data.)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/1eb38ea0-d1c3-11e5-9c15-e768e1fc9945.jpg\"  /></div></a>",
    "hgId" : "cb745ab0-e17d-11e5-b691-fd84ee2fa9c5",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($50)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Redeem for credits to purchase a giftcard of your choosing!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>50</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/505a3090-e5fe-11e5-acdb-59d189d02c0b.jpg\"  /></div></a>",
    "hgId" : "58b551c0-e5fe-11e5-a063-3df389450ac7",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($25)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Purchase to redeem for a gift card of your choosing in the giftcard store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/6af2f770-e5fe-11e5-80a3-c3f8fcaad42c.jpg\"  /></div></a>",
    "hgId" : "7bb288a0-e5fe-11e5-9ff3-f13ca88c68d1",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($75)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select this card for credits to redeem for gift cards of your choosing!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>75</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/602a9f90-e6ea-11e5-aa15-517d3bfff4eb.jpg\"  /></div></a>",
    "hgId" : "69484d70-e6ea-11e5-8b0e-1b343427a882",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($100)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select this reward to receive credits to redeem in the gift card store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/a90a2be0-e6ea-11e5-9bac-8f76fa1bd7d1.jpg\"  /></div></a>",
    "hgId" : "b0ebd750-e6ea-11e5-b437-0778436f0071",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($15)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select this reward to receive credits to redeem for a gift card of your choosing</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>15</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/eb33bb80-e6ea-11e5-8093-b3dcd21754d6.jpg\"  /></div></a>",
    "hgId" : "f20ef370-e6ea-11e5-8b0e-1b343427a882",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Habitat Hustle 5k</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Sunday, April 10th 9AM\nCome race, run, or walk a 5K in support of affordable housing with Habitat for Humanity of Metro Denver!\nHabitat for Humanity of Metro Denver's Youth United program engages youth ages 14 - 18 with Habitat’s mission of building decent, affordable homes in partnership with low income families. Youth United also empowers high school students to raise the funds needed to sponsor and build a Habitat for Humanity house.\nYouth United will be partnering with 4 families this year to help build 4 homes in Montbello. One of these homes will be purchased by Moulay and Sana, hard-working parents with 2 daughters who currently live in a crowded one-bedroom apartment with pests, mice, and mold which has contributed to serious health issues for their children. They are looking forward to living in a safe, spacious, healthy environment in which their children can grow and develop.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/d49caf40-e7c5-11e5-a957-755d74e908f3.jpg\"  /></div></a>",
    "hgId" : "fe6fedf0-e7c5-11e5-ba21-b1b10ab6a8d8",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Microsoft Band 2 (small) Activity Tracker</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Continuous heart rate monitor tracks heart rate, calorie burn, and sleep quality\nTracking for running, biking, golf, and more\nEmail, text, calendar, and call alerts on the go\n11 sensors, including GPS, UV monitor, and barometer\nFull-color curved display\nWorks with Windows Phone, Android, and iPhone2</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/eef25890-eab8-11e5-ba9c-af1386140204.jpg\"  /></div></a>",
    "hgId" : "8c3067a0-eab9-11e5-8c2e-ada2c1747797",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Microsoft Band 2 (medium) Activity Tracker</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Continuous heart rate monitor tracks heart rate, calorie burn, and sleep quality\nTracking for running, biking, golf, and more\nEmail, text, calendar, and call alerts on the go\n11 sensors, including GPS, UV monitor, and barometer\nFull-color curved display\nWorks with Windows Phone, Android, and iPhone2</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/aa49c9c0-eab9-11e5-ba9c-af1386140204.jpg\"  /></div></a>",
    "hgId" : "c0f8ac40-eab9-11e5-92ce-4374139b2d81",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Microsoft Band 2 (large) Activity Tracker</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Continuous heart rate monitor tracks heart rate, calorie burn, and sleep quality\nTracking for running, biking, golf, and more\nEmail, text, calendar, and call alerts on the go\n11 sensors, including GPS, UV monitor, and barometer\nFull-color curved display\nWorks with Windows Phone, Android, and iPhone2</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/c98c4290-eab9-11e5-b9f3-75580a44fab7.jpg\"  /></div></a>",
    "hgId" : "db3e9830-eab9-11e5-946b-f94d55a58d13",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cold Run for Warm Meals Registration</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Saturday March 26\n9:30 - 11:30\nThe National AgriMarketing Association Iowa Chapter is proud to introduce the Cold Run for Warm Meals, a 2.5 mile run or walk benefitting WesleyLife Meals on Wheels. Food insecurity is a challenge that affects an incredible amount of Iowans – over 83,000 seniors in Iowa are threatened by hunger. We ask that you join us to stand against hunger in Iowa by participating in the Cold Run for Warm Meals. Register today! \n\n*Source: Meals on Wheels Assocation of America, February 2015. (Latest available data.)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/1eb38ea0-d1c3-11e5-9c15-e768e1fc9945.jpg\"  /></div></a>",
    "hgId" : "8d2e8ed0-ef7c-11e5-8bb1-5d63be69e6c8",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Charitable Contribution To The Philanthropy Committee</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Allows employee to make a contribution of their choosen amount to the Philanthropy Committee's fundraising efforts.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/a5778520-f033-11e5-b241-f715eb32dec3.jpg\"  /></div></a>",
    "hgId" : "aec2f9c0-f033-11e5-85d0-db66bd728503",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Burns Polo Shirt</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Employee can obtain an additional Burns polo shirt from HR.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>20</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/46/e2c0c270-f033-11e5-ba06-d91c0b4c2d14.jpg\"  /></div></a>",
    "hgId" : "e98bcdc0-f033-11e5-85d0-db66bd728503",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>6 Month Birchbox Subscription</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Birchbox is a monthly beauty subscription service for both men and women. You get a monthly shipment of beauty products for just $10 a month! Your customized Birchbox ships free every month, and you can earn back half the value of your box by reviewing all five of your samples. See Libby to redeem your gift today!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/4de0f4e0-f10f-11e5-b519-3b9ef9ed9030.jpg\"  /></div></a>",
    "hgId" : "66936f90-f10f-11e5-8d9d-11db6c6bbcd1",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>test</strong> was recently added to the store!</h4><div class=\"mar-bot10\">test</div><div class=\"mar-bot10 product-item-label\">This item's funding goal is <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it expires!</div><img src=\"//stcdn5.highground.com/product/52/b86234d0-f111-11e5-8865-9346515be4d3.jpg\"  /></div></a>",
    "hgId" : "0bfaa870-f112-11e5-a795-8d3b98165aac",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>CAMPAIGN</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Ask Me About My Goat Flip Up Tee</strong> was recently added to the store!</h4><div class=\"mar-bot10\">This is one-of-a-kind, flip-up tee is sure to bring some laughs when someone asks you, \"about your goat.\" See Libby to claim yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/6ab2bf00-f113-11e5-a75d-5f6ebf5c1469.jpg\"  /></div></a>",
    "hgId" : "c302c740-f113-11e5-a795-8d3b98165aac",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2 Cubs or Sox Tickets</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Baseball season is upon us! Attend a Cubs or Sox game of your choice with a friend or family member. Up to a $75 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e37d0c90-e3b0-11e4-b456-79e6926989d5.jpg\"  /></div></a>",
    "hgId" : "7b75dd30-f114-11e5-9e8a-172ac5258d73",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Annual Divvy Bike Membership</strong> was recently added to the store!</h4><div class=\"mar-bot10\">What better way to get ready for spring than to get an annual Divvy bike membership! Divvy is a bike sharing system featuring thousands of bikes at hundreds of stations from Andersonville to Hyde Park, available 24/7, 365 days a year. Each station has a touchscreen kiosk, station map, and a docking system that releases bikes using a member key or ride code. See Libby to claim yours today!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/4691d890-f127-11e5-9ff4-e5c445a1045e.jpg\"  /></div></a>",
    "hgId" : "17b39dd0-f116-11e5-9cec-3fc20d809b0d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Baby Goat Canvas Lunch Bag</strong> was recently added to the store!</h4><div class=\"mar-bot10\">This roll to close with secure velcro - Phthalate, BPA, Lead-Free and Machine Washable lunch bag is great for you to bring your lunch to work in. See Libby to claim yours today!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/bebe7490-f118-11e5-96ed-e35f577566fc.jpg\"  /></div></a>",
    "hgId" : "d6b5b590-f118-11e5-9e8a-172ac5258d73",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Belle Chevre Goat Cheese Gift Box</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Get the Belle Chevre breakfast sampler, with a trio of Effie's tea biscuits made from quality ingredients that we all know and love. Their crisp texture, hint of buttery sweetness and a slightly salty finish make them a perfect treat any time of day. They come with three of Belle Chevre's breakfast cheeses, creamy chevres mixed with fig, honey, and coffee. A sweet treat for any palate.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4800</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/ca1653a0-f11b-11e5-b665-d36f6766bc22.jpg\"  /></div></a>",
    "hgId" : "de290770-f11b-11e5-8d9d-11db6c6bbcd1",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 StubHub Certificate</strong> was recently added to the store!</h4><div class=\"mar-bot10\">There are some great concerts coming to Chicago this summer.......Adele, Coldplay, Rihanna, Beyonce and Billy Joel, just to name a few. Use this certificate towards your ticket purchase!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/24fc20f0-f127-11e5-9fa2-ad8895ae058f.jpg\"  /></div></a>",
    "hgId" : "c592c650-f126-11e5-a42b-0fd6d7fe37d8",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Special Olympics 5k</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Saturday, April 23rd 8 AM\nWhether you’re running for fun or running towards a goal, everyone who participates in the Iowa Law Enforcement 5k event is running for a dream – the dream of a Special Olympics Iowa (SOIA) athlete.  This is a great opportunity for individuals and organizations to raise money and support SOIA athletes.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/7703d970-e7c6-11e5-b7e2-e31acf3ab65c.jpg\"  /></div></a>",
    "hgId" : "6699fc40-f130-11e5-a42b-0fd6d7fe37d8",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch for 2 @ Portillo's</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Take a stroll over to Portillo's with a coworker and have lunch on HighGround. Up to a $30 value.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/8adac5c0-f127-11e5-a7c5-f7000a5a2999.jpg\"  /></div></a>",
    "hgId" : "83fa2280-f11a-11e5-a795-8d3b98165aac",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Your Brain At Work by David Rock</strong> was recently added to the store!</h4><div class=\"mar-bot10\">We recently partnered with the NeuroLeadership Institute which was started by David Rock. David Rock coined the term ‘Neuroleadership’ and is the Director of the NeuroLeadership Institute, a global initiative bringing neuroscientists and leadership experts together to build a new science for leadership development. We will be incorporating some of his philosophies into our product so this book can provide great insight into his research.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1700</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/28e328b0-f133-11e5-9fa2-ad8895ae058f.jpg\"  /></div></a>",
    "hgId" : "547ea440-f133-11e5-8d9d-11db6c6bbcd1",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Round of Golf @ Harborside</strong> was recently added to the store!</h4><div class=\"mar-bot10\">The snow has melted and the courses are getting greener, so it is time to play a round of golf! Enjoy a round of golf at Harborside on HighGround up to a $60 value. See Libby to schedule your tee time today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/0580d910-f1d0-11e5-8ad0-d1e4aac9d3ca.jpg\"  /></div></a>",
    "hgId" : "359d9700-f1d0-11e5-9f09-cbcf7f9f1908",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Test</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Test</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/6ec12a00-f1d1-11e5-9821-dd8733f78d2f.jpg\"  /></div></a>",
    "hgId" : "7d61d2d0-f1d1-11e5-beb3-6d57aab17272",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>We All Goats To Recycle Coffee Mug</strong> was recently added to the store!</h4><div class=\"mar-bot10\">In honor of April being Earth Month, gift a We All Goats To Recycle Mug. See Libby to claim yours today.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/54d61600-f1d6-11e5-b22a-db35f7ce5928.jpg\"  /></div></a>",
    "hgId" : "97674110-f1d6-11e5-aac9-ef7318a4a75b",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$10 Gift Card of your Choice!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Spend it where you like.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>750</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/63d34530-ba48-11e5-884d-1f3263855c35.jpg\"  /></div></a>",
    "hgId" : "6b09e730-f1f9-11e5-9e75-d572eed679e9",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$25 Giftcard of your choosing</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Redeem for a $25 gift card of your choosing!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1875</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/ec774800-ba48-11e5-af4c-31a0520f8e17.jpg\"  /></div></a>",
    "hgId" : "7070cea0-f1f9-11e5-bfef-69f3c87b8e0a",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Gift Card of your Choice</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Spend it where you like.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3750</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/65/07a8f380-ba49-11e5-af4c-31a0520f8e17.jpg\"  /></div></a>",
    "hgId" : "74a3f100-f1f9-11e5-9f09-cbcf7f9f1908",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Safari Books Subscription</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Free, unlimited access to the maker of all those smart books with animals on the front cover.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/d5e9e020-75a7-11e4-b0dc-b15adea963e3.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "51520390-e430-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Manager of Your Choice Wears a Costume</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">We have the banana suit on reserve but you can choose another costume, if you'd like.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/0b98ad00-fe2f-11e3-849b-378408f25c4f.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "574bb520-e430-11e4-b091-9bfd307f9da5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Sip with Vip</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Get your Vipon. A 15 minute one-on-one from our fearless leader.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/9d41d820-b393-11e4-90f2-b9f758f08a27.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "5d3205c0-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Choose the Keg at Beer O'Clock</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Select your favorite beer to keep on tap for an upcoming beer o'clock!</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/783154e0-e3a7-11e4-bde5-75a03228c253.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6357a950-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Design Your Own Coffee Mug or Pint Glass</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Coffee is for closers. Prove it.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/c65db0f0-e3a7-11e4-98aa-5b668397409e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "635eae30-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>An Hour of Lies, Half Truths, and Storytelling with Moose</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Plus a delicious cupcake.  Executive development course for 1-1 coaching & career management, complete with political commentary, delicious pastry, style tips for the portly male, and moral turpitude (okay maybe leave off that last one).</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/506c8a40-5551-11e4-88a4-4f9e73775174.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "691f4e60-e430-11e4-b533-392b3fb92bf5"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>HighGround Slippers</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">Branded slippers to wear at your leisure.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e0b80c60-ac8a-11e4-821c-312767ed59c4.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "6f094880-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Raspberry Pi 3 Model B</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Get your creative juices flowing with this gadget!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/57894200-b1a9-11e4-b3f2-c71e1f30c30e.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7506f1b0-e430-11e4-94a0-837ea5770e04"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Standing Desk</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">For those who want to stay healthy and motivated while standing up.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>25000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/69afe590-a62a-11e4-9ead-8d54b3bd372c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7b236d80-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Uber to Work and Back for the Week</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Ride in luxury for the week with your very own driver. Note: maximum benefit is $150.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>15000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/404c78f0-c806-11e4-8f86-773e41d5d769.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "7b27b340-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fitbit Flex</strong> was recently added to the store!</h4><div class=\"clearfix is-bottom-padded\">What's the best way to avoid laziness? Personal trainer? Self-discipline? NOPE--think again, Grandpa. It's an electronic wrist thing that tracks your activity. And then some. Welcome to a new world of health-filled competition with your friends and, of course, the greatest opponent of all: yourself.</div><div class=\"clearfix is-bottom-padded product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn4.highground.com/product/1/e1cdbda0-e3aa-11e4-80bc-6d91a5578a59.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "81113830-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Goat Clothes</strong> was recently added to the store!</h4><div class=\"is-bottom-padded\">Pick attire under $25 for your plush goat to rock. #nonakedgoats</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/f5cf0920-e3a6-11e4-bb38-f541f8383ccf.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "8111fb80-e430-11e4-9e57-a1d2bdcc2bbf"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2 Tickets to Dan Drees Stand Up Comedy Show</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Check out our very own, Dan Drees, as he hits the stage at a Stand Up Comedy Show. He performs about 3 times per month so the dates vary. This is good for 2 tickets to the show @ Lincoln Lodge.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/275d09a0-bb98-11e5-bc4f-87d35d3a174c.jpg\"  /></div></a>",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
},
    "hgId" : "0cce1a20-bb11-11e5-ae3a-a940b8ab612d"
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cold Run for Warm Meals Registration</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Saturday March 26\n9:30 - 11:30\nThe National AgriMarketing Association Iowa Chapter is proud to introduce the Cold Run for Warm Meals, a 2.5 mile run or walk benefitting WesleyLife Meals on Wheels. Food insecurity is a challenge that affects an incredible amount of Iowans – over 83,000 seniors in Iowa are threatened by hunger. We ask that you join us to stand against hunger in Iowa by participating in the Cold Run for Warm Meals. Register today! \n\n*Source: Meals on Wheels Assocation of America, February 2015. (Latest available data.)</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>300</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/1eb38ea0-d1c3-11e5-9c15-e768e1fc9945.jpg\"  /></div></a>",
    "hgId" : "01dea880-d1c5-11e5-9b95-693e2c415d41",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Plush Goat</strong> was recently added to the store!</h4><div class=\"mar-bot10\">We scoured the internet to offer the cutest stuffed goat mankind has been able to produce. Be warned: this cuddly version of Gus is in limited supply.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/0db2e930-fe29-11e3-8462-1fef1dc3f7dc.jpg\"  /></div></a>",
    "hgId" : "f4e2b6d0-f5e6-11e5-acae-9dbdc2169066",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Special Olympics 10k</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Saturday, April 23rd 8 AM\nWhether you’re running for fun or running towards a goal, everyone who participates in the Iowa Law Enforcement 10k event is running for a dream – the dream of a Special Olympics Iowa (SOIA) athlete.  This is a great opportunity for individuals and organizations to raise money and support SOIA athletes.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/7519bca0-f730-11e5-9c25-ad6f717a293f.jpg\"  /></div></a>",
    "hgId" : "9eefe180-f730-11e5-9b2a-a7da7633f1c9",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch/Dinner on Struck</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Lunch/ Dinner up to $15.00! \nSubmit receipt through workamajig.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>150</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/19/09545fd0-32c8-11e4-9559-e9b2bc08c822.jpg\"  /></div></a>",
    "hgId" : "ec256ff0-f77c-11e5-9b2a-a7da7633f1c9",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Colfax 5k</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Kick off Denver’s Colfax Marathon weekend in City Park with the Bellco Colfax 5K! Go for a PR in this chip-timed race – separate stroller-friendly start wave for families and walkers with a 1.8 mile shortcut for kids. Run in the Dog Wave and get your dog a race bandana! Your chance to be a part of marathon weekend – at a much shorter distance! The 5K starts in City Park and weaves its way around the park finishing in the same place as the Marathon.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>450</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/1cf68510-fb33-11e5-a570-f740757a154e.jpg\"  /></div></a>",
    "hgId" : "4a0f51d0-fb33-11e5-a6b7-2bccba96157f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Reusable Bag</strong> was recently added to the store!</h4><div class=\"mar-bot10\">In honor of April being Earth Month, this reusable bag will come in handy when you are at the Farmer's Market this summer, shopping, or can even be used as a gym bag. See Libby to claim your bag today!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1800</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/b2efe0a0-fb62-11e5-979d-c308b3578494.jpg\"  /></div></a>",
    "hgId" : "c697ebc0-fb62-11e5-a6b7-2bccba96157f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fleet Feet Gift Card $100</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Fleet Feet Sports. Retail chain stocking athletic shoes, apparel & accessories geared toward runners.\nAddress: 521 E Locust St, Des Moines, IA 50309\nPhone:(515) 323-3338</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/c982a090-fccb-11e5-9503-0d6f66bc52dd.jpg\"  /></div></a>",
    "hgId" : "dfdb25b0-fccb-11e5-b10b-fdc841107d0c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fleet Feet Gift Card $50</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Fleet Feet Sports.  Retail chain stocking athletic shoes, apparel & accessories geared toward runners.\nAddress: 521 E Locust St, Des Moines, IA 50309\nPhone:(515) 323-3338</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/f64250d0-fccb-11e5-9503-0d6f66bc52dd.jpg\"  /></div></a>",
    "hgId" : "0db34ad0-fccc-11e5-9b99-6fc01f8b3cca",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help Others, Save Lives, Make a Bigger Difference</strong> was recently added to the store!</h4><div class=\"mar-bot10\">6 months of monitoring service to give to someone you choose (current client or someone new) and VRI will donate $200 to a charity of their choosing in your name to help people Be Safe and Live Well.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/f929d8b0-00a2-11e6-9a22-1ddb91882077.jpg\"  /></div></a>",
    "hgId" : "27ff2280-00a3-11e6-8d5c-ab4316af1437",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help your Household!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Kroger Card.  2,625 Stores in 34 States.  The Kroger Co. spans many states with store formats that include grocery and multi-department stores, convenience stores and jewelry stores.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/685b1ef0-ce82-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "hgId" : "207f0b10-017f-11e6-a729-a1d332f291fb",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go See the Reds</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$200 Reds Gift Certificate for you to choose your game, your seats, your day! While poised to make his fourth consecutive Opening Day start when he pitches for the Reds Monday vs. the Pirates, ace Johnny Cueto could be beginning his final season in Cincinnati.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/815fa6b0-ce81-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "hgId" : "1d078df0-0237-11e6-ae1f-bf495fa14717",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go FAST with a Friend!!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">3 Lap Ride Along for 2 People - Experience real life racing thrills by riding as a passenger with a professional driver in a meticulously prepared 600 horse power Sprint Cup style NASCAR stock car.\n\nFull size, Sprint Cup stock cars that have been raced by the likes of Jimmie Johnson, Jeff Gordon, Carl Edwards and Dale JR. Race with a professional instructor and top speeds of 160 MPH!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/2a1c99f0-e36f-11e4-bde5-75a03228c253.jpg\"  /></div></a>",
    "hgId" : "4c3d2020-02fb-11e6-b6dc-5907bba4d6b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get VRI Gear</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 towards the purchase of VRI Gear from the VRI Store.\n\nGo to the VRI store link, write down what you want and send it to Kim in HR.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/7a532950-0021-11e6-bb17-732c7f3c82aa.jpg\"  /></div></a>",
    "hgId" : "abad3180-02fb-11e6-b6dc-5907bba4d6b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift Card of Your Choosing - $10</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Select from the catalog within the gift card store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/4e524840-bf12-11e5-a67b-bf41110a1508.jpg\"  /></div></a>",
    "hgId" : "3dd0a6e0-0591-11e6-9cb4-77c2ac0489b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get a FitBit Flex - Work toward your Health & Wellness Goals</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Track steps, distance, calories, active minutes, hourly activity and stationary time. Progress display, wireless syncing to smartphones or computer, water-resistant wristband with a 5-day battery life.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/0f7ff7c0-00ee-11e6-9b7d-d90b9a713b81.jpg\"  /></div></a>",
    "hgId" : "acad1380-05a7-11e6-a34c-77b4b6f32b4e",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help Others, Save Lives, Make a Difference</strong> was recently added to the store!</h4><div class=\"mar-bot10\">3 months of monitoring service to give to someone you choose (current client or someone new) and VRI will donate $100 to a charity of their choosing in your name to help people Be Safe and Live Well.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/846f84b0-cf03-11e4-ad46-db9ed259b01c.jpg\"  /></div></a>",
    "hgId" : "ae1d1e40-05a7-11e6-9cb4-77c2ac0489b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($100)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Gift card of your choosing ($100) You will receive a confirmation email to let you know when your order has been processed. Use the credits to redeem for a giftcard of your choosing in the store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/6e0a4630-0803-11e6-849e-c946369e037f.jpg\"  /></div></a>",
    "hgId" : "94bf2de0-0803-11e6-acfe-c76aaf78a621",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($500)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Gift card of your choosing ($100) You will receive a confirmation email to let you know when your order has been processed. Use the credits to redeem for a giftcard of your choosing in the store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/c1957360-0803-11e6-8687-93bda988ac7f.jpg\"  /></div></a>",
    "hgId" : "caa69e20-0803-11e6-a6bf-d36838b30f84",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Gift card of your choosing ($15)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Gift card of your choosing ($100) You will receive a confirmation email to let you know when your order has been processed. Use the credits to redeem for a giftcard of your choosing in the store!</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>150</h5></div><div class=\"clear\"></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/67/2add8c80-0805-11e6-b7cb-d56c9870a647.jpg\"  /></div></a>",
    "hgId" : "2ed0e6c0-0805-11e6-97ad-79fe3499dac4",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Special Olympics 5k</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Saturday, April 23rd 8 AM\nWhether you’re running for fun or running towards a goal, everyone who participates in the Iowa Law Enforcement 5k event is running for a dream – the dream of a Special Olympics Iowa (SOIA) athlete.  This is a great opportunity for individuals and organizations to raise money and support SOIA athletes.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/7703d970-e7c6-11e5-b7e2-e31acf3ab65c.jpg\"  /></div></a>",
    "hgId" : "991d7750-08a5-11e6-bac2-1550fbf5e5b5",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help Others, Save Lives, Make a Bigger Difference</strong> was recently added to the store!</h4><div class=\"mar-bot10\">6 months of monitoring service to give to someone you choose (current client or someone new) and VRI will donate $200 to a charity of their choosing in your name to help people Be Safe and Live Well.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/f929d8b0-00a2-11e6-9a22-1ddb91882077.jpg\"  /></div></a>",
    "hgId" : "dd866970-08c2-11e6-a6a1-a7b0b12c73ff",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get to the Point!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Cedar Point Good Any Day Ticket!!!  Visit any day the park is open during the 2016 season and enjoy all of the world-class rides and attractions including the tallest, fastest, longest dive coaster, Valravn!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/9f760740-02fe-11e6-9ebb-99ff2622c1ca.jpg\"  /></div></a>",
    "hgId" : "e8a8e800-08c2-11e6-9ae8-79ef5bcd5b92",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2016 Denver Heart & Stroke Walk</strong> was recently added to the store!</h4><div class=\"mar-bot10\">The 2016 Denver Heart & Stroke Walk\nSaturday, June 4th, 2016 - 5K or 1 Mile Option\nNEW 5k Competitive Run!\nFestival open 7:30am | Run Start 8:00am | Walk Start 8:30am</div><div class=\"product-item-label clearfix\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn5.highground.com/product/52/1921dc10-0afa-11e6-b466-77cb57711405.jpg\"/></div></a>",
    "hgId" : "39bfed40-0afa-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cheer the Dragons More!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Gift Certificate to the Dayton Dragons for you to pick your game, your seats, your FUN!  Dayton Dragons 2015 single-game tickets will go on sale to the general public on Wednesday, March 18 at 10:00 a.m. Tickets can be purchased at the Dragons Box Office located next to the main entry gates at Fifth Third Field, on-line at daytondragons.com, and at any Ticketmaster outlet.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/a76a1a80-db9b-11e4-bd88-a76b07dbcc0f.jpg\"  /></div></a>",
    "hgId" : "d326d870-0b01-11e6-b2ee-c52ee4d5369c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take Flight!!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Discover the thrill of flying when you Learn to Fly a Cessna 172 near Cincinnati!\n\nBegin with a meet and greet with your instructor followed by a pre-flight inspection of the aircraft. Learn the basic controls and how to properly maneuver the plane prior to flight.\n\nTogether you'll taxi to the runway and prepare for take-off. Once airborne, you'll do most of the flying during the approximately 45-minute flight.\n\nTake in spectacular views of the Cincinnatti skyline and surrounding countryside when you fly with an experienced FAA Certified Instructor on this Learn to Fly experience.\n\nClermont County Airport - Batavia, OH \nYear-Round: Monday through Saturday - 8:00 AM to 6:00 PM; Sundays - 11:00 AM to 6:00 PM</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/0f4bac40-e394-11e4-b995-67e0d22c24a1.jpg\"  /></div></a>",
    "hgId" : "d8035a30-0b01-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take a Leap of Faith!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Last year thousands of people of all ages and professions ventured forth into the world of sport parachuting. Many have since embraced it as their favorite sport. Some will go on to become professional competitors and instructors. Others simply found it is a terrific way to spend a weekend.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/08a97060-e36d-11e4-80bc-6d91a5578a59.jpg\"  /></div></a>",
    "hgId" : "e0a0db90-0b01-11e6-8cf9-b73eb280165c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Relax</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Massage Envy Spa gift card. Massage therapy can be a powerful ally in your wellness program.\n\nAt Massage Envy Spa, we work hard to make massage therapy available to everybody. That's why we provide therapeutic massages as late as 10 pm, seven days a week. It's why we offer over 1000 locations nationwide. It's why our massage services range from Swedish Massage and Sports Massage to Prenatal Massage and Geriatric Massage. It's also why our affordable massages and memberships are usually half of most day spa prices. Need more convincing? Get started with your first massage and feel for yourself.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/76068db0-cf03-11e4-9453-3f2657c1c301.jpg\"  /></div></a>",
    "hgId" : "ec35f210-0b01-11e6-8cf9-b73eb280165c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Play at Scene 75</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 Gift Certificate for Scene75.  Voted Best In Ohio and An International Award-Winning Entertainment Center!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/374a1150-cf03-11e4-923f-3ffd44e7238a.jpg\"  /></div></a>",
    "hgId" : "f2d44810-0b01-11e6-9400-d398a81eb7b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Shop or Dine at The Greene</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 gift card to the Greene for Dining or Shopping. The Greene offers visitors the ultimate shopping experience. You’re sure to find what you’re looking for among more than 75 top retailers who bring you outstanding brand names and stellar customer service.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/61ac2c50-ce70-11e4-91c2-1d7bcc577382.jpg\"  /></div></a>",
    "hgId" : "f7d36d00-0b01-11e6-8cf9-b73eb280165c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dream, Shadow, Lead</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Strength Finder Skills/Dreams Assessment and four 2-hour sessions Job Shadowing in a different department/job of interest; And attend a 2- to 4-hour workshop on leadership or skills development.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/15446e30-ce71-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "hgId" : "116e72f0-0b02-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Volunteer, Help Others, Saves Lives</strong> was recently added to the store!</h4><div class=\"mar-bot10\">1 Paid Day Off to Volunteer at a charity of your choice, and 3-months of free monitoring service to give to someone (current or new client) to help people Be Safe and Live Well.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/46530c90-ce79-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "hgId" : "145dcab0-0b02-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Help Others, Save Lives, Make a Difference</strong> was recently added to the store!</h4><div class=\"mar-bot10\">3 months of monitoring service to give to someone you choose (current client or someone new) and VRI will donate $100 to a charity of their choosing in your name to help people Be Safe and Live Well.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/846f84b0-cf03-11e4-ad46-db9ed259b01c.jpg\"  /></div></a>",
    "hgId" : "1b22bb80-0b02-11e6-8293-a31abcdc899d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cruise the River</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Enjoy a $100 RiverBoat Cruise Gift Card for dinner on the river. What's your perfect riverboat adventure? Maybe it's a romantic evening for two under the stars, or a leisurely Sunday brunch with the family. Perhaps you and your friends are looking to experience something tropical. https://www.bbriverboats.com/</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/a115ced0-cf03-11e4-9761-c5353cbb3d87.jpg\"  /></div></a>",
    "hgId" : "f1e55ec0-0b02-11e6-8cf9-b73eb280165c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Charity, Help Others, Save Lives</strong> was recently added to the store!</h4><div class=\"mar-bot10\">VRI will donate $200 to a charity of their choosing in their name and 3-months of free monitoring service to give to someone (current or new client) to help people Be Safe and Live Well.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/0e939610-ce7b-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "hgId" : "2258ef40-0b03-11e6-8293-a31abcdc899d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Be Fit! Live Well!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Annual Membership Gift Certificate for GAC Fitness in Springboro; G.A.C. Fitness is Springboro, Ohio's newest and cleanest fitness facility!!! Our state of the art facility offers Speed/Agility/Strength & Conditioning for athletes of all ages, personal training, group exercise room, small group training, smoothie bar, and locker rooms, complete with towel service. And while Mom and Dad are working out in our general fitness area of brand new, top of the line equipment you can rest assured your child will be safe and having fun in our kids care room.  Offering 30 classes that are free with membership.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/685ee7b0-ceff-11e4-9453-3f2657c1c301.jpg\"  /></div></a>",
    "hgId" : "270bc8f0-0b03-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Away!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Enjoy a Stay at a Marriott or Great Wolf Lodge for a value of up to $700.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/6a947480-ce7f-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "hgId" : "3f683460-0b03-11e6-8293-a31abcdc899d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Stay in the Woods and Take a Hike!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">A 3-Day/ 2-Night Cabin Package (Examples Vary): \n- Hocking Hills\n- Indian Lake\n- Put in Bay\n- Pigeon Forge\n- Gatlinburg\n\nUp to a $700 value</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/d0d27760-ce7f-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "hgId" : "4585c1a0-0b03-11e6-b2ee-c52ee4d5369c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go See the Reds</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$200 Reds Gift Certificate for you to choose your game, your seats, your day! While poised to make his fourth consecutive Opening Day start when he pitches for the Reds Monday vs. the Pirates, ace Johnny Cueto could be beginning his final season in Cincinnati.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/815fa6b0-ce81-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "hgId" : "4da58780-0b03-11e6-9400-d398a81eb7b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Be the King!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">2 Gold Season Passes to Kings Island. With a Gold Season Pass you'll enjoy unlimited visits all season long, free parking, early ride times on the record breaking Banshee, and much more!!!\n\nThese no longer are available for purchase after May 20. The park stops selling them around May 25.  We need the 5 days to buy them.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/516ae750-ce7a-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "hgId" : "522df5d0-0b03-11e6-8293-a31abcdc899d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$100 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"mar-bot10\">1000 credits to purchase a $100 gift card of your choice from the gift cards tab.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/db93c3b0-d8b2-11e4-98f4-7f3e7d34ef75.jpg\"  /></div></a>",
    "hgId" : "5793a4c0-0b03-11e6-b2ee-c52ee4d5369c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Gift Card of My Choice</strong> was recently added to the store!</h4><div class=\"mar-bot10\">500 credits to purchase a $50 gift card of your choice from the gift cards tab.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/bc09e1a0-d8b2-11e4-929f-4dd63b950082.jpg\"  /></div></a>",
    "hgId" : "5cae19e0-0b03-11e6-b2ee-c52ee4d5369c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go for the Green!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$500 Cash, Bills, Bones, Bread, Bucks, Cabbage, Cheddar, Clams, Coin, Cs, Dead Presidents, Dough, Stacks, Scratch, Shekels, Moola...you get the picture.   BTW, you can only choose cash once.  If you have selected it on a different level, your points will be returned.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>6000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/87b920f0-ce80-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "hgId" : "701dd6f0-0b03-11e6-8cf9-b73eb280165c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take in a Show...or 4 with a friend!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">2014-2015 DPAA New Horizon Season Flex Pass Subscription of 2 flex pass 4-packs to Dayton Opera, Ballet and Philharmonic. Flex passes allows the maximum flexibility. We will purchase a pack of vouchers that you can exchange for live tickets within 30 days of the performance date. Select from the best seats available at that time. The bigger the subscription package, the better the savings.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/ba619160-cf05-11e4-b05f-370aa8a168d9.jpg\"  /></div></a>",
    "hgId" : "76714140-0b03-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Play Hooky!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">3 EXTRA Days of PTO. A high school wise guy was determined to have a day off from school, despite what the principal thought of that. Well, this isn't High School - but our principal is OK with you earning 3 extras days of PTO!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/efbac240-ce7f-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "hgId" : "f385d2e0-0b03-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Carried Away!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">This gorgeous, relaxing sunrise or sunset hot air balloon flight in the beautiful Cincinnati/Dayton corridor lasts approximately 45-60 minutes. Please allow up to 3 hours for the complete experience with our crew including: a personalized pre-flight orientation, inflation, flight, landing, and post-flight celebration!!  You may be onboard with other passengers who have also made Non-Exclusive Flight reservations. Flights include complimentary Bella glass champagne flutes, local champagne from Valley Vineyards of Morrow, OH, or sparkling wine toast. Upgradable.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/0fabf1a0-ce80-11e4-8bfe-2355b87e8604.jpg\"  /></div></a>",
    "hgId" : "f3875980-0b03-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take Flight!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Two round trip plane tickets (up to $350 value each) for a total value of $700.00.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/a263dea0-ce7f-11e4-86d1-1b685b7543a5.jpg\"  /></div></a>",
    "hgId" : "17515640-0b04-11e6-9400-d398a81eb7b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get the Green!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$200 Cash, Bills, Bones, Bread, Bucks, Cabbage, Cheddar, Clams, Coin, Cs, Dead Presidents, Dough, Stacks, Scratch, Shekels, Moola...you get the picture.   BTW, you can only choose cash once.  If you have selected it on a different level, your points will be returned.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/af8ffac0-ce7d-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "hgId" : "1a96e450-0b04-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get More Gear!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$200 to spend in the VRI Store!!!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/5e9d9810-cf05-11e4-bfc6-eda0a18b0b3d.jpg\"  /></div></a>",
    "hgId" : "2e4be7c0-0b04-11e6-8cf9-b73eb280165c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make it a Date Night</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$300 gift certificate at Fleming's at The Greene or Jeff Ruby’s Steakhouse. High-end steakhouse chain with aged prime beef & classics such as lobster tails & pork chops.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/fc24bc50-ce7c-11e4-ab04-1da7a09463e2.jpg\"  /></div></a>",
    "hgId" : "3ad19fd0-0b04-11e6-9400-d398a81eb7b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Develop, Learn, Lead</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Attend a Full-day Leadership or Industry Conference, and Strength Finder Skills/Dreams Assessment and Receive Leadership Skills Development Pack.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/2ca880d0-ce7a-11e4-869e-d757aface84a.jpg\"  /></div></a>",
    "hgId" : "6a17d3e0-0b04-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go Play Together!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">2000 credits to purchase $200 of Family Entertainment Gift Cards of your choice from our Gift Cards tab. Choose from dinner out, places to go shop or play, or to go see a movie!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>2000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/160bbc30-ce79-11e4-9442-9bde736188c2.jpg\"  /></div></a>",
    "hgId" : "82a401e0-0b04-11e6-9400-d398a81eb7b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go to the Races</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Enjoy a $300 gift card for the luxury and excitement at Belterra Park. Enjoy the experience and all of the amenities that Belterra Park has to offer. Please note: Gift cards are not redeemable for cash or gaming purposes. https://www.belterrapark.com/</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/adb480d0-ce79-11e4-b1b5-bf10d414ef74.jpg\"  /></div></a>",
    "hgId" : "ebabac10-0b04-11e6-8293-a31abcdc899d",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Cheer the Dragons!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$50 Gift Certificate to the Dayton Dragons for you to pick your game, your seats, your FUN!  Dayton Dragons 2015 single-game tickets will go on sale to the general public on Wednesday, March 18 at 10:00 a.m. Tickets can be purchased at the Dragons Box Office located next to the main entry gates at Fifth Third Field, on-line at daytondragons.com, and at any Ticketmaster outlet.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/90dfda10-ce81-11e4-869e-d757aface84a.jpg\"  /></div></a>",
    "hgId" : "f3128230-0b04-11e6-895c-61adff67509f",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Get Food!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$50 Kroger Card.  2,625 Stores in 34 States.  The Kroger Co. spans many states with store formats that include grocery and multi-department stores, convenience stores and jewelry stores.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/e4397320-e20d-11e4-9c30-b913bf89da40.jpg\"  /></div></a>",
    "hgId" : "fa7560b0-0b04-11e6-8cf9-b73eb280165c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dream, Learn, Lead</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Participate in a Strength Finder Skills/Dreams Assessment and Attend a 2 to 4-hour workshop on leadership or skills development.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/020e3480-ce6d-11e4-91c2-1d7bcc577382.jpg\"  /></div></a>",
    "hgId" : "47763510-0b05-11e6-b2ee-c52ee4d5369c",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Weight Watchers Coaching + ONline Plus</strong> was recently added to the store!</h4><div class=\"mar-bot10\">This is a 3-month membership for a personal assessment for a customized healthy living plan and  one-on-one phone sessions with a coach to tailor your plan.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/f5eb59d0-0b06-11e6-b466-77cb57711405.jpg\"  /></div></a>",
    "hgId" : "123f3e30-0b07-11e6-9400-d398a81eb7b2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Take Flight!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Two round trip plane tickets (up to $350 value each) for a total value of $700.00.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/a263dea0-ce7f-11e4-86d1-1b685b7543a5.jpg\"  /></div></a>",
    "hgId" : "23cd33f0-0bac-11e6-aae5-b9a6668f2770",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Go On a Cruise!!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$1,000 Carnival Cruise Line Gift Card. Carnival Gift Cards can be used on almost anything: towards the purchase of a Carnival cruise and redeemed onboard toward the Sail & Sign account for gifts, drinks, and fun.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/1446c390-dfa4-11e4-bc1f-e5d8f458bf34.jpg\"  /></div></a>",
    "hgId" : "282da7e0-0bac-11e6-aae5-b9a6668f2770",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Make it a Carnival!</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$500 Carnival Cruise Line Gift Card. Carnival Gift Cards can be used on almost anything: towards the purchase of a Carnival cruise and redeemed onboard toward the Sail & Sign account for gifts, drinks, and fun.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>5000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/21/71bde090-dfa3-11e4-8644-8ff1146f9260.jpg\"  /></div></a>",
    "hgId" : "2e31e0c0-0bac-11e6-aae5-b9a6668f2770",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Race For Hope 5k</strong> was recently added to the store!</h4><div class=\"mar-bot10\">WELCOME! Welcome to the home of the 4th annual Race for Hope Des Moines!  Our event has had a successful three years and we are excited to see everyone again in May!  If this is your first time visiting, just scroll down for more information.  If you are a return guest, we hope this website contains all the info you need to be ready for May 14! We are always working to improve your online experience. If you can’t find any information, please don’t hesitate to contact us using the link above.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/10a5dd30-1602-11e6-957c-8b77a37d6ab2.jpg\"  /></div></a>",
    "hgId" : "1948b5c0-1602-11e6-84b7-d55eca9c7ecc",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>PhishMe Toddy Wedge</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Support your phone with this PhishMe tech accessory. Please note that toddy will be PhishMe branded.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>70</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn3.highground.com/product/79/f77a1ef0-22a6-11e6-82d4-a7810861c88c.jpg\"  /></div></a>",
    "hgId" : "0eae5520-1611-11e6-bc0d-fd70101d9abe",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>PhishMe Water Bottle</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Stay hydrated on the go! Enjoy your recommended 8 glasses of water today in a PhishMe water bottle.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>100</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/79/3a7107c0-1611-11e6-9938-653068cf64cb.jpg\"  /></div></a>",
    "hgId" : "3e7fb230-1611-11e6-bc0d-fd70101d9abe",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>PhishMe Baseball Cap</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Keep the sun out of your eyes with thie PhishMe baseball cap.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>140</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/79/1e3c75c0-1612-11e6-9525-0da1e065bdcc.jpg\"  /></div></a>",
    "hgId" : "27037820-1612-11e6-85cc-6d413db794d2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$20 Gift card of your choosing</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Redeem for a gift card of your choosing within the gift card store.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>200</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn4.highground.com/product/79/6444c630-1612-11e6-9d44-cfb06736b878.jpg\"  /></div></a>",
    "hgId" : "68bedca0-1612-11e6-852e-f913065887b9",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>PhishMe Umbrella 62\"</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Stay dry in the most inclement weather with this PhishMe branded umbrella.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>260</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn1.highground.com/product/79/7757e8f0-21c6-11e6-9974-3b62b208e3ae.jpg\"  /></div></a>",
    "hgId" : "9869c5f0-1612-11e6-852e-f913065887b9",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>PhishME Zoom brand (Apple certified) power charger</strong> was recently added to the store!</h4><div class=\"mar-bot10\">POWER IT UP with a PhishMe Zoom Power Charger.</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>460</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn4.highground.com/product/79/43fc9d90-2291-11e6-9666-9f6822f2f1b3.jpg\"  /></div></a>",
    "hgId" : "cdebe4b0-1612-11e6-84b7-d55eca9c7ecc",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>PhishMe Backpack</strong> was recently added to the store!</h4><div class=\"mar-bot10\">On the go for work or for fun…enjoy this PhishMe backpack.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/79/16629d10-1613-11e6-b88b-4df25b172be1.jpg\"  /></div></a>",
    "hgId" : "1bd9d830-1613-11e6-852e-f913065887b9",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fitbit</strong> was recently added to the store!</h4><div class=\"mar-bot10\">On the go, track your steps with this PhishMe Fitbit</div><div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn5.highground.com/product/79/bdbba620-2292-11e6-b070-b509fd60951e.jpg\"  /></div></a>",
    "hgId" : "74c92db0-1613-11e6-85cc-6d413db794d2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Bluetooth speaker</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Rock out with this PhishMe Bluetooth speaker.</div><div class=\"product-item-label clearfix\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn1.highground.com/product/79/9dfba8d0-22a6-11e6-adda-433771a80876.jpg\"/></div></a>",
    "hgId" : "58bb72b0-1616-11e6-84b7-d55eca9c7ecc",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$50 Gift Card Boulder Running Company</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$50 GIFT CARD TO:  BOULDER RUNNING COMPANY - GREENWOOD VILLAGE - GREENWOOD VILLAGE</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/62ab6dd0-1b7e-11e6-a146-df18c932fe8a.jpg\"  /></div></a>",
    "hgId" : "8e75c190-1b7e-11e6-9e14-df3f6c8413e4",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>$100 Gift Card Boulder Running Company</strong> was recently added to the store!</h4><div class=\"mar-bot10\">$100 GIFT CARD TO:  BOULDER RUNNING COMPANY - GREENWOOD VILLAGE - GREENWOOD VILLAGE</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>1000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/c0915cc0-1b7e-11e6-ae37-7730b77a7651.jpg\"  /></div></a>",
    "hgId" : "e8d48590-1b7e-11e6-9bbb-a70e1abcf979",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2 Cubs or Sox Tickets</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Baseball season is upon us! Attend a Cubs or Sox game of your choice with a friend or family member. Up to a $75 value.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>7500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e37d0c90-e3b0-11e4-b456-79e6926989d5.jpg\"  /></div></a>",
    "hgId" : "1e8136e0-1c68-11e6-882f-03ec348fd122",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Suggest a Snack</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Don't keep it a secret any longer....let us know what your favorite snack or drink is so we can share it with the entire office! See Libby to put in your snack request.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>500</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/ce8b7540-50ef-11e5-9dba-717473d60d4a.jpg\"  /></div></a>",
    "hgId" : "4888f310-1c68-11e6-882f-03ec348fd122",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Fitbit Flex</strong> was recently added to the store!</h4><div class=\"mar-bot10\">What's the best way to avoid laziness? Personal trainer? Self-discipline? NOPE--think again, Grandpa. It's an electronic wrist thing that tracks your activity. And then some. Welcome to a new world of health-filled competition with your friends and, of course, the greatest opponent of all: yourself.</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>10000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/e1cdbda0-e3aa-11e4-80bc-6d91a5578a59.jpg\"  /></div></a>",
    "hgId" : "5a1d3960-1c68-11e6-851c-07925a121a52",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Raspberry Pi 2 Model B</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Get your creative juices flowing with this gadget!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/57894200-b1a9-11e4-b3f2-c71e1f30c30e.jpg\"  /></div></a>",
    "hgId" : "666f5e50-1c68-11e6-882f-03ec348fd122",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Lunch With a Coworker @ Gino's East</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Don't eat alone. Grab a coworker and head over to Gino's East in River North for lunch on Highground. Reach out to Libby to plan your lunch today!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>4000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/b6581af0-1c69-11e6-9a15-d183484f8ed2.jpg\"  /></div></a>",
    "hgId" : "ea308150-1c69-11e6-a3bb-a78498b7e977",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Vote Goat Tee</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Goats recently announced their run for the white house in 2016 and now is the time to show your support! We've goat to fix this nation and goats are the only ones who can goat the job done right! See Libby to claim your tee today!</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>3000</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/1/9cf3f3c0-1c7a-11e6-a181-4fbbeef0e253.jpg\"  /></div></a>",
    "hgId" : "e0096a00-1c7a-11e6-bf20-3d5f4ddaf7a2",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Royal Family Kids Camp 5k</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Friday May 20, 2016 @ 6:30 PM\nRaccoon River Park, West Des Moines\n(Packet pickup is at Fitness Sports 4-7 PM Thursday, May 19)</div>ang<div class=\"product-item-label\">This item costs <h5><i class=\"icon icon-point\"></i>250</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img src=\"//stcdn5.highground.com/product/52/3ca74820-1cf5-11e6-9014-5b302a9c2526.jpg\"  /></div></a>",
    "hgId" : "501a6090-1cf5-11e6-abcd-6be4dae7aafc",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Dress Socks</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Show off your PhishMe pride with some trendy dress socks.  One size fits most with these stretchy dress socks – as a guideline they fit a kids 7+ up to a men’s size 13 and all sizes in between.</div><div class=\"product-item-label clearfix\">This item costs <h5><i class=\"icon icon-point\"></i>60</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn1.highground.com/product/79/b6376460-21cb-11e6-b268-372c4abd4b03.jpg\"/></div></a>",
    "hgId" : "c50dc330-21cb-11e6-a385-956932b0e6e5",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>Niki Half Zip Pullover (sizes coming)</strong> was recently added to the store!</h4><div class=\"mar-bot10\">Be trendy and stay warm with this PhishMe pullover half zip. The half zips are all mens/unisex.</div><div class=\"product-item-label clearfix\">This item costs <h5><i class=\"icon icon-point\"></i>1390</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn5.highground.com/product/79/e7f30230-22b0-11e6-adda-433771a80876.jpg\"/></div></a>",
    "hgId" : "da9bf370-21cb-11e6-91d2-c9d88e566c81",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
},
{
    "Message" : "<h4 class=\"lead media-heading\"><strong>2016 Denver Heart & Stroke Walk</strong> was recently added to the store!</h4><div class=\"mar-bot10\">The 2016 Denver Heart & Stroke Walk\nSaturday, June 4th, 2016 - 5K or 1 Mile Option\nNEW 5k Competitive Run!\nFestival open 7:30am | Run Start 8:00am | Walk Start 8:30am</div><div class=\"product-item-label clearfix\">This item costs <h5><i class=\"icon icon-point\"></i>400</h5></div><div class=\"image-upload product-item-action\"><a href=\"https://app.highground.com/#/Motivate/Rewards\"><div>Come check it out before it's all gone!</div><img alt=\"\" src=\"https://stcdn3.highground.com/product/52/1921dc10-0afa-11e6-b466-77cb57711405.jpg\"/></div></a>",
    "hgId" : "31359f30-2819-11e6-b6cb-fbcdcb6412c6",
    "Template" : {
    "Title" : "<div class=\"weight-normal\">A new <strong>REWARD</strong> is available in the store!</div>"
}
}],
    changeData = false;

productItems.forEach(function (pi) {
    print(pi.hgId);
    if (changeData) {
        db.Recognition.update({hgId: pi.hgId}, {$set: {
            Message: pi.Message,
            "Template.Message": pi.Message,
            "Template.Title": pi.Template.Title,
            "Template.Description": pi.Template.Title
        }});
    }
});
