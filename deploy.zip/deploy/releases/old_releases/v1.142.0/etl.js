'use strict';
var HgMigrationFile = function () {
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async'),
        config = require('../../../hgnode/configurations/config.js'),
        newProduct,
        htmlHelper = require('../../../hgnode/helpers/htmlHelper.js');

    require('../../../hgnode/framework/RequireExt.js');
    newProduct = require('../../../static/templates/server/feed/new-product.html');

    // find all instances of product postings to the feed to support localization
    function fixRecognitionCdnUrls(callback) {
        EntityCache.Recognition.find({"Template.Type": "ProductItem"}, function (err, recs) {
            var itemName,
                itemDescription,
                itemUrl,
                itemImage,
                itemTeaser,
                itemCostIndex,
                itemCostValues;
            if (err) {
                return callback(err);
            }
            async.each(recs, function (rec, cb) {
                if (rec.Template.Title.indexOf('REWARD') > -1 || rec.Template.Title.indexOf('reward') > -1 || rec.Template.Title.indexOf('services.int.prd.anr') > -1) {
                    rec.Template.Title = '<div class="weight-normal" translate="services.int.prd.anr"></div>';
                    itemTeaser = 'services.int.prd.cio';
                    itemCostIndex = 'services.int.prd.tic';
                } else {
                    rec.Template.Title = '<div class="weight-normal" translate="services.int.prd.anc"></div>';
                    itemTeaser = 'services.int.prd.bie';
                    itemCostIndex = 'services.int.prd.ifg';
                }
                itemName = rec.Message.match(/<strong>.*<\/strong>/);
                if (!itemName || !itemName.length) {
                    itemName = rec.Message.match(/{itemName: '.*?'}/);
                    if (itemName && itemName.length) {
                        // new format, don't worry about quotes since it's already converted
                        itemName = itemName[0].replace(/{itemName: '/, '').replace(/'}/, '');
                    }
                } else {
                    itemName = itemName[0].replace(/<.*?>/g, '').replace(/"/g, "&quot;").replace(/'/g, "\\'");
                }
                itemDescription = rec.Message.match(/<\/h4><div.*?<\/div>/);
                if (itemDescription && itemDescription.length) {
                    itemDescription = itemDescription[0].replace(/<.*?>/g, '');
                }
                itemUrl = rec.Message.match(/href=".*?"/);
                if (itemUrl && itemUrl.length) {
                    itemUrl = itemUrl[0].replace(/href=/, '').replace(/"/g, '');
                }
                itemImage = rec.Message.match(/src=".*?"/);
                if (itemImage && itemImage.length) {
                    itemImage = itemImage[0].replace(/src=/, '').replace(/"/g, '');
                }
                itemCostValues = rec.Message.match(/<\/i>\d*/);
                if (!itemCostValues || !itemCostValues.length) {
                    itemCostValues = rec.Message.match(/{pointCost: \d*/);
                    if (itemCostValues && itemCostValues.length) {
                        itemCostValues = itemCostValues[0].replace(/{pointCost: /, '');
                    } else {
                        itemCostValues = rec.Message.match(/{fundingGoal: \d*/);
                        if (itemCostValues && itemCostValues.length) {
                            itemCostValues = itemCostValues[0].replace(/{fundingGoal: /, '');
                        }
                    }
                } else {
                    itemCostValues = itemCostValues[0].replace(/<\/i>/, '');
                }
                // if src is empty, then switch itemUrl and itemImage - this will fix the first script that messed up the message
                if (itemUrl && !itemImage) {
                    itemImage = itemUrl;
                    itemUrl = config.protocol + config.baseUrl + '#/Motivate/Rewards';
                }
                rec.Message = htmlHelper.replaceTokens(newProduct, {
                    itemName: itemName || '',
                    itemDescription: itemDescription || '',
                    itemUrl: itemUrl || '',
                    itemImage: itemImage || '',
                    itemTeaser: itemTeaser,
                    itemCostIndex: itemCostIndex,
                    itemCostValues: (itemTeaser === 'services.int.prd.cio' ? '{pointCost: ' : '{fundingGoal: ') + itemCostValues + '}'
                });

                //console.log(rec.Message);

                EntityCache.Recognition.update({hgId: rec.hgId}, {
                    $set: {
                        Message: rec.Message,
                        "Template.Title": rec.Template.Title,
                        "Template.Description": rec.Template.Title
                    }
                }, function (err) {
                    cb(err);
                });
            }, function (err) {
                callback(err);
            });
        });
    }

    function addMiscIndexes(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.Petition.db.collections.Petition.ensureIndex({
                    EntityId: 1,
                    Status: 1
                }, {name: 'EntityIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.MobileNotificationItem.db.collections.MobileNotificationItem.ensureIndex({
                    UserId: 1,
                    Viewed: 1
                }, {name: 'EntityIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.ManagerAlert.db.collections.ManagerAlert.ensureIndex({
                    ReportMemberId: 1,
                    AlertType: 1,
                    Status: 1
                }, {name: 'AlertTypeIndex', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.ManagerAlert.db.collections.ManagerAlert.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            })
        ], fcallback);
    }

    this.Run = function (callback) {
        async.series([
            fixRecognitionCdnUrls,
            addMiscIndexes
        ], callback);
    };
};

module.exports = new HgMigrationFile();
