// 1. remove the REPORT_XXX environment settings from all Heroku configs

// 2. remove unused databases and collections
//database: hgsearch
use hgsearch;
db.dropDatabase();

// 3. remove unused collections
use hgcommon;
db.MemberActivityReport.drop();
db.carts.drop();
db.GlobalSettings.drop();
db.inventoryitems.drop();
db.NotificationPreference.drop();
db.NotificationSubscription.drop();
db.PaymentProfile.drop();
db.PerformanceReview.drop();
db.PerformanceCard.drop();

use hgthanka;
db.Attachment.drop();

// 4: Update Historical Record for Comment Schema Add Member ID
use hgcommon;
member = db.Member.aggregate({$match: {}},{$project:{_id:0,hgId:1,GroupId:1,UserId:1}}).result;
members={};
for(j=0;j<member.length;j+=1){
members['ID-'+member[j].GroupId+'-'+member[j].UserId]=member[j].hgId;
}

use hgthanka;
comments = db.Comment.aggregate({$match: {}}).result;

function executeQuery() {
    print("Begin- executeQuery");
    print("Total Comments to Update:" + comments.length);
    for(j = 0, lenTotal = comments.length; j < lenTotal; j++) {
        if ((comments[j].GroupId) && comments[j].GroupId !== null && comments[j].GroupId !== undefined) {
            result = members['ID-'+comments[j].GroupId+'-'+comments[j].CommenterUserhgId];
            if (result !== null) {
                db.Comment.update({'EntityId' : comments[j].EntityId}, { $set : {'MemberId' : result}}, {multi: true});
            } else {
                print('Cannot find member Id for GroupId:' + comments[j].GroupId + ' UserId:' + comments[j].CommenterUserhgId)
            }
        } else {
            print('Comment Record Missing GroupID, EntityId=' + comments[j].EntityId)
        }
    }  
}

executeQuery();

//5. Run Report Aggregation to fix Date Time Slice issue
/*
http://app.highground.com/svc/Report/RemoveActivityReport
http://app.highground.com/svc/Report/BuildTrackActivityReport?StartDate=1357020000000&EndDate=1388469600000
http://app.highground.com/svc/Report/BuildRecognitionActivityReport?StartDate=1357020000000&EndDate=1388469600000
http://app.highground.com/svc/Report/BuildCommentActivityReport?StartDate=1357020000000&EndDate=1388469600000
http://app.highground.com/svc/Report/BuildMemberActivityReport?StartDate=1357020000000&EndDate=1388469600000
*/