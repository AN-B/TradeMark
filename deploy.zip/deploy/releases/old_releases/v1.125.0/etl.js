var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addGRSClientProfile(callback) {
        var profile = new EntityCache.ClientProfile();
        profile.ClientName = 'GRS';
        profile.APIKey = "c5c9381c-af19-11e5-85e6-a34f368fbaf1";    //this was generated on prod with Provision GenerateGuids svc
        profile.ClientType = 'Partner';
        profile.APIKeyStatus = 'Active';
        profile.APIKeyVersion = '1.0';
        profile.PartnerId = "e8cbe680-cb4f-11e5-a164-016b2911a3b3";
        profile.AvailableServices = ["GRS"];

        console.log('GRS apikey', profile.APIKey);

        profile.save(callback);
    }


    this.Run = function (callback) {
        async.series([
            addGRSClientProfile
        ], callback);
    };
};

module.exports = new HgMigrationFile();