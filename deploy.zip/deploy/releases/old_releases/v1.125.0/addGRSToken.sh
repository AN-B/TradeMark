#!/usr/bin/env bash

##ATTENTION: DO NOT RUN THIS ENTIRE SCRIPT
##UNCOMMENT THE LINES FOR THE SPECIFIC ENV, THEN RUN SCRIPT

##demo
#heroku config:set GRS_STOREFRONT_USER=CPYZ0389 GRS_STOREFRONT_TOKEN=abcde12345! --app hgndemo
#heroku config:set GRS_STOREFRONT_USER=CPYZ0389 GRS_STOREFRONT_TOKEN=abcde12345! --app hgapidemo
#heroku config:set GRS_STOREFRONT_USER=CPYZ0389 GRS_STOREFRONT_TOKEN=abcde12345! --app hgmodemo
#heroku config:set GRS_STOREFRONT_USER=CPYZ0389 GRS_STOREFRONT_TOKEN=abcde12345! --app hgesbdemo

##prod
#heroku config:set GRS_STOREFRONT_USER=admin GRS_STOREFRONT_TOKEN='abcde12345!2' --app hgnprod
#heroku config:set GRS_STOREFRONT_USER=admin GRS_STOREFRONT_TOKEN='abcde12345!2' --app hgapiprod
#heroku config:set GRS_STOREFRONT_USER=admin GRS_STOREFRONT_TOKEN='abcde12345!2' --app hgmoprod
#heroku config:set GRS_STOREFRONT_USER=admin GRS_STOREFRONT_TOKEN='abcde12345!2' MAX_WORKERS=2 --app hgesbprod
