var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../../hgnode/framework/EntityCache.js'),
        async = require('async'),
        featureEnums = require('../../../../hgnode/enums/FeatureFlagEnums.js');

    function updateGroups(callback) {
        EntityCache.Group.find({}, function (err, groups) {
            if (err) {
                console.log('Error getting groups');
                return callback(err);
            }
            // since there might be some issues with this script adding multiple flags in previous versions,
            // this part deletes all of the MobileAccess flags first, then adds them back in
            groups.forEach(function (group) {
                console.log("Updating " + group.GroupName + "...");
                if (group.Preference.FeatureFlags) {
                    group.Preference.FeatureFlags = group.Preference.FeatureFlags.filter(function (ff) {
                        return ff.FeatureName !== featureEnums.MobileAccess;
                    });
                    group.Preference.FeatureFlags.push({
                        FeatureName: featureEnums.MobileAccess,
                        FeatureMeta: [],
                        FeatureEnabled: true
                    });
                    if (group.ValueLevelSetting && group.ValueLevelSetting.Levels) {
                        group.ValueLevelSetting.Levels.forEach(function (level) {
                            if (level.LimitPeriod === 'No Limit') {
                                level.LimitPeriod = 'NoLimit';
                            }
                        });
                    }
                    group.save(function (err) {
                        if (err) {
                            callback(err);
                        }
                        callback();
                    });
                }
            });
        });
    }

    this.Run = function (fcallback) {
        async.series([
            updateGroups
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
