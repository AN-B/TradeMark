load("../db-scripts/commonDB.js");
setEnv("st");

switchDB("hgperka");

var oldGlobalVisa = db.TangoCard.findOne({CardName: "Visa"}),
    dryRun = true,
    selEnv = 'uat',
    cdn = {
        uat: [
            '//d1hvxn71dqi24l.cloudfront.net',
            '//d1eusys6fdo11q.cloudfront.net',
            '//d1n0suh8db960g.cloudfront.net'
        ],
        st: [
            '//d1mdptzm6hyqsk.cloudfront.net',
            '//d11gzz9ueyzwk5.cloudfront.net',
            '//d14l7genrzpehp.cloudfront.net'
        ],
        prod: [
            '//d2m1f7os0jcurd.cloudfront.net',
            '//dwl9fvarlrqri.cloudfront.net',
            '//d16rcxsybf2tyb.cloudfront.net'
        ]
    },
    i = 0,
    newVisa = {
        "CardName" : "Prepaid Visa Reward",
        "Country" : "USA",
        "CreatedBy" : "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
        "CreatedDate" : Date.now(),
        "Denominations" : [
            {
                "CurrencyType" : "USD",
                "MaxPrice" : 100000,
                "MinPrice" : 500,
                "UnitPrice" : 0,
                "Denomination" : -1,
                "SKU" : "PPVV-E-V-STD",
                "Description" : "Prepaid Visa® Reward"
            }
        ],
        "EmailTemplateId" : "33721",
        "ExcludedGroupIds" : [
            "67c6df60-3476-11e5-a6d2-cda5020121f5",
            "fb496c90-c1a3-11e3-bb0d-49bd56e7730e", 
            "7bc84a10-ac49-11e2-816a-81fd71297a71", 
            "a951d3d0-1a43-11e3-b544-b5fd63eafa89", 
            "67fe3480-9808-11e3-84fb-257f0d28f9f7", 
            "51193440-a0c3-11e3-a081-8f99ce572ffe", 
            "0d8c43c0-78a5-11e3-a321-c13e2a754199", 
            "970b4070-ce75-11e4-8bfe-2355b87e8604", 
            "93c913a0-bdf2-11e2-9666-cb9e9195cb36", 
            "53442a10-edb0-11e3-8082-df8151173dcb", 
            "f7c50ed0-8f71-11e3-83de-21f00c0936e3", 
            "f4b3ceb0-3c46-11e5-97a8-475589db2923",
            "28c6a300-d0a3-11e3-9876-450840dd7df6",
            "a11c7ed0-3c35-11e4-a2bc-13f3a9e85c97"
        ],
        "GroupIds" : [
            "all"
        ],
        "ImageUrl" : "https:" + cdn[selEnv][1] + "/giftcard/prepaid-virtual-visa-custom-gift-card.png",
        "ModifiedBy" : "132f9280-bb9a-11e4-a123-b3c1e56907c3",
        "ModifiedDate" : Date.now(),
        "Type" : "giftcard",
        "hgId" : "d3e71400-4cbb-11e5-9392-93e03166e122"
    };

if (!dryRun) {
    db.ArchiveCollection.save(oldGlobalVisa);
    db.TangoCard.remove({CardName: "Visa"});
    db.TangoCard.save(newVisa);
}