#ATTENTION: DO NOT RUN THIS ENTIRE SCRIPT, ONLY RUN THE NECESSARY LINES FOR THE SPECIFIC ENVIRONMENT BEING DEPLOYED
# 1. RUN THE BEFORE DEPLOY LINES
# 2. DEPLOY THE BRANCH
# 3. RUN THE AFTER DEPLOY LINES

#dev - before deploy
heroku config:set BUILD_ENV=dev --app hgndev
#dev - after deploy
heroku config:set NODE_ENV=development --app hgndev

# poc - before deploy
heroku config:set BUILD_ENV=poc --app hgnpoc
heroku config:set BUILD_ENV=poc --app hgapipoc
heroku config:set BUILD_ENV=poc --app hgesbpoc
# poc - after deploy
heroku config:set NODE_ENV=production --app hgnpoc
heroku config:set NODE_ENV=production --app hgapipoc
heroku config:set NODE_ENV=production --app hgesbpoc

# tron - before deploy
heroku config:set BUILD_ENV=tron --app hgntron
heroku config:set BUILD_ENV=tron --app hgapitron
heroku config:set BUILD_ENV=tron --app hgesbtron
# tron - after deploy
heroku config:set NODE_ENV=production --app hgntron
heroku config:set NODE_ENV=production --app hgapitron
heroku config:set NODE_ENV=production --app hgesbtron

# borg - before deploy
heroku config:set BUILD_ENV=borg --app hgnborg
heroku config:set BUILD_ENV=borg --app hgmoborg
heroku config:set BUILD_ENV=borg --app hgesbborg
# borg - after deploy
heroku config:set NODE_ENV=production --app hgnborg
heroku config:set NODE_ENV=production --app hgmoborg
heroku config:set NODE_ENV=production --app hgesbborg

# cylon - before deploy
heroku config:set BUILD_ENV=cylon --app hgncylon
heroku config:set BUILD_ENV=cylon --app hgesbcylon
# cylon - after deploy
heroku config:set NODE_ENV=production --app hgncylon
heroku config:set NODE_ENV=production --app hgesbcylon

# ripley - before deploy
heroku config:set BUILD_ENV=ripley --app hgnripley
heroku config:set BUILD_ENV=ripley --app hgesbripley
# ripley - after deploy
heroku config:set NODE_ENV=production --app hgnripley
heroku config:set NODE_ENV=production --app hgesbripley

# scully - before deploy
heroku config:set BUILD_ENV=scully --app hgnscully
heroku config:set BUILD_ENV=scully --app hgesbscully
# scully - after deploy
heroku config:set NODE_ENV=production --app hgnscully
heroku config:set NODE_ENV=production --app hgesbscully

# trinity - before deploy
heroku config:set BUILD_ENV=trinity --app hgntrinity
heroku config:set BUILD_ENV=trinity --app hgesbtrinity
# trinity - after deploy
heroku config:set NODE_ENV=production --app hgntrinity
heroku config:set NODE_ENV=production --app hgesbtrinity

# qa - before deploy
heroku config:set BUILD_ENV=qa --app hgnqa
heroku config:set BUILD_ENV=qa --app hgapiqa
heroku config:set BUILD_ENV=qa --app hgmoqa
heroku config:set BUILD_ENV=qa --app hgesbqa
# qa - after deploy
heroku config:set NODE_ENV=production --app hgnqa
heroku config:set NODE_ENV=production --app hgapiqa
heroku config:set NODE_ENV=production --app hgmoqa
heroku config:set NODE_ENV=production --app hgesbqa

# uat - before deploy
heroku config:set BUILD_ENV=uat --app hgnuat
heroku config:set BUILD_ENV=uat --app hgapiuat
heroku config:set BUILD_ENV=uat --app hgmouat
heroku config:set BUILD_ENV=uat --app hgesbuat
# uat - after deploy
heroku config:set NODE_ENV=production --app hgnuat
heroku config:set NODE_ENV=production --app hgapiuat
heroku config:set NODE_ENV=production --app hgmouat
heroku config:set NODE_ENV=production --app hgesbuat

# stage - before deploy
heroku config:set BUILD_ENV=st --app hgnst
heroku config:set BUILD_ENV=st --app hgapist
heroku config:set BUILD_ENV=st --app hgmost
heroku config:set BUILD_ENV=st --app hgesbst
# stage - after deploy
heroku config:set NODE_ENV=production --app hgnst
heroku config:set NODE_ENV=production --app hgapist
heroku config:set NODE_ENV=production --app hgmost
heroku config:set NODE_ENV=production --app hgesbst

# demo - before deploy
heroku config:set BUILD_ENV=demo --app hgndemo
heroku config:set BUILD_ENV=demo --app hgapidemo
heroku config:set BUILD_ENV=demo --app hgmodemo
heroku config:set BUILD_ENV=demo --app hgesbdemo
# demo - after deploy
heroku config:set NODE_ENV=production --app hgndemo
heroku config:set NODE_ENV=production --app hgapidemo
heroku config:set NODE_ENV=production --app hgmodemo
heroku config:set NODE_ENV=production --app hgesbdemo

# prod - before deploy
heroku config:set BUILD_ENV=prod --app hgnprod
heroku config:set BUILD_ENV=prod --app hgapiprod
heroku config:set BUILD_ENV=prod --app hgmoprod
heroku config:set BUILD_ENV=prod --app hgesbprod
# prod - after deploy
heroku config:set NODE_ENV=production --app hgnprod
heroku config:set NODE_ENV=production --app hgapiprod
heroku config:set NODE_ENV=production --app hgmoprod
heroku config:set NODE_ENV=production --app hgesbprod
