/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        guid = require('node-uuid'),
        guidMap = {
            qa: "2dbb36f0-787c-11e5-9f2d-db6553d33491",
            uat: "3ad1e460-787c-11e5-a637-af2fda7750a4",
            demo: "44673340-787c-11e5-9f2d-db6553d33491",
            st: "4b8121e0-787c-11e5-a637-af2fda7750a4",
            prod: "559cded0-787c-11e5-9f2d-db6553d33491"
        };

    function addMonthlyUserActivityIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.MetricsMonthlyActivity.db.collections.MetricsMonthlyActivity.ensureIndex({
                    _id: 1,
                    p: 1,
                    g: 1
                }, {name : 'CoreDocIndex', background: true }, callback);
            })
        ], fcallback);
    }

    function migrateUserActivityData(callback) {
        EntityCache.MetricsUserActivity.aggregate([
            {$match: {}},
            {$group: {
                _id: { 
                    g: "$g",
                    year: {'$year': '$p'},
                    month: {'$month': '$p'}
                },
                m: { '$addToSet': "$m"}
            }}
        ], function (error, result) {
            if (error || !result || !result.length) {
                return callback(error);
            }
            EntityCache.MetricsMonthlyActivity.create(result.map(function (item) {
                return {
                    g: item._id.g,
                    p: new Date(Date.UTC(item._id.year, item._id.month, 1, 23, 59, 59) - 86400000),
                    year: item._id.year,
                    month: item._id.month,
                    t: item.m.length
                };
            }), callback);
        });
    }

    function monthlyMetricsAggregationJob(callback) {
        var job = new EntityCache.Job({
            hgId: guidMap[process.env.BUILD_ENV] || guid.v1(),
            JobName: 'MonthlyMetricsAggregationTask',
            MethodName: 'MonthlyMetricsAggregationTask',
            PeriodType: 'Monthly',
            Hour: 12,
            Day: 1,
            LatestTriggerDate: 0
        });
        job.save(callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addMonthlyUserActivityIndex, 
            migrateUserActivityData,
            monthlyMetricsAggregationJob
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
