load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hglog");

var dryRun = true;

//Remove Deprecated Fields
var update = {
    $unset: {
        CorrelationId: "",
        Date: "",
        ModifiedDate: "",
        ModifiedBy: "",
        CreatedDate: "",
        CreatedBy: "",
        hgId: ""
    }
};
if (!dryRun) {
    db.UserActivityAudit.update({}, update, {multi: true});
    db.UnAuthorizedActivity.update({}, update, {multi: true});
    db.UserActivityAudit.update({GroupId: ""}, {$unset: {GroupId: ""}}, {multi: true});
    db.UserActivityAudit.update({GroupName: ""}, {$unset: {GroupName: ""}}, {multi: true});
    db.UserActivityAudit.update({FullName: ""}, {$unset: {FullName: ""}}, {multi: true});
    db.UserActivityAudit.update({UserId: ""}, {$unset: {UserId: ""}}, {multi: true});
    db.UserActivityAudit.update({MemberId: ""}, {$unset: {MemberId: ""}}, {multi: true});

    db.UnAuthorizedActivity.update({GroupId: ""}, {$unset: {GroupId: ""}}, {multi: true});
    db.UnAuthorizedActivity.update({GroupName: ""}, {$unset: {GroupName: ""}}, {multi: true});
    db.UnAuthorizedActivity.update({FullName: ""}, {$unset: {FullName: ""}}, {multi: true});
    db.UnAuthorizedActivity.update({UserId: ""}, {$unset: {UserId: ""}}, {multi: true});
    db.UnAuthorizedActivity.update({MemberId: ""}, {$unset: {MemberId: ""}}, {multi: true});

}

//this section is likely going to take a while to complete because of the size of the collection
if (!dryRun) {
    db.runCommand({compact: 'UserActivityAudit', force: true});
    db.runCommand({compact: 'UnAuthorizedActivity', force: true});
} 
