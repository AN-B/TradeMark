load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgperform");

//Schema changes to Template and Survey collections
// Change to Fields
/* Title, Description, UberQuestion, DriverQuestions, PulseQuestion */
var dryRun = true;
function transform(template) {
    if (template.Title && template.Title.Text) {
        template.Title = template.Title.Text;    
    }
    if (template.Description && template.Description.Text) {
        template.Description = template.Description.Text;
    }
    if (template.UberQuestion) {
        if (template.UberQuestion.MaxLabelAnswer.Text) {
            template.UberQuestion.MaxLabelAnswer = template.UberQuestion.MaxLabelAnswer.Text;
        }
        if (template.UberQuestion.MinLabelAnswer.Text) {
            template.UberQuestion.MinLabelAnswer = template.UberQuestion.MinLabelAnswer.Text    
        }
        if (template.UberQuestion.Question.Text) {
            template.UberQuestion.Question = template.UberQuestion.Question.Text;
        }
    }
    if (template.DriverQuestions && template.DriverQuestions.length) {
        template.DriverQuestions.forEach(function (dQuestion) {
            if (dQuestion.MaxLabelAnswer.Text) {
                dQuestion.MaxLabelAnswer = dQuestion.MaxLabelAnswer.Text;
            }
            if (dQuestion.MinLabelAnswer.Text) {
                dQuestion.MinLabelAnswer = dQuestion.MinLabelAnswer.Text;
            }
            if (dQuestion.Question.Text) {
                dQuestion.Question = dQuestion.Question.Text;
            }
        });
    }
    if (template.PulseQuestions && template.PulseQuestions.length) {
        template.PulseQuestions.forEach(function (pQuestion) {
            if (pQuestion.Question.Text) {
                pQuestion.Question = pQuestion.Question.Text;
            }
        });
    }
    return template;
}

db.Template.find({}).forEach(function (template) {
    template = transform(template);
    if (!dryRun) {
        db.Template.save(template);
    }
});

//Schema changes to Survey Template collection
db.Survey.find({}).forEach(function (survey) {
    if (survey.Template) {
        survey.Template = transform(survey.Template);
        if (!dryRun) {
            db.Survey.save(survey);
        }
    }
});

if (!dryRun) {
    db.runCommand({compact: 'Template', force: true});
    db.runCommand({compact: 'Survey', force: true});
}