// groupId = '26a27290-c93b-11e2-97c3-7fea105fa5fe'; // local inwk
var groupId = 'a0b0ad70-0551-11e3-abca-d7a68b3c36fe'; // uat inwk
//var groupId = '00474e30-c93c-11e2-aedf-47638bb1c36d'; // prod inwk

// db.Group.find({'Preference.FeatureFlags.FeatureName' : 'DisableFeatureByRole'});
//above query returns only Innerworkings, which "hgId": "00474e30-c93c-11e2-aedf-47638bb1c36d" -- prod
//26a27290-c93b-11e2-97c3-7fea105fa5fe -- local

// db.Member.find({'GroupId' : groupId, 'RolesInGroup' : {$in : ['OffBoarded', 'Employee', 'Manager']}});

// dont allow inwk 'OffBoarded', 'Employee', 'Manager' members to purchase credits
db.Member.update({'GroupId' : groupId, 'RolesInGroup' : {$in : ['OffBoarded', 'Employee', 'Manager']}}, {$addToSet :
    {
        'RemovedPermissions' : 'PurchaseCredits'
    }
},{multi:true});

// dont allow inwk 'OffBoarded', 'Employee', 'Manager', 'Executive', 'Owner', 'Admin' members to purchase group deals
db.Member.update({'GroupId' : groupId, 'RolesInGroup' : {$in : ['OffBoarded', 'Employee', 'Manager', 'Executive', 'Owner', 'Admin']}}, {$addToSet :
    {
        'RemovedPermissions' : 'GroupDeal'
    }
},{multi:true});

// dont allow inwk 'OffBoarded', 'Employee', 'Manager', 'Executive', 'Owner', 'Admin' members CharitiesButton
db.Member.update({'GroupId' : groupId, 'RolesInGroup' : {$in : ['OffBoarded', 'Employee', 'Manager', 'Executive', 'Owner', 'Admin']}}, {$addToSet :
    {
        'RemovedPermissions' : 'CharitiesButton'
    }
},{multi:true});

// turn on Perform in Production for Mercury and Fooda
db.Group.update({hgId: {$in:['1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde','7bc84a10-ac49-11e2-816a-81fd71297a71']}}, {$addToSet: {
    'Preference.FeatureFlags' :
    {
        FeatureName: 'EnablePerform',
        FeatureEnabled: true
    }
}},{multi:true});

// turn on Perform in Demo for Acme and Initech
db.Group.update({hgId: {$in:['c4557e50-112b-11e3-8580-ef81caa8e0fb','3273ffa0-a198-11e2-bd0c-27a595a7c7b9']}}, {$addToSet: {
    'Preference.FeatureFlags' :
    {
        FeatureName: 'EnablePerform',
        FeatureEnabled: true
    }
}},{multi:true});

// turn on Share Link in Production for Mercury and Fooda
db.Group.update({hgId: {$in:['1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde','7bc84a10-ac49-11e2-816a-81fd71297a71']}}, {$addToSet: {
    'Preference.FeatureFlags' :
    {
        FeatureName: 'ShareLink',
        FeatureMeta: [
            {
                Name: "LinkedIn",
                Value: true
            },
            {
                Name: "Facebook",
                Value: false
            }
        ],
        FeatureEnabled: true
    }
}},{multi:true});

// turn on Share Link in Demo for Acme and Initech
db.Group.update({hgId: {$in:['c4557e50-112b-11e3-8580-ef81caa8e0fb','3273ffa0-a198-11e2-bd0c-27a595a7c7b9']}}, {$addToSet: {
    'Preference.FeatureFlags' :
    {
        FeatureName: 'ShareLink',
        FeatureMeta: [
            {
                Name: "LinkedIn",
                Value: true
            },
            {
                Name: "Facebook",
                Value: false
            }
        ],
        FeatureEnabled: true
    }
}},{multi:true});