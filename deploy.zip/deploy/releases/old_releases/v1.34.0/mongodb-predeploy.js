load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Environment.remove();
db.Environment.insert({
    Name : 'QA Server',
    api : 'https://moqa.highground.com/',
    s3 : "https://hgqa1.s3.amazonaws.com",
    Enabled : true
});
db.Environment.insert({
    Name : 'Staging Server',
    api : 'https://most.highground.com/',
    s3 : 'https://hgstage.s3.amazonaws.com',
    Enabled : true
});
db.Environment.insert({
    Name : 'UAT Server',
    api : 'https://mouat.highground.com/',
    s3 : 'https://hguat.s3.amazonaws.com',
    Enabled : true
});


db.Member.update({FullName: {$in: ["Gary Wei"]}, GroupName: {$nin: ["Mercury"]}}, {$addToSet: {AddedPermissions: "SwitchEnvironment"}}, {multi: true});


switchDB("hgcommon");
var mercuryGroupName = 'Mercury Industries',
    allianzGroupName = 'Allianz',
    groups = db.Group.aggregate({$match :
        { $or: [
            {'GroupName' : mercuryGroupName},
            {'GroupName' : allianzGroupName}
        ]}
    }).result,
    cardNames = ['Nike', 'Nordstrom', "Lowe's", "Maggiano's", 'Nordstrom Rack', 'On the Border', 'Overstock.com', "Papa John's",
        'Petco', 'Pottery Barn', 'Redbox', 'Red Robin', 'Sears', 'Sephora', 'The Sports Authority', 'Staples', "TGI Friday's",
        'T.J.Maxx', 'The Home Depot', 'AMC', "Applebee's", 'Bass Pro Shops', "Chili's", "Dave & Buster's", "Domino's",
        'Footlocker', 'GameStop', 'IHOP', "Kohl's" ];

switchDB("hgperka");
if(groups && groups.length === 2) {
    groups.forEach(function (group) {
        print("Exposing cards to " + group.GroupName);
        groupId = group.hgId;
        db.TangoCard.update({'CardName' : {$in : cardNames} }, {$addToSet : {GroupIds : groupId}}, {multi : true}); //expose card to customer
    })
} else {
    print('Did not find both groups');
}

//Run Recognition Migration Script 
//---> Deploy/Analytics/trackMigration.js

