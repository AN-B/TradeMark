/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        inserts = [
            {
                "FullCategory" : "Introduction:LoginOrRefresh",
                "PrimaryCategory" : "Introduction",
                "SecondaryCategory" : "LoginOrRefresh",
                "Feature" : "",
                "TutorialNumber" : 0,
                "Step" : 1,
                "RouteURL" : "/User/Account",
                "TemplateURL" : "/Introduction/LoginOrRefresh-1.html",
                "ExitURL" : "",
                "Permissions" : "Basic",
                "TargetSelector" : "",
                "EventName" : ""
            }, {
                "FullCategory" : "Introduction:LoginOrRefresh",
                "PrimaryCategory" : "Introduction",
                "SecondaryCategory" : "LoginOrRefresh",
                "Feature" : "",
                "TutorialNumber" : 0,
                "Step" : 2,
                "RouteURL" : "/User/Account",
                "TemplateURL" : "/Introduction/LoginOrRefresh-2.html",
                "ExitURL" : "",
                "Permissions" : "Basic",
                "TargetSelector" : "",
                "EventName" : ""
            }, {
                "FullCategory" : "Introduction:LoginOrRefresh",
                "PrimaryCategory" : "Introduction",
                "SecondaryCategory" : "LoginOrRefresh",
                "Feature" : "",
                "TutorialNumber" : 0,
                "Step" : 4,
                "RouteURL" : "/User/Account",
                "TemplateURL" : "/Introduction/LoginOrRefresh-4.html",
                "ExitURL" : "",
                "Permissions" : "Basic",
                "TargetSelector" : "",
                "EventName" : ""
            }, {
                "FullCategory" : "Introduction:LoginOrRefresh",
                "PrimaryCategory" : "Introduction",
                "SecondaryCategory" : "LoginOrRefresh",
                "Feature" : "",
                "TutorialNumber" : 0,
                "Step" : 3,
                "RouteURL" : "/User/Account",
                "TemplateURL" : "/Introduction/LoginOrRefresh-3.html",
                "ExitURL" : "",
                "Permissions" : "Basic",
                "TargetSelector" : "[ng-href=\"#/User/Account\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:CompanyFeed",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "CompanyFeed",
                "TutorialNumber" : 1,
                "Step" : 2,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/Recognize-CompanyFeed-2.html",
                "ExitURL" : "",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : ".meta",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:CompanyFeed",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "CompanyFeed",
                "TutorialNumber" : 1,
                "Step" : 1,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/Recognize-CompanyFeed-1.html",
                "ExitURL" : "",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : "[ translate=\"common.rec\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Introduction:LoginOrRefresh",
                "PrimaryCategory" : "Introduction",
                "SecondaryCategory" : "LoginOrRefresh",
                "Feature" : "",
                "TutorialNumber" : 0,
                "Step" : 6,
                "RouteURL" : "/User/Account",
                "TemplateURL" : "/Introduction/LoginOrRefresh-6.html",
                "ExitURL" : "",
                "Permissions" : "Basic",
                "TargetSelector" : "[translate=\"users.ac.pr.cp\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Introduction:LoginOrRefresh",
                "PrimaryCategory" : "Introduction",
                "SecondaryCategory" : "LoginOrRefresh",
                "Feature" : "",
                "TutorialNumber" : 0,
                "Step" : 5,
                "RouteURL" : "/User/Account",
                "TemplateURL" : "/Introduction/LoginOrRefresh-5.html",
                "ExitURL" : "",
                "Permissions" : "Basic",
                "TargetSelector" : "[translate=\"common.fst\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:CompanyFeed",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "CompanyFeed",
                "TutorialNumber" : 1,
                "Step" : 3,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/Recognize-CompanyFeed-3.html",
                "ExitURL" : "/Company/Filter/All",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : ".search-container",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 1,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-1.html",
                "ExitURL" : "",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : "",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 2,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-2.html",
                "ExitURL" : "",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : "[translate=\"common.recw\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 4,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-4.html",
                "ExitURL" : "",
                "Permissions" : "CustomizedRecognition",
                "TargetSelector" : "[ng-if=\"isCustom\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 3,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-3.html",
                "ExitURL" : "",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : "[translate=\"common.chob\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 5,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-5.html",
                "ExitURL" : "",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : "[translate=\"common.wri\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 7,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-7.html",
                "ExitURL" : "",
                "Permissions" : "AddGiftToNewRecognition",
                "TargetSelector" : "[ng-click=\"openGiftDialog()\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 6,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-6.html",
                "ExitURL" : "",
                "Permissions" : "SendPointsInRecognition",
                "TargetSelector" : "[ng-click=\"request.MoreOptions.pointValueClicked = !request.MoreOptions.pointValueClicked\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 8,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-8.html",
                "ExitURL" : "",
                "Permissions" : "HideRecognition",
                "TargetSelector" : "[ng-if=\"!request.MoreOptions.suppressFeed\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Points:VirtualCurrency",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Points",
                "Feature" : "Virtual Currency",
                "TutorialNumber" : 3,
                "Step" : 4,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/VirtualCurrency-4.html",
                "ExitURL" : "",
                "Permissions" : "PointStore",
                "TargetSelector" : "[ng-href=\"#/Motivate/Rewards\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Recognize:GiveRecognition",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Recognize",
                "Feature" : "GiveRecognition",
                "TutorialNumber" : 2,
                "Step" : 9,
                "RouteURL" : "/Recognize/Company/GiveEveryday",
                "TemplateURL" : "/Company/Recognize-GiveRecognition-9.html",
                "ExitURL" : "/Company/Filter/All",
                "Permissions" : "GiveRecognition",
                "TargetSelector" : ".btn-close.btn-close-success.pull-right",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Points:VirtualCurrency",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Points",
                "Feature" : "Virtual Currency",
                "TutorialNumber" : 3,
                "Step" : 5,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/VirtualCurrency-5.html",
                "ExitURL" : "",
                "Permissions" : "PointStore",
                "TargetSelector" : ".gift-attached",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Points:VirtualCurrency",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Points",
                "Feature" : "Virtual Currency",
                "TutorialNumber" : 3,
                "Step" : 1,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/VirtualCurrency-1.html",
                "ExitURL" : "",
                "Permissions" : "PointStore",
                "TargetSelector" : "",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Points:VirtualCurrency",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Points",
                "Feature" : "Virtual Currency",
                "TutorialNumber" : 4,
                "Step" : 1,
                "RouteURL" : "/Motivate/Rewards",
                "TemplateURL" : "/Company/VirtualCurrency-6.html",
                "ExitURL" : "",
                "Permissions" : "suggestRewardIdea",
                "TargetSelector" : "[ng-if=\"flags.canSuggestReward\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Points:VirtualCurrency",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Points",
                "Feature" : "Virtual Currency",
                "TutorialNumber" : 3,
                "Step" : 3,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/VirtualCurrency-3.html",
                "ExitURL" : "",
                "Permissions" : "PointStore",
                "TargetSelector" : ".meta",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Points:VirtualCurrency",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Points",
                "Feature" : "Virtual Currency",
                "TutorialNumber" : 3,
                "Step" : 2,
                "RouteURL" : "/Company/Filter/All",
                "TemplateURL" : "/Company/VirtualCurrency-2.html",
                "ExitURL" : "",
                "Permissions" : "PointStore",
                "TargetSelector" : ".currency.ng-scope.divider",
                "EventName" : ""
            }, {
                "FullCategory" : "Company:Points:VirtualCurrency",
                "PrimaryCategory" : "Company",
                "SecondaryCategory" : "Points",
                "Feature" : "Virtual Currency",
                "TutorialNumber" : 5,
                "Step" : 1,
                "RouteURL" : "",
                "TemplateURL" : "/Company/VirtualCurrency-7.html",
                "ExitURL" : "",
                "Permissions" : "PointStore",
                "TargetSelector" : ".currency.ng-scope.divider",
                "EventName" : ""
            }, {
                "EventName" : "HgAppRecognitionReceived",
                "ExitURL" : "",
                "Feature" : "Virtual Currency",
                "FullCategory" : "Company:Points:VirtualCurrency",
                "Permissions" : "PointStore",
                "PrimaryCategory" : "Company",
                "RouteURL" : "",
                "SecondaryCategory" : "Points",
                "Step" : 1,
                "TargetSelector" : "[translate=\"dialogs.rec.rec.youp\"]",
                "TemplateURL" : "/Company/VirtualCurrency-8.html",
                "TutorialNumber" : 6
            }, {
                "FullCategory" : "Profile:Perform",
                "PrimaryCategory" : "Profile",
                "SecondaryCategory" : "Perform",
                "Feature" : "",
                "TutorialNumber" : 8,
                "Step" : 1,
                "RouteURL" : "/Profile/Perform",
                "TemplateURL" : "/Profile/Perform-2.html",
                "ExitURL" : "",
                "Permissions" : "perform",
                "TargetSelector" : "[href=\"#/Profile/Perform\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Profile:Perform",
                "PrimaryCategory" : "Profile",
                "SecondaryCategory" : "Perform",
                "Feature" : "",
                "TutorialNumber" : 7,
                "Step" : 1,
                "RouteURL" : "/Profile/Perform",
                "TemplateURL" : "/Profile/Perform-1.html",
                "ExitURL" : "",
                "Permissions" : "perform",
                "TargetSelector" : "[ng-repeat=\"review in pendingReviews | limitTo: pendingLimitTo\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Profile:Perform",
                "PrimaryCategory" : "Profile",
                "SecondaryCategory" : "Perform",
                "Feature" : "",
                "TutorialNumber" : 8,
                "Step" : 2,
                "RouteURL" : "/Profile/Perform",
                "TemplateURL" : "/Profile/Perform-3.html",
                "ExitURL" : "",
                "Permissions" : "perform",
                "TargetSelector" : "[translate=\"profile.per.rev.vio\"]",
                "EventName" : ""
            }, {
                "FullCategory" : "Profile:Perform",
                "PrimaryCategory" : "Profile",
                "SecondaryCategory" : "Perform",
                "Feature" : "",
                "TutorialNumber" : 9,
                "Step" : 1,
                "RouteURL" : "/Profile/Perform",
                "TemplateURL" : "/Profile/Perform-4.html",
                "ExitURL" : "",
                "Permissions" : "perform",
                "TargetSelector" : "[ng-click=\"review.showReqEdit=true\"]",
                "EventName" : ""
            }],
        guids = {
            qa: ["a7ce4650-6d21-11e5-848a-53ff41da92d1","a7ce4651-6d21-11e5-848a-53ff41da92d1","a7ce4652-6d21-11e5-848a-53ff41da92d1","a7ce4653-6d21-11e5-848a-53ff41da92d1","a7ce4654-6d21-11e5-848a-53ff41da92d1","a7ce4655-6d21-11e5-848a-53ff41da92d1","a7ce4656-6d21-11e5-848a-53ff41da92d1","a7ce4657-6d21-11e5-848a-53ff41da92d1","a7ce4658-6d21-11e5-848a-53ff41da92d1","a7ce4659-6d21-11e5-848a-53ff41da92d1","a7ce465a-6d21-11e5-848a-53ff41da92d1","a7ce465b-6d21-11e5-848a-53ff41da92d1","a7ce465c-6d21-11e5-848a-53ff41da92d1","a7ce465d-6d21-11e5-848a-53ff41da92d1","a7ce465e-6d21-11e5-848a-53ff41da92d1","a7ce465f-6d21-11e5-848a-53ff41da92d1","a7ce6d60-6d21-11e5-848a-53ff41da92d1","a7ce6d61-6d21-11e5-848a-53ff41da92d1","a7ce6d62-6d21-11e5-848a-53ff41da92d1","a7ce6d63-6d21-11e5-848a-53ff41da92d1","a7ce6d64-6d21-11e5-848a-53ff41da92d1","a7ce6d65-6d21-11e5-848a-53ff41da92d1","a7ce6d66-6d21-11e5-848a-53ff41da92d1","a7ce6d67-6d21-11e5-848a-53ff41da92d1","a7ce6d68-6d21-11e5-848a-53ff41da92d1","a7ce6d69-6d21-11e5-848a-53ff41da92d1","a7ce6d6a-6d21-11e5-848a-53ff41da92d1","a7ce6d6b-6d21-11e5-848a-53ff41da92d1","a7ce6d6c-6d21-11e5-848a-53ff41da92d1","a7ce6d6d-6d21-11e5-848a-53ff41da92d1"],
            demo: ["87e4b810-6d21-11e5-80a8-191897316c1c","87e4b811-6d21-11e5-80a8-191897316c1c","87e4b812-6d21-11e5-80a8-191897316c1c","87e4b813-6d21-11e5-80a8-191897316c1c","87e4b814-6d21-11e5-80a8-191897316c1c","87e4b815-6d21-11e5-80a8-191897316c1c","87e4b816-6d21-11e5-80a8-191897316c1c","87e4b817-6d21-11e5-80a8-191897316c1c","87e4b818-6d21-11e5-80a8-191897316c1c","87e4b819-6d21-11e5-80a8-191897316c1c","87e4b81a-6d21-11e5-80a8-191897316c1c","87e4b81b-6d21-11e5-80a8-191897316c1c","87e4b81c-6d21-11e5-80a8-191897316c1c","87e4b81d-6d21-11e5-80a8-191897316c1c","87e4b81e-6d21-11e5-80a8-191897316c1c","87e4b81f-6d21-11e5-80a8-191897316c1c","87e4b820-6d21-11e5-80a8-191897316c1c","87e4b821-6d21-11e5-80a8-191897316c1c","87e4b822-6d21-11e5-80a8-191897316c1c","87e4b823-6d21-11e5-80a8-191897316c1c","87e4b824-6d21-11e5-80a8-191897316c1c","87e4b825-6d21-11e5-80a8-191897316c1c","87e4b826-6d21-11e5-80a8-191897316c1c","87e4b827-6d21-11e5-80a8-191897316c1c","87e4b828-6d21-11e5-80a8-191897316c1c","87e4b829-6d21-11e5-80a8-191897316c1c","87e4b82a-6d21-11e5-80a8-191897316c1c","87e4b82b-6d21-11e5-80a8-191897316c1c","87e4b82c-6d21-11e5-80a8-191897316c1c","87e4b82d-6d21-11e5-80a8-191897316c1c"]
        };

    function removeAllTutorials(callback) {
        EntityCache.Tutorial.remove({}, function (error) {
            if (error) {
                return callback(error);
            }
            callback(error);

        });
    }

    function insertAllTutorials(scallback) {
        var index = 0,
            guidMap = guids[process.env.BUILD_ENV],
            insertTutorial = function (insert, callback) {
                var item = new EntityCache.Tutorial();
                item.hgId = guidMap[index];
                item.FullCategory = insert.FullCategory;
                item.PrimaryCategory = insert.PrimaryCategory;
                item.SecondaryCategory = insert.SecondaryCategory;
                item.Feature = insert.Feature;
                item.TutorialNumber = insert.TutorialNumber;
                item.Step = insert.Step;
                item.RouteURL = insert.RouteURL;
                item.TemplateURL = insert.TemplateURL;
                item.ExitURL = insert.ExitURL;
                item.Permissions = insert.Permissions;
                item.TargetSelector = insert.TargetSelector;
                item.EventName = insert.EventName;
                item.CreatedDate = new Date().getTime();
                item.ModifiedDate = new Date().getTime();
                index += 1;
                item.save(callback);
            };
        Async.each(inserts, insertTutorial, scallback);
    }

    function disableTutorialFlagsForAllCompanies(fcallback) {
        EntityCache.Group.find({}, function (err, groups) {
            if (err || !groups) {
                console.log('Error getting groups');
                return callback(err);
            }
            groups.forEach(function (group) {
                if (group.Preference.FeatureFlags) {
                    if (!group.Preference.FeatureFlags.some(function (f) {
                            return f.FeatureName === 'EnableTutorials'
                        })) {
                        group.Preference.FeatureFlags.push({
                            "FeatureEnabled": false,
                            "FeatureMeta": [],
                            "FeatureName": "EnableTutorials"
                        });
                        group.save(function (err) {
                            if (err) {
                                return fcallback(err);
                            }
                        });
                    }
                }
            });
            fcallback();
        });
    }

    this.Run = function (fcallback) {
        var funcArray = [disableTutorialFlagsForAllCompanies];
        if (process.env.BUILD_ENV === 'qa' || process.env.BUILD_ENV === 'demo') {
            funcArray.push(removeAllTutorials);
            funcArray.push(insertAllTutorials);
        }
        Async.series(funcArray, fcallback);
    };
};
module.exports = new HgMigrationFile();