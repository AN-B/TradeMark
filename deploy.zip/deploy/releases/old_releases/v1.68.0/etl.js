load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgcommon');

var memberDeptHash = {},
    newGifts = [],
    newGift = {},
    start,
    end;

db.Member.find().forEach(function (member) {
    memberDeptHash[member.hgId] = member.GroupDepartmentName;
});

switchDB('hgperform');

db.PerformanceReview.find().forEach(function (review) {
    review.Peoples.forEach(function (person) {
        person.Department = memberDeptHash[person.MemberId];
    });
    db.PerformanceReview.update({ hgId: review.hgId}, {$set: {Peoples: review.Peoples}});
});

// custom role hierarchies
db.PerformanceCard.update({}, {$rename: {'SubjectManagerOnly': 'DetectableRolesOnly'}}, {multi: true});
db.PerformanceCycle.find().forEach(function (performanceCycle) {
    if (performanceCycle.Cards) {
        performanceCycle.Cards.forEach(function (card) {
            if (card.SubjectManagerOnly !== undefined) {
                card.DetectableRolesOnly = card.SubjectManagerOnly;
            }
        });
        db.PerformanceCycle.update({hgId: performanceCycle.hgId}, {$set: {'Cards': performanceCycle.Cards}});
    }
});

switchDB('hgthanka');

db.Recognition.find({'Gifts.0': {$exists: true}}).forEach(function (recognition) {
    newGifts = [];
    newGift = {};
    start = recognition.CreatedDate;
    end = recognition.CreatedDate + 86400000;
    recognition.Gifts.forEach(function (gift) {
        newGift.SenderId = gift.senderId || gift.SenderId;
        newGift.ProductId = gift.productId || gift.giftId || gift.ProductId;
        newGift.Type = gift.Type || 'Group';
        newGift.OrderIds = [];
        if (!gift.OrderIds && newGift.ProductId.length) {
            switchDB('hgperka');
            db.ProductOrder.find({
                CreatedDate: {$gte: start, $lt: end},
                'Recipient.MemberId': recognition.RecipientMember.hgId,
                'ProductItem.hgId': newGift.ProductId
            }).forEach(function (order) {
                newGift.OrderIds.push(order.hgId);
            });
            switchDB('hgthanka');
        } else {
            newGift.OrderIds = gift.OrderIds;
        }
        newGifts.push(newGift);
        db.Recognition.update({hgId : recognition.hgId}, {$set : {Gifts: newGifts}});
    });

});

//below is for sentiment
switchDB("hgcommon");

var sentimentTopicId = '0b590b37-490f-4dbc-8f76-c7af405f248a',
    groupName = 'Mercury Industries',
    group = db.Group.findOne({GroupName : groupName}),
    groupId = group.hgId,
    recurrenceId = 'da14b5e7-1c96-4d12-9cc0-2258bca92c42';
print(groupId);
db.SentimentTopic.remove({hgId : sentimentTopicId});
db.SentimentTopic.insert({
    hgId : sentimentTopicId,
    QuestionText : 'How do you feel about work today?',
    AnswerType : 'ScaleRating',
    AnswerSelectors : [
        {
            Value : 0,
            Text : 'Horrible'
        },
        {
            Value : 1,
            Text : 'Poor'
        },
        {
            Value : 2,
            Text : 'Fair'
        },
        {
            Value : 3,
            Text : 'Good'
        },
        {
            Value : 4,
            Text : 'Excellent'
        }
    ],
    GroupId : groupId,
    GroupName : groupName,
    Status : 'Active',
    DaysToLive: 14,
    CreatedDate : new Date().getTime(),
    ModifiedDate : new Date().getTime()
});

db.Recurrence.remove({hgId : recurrenceId});
db.Recurrence.insert({
    hgId : recurrenceId,
    EntityType : 'SentimentTopic',
    EntityId : sentimentTopicId,
    PeriodType : 'Weekly',
    NumPeriod : 2,
    Status : 'Active',
    FirstTriggerDate : new Date().getTime(),// + 7 * 24 * 3600 * 1000,
    CreatedDate : new Date().getTime(),
    ModifiedDate : new Date().getTime()
});

db.Job.remove({JobName : 'RemindSentiment'});
db.Job.insert({
    JobName : 'RemindSentiment',
    MethodName : 'RemindSentiment',
    PeriodType : 'Daily',
    Hour : 2,
    LatestTriggerDate : 0
});

db.Sentiment.ensureIndex({GroupId : 1});
db.Sentiment.ensureIndex({GroupId : 1, TopicId : 1});
db.Sentiment.ensureIndex({GroupId : 1, TopicId : 1, RoundId : 1});

db.SentimentTopic.ensureIndex({GroupId : 1});
db.SentimentTopic.ensureIndex({GroupId : 1, hgId : 1});
db.SentimentTopic.ensureIndex({GroupId : 1, hgId : 1, Status : 1});

//below is for kick-starter feature
db.Job.remove({JobName: 'ExpireCampaignItems'});
db.Job.insert({
    JobName : 'ExpireCampaignItems',
    MethodName : 'ExpireCampaignItems',
    PeriodType : 'Daily',
    Hour : 5,
    LatestTriggerDate : 0
});

switchDB("hgperka");

db.ProductItem.ensureIndex({GroupId : 1, ProductType : 1, Status : 1, ExpireDate : 1});

