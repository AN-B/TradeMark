/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        UnitedAdminUsersEmployeeIds = ['U003278', 'U076563', 'U286737', 'U093385', 'U283339', 'U034534', 'U298118'],
        unitedGroupName = 'United Airlines';
        // 003278 - Marlon Crawford
        // 076563 - Lorelea DeWitt-Antilla
        // 286737 - Janet Tyse
        // 093385 - Patti Foss
        // 283339 - Robert Thomas
        // 034534 - Terry Lewis
        // 298118 - Monica Tibbitts
    function addProvisionIndex(callback) {
        Async.series([
            (function(callback) {
                EntityCache.ProvisionAudit.db.collections.ProvisionAudit.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    FullName: 1,
                    Status: 1,
                    Type: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.Member.db.collections.Member.ensureIndex({
                    GroupId: 1,
                    EmployeeId: 1
                }, {name: 'EmployeeIdIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedMember.db.collections.ProvisionStagedMember.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    UserName: 1,
                    EmpID: 1,
                    ManagerUserName: 1,
                    NewUserName: 1,
                    OffBoardType: 1,
                    Location: 1,
                    USM: 1,
                    InvalidEmail: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedMember.db.collections.ProvisionStagedMember.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    UserName: 1,
                    ManagerUserName: 1,
                    InvalidEmail: 1,
                    InvalidStartDate: 1,
                    InvalidBirthDate: 1,
                    InvalidRole: 1,
                    InvalidSuppressAnniversary: 1,
                    InvalidSuppressBirthday: 1,
                    InvalidNewUserName: 1,
                    InvalidUserName: 1,
                    InvalidNewUserNameValue: 1,
                    InvalidManagerUserNameValue: 1
                }, {name: 'MemberValidationIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedLocation.db.collections.ProvisionStagedLocation.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    Name: 1,
                    Row: 1,
                    LocationCode: 1,
                    InvalidCountry: 1,
                    InvalidState: 1,
                    InvalidZipCode: 1,
                    InvalidLanguage: 1,
                    InvalidTimeZone: 1
                }, {name: 'LocationValidationIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedDepartment.db.collections.ProvisionStagedDepartment.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    Name: 1,
                    Code: 1,
                    ProcessType: 1,
                    Status: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.Member.db.collections.Member.ensureIndex({
                    GroupId:1,
                    MembershipStatus: 1,
                    LastName: 1
                }, {name: 'LastNameIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionFileMap.db.collections.ProvisionFileMap.ensureIndex({
                    GroupId:1
                }, {name: 'GroupIdIndex', background: true}, callback);
            })
        ], callback);
    }

    function setUnitedAdminRoleUsers(callback) {
        EntityCache.Group.findOne({GroupName: unitedGroupName}, function (error, group) {
            if (error) {
                return callback(error);
            }
            if (!group) {
                return callback('CANNOT FIND UNITED GROUP');
            }
            EntityCache.Member.update({
                GroupId: group.hgId,
                EmployeeId: {$in: UnitedAdminUsersEmployeeIds}
            }, {
                $set: {
                    RolesInGroup: ['Admin']
                }
            }, {
                multi: true
            }, function (error, count) {
                if (error) {
                    return callback(error);
                }
                if (UnitedAdminUsersEmployeeIds.length !== count) {
                    return callback('Expected 7 Admin roles to have been update. Only ' + count + ' was updated');
                }
                return callback();
            });
        });
    }
    function setCustomMemberFields(callback) {
        EntityCache.Group.findOne({GroupName: unitedGroupName}, function (error, group) {
            if (error) {
                return callback(error);
            }
            if (!group) {
                return callback('CANNOT FIND UNITED GROUP');
            }
            var customMemberFields = new EntityCache.GroupCustomMemberField({
                GroupId: group.hgId,
                GroupName: group.GroupName,
                JobCode: true,
                JobLevel: true,
                UnionCode: true,
                BenfitStatus: true,
                MileagePlus: true,
                MailCD: true,
                HomeCountry: true,
                CostCenter: true
            });
            customMemberFields.save(callback);
        });
    }
    function setUnitedMapFile(callback) {
        EntityCache.Group.findOne({GroupName: unitedGroupName}, function (error, group) {
            if (error) {
                return callback(error);
            }
            if (!group) {
                return callback('CANNOT FIND UNITED GROUP');
            }
            EntityCache.ProvisionFileMap.remove({GroupId: group.hgId}, function (error) {
                if (error) {
                    return callback(error);
                }
                var mapfile = new EntityCache.ProvisionFileMap({
                    GroupId: group.hgId,
                    GroupName: group.GroupName,
                    MapFunctionName: 'fnUnitedAirlines',
                    Keys: {
                        Action: "H",
                        FirstName: "EMPL_FIRST_NM",
                        LastName: "EMPL_LAST_NM",
                        FullName: "COMBINE_PN_FM",
                        UserName: "$EMAIL",
                        Email: "$EMAIL",
                        StartDate: "COMPY_SEN_DATE",
                        BirthDate: "BIRTH_DATE",
                        SuppressBirthday: "$DEFAULT::FALSE",
                        SuppressAnniversary: "$DEFAULT::FALSE",
                        EmpID: "EMPL_ID",
                        Department: "DIVISION",
                        DepartmentCode: "DIVISION_CD",
                        Position: "JOB_TILE",
                        JobCode: "JOB_CD",
                        JobLevel: "JOB_LVL",
                        UnionCode: "UNION_CD",
                        MileagePlus: "$BLANK",
                        BenefitStatus: "EMPL_BEN_STATUS",
                        HomeZip: "$BLANK",
                        MailCD: "MAIL_CD",
                        HomeCountry: "EMPL_HOME_CNTRY",
                        WorkZip: "$BLANK",
                        Manager: "$BLANK",
                        ManagerEmpID: "SPVR_ID",
                        Location: "LOC_CD",
                        MailCD: "MAIL_CD",
                        CostCenter: "COST_CNTR_CD",
                        OffBoardType: "$OFFBOARD",
                        OffBoardDate: "$BLANK",
                        Role: "$DEFAULT::Employee"
                    },
                    FileExt: "txt",
                    FileDelimiter: "|",
                    FileEndLineChar: "\n",
                    ManagerUserNameProvided: false,
                    ManagerEmployeeIdProvided: true,
                    DoNotCopyDefaultAvatar: false,
                    UserNameGenerated: true,
                    AllowAutoUserNameChange: true,
                    UserNameDomain: 'united.airlines.com',
                    AllowOffboardedManagerTransfer: true
                });
                mapfile.save(callback);
            });
        });
    }
    function setUnitedManagerRoleUsers(callback) {
        var dataReturned = 1,
            skip = 0;
        EntityCache.Group.findOne({GroupName: unitedGroupName}, function (error, group) {
            if (error) {
                return callback(error);
            }
            if (!group) {
                return callback('CANNOT FIND UNITED GROUP');
            }
            Async.whilst(
                function () {
                    return dataReturned;
                },
                function (scallback) {
                    EntityCache.Member.aggregate([
                        {$match: {
                            GroupId: group.hgId,
                            MembershipStatus: "Active",
                            'MyManagers.MemberId': {$exists: true, $ne: ""}
                        }},
                        {$group: {
                            _id: '$MyManagers.MemberId'
                        }},
                        {$skip: skip},
                        {$limit: 500}
                    ], function (error, managers) {
                        if (error) {
                            return scallback(error);
                        }
                        skip += managers.length;
                        dataReturned = managers.length;
                        if (!managers.length) {
                            return scallback();
                        }
                        EntityCache.Member.update({
                            GroupId: group.hgId,
                            MembershipStatus: "Active",
                            EmployeeId: {$nin: UnitedAdminUsersEmployeeIds},
                            hgId: {$in: managers.map(function (item) {
                                return item._id;
                            })}
                        }, {
                            $set: {
                                RolesInGroup: ['Manager']
                            }
                        }, {
                            multi: true
                        }, scallback);
                    });
                },
                callback
            );
        });
    }
    function setHideDepartmentsFlag(callback) {
        EntityCache.Group.findOne({GroupName: unitedGroupName}, function (error, group) {
            if (error) {
                return callback(error);
            }
            if (!group) {
                return callback('CANNOT FIND UNITED GROUP');
            }
            group.Preference.FeatureFlags.push({
                FeatureName: "HideAdminDepartment",
                FeatureMeta: [],
                FeatureEnabled: true
            });
            group.save(callback);
        });
    }
    this.Run = function (fcallback) {
        Async.series([
            // addProvisionIndex,
            setHideDepartmentsFlag,
            setUnitedAdminRoleUsers,
            setUnitedManagerRoleUsers,
            setUnitedMapFile,
            setCustomMemberFields
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();