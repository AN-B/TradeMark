// find all recogntions and set the status to Active
db.Recognition.update({'Status':''},{$set:{'Status':'Active'}},{multi:true});