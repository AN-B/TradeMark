load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

//hard delete HGAdmin from Non Mercury Industries
var query = { GroupName : { $ne : "Mercury Industries"}, RolesInGroup : 'HGAdmin'};
db.Member.remove(query)

// There should only be one UserId with 2 memberIds today (Hugo Forte)
var hugo = db.UserInfo.findOne({'UserPersonal.PrimaryEmail' : 'hugo@highground.com'}, {_id : 0, hgId : 1});
var hugoFilter = (!hugo) ? {} : { UserId : {$ne : hugo.hgId } };

var result = db.Member.aggregate([{$match : hugoFilter},
{$group : {_id : { UserId : '$UserId'}, count : { $sum : 1}}}, 
{$match : { count : { $gt : 1 } }}]).result

if (result !== undefined && result.length > 0) {
	print('Still have some users with multi member Ids');
	var hgIds = result.map(function(item) { return item._id.UserId; });
	var users = db.UserInfo.find({hgId : { $in : hgIds}}, {_id : 0, hgId : 1, UserPersonal : 1});
    users.map(function(item) { printjson(item);});
    print('These members need to be Manually Deleted before the Default Preference GroupId is resynced');
    db.Member.find({UserId : {$in : hgIds}},
    	{_id : 0, hgId :1, GroupName : 1, FullName : 1, RolesInGroup : 1}).forEach(function (item) {
    		printjson(item);
    });
} else {
	print('Re-Syncing UserInfo Default Groups')
	db.Member.find(hugoFilter, {_id : 0, hgId : 1, UserId : 1, FullName : 1, GroupName : 1, GroupId: 1}).sort({GroupId : 1}).forEach(function (item) {
		print('Setting Preference Default GroupId Record for : ' + item.FullName + ' --> ' + item.GroupName);
		db.UserInfo.update({hgId : item.UserId}, {$set : {'Preference.DefaultGroupId' : item.GroupId}}, {upsert : false});
	});
}
