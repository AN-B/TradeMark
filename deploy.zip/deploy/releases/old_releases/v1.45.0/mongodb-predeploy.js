load("../../db-scripts/commonDB.js");
setEnv("local");

/* 
Index was included in HotFix 1.44.1
switchDB("hgthanka");
//Add Recognition Index
db.Recognition.ensureIndex({'hgId' : 1,  Status : 1});
db.Recognition.ensureIndex({'BatchId' : 1,  Status : 1});
*/

switchDB("hgcommon");
var sonomaGroupId = db.Group.find({GroupName : 'Sonoma Partners'}, {_id : 0, hgId : 1});


switchDB("hgthanka");
//1. Update Blank Recognition titles
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Title' : '',
    'Template.GroupName' : { $nin : ['Sonoma Partners', 'Rightpoint'] },
    'Status' : 'Active'  
},
update = {
    'Template.Title' : 'Happy Birthday!',
    Message : 'Happy Birthday!'
};
db.Recognition.update(query, {$set : update}, {multi : true});

//2. Delete Sonoma Partners and RightPoint Recognition
//a) recognition
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Title' : '',
    'Template.GroupId' : sonomaGroupId.hgId,
    'Status' : 'Active'  
};
db.Recognition.remove(query);

//remove Sonoma Partners Likes
var query = {
    GroupId : sonomaGroupId.hgId
};
db.Congrat.remove(query);

//b) Delete Metrics Sonoma Partners Recognitions
switchDB("hgreports");
if (sonomaGroupId != null) {
    var query = {
        g : sonomaGroupId.hgId
    };
    db.MetricsRecognition.remove(query);
    db.MetricsRecognitionCategory.remove(query);
    db.MetricsRecognitionPublicity.remove(query);
    db.MetricsRecognitionShare.remove(query);
    db.MetricsRecognitionSource.remove(query);
    var query = {
        g : sonomaGroupId.hgId,
        c : { $in : ['RecognitionGiven'] }
    };
    db.MetricsDepartment.remove(query);
    var query = {
        g : sonomaGroupId.hgId,
        c : { $in : ['RecognitionGiven', 'RecognitionReceived', 'RecognitionDeleted'] }
    };
    db.MetricsMember.remove(query);
    //remove likes
    var query = {
        g : sonomaGroupId.hgId
    };
    db.MetricsCongrat.remove(query);
}

//4. Avatar Sync
// In deploy/AvatarSync
// Run node get-s3Avatar.js > {env}.js to generate the list of avatars (change bucket to environment)
// Copy list to {env}-avatar.js file
// then run database script (avatar-sync.js)


//5. Remove VRI Comments Issue
// Deleting 254 comments Created by deleting a group track
switchDB("hgreports");
var query = {
    g :  '53442a10-edb0-11e3-8082-df8151173dcb',
    t : 259
},
update = {
   $set : { s : 'Web', t : 5}
};
db.MetricsComment.update(query, update);

var query = {
    g :  '53442a10-edb0-11e3-8082-df8151173dcb',
    m : '535fa151-edb0-11e3-8082-df8151173dcb', // Kimberly Witt
    c : 'CommentsMade',
    t : 259
}
update = {
   $set : { s : 'Web', t : 5}
};
db.MetricsMember.update(query, update);

//milestone comments have a null source
var query = {
    s : null
};
update = {
   $set : { s : 'Web'}
};
db.MetricsComment.update(query, update, {multi : true});

switchDB("hgthanka");
var query = {
   GroupId : '53442a10-edb0-11e3-8082-df8151173dcb', 
   MemberId : '535fa151-edb0-11e3-8082-df8151173dcb', // Kimberly Witt
   Comment: 'Test'  
},
update = {
    $set : {Status : 'Deleted'}
};
db.Comment.update(query, update,  {multi : true});

//provision API client SF
switchDB("hgsecurity");

db.ClientProfile.remove({ClientName : 'SalesForce'});

db.ClientProfile.insert({
    hgId : 'd9f64db1-d80f-422e-b23a-3ec368c671f4',
    "ClientName" : "SalesForce",
    "APIKey" : 'ab090607-2b7f-40a0-85a5-054aeadf23b5',
    "APIKeyVersion" : "v1.0.1",
    "APIKeyStatus" : "Active",
    "AvailableServices" : [
        'EventBus',
        'Recognition'
    ],
    "CreatedDate" : 1356019594383
});
