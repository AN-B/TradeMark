// load("db-scripts/commonDB.js");
// setEnv("local");

//please note as we release Rec20 in steps, and some customers will stay on Rec10, the following scripts will be copied and pasted to release folders, then commented out from here
//gw : commenting out because they are moved to v.1.24.0

// //run the following script in hgthanka to migrate the binary Archived field to Status in comments
// switchDB("hgthanka");

// db.Badge.update({'SpecialUsages' : {$exists : false}}, {$set : {'SpecialUsages' : []}}, {multi : true});

// db.RecognitionTemplate.update({'IsPublic' : {$ne : true}}, {$set : {'Publicity' : 'Private'}}, {multi: true});
// db.RecognitionTemplate.update({'IsPublic' : true}, {$set : {'Publicity' : 'Both'}}, {multi: true});
// // db.RecognitionTemplate.update({}, {$unset : {'IsPublic' : ''}}, {multi: true});

// //get rid of deleted fields in recognition
// // db.Recognition.update({}, {$unset : {
// //     'RecipientMember_Ref' : '',
// //     'RecipientMember_Obj' : '',
// //     'CreatorMember_Ref' : '',
// //     'Group_Ref' : ''
// // }}, {multi: true});

// // switchDB("hgcommon");

// // members = db.Member.aggregate({$match: {}}).result;

// // function getUserIdByMemberId(memberId) {
// //     for (j = 0; j < members.length; j += 1) {
// //         if (members[j].hgId === memberId) {
// //             return members[j].UserId;
// //         }
// //     }
// // }

//set feature flags for customers who don't want values recognition
switchDB("hgcommon");

db.Group.update({'HGAccountId' : 'HG201300abcde'}, {$addToSet :
    {'Preference.FeatureFlags' : {
        "FeatureName" : "DisableValues",
        "FeatureEnabled" : true
    }
}});
