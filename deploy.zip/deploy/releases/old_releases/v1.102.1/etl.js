/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../../hgnode/framework/EntityCache.js'),
        guid = require('node-uuid'),
        Async = require('async');

    function createActivity(params, callback) {
        var pActivity = new EntityCache.ProvisionActivity(params);
        pActivity.save(callback);
    }
    function getGroupActivity(params, callback) {
        EntityCache.Group.findOne({GroupName: params.Content.Company.Name}, function (error, group) {
            if (error) {
                return callback(error);
            }
            if (group === null) {
                return callback('Group Not Found');
            }
            createActivity({
                hgId: guid.v1(),
                BatchId: params.BatchId,
                ModifiedDate: Date.now(),
                CreatedDate: Date.now(),
                CreatedBy: params.CreatedBy,
                ModifiedBy: params.ModifiedBy,
                Notification: 'Pending',
                Status: 'Successful',
                Summary: "Group " + params.Content.Company.Name  + " is created",
                EntityValue: group.hgId,
                EntityName: "Group",
                Type: params.Type === 'Onboard' ? 'GroupCreated' : 'GroupUpdated'
            }, callback);
        });
    }
    function processSingleAudit(audit, callback) {
        EntityCache.ProvisionBatch.findOne({hgId: audit.BatchId}, function (error, batch) {
            if (error || batch) {
                return callback(error);
            }
            batch = new EntityCache.ProvisionBatch({
                hgId: audit.BatchId,
                FileName: audit.FileName,
                Type: 'ImportCustomer',
                CreatedDate: audit.CreatedDate,
                ModifiedDate: audit.ModifiedDate,
                CreatedBy: audit.CreatedBy,
                ModifiedBy: audit.ModifiedBy
            });
            batch.save(function (error) {
                if (error) {
                    return callback(error);
                }
                console.log('Processing file: ' + audit.FileName);
                getGroupActivity(audit, function (error) {
                    if (error === 'Group Not Found') {
                        console.log(error);
                        return callback();
                    }
                    if (error) {
                        return callback(error);
                    }
                    Async.each(audit.Content.Employees, function (record, fcallback) {
                        var username = record.NewUserName || record.UserName;
                        EntityCache.UserInfo.findOne({
                            LowercaseUserName: username.toLowerCase()
                        }, function (error, userInfo) {
                            if (error) {
                                return fcallback(error);
                            }
                            if (!userInfo) {
                                console.log('Username not found:' + record.UserName.toLowerCase());
                                return fcallback();
                            }
                            Async.parallel({
                                userInfo: function (pCallback) {
                                    createActivity({
                                        hgId: guid.v1(),
                                        BatchId: audit.BatchId,
                                        ModifiedDate: Date.now(),
                                        CreatedDate: Date.now(),
                                        CreatedBy: audit.CreatedBy,
                                        ModifiedBy: audit.ModifiedBy,
                                        Notification: 'Pending',
                                        Status: 'Successful',
                                        Summary: "UserInfo " + record.UserName.toLowerCase() + " is created",
                                        EntityValue: userInfo.hgId,
                                        EntityName: "UserInfo",
                                        Type: audit.Type === 'Onboard' ? 'UserAdded' : 'UserUpdated'
                                    }, pCallback);
                                },
                                member: function (pCallback) {
                                    EntityCache.Member.findOne({
                                        UserId: userInfo.hgId,
                                        GroupId: userInfo.Preference.DefaultGroupId
                                    }, function (error, member) {
                                        if (error) {
                                            return pCallback(error);
                                        }
                                        createActivity({
                                            hgId: guid.v1(),
                                            BatchId: audit.BatchId,
                                            ModifiedDate: Date.now(),
                                            CreatedDate: Date.now(),
                                            CreatedBy: audit.CreatedBy,
                                            ModifiedBy: audit.ModifiedBy,
                                            Notification: 'Pending',
                                            Status: 'Successful',
                                            Summary: "Member " + record.UserName.toLowerCase() + " is created",
                                            EntityValue: member.hgId,
                                            EntityName: "Member",
                                            Type: audit.Type === 'Onboard' ? 'MemberAdded' : 'MemberUpdated'
                                        }, pCallback);
                                    });
                                }
                            }, fcallback);
                        });
                    }, function (error) {
                        console.log('processing audit file completed');
                        callback(error);
                    });
                });
            });
        });
    }
    function addMissingBatchId(callback) {
        EntityCache.ProvisionAudit.find({ Status: 'FileProcessed'}, function (error, audits) {
            if (error || !audits.length) {
                return callback(error);
            }
            console.log('Processsing ' + audits.length  + ' records');
            Async.eachSeries(audits, processSingleAudit, callback);
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            addMissingBatchId
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
