var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function populateGoalCycleParticipantDeptLocId(callback) {
        EntityCache.GoalCycleParticipant.aggregate([{
            $match: {
                ParticipantType: "Member",
                Status: {$exists: true}
            }
        }, {
            $group: {
                "_id": {
                    MemberId: "$Owner.MemberId"
                }
            }
        }], function (error, result) {
            var memberIds;
            if (error) {
                return callback(error);
            }
            memberIds = result.map(function (item) {
                return item._id.MemberId;
            });
            EntityCache.Member.find({
                hgId: {
                    $in: memberIds
                }
            }, {
                hgId: true,
                GroupDepartmentId: true,
                "Location.hgId": true,
                GroupDepartmentName: true,
                "Location.Name": true
            }, function (error, members) {
                var memberMap = {};
                if (error) {
                    return callback(error);
                }
                members.forEach(function (member) {
                    memberMap[member.hgId] = member;
                });
                EntityCache.GoalCycleParticipant.find({
                    ParticipantType: "Member",
                    Status: {$exists: true}
                }, function (error, participants) {
                    if (error) {
                        return callback(error);
                    }
                    Async.each(participants, function (participant, pCallback) {
                        var member;
                        if (!memberMap[participant.Owner.MemberId]) {
                            return pCallback();
                        }
                        member = memberMap[participant.Owner.MemberId];
                        participant.Owner.DeptId = member.GroupDepartmentId;
                        participant.Owner.LocId = member.Location.hgId;
                        participant.Owner.DeptName = member.GroupDepartmentName;
                        participant.Owner.LocName = member.Location.Name;
                        participant.save(pCallback);
                    }, function (error) {
                        callback(error);
                    });
                });
            });
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            populateGoalCycleParticipantDeptLocId
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
