var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        insertColumn;

    insertColumn = function (params, callback) {
        var departmentDetails = [],
            i,
            len,
            mqueryResponse = EntityCache.Team.find({hgId : {$in : params.Data.RestrictDepartmentIds}});

        mqueryResponse.exec(function (error, department) {
            if (error) {
                callback(error);
            } else {
                for (i = 0, len = department.length; i < len; i += 1) {
                    departmentDetails.push({
                        Id : department[i].hgId,
                        Name : department[i].Name
                    });
                }
                EntityCache.RecognitionTemplate.update({hgId: params.Data.hgId},
                    {
                        $set: {
                            RestrictDepartments: departmentDetails
                        }
                    }, function (error) {
                        if (error) {
                            callback(error);
                        } else {
                            callback();
                        }
                    });
            }
        });
    };
    function renameColumnInRecognitionTemplate(callback) {
        var requests = [],
            deleteHgIds = [],
            i,
            len;
        EntityCache.RecognitionTemplate.find({RestrictDepartmentIds: {$ne: null}}, function (error, data) {
            if (error) {
                callback(error);
            } else {
                for (i = 0, len = data.length; i < len; i += 1) {
                    requests.push({
                        Data : data[i]
                    });
                }
                Async.each(requests, insertColumn, function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        for (i = 0, len = data.length; i < len; i += 1) {
                            deleteHgIds.push(data[i].hgId);
                        }
                        EntityCache.RecognitionTemplate.update({hgId : {$in : deleteHgIds}}, {$unset: {RestrictDepartmentIds : 1}}, function (error) {
                            if (error) {
                                callback(error);
                            }
                        });
                    }
                });
            }
        });
    }

    this.Run = function (callback) {
        Async.series([
            renameColumnInRecognitionTemplate()
        ], callback);
    };
};
module.exports = new HgMigrationFile();