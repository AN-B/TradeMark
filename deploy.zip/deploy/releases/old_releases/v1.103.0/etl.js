var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../../hgnode/framework/EntityCache.js'),
        Async = require('async');


    function populateManagerUserId(callback) {
        EntityCache.Member.find({
            MembershipStatus: 'Active',
            MyManagers: {$exists : true},
            "MyManagers.MemberId": {$exists : true},
            $or : [
                {"MyManagers.UserId": ''},
                {"MyManagers.UserId": null},
                {"MyManagers.UserId": {$exists: false}}
            ]
        }, function (error, members) {
            if (error) {
                return callback(error);
            }
            Async.each(members, function (member, asyncCallback) {
                if (!member.MyManagers || !member.MyManagers.length || !member.MyManagers[0].MemberId) {
                    console.log('No manager for ' + member.FullName);
                    return asyncCallback();
                }
                console.log('Trying to set UserId for ', member.FullName);
                EntityCache.Member.findOne({hgId: member.MyManagers[0].MemberId}, function (error, managerMember) {
                    if (error || !managerMember) {
                        return callback('Error loading managerMember');
                    }
                    member.MyManagers[0].UserId = managerMember.UserId;
                    member.save(asyncCallback);
                });
            }, callback);
        });
    }


    this.Run = function (callback) {
        Async.series([
            populateManagerUserId
        ], callback);
    };
};

module.exports = new HgMigrationFile();
