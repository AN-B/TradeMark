load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");


db.CareerTrack.find({}).forEach(
	function(track) {
		hgId = track.hgId;
		closedDate = 0;
		// set closed date on the Goal
		if (track.Status === 'Closed' || track.Status === 'Completed' || track.Status === 'Cancelled' || track.Status === 'Void') {
			closedDate = (track.CareerTrackTemplate.Goal.TargetDate !== null) ? track.CareerTrackTemplate.Goal.TargetDate : 0;
		}
		// set closed date on the milestone
		for(i = 0, len = track.CareerTrackTemplate.MileStones.length; i < len; i += 1) {
			milestoneClosedDate = 0;
			milestoneStatus = track.CareerTrackTemplate.MileStones[i].Status;
			if (milestoneStatus === 'Closed' || milestoneStatus === 'Completed' || milestoneStatus === 'Cancelled' || milestoneStatus === 'Void') {
				milestoneClosedDate = (track.CareerTrackTemplate.MileStones[i].TargetDate !== undefined && track.CareerTrackTemplate.MileStones[i].TargetDate !== null) ? track.CareerTrackTemplate.MileStones[i].TargetDate : 0;
				track.CareerTrackTemplate.MileStones[i].ClosedDate = milestoneClosedDate;
			}
			track.CareerTrackTemplate.MileStones[i].ClosedDate = milestoneClosedDate;
		}
		track.CareerTrackTemplate.Goal.ClosedDate = closedDate;
		db.CareerTrack.update({'hgId' : hgId}, track);
	}
);

switchDB("hgcommon");

group = db.Group.findOne({GroupName:"Allianz"});
if (group) {
    db.Group.update({hgId: group.hgId}, {$addToSet: {
        "Preference.FeatureFlags":
            {
                FeatureName: 'CertificateTemplates',
                FeatureMeta : [
                    {
                        Name: "CertificateNames",
                        Value: "Alz_Cert1.svg,Alz_Cert2.svg,Alz_Cert3.svg"
                    }
                ],
                FeatureEnabled: true
            }
    }});
}
