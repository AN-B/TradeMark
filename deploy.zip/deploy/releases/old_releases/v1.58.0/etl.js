load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

var remarkableRecognitionNumberJobNum = db.Job.find({JobName : 'RemarkableRecognitionNumberJob'}).count();
if (remarkableRecognitionNumberJobNum <= 0) {
    db.Job.insert({
        JobName : 'RemarkableRecognitionNumberJob',
        MethodName : 'RemarkableRecognitionNumberJob',
        PeriodType : 'Daily',
        Hour : 22,
        LatestTriggerDate : 0
    });
}

db.Job.update({JobName : 'TrackCheckIn'}, {$set : {PeriodType : 'Daily'}});

db.Job.update({JobName : 'ClearPastEvents'}, {$set : {Hour : 9}});

db.Job.update({JobName : 'MemberGoalStatusRecap'}, {$set : {Hour : 14}});