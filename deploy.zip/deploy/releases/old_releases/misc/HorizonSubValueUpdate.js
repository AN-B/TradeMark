var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function changeSubvalueDescriptions(callback) {
        var groupName = 'Horizon Pharma',
            valuesData = [{
                Title: "Core Behavior",
                SubvaluesData: [{
                    Name: "Passion for Patients",
                    Description: "What we do matters.  We improve and save lives every day. When patients benefit, everyone benefits. This badge is given for outstanding focus on the patient."
                }, {
                    Name: "Integrity and Trust",
                    Description: "We are successful because we respect and trust each other and have transparent, authentic discussions. This badge is given for authentic and transparent communication or behavior."
                }, {
                    Name: "Composure",
                    Description: "We are calm and professional when faced with challenges. This badge is given for remaining composed in the face of challenge."
                }, {
                    Name: "Taking Ownership",
                    Description: "We hire smart people and empower each other to take ownership. We are personally accountable and comfortable being the only champion for an idea. This badge is given for taking something on, assuming ownership and making it happen."
                }]
            }, {
                Title: "Everyday Action",
                SubvaluesData: [{
                    Name: "Drive for Results",
                    Description: "We love to win and are relentless in the pursuit of our goals. Going above and beyond is what we do every day. This badge is given for pushing the limits, relentlessly focusing on the goal."
                }, {
                    Name: "Dealing with Ambiguity",
                    Description: "We are adept at navigating change and can decide and act without having the total picture. This badge is given for successfully navigating uncertainty or risk."
                }, {
                    Name: "Scalability: Grow Right",
                    Description: "We drive growth without over-engineering process. Our strong sense of urgency is balanced by precision & analysis. This badge is given for smart, scalable improvements."
                }, {
                    Name: "Compliance: It’s Non-negotiable",
                    Description: "We are compliant and make clear, legal and ethical business decisions. This badge is given for behavior that supports our Code of Business Conduct."
                }, {
                    Name: "Think Different",
                    Description: "We are disrupting the industry status quo through diversity of ideas and new ways of thinking. This badge is given for creating innovative, competitive and/or breakthrough ideas and strategies."
                }, {
                    Name: "Teamwork",
                    Description: "We have minimal hierarchy, so teamwork and collaboration are critical to our success. We band together, in good times and bad. This badge is given for exceptional teamwork."
                }, {
                    Name: "Roll Up Our Sleeves",
                    Description: "We leave our egos at the door and roll up our sleeves to get the job done. This badge is given for digging deep to get the job done and/or taking on tasks outside the job description."
                },  {
                    Name: "Get Stuff Done!",
                    Description: "We effectively handle multiple priorities and execute with a sense of urgency. We do more and go farther than others in our industry. This badge is given for getting a lot done in a short period of time, moving through challenges to get the job done."
                }, {
                    Name: "Agility",
                    Description: "We are nimble, creative and goal focused. This badge is given for speed and flexibility in achieving results."
                }, {
                    Name: "Power in Sharing",
                    Description: "We openly share knowledge so that we can learn and improve. This badge is given for sharing knowledge and best practices."
                }, {
                    Name: "Courage to Fail",
                    Description: "We fail fast, learn from our mistakes and move on. This badge is given for trying something new and having the courage to fail."
                }, {
                    Name: "Happy Attitude",
                    Description: "We celebrate success, work hard and have fun along the way. This badge is given for an infectious, positive attitude and for celebrating success."
                }, {
                    Name: "Work + Life",
                    Description: "We value life both inside and outside of work. This badge is given for supporting a work + life approach."
                }, {
                    Name: "Thank You",
                    Description: "We do great things, expect a lot from each other and take time to recognize a job well done. This badge is given for saying \"thank you\"."
                }]
            }];
        EntityCache.Group.findOne({ GroupName: groupName }, function (error, group) {
            if (error || !group) {
                return callback(error || "Unknown Group: " + groupName);
            }
            async.each(valuesData, function (valueData, vCallback) {
                EntityCache.RecognitionTemplate.findOne({
                    Title: valueData.Title,
                    Category: "Values",
                    GroupId: group.hgId
                }, function (error, template) {
                    if (error) {
                        return vCallback(error);
                    }
                    if (!template) {
                        console.log("Unknown Template: " + valueData.Title);
                        return vCallback();
                    }
                    async.each(valueData.SubvaluesData, function (subvalueData, sCallback) {
                        async.series([
                            (function (fCallback) {
                                EntityCache.RecognitionTemplate.findOneAndUpdate({
                                    Title: valueData.Title,
                                    Category: "Values",
                                    GroupId: group.hgId,
                                    "SubValues.Name": subvalueData.Name
                                }, {
                                    $set: {"SubValues.$.Description": subvalueData.Description}
                                }, fCallback);
                            }),
                            (function (fCallback) {
                                EntityCache.Translations.findOneAndUpdate({
                                    EntityId: template.hgId,
                                    GroupId: group.hgId,
                                    EntityType: "RecognitionTemplate",
                                    Lang: "en",
                                    "Values.SubValues.Name": subvalueData.Name
                                }, {
                                    $set: {"Values.SubValues.$.Description": subvalueData.Description}
                                }, fCallback);
                            })
                        ], sCallback);
                    }, vCallback);
                });
            }, callback);
        });
    }

    this.Run = function (callback) {
        async.series([changeSubvalueDescriptions], callback);
    };
};

module.exports = new HgMigrationFile();