load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

db.CareerTrack.ensureIndex({ BatchId : 1});
db.CareerTrack.reIndex();