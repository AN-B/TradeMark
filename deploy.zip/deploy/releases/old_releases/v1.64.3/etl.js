load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

//delete duplicate birthday and anniversary recognitions
// //Duplicate Recognitions for Birthday and Anniversary
// var issueStartDate = new Date('11/8/2014').getTime(),
//     issueEndDate = new Date('11/9/2014').getTime();
// var query = {
//     CreatedDate : { $gte : issueStartDate, $lte : issueEndDate},
//     'Template.Category' : 'System',
//     'Template.SubCategory' : { $in :  ['Birthday', 'Anniversary'] }
// };
// var project = {
//     _id : 0,
//     'RecipientMember.FullName' : 1,
//     'RecipientMember.hgId' : 1
// };
// db.Recognition.aggregate([ 
// {       
//     $match :query
// }, 
// {
//     $group : {
//         _id : {
//             FullName : '$RecipientMember.FullName',
//             Type : '$Template.SubCategory'
//         },
//         Total : { $sum : 1}
//     }
// }]);

// // 14 Users Affected each got 12 recognitions each
// // 5 Anniversary and 9 Birthdays

// //Todo : 
// // Delete 11 recognitions from each user
// // reduce MetricsRecognition
// // reduce MetricsDepartment
// // reduce MetricsManager
// // reduce MetricsRecognitionSource
// // reduce MetricsRecognitionCategory