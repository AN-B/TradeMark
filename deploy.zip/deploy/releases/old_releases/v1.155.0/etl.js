var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

   function archiveCheckinManagerAlert(callback) {
        EntityCache.ManagerAlert.find({
            AlertType: 'FeedbackCheckInDue',
            Status: { $in: ['Active', 'Processing']}
        }, function (error, items) {
            if (error || !items.length) {
                return callback(error);
            }
            var sessionIds = items.map(function (item) {
                return item.Data.SessionId;
            });
            EntityCache.FeedbackSession.find({
                hgId: {$in: sessionIds},
                Status: {$in: ['Archived', 'Closed', 'Completed']}
            }, { hgId: 1}, function (error, sessions) {
                if (error || !sessions.length) {
                    return callback(error);
                }
                EntityCache.ManagerAlert.update({
                    AlertType: 'FeedbackCheckInDue',
                    Status: { $in: ['Active', 'Processing']},
                    'Data.SessionId': {$in: sessions.map( function(s) { return s.hgId; })}
                },
                { $set: {Status: 'Completed'} },
                {multi: true},
                callback);
            });
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            archiveCheckinManagerAlert
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();