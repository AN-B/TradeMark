/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        guid = require('node-uuid');

    function changeTangoEPTemplateId(callback) {
        EntityCache.TangoCard.update({CardName: "Prepaid Visa Reward (International)"}, {
            EmailTemplateId: '39443'
        }, {
            multi: false
        }, function (err, num) {
            console.log('updated ' + num + ' records');
            callback();
        });
    }

    function setLocationDefaults(callback) {
        EntityCache.Team.update({
            Type: 'Location'
        }, {
            $set: {
                i18n: 'en',
                tz: 'America/Chicago'
            }
        }, {
            multi: true
        }, callback);
    }

    function addTranslationIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.Translations.db.collections.Translations.ensureIndex({
                    GroupId: 1,
                    EntityId: 1,
                    Lang: 1,
                    Status: 1
                }, {name: 'CoreDocIndex', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.Translations.db.collections.Translations.ensureIndex({
                    GroupId: 1,
                    EntityId: 1,
                    EntityType: 1,
                    Lang: 1
                }, {name: 'EntityType', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.RecognitionTemplate.db.collections.RecognitionTemplate.ensureIndex({
                    GroupId: 1,
                    Type: 1,
                    Category: 1,
                    DefaultBadge: 1
                }, {name: 'SystemBadgeIndex', background: true }, callback);
            })
        ], fcallback);
    }
    function createTranslation(data, callback) {
        EntityCache.Translations.create({
            GroupId: data.GroupId,
            EntityId: data.hgId,
            EntityType: "RecognitionTemplate",
            Lang: "en",
            Values: {
                Title: data.Title,
                Description: data.Description,
                Message: data.Message
            }
        }, callback);
    }
    function createDefaultBadge(group, callback) {
        var getSubCategory = function (type) {
            return ['News', 'Poll', 'Objective', 'Milestone'].indexOf(type) > - 1 ? 'Default' : type;
        },
        createBadge = function (badge, bCallback) {
            if (['Objective', 'Milestone', 'Welcome', 'Birthday', 'Anniversary', 'News', 'Poll'].indexOf(badge.Type) === -1) {
                console.log('Unknown Badge Type:' + badge.Type);
                return bCallback();
            }
            EntityCache.RecognitionTemplate.findOne({
                DefaultBadge: true,
                hgId: badge.Id
            }, function (error, template) {
                if (error) {
                    return bCallback(error);
                }
                if (!template) {
                    template = new EntityCache.RecognitionTemplate({
                        hgId: badge.Id || guid.v1()
                    });
                }
                template.DefaultBadge = true;
                template.GroupId = group.hgId;
                template.GroupName = group.GroupName;
                template.FriendlyGroupId = group.FriendlyGroupId;
                template.Category = 'System';
                template.SubCategory = getSubCategory(badge.Type);
                template.Publicity = 'Public';
                template.Type = badge.Type;
                template.Message = badge.Message;
                template.Description = badge.Title;
                template.Title = badge.Title;
                template.BackgroundFilename = badge.BackgroundFilename || "";
                template.BackgroundBadgeId = badge.BackgroundBadgeId || "";
                template.ForegroundFilename = badge.ForegroundFilename || "";
                template.ForegroundBadgeId = badge.ForegroundBadgeId || "";
                template.save(createTranslation(template, bCallback));
            });
        };
        if (!group.BadgeDefaults.length) {
            console.log('Group: ' + group.GroupName + ' has no badge defaults');
            return callback();
        }
        Async.each(group.BadgeDefaults, function (badge, badgeCallback) {
            if (badge.Type === 'Anniversary') {
                if (group.SystemRecognitionTemplates && group.SystemRecognitionTemplates.AnniversaryTemplateId) {
                    EntityCache.RecognitionTemplate.update({
                        hgId: group.SystemRecognitionTemplates.AnniversaryTemplateId
                    }, {
                        $set: {
                            DefaultBadge: true,
                            Type: 'Anniversary'
                        }
                    }, badgeCallback);
                } else {
                    console.log('Anniversary Template missing for: ' + group.GroupName);
                    badgeCallback();
                }
            } else {
                createBadge(badge, badgeCallback);     
            }
        }, callback);
    }
    function createDefaultBadges(callback) {
        EntityCache.Group.find({}, function (error, groups) {
            if (error || !groups.length) {
                return callback(error);
            }
            Async.each(groups, createDefaultBadge, callback);
        });
    }
    this.Run = function (fcallback) {
        Async.series([
            addTranslationIndex,
            createDefaultBadges,
            changeTangoEPTemplateId,
            setLocationDefaults
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
