load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

// Changing the Recognition Category from Everyday to System for all (welcome, anniversary and birthday) recognitions
// created in april to present
var april = new Date('4/1/2014').getTime();
var query = {
    CreatedDate : { $gte : april},
    "Template.Category" : "Everyday",
    'Template.Title' : { $in : [
            'Happy Anniversary!', 
            'Happy Anniversary',
            'Anniversary Badge', 
            'Welcome Badge',
            'Happy Birthday',
            'Welcome to K2 Engage!',
            'Welcome to GA Works!',
            'Welcome to Allianz!',
            'Welcome to Keno Kozie!',
            'Welcome to ACQnowledge!',
            'Welcome to HighGround!',
            'Welcome to Fooda!',
            'Welcome to springboard!',
            'Welcome to Podium!',
            'Welcome to Karma Connection!',
            'Welcome to Pace. Purpose. Performance.',
            'Birthday Badge',
            'Happy Birthday!'
    ]}
}
db.Recognition.update(query, {$set : {'Template.Category' :  'System'}}, {multi : true});
