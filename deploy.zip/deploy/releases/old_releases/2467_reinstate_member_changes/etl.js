/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function approveAdminPendingUsers(callback) {
        EntityCache.Member.update({
            MemberShipStatus: 'PendingAdminApprove',
       }, {
            $set: {
                MemberShipStatus: 'Active',
                RolesInGroup: ['Employee']
            }
       }, {
            $multi: true
       }, callback);
    }
    function offBoardedUserPendingApprove(callback) {
        EntityCache.Member.update({
            MemberShipStatus: {$in: ['PendUserAccept', 'UserReject']},
       }, {
            $set: {
                MemberShipStatus: 'OffBoarded',
                RolesInGroup: ['OffBoarded']
            }
       }, {
            $multi: true
       }, callback);
    }
    this.Run = function (fcallback) {
        Async.series([
            approveAdminPendingUsers,
            offBoardedUserPendingApprove
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
