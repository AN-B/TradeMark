//populate UserId for review people
"use hgcommon"
db.MemberActivityReport.drop();
db.carts.drop();
db.inventoryitems.drop();
db.PaymentProfile.drop();

members = db.Member.aggregate({$match: {}}).result;

function resolveUserIdByMemberId(memberId) {
    for (mIndex = 0; mIndex < members.length; mIndex += 1) {
        if (members[mIndex].hgId === memberId) {
            return members[mIndex].UserId;
        }
    }
}

function populateOnePeopleUserId(people) {
    userId = resolveUserIdByMemberId(people.MemberId);
    people.UserId = userId;
}

function updateOneReviewUserId(review) {
    print(review.hgId);
    peoples = review.Peoples;
    for (pIndex = 0; pIndex < peoples.length; pIndex += 1) {
        populateOnePeopleUserId(peoples[pIndex]);
    }
    db.PerformanceReview.update({'hgId' : review.hgId}, {$set : {'Peoples' : peoples}});
}
"use hgperform"
reviews = db.PerformanceReview.aggregate({$match: {}}).result;

for (i = 0; i < reviews.length; i += 1) {
    updateOneReviewUserId(reviews[i]);
}

// add a new FeatureFlag for HighGround only
// PRODUCTION
"use hgcommon"
db.Group.update({HGAccountId: 'HG201300001'}, {$addToSet :
    {
        'Preference.FeatureFlags' : {
            FeatureName : 'IsFoundingCompany',
            FeatureEnabled : true
        }
    }
});

// DEMO
db.Group.update({HGAccountId: 'HG2013D0001'}, {$addToSet :
{
    'Preference.FeatureFlags' : {
        FeatureName : 'IsFoundingCompany',
        FeatureEnabled : true
    }
}
});
// QA
// UAT
// DEV


// add new environment variable for production
// heroku config:set MAX_WORKERS=4 --app hgnprod

//fix birthday by remvoing the time part
db.UserInfo.find().forEach(
    function (userInfo) {
        hgId = userInfo.hgId;
        oldBirthdayTimestamp = userInfo.UserPersonal.Birthdate;
        oldBirthdate = new Date(oldBirthdayTimestamp);
        month = oldBirthdate.getMonth();
        year = oldBirthdate.getUTCFullYear();
        day = oldBirthdate.getDate();
        newBirthDate = new Date(year, month, day);
        // print(oldBirthdate);
        // print(newBirthDate);
        // print('');
        db.UserInfo.update({'hgId' : hgId}, {$set : {'UserPersonal.Birthdate' : newBirthDate.getTime()}});
    }
)

db.Member.find().forEach(
    function (member) {
        hgId = member.hgId;
        oldAnniversaryTimestamp = member.StartingDate;
        oldAnniversaryDate = new Date(oldAnniversaryTimestamp);
        month = oldAnniversaryDate.getMonth();
        year = oldAnniversaryDate.getUTCFullYear();
        day = oldAnniversaryDate.getDate();
        newAnniversaryDate = new Date(year, month, day);
        // print(oldAnniversaryDate);
        // print(newAnniversaryDate);
        // print('');
        db.Member.update({'hgId' : hgId}, {$set : {'StartingDate' : newAnniversaryDate.getTime()}});
    }
)

// POST Application Deployment
// Run Report Aggregation for hgreports User Activity Collection
// http://app.highground.com/svc/Report/BuildGroupUserSystemActivityReport?StartDate=1357020000000&EndDate=1388469600000

