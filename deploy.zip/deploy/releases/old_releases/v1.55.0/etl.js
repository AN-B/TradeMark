load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgfinance");

db.CreditAccount.remove({OwnerId : null});

switchDB("hgperka");

var productOrders = db.ProductOrder.find();
var productItems = db.ProductItem.find();

switchDB('hgcommon');

var memberUserId = {};
db.Member.find({}).forEach(function (item) {
    if (!memberUserId[item.GroupId + '.' + item.UserId]) {
        memberUserId[item.GroupId + '.' + item.UserId] = item.hgId;
    }
});


switchDB("hgreports");

function getJustUTCDate(d) {
 	return new Date(new Date(d).toString().substring(0, 15)); 	
}

function saveMemberMetrics(params) {
	var query = {p : params.Date, g : params.GroupId, m : params.MemberId, c : params.Category};
	var options = {upsert: true};
	var update = {$inc : { t : 1}};
	printjson(query);
	printjson(update); 
	db.MetricsMember.update(query, update, options);
}

function extractProductItems(item) {
	saveMemberMetrics( {
		Date : getJustUTCDate(item.CreatedDate), 
		GroupId : item.GroupId,
		MemberId : memberUserId[item.GroupId + '.' + item.ModifiedBy],
		Category : (item.Status === 'Archived') ? 'DeleteProductItem' :  'CreateProductItem'
	});
}

function extractProductOrders(item) {
	// add user that placed the order
	saveMemberMetrics( {
		Date : getJustUTCDate(item.CreatedDate), 
		GroupId : item.ProductItem.GroupId,
		MemberId : item.Requester.MemberId,
		Category : 'PlaceItemOrder'
	});
	
	// add activity after order
	if (item.Status !== 'Ordered') {
		saveMemberMetrics( {
			Date : getJustUTCDate(item.ModifiedDate), 
			GroupId : item.ProductItem.GroupId,
			MemberId : memberUserId[item.ProductItem.GroupId + '.' + item.ModifiedBy],
			Category : (item.Status === 'Fulfilled') ? 'FulfillOrder' :  'CancelOrder'
		});
	}
}

var query = {
	c : { $in : ['DeleteProductItem', 'CreateProductItem', 
		'FulfillOrder', 'PlaceItemOrder', 'CancelOrder'] }
};
db.MetricsMember.remove(query);

for (i = 0; i < productItems.length(); i += 1) {
	extractProductItems(productItems[i]);
}

for (i = 0; i < productOrders.length(); i += 1) {
	extractProductOrders(productOrders[i]);
}