load("../../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Job.remove({JobName : 'DeliverPendingGoalCycles'});
db.Job.insert({
    JobName : 'DeliverPendingGoalCycles',
    MethodName : 'DeliverPendingGoalCycles',
    PeriodType : 'Daily',
    Hour : 2,
    LatestTriggerDate : 0
});
