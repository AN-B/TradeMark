var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function removeTokens(callback) {
        var batches = [],
            userList = [],
            cursor = EntityCache.Member.find({
                GroupName: "United Airlines",
                MembershipStatus: "InActive"
            }, {
                UserId: 1
            }, {
                lean: true
            }).cursor({batchSize: 250});
        cursor.eachAsync(function (item) {
            userList.push(item.UserId);
            if (userList.length === 1000) {
                batches.push(userList.splice(0));
                console.log('batch: ' + batches.length);
                userList.length = 0;
            }
        }).then(function () {
            batches.push(userList);
            console.log('batch: ' + batches.length);
            Async.forEachLimit(batches, 10, function (b, aCb) {
                console.log('size: ' + b.length);
                EntityCache.UserInfoWithToken.remove({
                    hgId: {$in: b}
                }, function (err) {
                    if (err) {
                        return aCb(err);
                    }
                    EntityCache.UserSecurityWithToken.remove({
                        hgId: {$in: b}
                    }, function (err) {
                        if (err) {
                            return aCb(err);
                        }
                        aCb();
                    });
                });
            }, function (err) {
                if (err) {
                    return callback(err);
                }
                callback();
            });
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            removeTokens
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
