/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');
      
    function addSurveyIndexes(callback) {
        Async.series([
            (function(fcallback) {
                EntityCache.SurveyAnswer.db.collections.SurveyAnswer.ensureIndex({
                    AccessCode: 1,
                    GroupId: 1,
                    Type: 1,
                    Status: 1
                }, {name: 'AccessCodeIndex', background: true, sparse: true}, fcallback);
            })
        ], callback);
    }
    this.Run = function (fcallback) {
        Async.series([
            addSurveyIndexes
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();