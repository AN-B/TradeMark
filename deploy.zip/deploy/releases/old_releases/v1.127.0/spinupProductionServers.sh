heroku ps:scale web=5 --app hgnprod
heroku ps:scale web=2 --app hgapiprod
heroku ps:scale web=2 --app hgmoprod
heroku ps:scale web=3 worker=1 --app hgesbprod
heroku maintenance:off --app hgnprod
heroku maintenance:off --app hgapiprod
heroku maintenance:off --app hgmoprod
heroku maintenance:off --app hgesbprod
