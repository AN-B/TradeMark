heroku ps:scale web=0 --app hgndemo
heroku ps:scale web=0 --app hgapidemo
heroku ps:scale web=0 --app hgmodemo
heroku ps:scale web=0 worker=0 --app hgesbdemo
heroku maintenance:on --app hgndemo
heroku maintenance:on --app hgapidemo
heroku maintenance:on --app hgmodemo
heroku maintenance:on --app hgesbdemo

heroku ps:scale web=0 --app hgnst
heroku ps:scale web=0 --app hgapist
heroku ps:scale web=0 --app hgmost
heroku ps:scale web=0 worker=0 --app hgesbst
heroku maintenance:on --app hgnst
heroku maintenance:on --app hgapist
heroku maintenance:on --app hgmost
heroku maintenance:on --app hgesbst
