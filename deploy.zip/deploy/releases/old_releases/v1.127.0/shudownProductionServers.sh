heroku ps:scale web=0 --app hgnprod
heroku ps:scale web=0 --app hgapiprod
heroku ps:scale web=0 --app hgmoprod
heroku ps:scale web=0 worker=0 --app hgesbprod
heroku maintenance:on --app hgnprod
heroku maintenance:on --app hgapiprod
heroku maintenance:on --app hgmoprod
heroku maintenance:on --app hgesbprod
