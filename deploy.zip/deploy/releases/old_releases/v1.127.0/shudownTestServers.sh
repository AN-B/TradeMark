heroku ps:scale web=0 --app hgnpoc
heroku ps:scale web=0 --app hgapipoc
heroku ps:scale web=0 worker=0 --app hgesbpoc
heroku maintenance:on --app hgnpoc
heroku maintenance:on --app hgapipoc
heroku maintenance:on --app hgesbpoc

heroku ps:scale web=0 --app hgntron
heroku ps:scale web=0 --app hgapitron
heroku ps:scale web=0 worker=0 --app hgesbtron
heroku maintenance:on --app hgntron
heroku maintenance:on --app hgapitron
heroku maintenance:on --app hgesbtron

heroku ps:scale web=0 --app hgnborg
heroku ps:scale web=0 --app hgmoborg
heroku ps:scale web=0 worker=0 --app hgesbborg
heroku maintenance:on --app hgnborg
heroku maintenance:on --app hgmoborg
heroku maintenance:on --app hgesbborg

heroku ps:scale web=0 --app hgncylon
heroku ps:scale web=0 worker=0 --app hgesbcylon
heroku maintenance:on --app hgncylon
heroku maintenance:on --app hgesbcylon

heroku ps:scale web=0 --app hgnripley
heroku ps:scale web=0 worker=0 --app hgesbripley
heroku maintenance:on --app hgnripley
heroku maintenance:on --app hgesbripley

heroku ps:scale web=0 --app hgnscully
heroku ps:scale web=0 worker=0 --app hgesbscully
heroku maintenance:on --app hgnscully
heroku maintenance:on --app hgesbscully

heroku ps:scale web=0 --app hgntrinity
heroku ps:scale web=0 worker=0 --app hgesbtrinity
heroku maintenance:on --app hgntrinity
heroku maintenance:on --app hgesbtrinity

heroku ps:scale web=0 --app hgnqa
heroku ps:scale web=0 --app hgapiqa
heroku ps:scale web=0 --app hgmoqa
heroku ps:scale web=0 worker=0 --app hgesbqa
heroku maintenance:on --app hgnqa
heroku maintenance:on --app hgapiqa
heroku maintenance:on --app hgmoqa
heroku maintenance:on --app hgesbqa

heroku ps:scale web=0 --app hgnuat
heroku ps:scale web=0 --app hgapiuat
heroku ps:scale web=0 --app hgmouat
heroku ps:scale web=0 worker=0 --app hgesbuat
heroku maintenance:on --app hgnuat
heroku maintenance:on --app hgapiuat
heroku maintenance:on --app hgmouat
heroku maintenance:on --app hgesbuat
