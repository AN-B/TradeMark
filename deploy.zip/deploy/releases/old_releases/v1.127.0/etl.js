var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function adGroupIndex(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.Group.db.collections.Group.ensureIndex({
                    Status: 1
                }, {name: 'StatusIndex', background: true }, callback);
            })
        ], fcallback);
    }
    this.Run = function (callback) {
        async.series([
            adGroupIndex
        ], callback);
    };
};

module.exports = new HgMigrationFile();