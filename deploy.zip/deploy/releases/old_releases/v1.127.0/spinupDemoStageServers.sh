heroku ps:scale web=3 --app hgndemo
heroku ps:scale web=1 --app hgapidemo
heroku ps:scale web=1 --app hgmodemo
heroku ps:scale web=2 worker=1 --app hgesbdemo
heroku maintenance:off --app hgndemo
heroku maintenance:off --app hgapidemo
heroku maintenance:off --app hgmodemo
heroku maintenance:off --app hgesbdemo

heroku ps:scale web=1 --app hgnst
heroku ps:scale web=1 --app hgapist
heroku ps:scale web=1 --app hgmost
heroku ps:scale web=1 worker=1 --app hgesbst
heroku maintenance:off --app hgnst
heroku maintenance:off --app hgapist
heroku maintenance:off --app hgmost
heroku maintenance:off --app hgesbst
