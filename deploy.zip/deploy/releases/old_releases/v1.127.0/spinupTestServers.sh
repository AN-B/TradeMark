heroku ps:scale web=1 --app hgnpoc
heroku ps:scale web=1 --app hgapipoc
heroku ps:scale web=1 worker=1 --app hgesbpoc
heroku maintenance:off --app hgnpoc
heroku maintenance:off --app hgapipoc
heroku maintenance:off --app hgesbpoc

heroku ps:scale web=1 --app hgntron
heroku ps:scale web=1 --app hgapitron
heroku ps:scale web=1 worker=1 --app hgesbtron
heroku maintenance:off --app hgntron
heroku maintenance:off --app hgapitron
heroku maintenance:off --app hgesbtron

heroku ps:scale web=1 --app hgnborg
heroku ps:scale web=1 --app hgmoborg
heroku ps:scale web=1 worker=1 --app hgesbborg
heroku maintenance:off --app hgnborg
heroku maintenance:off --app hgmoborg
heroku maintenance:off --app hgesbborg

heroku ps:scale web=1 --app hgncylon
heroku ps:scale web=1 worker=1 --app hgesbcylon
heroku maintenance:off --app hgncylon
heroku maintenance:off --app hgesbcylon

heroku ps:scale web=1 --app hgnripley
heroku ps:scale web=1 worker=1 --app hgesbripley
heroku maintenance:off --app hgnripley
heroku maintenance:off --app hgesbripley

heroku ps:scale web=1 --app hgnscully
heroku ps:scale web=1 worker=1 --app hgesbscully
heroku maintenance:off --app hgnscully
heroku maintenance:off --app hgesbscully

heroku ps:scale web=1 --app hgntrinity
heroku ps:scale web=1 worker=1 --app hgesbtrinity
heroku maintenance:off --app hgntrinity
heroku maintenance:off --app hgesbtrinity

heroku ps:scale web=1 --app hgnqa
heroku ps:scale web=1 --app hgapiqa
heroku ps:scale web=1 --app hgmoqa
heroku ps:scale web=1 worker=1 --app hgesbqa
heroku maintenance:off --app hgnqa
heroku maintenance:off --app hgapiqa
heroku maintenance:off --app hgmoqa
heroku maintenance:off --app hgesbqa

heroku ps:scale web=1 --app hgnuat
heroku ps:scale web=1 --app hgapiuat
heroku ps:scale web=1 --app hgmouat
heroku ps:scale web=1 worker=1 --app hgesbuat
heroku maintenance:off --app hgnuat
heroku maintenance:off --app hgapiuat
heroku maintenance:off --app hgmouat
heroku maintenance:off --app hgesbuat
