var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async'),
        guidMap = {
            uat: "683f1480-fc17-11e5-abd8-417de3033678",
            scully: "1a6c9ea0-fc1f-11e5-a646-6defec63a62d",
            demo: "f4669f20-fc1f-11e5-bfcc-5fa9a577457d",
            prod: "a1d11fc0-fc23-11e5-8067-6b40370d09e5",
            st: "90e7e680-fc23-11e5-b8bd-0503fd156298",
            poc: "b9495470-fc1d-11e5-ba57-733cded660f0",
            tron: "f22f85c0-fc1d-11e5-b4b8-812742960550",
            borg: "1af41390-fc1e-11e5-aee9-c1437f3d85a7",
            cylon: "6a54f800-fc1e-11e5-8872-0f1d92296a69",
            ripley: "783de990-fc1e-11e5-8ba3-b10f92735ff9",
            dev: "0b9a3010-fc22-11e5-a845-f5dfcf51dc30",
            qa: "e0640d60-fc1e-11e5-989a-7da07d3221d6",
            local: "484b2f90-fc23-11e5-a634-bd9dcae37e9b"
        };
    function updateDismissedAlertsJob(callback) {
        // delete the job first if it exists to allow running this multiple times
        EntityCache.Job.remove({JobName: 'UpdateDismissedAlerts'}, function () {
            var job = new EntityCache.Job({
                hgId: guidMap[process.env.BUILD_ENV],
                JobName: 'UpdateDismissedAlerts',
                MethodName: 'UpdateDismissedAlerts',
                PeriodType: 'Daily',
                Hour: 1,
                LatestTriggerDate: 0
            });
            job.save(callback);
        });
    }

    function addGoalReportIndex(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.GoalCycleParticipant.db.collections.GoalCycleParticipant.ensureIndex({
                    GroupId: 1,
                    CycleId: 1,
                    Status: 1
                }, {name: 'ReportIndex', background: true}, callback);
            })
        ], fcallback);
    }

    this.Run = function (callback) {
        async.series([
            updateDismissedAlertsJob,
            addGoalReportIndex
        ], callback);
    };
};

module.exports = new HgMigrationFile();
