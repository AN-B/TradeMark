/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
      Async = require('async');

    function addGroupIndex(callback) {
        EntityCache.Group.db.collections.Group.ensureIndex({
            GroupName : 1,
            Status : 1
        }, {name : 'CoreDocIndex' }, callback);
    }
    function addTeamIndex(callback) {
        EntityCache.Team.db.collections.Team.ensureIndex({
            GroupId : 1,
            Name : 1,
            Type : 1,
            Status : 1
        }, {name : 'CoreDocIndex' }, callback);
    }
    function addTrackCoreDocIndex(callback) {
        EntityCache.CareerTrack.db.collections.CareerTrack.ensureIndex({
            "CareerTrackTemplate.GroupId" : 1,
            "CreatedDate" : 1
        }, {name : 'CoreDocIndex' }, callback);
    }
    this.Run = function (fcallback) {
      Async.series([
          addGroupIndex,
          addTeamIndex,
          addTrackCoreDocIndex,
      ], function (error, results) {
        fcallback(error, results);
      });
    };
};
module.exports = new HgMigrationFile();