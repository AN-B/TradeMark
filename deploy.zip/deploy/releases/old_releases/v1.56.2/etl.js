load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

// get all department ids
var departments = db.Team.find({Status : 'Active',Type : 'Department'}, {hgId : 1}).toArray();
var departmentIds = departments.map(function (item) { return item.hgId;})

// remove pinned departments
db.Member.update({}, {$pull : {PinnedTeamIds : { $in : departmentIds}}, $set :  { ModifiedDate : new Date().getTime() }}, {multi : true});

// remove unpinned departments
db.Member.update({}, {$pull : {UnPinnedTeamIds : { $in : departmentIds}}, $set :  { ModifiedDate : new Date().getTime() }}, {multi : true});

// remove all departmentIds
db.Team.remove({Status : 'Active',Type : 'Department'});
