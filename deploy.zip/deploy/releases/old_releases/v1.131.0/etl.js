/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function approveAdminPendingUsers(callback) {
        EntityCache.Member.update({
            MemberShipStatus: 'PendingAdminApprove'
       }, {
            $set: {
                MemberShipStatus: 'Active',
                RolesInGroup: ['Employee']
            }
       }, {
            $multi: true
       }, callback);
    }

    function offBoardedUserPendingApprove(callback) {
        EntityCache.Member.update({
            MemberShipStatus: {$in: ['PendUserAccept', 'UserReject']}
       }, {
            $set: {
                MemberShipStatus: 'OffBoarded',
                RolesInGroup: ['OffBoarded']
            }
       }, {
            $multi: true
       }, callback);
    }

    function removeUnimportantNotification(callback) {
        EntityCache.Notification.remove({
            Important: {$ne: true},
            "Event.Name": {$ne: "RecognitionReceived"}//this is used for modal
        }, callback);
    }

    function removeCompletedAlerts(callback) {
        EntityCache.ManagerAlert.remove({
            Status: {$in: [ 'Deleted', 'Completed']},
            ModifiedDate: {$lte: Date.now() - 2592000000} // 30 days
        }).exec();
        callback();
    }

    function addMonthlyArchiveJob (callback) {
        EntityCache.Job.remove({JobName: 'RemoveCompletedManagerAlerts'}, function (error) {
            if (error) {
                return callback(error);
            }
            var job = new EntityCache.Job({
                hgId: 'a12396e0-ebaa-11e5-89be-89f1d0484f37',
                JobName: 'RemoveCompletedManagerAlerts',
                MethodName: 'RemoveCompletedManagerAlerts',
                PeriodType: 'Monthly',
                Day: 1,
                Hour: 11,
                LatestTriggerDate: 0
            });
            job.save(function (error) {
                if (error){
                    return callback(error);
                }
                callback();
            });
        });
    }

    function addSuppressedEmailJob(callback) {
        EntityCache.Job.remove({JobName: 'SuppressedEmail'}, function (error) {
            if (error) {
                return callback(error);
            }
            var job = new EntityCache.Job({
                hgId: 'a12396e1-ebaa-11e5-89be-89f1d0484f37',
                JobName: 'SuppressedEmail',
                MethodName: 'SuppressedEmail',
                PeriodType: 'Daily',
                Hour: 8,
                LatestTriggerDate: 0
            });
            job.save(function (error) {
                if (error) {
                    return callback(error);
                }
                callback();
            });
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            approveAdminPendingUsers,
            offBoardedUserPendingApprove,
            removeUnimportantNotification,
            removeCompletedAlerts,
            addMonthlyArchiveJob,
            addSuppressedEmailJob
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
