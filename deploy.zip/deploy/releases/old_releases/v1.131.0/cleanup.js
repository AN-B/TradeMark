load('../../db-scripts/commonDB.js');
setEnv("local");

//defrag collection
db.runCommand ({compact: 'Notification', force: true});

//defrag collection
db.runCommand ({compact: 'ManagerAlert', force: true});
