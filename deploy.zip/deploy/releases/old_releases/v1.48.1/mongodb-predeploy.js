load("commonDB.js");

setEnv("st");

switchDB("hgcommon");

var query = {
        //Status: { '$ne': 'Deleted' },
        //GroupId : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
        //Name : "Regression  testing",
        //"TeamMembers.MemberId" : "2331f5a1-9cd5-11e2-a3a4-25024474fe63"
    },
    project = {
        _id : 0,
        GroupName : 1,
        hgId : 1,
        Name : 1,
        TeamMembers : 1,
        Type : 1,
        Description : 1
    },
    arr = [],
    key,
    dupes = {},
    dupeUsersInTeam;

db.Team.find(query).forEach(function(item) {
    item.TeamMembers.forEach(function (itemTeamMembers) {
        if (!(itemTeamMembers === null || itemTeamMembers.MemberId === undefined || itemTeamMembers.MemberId === null)) {
            if (!dupes[item.Type + '.' + item.Name + '.' + itemTeamMembers.MemberId]) {
                dupes[item.Type + '.' + item.Name + '.' + itemTeamMembers.MemberId] =  {
                    GroupName : item.GroupName,
                    GroupId : item.GroupId,
                    TeamName : item.Name,
                    Count : 1,
                    TeamHgId : item.hgId,
                    MemberId : itemTeamMembers.MemberId,
                    MemberFullName : itemTeamMembers.MemberFullName,
                    Type: item.Type
                };
            } else {
                dupes[item.Type + '.' + item.Name + '.' + itemTeamMembers.MemberId].Count += 1;
            }
        }
    });
});

for (key in dupes) {
    if (dupes.hasOwnProperty(key)) {
        arr.push(dupes[key]);
    }
}

dupeUsersInTeam = arr.filter(function(item) { return item.Count > 1;});
printjson(dupeUsersInTeam);


//Fix Data   <------
// dupeUsersInTeam.forEach(function (item) {
//     var team = db.Team.findOne({hgId : item.TeamHgId}), deleteCount = 0;
//     for (i = 0, len = team.TeamMembers.length; i < len; i +=1) {
//         if (!(team.TeamMembers[i] == null || team.TeamMembers[i].MemberId === null || team.TeamMembers[i].MemberFullName === null)) {
//             print('Bad Data without MemberId');
//             printjson(team.TeamMembers[i]);
//         } else {
//             if (team.TeamMembers[i].MemberId === item.MemberId) {
//                 if (item.Count - deleteCount > 1) {
//                     print('deleting: ' + team.TeamMembers[i].MemberFullName + ' from Team: ' + item.TeamName);
//                     delete team.TeamMembers[i];    
//                     deleteCount += 1;
//                 }
//             }
//         }
//     }
//     db.Team.save(team);
// });
