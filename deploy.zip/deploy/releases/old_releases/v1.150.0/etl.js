/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');
    
    function updateRecognitionCommentCount(batchId, callback) {
        EntityCache.Comment.count({
            Status: 'Active',
            EntityId: batchId._id
        }, function (error, commentCount) {
            if (error || !commentCount) {
                return callback(error);
            }
            EntityCache.Recognition.update({
                BatchId: batchId._id
            }, {
                $set: {
                    CommentCount: commentCount
                }
            }, {
                multi: true
            }, callback);
        });
    }

    function updateRecognition(callback) {
        var nRecognition = 1,
            skip = 0;
        Async.whilst(
            function () {
                return nRecognition > 0;
            },
            function (scallback) {
                EntityCache.Recognition.aggregate([
                    {$match:{
                        ModifiedDate: {$gt: 1469687741899}, //Last recognition given yesterday 
                        Status: 'Active'
                    }},
                    {$group: {
                        _id: "$BatchId"
                    }},
                    {$skip: skip},
                    {$limit: 1000}
                ], function (error, recognitions) {
                    if (error) {
                        return scallback(error);
                    }
                    skip += recognitions.length;
                    console.log('processing:', skip);
                    nRecognition = recognitions.length;
                    if (!recognitions.length) {
                        return scallback();
                    }
                    Async.each(recognitions, updateRecognitionCommentCount, scallback);
                });
            },
            callback
        );
    }

    function addEventBusItemArchiveIndex(callback) {
        EntityCache.EventBusItemArchive.db.collections.EventBusItemArchive.ensureIndex({
            hgId: 1
        }, {
            name: 'EventBusItemArchiveIndex',
            background: true
        }, callback);
    }

    function removeProcessYammerUserIdsJob(callback) {
        EntityCache.Job.remove({JobName: 'ProcessYammerUserIds'}, callback);
    }

    function addProcessYammerUserIdsJob(callback) {
        var job = EntityCache.Job({
            Hour: 22,
            JobName: 'ProcessYammerUserIds',
            LatestTriggerDate: 0,
            MethodName: 'ProcessYammerUserIds',
            PeriodType : 'Daily'
        });
        job.save(callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            updateRecognition,
            addEventBusItemArchiveIndex,
            removeProcessYammerUserIdsJob,
            addProcessYammerUserIdsJob
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
