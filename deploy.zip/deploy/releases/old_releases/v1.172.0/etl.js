var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function insertFeedbackGuide(callback) {
        var guide = new EntityCache.FeedbackGuide({
           GroupId : "c8bee080-8b17-11e6-869b-0dc5348a3102",
           Type : "SelfEvaluation",
           FileName : "CSH_Check_In_Guide.pdf",
           hgId : 'df30c5a8-d9cc-11e6-ad34-878f7215ff89'
        });
        guide.save(callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            insertFeedbackGuide
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
