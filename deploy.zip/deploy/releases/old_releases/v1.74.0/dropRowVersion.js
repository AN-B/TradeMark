load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgcommon');

db.RowVersion.drop();
