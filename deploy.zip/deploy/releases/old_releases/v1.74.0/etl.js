/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
      Async = require('async');

    function addFeedSearchIndex(callback) {
        EntityCache.FeedSearch.db.collections.FeedSearch.ensureIndex({
            "MemberId" : 1,
            "DefaultSearch" : 1
        }, {name : 'CoreDocIndex' }, callback);
    }
    function addMemberUserIdIndex(callback) {
        EntityCache.Member.db.collections.Member.ensureIndex({
            "UserId" : 1
        }, {name : 'UserIdIndex' }, callback);
    }
    function addUserSecurityUserNameIndex(callback) {
        EntityCache.UserSecurity.db.collections.UserSecurity.ensureIndex({
            "LowercaseUserName" : 1
        }, {name : 'LowercaseUserName' }, callback);
    }
    function dropOldIndexMemberIndexes(mcallback) {
        function removeGroupMemberIndex(callback) {
          EntityCache.Member.db.collections.Member.dropIndex('GroupId_1_MembershipStatus_1', function (error, data) {
            if (error) {
                console.log(error);
            }
            callback();
          });
        }
        function removeManagerMemberIndex(callback) {
          EntityCache.Member.db.collections.Member.dropIndex('MembershipStatus_1_MyManagers.MemberId_1', function (error, data) {
            if (error) {
                console.log(error);
            }
            callback();
          });
        }
        Async.series([
            removeGroupMemberIndex,
            removeManagerMemberIndex
        ], function (error, results) {
          mcallback(error, results);
        });
    }
    function addUserInfoWithTokenUserTokenIndex(callback) {
         EntityCache.UserInfoWithToken.db.collections.UserInfoWithToken.ensureIndex({
            "UserToken" : 1
        }, {name : 'UserTokenIndex' }, callback);
    }
    function addUserInfoWithTokenActAsUserTokenIndex(callback) {
         EntityCache.UserInfoWithToken.db.collections.UserInfoWithToken.ensureIndex({
            "ActAsUserToken" : 1
        }, {name : 'ActAsUserTokenIndex' }, callback);
    }
    /*This Job is for feature/revert_user's_status_to_OffBoarded*/
    function addJobForSetStatusOfMembers(callback) {
        EntityCache.Job.remove({JobName: 'SetStatusToOffboardOfExpiredPendUsers'}, function (error, res) {
            if (error) {
                return callback(error);
            }
            EntityCache.Job.create([{
              JobName : 'SetStatusToOffboardOfExpiredPendUsers',
              MethodName : 'SetStatusToOffboardOfExpiredPendUsers',
              PeriodType : 'Daily',
              Hour : 5,
              LatestTriggerDate : 0
          }], callback);
        });
    }
    this.Run = function (fcallback) {
      Async.series([
          dropOldIndexMemberIndexes,
          addMemberUserIdIndex,
          addFeedSearchIndex,
          addUserSecurityUserNameIndex,
          addJobForSetStatusOfMembers,
          addUserInfoWithTokenUserTokenIndex,
          addUserInfoWithTokenActAsUserTokenIndex
      ], function (error, results) {
        fcallback(error, results);
      });
    };
};
module.exports = new HgMigrationFile();