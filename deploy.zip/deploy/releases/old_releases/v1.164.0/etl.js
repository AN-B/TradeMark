var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function setMemberLastLoginDate(callback) {
        var batchSize = 1000,
            numRecords = batchSize,
            i = -1;
        Async.whilst(
            function () {
                return numRecords >= batchSize;
            },
            function (scallback) {
                i += 1;
                EntityCache.UserInfo.find({
                    LastLoginTime: {
                        $gt: 0
                    }
                })
                    .sort({_id: -1})
                    .skip(i * batchSize)
                    .limit(batchSize)
                    .exec(function (error, users) {
                        if (error) {
                            return scallback(error);
                        }
                        numRecords = users.length;
                        Async.each(users, function (user, eCallback) {
                            EntityCache.Member.update({
                                MembershipStatus: 'Active',
                                UserId: user.hgId
                            }, {
                                $set: {
                                    LastLoginTime: user.LastLoginTime
                                }
                            }, {
                                multi: true
                            }, eCallback);
                        }, scallback);
                    });
            },
            callback
        );
    }
    function addRelevancyIndex(fcallback) {
        EntityCache.MemberRelevancy.db.collections.MemberRelevancy.ensureIndex({
            "MemberId": 1,
            "GroupId": 1,
            "Status": 1,
            "Size" : 1
        }, {name : 'Sgms_index', background: true }, fcallback);
    }
    this.Run = function (fcallback) {
        Async.series([
            setMemberLastLoginDate,
            addRelevancyIndex
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();