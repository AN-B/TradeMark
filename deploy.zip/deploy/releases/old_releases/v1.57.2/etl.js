load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

//Duplicate that should be deleted Record
var query = {
    "hgId" : { $in : [
        "b6f90a16-3da5-11e4-a238-bb3e4bbabc74", //sarah.meyers@agcs.allianz.com already deleted manually
        "33a6c756-3d55-11e4-b01c-5771b15f7faf", // jchaddock@k2help.com"
        "13c834a0-1739-11e4-ab99-4960863b25b2", // susan ritter
        "f8d4cb8f-3d54-11e4-b01c-5771b15f7faf" // kvolery@inwk.com
       ]}
};

//db.UserInfo.find(query);
db.UserInfo.remove(query);


switchDB('hgsecurity');
//db.UserSecurity.find(query);
db.UserSecurity.remove(query);


// susan ritter has two records in Member collection
// deleting account that has the offboard status
switchDB("hgcommon");
var query = {
    hgId : "13c834a2-1739-11e4-ab99-4960863b25b2"
};
//db.Member.find(query);
db.Member.remove(query);
