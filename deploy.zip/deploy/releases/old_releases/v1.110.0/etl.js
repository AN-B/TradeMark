var HgMigrationfile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        uuid = uuid = require('node-uuid'),
        async = require('async'),
        guidMap = {
            qa: "ef263850-71ef-11e5-9984-e584aa7121de",
            uat: "3ac9ef90-70f1-11e5-bfaa-05ed17b669d5",
            demo: "73c5a4b0-70f1-11e5-87a0-5d94e733392a",
            st: "fe060d00-71ef-11e5-9066-6f1341255611",
            prod: "0996b6b0-71f0-11e5-9c81-e798442b521d"
        };

    function addApproverEmailJob(callback) {
        var job = new EntityCache.Job({
            hgId: guidMap[process.env.BUILD_ENV] || uuid.v1(),
            JobName: 'ApproverOKRStatusRecap',
            MethodName: 'ApproverOKRStatusRecap',
            PeriodType: 'Weekly',
            Hour: 5,
            Day: 1,
            LatestTriggerDate: 0
        });
        job.save(callback);
    }

    this.Run = function (callback) {
        async.series([
            addApproverEmailJob
        ], callback);
    };
};

module.exports = new HgMigrationfile();