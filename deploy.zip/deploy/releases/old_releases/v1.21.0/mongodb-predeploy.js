load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Member.update({'EmployeeId' : 'HG001'}, {$addToSet :
    {
        'AddedPermissions' : 'SeeAllCycles'
    }
});



/*
Run - Fix issue not aggregating daily user activity
Changed aggregation to run from October 1 2013 to january 10 2014.

*** NOTE Data is aggregating Large data set (hglog.useractivity), it might take at least 5 minutes.

http://qa.highground.com/svc/Report/BuildGroupUserSystemActivityReport?StartDate=1380603600000&EndDate=1389333600000
http://uat.highground.com/svc/Report/BuildGroupUserSystemActivityReport?StartDate=1380603600000&EndDate=1389333600000
http://app.highground.com/svc/Report/BuildGroupUserSystemActivityReport?StartDate=1380603600000&EndDate=1389333600000

To verify after runing this you should now see daily aggregated data. 
hgreports.GroupUserSystemActivityReport({Type : 'Daily'})

*/