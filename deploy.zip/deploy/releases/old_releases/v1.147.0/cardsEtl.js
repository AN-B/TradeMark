/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function updatePerformCards(callback) {
        EntityCache.PerformanceCard.update({
            $and: [
                {RestrictUsers:{$ne: null}},
                {RestrictUsers:{$size: 0}}
            ]
        }, {
            $set: {
                RestrictUsers: null
            }
        }, {
            multi: true
        }, callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            updatePerformCards
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
