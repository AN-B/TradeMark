/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');
    
    function updateMemberRecongition (member, callback) {
        Async.parallel({
            RecognitionGiven: function (fcallback) {
                EntityCache.Recognition.update({
                    'CreatorMember.GroupId': member.GroupId,
                    'CreatorMember.hgId': member.hgId
                }, {
                    $set: {
                        'CreatorMember.MembershipStatus': 'OffBoarded',
                        'CreatorMember.RolesInGroup': ['OffBoarded']    
                    }
                }, {
                    multi: true
                }, fcallback);
            },
            RecognitionReceived: function (fcallback) {
                EntityCache.Recognition.update({
                    'RecipientMember.GroupId': member.GroupId,
                    'RecipientMember.hgId': member.hgId
                }, {
                    $set: {
                        'RecipientMember.MembershipStatus': 'OffBoarded',
                        'RecipientMember.RolesInGroup': ['OffBoarded']    
                    }
                }, {
                    multi: true
                }, fcallback);
            }
        }, callback);
    }
    
    function updateOffboardedMemberRecognitions(callback) {
        var nMemberRetreived = 1,
            skip = 0;
        Async.whilst(
            function () {
                return nMemberRetreived > 0;
            },
            function (scallback) {
                EntityCache.Member.find({MembershipStatus: 'OffBoarded'})
                    .select('hgId GroupId')
                    .skip(skip)
                    .limit(1000)
                    .exec(function (error, members) {
                        if (error) {
                            return scallback(error);
                        }
                        skip += members.length;
                        console.log('processing:', skip);
                        nMemberRetreived = members.length;
                        if (!members.length) {
                            return scallback();
                        }
                        Async.each(members, updateMemberRecongition, scallback);
                    });
            },
            callback
        );
    }

    function addIndexes(callback) {
        Async.series([
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    'CreatorMember.hgId': 1,
                    'CreatorMember.GroupId': 1,
                }, {name: 'RecognitionGiverIndex', background: true, check_keys: false, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.Recognition.db.collections.Recognition.ensureIndex({
                    'RecipientMember.hgId': 1,
                    'RecipientMember.GroupId': 1,
                }, {name: 'RecognitionReceiverIndex', background: true, check_keys: false}, callback);
            }),
            (function (callback) {
                EntityCache.MemberBookmark.db.collections.MemberBookmark.ensureIndex({
                    MemberId: 1
                }, {name: 'MemberIdIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.MemberBookmark.db.collections.MemberBookmark.ensureIndex({
                    hgId: 1
                }, {name: 'hgIdIndex', background: true}, callback);
            })
        ], callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addIndexes,
            updateOffboardedMemberRecognitions
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
