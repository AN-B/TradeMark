load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hglog");
//Add NotificationAudit
db.NotificationAudit.ensureIndex({'RecipientList.Address' : 1,  CreatedDate : 1});
db.NotificationAudit.ensureIndex({TemplateId : 1, CreatedDate : 1});
db.NotificationAudit.ensureIndex({'RecipientList.Address' : 1, CreatedDate : 1, TemplateId : 1, Subject : 1});

//Metrics Recogntion Migration
//To change local time to UTC :
//sudo ln -sf /usr/share/zoneinfo/UTC /etc/localtime

// recognition migration Change Source Type
//deploy/Analytics/recogntion.js