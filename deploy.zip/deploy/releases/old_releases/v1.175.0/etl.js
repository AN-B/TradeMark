/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    
    function updateUnitedMappingFile(callback) {
        EntityCache.ProvisionFileMap.update({
            GroupName: 'United Airlines'
        }, {
            $set: {
                PreserveRoleForExistingUsers: true,
                PreserveSuppressBirthdayForExistingUsers: true,
                PreserveSuppressAnniversaryForExistingUsers: true,
                "Keys.NewUserName":  "$BLANK",
                "Keys.ManagerUserName": "$BLANK"
            }
        }, function (error, count) {
            if (error) {
                return callback(error)
            }
            if (!count) {
                return callback('Error United Mapping File was not updated');
            }
            callback();
        }); 
    }

    this.Run = function (fcallback) {
        Async.series([
            updateUnitedMappingFile
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();