#!/usr/bin/env bash

##ATTENTION: DO NOT RUN THIS ENTIRE SCRIPT

##Test environment
heroku config:set SFTP_USER=qa@highground.com SFTP_PASSWORD='49Xrp_7VEKnQv$uR3EB4@q' --app hgesbqa
heroku config:set SFTP_USER=qa@highground.com SFTP_PASSWORD='49Xrp_7VEKnQv$uR3EB4@q' --app hgesbuat
heroku config:set SFTP_USER=qa@highground.com SFTP_PASSWORD='49Xrp_7VEKnQv$uR3EB4@q' --app hgesbpoc

## staging and prod
## ADD PROD PASS Before running
heroku config:set SFTP_USER=ftp@highground.com SFTP_PASSWORD=XXXX --app hgesbst
heroku config:set SFTP_USER=ftp@highground.com SFTP_PASSWORD=XXXX --app hgesbprod