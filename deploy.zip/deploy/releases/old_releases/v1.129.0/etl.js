var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addSFTPFolderNameIndex(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.Group.db.collections.Group.ensureIndex({
                    SFTPFolderName: 1
                }, {name: 'SFTPIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.UserInfo.db.collections.UserInfo.ensureIndex({
                    'UserPersonal.PrimaryEmail': 1
                }, {name: 'EmailIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.CareerTrack.db.collections.CareerTrack.ensureIndex({
                    "CareerTrackTemplate.Goal.hgId": 1
                }, {name: 'TrackGoalIndex', background: true, sparse: true}, callback);
            }),
            (function (callback) {
                EntityCache.CareerTrack.db.collections.CareerTrack.ensureIndex({
                    'CareerTrackTemplate.MileStones.hgId': 1
                }, {name: 'MilestoneIndex', background: true}, callback);
            }),
            (function (callback) {
                EntityCache.ProvisionActivity.db.collections.ProvisionActivity.ensureIndex({
                    Type: 1,
                    Notification: 1,
                    "EntityValue.OnBoardNotificationDate": 1
                }, {name: 'ScheduledOffboardIndex', background: true, sparse: true}, callback);
            })
        ], fcallback);
    }
    function setSFTPFolderName(callback) {
        //Set Folder Group existing companys
        if (process.env.BUILD_ENV !== 'prod') {
            return callback();
        }
        var groupFolders = [{
            FolderName: 'allianz',
            GroupName: 'Allianz',
            GroupId: '0d8c43c0-78a5-11e3-a321-c13e2a754199'
        }, {
            FolderName: 'chrsolutions',
            GroupName: 'CHR Solutions',
            GroupId: '625236d0-8141-11e4-b405-63b04526a795'
        }, {
            FolderName: 'horizon',
            GroupName: 'Horizon Pharma',
            GroupId: '1f0f3f10-cc24-11e5-86d3-b95f6e72c983'
        }, {
            FolderName: 'patagonia',
            GroupName: 'Patagonia',
            GroupId: 'eab60220-8fd9-11e5-90ae-5fa4fb51efbe'
        }, {
            Folder: 'cision',
            GroupName: 'Cision',
            GroupId: 'fe39e2d0-6e00-11e5-b6eb-03bc7e835c1b'
        }];
        async.each(groupFolders, function (gf, gCallback) {
            EntityCache.Group.findOneAndUpdate({
                hgId: gf.GroupId
            }, {
                $set: {
                    SFTPFolderName: gf.FolderName
                }
            }, gCallback);
        }, callback);
    }
    function addHRISClientProfile(callback) {
        EntityCache.Group.findOne({
            'Preference.FeatureFlags.FeatureName': 'IsFoundingCompany'
        }, function (error, group) {
            if (error || !group) {
                return callback(error || 'Error Loading IsFoundingCompany');
            }
            EntityCache.ClientProfile.findOne({ClientName: 'HRIS_FILE_UPLOAD'}, function (error, profile) {
                if (error || profile) {
                    return callback(error);
                }
                var clientProfile = new EntityCache.ClientProfile({
                    hgId: 'd2cb4460-e153-11e5-b365-ad8a17d3783a',
                    ClientName: 'HRIS_FILE_UPLOAD',
                    GroupId: group.hgId,
                    APIKey: 'da8da800-e153-11e5-8655-e5f105d7f8af',
                    APIKeyStatus: 'Active',
                    APIKeyVersion: "1.0",
                    AvailableServices: ['EventBus']
                });
                clientProfile.save(callback);
            });
        });
    }

    this.Run = function (callback) {
        async.series([
            addHRISClientProfile,
            addSFTPFolderNameIndex,
            setSFTPFolderName
        ], callback);
    };
};

module.exports = new HgMigrationFile();