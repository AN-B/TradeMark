var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        guid = require('node-uuid'),
        async = require('async');

    function addSuppressedEmailJob(callback) {
        EntityCache.Job.findOne({JobName: 'SuppressedEmail'}, function (error, job) {
            if (error || job) {
                return callback(error);
            }
            var job = new EntityCache.Job({
                hgId: guid.v1(),
                JobName: 'SuppressedEmail',
                MethodName: 'SuppressedEmail',
                PeriodType: 'Daily',
                Hour: 8,
                LatestTriggerDate: 0
            });
            job.save(callback);
        });
    }
    this.Run = function (callback) {
        async.series([
            addSuppressedEmailJob
        ], callback);
    };
};

module.exports = new HgMigrationFile();