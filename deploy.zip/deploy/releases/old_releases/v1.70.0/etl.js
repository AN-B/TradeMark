/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');
    /*
     *  Migration Script Template
     *  You need a run function with callback parameter
     *  Must call the callback function when done.
     */

    function deleteAcquirentDept(callback) {
        var departmentsToDelete = [
            'Z1',
            'Z10',
            'Z11',
            'Z12',
            'Z2',
            'Z3',
            'Z4',
            'Z5',
            'Z6',
            'Z7',
            'Z8',
            'Z9'
        ],
        query,
        update = {
          $set :{
            ModifiedDate : new Date().getTime(),
            Status : 'Deleted'
          }
        };
        EntityCache.Group.findOne({GroupName : 'Acquirent'}, function (error, data) {
            if (error) {
                callback(error);
            } else if (!data) {
                callback();
            } else {
                query = {
                   GroupId : data.hgId,
                   Type : 'Department',
                   Status : "Active",
                   Name : { $in : departmentsToDelete},
                   ChildTeams : {$size : 0}
                },
                EntityCache.Team.update(query, update, {multi : true}, callback);
            }
        });
        
    }
    //Indexes
    function addPerformanceReviewIndex(callback) {
        EntityCache.PerformanceReview.db.collections.PerformanceReview.ensureIndex({
            'Card.GroupId' : 1,
            StatusByAdminView : 1,
            'Peoples.MemberId' : 1
        }, {name : 'CoreDocIndex' }, callback);
    }

    //Execute Query
    this.Run = function (fcallback) {
        Async.series([
            addPerformanceReviewIndex,
            deleteAcquirentDept
        ], fcallback);
    };
};
module.exports = new HgMigrationFile();