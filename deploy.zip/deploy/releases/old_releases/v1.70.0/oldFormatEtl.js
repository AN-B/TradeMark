load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgcommon');

var departmentsToDelete = [
    'Z1',
    'Z10',
    'Z11',
    'Z12',
    'Z2',
    'Z3',
    'Z4',
    'Z5',
    'Z6',
    'Z7',
    'Z8',
    'Z9'
],
update = {
  $set :{
    ModifiedDate : new Date().getTime(),
    Status : 'Deleted'
  }
};
var acquirentGroup = db.Group.findOne({GroupName : 'Acquirent'});
if (acquirentGroup) {
	var query = {
	   GroupId : acquirentGroup.hgId,
	   Type : 'Department',
	   Status : "Active",
	   Name : { $in : departmentsToDelete},
	   ChildTeams : {$size : 0}
	};
	db.Team.update(query, update, {multi : true});	
}

switchDB('hgperform');

db.PerformanceReview.ensureIndex({
    'Card.GroupId' : 1,
    StatusByAdminView : 1,
    'Peoples.MemberId' : 1
}, {name : 'CoreDocIndex' });