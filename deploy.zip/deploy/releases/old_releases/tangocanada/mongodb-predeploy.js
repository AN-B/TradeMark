load("../db-scripts/commonDB.js");
setEnv("qa");

// use hgperka
switchDB('hgperka');
var cards = db.TangoCard.aggregate({$match : {}}).result;

print(cards.length);

cards.forEach(function (card) {
    var denominations = card.Denominations;
    denominations.forEach(function (denomination) {
        if (!denomination.Denomination) {
            denomination.Denomination = denomination.UnitPrice;
            print(denomination.Denomination);
        }
    });
    db.TangoCard.update({hgId : card.hgId}, {$set : {Denominations : denominations}});
    if (!card.Country) {
        db.TangoCard.update({hgId : card.hgId}, {$set : {Country : 'USA'}});
    }
});