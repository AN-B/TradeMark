/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        guid = require('node-uuid');

    function removeCompletedAlerts(callback) {
        EntityCache.ManagerAlert.remove({
            Status: {$in: [ 'Deleted', 'Completed']},
            ModifiedDate: {$lte: Date.now() - 2592000000} // 30 days
        }).exec();
        callback();
    }
    function addMonthlyArchiveJob (callback) {
        EntityCache.Job.remove({JobName: 'RemoveCompletedManagerAlerts'}, function (error) {
            if (error) {
                return callback(error);
            }
            var job = new EntityCache.Job({
                hgId: '91f055c0-e6ee-11e5-a279-0bf1718da929',
                JobName: 'RemoveCompletedManagerAlerts',
                MethodName: 'RemoveCompletedManagerAlerts',
                PeriodType: 'Monthly',
                Day: 1,
                Hour: 11,
                LatestTriggerDate: 0
            });
            job.save(function (error) {
                if (error){
                    return callback(error);
                }
                callback();
            });
        });
    }
    this.Run = function (fcallback) {
        Async.series([
            removeCompletedAlerts,
            addMonthlyArchiveJob
        ], fcallback);
    };
};
module.exports = new HgMigrationFile();