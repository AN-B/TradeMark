/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function removeUnimportantNotification(callback) {
        EntityCache.Notification.remove({
            Important: {$ne: true},
            "Event.Name": {$ne: "RecognitionReceived"}//this is used for modal
        }, callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            removeUnimportantNotification
        ], fcallback);
    };
};
module.exports = new HgMigrationFile();