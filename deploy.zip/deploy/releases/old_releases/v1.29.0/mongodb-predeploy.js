load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

// db.Recognition.find({'Template.Category' : {$exists : false}});
// db.Recognition.find({'Template.Category' : {$nin : ['Everyday', 'Values', 'Achievement', 'System']}});
// db.RecognitionTemplate.find({'Category' : {$nin : ['Everyday', 'Values', 'Achievement', 'System']}});

db.Recognition.update({'Template.Category' : {$nin : ['Everyday', 'Values', 'Achievement', 'System']}}, {$set : {'Template.Category' : 'Everyday'}}, {multi : true});
// db.RecognitionTemplate.update({'Category' : {$nin : ['Everyday', 'Values', 'Achievement', 'System']}}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'Type' : 'Skill'}, {$set : {'Type' : 'Recognition', 'Category' : 'Everyday'}}, {multi : true});

switchDB("hgperform");

db.PerformanceCycle.find({'ManagerCanSeeResponse' : true}).forEach(
    function (cycle) {
        var hgId = cycle.hgId;
        db.PerformanceReview.find({'CycleId' : hgId}).forEach(
            function(review) {
                review.Peoples.forEach(function (person){
                    if (person.PeopleType === 'Manager') {
                        person.CanSeeResponse = true;
                    }
                });

                db.PerformanceReview.update({'hgId' : review.hgId}, {$set : {'Peoples' : review.Peoples}});
            });
    });

//the following script is run only for demo, but i keep them here for the record because it's for this release's feature
// // var groupName = 'Mercury Industries',
// var groupName = 'HG-2',
//     group = db.Group.aggregate({$match : {'GroupName' : groupName}}).result,
//     groupId = group[0].hgId,
//     team = db.Team.find({'GroupId': groupId}, {'Name' : true, 'Type' : true});

// db.Team.update({'GroupId': groupId, 'Name' : {$in : ['Executive', 'Development', 'Sales', 'QA', 'Operations']}}, {$set : {'Type' : 'Department'}}, {multi : true});

