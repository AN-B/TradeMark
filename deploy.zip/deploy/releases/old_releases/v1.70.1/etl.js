load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgcommon');

//remove heartbeat records
db.DBHeartBeat.remove()

//add index on DBHeartBeat
db.DBHeartBeat.ensureIndex({
    'Name' : 1,
}, {name : 'CoreDocIndex' });