load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

//Setting Default OffBoarded Type
// OffBoarded Users --> Unknown
// Not OffBoarded Users --> NotApplicable
db.Member.update({ 'OffBoardType' : { $exists : false}, 'MembershipStatus': 'OffBoarded'}, {$set : { OffBoardType : 'Unknown'}}, {$multi : true})
db.Member.update({ 'OffBoardType' : { $exists : false}, 'MembershipStatus':  { $ne : 'OffBoarded'}}, {$set : { OffBoardType : 'NotApplicable'}}, {$multi : true})

//Setting group status field and setting default Active
db.Group.update({}, { $set : {Status : 'Active'}}, {$multi : true});

//Set Default Team Status
db.Team.update({Status : { $ne : 'Deleted'}}, { $set : {Status : 'Active'}}, {$multi : true});

