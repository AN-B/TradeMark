/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addArchivedRecordIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.ArchiveRecord.db.collections.ArchiveRecord.ensureIndex({
                    "ArchiveId" : 1,
                    "Collection": 1,
                }, {name : 'CoreDocIndex', background: true }, callback);
            })
        ], fcallback);
    }

    function archiveEventBusItems(fcallback) {
        var chunkSize = 1000,
            numItemsArchived = chunkSize,
            totalArchived = 0;
        Async.whilst(
            function () {
                return numItemsArchived === chunkSize;
            },
            function (scallback) {
                EntityCache.EventBusItem.find({Status: 'Processed'})
                    .limit(chunkSize)
                    .exec(function (error, items) {
                        if (error) {
                            return scallback(error);
                        }
                        numItemsArchived = items.length;
                        totalArchived += numItemsArchived;
                        EntityCache.EventBusItemArchive.create(items, function (error) {
                            if (error) {
                                return scallback(error);
                            }
                            EntityCache.EventBusItem.remove({
                                hgId: {
                                    $in: items.map(function (item) {
                                        return item.hgId;
                                    })
                                }
                            }, function (error) {
                                if (error) {
                                    return scallback(error);
                                }
                                console.log('records processed: ' + totalArchived);
                                scallback();
                            });
                        });
                    });
            },
            fcallback
        );
    }

    this.Run = function (fcallback) {
        Async.series([
            addArchivedRecordIndex,
            archiveEventBusItems
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
