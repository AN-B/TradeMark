load("../db-scripts/commonDB.js");
setEnv("st");

switchDB("hgcommon");

db.runCommand({compact: 'EventBusItem', force: true});
db.runCommand({compact: 'NotificationQueueItem', force: true});