load("../db-scripts/commonDB.js");
setEnv("st");

switchDB("hgperka");

var oldGlobalVisa = db.TangoCard.findOne({CardName: "Global Visa"}),
    dryRun = true,
    selEnv = 'st',
    cdn = {
        st: [
            '//d1mdptzm6hyqsk.cloudfront.net',
            '//d11gzz9ueyzwk5.cloudfront.net',
            '//d14l7genrzpehp.cloudfront.net'
        ],
        prod: [
            '//d2m1f7os0jcurd.cloudfront.net',
            '//dwl9fvarlrqri.cloudfront.net',
            '//d16rcxsybf2tyb.cloudfront.net'
        ]
    },
    i = 0,
    newVisa = {
        "CardName" : "Prepaid Visa Reward",
        "Country" : "Global",
        "CreatedBy" : "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
        "CreatedDate" : Date.now(),
        "Denominations" : [
            {
                "CurrencyType" : "USD",
                "MaxPrice" : 100000,
                "MinPrice" : 500,
                "UnitPrice" : 0,
                "Denomination" : -1,
                "SKU" : "PPVV-E-V-STD",
                "Description" : "Prepaid Visa® Reward"
            }
        ],
        "EmailTemplateId" : "33721",
        "ExcludedGroupIds" : [ 
            "7bc84a10-ac49-11e2-816a-81fd71297a71", 
            "021e3890-3376-11e4-bd25-fddc43234b3f", 
            "00198240-dd2f-11e3-93df-ed2289aa62ed", 
            "a951d3d0-1a43-11e3-b544-b5fd63eafa89", 
            "93c913a0-bdf2-11e2-9666-cb9e9195cb36", 
            "28c6a300-d0a3-11e3-9876-450840dd7df6", 
            "51193440-a0c3-11e3-a081-8f99ce572ffe", 
            "0d8c43c0-78a5-11e3-a321-c13e2a754199"
        ],
        "GroupIds" : [
            "all"
        ],
        "ImageUrl" : "https:" + cdn[selEnv][0] + "/giftcard/prepaid-virtual-visa-custom-gift-card.png",
        "ModifiedBy" : "132f9280-bb9a-11e4-a123-b3c1e56907c3",
        "ModifiedDate" : 1426179330628,
        "Type" : "giftcard",
        "hgId" : "8be552e0-3625-11e5-93fc-3bc2b4fc1b8f"
    };

if (!dryRun) {
    db.ArchiveCollection.save(oldGlobalVisa);
    db.TangoCard.remove({CardName: "Global Visa"});
    db.TangoCard.save(newVisa);
}

db.TangoCard.find().forEach(function (card) {
    var index = i % 3;
    print(card.ImageUrl);
    card.ImageUrl = card.ImageUrl.replace('https://hgprod.s3.amazonaws.com', 'https:' + cdn[selEnv][index]);
    print(card.ImageUrl);
    if (!dryRun) {
        db.TangoCard.save(card);
    }
    i += 1;
});
