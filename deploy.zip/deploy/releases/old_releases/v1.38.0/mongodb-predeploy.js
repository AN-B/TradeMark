load("../../db-scripts/commonDB.js");
setEnv("local");

// Before you run this, set you local time to utc
// sudo ln -sf /usr/share/zoneinfo/UTC /etc/localtime

// Run Deploy/Analytics/perform2.js
// Migration of Perform Cards data to new schema


//Fix Metrics Data issue
switchDB("hgreports");
db.MetricsComment.update({s : null}, {$set : {s : 'Web'}}, {multi : true});
db.MetricsRecognition.update({s : { $exists : false}}, { $set : {s : 'Web'}}, {multi : true});
db.MetricsRecognitionShare.update({s : { $exists : false}}, {$set : {s : 'Web'}}, {multi : true});
db.MetricsCongrat.update({s : { $exists : false}}, {$set : {s : 'Web'}}, {multi : true});
db.MetricsDepartment.update({s : { $exists : false}}, {$set : {s : 'Web'}}, {multi : true});