var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function removeEmptyTaggedUser(callback) {
        EntityCache.TaggedUser.remove({$where: "this.Tags.length === 0"}, callback);
    }
    function removeCommentTagReference(callback) {
        EntityCache.TaggedUser.find({$where: "this.Tags.length > 0"}, function (error, tags) {
            if (error) {
                return callback(error);
            }
            EntityCache.Comment.update({
                TaggedUser: {
                    $nin: tags.map(function (item) {
                        return item._id;
                    })}
            }, {
                $unset: {
                    TaggedUser: 1
                }
            }, {
                $multi: true
            }, callback);    
        });
    }
    function changeArrayToSingleObject(callback) {
        EntityCache.Comment.find({TaggedUser: {$exists: true}}, function (error, comments) {
            async.each(comments, function (comment, commentCallback) {
                var v = comment.TaggedUser;
                if (!v) {
                    return commentCallback();
                } else {
                    comment.TaggedUser = null;
                    comment.TaggedUser = v;
                    comment.save(commentCallback);
                }
            }, callback);
        });
    }

    this.Run = function (callback) {
        async.series([
            removeEmptyTaggedUser,
            removeCommentTagReference,
            changeArrayToSingleObject
        ], callback);
    };
};

module.exports = new HgMigrationFile();