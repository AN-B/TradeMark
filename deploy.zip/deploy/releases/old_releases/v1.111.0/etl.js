/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addGoalAlertJob(callback) {
        var job = new EntityCache.Job({
            hgId: '9e8ef8b2-7671-11e5-96f1-012d82ee0a00',
            JobName: 'OkAdhocAlerts',
            MethodName: 'OkAdhocAlerts',
            PeriodType: 'Daily',
            Hour : 2,
            LatestTriggerDate : 0
        });
        job.save(callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addGoalAlertJob
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
