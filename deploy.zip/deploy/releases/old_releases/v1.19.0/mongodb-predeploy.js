load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

// set UserId of the Manager in the Member object
db.Member.find().forEach(
    function (member) {
        hgId = member.hgId;
        if (member.MyManagers && member.MyManagers.length > 0) {
            var managers = [];
            member.MyManagers.forEach(
                function (manager) {
                    user = db.Member.findOne({'hgId' : manager.MemberId}, {'UserId' : true});
                    if (user) {
                        managers.push({
                            MemberId : manager.MemberId,
                            FullName : manager.FullName,
                            UserId : user.UserId
                        });
                    }
                }
            );
            db.Member.update({'hgId' : hgId}, {$set : {'MyManagers' : managers}});
        }
    }
);

//recognition template category fix "Change from Be the CEO of Your Position to Everyday"
db.Recognition.update({hgId : "e67365b0-1c84-11e3-b316-c994c78882ff"}, { $set : {"Template.Category" : "Everyday"}})
db.Recognition.update({hgId : "cbf87ee1-1cb7-11e3-8b76-d75319ece250"}, { $set : {"Template.Category" : "Everyday"}})

// Data cleanup
var members, users, memberRecords, userInfoRecords;
memberRecords = db.Member.aggregate({ $match :{}}).result
userInfoRecords = db.UserInfo.aggregate({ $match :{}}).result

function setRecordHashKeys() {
    members = {};
    users = {};
    for (i = 0; i < memberRecords.length; i += 1) {
        members[memberRecords[i].UserId] = memberRecords[i].hgId;
    }
    for (j = 0; j < userInfoRecords.length; j += 1) {
        users[userInfoRecords[j].hgId] = userInfoRecords[j].UserPersonal.FullName;
    }
}

function getOrphanMembers() {
    var ret = [];
    for (i = 0; i < memberRecords.length; i += 1) {
        if (!users[memberRecords[i].UserId]) {
            ret.push(memberRecords[i]);
        }
    }
    return ret;
}

function getOrphanUsers() {
    var ret = [];
    for (i = 0; i < userInfoRecords.length; i += 1) {
        if (!members[userInfoRecords[i].hgId]) {
            ret.push(userInfoRecords[i]);
        }
    }
    return ret;
}

function trimUserInfoWithToken() {
    var ret = [];
    ret = db.UserInfoWithToken.aggregate([{$group : {_id : {"UserId" : "$hgId"}, Count : {$sum : 1}}}]).result;
    ret.map(function(item) {
        if (item.Count > 1) {
            ret = db.UserInfoWithToken.aggregate({$match : {'hgId' : item._id.UserId}}, {$project :{"hgId" : 1, "LastLoginTime" : 1}}, {$sort : {"LastLoginTime" : -1}}, {$limit : 1})
            if (ret.result[0]) {
                db.UserInfoWithToken.remove({hgId : ret.result[0].hgId, LastLoginTime : { $ne : ret.result[0].LastLoginTime}})
            }
        }
    })
}

function trimUserSecurityWithToken() {
    var ret = [];
    ret = db.UserSecurityWithToken.aggregate([{$group : {_id : {"UserId" : "$hgId"}, Count : {$sum : 1}}}]).result;
    ret.map(function(item) {
        if (item.Count > 1) {
            ret = db.UserSecurityWithToken.aggregate({$match : {'hgId' : item._id.UserId}}, {$project :{"hgId" : 1, "LastRefreshTime" : 1}}, {$sort : {"LastRefreshTime" : -1}}, {$limit : 1})
            if (ret.result[0]) {
                db.UserSecurityWithToken.remove({hgId : ret.result[0].hgId, LastRefreshTime : { $ne : ret.result[0].LastRefreshTime}})
            }
        }
    });
}

function cleanUpOrphanMembers(data) {
    if (data && data.length > 0) {
        print("List of orphan Member records:")
        data.map(function(item) {
            printjson(item);
            db.Member.remove({hgId : item.hgId});
        });
    }
}

function cleanUpOrphanUsers(data) {
    if (data && data.length > 0) {
        print("List of orphan user records:");
        data.map(function(item) {
            printjson("hgId: " + item.hgId);
            db.UserInfo.remove({hgId : item.hgId});
        });
    }
}

function cleanUpOrphanUserSecurity(data) {
    if (data && data.length > 0) {
        print("List of orphan UserSecurity records:");
        data.map(function(item) {
            printjson("hgId: " + item.hgId);
            db.UserSecurity.remove({hgId : item.hgId});
        });
    }
}


var orphanMembers = [], orphanUsers = [], orphanUserSecurity = [];
setRecordHashKeys();
orphanMembers = getOrphanMembers();
orphanUsers = getOrphanUsers();

print('Orphan Members:' + orphanMembers.length);
cleanUpOrphanMembers(orphanMembers);

print('Orphan Users:' + orphanUsers.length);
cleanUpOrphanUsers(orphanUsers);

trimUserInfoWithToken();

//--- CHANGE DATABASE ---//
switchDB("hgsecurity");

orphanUserSecurity = db.UserSecurity.aggregate({$match :{'LowercaseUserName' : '' }}).result;
print('Orphan UserSecurity:' + orphanUserSecurity.length);
cleanUpOrphanUserSecurity(orphanUserSecurity);

trimUserSecurityWithToken();

// add feature flags to allianz group in demo/prod
switchDB("hgcommon");
group = db.Group.findOne({GroupName:"Allianz"});
if (group) {
    db.Group.update({hgId: group.hgId}, {$addToSet: {
        "Preference.FeatureFlags": {$each: [
            {
                FeatureName: 'DisableFeatureByRole',
                FeatureMeta : [
                    {
                        Name: "Roles",
                        Value: "OffBoarded,Employee,Manager,Executive,Owner,Admin"
                    },
                    {
                        Name: "Permissions",
                        Value: "trackTabs.summary,trackTabs.goalTracks,trackTabs.assignTracks,trackTabs.manageTracks,userTabs.recognizeMeLinks"
                    }
                ],
                FeatureEnabled: true
            },
            {
                FeatureName: 'DisableFeatureByRole',
                FeatureMeta : [
                    {
                        Name: "Roles",
                        Value: "OffBoarded,Employee,Manager,Executive,Owner"
                    },
                    {
                        Name: "Permissions",
                        Value: "userTabs.credits,userTabs.teams"
                    }
                ],
                FeatureEnabled: true
            }
        ]}
    }});
}



// 1. remove "hgthank" and "config" database from production - these are both empty and probably created by old code
// 2. add new envioronment variable called MONGODB_HGLOG with replica set connection for the hglog database
// 3. alter all MONGO environment variable settings to include the replica set
