load("../../db-scripts/commonDB.js");
setEnv("qa");

//Before you run this
//change local time to UTC

//sudo ln -sf /usr/share/zoneinfo/UTC /etc/localtime
//
// ---> Run Analytics/migration.js
// Data now includes coaching


switchDB("hgcommon");

var userInfo = {};
db.UserInfo.find({}).forEach(
    function(item) {
        if (!userInfo[item.hgId]) {
            userInfo[item.hgId] = {
                FirstName : item.UserPersonal.FirstName,
                LastName : item.UserPersonal.LastName
            };
        }
    }
);

switchDB("hgfinance");

db.Transaction.find({}).forEach(
    function (item) {
        var updateQuery;
        if (userInfo[item.UserId]) {
            updateQuery = {
                FirstName : userInfo[item.UserId].FirstName,
                LastName : userInfo[item.UserId].LastName
            };
            db.Transaction.update({hgId : item.hgId}, {$set : updateQuery});
        }
    }
);

//just check for userids in transaction that do not exist in userinfo.
var missingUserIdCount = db.Transaction.find({FirstName : {$exists : false}}, {_id : 0, UserId : 1}).count();
print('Found: ' + missingUserIdCount + ' missing userIds in Transaction.');
db.Transaction.find({FirstName : {$exists : false}}, {_id : 0, UserId : 1}).forEach(
    function (item) {
        print('UserId: ' + item.UserId);
    }
);

switchDB("hgperka");

db.PrepaidCard.find({}).forEach(
    function (item) {
        var updateQuery;
        if (userInfo[item.UserId]) {
            updateQuery = {
                FirstName : userInfo[item.UserId].FirstName,
                LastName : userInfo[item.UserId].LastName
            };
            db.PrepaidCard.update({hgId : item.hgId}, {$set : updateQuery});
        }
    }
);

//just check for userids in transaction that do not exist in userinfo.
var missingUserIdCount = db.PrepaidCard.find({FirstName : {$exists : false}}, {_id : 0, UserId : 1}).count();
print('Found: ' + missingUserIdCount + ' missing userIds in PrepaidCard.');
db.PrepaidCard.find({FirstName : {$exists : false}}, {_id : 0, UserId : 1}).forEach(
    function (item) {
        print('UserId: ' + item.UserId);
    }
);

switchDB("hgthanka");

//Set Default Source Fields for historical Data to Web
db.Recognition.update({}, {$set : { Source : 'Web'}}, {multi : true})
db.Comment.update({}, {$set : { Source : 'Web'}}, {multi : true})
db.Congrat.update({}, {$set : { Source : 'Web'}}, {multi : true})

//for TangoCard to go multi-nation
switchDB('hgperka');
var cards = db.TangoCard.aggregate({$match : {}}).result;

print(cards.length);

cards.forEach(function (card) {
    var denominations = card.Denominations;
    denominations.forEach(function (denomination) {
        if (!denomination.Denomination) {
            denomination.Denomination = denomination.UnitPrice;
            print(denomination.Denomination);
        }
    });
    db.TangoCard.update({hgId : card.hgId}, {$set : {Denominations : denominations}});
    if (!card.Country) {
    	db.TangoCard.update({hgId : card.hgId}, {$set : {Country : 'USA'}});
    }
});


// Run Deploy/Analytics/perform.js
// Before you run this, set you local time to utc
// sudo ln -sf /usr/share/zoneinfo/UTC /etc/localtime