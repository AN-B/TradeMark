#!/usr/bin/env bash

##ATTENTION: DO NOT RUN THIS ENTIRE SCRIPT
##UNCOMMENT THE LINES FOR THE SPECIFIC ENV, THEN RUN SCRIPT

##prod
#heroku config:set GRS_STOREFRONT_USER=GSPL3613 --app hgnprod
#heroku config:set GRS_STOREFRONT_USER=GSPL3613 --app hgapiprod
#heroku config:set GRS_STOREFRONT_USER=GSPL3613 --app hgmoprod
#heroku config:set GRS_STOREFRONT_USER=GSPL3613 MAX_WORKERS=2 --app hgesbprod
