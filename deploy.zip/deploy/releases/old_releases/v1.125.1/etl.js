var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addNotificationIndex(fcallback) {
        async.series([
            (function (callback) {
                EntityCache.Notification.db.collections.Notification.ensureIndex({
                    RecipientGroupId: 1,
                    EntityId: 1
                }, {name: 'EntityIndex', background: true }, callback);
            })
        ], fcallback);
    }

    function getUserIndex(callback) {
        EntityCache.Member.find({}, function (error, data) {
            if (error) {
                return callback(error);
            }
            var userIndex = {};
            data.forEach(function (item) {
                userIndex[item.UserId] = {
                    GroupId: item.GroupId
                };
            });
            callback(null, userIndex);
        });
    }

    function updateNotificationReviews(callback) {
        getUserIndex(function (error, userIndex) {
            if (error) {
                return callback(error);
            }
            EntityCache.Notification.find({
                'Event.Name': 'ReviewDelivered',
                Deleted: false
            }, function (error, notifications) {
                if (error) {
                    return callback(error);
                }
                var EntityId;
                async.each(notifications, function (notification, nCallback) {
                    if (!notification.RecipientGroupId) {
                        notification.RecipientGroupId = userIndex[notification.RecipientUserId] ? userIndex[notification.RecipientUserId].GroupId : '';
                    }
                    EntityId = notification.ActionUrl.split("/");
                    if (EntityId && EntityId[4]) {
                        notification.EntityId = EntityId[4];
                    }
                    notification.save(nCallback);
                }, callback);
            });
        });
    }

    this.Run = function (callback) {
        async.series([
            addNotificationIndex,
            updateNotificationReviews
        ], callback);
    };
};

module.exports = new HgMigrationFile();