load('../../db-scripts/commonDB.js');
setEnv("tron");

switchDB("hgcommon");

// Migrate Field forom old Collection to new Collection
var users = db.UserInfo.find();

users.forEach(function (item) {
    if (item.UserPersonal.Birthdate) {
        db.Member.update({
            UserId: item.hgId
        }, {
            $set: {
                Birthdate: item.UserPersonal.Birthdate
            }
        });
    }
});


// update all UserInfoWithToken
var members = db.Member.find();
members.forEach(function (member) {
    db.UserInfoWithToken.update({
        hgId: member.UserId
    }, {
        $set: {
            "UserContext.BirthdateInGroup": member.Birthdate
        }
    }, {multi:true});
});

// Deprecate field from old Collection
var update = {
    $unset: {
        'UserPersonal.Birthdate': ""
    }
};
db.UserInfo.update({}, update, {multi: true});


// reclaim memory to be reused
db.runCommand({compact: 'UserInfo', force :true});
