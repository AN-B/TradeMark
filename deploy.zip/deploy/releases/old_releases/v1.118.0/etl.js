/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function removeMobileGoalFeatureFlag(callback) {
        EntityCache.Group.update({
            'Preference.FeatureFlags': {
                $elemMatch: {
                    FeatureName: 'EnableMobileGoals'
                }
            }
        }, {
            $pull : {
                'Preference.FeatureFlags' : {
                    FeatureName: 'EnableMobileGoals'
                }
            },
            $set :  {
                ModifiedDate : Date.now()
            }
        }, {multi: true}, callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            removeMobileGoalFeatureFlag
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
