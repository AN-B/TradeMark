/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addProvisionIndex(callback) {
        Async.series([
            (function(callback) {
                EntityCache.ProvisionAudit.db.collections.ProvisionAudit.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    FullName: 1,
                    Status: 1,
                    Type: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.Member.db.collections.Member.ensureIndex({
                    GroupId: 1,
                    EmployeeId: 1
                }, {name: 'EmployeeIdIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedMember.db.collections.ProvisionStagedMember.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    UserName: 1,
                    EmpID: 1,
                    ManagerUserName: 1,
                    NewUserName: 1,
                    OffBoardType: 1,
                    Location: 1,
                    USM: 1,
                    InvalidEmail: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedMember.db.collections.ProvisionStagedMember.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    UserName: 1,
                    ManagerUserName: 1,
                    InvalidEmail: 1,
                    InvalidStartDate: 1,
                    InvalidBirthDate: 1,
                    InvalidRole: 1,
                    InvalidSuppressAnniversary: 1,
                    InvalidSuppressBirthday: 1,
                    InvalidNewUserName: 1,
                    InvalidUserName: 1,
                    InvalidNewUserNameValue: 1,
                    InvalidManagerUserNameValue: 1
                }, {name: 'MemberValidationIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedLocation.db.collections.ProvisionStagedLocation.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    Name: 1,
                    Row: 1,
                    LocationCode: 1,
                    InvalidCountry: 1,
                    InvalidState: 1,
                    InvalidZipCode: 1,
                    InvalidLanguage: 1,
                    InvalidTimeZone: 1
                }, {name: 'LocationValidationIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionStagedDepartment.db.collections.ProvisionStagedDepartment.ensureIndex({
                    AuditId: 1,
                    GroupId: 1,
                    Name: 1,
                    Code: 1,
                    ProcessType: 1,
                    Status: 1
                }, {name: 'CoreDocIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.Member.db.collections.Member.ensureIndex({
                    GroupId:1,
                    MembershipStatus: 1,
                    LastName: 1
                }, {name: 'LastNameIndex', background: true, sparse: true}, callback);
            }),
            (function(callback) {
                EntityCache.ProvisionFileMap.db.collections.ProvisionFileMap.ensureIndex({
                    GroupId:1
                }, {name: 'GroupIdIndex', background: true}, callback);
            })
        ], callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addProvisionIndex
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();