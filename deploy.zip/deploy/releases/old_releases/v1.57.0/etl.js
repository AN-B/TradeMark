load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Job.remove({});
db.Job.insert({
    JobName : 'ProcessRecurrence',
    MethodName : 'ProcessRecurrence',
    PeriodType : 'Daily',
    Hour : 1,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'cleanTempDir',
    MethodName : 'cleanTempDir',
    PeriodType : 'Daily',
    Hour : 3,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'OffBoardMembers',
    MethodName : 'OffBoardMembers',
    PeriodType : 'Daily',
    Hour : 3,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'ExpireStickyNews',
    MethodName : 'ExpireStickyNews',
    PeriodType : 'Daily',
    Hour : 4,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'UpdateOverDueReviewStatus',
    MethodName : 'UpdateOverDueReviewStatus',
    PeriodType : 'Daily',
    Hour : 4,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'DeliverReview',
    MethodName : 'DeliverReview',
    PeriodType : 'Daily',
    Hour : 5,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'ExpireProductItems',
    MethodName : 'ExpireProductItems',
    PeriodType : 'Daily',
    Hour : 5,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'TrackCheckIn',
    MethodName : 'TrackCheckIn',
    PeriodType : 'Weekly',
    Hour : 5,
    Day : 5,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'SendPreOverDueReviewReminders',
    MethodName : 'SendPreOverDueReviewReminders',
    PeriodType : 'Daily',
    Hour : 5,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'Birthday',
    MethodName : 'Birthday',
    PeriodType : 'Daily',
    Hour : 6,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'Anniversary',
    MethodName : 'Anniversary',
    PeriodType : 'Daily',
    Hour : 6,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'ScheduledOnBoardMemberNotification',
    MethodName : 'ScheduledOnBoardMemberNotification',
    PeriodType : 'Daily',
    Hour : 6,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'CheckTangoAccountBalance',
    MethodName : 'CheckTangoAccountBalance',
    PeriodType : 'Daily',
    Hour : 8,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'SendPastOverDueReviewReminders',
    MethodName : 'SendPastOverDueReviewReminders',
    PeriodType : 'Daily',
    Hour : 8,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'ClearPastEvents',
    MethodName : 'ClearPastEvents',
    PeriodType : 'Daily',
    Hour : 11,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'RemarkableRecognitionNumber',
    MethodName : 'RemarkableRecognitionNumber',
    PeriodType : 'Daily',
    Hour : 22,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'ResetMemberRules',
    MethodName : 'ResetMemberRules',
    PeriodType : 'Daily',
    Hour : 23,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'CheckDailyJobs',
    MethodName : 'CheckDailyJobs',
    PeriodType : 'Daily',
    Hour : 10,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'GenerateGroupInvoices',
    MethodName : 'GenerateGroupInvoices',
    PeriodType : 'Monthly',
    Hour : 12,
    Day : 1,
    LatestTriggerDate : 0
});
db.Job.insert({
    JobName : 'MemberGoalStatusRecap',
    MethodName : 'MemberGoalStatusRecap',
    PeriodType : 'Weekly',
    Hour : 23,
    Day : 5,
    LatestTriggerDate : 0
});
