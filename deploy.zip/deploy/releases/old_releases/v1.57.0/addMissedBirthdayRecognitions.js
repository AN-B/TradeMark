load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

var query = {
    'Preference.SuppressBirthday' : false
};

var list94 = [];
var list911 = [];
var list912 = [];
var list913 = [];
var list914 = [];
var list915 = [];
db.UserInfo.find(query).forEach(function(item) {
    var dt = new Date(item.UserPersonal.Birthdate);
    var date  = dt.getUTCDate();
    var month  = dt.getUTCMonth() + 1;
    var value = month + '-' + date;
    switch(value) {
        case '9-4':
            list94.push(item);
            break;
        case '9-11':
            list911.push(item);
            break;
        case '9-12':
            list912.push(item);
            break;
        case '9-13':
            list913.push(item);
            break;
        case '9-14':
            list914.push(item);
            break;
        case '9-15':
            list915.push(item);
            break;
        default :
            break;
    };
});

var query = {};
var groups = db.Group.find(query).toArray();
var members = db.Member.find(query).toArray();
var highgroundGlobalUserId  = '5e42c56e-5b17-4070-817f-d924a5cd7462';
var guidLibrary = ["d6055080-3eb6-11e4-abd4-1fb79be7e83e","d6057790-3eb6-11e4-abd4-1fb79be7e83e","d6057791-3eb6-11e4-abd4-1fb79be7e83e","d6057792-3eb6-11e4-abd4-1fb79be7e83e","d6057793-3eb6-11e4-abd4-1fb79be7e83e","d6057794-3eb6-11e4-abd4-1fb79be7e83e","d6057795-3eb6-11e4-abd4-1fb79be7e83e","d6057796-3eb6-11e4-abd4-1fb79be7e83e","d6057797-3eb6-11e4-abd4-1fb79be7e83e","d6057798-3eb6-11e4-abd4-1fb79be7e83e","d6057799-3eb6-11e4-abd4-1fb79be7e83e","d605779a-3eb6-11e4-abd4-1fb79be7e83e","d605779b-3eb6-11e4-abd4-1fb79be7e83e","d605779c-3eb6-11e4-abd4-1fb79be7e83e","d605779d-3eb6-11e4-abd4-1fb79be7e83e","d605779e-3eb6-11e4-abd4-1fb79be7e83e","d605779f-3eb6-11e4-abd4-1fb79be7e83e","d60577a0-3eb6-11e4-abd4-1fb79be7e83e","d60577a1-3eb6-11e4-abd4-1fb79be7e83e","d60577a2-3eb6-11e4-abd4-1fb79be7e83e","d60577a3-3eb6-11e4-abd4-1fb79be7e83e","d60577a4-3eb6-11e4-abd4-1fb79be7e83e","d60577a5-3eb6-11e4-abd4-1fb79be7e83e","d60577a6-3eb6-11e4-abd4-1fb79be7e83e","d60577a7-3eb6-11e4-abd4-1fb79be7e83e","d60577a8-3eb6-11e4-abd4-1fb79be7e83e","d60577a9-3eb6-11e4-abd4-1fb79be7e83e","d60577aa-3eb6-11e4-abd4-1fb79be7e83e","d60577ab-3eb6-11e4-abd4-1fb79be7e83e","d60577ac-3eb6-11e4-abd4-1fb79be7e83e","d60577ad-3eb6-11e4-abd4-1fb79be7e83e","d60577ae-3eb6-11e4-abd4-1fb79be7e83e","d60577af-3eb6-11e4-abd4-1fb79be7e83e","d60577b0-3eb6-11e4-abd4-1fb79be7e83e","d60577b1-3eb6-11e4-abd4-1fb79be7e83e","d60577b2-3eb6-11e4-abd4-1fb79be7e83e","d60577b3-3eb6-11e4-abd4-1fb79be7e83e","d60577b4-3eb6-11e4-abd4-1fb79be7e83e","d60577b5-3eb6-11e4-abd4-1fb79be7e83e","d60577b6-3eb6-11e4-abd4-1fb79be7e83e","d60577b7-3eb6-11e4-abd4-1fb79be7e83e","d60577b8-3eb6-11e4-abd4-1fb79be7e83e","d60577b9-3eb6-11e4-abd4-1fb79be7e83e","d60577ba-3eb6-11e4-abd4-1fb79be7e83e","d60577bb-3eb6-11e4-abd4-1fb79be7e83e","d60577bc-3eb6-11e4-abd4-1fb79be7e83e","d60577bd-3eb6-11e4-abd4-1fb79be7e83e","d60577be-3eb6-11e4-abd4-1fb79be7e83e","d60577bf-3eb6-11e4-abd4-1fb79be7e83e","d60577c0-3eb6-11e4-abd4-1fb79be7e83e","d60577c1-3eb6-11e4-abd4-1fb79be7e83e","d60577c2-3eb6-11e4-abd4-1fb79be7e83e","d60577c3-3eb6-11e4-abd4-1fb79be7e83e","d60577c4-3eb6-11e4-abd4-1fb79be7e83e","d60577c5-3eb6-11e4-abd4-1fb79be7e83e","d60577c6-3eb6-11e4-abd4-1fb79be7e83e","d60577c7-3eb6-11e4-abd4-1fb79be7e83e","d60577c8-3eb6-11e4-abd4-1fb79be7e83e","d60577c9-3eb6-11e4-abd4-1fb79be7e83e","d60577ca-3eb6-11e4-abd4-1fb79be7e83e","d60577cb-3eb6-11e4-abd4-1fb79be7e83e","d60577cc-3eb6-11e4-abd4-1fb79be7e83e","d60577cd-3eb6-11e4-abd4-1fb79be7e83e","d60577ce-3eb6-11e4-abd4-1fb79be7e83e","d60577cf-3eb6-11e4-abd4-1fb79be7e83e","d60577d0-3eb6-11e4-abd4-1fb79be7e83e","d60577d1-3eb6-11e4-abd4-1fb79be7e83e","d60577d2-3eb6-11e4-abd4-1fb79be7e83e","d60577d3-3eb6-11e4-abd4-1fb79be7e83e","d60577d4-3eb6-11e4-abd4-1fb79be7e83e","d60577d5-3eb6-11e4-abd4-1fb79be7e83e","d60577d6-3eb6-11e4-abd4-1fb79be7e83e","d60577d7-3eb6-11e4-abd4-1fb79be7e83e","d60577d8-3eb6-11e4-abd4-1fb79be7e83e","d60577d9-3eb6-11e4-abd4-1fb79be7e83e","d60577da-3eb6-11e4-abd4-1fb79be7e83e","d60577db-3eb6-11e4-abd4-1fb79be7e83e","d60577dc-3eb6-11e4-abd4-1fb79be7e83e","d60577dd-3eb6-11e4-abd4-1fb79be7e83e","d60577de-3eb6-11e4-abd4-1fb79be7e83e","d60577df-3eb6-11e4-abd4-1fb79be7e83e","d60577e0-3eb6-11e4-abd4-1fb79be7e83e","d60577e1-3eb6-11e4-abd4-1fb79be7e83e","d60577e2-3eb6-11e4-abd4-1fb79be7e83e","d60577e3-3eb6-11e4-abd4-1fb79be7e83e","d60577e4-3eb6-11e4-abd4-1fb79be7e83e","d60577e5-3eb6-11e4-abd4-1fb79be7e83e","d60577e6-3eb6-11e4-abd4-1fb79be7e83e","d60577e7-3eb6-11e4-abd4-1fb79be7e83e","d60577e8-3eb6-11e4-abd4-1fb79be7e83e","d60577e9-3eb6-11e4-abd4-1fb79be7e83e","d60577ea-3eb6-11e4-abd4-1fb79be7e83e","d60577eb-3eb6-11e4-abd4-1fb79be7e83e","d60577ec-3eb6-11e4-abd4-1fb79be7e83e","d60577ed-3eb6-11e4-abd4-1fb79be7e83e","d60577ee-3eb6-11e4-abd4-1fb79be7e83e","d60577ef-3eb6-11e4-abd4-1fb79be7e83e","d60577f0-3eb6-11e4-abd4-1fb79be7e83e","d60577f1-3eb6-11e4-abd4-1fb79be7e83e","d60577f2-3eb6-11e4-abd4-1fb79be7e83e"];
var listRecCreated = [];
var birthdayList = [
	{recognitionDate : '9/4/2014', Users : list94},
	{recognitionDate : '9/11/2014', Users : list911},
	{recognitionDate : '9/12/2014', Users : list912},
	{recognitionDate : '9/13/2014', Users : list913},
	{recognitionDate : '9/14/2014', Users : list914},
	{recognitionDate : '9/15/2014', Users : list915}
];

function getGuid() {
	return guidLibrary.pop();
}
function getJustDate(date) {
    var d = (date !== undefined) ? new Date(date) : new Date();
    return new Date(d.toString().substring(0, 15));
}
function saveDepartmentMetric(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, d : params.Department, c : params.Category, s : params.Source},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsDepartment.update(query, update, options);
}
function saveMemberMetric(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, m : params.MemberId, c : params.Category},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsMember.update(query, update, options);
}
function saveRecognitionSource(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, c : params.PublicityType, s : params.Source},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsRecognitionSource.update(query, update, options);
}
function saveRecognitionCategory(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, c : params.Category, s : params.Source},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsRecognitionCategory.update(query, update, options);
}
function saveRecognition(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {},
        subItem = {},
        total = 't',
        inc = '$inc',
        hourIndex = 'h.' + params.Hour;
    subItem[total] = params.UpdateValue;
    subItem[hourIndex] = 1;
    update[inc] = subItem;
    db.MetricsRecognition.update(query, update, options);
}

function getRecognitionPublicityType(recognition) {
    return (recognition.PublicCreatorInfo.FullName === '' || recognition.Template.Category === 'System') ? 'Internal' : 'Public';
}

function createRecognition(group, user, recipientMember, badge, SuppressInFeed, recognitionDate, category, subCategory) {
	var recognition = {},
		template = {
			hgId : badge.Id,
		    Publicity : 'Public',
		    Type : 'Recognition',
		    GroupId : group.hgId,
		    GroupName : group.GroupName,
		    FriendlyGroupId : group.FriendlyGroupId,
		    Description : badge.Title,
		    Title : badge.Title,
		    Category : category,
		    SubCategory : subCategory,
		    ModifiedDate : new Date(recognitionDate).getTime(),
		    CreatedDate : new Date(recognitionDate).getTime(),
		    CreatedBy : highgroundGlobalUserId,
		    ModifiedBy : highgroundGlobalUserId,
		    Levels : [],
		    AchievementLevelEnabled : false,
        	SubValues : [],
        	DefaultGivenToNewMembers : false,
        	ApproverMemberId : -1,
        	AccessLevel : "WithinGroup",
        	PointValue : 0,
        	CreditValue : 0,
        	DepartmentName : ""
		};

	recognition.hgId = getGuid();
	recognition.BatchId = getGuid();
	recognition.SuppressInFeed = SuppressInFeed;
	recognition.Template = template;
	recognition.BadgeFilename = template.hgId;
	recognition.Message = badge.Message || '';

	//Set the ProperDate
	recognition.CreatedDate = new Date(recognitionDate).getTime();
	recognition.ModifiedDate = new Date(recognitionDate).getTime();

	//set recipientMember
	recognition.RecipientMember = recipientMember;

	//set created by
	recognition.CreatedBy = highgroundGlobalUserId;
	recognition.ModifiedBy = highgroundGlobalUserId;
	recognition.PublicCreatorInfo = {
		FullName : group.ProgramName || group.GroupName,
		Email : '',
		CompanyName : ''
	};

	//set unused fields
	recognition.NewsId = '';
	recognition.Sticky = '';
	recognition.ExpireDate = '';
	recognition.ActualCreditValue =  0;
    recognition.ActualPointValue = 0;
    recognition.Attachments = [];
    recognition.CannedMessage =  "";
    recognition.CommentCount = 0;
    recognition.CompanyRating =  0;
    recognition.CongratMemberIds = [];
    recognition.CongratsCount = 0;
    recognition.MeCongrated = false;
    recognition.DismissMemberIds = [];
    recognition.MemberRating = 0;
    recognition.ShareCount = 0;
    recognition.Shares = [];
    recognition.Source = "Web";
    recognition.Status = 'Active';
    recognition.DismissMemberIds = [];
    recognition.DismissMemberIds = [];
    recognition.CreatorMember = {
    	ModifiedDate : new Date(recognitionDate).getTime(),
        ModifiedBy : "",
        CreatedDate : new Date(recognitionDate).getTime(),
        CreatedBy : "",
        hgId : "",
        LastRole : "",
        OffBoardType : "NotApplicable",
        GravatarEmail : "",
        ExperiencePoint : 0,
        FollowedTrackMemberIds : [],
        FollowedMemberIds : [],
        EmployeeId : "",
        FriendlyId : "",
        GroupDepartmentName : "",
        DefaultPaymentProfileId : "",
        InvitedBy : "",
        ApprovedOrDeniedBy : "",
        Preference : {
            RecapType : "Daily",
            WeekendDailyRecap : false
        },
        UnpinnedTeamIds : [],
        PinnedTeamIds : [],
        UnpinnedMemberIds : [],
        PinnedMemberIds : [],
        MyManagers : [],
        MembershipStatus : "Active",
        LastDailyRecapSentDate : 0,
        StartingDate : new Date(recognitionDate).getTime(),
        Position : "",
        RemovedPermissions : [],
        AddedPermissions : [],
        RolesInGroup : [],
        ProgramName : "",
        GroupName : "",
        GroupId : "",
        FullName : "",
        LastName : "",
        FirstName : "",
        UserId : ""
    };

    var recJustDate = getJustDate(recognitionDate),
    	departmentName = recognition.CreatorMember ? recognition.CreatorMember.GroupDepartmentName : '',
    	publicityType = getRecognitionPublicityType(recognition);
    category = [recognition.Template.Category, '.', recognition.Template.SubCategory].join('');

	saveRecognition({
        Date : recJustDate,
        Hour : new Date(recognition.CreatedDate).getHours(),
        GroupId : group.hgId,
        Source : recognition.Source,
        UpdateValue : 1
    });
    saveRecognitionCategory({
        Category : category,
        Date : recJustDate,
        GroupId : group.hgId,
        Source : recognition.Source,
        UpdateValue : 1
    });
    saveRecognitionSource({
        PublicityType : publicityType,
        Date : recJustDate,
        GroupId : group.hgId,
        Source : recognition.Source,
        UpdateValue : 1
    });
    saveMemberMetric({
        Date : recJustDate,
        GroupId : group.hgId,
        MemberId : recognition.RecipientMember.hgId,
        Category : 'RecognitionReceived',
        UpdateValue : 1
    });

    if (publicityType === 'Internal') {
        saveDepartmentMetric({
            Department : (departmentName === '' || departmentName === null || departmentName === undefined) ? 'Other' : departmentName,
            Date : recJustDate,
            GroupId : group.hgId,
            Category : 'RecognitionGiven',
            UpdateValue : 1,
            Source : recognition.Source
        });
    }
    //printjson(recognition);
    switchDB("hgthanka");
    listRecCreated.push({GroupId : group.GroupName, FullName : recipientMember.FullName, Date : recognitionDate});
    db.Recognition.insert(recognition);
}

birthdayList.forEach(function(bList) {
	if (bList.Users.length > 0) {
		print(bList.recognitionDate + ' has # of Users ' + bList.Users.length);
		bList.Users.forEach(function(item) {
			var user1 = item;
			//get User, ensure user preference
			if (!user1.Preference.SuppressBirthday) {
				//get User Group
				var group = groups.filter(function (item) {
					return item.hgId === user1.Preference.DefaultGroupId;
				});
				if (group && group.length === 1) {
					group = group[0];
					//Ensure Group preference
					if (group.Preference.BirthdayEmailEnabled) {
						// Get Group Birthday Badge
						var badge = group.BadgeDefaults.filter(function (item) {
							return item.Type === 'Birthday';
						});
						if (badge && badge.length === 1) {
							badge = badge[0];
							//get Member record
							var member = members.filter(function (item) {
								return item.UserId === user1.hgId && item.GroupId === group.hgId;
							});
							if (member && member.length == 1) {
								member = member[0];
                                if (member.MembershipStatus === 'Active') {
                                    //create recognition
                                    createRecognition(group, user1, member, badge, false, bList.recognitionDate, 'System', 'Birthday');    
                                } else {
                                    print(user1.UserPersonal.FullName + ' Status is not Active. Current Status: ' + member.MembershipStatus);    
                                }
							} else {
								print('Cannot Member for User: ' + user1.UserPersonal.FullName);
							}
						} else {
							print('Group : ' + group.GroupName + ' has Birthday BadgeDefaults does not exist');	
						}
					} else {
						print('Group : ' + group.GroupName + ' has BirthdayEmailEnabled set to ' + group.Preference.BirthdayEmailEnabled + ' User: ' + user1.UserPersonal.FullName);	
					}
				} else {
					print('Cannot Find Group for User: ' + user1.UserPersonal.FullName);
				}
			} else {
				print('Users with Suppressed Birthday: ' + user1.UserPersonal.FullName + ': ' + user1.Preference.SuppressBirthday);
			}
		});
	}
});

print('Recognitions Created: ' + listRecCreated.length);
printjson(listRecCreated);
