load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

var query = {MembershipStatus : 'Active'};

var list94 = [];
var list911 = [];
var list912 = [];
var list913 = [];
var list914 = [];
var list915 = [];
db.Member.find(query).forEach(function(item) {
    var dt = new Date(item.StartingDate);
    var date  = dt.getUTCDate();
    var month  = dt.getUTCMonth() + 1;
    var value = month + '-' + date;
    if (dt.getUTCFullYear() !== 2014) {
        switch(value) {
            case '9-4':
                list94.push(item);
                break;
            case '9-11':
                list911.push(item);
                break;
            case '9-12':
                list912.push(item);
                break;
            case '9-13':
                list913.push(item);
                break;
            case '9-14':
                list914.push(item);
                break;
            case '9-15':
                list915.push(item);
                break;
            default :
                break;
        };
    }
});

var query = {};
var groups = db.Group.find(query).toArray();
var users = db.UserInfo.find(query).toArray();
var highgroundGlobalUserId  = '5e42c56e-5b17-4070-817f-d924a5cd7462';
var guidLibrary = ["3372cd20-3f51-11e4-a604-8f8c1fbc5ada","3372cd21-3f51-11e4-a604-8f8c1fbc5ada","3372cd22-3f51-11e4-a604-8f8c1fbc5ada","3372cd23-3f51-11e4-a604-8f8c1fbc5ada","3372cd24-3f51-11e4-a604-8f8c1fbc5ada","3372cd25-3f51-11e4-a604-8f8c1fbc5ada","3372cd26-3f51-11e4-a604-8f8c1fbc5ada","3372cd27-3f51-11e4-a604-8f8c1fbc5ada","3372cd28-3f51-11e4-a604-8f8c1fbc5ada","3372cd29-3f51-11e4-a604-8f8c1fbc5ada","3372cd2a-3f51-11e4-a604-8f8c1fbc5ada","3372cd2b-3f51-11e4-a604-8f8c1fbc5ada","3372cd2c-3f51-11e4-a604-8f8c1fbc5ada","3372cd2d-3f51-11e4-a604-8f8c1fbc5ada","3372cd2e-3f51-11e4-a604-8f8c1fbc5ada","3372cd2f-3f51-11e4-a604-8f8c1fbc5ada","3372cd30-3f51-11e4-a604-8f8c1fbc5ada","3372cd31-3f51-11e4-a604-8f8c1fbc5ada","3372cd32-3f51-11e4-a604-8f8c1fbc5ada","3372cd33-3f51-11e4-a604-8f8c1fbc5ada","3372cd34-3f51-11e4-a604-8f8c1fbc5ada","3372cd35-3f51-11e4-a604-8f8c1fbc5ada","3372cd36-3f51-11e4-a604-8f8c1fbc5ada","3372cd37-3f51-11e4-a604-8f8c1fbc5ada","3372cd38-3f51-11e4-a604-8f8c1fbc5ada","3372cd39-3f51-11e4-a604-8f8c1fbc5ada","3372cd3a-3f51-11e4-a604-8f8c1fbc5ada","3372cd3b-3f51-11e4-a604-8f8c1fbc5ada","3372cd3c-3f51-11e4-a604-8f8c1fbc5ada","3372cd3d-3f51-11e4-a604-8f8c1fbc5ada","3372cd3e-3f51-11e4-a604-8f8c1fbc5ada","3372cd3f-3f51-11e4-a604-8f8c1fbc5ada","3372cd40-3f51-11e4-a604-8f8c1fbc5ada","3372cd41-3f51-11e4-a604-8f8c1fbc5ada","3372cd42-3f51-11e4-a604-8f8c1fbc5ada","3372cd43-3f51-11e4-a604-8f8c1fbc5ada","3372cd44-3f51-11e4-a604-8f8c1fbc5ada","3372cd45-3f51-11e4-a604-8f8c1fbc5ada","3372cd46-3f51-11e4-a604-8f8c1fbc5ada","3372cd47-3f51-11e4-a604-8f8c1fbc5ada","3372cd48-3f51-11e4-a604-8f8c1fbc5ada","3372cd49-3f51-11e4-a604-8f8c1fbc5ada","3372cd4a-3f51-11e4-a604-8f8c1fbc5ada","3372cd4b-3f51-11e4-a604-8f8c1fbc5ada","3372cd4c-3f51-11e4-a604-8f8c1fbc5ada","3372cd4d-3f51-11e4-a604-8f8c1fbc5ada","3372cd4e-3f51-11e4-a604-8f8c1fbc5ada","3372cd4f-3f51-11e4-a604-8f8c1fbc5ada","3372cd50-3f51-11e4-a604-8f8c1fbc5ada","3372cd51-3f51-11e4-a604-8f8c1fbc5ada","3372cd52-3f51-11e4-a604-8f8c1fbc5ada","3372cd53-3f51-11e4-a604-8f8c1fbc5ada","3372cd54-3f51-11e4-a604-8f8c1fbc5ada","3372cd55-3f51-11e4-a604-8f8c1fbc5ada","3372cd56-3f51-11e4-a604-8f8c1fbc5ada","3372cd57-3f51-11e4-a604-8f8c1fbc5ada","3372cd58-3f51-11e4-a604-8f8c1fbc5ada","3372cd59-3f51-11e4-a604-8f8c1fbc5ada","3372cd5a-3f51-11e4-a604-8f8c1fbc5ada","3372cd5b-3f51-11e4-a604-8f8c1fbc5ada","3372cd5c-3f51-11e4-a604-8f8c1fbc5ada","3372cd5d-3f51-11e4-a604-8f8c1fbc5ada","3372cd5e-3f51-11e4-a604-8f8c1fbc5ada","3372cd5f-3f51-11e4-a604-8f8c1fbc5ada","3372cd60-3f51-11e4-a604-8f8c1fbc5ada","3372cd61-3f51-11e4-a604-8f8c1fbc5ada","3372cd62-3f51-11e4-a604-8f8c1fbc5ada","3372f430-3f51-11e4-a604-8f8c1fbc5ada","3372f431-3f51-11e4-a604-8f8c1fbc5ada","3372f432-3f51-11e4-a604-8f8c1fbc5ada","3372f433-3f51-11e4-a604-8f8c1fbc5ada","3372f434-3f51-11e4-a604-8f8c1fbc5ada","3372f435-3f51-11e4-a604-8f8c1fbc5ada","3372f436-3f51-11e4-a604-8f8c1fbc5ada","3372f437-3f51-11e4-a604-8f8c1fbc5ada","3372f438-3f51-11e4-a604-8f8c1fbc5ada","3372f439-3f51-11e4-a604-8f8c1fbc5ada","3372f43a-3f51-11e4-a604-8f8c1fbc5ada","3372f43b-3f51-11e4-a604-8f8c1fbc5ada","3372f43c-3f51-11e4-a604-8f8c1fbc5ada","3372f43d-3f51-11e4-a604-8f8c1fbc5ada","3372f43e-3f51-11e4-a604-8f8c1fbc5ada","3372f43f-3f51-11e4-a604-8f8c1fbc5ada","3372f440-3f51-11e4-a604-8f8c1fbc5ada","3372f441-3f51-11e4-a604-8f8c1fbc5ada","3372f442-3f51-11e4-a604-8f8c1fbc5ada","3372f443-3f51-11e4-a604-8f8c1fbc5ada","3372f444-3f51-11e4-a604-8f8c1fbc5ada","3372f445-3f51-11e4-a604-8f8c1fbc5ada","3372f446-3f51-11e4-a604-8f8c1fbc5ada","3372f447-3f51-11e4-a604-8f8c1fbc5ada","3372f448-3f51-11e4-a604-8f8c1fbc5ada","3372f449-3f51-11e4-a604-8f8c1fbc5ada","3372f44a-3f51-11e4-a604-8f8c1fbc5ada","3372f44b-3f51-11e4-a604-8f8c1fbc5ada","3372f44c-3f51-11e4-a604-8f8c1fbc5ada","3372f44d-3f51-11e4-a604-8f8c1fbc5ada","3372f44e-3f51-11e4-a604-8f8c1fbc5ada","3372f44f-3f51-11e4-a604-8f8c1fbc5ada","3372f450-3f51-11e4-a604-8f8c1fbc5ada"];
var listRecCreated = [];
var anniversaryList = [
	{recognitionDate : '9/4/2014', Members : list94},
	{recognitionDate : '9/11/2014', Members : list911},
	{recognitionDate : '9/12/2014', Members : list912},
	{recognitionDate : '9/13/2014', Members : list913},
	{recognitionDate : '9/14/2014', Members : list914},
	{recognitionDate : '9/15/2014', Members : list915}
];

function getGuid() {
	return guidLibrary.pop();
}
function getJustDate(date) {
    var d = (date !== undefined) ? new Date(date) : new Date();
    return new Date(d.toString().substring(0, 15));
}
function saveDepartmentMetric(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, d : params.Department, c : params.Category, s : params.Source},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsDepartment.update(query, update, options);
}
function saveMemberMetric(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, m : params.MemberId, c : params.Category},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsMember.update(query, update, options);
}
function saveRecognitionSource(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, c : params.PublicityType, s : params.Source},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsRecognitionSource.update(query, update, options);
}
function saveRecognitionCategory(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId, c : params.Category, s : params.Source},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {$inc : { t : params.UpdateValue}};
    if (params.UpdateValue < 1) {
        query.t = { $gte : 1};
    }
    db.MetricsRecognitionCategory.update(query, update, options);
}
function saveRecognition(params) {
	switchDB("hgreports");
    var query = {p : params.Date, g : params.GroupId},
        options = {upsert: (params.UpdateValue < 1) ? false : true },
        update = {},
        subItem = {},
        total = 't',
        inc = '$inc',
        hourIndex = 'h.' + params.Hour;
    subItem[total] = params.UpdateValue;
    subItem[hourIndex] = 1;
    update[inc] = subItem;
    db.MetricsRecognition.update(query, update, options);
}

function getRecognitionPublicityType(recognition) {
    return (recognition.PublicCreatorInfo.FullName === '' || recognition.Template.Category === 'System') ? 'Internal' : 'Public';
}

function getSuppressInFeedStatus(userPreference) {
    var result;
    if (userPreference === null || userPreference === undefined) {
        result = false;
    } else {
        result = userPreference;
    }
    return result;
}

function createRecognition(group, user, recipientMember, badge, SuppressInFeed, recognitionDate, category, subCategory) {
	var recognition = {},
		template = {
			hgId : badge.Id,
		    Publicity : 'Public',
		    Type : 'Recognition',
		    GroupId : group.hgId,
		    GroupName : group.GroupName,
		    FriendlyGroupId : group.FriendlyGroupId,
		    Description : badge.Title,
		    Title : badge.Title,
		    Category : category,
		    SubCategory : subCategory,
		    ModifiedDate : new Date(recognitionDate).getTime(),
		    CreatedDate : new Date(recognitionDate).getTime(),
		    CreatedBy : highgroundGlobalUserId,
		    ModifiedBy : highgroundGlobalUserId,
		    Levels : [],
		    AchievementLevelEnabled : false,
        	SubValues : [],
        	DefaultGivenToNewMembers : false,
        	ApproverMemberId : -1,
        	AccessLevel : "WithinGroup",
        	PointValue : 0,
        	CreditValue : 0,
        	DepartmentName : ""
		};

	recognition.hgId = getGuid();
	recognition.BatchId = getGuid();
	recognition.SuppressInFeed = SuppressInFeed;
	recognition.Template = template;
	recognition.BadgeFilename = template.hgId;
	recognition.Message = badge.Message || '';

	//Set the ProperDate
	recognition.CreatedDate = new Date(recognitionDate).getTime();
	recognition.ModifiedDate = new Date(recognitionDate).getTime();

	//set recipientMember
	recognition.RecipientMember = recipientMember;

	//set created by
	recognition.CreatedBy = highgroundGlobalUserId;
	recognition.ModifiedBy = highgroundGlobalUserId;
	recognition.PublicCreatorInfo = {
		FullName : group.ProgramName || group.GroupName,
		Email : '',
		CompanyName : ''
	};

	//set unused fields
	recognition.NewsId = '';
	recognition.Sticky = '';
	recognition.ExpireDate = '';
	recognition.ActualCreditValue =  0;
    recognition.ActualPointValue = 0;
    recognition.Attachments = [];
    recognition.CannedMessage =  "";
    recognition.CommentCount = 0;
    recognition.CompanyRating =  0;
    recognition.CongratMemberIds = [];
    recognition.CongratsCount = 0;
    recognition.MeCongrated = false;
    recognition.DismissMemberIds = [];
    recognition.MemberRating = 0;
    recognition.ShareCount = 0;
    recognition.Shares = [];
    recognition.Source = "Web";
    recognition.Status = 'Active';
    recognition.DismissMemberIds = [];
    recognition.DismissMemberIds = [];
    recognition.CreatorMember = {
    	ModifiedDate : new Date(recognitionDate).getTime(),
        ModifiedBy : "",
        CreatedDate : new Date(recognitionDate).getTime(),
        CreatedBy : "",
        hgId : "",
        LastRole : "",
        OffBoardType : "NotApplicable",
        GravatarEmail : "",
        ExperiencePoint : 0,
        FollowedTrackMemberIds : [],
        FollowedMemberIds : [],
        EmployeeId : "",
        FriendlyId : "",
        GroupDepartmentName : "",
        DefaultPaymentProfileId : "",
        InvitedBy : "",
        ApprovedOrDeniedBy : "",
        Preference : {
            RecapType : "Daily",
            WeekendDailyRecap : false
        },
        UnpinnedTeamIds : [],
        PinnedTeamIds : [],
        UnpinnedMemberIds : [],
        PinnedMemberIds : [],
        MyManagers : [],
        MembershipStatus : "Active",
        LastDailyRecapSentDate : 0,
        StartingDate : new Date(recognitionDate).getTime(),
        Position : "",
        RemovedPermissions : [],
        AddedPermissions : [],
        RolesInGroup : [],
        ProgramName : "",
        GroupName : "",
        GroupId : "",
        FullName : "",
        LastName : "",
        FirstName : "",
        UserId : ""
    };

    var recJustDate = getJustDate(recognitionDate),
    	departmentName = recognition.CreatorMember ? recognition.CreatorMember.GroupDepartmentName : '',
    	publicityType = getRecognitionPublicityType(recognition);
    category = [recognition.Template.Category, '.', recognition.Template.SubCategory].join('');

	saveRecognition({
        Date : recJustDate,
        Hour : new Date(recognition.CreatedDate).getHours(),
        GroupId : group.hgId,
        Source : recognition.Source,
        UpdateValue : 1
    });
    saveRecognitionCategory({
        Category : category,
        Date : recJustDate,
        GroupId : group.hgId,
        Source : recognition.Source,
        UpdateValue : 1
    });
    saveRecognitionSource({
        PublicityType : publicityType,
        Date : recJustDate,
        GroupId : group.hgId,
        Source : recognition.Source,
        UpdateValue : 1
    });
    saveMemberMetric({
        Date : recJustDate,
        GroupId : group.hgId,
        MemberId : recognition.RecipientMember.hgId,
        Category : 'RecognitionReceived',
        UpdateValue : 1
    });

    if (publicityType === 'Internal') {
        saveDepartmentMetric({
            Department : (departmentName === '' || departmentName === null || departmentName === undefined) ? 'Other' : departmentName,
            Date : recJustDate,
            GroupId : group.hgId,
            Category : 'RecognitionGiven',
            UpdateValue : 1,
            Source : recognition.Source
        });
    }
    switchDB("hgthanka");
    listRecCreated.push({GroupId : group.GroupName, FullName : recipientMember.FullName, Date : recognitionDate, SuppressInFeed : SuppressInFeed});
    db.Recognition.insert(recognition);
}

anniversaryList.forEach(function(aList) {
	if (aList.Members.length > 0) {
		print(aList.recognitionDate + ' has # of Users ' + aList.Members.length);
		aList.Members.forEach(function(member) {
            //get User
            var user1 = users.filter(function (item) {
                return member.UserId === item.hgId;
            });
            if (user1 && user1.length === 1) {
                user1 = user1[0];
                //get group
                var group = groups.filter(function (item) {
                    return item.hgId === member.GroupId;
                });
                if (group && group.length === 1) {
                    group = group[0];
                    //Ensure Group preference
                    if (group.Preference.AnniversaryEmailEnabled) {
                        // Get Group Anniversary Badge
                        var badge = group.BadgeDefaults.filter(function (item) {
                            return item.Type === 'Anniversary';
                        });
                        if (badge && badge.length === 1) {
                            badge = badge[0];
                            //create recognition
                            var suppressInFeed = getSuppressInFeedStatus(user1.Preference.SuppressAnniversary);
                            createRecognition(group, user1, member, badge, suppressInFeed, aList.recognitionDate, 'System', 'Anniversary');
                        } else {
                            print('Group : ' + group.GroupName + ' has Anniversary BadgeDefaults does not exist'); 
                        }
                    } else {
                        print('Group : ' + group.GroupName + ' has AnniversaryEmailEnabled set to ' + group.Preference.AnniversaryEmailEnabled + ' User: ' + member.FullName);    
                    }
                } else {
                    print('Cannot Find Group for User: ' + member.FullName);
                }
            } else {
                print('Cannot Find User: ' + member.FullName);
            }
		});
	}
});

print('Recognitions Created: ' + listRecCreated.length);
printjson(listRecCreated);
