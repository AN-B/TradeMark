// add the TermsOfUse property in the hgcommon.Group collection
db.Group.update({},{$set:{"TermsOfUse": {
    "Accepted": true,
    "AcceptMemberId": "2b012756-4c68-46e6-b83e-ed399c82ce1d",
    "AcceptMemberName": "Mr. Roboto",
    "AcceptDate": 1379653200000
}}},{multi:true});

//enable URL rewriting for all groups except K2
// db.Group.findOne({'HGAccountId' : 'HG201300003'});
db.Group.update({'HGAccountId' : {$ne : 'HG201300003'} }, {$addToSet :
    {
        'Preference.FeatureFlags' : {
            "FeatureName" : "URLRewriting",
            "FeatureMeta" : [ ],
            "FeatureEnabled" : true
        }
    }
});

db.Group.update({'HGAccountId' : 'HG201300003'}, {$addToSet :
    {
        'Preference.FeatureFlags' : {
            "FeatureName" : "URLRewriting",
            "FeatureMeta" : [ ],
            "FeatureEnabled" : false
        }
    }
});

//mercury badge template mapping
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Account Management'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Sales'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Wellness'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Customer Service'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Occasion'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Quick'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Congrats'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Good Job'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Everyday Recognition'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Technology'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'General'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Account Finance'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Corporate'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Letters'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Number'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'IT'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Achievement'}, {$set : {'Category' : 'Achievement'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'HighGround Value'}, {$set : {'Category' : 'Values'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Keno Kozie'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Peer-2-Peer'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'QA'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Encouragement'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Thanks'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Welcome'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Kudos'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Values'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'News'}, {$set : {'Category' : 'System'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Playing Cards'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Food'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'TEST'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde', 'Category' : 'Wedding'}, {$set : {'Category' : 'Everyday'}}, {multi : true});

//fooda badge template mapping
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Fooda'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Everyday Recognition'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Account Finance'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Corporate'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Customer Service'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Sales'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'General'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Technology'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Wellness'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Customer'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Account Management'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'HighGround Awards'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Thanks'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'Company Values'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '7bc84a10-ac49-11e2-816a-81fd71297a71', 'Category' : 'News'}, {$set : {'Category' : 'System'}}, {multi : true});

//k2 badge template mapping
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Letters'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Recognition'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Accounting / Finance'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Account Management'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Achievement'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Corporate'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Customer Service'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Sales'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Everyday Recognition'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'General'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Technology'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Number'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Support'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Onboarding'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Welcome To The Team SG3'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'Keno Kozie'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'SG1'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '93c913a0-bdf2-11e2-9666-cb9e9195cb36', 'Category' : 'News'}, {$set : {'Category' : 'System'}}, {multi : true});

//adage badge template mapping
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Adage Values'}, {$set : {'Category' : 'Values'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Customer & Vendor'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Traditional Awards'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Skills'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Achievement'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'KPI'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Peer-to-Peer'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Everyday Recognition'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'a951d3d0-1a43-11e3-b544-b5fd63eafa89', 'Category' : 'Corporate'}, {$set : {'Category' : 'Everyday'}}, {multi : true});

//GiveForward badge template mapping
db.RecognitionTemplate.update({'GroupId' : 'dee8de90-172c-11e3-8e6a-11fc2f75ffee', 'Category' : 'Cultivate Through Compassion'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'dee8de90-172c-11e3-8e6a-11fc2f75ffee', 'Category' : 'Be the CEO of Your Position'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'dee8de90-172c-11e3-8e6a-11fc2f75ffee', 'Category' : 'Authenticity'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'dee8de90-172c-11e3-8e6a-11fc2f75ffee', 'Category' : 'Take Fun Seriously'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'dee8de90-172c-11e3-8e6a-11fc2f75ffee', 'Category' : 'Company Initiatives'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'dee8de90-172c-11e3-8e6a-11fc2f75ffee', 'Category' : 'Tenure with a Twist'}, {$set : {'Category' : 'Achievements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : 'dee8de90-172c-11e3-8e6a-11fc2f75ffee', 'Category' : 'Corporate'}, {$set : {'Category' : 'System'}}, {multi : true});

//Innerworking badge template mapping
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'Sales'}, {$set : {'Category' : 'Acheivements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'INWK Innovation'}, {$set : {'Category' : 'Values'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'INWK Determination'}, {$set : {'Category' : 'Values'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'INWK Insight'}, {$set : {'Category' : 'Values'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'INWK Collaboration'}, {$set : {'Category' : 'Values'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'Everyday Recognition'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'General'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'Accounting/Finance'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'Achievement'}, {$set : {'Category' : 'Acheivements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'Corporate'}, {$set : {'Category' : 'Acheivements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'Customer Service'}, {$set : {'Category' : 'Everyday'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'Operations'}, {$set : {'Category' : 'Acheivements'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'INWK CEO'}, {$set : {'Category' : 'Values'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'News'}, {$set : {'Category' : 'System'}}, {multi : true});
db.RecognitionTemplate.update({'GroupId' : '00474e30-c93c-11e2-aedf-47638bb1c36d', 'Category' : 'INWK Tenure'}, {$set : {'Category' : 'Acheivements'}}, {multi : true});
