'use strict';
var HgMigrationFile = function () {
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        config = require('../../../hgnode/configurations/config.js'),
        async = require('async'),
        cdnIndex = 0,
        cdnCount = config.s3store.cdn.length;

    // find all instances of cloudfront and amazonaws urls and replace with the new highground.com urls
    function fixTangoCdnUrls(callback) {
        // replace tango card urls
        EntityCache.TangoCard.find({}, function (err, cards) {
            if (err) {
                return callback(err);
            }
            cards.forEach(function (card) {
                var oldVal = card.ImageUrl;
                if (card.ImageUrl.indexOf('cloudfront') > -1) {
                    card.ImageUrl = card.ImageUrl.replace(/\/\/.*.cloudfront.net/g, config.s3store.cdn[cdnIndex % cdnCount]);
                } else if (card.ImageUrl.indexOf('amazonaws') > -1) {
                    card.ImageUrl = card.ImageUrl.replace(/\/\/.*.amazonaws.com/g, config.s3store.cdn[cdnIndex % cdnCount]);
                }

                if (card.ImageUrl.indexOf('/graphics/') > -1) {
                    card.ImageUrl = card.ImageUrl.replace(/graphics\/item-images/g, 'giftcard');
                }
                if (oldVal !== card.ImageUrl) {
                    if (['giftcard', 'charity'].indexOf(card.Type) === -1) {
                        card.Type = 'giftcard';
                    }
                    card.save(function (err) {
                        if (err) {
                            return callback(err);
                        }
                        cdnIndex += 1;
                    });
                }
            });
            callback();
        });
    }

    // find all instances of cloudfront and amazonaws urls and replace with the new highground.com urls
    function fixRecognitionCdnUrls(callback) {
        // replace recognition urls
        EntityCache.Recognition.find({Message:/cloudfront/}, function (err, recs) {
            if (err) {
                return callback(err);
            }
            recs.forEach(function (rec) {
                rec.Message = rec.Message.replace(/src=".*:\/\/.*.cloudfront.net/g, 'src="' + config.s3store.cdn[cdnIndex % cdnCount]);
                EntityCache.Recognition.update({hgId: rec.hgId}, {$set: {Message: rec.Message}}, function (err) {
                    if (err) {
                        return callback(err);
                    }
                    cdnIndex += 1;
                });
            });
            EntityCache.Recognition.find({Message:/amazonaws/}, function (err, recs) {
                if (err) {
                    return callback(err);
                }
                recs.forEach(function (rec) {
                    rec.Message = rec.Message.replace(/src=".*:\/\/.*.amazonaws.com/g, 'src="' + config.s3store.cdn[cdnIndex % cdnCount]);
                    EntityCache.Recognition.update({hgId: rec.hgId}, {$set: {Message: rec.Message}}, function (err) {
                        if (err) {
                            return callback(err);
                        }
                        cdnIndex += 1;
                    });
                });
            });
            callback();
        });
    }

    // find all instances of cloudfront and amazonaws urls and replace with the new highground.com urls
    function fixCommentCdnUrls(callback) {
        EntityCache.Comment.find({'Attachments.ImgSrc':/cloudfront/}, function (err, coms) {
            if (err) {
                return callback(err);
            }
            coms.forEach(function (com) {
                if (com.Attachments && com.Attachments.length) {
                    com.Attachments.forEach(function (att) {
                        att.ImgSrc = att.ImgSrc.replace(/\/\/.*.cloudfront.net/g, config.s3store.cdn[cdnIndex % cdnCount]);
                        cdnIndex += 1;
                    });
                    com.save(function (err) {
                        if (err) {
                            return callback(err);
                        }
                    });
                }
            });
            EntityCache.Comment.find({'Attachments.ImgSrc':/amazonaws/}, function (err, coms) {
                if (err) {
                    return callback(err);
                }
                coms.forEach(function (com) {
                    if (com.Attachments && com.Attachments.length) {
                        com.Attachments.forEach(function (att) {
                            att.ImgSrc = att.ImgSrc.replace(/\/\/.*.amazonaws.com/g, config.s3store.cdn[cdnIndex % cdnCount]);
                            cdnIndex += 1;
                            com.save(function (err) {
                                if (err) {
                                    return callback(err);
                                }
                            });
                        });
                    }
                });
                EntityCache.Comment.find({Comment:/amazonaws/}, function (err, coms) {
                    if (err) {
                        return callback(err);
                    }
                    coms.forEach(function (com) {
                        com.Comment = com.Comment.replace(/\/\/.*.amazonaws.com/g, config.s3store.cdn[cdnIndex % cdnCount]);
                        cdnIndex += 1;
                        com.save(function (err) {
                            if (err) {
                                return callback(err);
                            }
                        });
                    });
                    callback();
                });
            });
        });
    }


    function migrateRecognitionIconPickerColor(callback) {
        var query = {
                $where: "Array.isArray(this.IconPickerColor) === false",
                IconPickerColor: {$exists: true}
            };
        EntityCache.RecognitionTemplate.find(query, function (err, res) {
            if (err) {
                return callback(err);
            }
            async.each(res, function (document, cb) {
                EntityCache.RecognitionTemplate.update({hgId: document.hgId}, {$set: {IconPickerColor: [document.IconPickerColor]}}, function (err) {
                    cb(err);
                });
            }, function (err) {
                callback(err);
            });
        });
    }

    function migrateRecognitionBkgdPickerColor(callback) {
        var query = {
                $where: "Array.isArray(this.BkgdPickerColor) === false",
                BkgdPickerColor: {$exists: true}
            };
        EntityCache.RecognitionTemplate.find(query, function (err, res) {
            if (err) {
                return callback(err);
            }
            async.each(res, function (document, cb) {
                EntityCache.RecognitionTemplate.update({hgId: document.hgId}, {$set: {BkgdPickerColor: [document.BkgdPickerColor]}}, function (err) {
                    cb(err);
                });
            }, function (err) {
                callback(err);
            });
        });
    }

    function migrateRecognitionSubValue(callback) {
        var query = {
                $where: "Array.isArray(this.SubValues[0].IconPickerColor) === false",
                'SubValues[0].IconPickerColor': {$exists: true}
            },
            i, len;
        EntityCache.RecognitionTemplate.find(query, function (err, res) {
            if (err) {
                return callback(err);
            }
            async.each(res, function (document, cb) {
                for (i = 0, len = document.SubValues.length; i < len; i += 1) {
                    document.SubValues[i].IconPickerColor = [document.SubValues[i].IconPickerColor];
                }
                EntityCache.RecognitionTemplate.update({hgId: document.hgId}, {$set: {SubValues: document.SubValues}}, function (err) {
                    cb(err);
                });
            }, function (err) {
                callback(err);
            });
        });
    }

    this.Run = function (callback) {
        async.series([
            fixTangoCdnUrls,
            fixRecognitionCdnUrls,
            fixCommentCdnUrls,
            migrateRecognitionIconPickerColor,
            migrateRecognitionBkgdPickerColor,
            migrateRecognitionSubValue
        ], callback);
    };
};

module.exports = new HgMigrationFile();