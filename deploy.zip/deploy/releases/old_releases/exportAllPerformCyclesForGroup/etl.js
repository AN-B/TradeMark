/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        arrayUtil = require('../../../hgnode/util/arrayUtil.js'),
        fs = require('fs.extra'),
        csvWriterModule = require('csv-write-stream'),
        guid = require('node-uuid'),
        Async = require('async');
    function getReviewsForCycle(params, callback) {
        var sanitizeReviewDates = function (reviews) {
                if (reviews && reviews.length > 0) {
                    reviews.forEach(function (review) {
                        if (review.Peoples && review.Peoples.length > 0) {
                            review.Peoples.forEach(function (people) {
                                if (people.DueDate === 0) {
                                    people.DueDate = null;
                                }
                                if (people.SubmitDate === 0) {
                                    people.SubmitDate = null;
                                }
                            });
                        }
                    });
                }
            },
            condition = {'CycleId' : params.CycleId, DeliveryId : params.DeliveryId, 'StatusByAdminView' : {$ne : 'Archived'}},
            skip = params.Skip || 0,
            take = params.Take || 0;

        EntityCache.PerformanceReview.find(condition).skip(skip).limit(take).exec(function (err, reviews) {
            if (err) {
                callback(err, null);
            } else {
                sanitizeReviewDates(reviews);
                callback(null, reviews);
            }
        });
    }
    function loadCycleReviewsBatch(params, callback) {
        params.Skip = params.BatchIndex * params.BatchSize;
        params.Take = params.BatchSize;
        EntityCache.PerformanceCycle.findOne({hgId : params.CycleId}, function (err, cycle) {
            var cycleDetail;
            if (err || !cycle) {
                callback('error loalding cycle');
            } else {
                cycleDetail = EntityCache.CycleDetail(cycle);
                getReviewsForCycle({CycleId : cycle.hgId, DeliveryId : cycle.CurrentDeliveryId, Skip : params.Skip, Take : params.Take}, function (error, reviews) {
                    if (error) {
                        callback(err);
                    } else {
                        cycleDetail.Reviews = reviews;
                        console.log('loadCycleReviewsBatch: ' + reviews.length);
                        callback(null, cycleDetail);
                    }
                });
            }
        });
    }

    function loadTracksById(params, callback) {
        EntityCache.CareerTrack.find({hgId: {$in: params.TrackIds}}, callback);
    }

    function getReviewNumberInCycle(params, callback) {
        EntityCache.PerformanceReview.count({CycleId : params.CycleId, StatusByAdminView : {$ne : 'Archived'}}, callback);
    }

    function exportOneCycle(params, callback) {
        var numPerBatch = 10,
            numberOfBatches,
            i = -1,
            row,
            answer,
            subject,
            isReviewee = false,
            showAnswer = true,
            answerCell = '',
            writer = params.Writer,
            getValues = function (selections, question) {
                var values = [];
                if (selections && selections.forEach) {
                    selections.forEach(function (selection) {
                        arrayUtil.ObjectIndexOf(question.AnswerSelectors, 'Value', selection, function (index) {
                            if (index > -1) {
                                values.push(selection + ' (' +  question.AnswerSelectors[index].Text + ')');
                            }
                        });
                    });
                }
                return values.join(',');
            },
            exportOneBatchToCsv = function (eparams, asyncCallback) {
                loadCycleReviewsBatch(eparams, function (error, cycle) {
                    if (error) {
                        asyncCallback(error);
                    }
                    var trackIds = [];
                    cycle.Reviews.forEach(function (review) {
                        review.Card.Sections.forEach(function (section) {
                            section.Questions.forEach(function (question) {
                                if (question.TrackId && question.TrackId.length > 0 && trackIds.indexOf(question.TrackId) === -1) {
                                    trackIds.push(question.TrackId);
                                }
                            });
                        });
                    });
                    params.TrackIds = trackIds;
                    console.log('Track Ids: ');
                    console.log(trackIds);
                    loadTracksById(params, function (err, tracks) {
                        if (err) {
                            return callback(err);
                        }
                        cycle.Reviews.forEach(function (review) {
                            arrayUtil.ObjectIndexOf(review.Peoples, 'PeopleType', 'Subject', function (index) {
                                if (index === -1) {
                                    callback('Subject is required for each review');
                                }
                                subject = review.Peoples[index];

                                if (subject.EntityId === params.UserId) {
                                    isReviewee = true;
                                }
                            });
                            review.Card.Sections.forEach(function (section) {
                                section.Questions.forEach(function (question) {
                                    if (question.TrackId && question.TrackId.length > 0) {
                                        arrayUtil.ObjectIndexOf(tracks, 'hgId', question.TrackId, function (index) {
                                            if (index > -1) {
                                                question.Track = tracks[index];
                                            }
                                        });
                                    }
                                    review.Peoples.forEach(function (person) {
                                        row = [];
                                        if (person.ContainQuestionForMe) {
                                            arrayUtil.ObjectIndexOf(question.Answers, 'MemberId', person.MemberId, function (index) {
                                                row.push(cycle.hgId + '-' + person.MemberId + '-' + question.hgId); // reviewId + memberId + questionid
                                                if (index > -1) {
                                                    answer = question.Answers[index];
                                                    showAnswer = isReviewee && question.Confidential ? false : true;
                                                    row.push(review.CycleName);
                                                    row.push(review.Card.Title);
                                                    row.push(subject.MemberFullname);
                                                    row.push(subject.Department);
                                                    row.push(subject.EmployeeId);
                                                    row.push(person.Anonymous ? 'Anonymous' : person.MemberFullname);
                                                    row.push(person.Anonymous ? '000' : person.EmployeeId);
                                                    row.push(section.Title);
                                                    row.push(question.QuestionText);
                                                    if (question.AnswerType === 'RadioButton') {
                                                        answerCell = getValues(answer.SelectedValues, question);
                                                    } else {
                                                        answerCell = answer.Text.length > 0 ? answer.Text : getValues(answer.SelectedValues, question);
                                                    }
                                                    row.push(answerCell);
                                                    row.push((question.AnswerType === 'ScaleRating' && answer.SelectedValues && answer.SelectedValues.length > 0 && answer.SelectedValues[0] !== 'N/A') ? answer.SelectedValues[0] : '');
                                                    row.push(question.AllowComments && showAnswer ? answer.Text : '');
                                                    row.push(question.Track && showAnswer ? question.Track.CareerTrackTemplate.Title : '');
                                                    row.push(question.Track ? question.Track.PercentAchieved + '%' : '');

                                                } else {
                                                    row.push(review.CycleName);
                                                    row.push(review.Card.Title);
                                                    row.push(subject.MemberFullname);
                                                    row.push(subject.Department);
                                                    row.push(subject.EmployeeId);
                                                    row.push(person.Anonymous ? 'Anonymous' : person.MemberFullname);
                                                    row.push(person.Anonymous ? '000' : person.EmployeeId);
                                                    row.push(section.Title);
                                                    row.push(question.QuestionText);
                                                    row.push('');
                                                    row.push('');
                                                    row.push('');
                                                    row.push('');
                                                    row.push('');
                                                }

                                                if (row.length > 0) {
                                                    writer.write(row);
                                                }
                                            });
                                        }
                                    });
                                });
                            });
                        });
                        asyncCallback();
                    });
                });
            };
        params.CycleId = params.Cycle.hgId;
        getReviewNumberInCycle({CycleId: params.CycleId}, function (error, reviewNumber) {
            if (error) {
                return callback(error);
            }
            console.log('reviewNumber: ' + reviewNumber);
            if (!reviewNumber) {
                return callback();
            }
            numberOfBatches = Math.ceil(reviewNumber / numPerBatch);
            Async.whilst(
                function () {
                    i += 1;
                    numberOfBatches -= 1;
                    return numberOfBatches > -1;
                },
                function (asyncCallback) {
                    exportOneBatchToCsv({
                        CycleId: params.CycleId,
                        BatchIndex: i,
                        BatchSize: numPerBatch,
                        Writer: writer
                    }, asyncCallback);
                },
                function (err) {
                    if (err) {
                        console.log(err);
                        callback(err + ' error happened in exportOneBatchToCsv');
                    } else {
                        callback();
                    }
                }
            );
        });
    }

    function exportAllPerformCyclesForGroup(callback) {
        // var groupName = 'Mercury',
        var groupName = 'Communispace',
            headerFields = ["ReviewId", 'CycleName', "CardName", 'Reviewee', 'Department', 'RevieweeId', 'Reviewer', 'ReviewerId', 'Section', 'QuestionText', 'Answer', 'Rating', 'Comment', 'TrackName', 'PercentageAchieved'],
            writer = csvWriterModule({ headers: headerFields}),
            fileFullPathName = __dirname.replace('hgnode/services/internal', 'provision/') + guid.v1() + '.csv',
            cycleIndex = 0;
        writer.pipe(fs.createWriteStream(fileFullPathName));

        EntityCache.PerformanceCycle.find({GroupName: groupName}, function (error, cycles) {
            console.log('Total ' + cycles.length + ' cycles');
            if (error) {
                return callback(error);
            }
            Async.whilst(
                function () {
                    cycleIndex += 1;
                    return cycleIndex < cycles.length;
                },
                function (asyncCallback) {
                    console.log('CycleId: ' + cycles[cycleIndex - 1].hgId);
                    exportOneCycle({
                        Cycle: cycles[cycleIndex - 1],
                        Writer: writer
                    }, asyncCallback);
                },
                function (error) {
                    console.log('done');
                    writer.end();
                }
            );
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            exportAllPerformCyclesForGroup
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
