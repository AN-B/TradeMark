/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addSubscriberIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.SubscriberAudit.db.collections.SubscriberAudit.ensureIndex({
                    "EventId" : 1,
                    "ServiceName": 1,
                    "MethodName": 1,
                    "Status": 1
                }, {name : 'SubscriberIndex', background: true }, callback);
            })
        ], fcallback);
    }
    function addNotificationAuditIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.NotificationAudit.db.collections.NotificationAudit.ensureIndex({
                    "hgId" : 1,
                    "Action": 1
                }, {name : 'NotificationAuditAction', background: true }, callback);
            })
        ], fcallback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addSubscriberIndex,
            addNotificationAuditIndex
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
