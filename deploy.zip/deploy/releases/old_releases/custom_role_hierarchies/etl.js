/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');
    /*
     *  Migration Script Template
     *  You need a run function with callback parameter
     *  Must call the callback function when done.
     */
    function performUpdate(callback) {
        EntityCache.PerformanceCard.update({}, {$rename: {'SubjectManagerOnly': 'DetectableRolesOnly'}}, {multi: true}, function (error) {
            EntityCache.PerformanceCycle.find({}, function (error, performanceCycles) {
                performanceCycles.forEach(function (performanceCycle) {
                    performanceCycle.Cards.forEach(function (card) {
                        if (card.SubjectManagerOnly !== undefined) {
                            card.DetectableRolesOnly = card.SubjectManagerOnly;
                        }
                    });
                    EntityCache.PerformanceCycle.update({hgId: performanceCycle.hgId}, {$set: {'Cards' : performanceCycle.Cards}}, function (error) {
                        callback();
                    });
                    callback();
                });
            });
        });
    }
    this.Run = function (fcallback) {
        Async.series([
            performUpdate
        ], function (error, results) {
            fcallback(error, results);
        });
    };
};
module.exports = new HgMigrationFile();