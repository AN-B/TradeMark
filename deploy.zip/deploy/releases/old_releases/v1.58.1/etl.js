load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

// for All OffBoarded members
// Remove all manually added permissions 
var query = {
    MembershipStatus : 'OffBoarded'
},
update = {
    $set : {
        AddedPermissions : []
    }
};
db.Member.update(query, update, { multi : true});