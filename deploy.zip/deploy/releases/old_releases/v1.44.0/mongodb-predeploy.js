load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

// Update Membership status for Roles that have been offboarded
// This currently only affects Safe Heavn Account
var query = {
    MembershipStatus : 'Active',
    RolesInGroup : 'OffBoarded',
}, 
update = { 
	$set : {
		MembershipStatus : 'OffBoarded'
	}
};
db.Member.update(query, update, {multi : true});

//Set Member EndingDate for Offboarded Members
var query = {
    MembershipStatus : 'OffBoarded'
};
db.Member.find(query).forEach(function (item) {
	db.Member.update({hgId : item.hgId}, { $set : { EndingDate : item.ModifiedDate} })
});

//Remove EndingDate from All Active Members
var query = {
    MembershipStatus : 'Active'
};
db.Member.update(query, {$unset : { 'EndingDate' : ''}}, {multi : true})


//Drop TangoCards_Canada_0618.xlsx in Prod s3 Prod folder
//then
//Provion Tango Canada Card
//For Staging
//http://st.highground.com/svc/Provision/ManageTangoCards/TangoCards_Canada_0618.xlsx
//For Prod
//http://app.highground.com/svc/Provision/ManageTangoCards/TangoCards_Canada_0618.xlsx