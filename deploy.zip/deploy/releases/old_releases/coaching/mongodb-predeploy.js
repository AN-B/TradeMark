load("db-scripts/commonDB.js");
setEnv("local");

// //run the following script in hgthanka to migrate the binary Archived field to Status in comments
switchDB("hgthanka");
// db.Comment.update(
//     {'EntityType' : 'Coaching'},
//     {$set : {
//         // EntityType : 'Milestone',//this line is temp commented out in order not to break functionality, but should be uncommented later
//         Type : 'Coaching'

//     }},
//     {multi : true}
// );
