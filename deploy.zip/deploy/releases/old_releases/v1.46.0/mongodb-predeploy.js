load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");

db.Environment.remove();
db.Environment.insert({
    Name : 'POC Server',
    api : 'http://mopoc.highground.com/',
    s3 : "http://hgpoc.s3.amazonaws.com",
    Enabled : true,
    pkey : 'd72312475b5d02aaffb9',
    PermissionRequired : ['SwitchEnvironmentQA', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'QA Server',
    api : 'https://moqa.highground.com/',
    s3 : "https://hgqa1.s3.amazonaws.com",
    Enabled : true,
    pkey : 'a8b5910bbd4ee3de3c83',
    PermissionRequired : ['SwitchEnvironmentQA', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'Staging Server',
    api : 'http://most.highground.com/',
    s3 : 'http://hgstage.s3.amazonaws.com',
    Enabled : true,
    pkey : 'eff6d3a911b21fdbaf5a',
    PermissionRequired : ['SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'UAT Server',
    api : 'http://mouat.highground.com/',
    s3 : 'http://hguat.s3.amazonaws.com',
    Enabled : true,
    pkey : '314609f264712e7a4ce4',
    PermissionRequired : ['SwitchEnvironmentSales', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'Demo Server',
    api : 'http://modemo.highground.com/',
    s3 : 'http://hgdemo.s3.amazonaws.com',
    Enabled : true,
    pkey : 'dd6c83d01dfdde3d09cc',
    PermissionRequired : ['SwitchEnvironmentSales', 'SwitchEnvironmentHG']
});
db.Environment.insert({
    Name : 'Production Server',
    api : 'https://mo.highground.com/',
    s3 : 'https://hguat.s3.amazonaws.com',
    Enabled : true,
    pkey : 'f84b7d75fcab09fe6ff9',
    PermissionRequired : ['SwitchEnvironmentQA', 'SwitchEnvironmentSales', 'SwitchEnvironmentHG']
});

var userGroupId = {};
db.UserInfo.find().forEach(function (item) {
    if (!userGroupId[item.hgId]) {
        userGroupId[item.hgId] = item.Preference.DefaultGroupId;
    }
});

switchDB("hgperka");
var cardSkuIndex = {};
db.TangoCard.find().forEach(function (item) {
    if (item && item.Denominations && item.Denominations.length > 0) {
        item.Denominations.forEach(function (skuItem) {
            if (!cardSkuIndex[skuItem.SKU]) {
                cardSkuIndex[skuItem.SKU] = {
                    CardName : item.CardName,
                    Type : item.Type
                }
            }
        });
    }
});

db.TangoCardOrder.find().forEach(function (item) {
    update = {
        $set : {
            GroupId : userGroupId[item.UserId],
            CardName : cardSkuIndex[item.sku].CardName,
            CardType : cardSkuIndex[item.sku].Type
        }
    }
    db.TangoCardOrder.update({hgId : item.hgId}, update);
})

