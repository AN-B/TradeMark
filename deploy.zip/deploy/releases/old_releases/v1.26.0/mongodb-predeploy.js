load("../../db-scripts/commonDB.js");
setEnv("local");

// add the psuedo id to the anonymous participants
switchDB("hgperform");
db.PerformanceReview.find({'Peoples.Anonymous' : true}).forEach(
    function (review) {
        var hgId = review.hgId,
            anonymousNumber = 0,
            i;
        for (i = 0; i < review.Peoples.length; i += 1) {
            if (review.Peoples[i].Anonymous === true) {
                anonymousNumber += 1;
                review.Peoples[i].AnonymousId = anonymousNumber.toString();
            }
        }
        if (anonymousNumber > 1) {
            db.PerformanceReview.update({'hgId' : hgId}, {$set : {'Peoples' : review.Peoples}});
        }
    }
);

// clear out old NotificationQueueItem records - due to defect that did not clear out these items
switchDB("hgcommon");
hgIds=[];
hgIds=db.NotificationQueueItem.find({},{_id:0,hgId:1}).map(function(nqi){return nqi.hgId});
switchDB("hglog");
delArray=db.NotificationAudit.find({hgId:{$in:hgIds}},{_id:0,hgId:1}).map(function(na){return na.hgId});
switchDB("hgcommon");
db.NotificationQueueItem.remove({hgId:{$in:delArray}});

// add ForSalesDemo feature flag in demo for Acme
switchDB("hgcommon");
group = db.Group.findOne({GroupName:"Acme, Inc."});
if (group && group.hgId) {
    db.Group.update({hgId: group.hgId}, {$addToSet: {
        "Preference.FeatureFlags":
        {
            FeatureName: 'ForSalesDemo',
            FeatureEnabled: true
        }
    }});
}

// set the weekly daily recap to Wednesday for Allianz
switchDB("hgcommon");
group = db.Group.findOne({GroupName:"Allianz"});
if (group && group.hgId) {
    db.Group.update({hgId:group.hgId},{$set:{"Preference.WeeklyRecapEnabled":true, "Preference.WeeklyRecapDay":"Wednesday"}});
    db.Member.update({'GroupId' : group.hgId}, {$set : {'Preference.RecapType' : 'Weekly'}}, {multi : true});
}

