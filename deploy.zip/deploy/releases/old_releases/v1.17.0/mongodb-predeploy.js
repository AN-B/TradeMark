// 1. remove nodetime from non-production environments

