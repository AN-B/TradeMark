//run the following script in hgthanka to migrate the binary Archived field to Status in comments
db.Comment.update({'Archived' : {$ne : true}}, {$set : {'Status' : 'Active'}}, {multi: true});
db.Comment.update({'Archived' : true}, {$set : {'Status' : 'Archived'}}, {multi: true});
db.Comment.update({}, {$unset : {'Archived' : ''}}, {multi: true});

//run the following in hgcommon
db.Group.update({'HGAccountId' : 'HG201300001'}, {$addToSet :
    {
        'Preference.FeatureFlags' : {
            "FeatureName" : "SendRealEmails",
            "FeatureMeta" : [ ],
            "FeatureEnabled" : true
        }
    }
});

// change all manager roles back to employee role for all Adage users that were switched over
db.Member.update({'GroupId':'a951d3d0-1a43-11e3-b544-b5fd63eafa89','OldRole':'Employee'},
    {$set:{'RolesInGroup':['Employee']}}, {multi:true}
);
db.Member.update({'GroupId':'a951d3d0-1a43-11e3-b544-b5fd63eafa89','OldRole':'Employee'},
    {$unset:{'OldRole':''}}, {multi:true}
);

