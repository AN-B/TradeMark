/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function addProvisionAuditIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.ProvisionAudit.db.collections.ProvisionAudit.ensureIndex({
                    _id: 1,
                    "Content.Employees.NewUserName": 1
                }, {name : 'NewUserNameIndex', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.ProvisionAudit.db.collections.ProvisionAudit.ensureIndex({
                    _id: 1,
                    "Content.Employees.EmpID": 1
                }, {name : 'EmployeeIdIndex', background: true }, callback);
            }),
            (function (callback) {
                EntityCache.ProvisionAudit.db.collections.ProvisionAudit.ensureIndex({
                    _id: 1,
                    "Content.Employees.UserName": 1
                }, {name : 'UserNameIndex', background: true }, callback);
            })
        ], fcallback);
    }

    function addProvisionQueueIndex(fcallback) {
        Async.series([
            (function (callback) {
                EntityCache.ProvisionQueue.db.collections.ProvisionQueue.ensureIndex({
                    AuditId: 1,
                    Status: 1
                }, {name : 'CoreDocIndex', background: true }, callback);
            })
        ], fcallback);
    }

    this.Run = function (fcallback) {
        Async.series([
            addProvisionAuditIndex,
            addProvisionQueueIndex
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
