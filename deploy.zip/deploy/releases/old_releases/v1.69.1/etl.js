load('../../db-scripts/commonDB.js');
setEnv("local");

switchDB('hgcommon');

// add new default value level for Director role on existing companies that have levels enabled
var groups=db.Group.find({ValueLevelSetting:{$exists:true}});
if (groups && groups.length) {
    groups.forEach(function (group) {
        if (group.ValueLevelSetting && group.ValueLevelSetting.Levels && group.ValueLevelSetting.Levels.length === 4) {
            group.ValueLevelSetting.Levels.forEach(function (level) {
                if (level.AvailabilityToRoles && level.AvailabilityToRoles.length) {
                    if (!level.AvailabilityToRoles.filter(function (l) {
                            return l.RoleName == 'Director';
                        }).length) {
                        level.AvailabilityToRoles.splice(2, 0, {
                            RoleName: 'Director',
                            Allowed: true,
                            LimitNumber: NumberInt(10)
                        });
                    }
                }
            });
            //print(group.ValueLevelSetting.Levels);
            db.Group.save(group);
            print(group.GroupName+' updated.');
        }
    });
}
