/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function fixRecognitionSource(callback) {
        EntityCache.Recognition.update({
            'TriggerInfo.GroupName': { $exists: true, $ne: ""}
        }, {
            $set:  {
                Source: 'RulesEngine'
            }
        }, {multi: true}, callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            fixRecognitionSource
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
