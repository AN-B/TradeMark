load("../db-scripts/commonDB.js");
setEnv("poc");

switchDB("hgsecurity");

db.ClientProfile.remove({ClientName : 'SalesForce'});

db.ClientProfile.insert({
    hgId : 'd9f64db1-d80f-422e-b23a-3ec368c671f4',
    "ClientName" : "SalesForce",
    "APIKey" : 'ab090607-2b7f-40a0-85a5-054aeadf23b5',
    "APIKeyVersion" : "v1.0.1",
    "APIKeyStatus" : "Active",
    "AvailableServices" : [
        'EventBus',
        'Recognition'
    ],
    "CreatedDate" : 1356019594383
});