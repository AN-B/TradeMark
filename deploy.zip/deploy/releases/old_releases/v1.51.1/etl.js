load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgperform");

var num = db.PerformanceReview.find({StatusByAdminView : "NotStarted", "Peoples.StatusInCurrentReview" : {$in : ["Submitted"]}}).count();
print(num);

db.PerformanceReview.update(
    {
        StatusByAdminView : "NotStarted",
        "Peoples.StatusInCurrentReview" : {$in : ["Submitted"]}
    },
    {
        $set : {StatusByAdminView : 'InProgress'}
    },
    {multi : true}
);

switchDB("hgthanka");

//fidelity GroupId "hgId" : "00198240-dd2f-11e3-93df-ed2289aa62ed"
// var query = {
//     'Template.GroupId' : "00198240-dd2f-11e3-93df-ed2289aa62ed",
//     'RecipientMember.hgId' : '5ab88433-f34d-11e3-a59e-0d7834fe1cb5'
// };
//db.Recognition.find(query).sort({CreatedDate : -1})

// Recognition Given to Harriet Kwast that needs to be deleted.
// hgId : 8e9ddc40-1ceb-11e4-8bd2-637669b9a524
// BatchId : 8e8d8890-1ceb-11e4-8bd2-637669b9a524
// GivenBy MemberId : deb35572-198f-11e4-b352-2f852ff1ccb1
// Given Date : 1406906643601.000000

// Recognition Given to Chris Saltzman that needs to be deleted.
// hgId : c1cdcda0-1ceb-11e4-b599-27288ff46877
// BatchId : c1c03910-1ceb-11e4-b599-27288ff46877
// GivenBy MemberId : deb35572-198f-11e4-b352-2f852ff1ccb1
// Given Date : 1406906643601.000000

//Soft Delete Harriet Kwast Recognition
db.Recognition.update({hgId : '8e9ddc40-1ceb-11e4-8bd2-637669b9a524'}, {
    $set : {
        Status : 'Deleted',
        BatchId : '8e9ddc40-1ceb-11e4-8bd2-637669b9a524'
    }
})

//Soft Delete Chris Saltzman Recognition
db.Recognition.update({hgId : 'c1cdcda0-1ceb-11e4-b599-27288ff46877'}, {
    $set : {
        Status : 'Deleted',
        BatchId : 'c1cdcda0-1ceb-11e4-b599-27288ff46877'
    }
})

db.Recognition.find({hgId : { $in :
        ['8e9ddc40-1ceb-11e4-8bd2-637669b9a524',
            'c1cdcda0-1ceb-11e4-b599-27288ff46877']}},
    {_id : 0, 'RecipientMember.FullName' : 1, Status : 1, hgId : 1})


switchDB("hgreports");
/**** Fix Metrics Data for Harriet Kwast  add Chris Saltzman and Team Fidelitity
 Recognitions given by the same user 2 minutes apart
 ***/
//Chris Saltzman recognition given 1407275962259 (2014-08-01) --> 1406851200000 // hour 21
var query = {
    g : "00198240-dd2f-11e3-93df-ed2289aa62ed",
    p : {  $gte : new Date(1407196800000), $lt : new Date(1407275962259) }
};
var update = {$set : { "h.21" : 45, t : 49}};
db.MetricsRecognition.update(query, update, { upsert : false});
//db.MetricsRecognition.find(query).sort({p : -1});


// Category of Recognition was Achievement.Anniversary
var query = {
    g : "00198240-dd2f-11e3-93df-ed2289aa62ed",
    c : "Achievement.Anniversary",
    p : {  $gte : new Date(1407196800000), $lt : new Date(1407275962259) }
};
var update = {$set : { t : 33}};
db.MetricsRecognitionCategory.update(query, update)
//db.MetricsRecognitionCategory.find(query).sort({p : -1});

//Recognition Source was Internal
var query = {
    g : "00198240-dd2f-11e3-93df-ed2289aa62ed",
    c : "Internal",
    t : 50,
    p : {  $gte : new Date(1407196800000), $lt : new Date(1407275962259) }
};
var update = {$set : { t : 48}};
db.MetricsRecognitionSource.update(query, update);
//db.MetricsRecognitionSource.find(query)

//Recognition was given by Department "" so we user Other
var query = {
    g : "00198240-dd2f-11e3-93df-ed2289aa62ed",
    d : "Other",
    p : {  $gte : new Date(1407196800000), $lt : new Date(1407275962259) }
};
var update = {$set : { t : 42}};
db.MetricsDepartment.update(query, update);
//db.MetricsDepartment.find(query)

//User Member for Metric for user that gave recognition
var query = {
    g : "00198240-dd2f-11e3-93df-ed2289aa62ed",
    m : "deb35572-198f-11e4-b352-2f852ff1ccb1",
    c : "RecognitionGiven",
    p : {  $gte : new Date(1407196800000), $lt : new Date(1407275962259) }
};
var update = {$set : { t : 43}};
//db.MetricsMember.find(query);
db.MetricsMember.update(query, update);


//User Member for Metric for user that received the recognition Harriet
var query = {
    g : "00198240-dd2f-11e3-93df-ed2289aa62ed",
    m :  "5ab612c1-f34d-11e3-a59e-0d7834fe1cb5", //Harriet
    c : "RecognitionReceived",
    p : {  $gte : new Date(1407196800000), $lt : new Date(1407275962259) }
};
var update = {$set : { t : 0}};
db.MetricsMember.update(query, update);
//db.MetricsMember.find(query)

//User Member for Metric for user that received the recognition Harriet
var query = {
    g : "00198240-dd2f-11e3-93df-ed2289aa62ed",
    m :  "5ab88433-f34d-11e3-a59e-0d7834fe1cb5", //Chris
    c : "RecognitionReceived",
    p : {  $gte : new Date(1407196800000), $lt : new Date(1407275962259) }
};
var update = {$set : { t : 0}};
db.MetricsMember.update(query, update);
// db.MetricsMember.find(query)


