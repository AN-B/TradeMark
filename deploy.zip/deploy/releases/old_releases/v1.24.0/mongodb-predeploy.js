load("db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

db.Badge.update({'SpecialUsages' : {$exists : false}}, {$set : {'SpecialUsages' : []}}, {multi : true});

db.RecognitionTemplate.update({'IsPublic' : {$ne : true}}, {$set : {'Publicity' : 'Private'}}, {multi: true});
db.RecognitionTemplate.update({'IsPublic' : true}, {$set : {'Publicity' : 'Both'}}, {multi: true});

db.Recognition.find({'BadgeFilename' : {$exists : false}}).forEach(
    function (recognition) {
        if (recognition && recognition.Template) {
            db.Recognition.update({'hgId' : recognition.hgId}, {$set : {'BadgeFilename' : recognition.Template.hgId}});
        }
    }
);

db.Recognition.find({'BadgeFilename' : ''}).forEach(
    function (recognition) {
        if (recognition && recognition.Template) {
            db.Recognition.update({'hgId' : recognition.hgId}, {$set : {'BadgeFilename' : recognition.Template.hgId}});
        }
    }
);

// clean up the log by removing all of the info cluster logging
switchDB("hglog");
db.log.remove({message:{$regex:"Cluster worker.*"},level:"info"});