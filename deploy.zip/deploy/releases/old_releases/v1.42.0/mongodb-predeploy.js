load("../../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgthanka");

//populate the new property CareerTrackTemplate.MilestoneWeightType with a default value
print('populate CareerTrackTemplate.MilestoneWeightType with a default value "Equally"'); 
db.CareerTrack.update({'CareerTrackTemplate.MilestoneWeightType' : { $exists : false}}, {$set : {'CareerTrackTemplate.MilestoneWeightType' : 'Equally'}}, {multi : true});

//---Recognition Re-Categorization---//
//-1- Update Welcome Recognitions that have their Category Set to Everyday. Change Category to System
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'Everyday',
    'Template.Title' : { $regex : 'Welcome', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'System'}};
db.Recognition.update(query, update, {multi : true})

//-2- Set SubCategory Field for Welcome Recognitions
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Title' : { $regex : 'Welcome', $options : 'i'}
},
update = { $set : { 'Template.SubCategory' : 'Welcome'}};
db.Recognition.update(query, update, {multi : true})

//-3- For all System Birthday Recognitions that have the Category set to Everyday to System
var query = {
    'CreatorMember.FullName' : '', //<-- indicates system recognition
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'Everyday',
    'Template.Title' : { $regex : 'Birthday', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'System'}};
db.Recognition.update(query, update, {multi : true})

//-4- For all System Birthday Recognitions that have the Category set to Acheivements to System
var query = {
    'CreatorMember.FullName' : '', //<-- indicates system recognition
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'Acheivements',
    'Template.Title' : { $regex : 'Birthday', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'System'}};
db.Recognition.update(query, update, {multi : true})

//-5- For all manually Created Birtday Recognitions that have the Category to set System, Change to Everyday
var query = {
    'CreatorMember.FullName' : { $ne : ''}, //<--Manully Created Recognitions
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'System', //<-- Currently Set to System
    'Template.Title' : { $regex : 'Birthday', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'Everyday'}};
db.Recognition.update(query, update, {multi : true})

//-6- For all System Birthday Recognitions that Set the Sub-Category to 'Birthday'
var query = {
    'CreatorMember.FullName' : '',
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'System',
    'Template.Title' : { $regex : 'Birthday', $options : 'i'}
},
update = { $set : { 'Template.SubCategory' : 'Birthday'}};
db.Recognition.update(query, update, {multi : true})

//-7- For all System Anniversary Recognitions that have the Category set to Everyday, Change to System
var query = {
    'CreatorMember.FullName' : '', //<--System Recognitions
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'Everyday',
    'Template.Title' : { $regex : 'Anniversary', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'System'}};
db.Recognition.update(query, update, {multi : true})

//-8- For all System Anniversary Recognitions that have the Category set to Achievement, Change to System
var query = {
    'CreatorMember.FullName' : '', //<--System Recognitions
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'Achievement',
    'Template.Title' : { $regex : 'Anniversary', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'System'}};
db.Recognition.update(query, update, {multi : true})

//-9- For all System Anniversary Recognitions that have the Category set to Achievements, Change to System
var query = {
    'CreatorMember.FullName' : '', //<--System Recognitions
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'Achievements',
    'Template.Title' : { $regex : 'Anniversary', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'System'}};
db.Recognition.update(query, update, {multi : true})

//-10- For all manually Created Anniversary Recognitions that have the Category set to System, Change to Anniversary
var query = {
    'CreatorMember.FullName' : { $ne : ''}, //<--Manually Created Recognitions
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'System',
    'Template.Title' : { $regex : 'Anniversary', $options : 'i'}
},
update = { $set : { 'Template.Category' : 'Achievements'}};
db.Recognition.update(query, update, {multi : true})

//-11- For all System Anniversary Recognitions, Set the Sub-Category to 'Anniversary'
var query = {
    'CreatorMember.FullName' : '', //<--System Recognitions
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category' : 'System',
    'Template.Title' : { $regex : 'Anniversary', $options : 'i'}
},
update = { $set : { 'Template.SubCategory' : 'Anniversary'}};
db.Recognition.update(query, update, {multi : true})

//-12- Four Adage News Items were miscategorized as Recognitions. Change switch from Template.Type to Newsfeed
var adageMiscategorizedNewsRecognitions = [
    "9a835530-3b69-11e3-9816-a3909a21f741",
    "9a841880-3b69-11e3-9816-a3909a21f741",
    "9a8502e0-3b69-11e3-9816-a3909a21f741",
    "9a859f20-3b69-11e3-9816-a3909a21f741"
],
query = {
    hgId : { $in : adageMiscategorizedNewsRecognitions}
},
update = { $set : { 'Template.Type' : 'Newsfeed'}};
db.Recognition.update(query, update, {multi : true});

//-13- For all Everyday Recognitions that do not have a SubCategory Type Set. Set SubCategory Type to Default
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.SubCategory' : null,
    'Template.Category'  : 'Everyday',
},
update = { $set : { 'Template.SubCategory' : 'Default'}};
db.Recognition.update(query, update, {multi : true})

//-14- For all Values Recognitions that do not have a SubCategory Type Set. Set SubCategory Type to Default
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.SubCategory' : null,
    'Template.Category'  : 'Values',
},
update = { $set : { 'Template.SubCategory' : 'Default'}};
db.Recognition.update(query, update, {multi : true})

//-15- For all Achievements Recognitions that the Category type Missplaced as Achievement and Acheivements change Category type to Achievements
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.SubCategory' : null,
    'Template.Category'  : { $in : ['Acheivements', 'Achievements'] }
},
update = { $set : { 'Template.Category' : 'Achievement'}};
db.Recognition.update(query, update, {multi : true})

//-16- Update for 11 recognitions that did not have Category set. These recognitions happen to be
// track completion recognitions. Setting Category to Achievement and Sub Category to TrackCompletion
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.SubCategory' : null,
    'Template.Category'  : '',
    "Message" : "This track has been completed."
},
update = { $set : { 'Template.Category' : 'Achievement', 'Template.SubCategory' : 'TrackCompletion'}};
db.Recognition.update(query, update, {multi : true})

//-17- For all Achievements Recognitions that do not have a SubCategory Type Set. Set SubCategory Type to Default
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.SubCategory' : null,
    'Template.Category'  : 'Achievement',
},
update = { $set : { 'Template.SubCategory' : 'Default'}};
db.Recognition.update(query, update, {multi : true})

//-18- For all Achievement Recognition with the Message : This track has been completed, Set the SubCategory Type to TrackCompletion
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category'  : 'Achievement',
    'Message' : 'This track has been completed.'
},
update = { $set : { 'Template.SubCategory' : 'TrackCompletion'}};
db.Recognition.update(query, update, {multi : true})

//-19- For all Everyday Recognition with the Message : This track has been completed, Set the SubCategory Type to TrackCompletion
var query = {
    'Template.Type' : { $ne : 'Newsfeed'},
    'Template.Category'  : 'Everyday',
    'Message' : 'This track has been completed.'
},
update = { $set : { 'Template.SubCategory' : 'TrackCompletion'}};
db.Recognition.update(query, update, {multi : true})

//----Recognition Template Update----//

//-20- Their is one welcome recongition template that has a category set to Acheivements. Change Set it to System
var query = {
    Title : { $regex : 'Welcome', $options : 'i'},
    Category : 'Acheivements'
},
update = { $set : { 'Category' : 'System'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-21- Set the SubCategory for all welcome recongition template to Welcome
var query = {
    Title : { $regex : 'Welcome', $options : 'i'},
},
update = { $set : { 'SubCategory' : 'Welcome'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-22- Set Birthday recognition templates to System. Currently we have 5 Birthday rec. templates set to Achievement, Everyday, and Acheivements
var query = {
    Title : { $regex : 'Birthday', $options : 'i'},
    Category : { $ne : 'System'}
},
update = { $set : { 'Category' : 'System'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-23- Set Birthday recognition Sub Category templates to Birthday.
var query = {
    Title : { $regex : 'Birthday', $options : 'i'}
},
update = { $set : { 'SubCategory' : 'Birthday'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-24- Set all missplaced Achievement Category templates properly. Change from Acheivements to Achievement
var query = {
    Category : 'Acheivements'
},
update = { $set : { 'Category' : 'Achievement'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-25- Set the sub-category for all Anniversary Recognitions to 'Anniversary'
var query = {
    Title : { $regex : 'Anniversary', $options : 'i'}
},
update = { $set : { 'SubCategory' : 'Anniversary'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-26- Set the sub-category for all Anniversary Recognitions to 'Anniversary'
var query = {
    Title : { $regex : 'Anniversary', $options : 'i'}
},
update = { $set : { 'SubCategory' : 'Anniversary'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-27- Set the sub-category for all Values Recognitions to 'Default'
var query = {
    Category : 'Values'
},
update = { $set : { 'SubCategory' : 'Default'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-27- Set the sub-category for all Values Recognitions to 'Default'
var query = {
    Category : 'Values'
},
update = { $set : { 'SubCategory' : 'Default'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-28- For Achievement rec. templates that do not have a sub-category, Set the SubCategory to Default
var query = {
    SubCategory : null,
    Category : 'Achievement'
},
update = { $set : { 'SubCategory' : 'Default'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-29- For Everyday rec. templates that do not have a sub-category, Set the SubCategory to Default
var query = {
    SubCategory : null,
    Category : 'Everyday'
},
update = { $set : { 'SubCategory' : 'Default'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-30- For System rec. templates that do not have a sub-category, Set the SubCategory to Default
var query = {
    SubCategory : null,
    Category : 'System'
},
update = { $set : { 'SubCategory' : 'Default'}};
db.RecognitionTemplate.update(query, update, {multi : true})

//-31- Set all Edge Communications to Deleted. Edge Communications Do not have Recognitions Enabled.
var query = {
    'Template.GroupName' : 'Edge Communications'
},
update = { $set : { 'Status' : 'Deleted'}};
db.Recognition.update(query, update, {multi : true})

switchDB("hgcommon");
//-32- Remove all Edge Communications Metric Recognition Data
var edgeGroupId = db.Group.findOne({GroupName : 'Edge Communications'}, {hgId : 1});
if (edgeGroupId !== null) {
    switchDB("hgreports");
    var query = {
        g : edgeGroupId.hgId
    };
    db.MetricsRecognition.remove(query);
    db.MetricsRecognitionCategory.remove(query);
    db.MetricsRecognitionSource.remove(query);
    db.MetricsRecognitionShare.remove(query);
    var query = {
        g : edgeGroupId.hgId,
        c : { $in : ['RecognitionReceived', 'RecognitionGiven', 'LinkedInShares']}
    };
    db.MetricsDepartment.find(query);
    db.MetricsMember.find(query);
}

switchDB("hgthanka");
//-33- Set Default Recognition Source to Web. Their is one recognition that does not have this set
var query = {
    Source : null,
    Status : 'Active',
    'Template.Type' : { $ne : 'Newsfeed'}
},
update = { $set : {Source  : 'Web'}};
db.Recognition.update(query, update, {multi : true})

switchDB("hgreports");
//-33- Fix Bad Metrics data with missing member Id
var query = {
    m : null
};
db.MetricsMember.remove(query, {multi : true});


//Metrics Recogntion Migration
/*To change local time to UTC :

sudo ln -sf /usr/share/zoneinfo/UTC /etc/localtime

// recognition migration
deploy/Analytics/recogntion.js

// capturing users that deleted a review
deploy/Analytics/archived-Review.js

// migrating deliver cycle data
deploy/Analytics/migrate-cycles.js
*/