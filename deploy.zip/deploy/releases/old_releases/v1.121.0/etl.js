var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        async = require('async');

    function addClientProfileType(callback) {
        EntityCache.ClientProfile.update({ClientType: {$exists: false}}, {ClientType: 'Group'}, {multi: true}, function (err, num) {
            console.log('updated ' + num + ' records');
            callback();
        });
    }

    this.Run = function (callback) {
        async.series([
            addClientProfileType
        ], callback);
    };
};

module.exports = new HgMigrationFile();