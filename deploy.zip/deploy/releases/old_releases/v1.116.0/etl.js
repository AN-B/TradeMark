/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function updateOverDuGoalAlerts(callback) {
        EntityCache.ManagerAlert.find({
            AlertType: 'GoalUpdateOverdue',
            Status: 'Active',
            'Data.GoalId': {$exists: true}
        }, function (error, alerts) {
            if (error) {
                return callback(error);
            }
            Async.each(alerts, function (alert, alertCallback) {
                EntityCache.Goal.findOne({
                    hgId: alert.Data.GoalId
                }, function (error, goal) {
                    if (error || !goal) {
                        return alertCallback(error);
                    }
                    EntityCache.ManagerAlert.update({
                        hgId: alert.hgId
                    }, {
                        $set: {
                            'Data.GoalName': goal.Name
                        }
                    }, alertCallback); 
                });
            }, callback);
        });
    }

    function addAdhocGoalFeatureFlag(callback) {
        EntityCache.Group.update({
            'Preference.FeatureFlags': {
                $elemMatch: {
                    FeatureName: 'EnableGoals',
                    FeatureEnabled: true
                }
            }
        }, {
            $addToSet: {
                'Preference.FeatureFlags': {
                    FeatureName: 'AdhocGoal',
                    FeatureMeta: [],
                    FeatureEnabled: true
                }
            }
        }, {multi: true}, callback);
    }

    this.Run = function (fcallback) {
        Async.series([
            updateOverDuGoalAlerts,
            addAdhocGoalFeatureFlag
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
