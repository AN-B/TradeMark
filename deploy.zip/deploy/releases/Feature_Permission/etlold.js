 var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function insertFeaturePermission(callback) {

        var theTimestamp = (new Date()).getTime();
 EntityCache.FeaturePermission.insertMany([{
			FeatureName : "ShareLink",
			Permission: ["ShareLink"],
			Description: "Social Media Sharing",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},
			
		{
			FeatureName : "EnableLanguages",
			Permission: ["EnableLanguages"],
			Description: "Enable Languages",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},
			
		{
			FeatureName : "RestrictAvatarSetting",
			Permission: ["AllowAvatarUpload"],
			Description: "Restrict users from setting avatar",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},
			
		{
			FeatureName : "HideSeeAllNotification",
            Permission: ["AllImportantNotifications"],
            Description: "Hide All Notification",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			
		{
			FeatureName : "TurnOffTeam",
            Permission: ["AdhocTeam","TeamManagement","TeamAdmin"],
            Description: "Turn Off ad-hoc Team",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			
		{
			FeatureName : "PreventProfileInfoEditing",
            Permission: ["AllowProfileInfoEditing"],
            Description: "Prevent users from editing account profile info",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			
		{
			FeatureName : "CustomProfanityFilter",
			Permission: ["ManageProfanity"],
			Description: "Custom Profanity Filter",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},	
			
		{
			FeatureName : "DisableValues",
			Permission: ["ValuesRecognition"],
			Description: "Refers to the Values tab when giving a recognition in Recognition 2.0.",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},

		{
			FeatureName : "DisableMotivate",
			Permission: ["SendCreditsInRecognition"],
			Description: "Motivate",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},
			
		{
			FeatureName : "EnableTeamTab",
			Permission: ["TeamTabManagement"],
			Description: "Team Tab",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},
			
		{
			FeatureName : "EnableLocation",
			Permission: ["ManageLocation","SeeLocation"],
			Description:  "Location",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
			},
			
		{
			FeatureName : "EnableDisplay",
			Permission: ["ManageDisplay"],
			Description: "Kiosk",
            "CreatedDate": theTimestamp,
            "CreatedBy": "Admin",
            "ModifiedDate": theTimestamp,
            "ModifiedBy": "Admin"
	    },
			{
            FeatureName: "SpendCreditTransfer",
            Description: "Spend Credit Transfer",
			Permissions: ["TransferSpendCredits"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnablePoints",
            Description: "Points (virtual currency)",
			Permissions: ["AddGiftToOldRecognition",
                          "ShowPointsInPublicFeed",
                          "GivePointGift",
                          "PointStore",
                          "ManagePointEconomy",
                          "ManageProductOrder",
                          "ManageProductItem",
                          "SendPointsInRecognition",
                          "AddPointsInRecognition",
                          "MemberPoint"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnableAddPoints",
            Description: "Enable Add Points",
			Permissions: ["AddPointsInRecognition"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "Recognition2",
            Description: "Recognition",
			Permissions: ["CustomizedRecognition",
                          "EverydayRecognition",
						  "ValuesRecognition",
                          "GiveRecognitionToDepartment",
                          "GiveRecognitionToLocation",
                          "AllowSelectAllWhenGivingRecognition",
                          ],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "HideRecognitionByLocation",
            Description: "Hide Giving Recognition By Department",
			Permissions: ["GiveRecognitionToLocation"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "HideRecognitionByDepartment",
            Description: "Hide Giving Recognition By Department",
			Permissions: ["GiveRecognitionToDepartment"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "HideSelectAllWhenGivingRecognition",
            Description: "Hide Select All when giving recognition",
			Permissions: ["AllowSelectAllWhenGivingRecognition"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "DisableTracks",
            Description: "Tracks",
			Permissions: ["CreateTrack"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "GoalWeighting",
            Description: "Create weighted Goal Cycle",
			Permissions: ["GoalWeighting"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "SkipGoalApproval",
            Description: "Skip goal setting or closing approval",
			Permissions: ["SkipGoalApproval"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "RecurringGoalCycle",
            Description: "Recurring Goal Cycle",
			Permissions: ["RecurringGoalCycle"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "GoalLibrary",
            Description:"Goal Library and assign goals",
			Permissions: ["ManageGoalLibrary"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "OpenClosedGoal",
            Description: "Allow user to reopen closed goals",
			Permissions: ["OpenClosedGoal"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "UploadGoalCycleParticipants",
            Description:"Upload goal cycle participants",
			Permissions: ["UploadGoalCycleParticipants"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "ContinuousFeedback",
            Description: "Continuous Feedback",
			Permissions: ["ContinuousFeedback","ManageFeedback"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "UserNotificationPreference",
            Description: "User Notification Preference",
			Permissions: ["UserNotificationPreference"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "RestrictChatWidget",
            Description: "Restrict chat widget from rendering",
			Permissions: ["UserNotificationPreference"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "DontPersistCookies",
            Description: "Don't Persist Cookies",
			Permissions: ["DontPersistCookies"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "ForSalesDemo",
            Description: "SalesDemo",
			Permissions: ["FeedbackDemo"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnableConversationGuide",
            Description:"Enable the conversation guide",
			Permissions: ["EnableConversationGuide"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "FeedbackCheckin",
            Description: "Feedback Checkin",
			Permissions: ["EnableConversationGuide","TeamCheckin","FeedbackCheckin","ManageFeedback"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "HideHelpLink",
            Description: "Hide Help Link",
			Permissions: ["HideHelpLink"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "ManagerCheckin",
            Description: "Manager Checkin",
			Permissions: ["ManagerCheckin"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnableGoals",
            Description:"Goals",
			Permissions: ["TeamGoals"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "RequestFeedback",
            Description: "Request Feedback",
			Permissions: ["RequestFeedback","ManageFeedback"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "GiveFeedback",
            Description:  "Give unsolicited feedback",
			Permissions: ["GiveFeedback","ManageFeedback"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "TalentInsights",
            Description:  "Talent Insights",
			Permissions: ["TalentInsights","ManageTalentInsight"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "PerformGoal",
            Description: "Enable Goal Type Questions In Perform Cards",
			Permissions: ["PerformGoal"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "NumericPercentageTarget",
            Description: "Create Percentage Type Target For Numeric Goal Key Result",
			Permissions: ["NumericPercentageTarget"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "SelectRecapTime",
            Description: "Allow admin select recap email time",
			Permissions: ["SelectRecapTime"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "AdhocGoal",
            Description: "Allow admin select recap email time",
			Permissions: ["AdhocGoal"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "MobileAllowCompanyGoalMod",
            Description:"Mobile Allow Company Goal Modification",
			Permissions: ["MobileAllowCompanyGoalMod"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "MobileAllowTeamGoalMod",
            Description: "Mobile Allow Department Goal Modification",
			Permissions: ["MobileAllowTeamGoalMod"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnableGoals",
            Description:  "Goals",
			Permissions: ["ManageGoalCycle","Goal"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnableBenchmarkSurvey",
            Description: "Enable Benchmark Survey",
			Permissions: ["BenchmarkSurvey","ManageBenchmarkSurvey","ManagePulseSurvey"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnablePulseSurvey",
            Description: "Enable Pulse Survey",
			Permissions: ["PulseSurvey","ManagePulseSurvey"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnableTutorials",
            Description:  "User Tutorials",
			Permissions: ["Tutorials"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "ReqFeedbackAboutOthers",
            Description: "Request feedback about others",
			Permissions: ["ReqFeedbackAboutOthers"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "EnableOptOutPublicRec",
            Description: "Allow users to make all recognitions private",
			Permissions: ["EnableOptOutPublicRec"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "AllowSurveyKiosk",
            Description: "Allow Survey Kiosk",
			Permissions: ["AllowSurveyKiosk"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "SuggestRewardIdea",
            Description: "Suggest Reward Idea",
			Permissions: ["SuggestRewardIdea"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{
            FeatureName: "RestrictToSingleSession",
            Description:  "Restrict to a single login session",
			Permissions: ["RestrictToSingleSession"],
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            }], callback);

    }

    this.Run = function (fcallback) {
        Async.series([
            insertFeaturePermission
        ], fcallback);
    };
};
module.exports = new HgMigrationFile();