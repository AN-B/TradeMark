var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function updateCC(file, cb) {
        var fs = require('fs'),
            readline = require('readline'),
            rd = readline.createInterface({
                input: fs.createReadStream(file),
                output: process.stdout,
                terminal: false
            }),
            headers,
            cCode,
            empId,
            fields,
            ccCount = {},
            ccodeIndex,
            empIdIndex,
            bucketCode,
            buckets = {};

        console.log('reading ' + file);

        rd.on('line', function (line) {
            if (line && line.length) {
                if (line.indexOf('COST_CNTR_CD') > -1) {
                    headers = line.split('|');
                    ccodeIndex = headers.indexOf('COST_CNTR_CD');
                    empIdIndex = headers.indexOf('EMPL_ID');
                } else {
                    fields = line.split('|');
                    if (fields && fields.length) {
                        cCode = fields[ccodeIndex].replace(/ /g, '');
                        empId = fields[empIdIndex].replace(/ /g, '');
                        if (cCode && empId) {
                            if (!ccCount[cCode]) {
                                ccCount[cCode] = 1;
                            }
                            bucketCode = ccCount[cCode] + '**' + cCode;
                            if (!buckets[bucketCode]) {
                                console.log('creating bucket: ' + bucketCode);
                                buckets[bucketCode] = [empId];
                            } else {
                                buckets[bucketCode].push(empId);
                                // split into buckets of 1000 so the query is smaller
                                if (buckets[bucketCode].length === 1000) {
                                    ccCount[cCode] += 1;
                                }
                            }
                        }
                    }
                }
            }
        });

        rd.on('close', function () {
            Async.eachLimit(Object.keys(buckets), 10, function (key, eCb) {
                console.log('updating bucket: ' + key);
                EntityCache.Member.update({
                    GroupName: "United Airlines",
                    EmployeeId: {$in: buckets[key]}
                }, {
                    $set: {CostCenter: key.split('**')[1]}
                }, {multi: true}, function (err, count) {
                    if (err) {
                        return eCb(err);
                    }
                    eCb();
                });
            }, function (err) {
                if (err) {
                    return cb(err);
                }
                cb();
            });
        });
    }

    function updateCostCenter(callback) {
        var dir = __dirname.replace('projects/hgapp/deploy/releases/Misc', '');
        updateCC(dir + 'DesktopStuff/clients/united/united_demographics_full_20161020.txt', function (err) {
            if (err) {
                return callback(err);
            }
            updateCC(dir + 'DesktopStuff/clients/united/united_demographics_changes_20161103.txt', function (err) {
                if (err) {
                    return callback(err);
                }
                callback();
            });
        });
    }

    this.Run = function (fcallback) {
        Async.series([
            updateCostCenter
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
