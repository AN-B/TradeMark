var fs = require('fs'),
    readline = require('readline'),
    count = 0,
    supervisors = {},
    columns = [
        'EMPL_LAST_NM',
        'EMPL_FIRST_NM',
        'EMPL_PREF_NM',
        'EMPL_ID',
        'BIRTH_DATE',
        'COMPY_SEN_DATE',
        'LOC_CD',
        'MAIL_CD',
        'EMPL_HOME_CNTRY',
        'COST_CNTR_CD',
        'DIVISION_CD',
        'DIVISION',
        'JOB_CD',
        'JOB_TILE',
        'JOB_LVL',
        'UNION_CD',
        'EMPL_BEN_STATUS',
        'SPVR_ID',
        'EMAIL'
    ],
    rd,
    ws = fs.createWriteStream('hris-' + Date.now() + '.txt');

rd = readline.createInterface({
    input: fs.createReadStream('CDSPNP1.KK.RECOGN.PROD.OUT.G0006V00.txt'),
    output: process.stdout,
    terminal: false
});

rd.on('line', function (line) {
    var cols;
    if (count) {
        cols = line.split('|');
        if (cols[17].indexOf('U') === -1) {
            cols[17] = 'U' + cols[17];
        }
        if (!cols[18].length) {
            cols[18] = cols[3] + '@united.com';
        }
        cols.length = 19;
    } else {
        cols = line.split('|').filter(function (c) {
            return c.replace(/ /g, '').length;
        });
    }
    ws.write(cols.join('|') + '\r');
    count += 1;
});

rd.on('close', function () {
    ws.end();
    process.exit();
});
