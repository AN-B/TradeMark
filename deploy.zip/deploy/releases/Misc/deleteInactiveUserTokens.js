var groupName = "United Airlines",
    groupId = db.Group.findOne({GroupName: groupName}).hgId,
    memberBuckets = [],
    bucket = [];

db.Member.find({GroupId: groupId, MembershipStatus: 'InActive'}, {UserId: 1, _id: -1}).forEach(function (mem) {
    bucket.push(mem.UserId);
    if (bucket.length === 500) {
        memberBuckets.push(bucket.slice(0));
        bucket.length = 0;
    }
});

memberBuckets.forEach(function (bu) {
    db.UserInfoWithToken.remove({hgId: {$in: bu}});
});
