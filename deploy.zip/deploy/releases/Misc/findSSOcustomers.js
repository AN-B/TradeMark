var groupIds = [],
    groupNames = [];
db.GroupSSO.find({"SAML.entryPoint":{$exists:true,$ne:""}},{GroupId:1,_id:0}).forEach(function (g) {
    groupIds.push(g.GroupId);
});
db.Group.find({hgId:{$in:groupIds},Status:"Active"}).forEach(function(g) {
    groupNames.push(g.GroupName);
});
printjson(groupNames.sort());