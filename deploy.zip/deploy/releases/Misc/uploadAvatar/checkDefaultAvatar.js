var userMap = require('./prod.json'),
    missing = require('./missingPhotosList.json'),
    async = require('async'),
    exec = require('child_process').exec,
    environment = 'prod',
    defaultAvatarHeader = "/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAAA8AAD/4QMtaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI";

async.waterfall([
    function (wcb) {
        Object.keys(userMap).forEach(function (k) {
            if (missing.indexOf(k) > -1) {
                userMap[k] =  null;
            }
        });
        wcb();
    },
    function (wcb) {
        console.log('Reading AWS Key...');
        exec('heroku config:get AWS_KEY --app hgn' + environment, function (err, key) {
            if (err) {
                return wcb(err);
            }
            if (!key) {
                return wcb('AWS Key missing!');
            }
            process.env.AWS_KEY = key.replace('\n','');
            wcb();
        });
    },
    function (wcb) {
        console.log('Reading AWS Secret...');
        exec('heroku config:get AWS_SECRET --app hgn' + environment, function (err, secret) {
            if (err) {
                return wcb(err);
            }
            if (!secret) {
                return wcb('AWS Secret missing!');
            }
            process.env.AWS_SECRET = secret.replace('\n','');
            wcb();
        });
    },
    function (wcb) {
        var AWS = require('aws-sdk'),
            s3 = new AWS.S3({
                accessKeyId: process.env.AWS_KEY,
                secretAccessKey: process.env.AWS_SECRET
            }),
            bucket = 'hg' + environment,
            base64,
            defaultAvatarMap = {};
        async.eachLimit(Object.keys(userMap), 9, function (um, ecb) {
            if (userMap[um]) {
                s3.getObject({
                    Bucket: bucket,
                    Key: 'user/' + userMap[um] + '.jpg'
                }, function (err, data) {
                    if (err) {
                        return ecb(err);
                    }
                    if (data && data.Body) {
                        if (data.Body.toString('base64').indexOf(defaultAvatarHeader) > -1) {
                            defaultAvatarMap[um] = userMap[um];
                        }
                    }
                    ecb();
                });
            } else {
                ecb();
            }
        }, function (err) {
            if (err) {
                return wcb(err);
            }
            console.log(JSON.stringify(defaultAvatarMap, null, 4));
            wcb();
        })
    }
], function (err) {
    if (err) {
        console.log(err);
        process.exit(1);
    }
    console.log('Done.');
    process.exit(0);
});