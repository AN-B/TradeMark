var userMap,
    async = require('async'),
    dirPath = process.argv[2],
    noAvatar = [],
    noAvatarIds = [],
    environment = process.argv[3],
    exec = require('child_process').exec,
    copyPhotosList = []; // require('./copyPhotosList.json');

async.waterfall([
    function (wcb) {
        if (!dirPath || !environment) {
            return wcb('missing params');
        }
        wcb();
    },
    function (wcb) {
        userMap = require('./' + environment + '.json');
        if (!userMap || !Object.keys(userMap).length) {
            return wcb('map is empty');
        }
        wcb();
    },
    function (wcb) {
        var fs = require('fs');
        console.log('Checking avatars...');
        fs.readdir(dirPath, function (err, dirs) {
            if (err || !dirs) {
                return wcb(err);
            }
            async.forEach(dirs, function (dir, dcb) {
                if (dir !== '.DS_Store') {
                    fs.readdir(dirPath + '/' + dir, function (err, files) {
                        if (err || !files) {
                            return dcb(err);
                        }
                        files.forEach(function (f) {
                            var empId = f.replace(/\.jpg/gi, '').toUpperCase(),
                                fullPath;
                            if (copyPhotosList[empId]) {
                                fullPath = [dirPath, dir, f].join('/');
                                console.log(fullPath);
                                exec('cp ' + fullPath + ' ~/Desktop/uploadUnitedPhotos/');
                            }
                            if (userMap[empId]) {
                                userMap[empId] = null;
                            }
                        });
                        dcb();
                    });
                } else {
                    dcb();
                }
            }, function (err) {
                if (err) {
                    return wcb(err);
                }
                wcb();
            });
        });
    }
], function (err) {
    if (err) {
        console.log(err);
        return process.exit(1);
    }
    Object.keys(userMap).forEach(function (key) {
        if (userMap[key]) {
            noAvatar.push(key);
            noAvatarIds.push(userMap[key]);
        }
    });
    console.log(noAvatar.sort(), noAvatar.length);
    console.log(noAvatarIds);
});
