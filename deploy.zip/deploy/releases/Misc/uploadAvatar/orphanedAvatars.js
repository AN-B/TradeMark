/*
    node projects/hgapp/deploy/releases/Misc/uploadAvatar/orphanedAvatars.js [path_to_directory_that_contains_avatars] [environment]
    user is required to have access to the environment varialbes for the target environment
*/
var userMap,
    async = require('async'),
    dirPath = process.argv[2],
    orphaned = [],
    environment = process.argv[3];

async.waterfall([
    function (wcb) {
        if (!dirPath || !environment) {
            return wcb('missing params');
        }
        wcb();
    },
    function (wcb) {
        userMap = require('./' + environment + '.json');
        if (!userMap || !Object.keys(userMap).length) {
            return wcb('map is empty');
        }
        wcb();
    },
    function (wcb) {
        var fs = require('fs');
        console.log('Checking avatars...');
        fs.readdir(dirPath, function (err, files) {
            if (err || !files) {
                return wcb(err);
            }
            files.forEach(function (f) {
                var empId = f.replace(/\.jpg/gi, '').toUpperCase();
                if (!userMap[empId]) {
                    orphaned.push(empId);
                }
            });
            console.log(orphaned);
            console.log(orphaned.length, 'avatars orphaned');
            console.log(files.length, 'avatars processed.');
            wcb();
        });
    }
], function (err) {
    if (err) {
        console.log(err);
        return process.exit(1);
    }
});
