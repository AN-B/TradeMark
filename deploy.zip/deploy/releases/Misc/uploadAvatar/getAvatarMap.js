var groupId = db.Group.findOne({GroupName:'United Airlines'}).hgId,
    avatarMap = {};
db.getCollection('Member').find({GroupId:groupId},{UserId:1,EmployeeId:1,_id:0}).forEach(function(m) {
    avatarMap[m.EmployeeId] = m.UserId;
});
print(JSON.stringify(avatarMap, null, 4));
