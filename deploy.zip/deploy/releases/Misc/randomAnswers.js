/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        cryptoHelper = require('../../../hgnode/helpers/cryptoHelper.js'),
        Async = require('async'),
        guid = require('node-uuid'),
        surveyAnswers = {};
    function updateSurvey(survey, callback) {
        var questions = survey.QandA;
        questions.forEach(function (question) {
            question.Status = 'Completed';
            // question.Comment = " blah comment " + Date.now();
            question.AnsweredDate = Date.now();
            question.AnswerValue = Math.floor(Math.random() * 5) + 1;
            question.ScaledAnswerValue = (question.AnswerValue === 0 ) ? 0 : question.AnswerValue * 20;
        });
        survey.Status = 'Completed';
        survey.CompletedDate = Date.now();
        survey.save(function (error) {
            if (error) {
                return callback(error);
            }
            callback();
        });
    }
    function generateRandmoSurveyAnswers(callback) {
        EntityCache.SurveyAnswer.find({
            CurrentRoundId: 'ae90c600-cb6f-11e5-8c1a-c97c399379ff'
        }, function (error, surveys) {
            if (error) {
                return callback(error);
            }
            console.log('surveys', surveys.length);
            Async.each(surveys, updateSurvey, callback);
        });
    }

    function loadFile(callback) {
        var result = [],
            excel = require('excel-stream'),
            fs = require('fs');
        fs.createReadStream('/projects/DemoSurvey/Vickerman.Industries.Benchmark.xlsx')
            .pipe(excel({
                sheet: 'Sheet1',
                escapeChar: '"',
                enclosedChar: '"'
            }))
            .on('data', function (data) {
                result.push(data);
            })
            .on('close', function () {
                result = result.filter(function (item) {
                    return item.hgId !== 0;
                });
                callback(null, result);
            });
    }

    function processSingleRecord(surveyAnswerKey, callback) {
        var surveyAnswerRecord = surveyAnswers[surveyAnswerKey];
        EntityCache.SurveyAnswer.findOne({hgId: surveyAnswerKey}, function (error, data) {
            if (error || !data) {
                return callback();
            }
            data.QandA.forEach(function (question) {
                surveyAnswerRecord.forEach(function (cQuestion) {
                    if (question.QuestionId === cQuestion.QuestionId) {
                        question.AnsweredDate = Date.now();
                        question.Status = "Completed";
                        question.AnswerValue = cQuestion.Answer;
                        question.ScaledAnswerValue = (cQuestion.Answer - 1) / (5 - 1) * 100;
                    }
                });
            });
            data.Status = "Completed";
            data.save(callback);
        });
    }
    function processSurveyResult(callback) {
        loadFile(function (error, data) {
            data.forEach(function (item) {
                if (!surveyAnswers[item.hgId]) {
                    surveyAnswers[item.hgId] = [item];
                } else {
                    surveyAnswers[item.hgId].push(item);
                }
            });
            Async.each(Object.keys(surveyAnswers), processSingleRecord, callback);
        });
    }
    this.Run = function (fcallback) {
        Async.series([
            processSurveyResult
        ], fcallback);
    };
};
module.exports = new HgMigrationFile();