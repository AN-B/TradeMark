/*
    node projects/hgapp/deploy/releases/Misc/updateUnited.js [path_to_directory_that_contains_avatars] [environment]
    user is required to have access to the environment varialbes for the target environment
    this is for updating members and uploading avatars for United only
    set "path_to_directory_that_contains_avatars" to "none" to skip uploading avatars (for weekend demographics files)
    all users that have not logged in will be set as logged in
*/

var userMap = {},
    async = require('async'),
    exec = require('child_process').exec,
    dirPath = process.argv[2],
    skipUploading = dirPath === "none",
    environment = process.argv[3],
    groupName = "United Airlines",
    includeDivisions = [
        {
            Name: 'Human Resources',
            Date: new Date('12/08/2016')
        },
        {
            Name: 'Labor Relations',
            Date: new Date('12/08/2016')
        },
        {
            Name: 'Corporate Communications',
            Date: new Date('12/08/2016')
        }
    ],
    includeUsers = require('./activateUsers.json'),
    excludeUsers = require('./deactivateUsers.json'),
    includeLocations = {
        'CLE': new Date('01/08/2017')
    },
    ConnectionCache,
    EntityCache;

async.waterfall([
    // set up the environemnt vars
    function (wcb) {
        if (!dirPath || !environment) {
            return wcb('missing params');
        }
        process.env.MONGO_HGSECURITY = 'mongodb://localhost:27017/hgsecurity';
        process.env.MONGO_HGTHANKA = 'mongodb://localhost:27017/hgthanka';
        process.env.MONGO_HGPERKA = 'mongodb://localhost:27017/hgperka';
        process.env.MONGO_HGFINANCE = 'mongodb://localhost:27017/hgfinance';
        process.env.MONGO_HGPERFORM = 'mongodb://localhost:27017/hgperform';
        process.env.MONGO_HGREPORTS = 'mongodb://localhost:27017/hgreports';
        process.env.MONGODB_HGLOG = 'mongodb://localhost:27017/hglog';
        process.env.BUILD_ENV = environment;
        process.env.DB_EXCLUDE_SECURE = 'hgsecurity,hgthanka,hgperka,hgfinance,hgperform,hgreports,hglog';
        wcb();
    },
    // get all of the config settings from heroku
    function (wcb) {
        console.log('Reading MongoDB connection strings...');
        async.waterfall([
            // get the connection string for hgcommon
            function (icb) {
                console.log('MONGO_HGCOMMON');
                exec('heroku config:get MONGO_HGCOMMON --app hgn' + environment, function (err, key) {
                    if (err) {
                        return icb(err);
                    }
                    if (!key) {
                        return icb('MONGO_HGCOMMON missing!');
                    }
                    process.env.MONGO_HGCOMMON = key.replace('\n','');
                    icb();
                });
            },
            // get the primary replica name
            function (icb) {
                console.log('REPLICA_PRIMARY');
                exec('heroku config:get REPLICA_PRIMARY --app hgn' + environment, function (err, key) {
                    if (err) {
                        return icb(err);
                    }
                    if (!key) {
                        return icb('REPLICA_PRIMARY missing!');
                    }
                    process.env.REPLICA_PRIMARY = key.replace('\n','');
                    process.env.REPLICA_PRIMARY_B = process.env.REPLICA_PRIMARY;
                    icb();
                });
            },
            // get the secondary replica name
            function (icb) {
                console.log('REPLICA_SECONDARY');
                exec('heroku config:get REPLICA_SECONDARY --app hgn' + environment, function (err, key) {
                    if (err) {
                        return icb(err);
                    }
                    if (!key) {
                        return icb('REPLICA_SECONDARY missing!');
                    }
                    process.env.REPLICA_SECONDARY = key.replace('\n','');
                    process.env.REPLICA_SECONDARY_B = process.env.REPLICA_SECONDARY;
                    icb();
                });
            }
        ], function (err) {
            if (err) {
                return wcb(err);
            }
            wcb();
        });
    },
    // initialize the conncetion and entity caches
    function (wcb) {
        ConnectionCache = require('../../../hgnode/framework/ConnectionCache.js');
        ConnectionCache.init(function () {
            EntityCache = require('../../../hgnode/framework/EntityCache.js');
            wcb();
        });
    },
    // perform all the database updates
    function (wcb) {
        async.waterfall([
            // get the group id
            function (icb) {
                console.log('Reading GroupId...');
                EntityCache.Group.findOne({GroupName: groupName}, {hgId: 1}, function (err, group) {
                    if (err) {
                        return wcb(err);
                    }
                    if (!group || !group.hgId) {
                        return wcb('No group found!');
                    }
                    icb(null, group);
                });
            },
            // setting up the queries
            function (group, icb) {
                console.log('Setting inactive users...');
                var query = {
                        GroupId: group.hgId,
                        MembershipStatus: 'Active',
                        $or: []
                    },
                    queryActivate = {
                        GroupId: group.hgId,
                        MembershipStatus: 'InActive',
                        $or: []
                    },
                    today = new Date(),
                    userDate,
                    tomorrow = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1),
                    divisions = [],
                    locations = [],
                    users = [],
                    exUsers = [],
                    newLaunch = false;
                if (includeUsers && includeUsers.length) {
                    includeUsers.forEach(function (iu) {
                        userDate = new Date(iu.Date);
                        if (today >= userDate) {
                            users = users.concat(iu.Users);
                            if (userDate <= tomorrow) {
                                newLaunch = true;
                            }
                        }
                    });
                    if (users.length) {
                        query.$or.push({EmployeeId: {
                            $nin: users
                        }});
                        queryActivate.$or.push({EmployeeId: {
                            $in: users
                        }});
                    }
                }
                if (excludeUsers && excludeUsers.length) {
                    excludeUsers.forEach(function (eu) {
                        userDate = new Date(eu.Date);
                        if (today >= userDate) {
                            exUsers = exUsers.concat(eu.Users);
                            if (userDate <= tomorrow) {
                                newLaunch = true;
                            }
                        }
                    });
                    if (exUsers.length) {
                        if (users.length) {
                            query.$or.unshift({
                                EmployeeId: {
                                    $in: exUsers
                                }
                            });
                            queryActivate.$or.forEach(function (or) {
                                if (or.EmployeeId) {
                                    or.EmployeeId.$nin = exUsers;
                                }
                            });
                        } else {
                            query.$or.push({
                                EmployeeId: {
                                    $in: exUsers
                                }
                            });
                            queryActivate.$or.push({
                                EmployeeId: {
                                    $nin: exUsers
                                }
                            });
                        }
                    }
                }
                if (includeDivisions && includeDivisions.length) {
                    includeDivisions.forEach(function (div) {
                        if (today >= div.Date) {
                            divisions.push(div.Name);
                            if (div.Date <= tomorrow) {
                                newLaunch = true;
                            }
                        }
                    });
                    if (divisions.length) {
                        query.GroupDepartmentName = {
                            $nin: divisions
                        };
                        queryActivate.$or.push({GroupDepartmentName: {
                            $in: divisions
                        }});
                    }
                }
                if (includeLocations) {
                    Object.keys(includeLocations).forEach(function (key) {
                        if (today >= includeLocations[key]) {
                            locations.push(key);
                            if (includeLocations[key] <= tomorrow) {
                                newLaunch = true;
                            }
                        }
                    });
                    if (locations.length) {
                        query["Location.Name"] = {
                            $nin: locations
                        };
                        queryActivate.$or.push({"Location.Name": {
                            $in: locations
                        }});
                    }
                }
                console.log(JSON.stringify(query, null, 4));
                console.log(JSON.stringify(queryActivate, null, 4));
                async.waterfall([
                    // activate any newly launched users
                    function (qcb) {
                        if (newLaunch) {
                            if (!queryActivate.$or.length) {
                                delete queryActivate.$or;
                            }
                            EntityCache.Member.update(queryActivate, {$set: {MembershipStatus: 'Active'}}, {multi: true}, function (err, count) {
                                if (err) {
                                    return qcb(err);
                                }
                                console.log(count + ' members activated.');
                                qcb();
                            });
                        } else {
                            console.log('No new members to launch.');
                            qcb();
                        }
                    },
                    // activate any offboarded that have been reinstated
                    function (qcb) {
                        queryActivate.MembershipStatus = 'OffBoarded';
                        queryActivate.RolesInGroup = {
                            $ne: 'OffBoarded'
                        };
                        EntityCache.Member.update(queryActivate, {$set: {MembershipStatus: 'Active'}}, {multi: true}, function (err, count) {
                            if (err) {
                                return qcb(err);
                            }
                            console.log(count + ' members reinstated.');
                            qcb();
                        });
                    },
                    // deactivate any specific users
                    function (qcb) {
                        if (!query.$or.length) {
                            delete query.$or;
                        }
                        EntityCache.Member.update(query, {$set: {MembershipStatus: 'InActive'}}, {multi: true}, function (err, count) {
                            if (err) {
                                return qcb(err);
                            }
                            console.log(count + ' members deactivated.');
                            qcb();
                        });
                    },
                    // force the logged in flag for active members that have not logged in
                    function (qcb) {
                        var neverLoggedIn = [];
                        EntityCache.Member.find({
                            GroupId: group.hgId,
                            MembershipStatus: "Active",
                            LastLoginTime: 0
                        }, function (err, members) {
                            if (err) {
                                return qcb(err);
                            }
                            console.log(members.length + ' members not logged in found!');
                            if (members && members.length) {
                                members.forEach(function (mem) {
                                    neverLoggedIn.push(mem.UserId);
                                });
                                EntityCache.Member.update({UserId: {$in: neverLoggedIn}}, {$set: {LastLoginTime: Date.now()}}, {multi: true}, function (err, count) {
                                    if (err) {
                                        return qcb(err);
                                    }
                                    console.log(count + ' members LastLoginTime updated.');
                                    qcb(null, neverLoggedIn);
                                });
                            } else {
                                console.log('All active members logged in already.');
                                qcb(null, neverLoggedIn);
                            }
                        });
                    },
                    // force the first logged in info for active members that have not logged in
                    function (members, qcb) {
                        var now = Date.now();
                        if (members && members.length) {
                            EntityCache.UserInfo.update({
                                hgId: {$in: members}
                            }, {$set: {
                                FirstLogin: [{
                                    Source: 'Script',
                                    LoginTime: now
                                }],
                                "Flags.WelcomeBadgePending": false,
                                LastLoginTime: now
                            }}, {multi: true}, function (err, count) {
                                if (err) {
                                    return qcb(err);
                                }
                                console.log(count + ' members FirstLogin updated.');
                                qcb();
                            });
                        } else {
                            console.log('No member FirstLogin updated.');
                            qcb();
                        }
                    },
                    // display the number of active users
                    function (qcb) {
                        EntityCache.Member.count({
                            GroupId: group.hgId,
                            MembershipStatus: 'Active'
                        }, function (err, count) {
                            if (err) {
                                return qcb(err);
                            }
                            console.log(count + ' active members.');
                            qcb();
                        });
                    }
                ], function (err) {
                    if (err) {
                        return wcb(err);
                    }
                    icb(null, group);
                });
            },
            // generate the employee to user id map
            function (group, icb) {
                if (skipUploading) {
                    console.log('Skipped uploading avatars.');
                    return icb();
                }
                console.log('Generating EmployeeId <> UserId map...');
                EntityCache.Member.find({GroupId: group.hgId}, {
                    UserId: 1,
                    EmployeeId: 1,
                    _id: 0
                }, {lean: true}, function (err, members) {
                    if (err) {
                        return wcb(err);
                    }
                    if (!members || !members.length) {
                        return wcb('No members found!');
                    }
                    console.log(members.length + ' members found.');
                    members.forEach(function (mem) {
                        userMap[mem.EmployeeId] = mem.UserId;
                    });
                    icb();
                });
            }
        ], function (err) {
            if (err) {
                return wcb(err);
            }
            wcb();
        });
    },
    // read the aws key
    function (wcb) {
        if (skipUploading) {
            return wcb();
        }
        console.log('Reading AWS Key...');
        exec('heroku config:get AWS_KEY --app hgn' + environment, function (err, key) {
            if (err) {
                return wcb(err);
            }
            if (!key) {
                return wcb('AWS Key missing!');
            }
            process.env.AWS_KEY = key.replace('\n','');
            wcb();
        });
    },
    // read the aws secret
    function (wcb) {
        if (skipUploading) {
            return wcb();
        }
        console.log('Reading AWS Secret...');
        exec('heroku config:get AWS_SECRET --app hgn' + environment, function (err, secret) {
            if (err) {
                return wcb(err);
            }
            if (!secret) {
                return wcb('AWS Secret missing!');
            }
            process.env.AWS_SECRET = secret.replace('\n','');
            wcb();
        });
    },
    // upload the avatars to S3
    function (wcb) {
        var AWS = require('aws-sdk'),
            fs = require('fs'),
            s3 = new AWS.S3({
                accessKeyId: process.env.AWS_KEY,
                secretAccessKey: process.env.AWS_SECRET
            }),
            bucket = 'hg' + environment,
            count = 0,
            currentTimestamp = Date.now();
        if (skipUploading) {
            return wcb();
        }
        console.log('Uploading avatars...');
        fs.readdir(dirPath, function (err, files) {
            if (err || !files) {
                return wcb(err);
            }
            async.eachLimit(files, 9, function (f, callback) {
                var empId = f.replace(/\.jpg/gi, '').toUpperCase();
                if (userMap[empId]) {
                    fs.readFile(dirPath + '/' + f, function (err, data) {
                        if (err) {
                            return wcb(err);
                        }
                        console.log(f, userMap[empId]);
                        s3.putObject({
                            Bucket: bucket,
                            ContentType: 'image/jpeg',
                            Key: 'user/' + userMap[empId] + '.jpg',
                            Body: data,
                            ACL: 'public-read'
                        }, function (err) {
                            if (err) {
                                return callback(err);
                            }
                            count += 1;
                            // update the avatar version on both the UserInfo and UserInfoWithToken records
                            EntityCache.UserInfo.update({
                                hgId: userMap[empId]
                            }, {
                                $set: {AvatarVersion: currentTimestamp, AvatarUploaded: true}
                            }, function (err) {
                                if (err) {
                                    return callback(err);
                                }
                                EntityCache.UserInfoWithToken.update({
                                    hgId: userMap[empId]
                                }, {
                                    $set: {AvatarVersion: currentTimestamp, AvatarUploaded: true}
                                }, {
                                    multi: true
                                }, function (err) {
                                    if (err) {
                                        return callback(err);
                                    }
                                    callback();
                                });
                            });
                        });
                    });
                } else {
                    console.log(f, 'skipped');
                    callback();
                }
            }, function (err) {
                if (err) {
                    return wcb(err);
                }
                console.log(count + ' avatars uploaded.');
                wcb();
            });
        });
    }
], function (err) {
    if (err) {
        console.log(err);
        return process.exit(1);
    }
    console.log('Done.');
    process.exit(0);
});
