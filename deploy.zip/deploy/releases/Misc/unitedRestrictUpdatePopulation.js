var groupName = "United Airlines",
    groupId = db.Group.findOne({GroupName: groupName}).hgId,
    divisions = [
        'Human Resources',
        'Labor Relations',
        'Corporate Communications'
    ],
    users = [
        'U088882' // Tim Chin
    ];

print(groupId);

// disable active records that fall outside of the selected divisions
db.Member.update({
    GroupId: groupId,
    MembershipStatus: 'Active',
    GroupDepartmentName: {
        $nin: divisions
    },
    EmployeeId: {
        $nin: users
    }
}, {$set: {MembershipStatus: 'InActive'}}, {multi: true});

print(db.Member.find({GroupId: groupId, MembershipStatus: 'Active'}).count());
