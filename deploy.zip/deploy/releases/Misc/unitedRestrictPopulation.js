var groupName = "United Airlines",
    groupId = db.Group.findOne({GroupName: groupName}).hgId,
    divisions = [
        'Human Resources',
        'Labor Relations',
        'Corporate Communications'
    ],
// the cost center or empids do not belong to the divisions being enable, so it will not be included in the query
    costCenter = '3010',
    empIds = [
        'U298555',
        'U299181',
        'U299204',
        'U312458'
    ];

print(groupId);

// disable all records
db.Member.update({GroupId: groupId}, {$set: {MembershipStatus: 'InActive'}}, {multi: true});

// enable divisions except the cost center
db.Member.update({GroupId: groupId, GroupDepartmentName: {$in: divisions}}, {$set: {MembershipStatus: 'Active'}}, {multi: true});

print(db.Member.find({GroupId: groupId, MembershipStatus: 'Active'}).count());
