// Company Data cleanup Script
//--------------
// ATTENTION:
// This Script is MEANT to be USED IN TESTING ENV.
//--------------
/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async'),
        TEST_GROUP_NAME = 'SampleA',
        TEST_GROUP_ID,
        TEST_GROUP_USERIDS;
    //TODO - OTHer Mapping
    //Notification -- >RecipientUserId
    //CreditAccount -->OwnerId (userid and memberId)
    //PerformanceReview --> Card.GroupId
    //Giftcard ---> RequestId (userId, memberId)
    //ProductOrder --> Recipient.UserId and Requester.UserId
    //TangoCard -- pull from GroupIds
    //CareerTrack -- > CreatorMember.GroupId
    //Recognition -- > CreatorMember.GroupId
    function removeData(params, callback) {
    	Async.each(params.Entities, function (entityKey, rCallback) {
    		if (!EntityCache[entityKey]) {
    			console.log('----->Collection not found for entity ' + entityKey);
    			return rCallback();
    		}
    		if (!EntityCache[entityKey].db) {
    			console.log('----->Collection is not an database entity ' + entityKey);	
    			return rCallback();
    		}
    		console.log('----->removing data in ' + entityKey);
    		EntityCache[entityKey].remove(params.Query).exec();
    		rCallback();
      	}, callback);
    }
    function removeGroupRecord(callback) {
    	console.log('==================================');
    	console.log('| Finally Removing  Group Record |');
    	console.log('==================================');
    	EntityCache.Group.remove({hgId: TEST_GROUP_ID}, callback);
    }
    function cleanDataViaGroupId(callback) {
    	console.log('cleanDataViaGroupId');
      	if (!TEST_GROUP_ID) {
      		return callback('TEST_GROUP_ID is null');
      	}
      	removeData({
      		Entities: Object.keys(EntityCache),
      		Query: {
      			GroupId: TEST_GROUP_ID
      		}
      	}, callback);
    }
    function cleanMetricsData(callback) {
    	console.log('cleanMetricsData');
      	if (!TEST_GROUP_ID) {
      		return callback('TEST_GROUP_ID is null');
      	}
      	var entityWithUserIdKeys = [
      		'MetricsCongrat',
			'MetricsComment',
			'MetricsMember',
			'MetricsPerform',
			'MetricsPerformActivity',
			'MetricsRecognition',
			'MetricsManager',
			'MetricsRecognitionCheckInNumber',
			'MetricsRecognitionCategory',
			'MetricsRecognitionSource',
			'MetricsDepartment',
			'MetricsRecognitionShare',
			'MetricsUserActivity',
			'MetricsMonthlyActivity',
			'MetricsTrack',
			'MetricsNews',
			'MetricsCoaching',
			'MetricsFeedBack',
			'MetricsCoachingCategory'
      	];
      	removeData({
      		Entities: entityWithUserIdKeys,
      		Query: {
      			g: TEST_GROUP_ID
      		}
      	}, callback);
    }
    function cleanUserDataViahgId(callback) {
    	console.log('cleanUserDataViahgId');
    	if (!TEST_GROUP_USERIDS || !TEST_GROUP_USERIDS.length) {
      		return callback('No UserIds to remove');
      	}
      	var entityWithUserIdKeys = [
      		'UserInfo',
      		'UserInfoWithToken',
      		'UserSecurity',
			'UserSecurityWithToken'
      	];
      	removeData({
      		Entities: entityWithUserIdKeys,
      		Query: {
      			hgId: {$in: TEST_GROUP_USERIDS}
      		}
      	}, callback);
    }
    function cleanUserDataViaEntityId(callback) {
    	console.log('cleanUserDataViaEntityId');
    	if (!TEST_GROUP_USERIDS || !TEST_GROUP_USERIDS.length) {
      		return callback('No UserIds to remove');
      	}
      	var entityWithUserIdKeys = [
      		'ActionToken'
      	];
      	removeData({
      		Entities: entityWithUserIdKeys,
      		Query: {
      			EntityId: {$in: TEST_GROUP_USERIDS}
      		}
      	}, callback);
    }
    function cleanUserDataViaUserId(callback) {
    	console.log('cleanUserDataViaUserId');
    	if (!TEST_GROUP_USERIDS || !TEST_GROUP_USERIDS.length) {
      		return callback('No UserIds to remove');
      	}
      	var entityWithUserIdKeys = [
      		'MemberRule',
      		'MobileNotificationItem',
      		'ScheduleEvent',
      		'GiftcardOrderRequest',
      		'GiftcardOrderRequestArchive'
      	];
      	removeData({
      		Entities: entityWithUserIdKeys,
      		Query: {
      			UserId: {$in: TEST_GROUP_USERIDS}
      		}
      	}, callback);
    }
    function getGroupUserIds(callback) {
    	EntityCache.UserInfo.find({'Preference.DefaultGroupId': TEST_GROUP_ID}, {hgId: 1}, function (error, data) {
    		if (error) {
    			return callback(error);
    		}
    		TEST_GROUP_USERIDS = data.map(function (item) {
    			return item.hgId;
    		});
    		console.log('Group has '+ TEST_GROUP_USERIDS.length + ' UserInfo record(s).');
    		callback();
    	});
    }
    function getGroup(callback) {
        EntityCache.Group.findOne({GroupName: TEST_GROUP_NAME}, function (error, group) {
        	if (error || !group) {
        		return callback(error || 'GROUP: ' + TEST_GROUP_NAME + ' does not exist');
        	}
        	TEST_GROUP_ID = group.hgId;
        	console.log('Group ID: '+ TEST_GROUP_ID);
        	callback();
        });
    }

    this.Run = function (fcallback) {
    	console.log('===============================')
    	console.log('| Begin  Group Cleanup Script |');
    	console.log('===============================')
        Async.series([
        	getGroup,
			getGroupUserIds,
            cleanUserDataViaUserId,
            cleanUserDataViaEntityId,
            cleanUserDataViahgId,
            cleanMetricsData,
            cleanDataViaGroupId,
            removeGroupRecord
        ], fcallback);
    };
};

module.exports = new HgMigrationFile();
