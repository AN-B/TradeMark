/*jslint node:true es5:true*/
var HgMigrationFile = function () {
    'use strict';
    var EntityCache = require('../../../hgnode/framework/EntityCache.js'),
        Async = require('async');

    function insertFeaturePermissionMapping(callback) {

        var theTimestamp = (new Date()).getTime();

        EntityCache.FeaturePermissionMapping.insertMany([{

				"Feature" : "BrandedEmail", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp,
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp,
				"ModifiedBy" : "Admin" 
				
    
			},
			{
                "Feature" : "ShareLink", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "recognizeTabs.shareLink",
						"CustomLogic" : "secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('shareLink') === -1"
					}, 
					{
					"Type" : "Permission", 
					"Action" : "Add", 
					"PermissionName" : "ShareLink"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp,
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
            },
            {
                "Feature" : "EnablePerform", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "profileTabs.perform",
						"CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Permission", 
						"PermissionName" : "TeamPerform"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
            },
            {
                "Feature" : "DisableValues", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ValuesRecognition"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
            },
            {
                "Feature" : "DisableFeatureByRole", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
            {
                "Feature" : "DisableTracks", 
     
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "CreateTrack"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "trackTabs"
					}
				], 
				"FalseCondition" : [

				],
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
            {
                
				"Feature" : "DisableMotivate", 
    
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.paymentInfo"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.credits"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.credits"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.sendCredits"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.points"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.points"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.pointStore",
						"CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.points",
						"CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.points",
						"CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.pointStore"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.givePointGift"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.sendPoints"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.addPoints"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.showPointsInFeed"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "trackTabs.addPoints"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.addGiftNew"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.addGiftOld"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.grsStorefront"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "SendCreditsInRecognition"
					}
				],
				"FalseCondition" : [

				],	
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
            {
                
				"Feature" : "EnableHideRecognition", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
            {
                "Feature" : "EnableCoaching", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "profileTabs.coaching",
						"CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
					} 
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
            {
                "Feature" : "EnableFeedback", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "profileTabs.feedback",
						"CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": theTimestamp,
                "CreatedBy": "Admin",
                "ModifiedDate": theTimestamp,
                "ModifiedBy": "Admin"
            },
			{ 
   
				"Feature" : "Recognition2", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "recognizeTabs.recognition2",
						"CustomLogic" : "(secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('recognition2') === -1 && secureTabs.recognizeTabs.indexOf('giveRecognition') > -1)",
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "profileTabs.profile",
						"CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.indexOf('profile') === -1"
					},
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "profileTabs.recognition",
						"CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.indexOf('recognition') === -1"
					}
					], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "companyTabs"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "profileTabs.profile"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "trackTabs.addCredits"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AllowSelectAllWhenGivingRecognition"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GiveRecognitionToDepartment"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GiveRecognitionToLocation"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.recognitions"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.recognizeMeLinks"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "profileTabs.recognition"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GiveRecognition"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "CustomizedRecognition"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "EverydayRecognition"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ValuesRecognition"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GiveRecognitionToLocation"
					}
				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "ForSalesDemo", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "motivateTabs.pointStore"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "userTabs.forSalesDemo"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "adminTabs.reports"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "teamTabs.recognizedemo"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "teamTabs.goalsdemo"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : " companyTabs"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "teamTabs.coachingdemo"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "teamTabs.performdemo"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "teamTabs.actiondemo"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "adminTabs.viewAnalytics"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "FeedbackDemo"
					}
				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "teamTabs.actiondemo"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableTeamTab", 
				"TrueCondition" : [
				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "TeamTabManagement"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : " teamTabs"
					}
				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "DisableGroupLogin", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
   
				"Feature" : "EnablePoints", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.pointStore",
						"CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.points",
						"CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.points",
						"CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.addGiftNew"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.sendCredits"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.givePointGift"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.sendPoints"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.addPoints"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "recognizeTabs.showPointsInFeed"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "trackTabs.addPoints"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.addGiftOld"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.grsStorefront"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AddGiftToNewRecognition",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AddGiftToOldRecognition",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ShowPointsInPublicFeed",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GivePointGift",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "PointStore",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManagePointEconomy",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageProductOrder",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageProductItem",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "SendPointsInRecognition",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AddPointsInRecognition",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "MemberPoint",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableLocation", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageLocation"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "SeeLocation"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "RulesEngine", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "rules"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "RecurringCycle", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.recurringCycle"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "YammerIntegration", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.yammerIntegration"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "GRSStorefront", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "motivateTabs.grsStorefront"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "ShowPublicRecognitions", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "ProfanityFilter", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "CustomProfanityFilter", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageProfanity"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "PublicAPI", 
				"TrueCondition" : [
	
				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.manageAPI"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "TutorialUrl", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",				
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "SuggestRewardIdea", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "motivateTabs.suggestRewardIdea",
						"CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "SuggestRewardIdea"
					}
				], 
				"FalseCondition" : [

				],
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableDisplay", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.manageDisplay'"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageDisplay"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "TrackObjectiveWeight", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "trackTabs.trackObjectiveWeight",
						"CustomLogic" : "secureTabs.trackTabs && secureTabs.trackTabs.length"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "AnswerLibrary", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "profileTabs.answerLibrary",
						"CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "SendRealEmails", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "SpendCreditTransfer", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "userTabs.transferSpendCredits"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "TransferSpendCredits",
						"CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) === -1"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableBenchmarkSurvey", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.userBenchmarkSurvey"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.adminSurveys"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "BenchmarkSurvey"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageBenchmarkSurvey"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageAllSurveys"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnablePulseSurvey", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "userTabs.userPulseSurvey"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.adminSurveys"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "PulseSurvey"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManagePulseSurvey"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageAllSurveys"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
     
				"Feature" : "EnableGoals", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "TeamGoals"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "Goal"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageGoalCycle"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "RecurringGoalCycle", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "RecurringGoalCycle"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "GoalLibrary", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageGoalLibrary"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "OpenClosedGoal", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "OpenClosedGoal"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "UploadGoalCycleParticipants", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "UploadGoalCycleParticipants"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "GoalWeighting", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GoalWeighting"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "SkipGoalApproval", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "SkipGoalApproval"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "PerformGoal", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "PerformGoal"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "KeyResultUpdateToFeed", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "NotifyApproverGoalUpdates", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
     
				"Feature" : "NumericPercentageTarget", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "NumericPercentageTarget"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "SelectRecapTime", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "SelectRecapTime"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "AdhocGoal", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AdhocGoal"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "MobileAccess", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "MobileEmailSSOOverride", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "MobileAllowCompanyGoalMod", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "MobileAllowCompanyGoalMod"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "MobileAllowTeamGoalMod", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "MobileAllowTeamGoalMod"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableLanguages", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "EnableLanguages",
						"CustomLogic" : "(member.RolesInGroup.indexOf('HGAdmin') > -1 || member.RolesInGroup.indexOf('Admin') > -1)"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableAddPoints", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "recognizeTabs.addPoints",
						"CustomLogic" : "secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('addPoints') === -1"
					}
				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AddPointsInRecognition"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "PublicRecFreeformComments", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnablePolling", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "profileTabs.poll"
					}, 
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "profileTabs.rpoll"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableTutorials", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "Tutorials"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "MileagePlus", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "motivateTabs.mileagePlus"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "HidePasswordLogins", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "userTabs.hidePasswordField"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "ContinuousFeedback", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ContinuousFeedback"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageFeedback"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "ManagerCheckin", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManagerCheckin"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "FeedbackCheckin", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "EnableConversationGuide"
					}
				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageFeedback"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "TeamCheckin"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "FeedbackCheckin"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "RequestFeedback", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageFeedback"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "RequestFeedback"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "GiveFeedback", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "GiveFeedback"
					}
				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageFeedback"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "MaskAnonymousReviewUser", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableNineBox", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "userTabs.enableNineBox"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "TalentInsights", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "TeamTalent"
					}
				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "TalentInsight"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ManageTalentInsight"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "AlertMissingPoint", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
		
				"Feature" : "UserNotificationPreference", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "UserNotificationPreference"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "DemoStaticData", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "teamTabs.demoStaticData"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "DemoSettings", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "adminTabs.demoSettings"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "RestrictChatWidget", 
   
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AllowChatWidget",
						"CustomLogic" : "(!role || !role.AddedPermissions || role.AddedPermissions.indexOf(MemberEnums.MemberPermission.AllowChatWidget.Name) === -1) && (!member.AddedPermissions || member.AddedPermissions.indexOf(MemberEnums.MemberPermission.AllowChatWidget.Name) === -1))"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableConversationGuide", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "EnableConversationGuide"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "ReqFeedbackAboutOthers", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "ReqFeedbackAboutOthers"
					}
				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
			
				"Feature" : "RestrictAvatarSetting", 
				"FalseCondition" : [

				], 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AllowAvatarUpload"
					}
				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "EnableOptOutPublicRec", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "EnableOptOutPublicRec"
					}
				], 	
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "MultiManager", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "userTabs.multiManager"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "DontPersistCookies", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "DontPersistCookies"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "RelevancyFilter", 
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Add", 
						"PermissionName" : "userTabs.relevancyFilter"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "ManagerTeamTabLearning", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "ManagerTeamLearning"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : " ManagersSeePrivateBadge", 
				"TrueCondition" : [

				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "PreventProfileInfoEditing", 
    
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AllowProfileInfoEditing"
					}
				],
				"FalseCondition" : [

				],	
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "HideAdminDepartment", 
    
				"TrueCondition" : [
					{
						"Type" : "Tab", 
						"Action" : "Remove", 
						"PermissionName" : "adminTabs.manageDepartment"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "TurnOffTeam", 
    
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AdhocTeam"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "TeamManagement"
					}, 
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "TeamAdmin"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},	
			{ 
    
				"Feature" : "HideSeeAllNotification", 
     
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AllImportantNotifications"
					}
				], 
				"Falsecondition" : [

				],
				"CustomLogic" : "",
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "HideHelpLink", 
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "HideHelpLink"
					}
				], 
				"Falsecondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
		
				"Feature" : "AllowSurveyKiosk", 
    
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Add", 
						"PermissionName" : "AllowSurveyKiosk"
					}
				], 
				"Falsecondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "HideRecognitionByLocation", 
     
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GiveRecognitionToLocation"
					}
				], 
				"FalseCondition" : [

				],
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
     
				"Feature" : "HideRecognitionByDepartment", 
    
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "GiveRecognitionToDepartment"
					}
				], 
				"FalseCondition" : [

				], 
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
			},
			{ 
    
				"Feature" : "HideSelectAllWhenGivingRecognition", 
    
				"TrueCondition" : [
					{
						"Type" : "Permission", 
						"Action" : "Remove", 
						"PermissionName" : "AllowSelectAllWhenGivingRecognition"
					}
				],
				"FalseCondition" : [

				], 	
				"CustomLogic" : "", 
				"GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
				"CreatedDate" : theTimestamp, 
				"CreatedBy" : "Admin", 
				"ModifiedDate"  : theTimestamp, 
				"ModifiedBy" : "Admin" 
    
}], callback);

    }

    this.Run = function (fcallback) {
        Async.series([
            insertFeaturePermissionMapping
        ], fcallback);
    };
};
module.exports = new HgMigrationFile();