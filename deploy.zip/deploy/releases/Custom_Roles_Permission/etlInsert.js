load("../db-scripts/commonDB.js");
setEnv("local");

switchDB("hgcommon");




        db.FeaturePermissionMapping.insert({

            "Feature" : "BrandedEmail",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "ShareLink",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "recognizeTabs.shareLink",
                    "CustomLogic" : "secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('shareLink') === -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "ShareLink"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "EnablePerform",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "profileTabs.perform",
                    "CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Permission",
                    "PermissionName" : "TeamPerform"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });



        db.FeaturePermissionMapping.insert({

            "Feature" : "DisableValues",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ValuesRecognition"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "DisableFeatureByRole",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "DisableTracks",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "CreateTrack"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "trackTabs"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });



        db.FeaturePermissionMapping.insert({

            "Feature" : "DisableMotivate",

            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.paymentInfo"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.credits"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.credits"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.sendCredits"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.points"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.points"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.pointStore",
                    "CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.points",
                    "CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.points",
                    "CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.pointStore"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.givePointGift"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.sendPoints"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.addPoints"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.showPointsInFeed"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "trackTabs.addPoints"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.addGiftNew"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.addGiftOld"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.grsStorefront"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "SendCreditsInRecognition"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableHideRecognition",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableCoaching",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "profileTabs.coaching",
                    "CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableFeedback",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "profileTabs.feedback",
                    "CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "Recognition2",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "recognizeTabs.recognition2",
                    "CustomLogic" : "(secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('recognition2') === -1 && secureTabs.recognizeTabs.indexOf('giveRecognition') > -1)",
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "profileTabs.profile",
                    "CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.indexOf('profile') === -1"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "profileTabs.recognition",
                    "CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.indexOf('recognition') === -1"
                }
            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "companyTabs"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "profileTabs.profile"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "trackTabs.addCredits"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AllowSelectAllWhenGivingRecognition"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GiveRecognitionToDepartment"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GiveRecognitionToLocation"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.recognitions"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.recognizeMeLinks"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "profileTabs.recognition"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GiveRecognition"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "CustomizedRecognition"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "EverydayRecognition"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ValuesRecognition"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GiveRecognitionToLocation"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "ForSalesDemo",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "motivateTabs.pointStore"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "userTabs.forSalesDemo"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "adminTabs.reports"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "teamTabs.recognizedemo"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "teamTabs.goalsdemo"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : " companyTabs"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "teamTabs.coachingdemo"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "teamTabs.performdemo"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "teamTabs.actiondemo"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "adminTabs.viewAnalytics"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "FeedbackDemo"
                }
            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "teamTabs.actiondemo"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableTeamTab",
            "TrueCondition" : [
            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "TeamTabManagement"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : " teamTabs"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });




        db.FeaturePermissionMapping.insert({

            "Feature" : "DisableGroupLogin",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnablePoints",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.pointStore",
                    "CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.points",
                    "CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.points",
                    "CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.addGiftNew"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.sendCredits"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.givePointGift"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.sendPoints"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.addPoints"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "recognizeTabs.showPointsInFeed"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "trackTabs.addPoints"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.addGiftOld"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.grsStorefront"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AddGiftToNewRecognition",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AddGiftToOldRecognition",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ShowPointsInPublicFeed",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GivePointGift",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "PointStore",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManagePointEconomy",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageProductOrder",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageProductItem",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "SendPointsInRecognition",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AddPointsInRecognition",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "MemberPoint",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) > -1"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableLocation",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageLocation"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "SeeLocation"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "RulesEngine",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "rules"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "RecurringCycle",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.recurringCycle"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "YammerIntegration",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.yammerIntegration"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "GRSStorefront",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "motivateTabs.grsStorefront"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "ShowPublicRecognitions",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "ProfanityFilter",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "CustomProfanityFilter",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageProfanity"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "PublicAPI",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.manageAPI"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "TutorialUrl",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "SuggestRewardIdea",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "motivateTabs.suggestRewardIdea",
                    "CustomLogic" : "secureTabs.motivateTabs && secureTabs.motivateTabs.length"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "SuggestRewardIdea"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableDisplay",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.manageDisplay'"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageDisplay"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "TrackObjectiveWeight",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "trackTabs.trackObjectiveWeight",
                    "CustomLogic" : "secureTabs.trackTabs && secureTabs.trackTabs.length"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "AnswerLibrary",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "profileTabs.answerLibrary",
                    "CustomLogic" : "secureTabs.profileTabs && secureTabs.profileTabs.length"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "SendRealEmails",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "SpendCreditTransfer",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "userTabs.transferSpendCredits"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "TransferSpendCredits",
                    "CustomLogic" : "member.RolesInGroup.indexOf(EntityEnums.MembersRoleInGroup.Consultant) === -1"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableBenchmarkSurvey",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.userBenchmarkSurvey"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.adminSurveys"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "BenchmarkSurvey"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageBenchmarkSurvey"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageAllSurveys"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "EnablePulseSurvey",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "userTabs.userPulseSurvey"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.adminSurveys"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "PulseSurvey"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManagePulseSurvey"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageAllSurveys"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableGoals",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "TeamGoals"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "Goal"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageGoalCycle"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "RecurringGoalCycle",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "RecurringGoalCycle"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "GoalLibrary",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageGoalLibrary"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "OpenClosedGoal",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "OpenClosedGoal"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "UploadGoalCycleParticipants",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "UploadGoalCycleParticipants"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "GoalWeighting",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GoalWeighting"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "SkipGoalApproval",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "SkipGoalApproval"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "PerformGoal",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "PerformGoal"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "KeyResultUpdateToFeed",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "NotifyApproverGoalUpdates",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "NumericPercentageTarget",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "NumericPercentageTarget"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "SelectRecapTime",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "SelectRecapTime"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "AdhocGoal",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AdhocGoal"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "MobileAccess",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "MobileEmailSSOOverride",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "MobileAllowCompanyGoalMod",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "MobileAllowCompanyGoalMod"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "MobileAllowTeamGoalMod",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "MobileAllowTeamGoalMod"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableLanguages",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "EnableLanguages",
                    "CustomLogic" : "(member.RolesInGroup.indexOf('HGAdmin') > -1 || member.RolesInGroup.indexOf('Admin') > -1)"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableAddPoints",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "recognizeTabs.addPoints",
                    "CustomLogic" : "secureTabs.recognizeTabs && secureTabs.recognizeTabs.indexOf('addPoints') === -1"
                }
            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AddPointsInRecognition"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "PublicRecFreeformComments",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnablePolling",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "profileTabs.poll"
                },
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "profileTabs.rpoll"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableTutorials",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "Tutorials"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "MileagePlus",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "motivateTabs.mileagePlus"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "HidePasswordLogins",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "userTabs.hidePasswordField"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "ContinuousFeedback",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ContinuousFeedback"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageFeedback"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "ManagerCheckin",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManagerCheckin"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "FeedbackCheckin",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "EnableConversationGuide"
                }
            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageFeedback"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "TeamCheckin"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "FeedbackCheckin"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "RequestFeedback",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageFeedback"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "RequestFeedback"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "GiveFeedback",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "GiveFeedback"
                }
            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageFeedback"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "MaskAnonymousReviewUser",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableNineBox",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "userTabs.enableNineBox"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "TalentInsights",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "TeamTalent"
                }
            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "TalentInsight"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ManageTalentInsight"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "AlertMissingPoint",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "UserNotificationPreference",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "UserNotificationPreference"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "DemoStaticData",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "teamTabs.demoStaticData"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "DemoSettings",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "adminTabs.demoSettings"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "RestrictChatWidget",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AllowChatWidget",
                    "CustomLogic" : "(!role || !role.AddedPermissions || role.AddedPermissions.indexOf(MemberEnums.MemberPermission.AllowChatWidget.Name) === -1) && (!member.AddedPermissions || member.AddedPermissions.indexOf(MemberEnums.MemberPermission.AllowChatWidget.Name) === -1))"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableConversationGuide",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "EnableConversationGuide"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "ReqFeedbackAboutOthers",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "ReqFeedbackAboutOthers"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "RestrictAvatarSetting",
            "FalseCondition" : [

            ],
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AllowAvatarUpload"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "EnableOptOutPublicRec",
            "TrueCondition" : [

            ],
            "FalseCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "EnableOptOutPublicRec"
                }
            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "MultiManager",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "userTabs.multiManager"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "DontPersistCookies",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "DontPersistCookies"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "RelevancyFilter",
            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Add",
                    "PermissionName" : "userTabs.relevancyFilter"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "ManagerTeamTabLearning",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "ManagerTeamLearning"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : " ManagersSeePrivateBadge",
            "TrueCondition" : [

            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "PreventProfileInfoEditing",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AllowProfileInfoEditing"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "HideAdminDepartment",

            "TrueCondition" : [
                {
                    "Type" : "Tab",
                    "Action" : "Remove",
                    "PermissionName" : "adminTabs.manageDepartment"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "TurnOffTeam",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AdhocTeam"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "TeamManagement"
                },
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "TeamAdmin"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "HideSeeAllNotification",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AllImportantNotifications"
                }
            ],
            "Falsecondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "HideHelpLink",
            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "HideHelpLink"
                }
            ],
            "Falsecondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "AllowSurveyKiosk",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Add",
                    "PermissionName" : "AllowSurveyKiosk"
                }
            ],
            "Falsecondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "HideRecognitionByLocation",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GiveRecognitionToLocation"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


        db.FeaturePermissionMapping.insert({

            "Feature" : "HideRecognitionByDepartment",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "GiveRecognitionToDepartment"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });

        db.FeaturePermissionMapping.insert({

            "Feature" : "HideSelectAllWhenGivingRecognition",

            "TrueCondition" : [
                {
                    "Type" : "Permission",
                    "Action" : "Remove",
                    "PermissionName" : "AllowSelectAllWhenGivingRecognition"
                }
            ],
            "FalseCondition" : [

            ],
            "CustomLogic" : "",
            "CreatedDate" :ISODate(),
            "CreatedBy" : "Admin",
            "ModifiedDate"  :ISODate(),
            "ModifiedBy" : "Admin"

        });


