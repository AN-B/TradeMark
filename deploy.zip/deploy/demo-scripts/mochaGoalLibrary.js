/*jslint node:true es5:true*/
/*global describe, it*/
'use strict';

var HGSession = require('./HGSession'),
    session = new HGSession(),
    guid = require('node-uuid'),
    assert = require("assert"),
    cycleServiceURL = 'http://localhost:8095/svc/GoalCycle/',
    goalServiceURL = 'http://localhost:8095/svc/Goal/',
    len;

describe('CuManagesGoalLibraryAndAssignGoals', function () {
    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });

    describe('CreateANewGoalTemplate', function () {
        var templateGoalId,
            cycleId,
            participants;
        it('should create a new goal template', function (done) {
            var payload = {
                Name : 'Goal template ' + new Date().toString(),
                Description: "This is for mocha testing blah blah",
                KeyResults : [
                    {
                        Name : 'KR 1: Finish up ORK backend',
                        Measure : 'Percentage',
                        Target : 100
                    },
                    {
                        Name : 'KR 2: help with Perform',
                        Measure : 'Percentage',
                        Target : 100
                    },
                    {
                        Name : 'KR 3: Fix 80 defects',
                        Measure : 'Numeric',
                        Target : 80
                    },
                    {
                        Name : 'KR 4: refactor 5 services during shark week',
                        Measure : 'Numeric',
                        Target : 5
                    }
                ]
            };
            session.request.post(goalServiceURL + 'SaveTemplate')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    assert.equal(response.statusCode, 200);
                    templateGoalId = response.body.hgId;
                    console.log(templateGoalId);
                    assert.equal(response.body.Name, payload.Name);
                    done();
                });
        });

        it('should return library supporting search term', function (done) {
            session.request.get(goalServiceURL + 'GetGoalLibrary?search=template&skip=0&status=&take=10')
                .type('json')
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    var templates = response.body;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log('there are ' + templates.length + ' templates');
                    done();
                });
        });

        it('should return latest template', function (done) {
            session.request.get(goalServiceURL + 'GetTemplateById?tId=' + templateGoalId)
                .type('json')
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    assert.equal(response.body.hgId, templateGoalId);
                    done();
                });
        });

        it('should return cycles that have been assigned with this template', function (done) {
            var payload = {
                TemplateId: templateGoalId,
                SearchTerm: "wei"
            };
            session.request.post(cycleServiceURL + 'GetAssignedCyclesByTemplateId')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    participants = response.body;
                    // console.log(data);
                    console.log("this template goal has been assign to ", response.body.length, "cycles");
                    done();
                });
        });


        it('should return active cycles are eligible to be assigned with the template', function (done) {
            var payload = {
                TemplateId: templateGoalId,
                SearchTerm: "weighting 2"
            };
            session.request.post(cycleServiceURL + 'GetCycleCandiatesByTemplateId')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    var cycles = response.body;
                    cycleId = cycles[0].Id;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(cycleId);
                    console.log(cycles.length + ' cycles could be assigned wiht this goal template');
                    done();
                });
        });

        it('should return individual participants of the cycle with flag whether he has been assigned with the given template', function (done) {
            session.request.get(cycleServiceURL + 'GetMemberParticipantsByCycleTemplateId?tId=' + templateGoalId + "&cId=" + cycleId + "&search=" + "ar")
                .type('json')
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    participants = response.body.Participants;
                    // console.log(data);
                    console.log("Total: ", response.body.Total, "this page has", response.body.Participants.length);
                    done();
                });
        });

        it('should assign template to a member participant in the cycle', function (done) {
            var payload = {
                TemplateId: templateGoalId,
                CycleId: cycleId,
                MemberIds: [participants.find(function (participant) {
                    return !participant.IsAssigned;
                }).MemberId]
            };
            console.log(payload);
            session.request.post(goalServiceURL + 'AssignTemplateGoal')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });

        it('should unassign template from the above participant in the cycle', function (done) {
            var payload = {
                TemplateId: templateGoalId,
                CycleId: cycleId,
                MemberIds: [participants.find(function (participant) {
                    return !participant.IsAssigned;
                }).MemberId]
            };
            console.log(payload);
            session.request.post(goalServiceURL + 'UnassignTemplateGoal')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });

        it('should pull template from the above cycle', function (done) {
            var payload = {
                TemplateId: templateGoalId,
                CycleId: cycleId
            };
            console.log(payload);
            session.request.post(goalServiceURL + 'RemoveTemplateFromCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    if (error) {
                        console.log(error);
                    }
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });

});

//mocha --opts deploy/demo-scripts/mocha.opts --grep CuManagesGoalLibraryAndAssignGoals
