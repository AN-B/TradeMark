/*jslint node:true es5:true*/
/*global describe, it*/
'use strict';

var HGSession = require('./HGSession'),
    session = new HGSession(),
    guid = require('node-uuid'),
    assert = require("assert"),
    cycleServiceURL = 'http://localhost:8095/svc/FeedbackCycle/',
    sessionServiceURL = 'http://localhost:8095/svc/FeedbackSession/',
    len;

describe('CuCreatesGuidedCheckInCycleAndPublishes', function () {
    var cards,
        cardId,
        initiatorId,
        cycleId;

    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });


    describe('CreateDraftGuidedCheckInCycle', function () {
        it('should create a new guided check in cycle, goal cycle', function (done) {
            var payload = {
                Title: new Date().toString() + 'HighGround Guided check in cycle',
                Description: new Date().toString() + ' HighGround Guided check in  to test',
                Notes: "Test note",
                Type: 'SelfEvaluation',
                SinglePageQuestion: false,
                Sections: [{
                    Title: "Goals Restro",
                    Type: "CycleGoal",
                    GoalCycleId: "fdb5baa0-03dd-11e6-9af7-176af83270da",
                    Questions: [{
                        Question: 'First question is....',
                        QuestionHelp: 'First question help is....',
                        Required: true,
                        SortOrder: 0,
                        Type: "ShortAnswer"
                    }, {
                        Question: 'Second question is....',
                        QuestionHelp: 'Second question help is....',
                        Required: true,
                        SortOrder: 1,
                        Type: "ShortAnswer"
                    }]
                }, {
                    Title: "Honors",
                    Type: "Recognitions",
                    StartDate: 1451628000000,
                    EndDate: 1462078800000,
                    Questions: [{
                        Question: 'First so many Recognitions!',
                        QuestionHelp: 'First so many Recognitions!',
                        Required: true,
                        SortOrder: 0,
                        Type: "ShortAnswer"
                    }, {
                        Question: 'Second so many Recognitions!',
                        QuestionHelp: 'Second so many Recognitions!',
                        Required: true,
                        SortOrder: 1,
                        Type: "ShortAnswer"
                    }]
                }, {
                    Title: "All Personal Goal discussion",
                    Type: "AdhocGoals",
                    StartDate: 1451628000000,
                    EndDate: 1462078800000,
                    Questions: [{
                        Question: 'Look at my Personal Goals!',
                        QuestionHelp: 'Look at my Personal Goals!',
                        Required: true,
                        SortOrder: 0,
                        Type: "ShortAnswer"
                    }]
                }, {
                    Title: "Personal Goal discussion one by one",
                    Type: "AdhocGoal",
                    StartDate: 1464238800000,
                    EndDate: 1464411600000,
                    Questions: [{
                        Question: 'One by one!',
                        QuestionHelp: 'One by one!',
                        Required: true,
                        SortOrder: 0,
                        Type: "ShortAnswer"
                    }]
                }],
                InitiatorSetting: {
                    DeliveryDate: Date.now(),
                    DueDate: Date.now() + 3600 * 1000 * 24 * 3
                }
            };
            session.request.post(cycleServiceURL + 'CreateCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    cycleId = response.body.hgId;
                    console.log("CycleId: ", cycleId);
                    done();
                });
        });
    });

    describe('PublishAboveDraftGuidedCheckInCycle', function () {
        it('should publish the above cycle', function (done) {
            var payload = {
                CycleId: cycleId,
                Criteria: [{
                    DepartmentId: "50cdf500-4296-11e4-baf4-bfc5d30f17c6",
                    Level: "All",
                    Location: "All"
                }]
            };
            session.request.post(cycleServiceURL + 'PublishCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body);
                    done();
                });
        });
    });
});

//mocha --opts deploy/demo-scripts/mocha.opts --grep CuCreatesGuidedCheckInCycleAndPublishes
//mocha --opts deploy/demo-scripts/mocha.opts --grep GaryOpensSelfEvaluationAnswerAndSubmit
