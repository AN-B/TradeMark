/*jslint node:true es5:true*/
/*global describe, it*/
'use strict';

var HGSession = require('./HGSession'),
    session = new HGSession(),
    guid = require('node-uuid'),
    assert = require("assert");

var cycleId;

//Demo: 10) Create goal cycle 2) Add Team "Product Engineering" 3) Publish cycle. Vip should receive email to create company goal
describe('CuCreatesAndPublishesTimeBasedGoalCycleForCheckInTesting', function () {
    var serviceURL = 'http://localhost:8095/svc/GoalCycle/';

    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });

    describe('CuCreateTimeBasedGoalCycleForCheckInTesting', function () {
        it('should create a new goal cycle, with staggered delivery of company, team and member', function (done) {
            var payload = {
                Title: 'First Quarter HighGround Company OKR',
                Description: 'Q4 OKR',
                Notes : 'Please get this done asap',
                CloseDate : new Date().getTime() + 3600 * 1000 * 24 * 7,//a week from now
                ClosePeriod : 5,
                CheckInFrequency : 'Weekly',
                DeliveryMethods: [
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Company',
                        DeliveryDate : new Date().getTime() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : new Date().getTime() + 3600 * 1000 * 24 * 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Daily',
                        ParticipantType : 'Team',
                        DeliveryDate : new Date().getTime() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : new Date().getTime() + 3600 * 1000 * 24 * 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Member',
                        DeliveryDate : new Date().getTime() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : new Date().getTime() + 3600 * 1000 * 24 * 3,
                    }
                ],
                CompanyGoalOwner : {
                    MemberId : '232d61c0-9cd5-11e2-a3a4-25024474fe63',//KM's local
                    UserId : '3cf59990-9cd2-11e2-a3a4-25024474fe63',//KM's local
                    FullName : 'Vip Sandhir'
                }
            };
            session.request.post(serviceURL + 'CreateGoalCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    cycleId = response.body.hgId;
                    done();
                });
        });
    });
    describe('CuPublishesAboveCycle', function () {
        it('should publish the above cycle', function (done) {
            console.log(cycleId);
            var payload = {
                CycleId: cycleId
            };
            session.request.post(serviceURL + 'PublishCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });

        });
    });
});
cycleId = '95181e40-08a5-11e5-95bb-0987ea6f6646';

describe('CuCreatesTeamGoalsForCycleToTestCheckIn', function () {
    var goalId,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });

    it('should create a new Team goal, attached to a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Name : 'Develop Goal of Q4',
            Participant : {
                ParticipantType : 'Team',
                ParticipantId : '50cdf500-4296-11e4-baf4-bfc5d30f17c6'
            },
            KeyResults : [
                {
                    Name : 'KR 1: Roll out 6 big features',
                    Measure : 'Numeric',
                    Target : 6
                },
                {
                    Name : 'KR 2: clear 80 backlog items',
                    Measure : 'Numeric',
                    Target : 80
                },
                {
                    Name : 'KR 3: Contintuous deployment',
                    Measure : 'Numeric',
                    Target : 30
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
    it('Should set cu team goals for a given cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Team',
                ParticipantId : '50cdf500-4296-11e4-baf4-bfc5d30f17c6'
            },
        };
        session.request.post(serviceURL + 'SetMyGoalsForCycle')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });

});
