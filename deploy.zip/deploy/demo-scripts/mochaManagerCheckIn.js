/*jslint node:true es5:true*/
/*global describe, it*/
'use strict';

var HGSession = require('./HGSession'),
    session = new HGSession(),
    guid = require('node-uuid'),
    assert = require("assert"),
    cycleServiceURL = 'http://localhost:8095/svc/FeedbackCycle/',
    sessionServiceURL = 'http://localhost:8095/svc/FeedbackSession/',
    len;

describe('CuDoesCheckInWitHisDirectReports', function () {
    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });

    describe('GetMyManagerCheckInTypes', function () {
        it('should return check in types available to me', function (done) {
            session.request.get(cycleServiceURL + 'GetMyManagerCheckInTypes')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log('You have ' + len + ' prompt');
                    console.log(response.body);
                    // response.body.forEach(function (card) {
                    //     console.log(card.Title);
                    // });
                    done();
                });
        });
    });

    describe('GetMyTeamForCheckIn', function () {
        it('should return paginated list of my team members with their respective last check in date', function (done) {
            session.request.get(sessionServiceURL + 'GetMyTeamForCheckIn')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log('You have ' + len + ' prompt');
                    console.log(response.body);
                    // response.body.forEach(function (card) {
                    //     console.log(card.Title);
                    // });
                    done();
                });
        });
    });

    describe('ManagerCuDoesCheckInWithGary', function () {
        it('should incurr a check in with gary', function (done) {
            var payload = {
                CycleId: "122501f0-2e52-11e6-8ac3-878b84e5c365",
                CheckedMemberId: "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                Note: 'Hey just want to check in. How are things going'
            };
            session.request.post(sessionServiceURL + 'ManagerCheckIn')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    console.log(response.body);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });

    describe('GetCheckInHistoryFromGary', function () {
        it('should return check in history given to Gary', function (done) {
            session.request.get(sessionServiceURL + 'GetCheckInHistory?mId=3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body);
                    // response.body.forEach(function (card) {
                    //     console.log(card.Title);
                    // });
                    done();
                });
        });
    });

    describe('GetOneCheckInDetailGivenToGary', function () {
        it('should return one check in detail', function (done) {
            session.request.get(sessionServiceURL + 'GetCheckInSessionDetail?sId=69cbf8f0-2e52-11e6-8a95-456c3b60860c')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body);
                    done();
                });
        });
    });

    describe('CuCommentOnGarySession', function () {
        it('should leave a comment on a check in session', function (done) {
            var payload = {
                SessionId: '69cbf8f0-2e52-11e6-8a95-456c3b60860c',
                Note: 'How are things going?'
            };
            session.request.post(sessionServiceURL + 'CommentManagerCheckInSession')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    console.log(response.body);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });

    describe('GetCommentsMadeToACheckInSession', function () {
        it('should return comments associated with a check in session', function (done) {
            session.request.get(sessionServiceURL + 'GetCommentsBySessionId?sId=69cbf8f0-2e52-11e6-8a95-456c3b60860c')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body);
                    done();
                });
        });
    });
});

//mocha --opts deploy/demo-scripts/mocha.opts --grep CuDoesCheckInWitHisDirectReports
//mocha --opts deploy/demo-scripts/mocha.opts --grep GetMyManagerCheckInTypes
//mocha --opts deploy/demo-scripts/mocha.opts --grep GetMyTeamForCheckIn
//mocha --opts deploy/demo-scripts/mocha.opts --grep ManagerCuDoesCheckInWithGary
//mocha --opts deploy/demo-scripts/mocha.opts --grep GetCheckInHistoryFromGary
//mocha --opts deploy/demo-scripts/mocha.opts --grep GetOneCheckInDetailGivenToGary
//mocha --opts deploy/demo-scripts/mocha.opts --grep CuCommentOnGarySession
//mocha --opts deploy/demo-scripts/mocha.opts --grep GetCommentsMadeToACheckInSession
