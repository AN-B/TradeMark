/*jslint node:true es5:true*/
/*global describe, it*/
'use strict';

var HGSession = require('./HGSession'),
    session = new HGSession(),
    guid = require('node-uuid'),
    assert = require("assert"),
    esbApiUrl = 'http://localhost:8086/' + '1.0/EventBus',
    // esbApiUrl = 'https://apitron.highground.com/1.0/EventBus',
    // esbApiUrl = 'https://apipoc.highground.com/1.0/EventBus',
    len;


describe('mochaUseESBAPIToCreateEvents', function () {
    describe('Create new events in EventBus', function () {
        it.skip('should create a new event with a Service Award event type', function (done) {
            var payload = {
                    "EventType": "Service Award",
                    "Payload": {
                        "ActivityType" : "",
                        "CallResult" : "",
                        "CallDuration" : "",
                        "TaskType" : "",
                        "TaskSubject" : "",
                        "OpportunityName" : "",
                        "UserEmail" : "katrina@ahighground.com",
                        "CompanyName" : "Highground",
                        "Amount" : "1"
                    }
                };
            session.request.post(esbApiUrl)
                .set('clientkey', 'ab090607-2b7f-40a0-85a5-054aeadf23b5')
                .send(payload)
                .end(function (response) {
                    assert.equal(response.statusCode, 200);
                    assert.equal(response.body.EventType, payload.EventType);
                    done();
                });
        });

        it.skip('should create a new event with a BDContractSold event type', function (done) {
            var payload = {
                    EventType: 'ContractSold',
                    Payload : {
                        Amount : 300,
                        CompanyName : 'Mercury Industries',
                        UserEmail : 'marcie@highground.com',
                        OpportunityName : 'FoxCon'
                    },
                    EntityType: "SalesforceOpportunity",
                    EntityId: "SalesforceOpportunity001"
                };
            session.request.post(esbApiUrl)
                .set('clientkey', 'ab090607-2b7f-40a0-85a5-054aeadf23b5')
                .send(payload)
                .end(function (response) {
                    console.log(response);
                    assert.equal(response.statusCode, 200);
                    assert.equal(response.body.EventType, payload.EventType);
                    done();
                });
        });
        it('should create a new event with a CsNewClientLaunched event type', function (done) {
            var payload = {
                    EventType: 'CsNewClientLaunched',
                    Payload : {
                        Amount : 1,
                        CompanyName : 'HighGround',
                        UserEmail : 'gary@highground.com',
                        OpportunityName : 'Teknion'
                    },
                    EntityType: "SalesforceAccount",
                    EntityId: "SalesforceAccount002"
                };
            session.request.post(esbApiUrl)
                .set('clientkey', 'ab090607-2b7f-40a0-85a5-054aeadf23b5')
                .send(payload)
                .end(function (response) {
                    console.log(response);
                    assert.equal(response.statusCode, 200);
                    assert.equal(response.body.EventType, payload.EventType);
                    done();
                });
        });
    });

});

//mocha --opts deploy/demo-scripts/mocha.opts --grep mochaUseESBAPIToCreateEvents
