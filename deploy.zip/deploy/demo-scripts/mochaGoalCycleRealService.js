/*jslint node:true es5:true*/
/*global describe, it*/
'use strict';

var HGSession = require('./HGSession'),
    session = new HGSession(),
    guid = require('node-uuid'),
    assert = require("assert");;

var cycleId;
//Demo: 1) Create goal cycle 2) Add Team "Product Engineering" 3) Publish cycle. Vip should receive email to create company goal
//https://github.com/HighGroundInc/hgapp/wiki/Goals-(OKR)#admin--goals---create-goal-cycle
describe('CuDeliversGoalCycleRealServiceDonotUncomment', function () {
    var serviceURL = 'http://localhost:8095/svc/GoalCycle/';

    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });

    describe('CuCreateGoalCycleRealServiceDonotUncomment', function () {
        it('should create a new goal cycle, with staggered delivery of company, team and member', function (done) {
            var payload = {
                Title: '2016 HighGround Company OKR',
                Description: 'Q4 OKR',
                Notes : 'Please get this done asap',
                CloseDate : Date.now() + 3600 * 1000 * 24 * 7,//a week from now
                ClosePeriod : 5,
                DeliveryMethods: [
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Company',
                        DeliveryDate : Date.now() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : Date.now() + 3600 * 1000 * 24 * 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Team',
                        DeliveryTrigger : 'OtherSet',
                        TrgParticipantType : 'Company',
                        SetDueInDays : 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Member',
                        DeliveryTrigger : 'OtherSet',
                        TrgParticipantType : 'Team',
                        SetDueInDays : 3
                    }
                ],
                CompanyGoalOwner : {
                    // MemberId: "232d61c0-9cd5-11e2-a3a4-25024474fe63",//Phil's locla
                    // UserId: "3cf59990-9cd2-11e2-a3a4-25024474fe63",//Phil's locla
                    // MemberId : 'd2ddecf0-a119-11e2-b177-7d64c8315189',//Gary's local
                    // UserId : 'd2c311f0-a119-11e2-b177-7d64c8315189',//Gary's local
                    MemberId : '232d61c0-9cd5-11e2-a3a4-25024474fe63',//KM's local
                    UserId : '3cf59990-9cd2-11e2-a3a4-25024474fe63',//KM's local
                    FullName : 'Vip Sandhir',
                    Title: 'CEO'
                }
            };
            session.request.post(serviceURL + 'CreateGoalCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    assert.equal(response.body.Title, payload.Title);
                    cycleId = response.body.hgId;
                    console.log(cycleId);
                    done();
                });
        });
    });

    describe('CuAddsProductEngineeringInAboveCycle', function () {
        it('should add Product Engineering team in the above cycle', function (done) {
            var payload = {
                CycleId: cycleId,
                // TeamId: "d54c2520-74d9-11e4-8af1-d982a5bc9132"//Phil's local
                //TeamId: '50cdf500-4296-11e4-baf4-bfc5d30f17c6'//Gary's local
                TeamId: 'f2322580-dd12-11e4-bf0f-73a1dd3e784b'//KM's local
            };
            session.request.post(serviceURL + 'AddTeam')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });
    describe('CuPublishesAboveCycle', function () {
        it('should publish the above cycle', function (done) {
            var payload = {
                CycleId: cycleId
            };
            session.request.post(serviceURL + 'PublishCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });
});
//this should be changed every time running first demo
cycleId = '0eced5c0-f97a-11e4-a076-d59df337be6d';

//Demo: Vip creates two goals, and sets his company goal for above cycele. This should trigger delivery to Cu (the team goal owner)
//https://github.com/HighGroundInc/hgapp/wiki/Goals-(OKR)#profile--goal---create-goal
describe('VipCreatesCompanyGoalsForCycleRealServiceDonotUncomment', function () {
    var goalId,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsVip(done);
    });

    after(function (done) {
        session.Logout(done);
    });

    it('should create a new Company goal, attached to a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Name : 'Company Goal of Q4',
            Participant : {
                ParticipantType : 'Company'
                // ParticipantId : 'Company'
            },
            KeyResults : [
                {
                    Name : 'KR 1: Land 5 big customers',
                    Measure : 'Numeric',
                    Target : 5
                },
                {
                    Name : 'KR 2: Double sales revenue',
                    Measure : 'Percentage',
                    Target : 100
                },
                {
                    Name : 'KR 3: Hire more people',
                    Measure : 'Numeric',
                    Target : 30
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
    it('should create another Company goal, attached to a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Name : 'Second Company Goal of Q4',
            Participant : {
                ParticipantType : 'Company'
            },
            KeyResults : [
                {
                    Name : 'KR 1 - 2: Land 15 medium customers',
                    Measure : 'Numeric',
                    Target : 5
                },
                {
                    Name : 'KR 2 - 2: Increase customer satisfaction',
                    Measure : 'Percentage',
                    Target : 100
                },
                {
                    Name : 'KR 3- 3: Get sales vp',
                    Measure : 'Numeric',
                    Target : 30
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                // goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
    it('should update the Company goal just created', function (done) {
        var payload = {
            hgId : goalId,
            CycleId : cycleId,
            Name : 'Company Goal of Q4 - update',
            Participant : {
                ParticipantType : 'Company'
                // ParticipantId : 'Company'
            },
            KeyResults : [
                {
                    Name : 'KR 1: Land 5 big customers - update',
                    Measure : 'Numeric',
                    Target : 5
                },
                {
                    Name : 'KR 2: Double sales revenue - update',
                    Measure : 'Percentage',
                    Target : 100
                },
                {
                    Name : 'KR 3: Hire more people - update',
                    Measure : 'Numeric',
                    Target : 30
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
    it('should set my company goal', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Company'
                // ParticipantId : 'Company'
            },
        };
        session.request.post(serviceURL + 'SetMyGoalsForCycle')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Cu creates team goals, and sets them for the cycle. This will trigger delivery to all team members
describe('CuCreatesTeamGoalsForCycleRealServiceDonotUncomment', function () {
    var goalId,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });

    it('should create a new Team goal, attached to a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Name : 'Develop Goal of Q4',
            Participant : {
                ParticipantType : 'Team',
                ParticipantId : '50cdf500-4296-11e4-baf4-bfc5d30f17c6'
            },
            KeyResults : [
                {
                    Name : 'KR 1: Roll out 6 big features',
                    Measure : 'Numeric',
                    Target : 6
                },
                {
                    Name : 'KR 2: clear 80 backlog items',
                    Measure : 'Numeric',
                    Target : 80
                },
                {
                    Name : 'KR 3: Contintuous deployment',
                    Measure : 'Numeric',
                    Target : 30
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
    it.skip('should create another Company goal, attached to a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Name : 'QA team Goal of Q4',
            Participant : {
                ParticipantType : 'Team',
                ParticipantId : '50cdf500-4296-11e4-baf4-bfc5d30f17c6'
            },
            KeyResults : [
                {
                    Name : 'KR 1 : reduce defects by half',
                    Measure : 'Percentage',
                    Target : 100
                },
                {
                    Name : 'KR 2: expand QA team by 3 staff',
                    Measure : 'Numeric',
                    Target : 3
                },
                {
                    Name : 'KR 3- 3: auto testing script',
                    Measure : 'Percentage',
                    Target : 100
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
    it('Should set cu team goals for a given cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Team',
                ParticipantId : '50cdf500-4296-11e4-baf4-bfc5d30f17c6'
            },
        };
        session.request.post(serviceURL + 'SetMyGoalsForCycle')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });

});

//Demo: Gary creates his member goals
describe('GaryCreatesMemberGoalsForCycleRealServiceDonotUncomment', function () {
    var goalId,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });

    it('should create a new Member goal, attached to a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Name : 'Gary Development Goal of Q4',
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            },
            KeyResults : [
                {
                    Name : 'KR 1: Finish up ORK backend',
                    Measure : 'Percentage',
                    Target : 100
                },
                {
                    Name : 'KR 2: help with Perform',
                    Measure : 'Percentage',
                    Target : 100
                },
                {
                    Name : 'KR 3: Fix 80 defects',
                    Measure : 'Numeric',
                    Target : 80
                },
                {
                    Name : 'KR 4: refactor 5 services during shark week',
                    Measure : 'Numeric',
                    Target : 5
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
    it('should create a second new Member goal, attached to a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Name : 'Gary communication Goal of Q4',
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            },
            KeyResults : [
                {
                    Name : 'KR 1: Set up lunch and learn sessions',
                    Measure : 'Numeric',
                    Target : 3
                },
                {
                    Name : 'KR 2: communicate more with coworkers',
                    Measure : 'Percentage',
                    Target : 100
                }
            ]
        };
        session.request.post(serviceURL + 'SaveGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Gary request to set his goals for the cycle. This should trigger email to Cu (his manager)
//https://github.com/HighGroundInc/hgapp/wiki/Goals-(OKR)#profile--goal---goal-overview-1
describe('GaryRequestsToSetHisGoalForCycleRealServiceDonotUncomment', function () {
    var goalId,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should submit gary member goal for Cu to approve', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            },
        };
        session.request.post(serviceURL + 'SetMyGoalsForCycle')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Cu rejects Gary's goal for the cycle. This should trigger email to be sent to Gary. His goals will revert to "Setting"
// https://github.com/HighGroundInc/hgapp/wiki/Goals-(OKR)#profile--goals--detail---approver-view-
describe('CuRejectsGaryGoalForCycleRealServiceDonotUncomment', function () {
    var firstGoalId,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should return Gary\'s goals for this cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            }
        };
        session.request.post(serviceURL + 'GetGoalsForParticipantByCycleId')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                if (response.body.length > 0) {
                    firstGoalId = response.body[0].hgId;
                }
                console.log(firstGoalId);
                done();
            });
    });
    it('Should reject Gary\'s first for this cycle', function (done) {
        var payload = {
            GoalId : firstGoalId,
            Note : 'Just do it agin!'
        };
        session.request.post(serviceURL + 'RejectSet')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                // assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Gary request to set his goals for the cycle again. This should trigger email to Cu (his manager)
describe('GaryRequestsToSetGoalAgainRealServiceDonotUncomment', function () {
    var serviceURL = 'http://localhost:8095/svc/Goal/',
        goalId;
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should submit gary member goal for Cu to approve', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            },
        };
        session.request.post(serviceURL + 'SetMyGoalsForCycle')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Cu approves Gary's goal. Gary should receive email
describe('CuApprovesGaryGoalsSettingRealServiceDonotUncomment', function () {
    var goalIds,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should return Gary\'s goals for this cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            }
        };
        session.request.post(serviceURL + 'GetGoalsForParticipantByCycleId')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                if (response.body.length > 0) {
                    goalIds = response.body.map(function (goal) {return goal.hgId; });
                }
                console.log(goalIds);
                done();
            });
    });
    it('Should approve Gary\'s goals for this cycle', function (done) {
        goalIds.forEach(function (goalId) {
            var payload = {
                GoalId : goalId
            };
            session.request.post(serviceURL + 'ApproveSet')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert.equal(response.statusCode, 200);
                    // assert.equal(response.body.Name, payload.Name);
                });
        });
        done();
    });
});

//Demo: Gary updates his goal in the cycle
//https://github.com/HighGroundInc/hgapp/wiki/Goals-(OKR)#profile--goal---goal-detail
describe('GaryGetsUpdatesHisGoalsInCycleRealServiceDonotUncomment', function () {
    var goal,
        serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should return Gary\'s own goals for this cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            }
        };
        session.request.post(serviceURL + 'GetGoalsForParticipantByCycleId')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                if (response.body.length > 0) {
                    goal = response.body.filter(function (goal) {
                        return goal.Name === 'Gary Development Goal of Q4';
                    })[0];
                }
                done();
            });
    });
    it('Should update Gary\'s member goal key result', function (done) {
        var payload = {
            GoalId : goal.hgId,
            KeyResultId : goal.KeyResults[1].hgId,
            Progress : 70
        };
        session.request.post(serviceURL + 'UpdateKeyResultProgress')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                done();
            });
    });
});

//Demo: Gary requests to close his goal. This should trigger email to Cu (manager)
describe('GaryRequestsToCloseHisGoalRealServiceDonotUncomment', function () {
    var serviceURL = 'http://localhost:8095/svc/Goal/',
        goalId;
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should submit gary member goal for Cu for closure', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            },
        };
        session.request.post(serviceURL + 'RequestCloseMyGoalsForCycle')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                console.log(goalId);
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Cu rejects. This will trigger email to Gary
describe('CuRejectsGaryGoalClosureRequestForCycleRealServiceDonotUncomment', function () {
    var serviceURL = 'http://localhost:8095/svc/Goal/',
        firstGoalId;
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should return Gary\'s goals for this cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            }
        };
        session.request.post(serviceURL + 'GetGoalsForParticipantByCycleId')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                if (response.body.length > 0) {
                    firstGoalId = response.body[0].hgId;
                }
                console.log(firstGoalId);
                done();
            });
    });
    it('Should reject Gary\'s first goal for closure for this cycle', function (done) {
        var payload = {
            GoalId : firstGoalId,
            Note : 'Not yet! You have to complet more!'
        };
        session.request.post(serviceURL + 'RejectClosure')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                // assert.equal(response.statusCode, 200);
                // assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Gary request to close his goal again. This should trigger email to Cu (manager)
describe('GaryRequestsToCloseHisGoalAgainRealServiceDonotUncomment', function () {
    var serviceURL = 'http://localhost:8095/svc/Goal/',
        goalId;
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should submit gary member goal for Cu for closure', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            },
        };
        session.request.post(serviceURL + 'RequestCloseMyGoalsForCycle')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                goalId = response.body.hgId;
                console.log(goalId);
                assert.equal(response.body.Name, payload.Name);
                done();
            });
    });
});

//Demo: Cu approves the goal. Now the goal is closed and Gary receives email
describe('CuApprovesGaryGoalForClosureRealService', function () {
    var serviceURL = 'http://localhost:8095/svc/Goal/',
        goalIds;
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should return Gary\'s goals for this cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            Participant : {
                ParticipantType : 'Member',
                ParticipantId : '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864'
            }
        };
        session.request.post(serviceURL + 'GetGoalsForParticipantByCycleId')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                if (response.body.length > 0) {
                    goalIds = response.body.map(function (goal) {return goal.hgId; });
                }
                console.log(goalIds);
                done();
            });
    });
    it('Should approve Gary\'s goals for this cycle', function (done) {
        // var payload = {
        //     GoalId : goalIds[1]
        // };
        // session.request.post(serviceURL + 'ApproveSet')
        //     .type('json')
        //     .send(payload)
        //     .end(function (error, response) {
        //         assert.equal(response.statusCode, 200);
        //         // assert.equal(response.body.Name, payload.Name);
        //         done();
        //     });
        goalIds.forEach(function (goalId) {
            var payload = {
                GoalId : goalId
            };
            session.request.post(serviceURL + 'ApproveClose')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert.equal(response.statusCode, 200);
                    // assert.equal(response.body.Name, payload.Name);
                    // done();
                });
        });
        done();
    });
});

//Demo: 10) Create goal cycle 2) Add Team "Product Engineering" 3) Publish cycle. Vip should receive email to create company goal
describe('CuDelivers2015GoalCycleRealService', function () {
    var serviceURL = 'http://localhost:8095/svc/GoalCycle/',
        curCycleId;

    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });

    describe('CuCreateTimeBasedGoalCycleRealServiceDonotUncomment', function () {
        it('should create a new goal cycle, with staggered delivery of company, team and member', function (done) {
            var payload = {
                Title: '2016 First Quarter HighGround Company OKR',
                Description: 'Q4 OKR',
                Notes : 'Please get this done asap',
                CloseDate : Date.now() + 3600 * 1000 * 24 * 7,//a week from now
                ClosePeriod : 5,
                CheckInFrequency : 'Weekly',
                DeliveryMethods: [
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Company',
                        DeliveryDate : Date.now() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : Date.now() + 3600 * 1000 * 24 * 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Daily',
                        ParticipantType : 'Team',
                        DeliveryDate : Date.now() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : Date.now() + 3600 * 1000 * 24 * 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Member',
                        DeliveryDate : Date.now() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : Date.now() + 3600 * 1000 * 24 * 3,
                    }
                ],
                CompanyGoalOwner : {
                    MemberId : '232d61c0-9cd5-11e2-a3a4-25024474fe63',//KM's local
                    UserId : '3cf59990-9cd2-11e2-a3a4-25024474fe63',//KM's local
                    FullName : 'Vip Sandhir',
                    Title: 'CEO'
                }
            };
            session.request.post(serviceURL + 'CreateGoalCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    curCycleId = response.body.hgId;
                    done();
                });
        });
    });
    describe('CuPublishesAboveCycle', function () {
        it('should publish the above cycle', function (done) {
            var payload = {
                CycleId: curCycleId
            };
            session.request.post(serviceURL + 'PublishCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });

        });
    });
});
cycleId = '0eced5c0-f97a-11e4-a076-d59df337be6d';

//demo: 11, update an existing draft cycle
describe('CuDelivers2015GoalCycleRealService', function () {
    var serviceURL = 'http://localhost:8095/svc/GoalCycle/',
        curCycleId;

    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });

    describe('CuUpdatesGoalCycleRealServiceDonotUncomment', function () {
        it('Should update a cycle', function (done) {
            var payload = {
                hgId: "a595aa30-0a62-11e5-ab3c-0bff91ec00fc",
                Title: '2016 First Quarter HighGround Company OKR',
                Description: 'Q4 OKR',
                Notes : 'Please get this done asap',
                CloseDate : Date.now() + 3600 * 1000 * 24 * 7,//a week from now
                ClosePeriod : 5,
                CheckInFrequency : 'Weekly',
                DeliveryMethods: [
                    {
                        CheckInFrequency : 'Weekly',
                        ParticipantType : 'Company',
                        DeliveryDate : Date.now() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : Date.now() + 3600 * 1000 * 24 * 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Daily',
                        ParticipantType : 'Team',
                        DeliveryDate : Date.now() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : Date.now() + 3600 * 1000 * 24 * 3,
                        ApprovalFlags: {
                            Set : false,
                            Update : false,
                            Closure : false
                        }
                    },
                    {
                        CheckInFrequency : 'Monthly',
                        ParticipantType : 'Member',
                        DeliveryDate : Date.now() - 1000,//deliver now
                        DeliveryTrigger : 'ByDate',
                        SetDueDate : Date.now() + 3600 * 1000 * 24 * 3,
                    }
                ]
            };
            session.request.post(serviceURL + 'UpdateGoalCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    curCycleId = response.body.hgId;
                    done();
                });
        });
    });
});

//demo: 12, set the company owner of a cycle
describe('CuSetsTheCompanyGoalOwnerOfAboveCycle', function () {
    var serviceURL = 'http://localhost:8095/svc/GoalCycle/';
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should set the CompanyGoalOwner of a cycle', function (done) {
        var payload = {
            CycleId : cycleId,
            MemberId: 'f4248f70-f989-11e4-ba77-a180c46f6a12'
        };
        session.request.post(serviceURL + 'SetCompanyGoalOwner')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                done();
            });
    });
});

//demo: 13, remove the company owner of a cycle
describe('CuRemovesTheCompanyGoalOwnerOfAboveCycle', function () {
    var serviceURL = 'http://localhost:8095/svc/GoalCycle/';
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should set the CompanyGoalOwner of a cycle', function (done) {
        var payload = {
            CycleId : cycleId
        };
        session.request.post(serviceURL + 'RemoveCompanyGoalOwner')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                done();
            });
    });
});

describe('CuCommentsOnGarysGoal', function () {
    var serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsCu(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should comment on Gary\'s goals', function (done) {
        var payload = {
            GoalId : 'f4248f70-f989-11e4-ba77-a180c46f6a12',
            Note: 'The progress is really slow!'
        };
        session.request.post(serviceURL + 'CommentGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                done();
            });
    });
});

describe('GaryCommentsOnGarysGoal', function () {
    var serviceURL = 'http://localhost:8095/svc/Goal/';
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });
    it('Should comment on Gary\'s goals', function (done) {
        var payload = {
            GoalId : 'f4248f70-f989-11e4-ba77-a180c46f6a12',
            Note: 'The progress is really slow!'
        };
        session.request.post(serviceURL + 'CommentGoal')
            .type('json')
            .send(payload)
            .end(function (error, response) {
                assert.equal(response.statusCode, 200);
                done();
            });
    });
});
describe('EventBusAPIHittingRealServiceDonotUncomment', function () {
    var serviceURL = 'http://localhost:8086/' + '1.0/EventBus';
    // var serviceURL = 'https://apipoc.highground.com/1.0/EventBus';
    // var serviceURL = 'https://apiuat.highground.com/1.0/EventBus';
    // var serviceURL = 'https://apitron.highground.com/1.0/EventBus';

    describe('Create new events in EventBus', function () {

        it('should create a new event with a ContractSold event type', function (done) {
            var payload = {
                EventType: 'ContractSold',
                Payload : {
                    Amount : 300,
                    CompanyName : 'Mercury Industries',
                    UserEmail : 'gary@highground.com',
                    OpportunityName: 'Apple'
                }
            };
            session.request.post(serviceURL)
                .type('json')
                .set('clientkey', 'ab090607-2b7f-40a0-85a5-054aeadf23b5')
                .send(payload)
                .end(function (error, response) {
                    console.log(response.body);
                    assert.equal(response.statusCode, 200);
                    assert.equal(response.body.EventType, payload.EventType);
                    done();
                });
        });

    });
});


