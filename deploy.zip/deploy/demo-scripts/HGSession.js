var HGSession = function () {
    "use strict";

    var loginURL = 'http://localhost:8095/svc/User/Login',
        logoutURL = 'http://localhost:8095/svc/User/Logout',
        request = require('superagent').agent(),
        assert = require('assert'),
        currentUserId;

    this.request = request;

    this.LoginAsCu = function (done) {
        var loginInfo = {
            UserName: 'cu@highground.com',
            Password: 'qatest1'
        };

        request.post(loginURL)
            .type('json')
            .send(loginInfo)
            .end(function (error, data) {
                assert.equal(data.statusCode, 200);
                assert(data.body.UserContext);
                assert(data.body.UserToken);

                currentUserId = data.body.hgId;

                done();
            });
    };
    this.LoginAsGary = function (done) {
        var loginInfo = {
            UserName: 'gary@highground.com',
            Password: 'qatest1'
        };

        request.post(loginURL)
            .type('json')
            .send(loginInfo)
            .end(function (error, data) {
                assert.equal(data.statusCode, 200);
                assert(data.body.UserContext);
                assert(data.body.UserToken);

                currentUserId = data.body.hgId;

                done();
            });
    };
    this.LoginAsVip = function (done) {
        var loginInfo = {
            UserName: 'vip@highground.com',
            Password: 'qatest1'
        };

        request.post(loginURL)
            .type('json')
            .send(loginInfo)
            .end(function (error, data) {
                assert.equal(data.statusCode, 200);
                assert(data.body.UserContext);
                assert(data.body.UserToken);

                currentUserId = data.body.hgId;

                done();
            });
    };

    this.Logout = function (done) {
        request.get(logoutURL)
            .end(function (error, data) {
                done();
            });
    };

    this.GetUserInfo = function (callback) {
        request.get(loginURL)
            .end(function (response) {
                assert.equal(response.statusCode, 200);
                assert(response.body);

                callback(response.body);
            });
    };

    this.currentUserId = function () {
        return currentUserId;
    };
};

module.exports = HGSession;