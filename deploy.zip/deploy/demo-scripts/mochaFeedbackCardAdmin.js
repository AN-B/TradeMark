/*jslint node:true es5:true*/
/*global describe, it*/
'use strict';

var HGSession = require('./HGSession'),
    session = new HGSession(),
    guid = require('node-uuid'),
    assert = require("assert"),
    cardServiceURL = 'http://localhost:8095/svc/FeedbackCard/',
    cycleServiceURL = 'http://localhost:8095/svc/FeedbackCycle/',
    sessionServiceURL = 'http://localhost:8095/svc/FeedbackSession/',
    len;

describe('CuCreatesFeedbackCardAndEditAndCreateACycle', function () {
    var cards,
        cardId,
        initiatorId,
        cycleId;

    before(function (done) {
        session.LoginAsCu(done);
    });
    after(function (done) {
        session.Logout(done);
    });

    describe('CreatesOneFeedbackCard', function () {
        it('should create a new feedback card', function (done) {
            var payload = {
                Title: new Date().toString() + 'HG FeedbackCard',
                Description: new Date().toString() + ' HG FeedbackCard to test',
                Questions: [],
                Type: 'CardTypeOne'
            };
            session.request.post(cardServiceURL + 'SaveCard')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    cardId = response.body.hgId;
                    console.log(cardId);
                    done();
                });
        });
    });

    describe('UpdateAndActivateAboveCard', function () {
        it('should create a new feedback card', function (done) {
            var payload = {
                hgId: cardId,
                Title: new Date().toString() + 'HG FeedbackCard updated',
                Description: new Date().toString() + ' HG FeedbackCard to test updated',
                Questions: [],
                PeopleTypes: [{
                    PeopleTypeName: 'Subject',
                    Required: true
                }, {
                    PeopleTypeName: 'Manager',
                    Required: true
                }],
                Type: 'CardTypeOne',
                Status: 'Active'
            };
            session.request.post(cardServiceURL + 'SaveCard')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body.Status);
                    done();
                });
        });
    });

    describe('GetAllAvailableFeedbackCard', function () {
        it('should create a new feedback card', function (done) {
            session.request.get(cardServiceURL + 'GetCards')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    cards = response.body;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    console.log('there are ' + len + ' cards');
                    // response.body.forEach(function (card) {
                    //     console.log(card.Title);
                    // });
                    done();
                });
        });
    });

    describe('SelectCardAndCreateCycle', function () {
        it('should create a new feedback cycle', function (done) {
            console.log(cards[0].Title);
            var payload = {
                Title: new Date().toString() + 'HighGround FeedbackCycle',
                Description: new Date().toString() + ' HighGround FeedbackCycle to test',
                Notes: "Test note",
                Workflow: 'Direct',
                PeriodStartDate: Date.now(),
                PeriodEndDate: Date.now(),
                Type: 'CycleTypeOne',
                CardId: cards[0].hgId,
                TriggerType: 'RequestAnytime',//other types include "GiveAnytime", "EventTrigger", "FrequencyTrigger"
                // TriggerType: 'EventTrigger',
                DeliveryDate: Date.now(),
                DaysToRequest: 9
            };
            session.request.post(cycleServiceURL + 'CreateCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    cycleId = response.body.hgId;
                    console.log("CycleId: ", cycleId);
                    done();
                });
        });
    });
    describe('AddEmployeesInProductEngeeringChicagoToAboveCycle', function () {
        it.skip('should add Product Engineering team in the above cycle', function (done) {
            var payload = {
                CycleId: cycleId,
                Criteria: [{
                    CriteriaType: 'Level',
                    EntityName: 'Employee'
                }, {
                    CriteriaType: 'Department',
                    EntityId: '50cdf500-4296-11e4-baf4-bfc5d30f17c6'
                }, {
                    CriteriaType: 'Location',
                    EntityId: 'e0b83cf0-9c43-11e4-a906-5de82fce06d9'
                }]
            };
            session.request.post(cycleServiceURL + 'AddCluster')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    console.log(response.body.hgId);
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });

    describe('PublishesAboveFeedbackCycle', function () {
        it('should publish the above cycle', function (done) {
            var payload = {
                CycleId: 'df52a0f0-0630-11e6-af00-3df8c4d2e969'
            };
            session.request.post(cycleServiceURL + 'PublishCycle')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body);
                    done();
                });
        });
    });

    describe('GetFeedbackPromptsAvailableToMe', function () {
        it('should Get Feedback Prompts Available To Me', function (done) {
            session.request.get(cycleServiceURL + 'GetMyCycles')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    initiatorId = response.body[0].hgId;
                    //assert.equal(response.body.Title, payload.Title);
                    console.log('You have ' + len + ' prompt');
                    // console.log(response.body);
                    // response.body.forEach(function (card) {
                    //     console.log(card.Title);
                    // });
                    done();
                });
        });
    });

    describe('GetCuSessionsToReceive', function () {
        it('should return feedback session given to me that are filled out but i have not thanked', function (done) {
            session.request.get(sessionServiceURL + 'GetSessionsToReceive')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    console.log('You have ' + len + ' received feedback sessions');
                    console.log(response.body);
                    // response.body.forEach(function (card) {
                    //     console.log(card.Title);
                    // });
                    done();
                });
        });
    });

    describe('GetCuSessionsReceived', function () {
        it('should get sessions received', function (done) {
            session.request.get(sessionServiceURL + 'GetSessionsReceived')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    //assert.equal(response.body.Title, payload.Title);
                    console.log('You have ' + len + ' received feedback sessions');
                    console.log(response.body);
                    // response.body.forEach(function (card) {
                    //     console.log(card.Title);
                    // });
                    done();
                });
        });
    });

    describe('CuRatesSessionThatHeReceived', function () {
        it('should RatesSessionThatHeReceived', function (done) {
            var payload = {
                    SessionId: '34e4f800-027c-11e6-988a-3d54ee801243',
                    SubjectRating: 'Helpful',
                    Note: "I don't aggree the feedbac but thanks."
                };
            session.request.post(sessionServiceURL + 'RateReceivedSession')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body.Status);
                    done();
                });
        });
    });

    describe('ChooseLatestPromptAndSendInviteTo4Members', function () {
        it('should Choose LatestPromptAndSendInviteTo3Members', function (done) {
            var payload = {
                CycleId: "ca123820-0718-11e6-96cc-4d0f3de565e5",
                ReviewerMemberIds: [
                    "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
                    // "f6834ac2-814a-11e4-b483-232126d25791",
                    // "d2df2570-a119-11e2-b177-7d64c8315189",
                    // "d2ddecf0-a119-11e2-b177-7d64c8315189"
                ],
                Note: 'Hey dude can yo provide some feedback please.'
            };
            session.request.post(sessionServiceURL + 'RequestFeedback')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    console.log(response.body);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });
});

describe('GaryLooksAtHisFeedbackRequestsAndDoStuff', function () {
    var sessionId;
    before(function (done) {
        session.LoginAsGary(done);
    });

    after(function (done) {
        session.Logout(done);
    });

    describe('GetSessionsToGiveIncludingPendingAndAccepted', function () {
        it('should GetSessionsToGive', function (done) {
            session.request.get(sessionServiceURL + 'GetSessionsToGive')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    sessionId = response.body[0] ? response.body[0].hgId : "";
                    console.log(len + ' requests');
                    console.log(sessionId);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });

    describe('GetSessionsGaveIncludingSubmittedSubjectRatedCompletedClosed', function () {
        it('should GetSessionsToGive', function (done) {
            session.request.get(sessionServiceURL + 'GetSessionsGave')
                .type('json')
                .end(function (error, response) {
                    len = response.body.length;
                    assert(response);
                    sessionId = response.body[0] ? response.body[0].hgId : "";
                    console.log(sessionId);
                    console.log(response.body);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });

    describe('ReviewerSeesSubjectRating', function () {
        it('should AcceptFirstFeedbackSessionRequest', function (done) {
            var payload = {
                    SessionId: '34e4f800-027c-11e6-988a-3d54ee801243'
                };
            session.request.post(sessionServiceURL + 'SeeSubjectRating')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body);
                    done();
                });
        });
    });

    describe('GetOneSessionById', function () {
        it('should GetSessionById', function (done) {
            session.request.get(sessionServiceURL + 'GetSessionById?sId=34e4f800-027c-11e6-988a-3d54ee801243')
                .type('json')
                .end(function (error, response) {
                    assert(response);
                    console.log(response.body);
                    assert.equal(response.statusCode, 200);
                    done();
                });
        });
    });

    describe('AnswerAndSaveAboveSession', function () {
        it('should AnswerAndSaveAboveSession', function (done) {
            var payload = {
                    SessionId: '85e716b0-0719-11e6-9e8d-cd630914933e',
                    Questions: [{
                        hgId: 'ca0fee30-0718-11e6-96cc-4d0f3de565e5',
                        Answer: {
                            SelectedValue: 3,
                            Text: 'Place holder q1'
                        }
                    }, {
                        hgId: 'ca0fee31-0718-11e6-96cc-4d0f3de565e5',
                        Answer: {
                            Text: 'Place holder q2'
                        }
                    }]
                };
            session.request.post(sessionServiceURL + 'AnswerAndSave')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body.Status);
                    done();
                });
        });
    });

    describe('TryToSubmitAboveSession', function () {
        it('should AcceptFirstFeedbackSessionRequest', function (done) {
            var payload = {
                    SessionId: '85e716b0-0719-11e6-9e8d-cd630914933e',
                    Questions: [{
                        hgId: 'ca0fee30-0718-11e6-96cc-4d0f3de565e5',
                        Answer: {
                            SelectedValue: 5,
                            Text: 'Place holder q1 - updated'
                        }
                    }]
                };
            session.request.post(sessionServiceURL + 'SubmitSession')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body);
                    done();
                });
        });
    });


    describe('AcceptFirstFeedbackSessionRequest', function () {
        it('should AcceptFirstFeedbackSessionRequest', function (done) {
            var payload = {
                    SessionId: '85e716b0-0719-11e6-9e8d-cd630914933e'
                };
            session.request.post(sessionServiceURL + 'AcceptRequest')
                .type('json')
                .send(payload)
                .end(function (error, response) {
                    assert(response);
                    assert.equal(response.statusCode, 200);
                    console.log(response.body.Status);
                    done();
                });
        });
    });
});

describe('VipLooksAtHisFeedbackRequestsAndDoStuff', function () {
    var sessionId;
    before(function (done) {
        session.LoginAsVip(done);
    });

    after(function (done) {
        session.Logout(done);
    });

    describe('DeclineFirstFeedbackSessionRequest', function () {
        it('should DeclineFirstFeedbackSessionRequest', function (done) {
            var payload = {
                    SessionId: sessionId,
                    Note: "Sorry I don't have time."
                };
            if (sessionId) {
                session.request.post(sessionServiceURL + 'DeclineRequest')
                    .type('json')
                    .send(payload)
                    .end(function (error, response) {
                        assert(response);
                        assert.equal(response.statusCode, 200);
                        console.log(response.body.Status);
                        done();
                    });
            } else {
                console.log("No more outstanding sessions");
                done();
            }
        });
    });
});

//mocha --opts deploy/demo-scripts/mocha.opts --grep CuCreatesFeedbackCardAndEditAndCreateACycle
//mocha --opts deploy/demo-scripts/mocha.opts --grep GetFeedbackPromptsAvailableToMe
//mocha --opts deploy/demo-scripts/mocha.opts --grep ChooseLatestPromptAndSendInviteTo4Members
//neeed to change cycleId
//mocha --opts deploy/demo-scripts/mocha.opts --grep GaryLooksAtHisFeedbackRequestsAndDoStuff
//mocha --opts deploy/demo-scripts/mocha.opts --grep VipLooksAtHisFeedbackRequestsAndDoStuff
