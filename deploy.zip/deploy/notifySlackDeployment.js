"use strict";

var superagent = require('superagent'),
    messageType = process.argv[2],
    username = process.argv[3],
    env = process.argv[4],
    branch = process.argv[5],
    userDisplayName = username,
    serverDisplayName = env,
    webhookUrl = 'https://hooks.slack.com/services/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',
    channels = [
        '#deployments'
    ];

function getPayload() {
    var params = {
            username: 'heroku',
            icon_url: 'https://slack.global.ssl.fastly.net/7bf4/img/services/heroku_48.png'
        },
        usernameMap = {
            philipplekhanov: ':bender:',
            roboto: ':danger:',
            rosshettel: ':groot:',
            tuance: ':cu:',
            sumasoft: ':sumasoft:'
        },
        envMap = {
            Tron: ':tron:',
            Cylon: ':cylon:',
            Borg: ':borg:',
            Ripley: ':ripley:',
            Scully: ':scully:',
            Trinity: ':trinity:'
        },
        messageString;

    userDisplayName = usernameMap[username] || username;
    serverDisplayName = envMap[env] || env;

    switch (messageType) {
    case 'deploying':
        messageString = ':warning: ' + userDisplayName + ' is taking ' + serverDisplayName + ' server down!';
        params.attachments = [{
            fallback: messageString,
            color: '#FFA500',
            text: messageString
        }];
        break;
    case 'deployed':
        messageString = ':success: ' + userDisplayName + ' deployed :branch: ' + branch + ' to ' + serverDisplayName + ' server.';
        params.attachments = [{
            fallback: messageString,
            color: '#008000',
            text: messageString
        }];
        break;
    case 'error':
        messageString = ':bangbang: ' + userDisplayName + ' encountered an error deploying.';
        params.attachments = [{
            fallback: messageString,
            color: '#FF0000',
            text: messageString
        }];
        break;
    }

    return params;
}

function post() {
    var payload = getPayload();

    channels.forEach(function (channel) {
        payload.channel = channel;
        superagent.post(webhookUrl)
            .send(payload)
            .end(function (err, res) {
                if (res.statusCode !== 200) {
                    console.log('Slack returned non 200 response code', res.body);
                }
            });
    });
}

post();