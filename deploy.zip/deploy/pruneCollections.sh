rm -Rfd hgcommon/Notification.bson
rm -Rfd hgcommon/Notification.metadata.json
rm -Rfd hgcommon/EventBusItem.bson
rm -Rfd hgcommon/EventBusItem.metadata.json
rm -Rfd hgcommon/UserInfoWithToken.bson
rm -Rfd hgcommon/UserInfoWithToken.metadata.json
rm -Rfd hgcommon/ProvisionActivity.bson
rm -Rfd hgcommon/ProvisionActivity.metadata.json

rm -Rfd hgfinance/Transaction.bson
rm -Rfd hgfinance/Transaction.metadata.json

rm -Rfd hgsecurity/UserSecurityWithToken.bson
rm -Rfd hgsecurity/UserSecurityWithToken.metadata.json
