/*jslint node:true es5:true*/
'use strict';

//node deploy/changePassword.js --p abc321 --env local
//node deploy/changePassword.js --p abc321 --env cylon
//node deploy/changePassword.js --p abc321 --env All (for all environments)
//availableEnv list does not include demo, prod, st, avatar
var availableEnv = [
        'local',
        'cylon',
        'borg',
        'dev',
        'poc',
        'qa',
        'tron',
        'uat',
        'ripley',
        'scully',
        'trinity'
    ],
    spawn = require('child_process').spawn,
    argsv = require('minimist')(process.argv.slice(2)),
    async = require('async'),
    superagent = require('superagent'),
    webhookUrl = 'https://hooks.slack.com/services/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',
    channel = '#dev-team',
    requireUncached = function (module) {
        delete require.cache[require.resolve(module)];
        return require(module);
    };

function setEnvValue(key, value) {
    process.env[key] = value;
}
function getHerokuConfig (params, callback) {
    var heroku = spawn('heroku', ['config:get',  params.KEY, '--app', params.APP]),
        value = '',
        errorMessage = '';
    heroku.stdout.on('data', function (data) {
        value += data.toString();
    });
    heroku.stderr.on('data', function (data) {
        errorMessage += data.toString();
    });
    heroku.on('close', function (code) {
        if (code !== 0) {
            console.log('code error', code);
        }
        callback(errorMessage, value.replace("\n", ""));
    });
}
function setDatabaseEnv(params, callback) {
    if (params.ENV === 'local') {
        return callback();
    }
    var dbKeyList = ['MONGO_HGCOMMON', 'MONGO_HGFINANCE', 'MONGODB_HGLOG', 'MONGO_HGPERFORM', 'MONGO_HGPERKA',
        'MONGO_HGREPORTS', 'MONGO_HGSECURITY', 'MONGO_HGTHANKA', 'REPLICA_PRIMARY', 'REPLICA_SECONDARY',
        'REPLICA_PRIMARY_B', 'MONGO_REPLICA', 'MONGO_REPLICA_LR'];
    async.each(dbKeyList, function (key, kCallback) {
        getHerokuConfig({ KEY: key, APP: 'hgn' + params.ENV}, function (error, value) {
            if (error) {
                return kCallback(error);
            }
            setEnvValue(key, value);
            return kCallback();
        });
    }, callback);
}
function setConnectionCache(env, callback) {
    process.env.BUILD_ENV = env;
    requireUncached('../hgnode/configurations/config.js');
    var ConnectionCache = requireUncached('../hgnode/framework/ConnectionCache.js');
    ConnectionCache.init(function () {
        callback(null, {
            ConnectionCache: ConnectionCache
        });
    });
}
function generatePasswordHash(params, callback) {
    var iterations = params.iterations || 15000,
        keyLen = 512,
        crypto = require('crypto'),
        pepper = process.env.PEPPER || 'pepper',
        secret;
    if (!params.salt) {
        try {
            params.salt = crypto.randomBytes(16).toString('hex');    // 16 bytes = 128 bits
        } catch (err) {
            console.log('Error generating random bytes for salt', err);
            return callback('Could not generate salt. Please try again.'); //better error message here
        }
    }
    secret = params.password + params.salt;
    crypto.pbkdf2(secret, pepper, iterations, keyLen, function (err, key) {
        if (err) {
            console.log(err);
            return callback(err);
        }
        callback(null, {
            passwordHash: key.toString('hex'),
            salt: params.salt,
            iterations: iterations
        });
    });
}
function updateMembersPassword(params, callback) {
    generatePasswordHash({password: params.Password}, function (error, data) {
        if (error) {
            return callback(error);
        }
        var UserInfoWithToken = params.ConnectionCache.hgcommon.db.collection('UserInfoWithToken'),
            UserSecurity = params.ConnectionCache.hgsecurity.db.collection('UserSecurity'),
            UserSecurityWithToken = params.ConnectionCache.hgsecurity.db.collection('UserSecurityWithToken');
        UserSecurity.update({},
            {
                $set: {
                    Password_PBKDF2: data.passwordHash,
                    PasswordIterations: data.iterations,
                    PasswordSalt: data.salt
                }
            }, {
                multi: true
            }, function (error, data) {
                if (error) {
                    return callback(error);
                }
                console.log([data.result.n, 'users passwords updated on', params.Env].join(' '));
                async.parallel({
                    userInfo: function (fcallback) {
                        UserInfoWithToken.remove({}, fcallback);
                    },
                    userSecurity: function (fcallback) {
                        UserSecurityWithToken.remove({}, fcallback);
                    }
                }, function (error) {
                    if (error) {
                        return callback(error);
                    }
                    if (params.Env === 'local') {
                        return callback();
                    }
                    var msg = 'Warning: QA Admin has updated members password to ' + params.Password + ' for ' + params.Env + ' server';
                    superagent.post(webhookUrl)
                        .send({
                            channel: channel,
                            username: 'QA Admin',
                            attachments: [{
                                fallback: msg,
                                color: '#FFA500',
                                text: msg
                            }]
                        })
                        .end(function (error, res) {
                            if (error) {
                                return callback(error);
                            }
                            if (res.statusCode !== 200) {
                                console.log(res.body);
                            }
                            return callback();
                        });
                });
        });
    });
}

if (!argsv.env) {
    console.log('Missing Required Env');
    return false;
}
if (argsv.env && availableEnv.indexOf(argsv.env) === -1 && argsv.env !== 'All') {
    console.log('Unknown Environment: ' + argsv.env);
    return false;
}
if (!argsv.p) {
    console.log('Missing Password');
    return false;
}
var params = {
    Password: argsv.p
};
console.log('==================================');
console.log('| Running Change Password Script! |');
console.log('==================================');
async.eachSeries(argsv.env === 'All' ? availableEnv : [argsv.env], function (env, pCallback) {
    console.log('Changing Password for ', env);
    if (['prod', 'demo', 'st', 'avatar'].indexOf(env.toLowerCase()) > -1) {
        return pCallback('SCRIPT SHOULD NOT RUN ON THIS ENV:' + env);
    }
    params.Env = env;
    setDatabaseEnv({ENV: params.Env}, function (error) {
        if (error) {
            return pCallback(error);
        }
        setConnectionCache(env, function (error, data) {
            params.ConnectionCache = data.ConnectionCache;
            updateMembersPassword(params, function () {
                params.ConnectionCache.shutdown();
                pCallback();
            });
        });    
    });    
}, function (error) {
    if (error) {
        console.log('==============================');
        console.log('| Houston we have a problem! |');
        console.log('==============================');
        console.log(error);
        console.log('==============================');
        process.exit(1);
    }
    console.log('============================');
    console.log('| Change Password Completed!|');
    console.log('============================');
    process.exit(0);
});




