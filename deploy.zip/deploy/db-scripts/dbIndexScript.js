var databases = ["hgcommon", "hgperform", "hgfinance", "hgthanka", "hgsecurity", "hgperka", "hglog", "hgreports"], 
    pIndex = [];
    
// GET ALL indexes
databases.forEach(function(dbName) {
    db = db.getSiblingDB(dbName);
    var collections = db.getCollectionNames();
    collections.forEach(function(collection) {
        db[collection].getIndexes().forEach(function(indexItem) {
            if (indexItem.name !== "_id_") {
                 pIndex.push({
                     Database: dbName,
                     Collection: collection,
                     Key: indexItem.key,
                     name: indexItem.name
                 });
             }
        })
    })
});
print(pIndex); 

//DROP ALL INDEXES
["hgcommon", "hgperform", "hgfinance", "hgthanka", "hgsecurity", "hgperka", "hglog", "hgreports"].forEach(function(dbName) {
    db = db.getSiblingDB(dbName);
    collections = db.getCollectionNames();
    collections.forEach(function(collection) {
        db[collection].getIndexes().forEach(function(indexItem) {
            db[collection].dropIndexes();
        })
    })
});


//APPLY ALL INDEXES
pIndex.forEach(function(indexItem) {
    db = db.getSiblingDB(indexItem.Database);
    db[indexItem.Collection].createIndex(indexItem.Key, {name: indexItem.name})
});




