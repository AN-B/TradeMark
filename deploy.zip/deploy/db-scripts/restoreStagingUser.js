load("commonDB.js");
setEnv("st");

var userVal = "STAGING_USERNAME",
    pwdVal = "STAGING_PASSWORD",
    user,
    setRoles = function (dbName) {
        return {
            user: userVal,
            pwd: pwdVal,
            roles: [
                {
                    role: "root",
                    db: "admin"
                },
                {
                    role: "dbOwner",
                    db: "st-" + dbName
                }
            ]
        };
    };

switchDB("hgcommon");
user = setRoles('hgcommon');
db.dropUser(user.user);
db.createUser(user);

switchDB("hgfinance");
user = setRoles('hgfinance');
db.dropUser(user.user);
db.createUser(user);

switchDB("hglog");
user = setRoles('hglog');
db.dropUser(user.user);
db.createUser(user);

switchDB("hgperform");
user = setRoles('hgperform');
db.dropUser(user.user);
db.createUser(user);

switchDB("hgperka");
user = setRoles('hgperka');
db.dropUser(user.user);
db.createUser(user);

switchDB("hgreports");
user = setRoles('hgreports');
db.dropUser(user.user);
db.createUser(user);

switchDB("hgsecurity");
user = setRoles('hgsecurity');
db.dropUser(user.user);
db.createUser(user);

switchDB("hgthanka");
user = setRoles('hgthanka');
db.dropUser(user.user);
db.createUser(user);

switchDB("hgcommon");
// remove slack integration from other companies
db.GroupSSO.update({GroupId:{$ne:"1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde"}},{$set:{Slack:{channels:[],access_token:""}}},{multi:true});
// change the channels for mercury industries
db.GroupSSO.update({GroupId:"1d277e60-9cd9-11e2-ba5b-8bde9b7bbcde"},{$set:{"Slack.channels":["#qa","#testing"]}});
// remove all yammer and saml integrations
db.GroupSSO.update({},{$set:{Yammer:{},SAML:{}}},{multi:true});

switchDB("hgsecurity");
// replace the client api keys
db.ClientProfile.find({}).forEach(function (profile) {
    profile.APIKey = profile.hgId;
    db.ClientProfile.save(profile);
});
