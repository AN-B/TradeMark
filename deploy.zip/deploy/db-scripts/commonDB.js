var environment = null,
    mapEnv = {
        local: '',
        dev: '',
        prod: '',
        qa: 'qa',
        uat: 'uat',
        poc: 'poc',
        tron: 'tron',
        borg: 'borg',
        cylon: 'cylon',
        demo: 'demo',
        ripley: 'ripley',
        scully : 'scully',
        trinity : 'trinity',
        st: 'st'
    };
function setEnv(env) {
    environment = mapEnv[env];
}
function switchDB(dbname) {
    if (environment) {
        dbname = environment + "-" + dbname;
    }
    db = db.getSiblingDB(dbname);
}
