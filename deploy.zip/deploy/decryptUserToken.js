var async = require('async'),
    exec = require('child_process').exec,
    keystore = require('../hgnode/configurations/keystore'),
    environment = process.argv[2],
    userToken = process.argv[3],
    cryptoPassword = process.argv[4];

// node projects/hgapp/deploy/cryptoHelper.js [ENVIRONMENT] [ENCRYPTED_USER_TOKEN_VALUE] [OPTIONAL_CRYPTO_PASSWORD]
// node projects/hgapp/deploy/cryptoHelper.js local QvniPXziBGknU539eJJXkk73Qu20ylShK+ZezK31NAbqPbAg
// if no password is supplied and it's local, then it will try to use process.env.CRYPTO_PASSWORD
// or the alternate way to decrypt a local user token would be
//    CRYPTO_PASSWORD=myPassword node projects/hgapp/deploy/cryptoHelper.js local QvniPXziBGknU539eJJXkk73Qu20ylShK+ZezK31NAbqPbAg

async.waterfall([
    function (wcb) {
        if (!environment || !userToken) {
            return wcb('missing parameters');
        }
        wcb();
    },
    function (wcb) {
        if (!cryptoPassword && environment !== 'local') {
            console.log('reading crypto password');
            exec('heroku config:get CRYPTO_PASSWORD --app hgn' + environment, function (err, key) {
                if (err) {
                    return wcb(err);
                }
                if (!key) {
                    return wcb('CRYPTO_PASSWORD missing!');
                }
                process.env.CRYPTO_PASSWORD = key.replace('\n', '');
                wcb();
            });
        } else if (!process.env.CRYPTO_PASSWORD) {
            process.env.CRYPTO_PASSWORD = cryptoPassword;
            wcb();
        } else {
            wcb();
        }
    },
    function (wcb) {
        var cryptoHelper;
        keystore.CryptoPassword = process.env.CRYPTO_PASSWORD;
        cryptoHelper = require('../hgnode/helpers/cryptoHelper.js');
        console.log(cryptoHelper.decrypt(new Buffer(userToken, 'base64')).toString());
        wcb();
    }
], function (err) {
    if (err) {
        console.log(err);
        return process.exit(1);
    }
    process.exit(0);
});
