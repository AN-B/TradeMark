#!/usr/bin/env bash

servers=( "avatar" "borg" "cylon" "demo" "poc" "qa" "ripley" "scully" "st" "trinity" "tron" "uat" "prod" )
types=( "api" "esb" "mo" "n" )
username="$1"

if [[ $username != "" ]]; then
    for s in "${servers[@]}"
    do
        for t in "${types[@]}"
        do
            #echo heroku access:remove $username --app hg$t$s
            heroku access:remove $username --app hg$t$s
        done
    done
else
    echo "username missing"
fi
