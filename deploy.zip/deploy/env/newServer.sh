#!/bin/bash

# this script will stand up a new environment
# newServer.sh [NAME_OF_NEW_SERVER] --> newServer.sh ripley
# leaving the second parameter blank will create all 4 servers: web, mobile, api, esb
# adding a second parameter will only install those specified (comma delimited list, no spaces): newServer.sh ripley api,esb
# second parameter list: web,mobile,api,esb

if [[ "$1" = "" ]]; then
    echo "Error: Missing server name."
    exit 0
fi

while true; do
    read -p "Are you sure you want to stand up new server(s) called "$1" (Yes or No)? " yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit 0;;
        * ) echo "Please answer Yes or No.";;
    esac
done

herokuWeb=""
herokuMobile=""
herokuApi=""
herokuEsb=""

if [ "$2" ]
then
    IFS=',' read -a settings <<< $2
    for element in ${settings[@]}
    do
        case $element in
            "web")
                herokuWeb="hgn"$1
            ;;
            "mobile")
                herokuMobile="hgmo"$1
            ;;
            "api")
                herokuApi="hgapi"$1
            ;;
            "esb")
                herokuEsb="hgesb"$1
            ;;
        esac
    done
else
    herokuWeb="hgn"$1
    herokuMobile="hgmo"$1
    herokuApi="hgapi"$1
    herokuEsb="hgesb"$1
fi

if [[ $herokuWeb != "" ]]; then
    echo "Creating "$herokuWeb" server..."
    heroku apps:create $herokuWeb
fi

if [[ $herokuMobile != "" ]]; then
    echo "Creating "$herokuMobile" server..."
fi

if [[ $herokuApi != "" ]]; then
    echo "Creating "$herokuApi" server..."
fi

if [[ $herokuEsb != "" ]]; then
    echo "Creating "$herokuEsb" server..."
fi
