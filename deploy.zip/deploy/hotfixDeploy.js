// run this script using nodemon while watching the deploy directory
// nodemon --watch projects/hgapp/deploy projects/hgapp/deploy/hotfixDeploy.js
var CronJob = require('cron').CronJob,
    exec = require('child_process').exec,
    days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'],
    arg = process.argv[2] || 'sun',
    hour = process.argv[3] || '23',
    day = days.indexOf(arg.toLowerCase());

function deployDemo() {
    console.log('Deploying to demo environment...');
    exec('/bin/sh ~/projects/hgapp/deploy/hgndeploy.sh demo projects ccf=yes,srr=yes,rnm=no,rut=no,bcc=yes,rds=yes,uhc=yes,uev=yes,rdm=yes,srn=no');
    console.log('Done.');
}

function deployProd() {
    console.log('Deploying to production environment...');
    exec('/bin/sh ~/projects/hgapp/deploy/hgndeploy.sh prod projects ccf=yes,srr=yes,rnm=no,rut=no,bcc=yes,rds=yes,uhc=yes,uev=yes,rdm=yes,srn=yes');
    console.log('Done.');
}

// this script does a final git pull 5 minutes before deployment, just in case we need to switch off the deployment
// any changes will restart this script
function finalScriptCheck() {
    console.log('Checking if there are any final script changes before the deploy...');
    exec('cd ~/projects/hgapp');
    exec('git pull');
    exec('cd ~');
    console.log('Done.');
}

// run script check job at 5 minutes before deployment
console.log('Setting git pull job on ' + days[day].toUpperCase() + ' @ 00 25 ' + hour + '...');
new CronJob(
    '00 25 ' + hour + ' * * ' + day.toString(),
    finalScriptCheck,
    function () {
        console.log('Git pull completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');

// run demo deployment job at exactly the half hour mark
console.log('Setting deployment job for demo on ' + days[day].toUpperCase() + ' @ 00 30 ' + hour + '...');
new CronJob(
    '00 30 ' + hour + ' * * ' + day.toString(),
    deployDemo,
    function () {
        console.log('Deployment to demo completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');

// run production deployment job 5 minutes after the demo deploy
console.log('Setting deployment job for prod on ' + days[day].toUpperCase() + ' @ 00 35 ' + hour + '...');
new CronJob(
    '00 35 ' + hour + ' * * ' + day.toString(),
    deployProd,
    function () {
        console.log('Deployment to prod completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');
