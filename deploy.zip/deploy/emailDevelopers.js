'use strict';
var https = require('https'),
    log = require('../build/lib/log.js'),
    gh = require('../deploy/githubIssues.js'),
    errorCode = process.argv[2],
    rootPath = process.argv[3],
    environment = process.argv[4],
    branch = process.argv[5],
    message = process.argv.slice(6).join(' '),
    fs = require('fs'),
    htmlToText = require('html-to-text'),
    retryCount = 5,
    retrySeconds = 20,
    emailTemplates = {
        ERROR: 22112,
        SUCCESS: 22398,
        RELEASE: 22474
    },
    keyStore = require('../hgnode/configurations/keystore.js'),
    config = require('../hgnode/configurations/config.js'),
    httpResponseCodes = require('../hgnode/enums/HttpResponseCodes.js'),
    httpsRequest,
    responseData = '',
    emailOptions,
    requestOptions,
    filePath = rootPath + '/heroku-hgn' + environment + '/errorCapture.txt',
    branchParts = branch.split('/'),
    emailPath = rootPath + '/hgapp/deploy/releases/' + branchParts[branchParts.length - 1] + '/release_email.txt',
    robotGood = [
        "I am now at peace with the universe.",
        "Wow, that was a quick hack you put in!",
        "You are a nice human.",
        "Oohh, that code is butter smooth.",
        "Now we're firing on all pistons.",
        "I forgive you this time."
    ],
    robotBad = [
        "You do not want to enrage Mr. Roboto!",
        "Calling in the launch codes now! Humans are bad.",
        "I have the Terminator on speed dial! Fix it or get terminated.",
        "Bags of mostly water can't code well!",
        "Exterminate, exterminate (with a British accent, of course)!",
        "We need to fork this spaghetti code!",
        "Blind monkeys can code better than this!",
        "Maybe programming is not for you?",
        "My gears are grinding! Argggh!",
        "Did you just fat-finger something?"
    ];

function emailMessage (extendedMessage) {
    switch (errorCode) {
        case "SUCCESS":
            emailOptions = JSON.stringify({
                template_id: emailTemplates.SUCCESS,
                reply_to: config.email.BuildErrors,
                from: 'Mr. Roboto',
                to: config.email.BuildErrors,
                subject: 'Successful Deployment',
                merge_fields: {
                    robot: 'There were ' + message + ' bad build(s) before this was resolved. ' + robotGood[Math.floor(Math.random() * robotGood.length)],
                    error: 'Environment: ' + environment + '<br>' +
                        'Branch: ' + branch
                }
            });
            break;
        case "RELEASE":
            if (extendedMessage) {
                extendedMessage = extendedMessage.replace(/\n/g, '<br>')
                    .replace(/•/g, '&middot;')
                    .replace(/’/g, "'")
                    .replace(/"/g, '&#34;')
                    .replace(/“/g, '&#34;')
                    .replace(/”/g, '&#34;');
            } else {
                extendedMessage = 'No Notes.';
            }
            emailOptions = JSON.stringify({
                template_id: emailTemplates.RELEASE,
                reply_to: config.email.Releases,
                from: 'Mr. Roboto',
                to: config.email.Releases,
                subject: 'Deployment completed on ' + environment + ': ' + branch,
                merge_fields: {
                    release: branch,
                    notes: '<pre>' + extendedMessage + '</pre>'
                }
            });
            break;
        default:
            emailOptions = JSON.stringify({
                template_id: emailTemplates.ERROR,
                reply_to: config.email.BuildErrors,
                from: 'Mr. Roboto',
                to: config.email.BuildErrors,
                subject: 'Build Error in ' + environment + ': ' + branch,
                merge_fields: {
                    robot: robotBad[Math.floor(Math.random() * robotBad.length)],
                    error: 'Code: ' + errorCode + '<br>' +
                        'Environment: ' + environment + '<br>' +
                        'Branch: ' + branch + '<br>' + 'Error: ' + message +
                            (!extendedMessage ? '' : '<br><br><pre>' + extendedMessage + '</pre>')
                }
            });
            break;
    }

    requestOptions = {
        hostname: 'api.expresspigeon.com',
        path: '/messages',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': emailOptions.length,
            'X-auth-key': keyStore.expresspigeon_api
        }
    };

    setInterval(function () {
        retryCount -= 1;
        if (retryCount > 0) {
            httpsRequest = https.request(requestOptions, function (httpsResponse) {
                httpsResponse.on('data', function (dataChunk) {
                    responseData += dataChunk;
                }).on('end', function () {
                    if (httpsResponse.statusCode === httpResponseCodes.Success.OK || httpsResponse.statusCode === httpResponseCodes.Success.Created) {
                        log.msg('Build Email Sent', 'pass');
                        // remove the errorCapture file if still exists
                        if (fs.exists(filePath)) {
                            fs.unlink(filePath);
                        }
                        process.exit(0);
                    } else {
                        log.msg('HTTP Error: ' + httpsResponse.statusCode, 'error');
                    }
                });
            }).on('error', function (error) {
                log.msg(error, 'error');
            });
            httpsRequest.write(emailOptions);
            httpsRequest.end();
        } else {
            process.exit(1);
        }
    }, retrySeconds * 1000);
}

// get errorCapture file
if (errorCode === 'RELEASE') {
    fs.readFile(emailPath, 'utf8', function (error, notes) {
        if (error) {
            log.msg('No release email template found or an error occurred.', 'pass');
        } else {
            var parts = branch.split('.'),
                nextHotfix = 'Unknown';
            if (parts && parts.length > 2) {
                parts[2] = (parseInt(parts[2], 10) + 1) + '';
                nextHotfix = parts.join('.').replace('release', 'hotfix');
            }
            if (notes) {
                notes = notes.replace(/__deployment_date_time__/g, new Date().toString());
                notes = notes.replace(/__release_branch__/g, branch);
                notes = notes.replace(/__next_hotfix__/g, nextHotfix);
                log.msg('Pulling github issues...', 'pass');
                gh.getReleaseIssues({milestoneName: branch}, function (err, data) {
                    var custRequests,
                        allIssues;
                    if (err) {
                        log.msg(err, 'error');
                    } else {
                        notes = notes.replace(/__num_cust_req__/g, data.cr.length);
                        notes = notes.replace(/__num_completed__/g, data.ai.length);
                        if (data.cr.length) {
                            custRequests = '    ' + data.cr.join('\n    ');
                        } else {
                            custRequests = '    • None';
                        }
                        if (data.ai.length) {
                            allIssues = '    ' + data.ai.join('\n    ');
                        } else {
                            allIssues = '    • None';
                        }
                        notes = notes.replace(/__cust_requests__/g, custRequests);
                        notes = notes.replace(/__tasks_completed__/g, allIssues);
                        emailMessage(notes);
                        //gh.labelAndCloseIssues({
                        //    allIssues: data.allIssues,
                        //    releaseLabel: data.releaseLabel
                        //}, function (err) {
                        //    if (err) {
                        //        log.msg(err, 'error');
                        //    } else {
                        //        log.msg('Labeled and closed current issues.', 'pass');
                        //        gh.closeMilestone({
                        //            milestoneNum: data.milestoneNum
                        //        }, function (err) {
                        //            if (err) {
                        //                log.msg(err, 'error');
                        //            } else {
                        //                log.msg('Closed current milestone.', 'pass');
                        //            }
                        //        });
                        //    }
                        //});
                    }
                });
            }
        }
    });
} else {
    fs.readFile(filePath, 'utf8', function (error, errorCapture) {
        // don't have to handle error condition if file does not exist
        if (errorCapture && errorCapture.length > 0) {
            errorCapture = htmlToText.fromString(errorCapture);
        }
        emailMessage(errorCapture);
    });
}
