#!/bin/bash
exit

# backup old qa db
mongodump -h dbh55.mongolab.com:27557 -d hgcommon -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds043487.mongolab.com:43487 -d hgsecurity -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds031627.mongolab.com:31627 -d hgthanka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds043487.mongolab.com:43487 -d hgperka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds031627.mongolab.com:31627 -d hgfinance -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035438.mongolab.com:35438 -d hgperform -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds053148.mongolab.com:53148 -d hgreports -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds031877.mongolab.com:31877 -d hglog -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/

# backup old uat db
mongodump -h ds061747.mongolab.com:61747 -d hgcommon -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/
mongodump -h ds061767.mongolab.com:61767 -d hgsecurity -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/
mongodump -h ds061747.mongolab.com:61747 -d hgthanka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/
mongodump -h ds061787.mongolab.com:61787 -d hgperka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/
mongodump -h ds061767.mongolab.com:61767 -d hgfinance -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035488.mongolab.com:35488 -d hgperform -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/
mongodump -h ds053148.mongolab.com:53148 -d hg-reports -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/
mongodump -h ds061777.mongolab.com:61777 -d hglog -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/uat/

# backup new uat db
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hgcommon -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hgsecurity -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hgthanka -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hgperka -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hgfinance -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hgperform -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hgreports -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/
mongodump -h ds035268-a1.mongolab.com:35268 -d uat-hglog -u hguatuser -p t0m4ndj3rrY! -o /Users/tuance/projects/backup/uat/

# backup old demo db
mongodump -h ds037097.mongolab.com:37097 -d hgcommon -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/
mongodump -h ds045137.mongolab.com:45137 -d hgsecurity -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/
mongodump -h dbh73.mongolab.com:27737 -d hgthanka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/
mongodump -h ds031847.mongolab.com:31847 -d hgperka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/
mongodump -h ds037077.mongolab.com:37077 -d hgfinance -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035358.mongolab.com:35358 -d hgperform -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/
mongodump -h ds053158.mongolab.com:53158 -d hg-reports -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035897.mongolab.com:35897 -d hglog -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/demo/

# backup new demo db
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hgcommon -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hgsecurity -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hgthanka -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hgperka -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hgfinance -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hgperform -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hgreports -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/
mongodump -h ds035268-a1.mongolab.com:35268 -d demo-hglog -u hgdemouser -p n16ht0f4h3l1v1ngD3ad! -o /Users/tuance/projects/backup/demo/

# backup new uat db for poc
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hgcommon -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hgsecurity -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hgthanka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hgperka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hgfinance -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hgperform -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hgreports -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/
mongodump -h ds035268-a0.mongolab.com:35268 -d uat-hglog -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/poc/

# backup qa for development
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hgcommon -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hgsecurity -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hgthanka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hgperka -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hgfinance -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hgperform -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hgreports -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/
mongodump -h ds035268-a0.mongolab.com:35268 -d qa-hglog -u hgdevuser -p h164gr0und! -o /Users/tuance/projects/backup/qa/

# restore qa
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hgcommon -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hgcommon
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hgsecurity -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hgsecurity
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hgthanka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hgthanka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hgperka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hgperka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hgfinance -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hgfinance
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hgperform -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hgperform
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hgreports -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hgreports
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d qa-hglog -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/qa/hglog

# restore uat
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hgcommon -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hgcommon
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hgsecurity -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hgsecurity
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hgthanka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hgthanka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hgperka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hgperka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hgfinance -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hgfinance
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hgperform -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hgperform
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hgreports -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hg-reports
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d uat-hglog -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/uat/hglog

# restore demo
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hgcommon -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hgcommon
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hgsecurity -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hgsecurity
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hgthanka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hgthanka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hgperka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hgperka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hgfinance -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hgfinance
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hgperform -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hgperform
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hgreports -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hg-reports
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d demo-hglog -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/demo/hglog

# restore poc
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hgcommon -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hgcommon
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hgsecurity -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hgsecurity
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hgthanka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hgthanka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hgperka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hgperka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hgfinance -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hgfinance
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hgperform -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hgperform
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hgreports -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hgreports
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d poc-hglog -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/poc/uat-hglog

# restore st
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hgcommon -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hgcommon
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hgsecurity -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hgsecurity
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hgthanka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hgthanka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hgperka -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hgperka
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hgfinance -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hgfinance
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hgperform -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hgperform
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hgreports -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hgreports
mongorestore --drop -h ds035268-a0.mongolab.com:35268 -d st-hglog -u hgdevuser -p h164gr0und! /Users/tuance/projects/backup/st/hglog

#restore poc > local
mongorestore --drop -h localhost -d hgcommon /Users/tuance/projects/backup/poc/hgcommon
mongorestore --drop -h localhost -d hgsecurity /Users/tuance/projects/backup/poc/hgsecurity
mongorestore --drop -h localhost -d hgthanka /Users/tuance/projects/backup/poc/hgthanka
mongorestore --drop -h localhost -d hgperka /Users/tuance/projects/backup/poc/hgperka
mongorestore --drop -h localhost -d hgfinance /Users/tuance/projects/backup/poc/hgfinance
mongorestore --drop -h localhost -d hgperform /Users/tuance/projects/backup/poc/hgperform
mongorestore --drop -h localhost -d hgreports /Users/tuance/projects/backup/poc/hgreports
mongorestore --drop -h localhost -d hglog /Users/tuance/projects/backup/poc/hglog

# restore borg
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hgcommon -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgcommon
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hgsecurity -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgsecurity
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hgthanka -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgthanka
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hgperka -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgperka
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hgfinance -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgfinance
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hgperform -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgperform
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hgreports -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hg-reports
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d borg-hglog -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hglog

# restore cylon
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hgcommon -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgcommon
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hgsecurity -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgsecurity
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hgthanka -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgthanka
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hgperka -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgperka
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hgfinance -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgfinance
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hgperform -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hgperform
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hgreports -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hg-reports
mongorestore --drop -h ds035268-a1.mongolab.com:35268 -d cylon-hglog -u hgqauser -p highground /Users/tuance/projects/backup/uat/uat-hglog
