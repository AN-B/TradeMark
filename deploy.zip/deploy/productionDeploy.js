// run this script using nodemon while watching the deploy directory
// nodemon --watch projects/hgapp/deploy projects/hgapp/deploy/productionDeploy.js
var CronJob = require('cron').CronJob,
    exec = require('child_process').exec;

function deployDemo() {
    console.log('Deploying to demo environment...');
    exec('/bin/sh ~/projects/hgapp/deploy/hgndeploy.sh demo projects ccf=yes,srr=no,rnm=no,rut=no,bcc=yes,rds=yes,uhc=yes,uev=yes,rdm=yes,srn=no');
    console.log('Done.');
}

function deployProd() {
    console.log('Deploying to production environment...');
    exec('/bin/sh ~/projects/hgapp/deploy/hgndeploy.sh prod projects ccf=yes,srr=no,rnm=no,rut=no,bcc=yes,rds=yes,uhc=yes,uev=yes,rdm=yes,srn=yes');
    console.log('Done.');
}

// this script does a final git pull 5 minutes before deployment, just in case we need to switch off the deployment
// any changes will restart this script
function finalScriptCheck() {
    console.log('Checking if there are any final script changes before the deploy...');
    exec('cd ~/projects/hgapp');
    exec('git pull');
    exec('cd ~');
    console.log('Done.');
}

// run script check job every Thursday at 10:25PM
console.log('Setting git pull job...');
new CronJob(
    '00 25 22 * * 4',
    finalScriptCheck,
    function () {
        console.log('Git pull completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');

// run demo deployment job every Thursday at 10:30PM
console.log('Setting deployment job for demo...');
new CronJob(
    '00 30 22 * * 4',
    deployDemo,
    function () {
        console.log('Deployment to demo completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');

// run prod deployment job every Thursday at 10:35PM
console.log('Setting deployment job for prod...');
new CronJob(
    '00 35 22 * * 4',
    deployProd,
    function () {
        console.log('Deployment to production completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');
