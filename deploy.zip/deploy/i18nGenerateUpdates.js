'use strict';
/* HOW TO USE THIS SCRIPT

   To find missing translations and keys from the translated file:
      node projects/hgapp/deploy/i18nGenerateUpdates.js ~/projects/hgapp/static/templates/i18n/en.json ~/projects/hgapp/static/templates/i18n/pt-br.json -m

   To find updated translations or added keys from a previous file:
      node projects/hgapp/deploy/i18nGenerateUpdates.js ~/projects/hgapp/static/templates/i18n/current-en.json ~/projects/hgapp/static/templates/i18n/previous-en.json -u

   To find deleted translations, reverse the order of the files (with the translated file first and the english file second with a -d mode switch):
      node projects/hgapp/deploy/i18nGenerateUpdates.js ~/projects/hgapp/static/templates/i18n/pt-br.json ~/projects/hgapp/static/templates/i18n/en.json -d

   To merge/stitch two files together:
      node projects/hgapp/deploy/i18nGenerateUpdates.js ~/Desktop/langcompare/pt-br.json ~/Desktop/langcompare/updated-1452809986052.json -s

   To remove deleted keys (use the "deleted-" file as the source:
      node projects/hgapp/deploy/i18nGenerateUpdates.js ~/Desktop/langcompare/deleted-1452809986052.json ~/Desktop/langcompare/pt-br.json -r

   To export a pipe delimited file of English and the equivalent translated value of the language:
      node projects/hgapp/deploy/i18nGenerateUpdates.js ~/Desktop/langcompare/en.json ~/Desktop/langcompare/pt-br.json -e

   -m = missing, -u = update, -d = deleted, -s = stitch, -r = remove, -e = export

   An exclusion file can be added as the last argument to ignore words that are identical between languages (should only be used with -m and -u modes)
      node projects/hgapp/deploy/i18nGenerateUpdates.js ~/Desktop/clients/allianz/en.json ~/Desktop/clients/allianz/pt-br.json -m ~/Desktop/clients/allianz/pt-br-exclude.json

   Requires the "deep-merge" node module

   An example for a full update would run through this scenario:
    1. Recieve an updated file from GPI
    2. Find any missing translations on the GPI file by running the GPI file against the update file (-m)
    3. Report missing translastions to GPI, if any and return to step 1
    4. Stitch this updated GPI file into the current language file in the repos (-s)
    5. Find any missing ones using the current English file against the stitched file (-m)
    6. If any missing ones found, send to GPI and return to step 1
    7. Find any updated ones using the current English file against the stitched file (-u)
    8. If any updates found, send to GPI and return to step 1
    9. Find any deleted ones using the current English file agianst the stitched file (-d)
   10. Run the deleted file against the stitched file to remove any old keys (-r)
   11. Check in the new GPI file to the repos for the current release cycle
   12. Repeat this process on every language file

   TODO: automate the steps above

 */

var source = process.argv[2],
    dest = process.argv[3],
    mode = process.argv[4],
    exclude = process.argv[5],
    sourceJson,
    destJson,
    excludeJson,
    i18n = {},
    filePath,
    emptyExists = true,
    modeMap = {
        "-m": "missing-",
        "-u": "updated-",
        "-d": "deleted-",
        "-s": "stitched-",
        "-r": "removed-",
        "-e": "export-"
    },
    removeFlag = '(removed-by-script)',
    removedCount,
    fs = require('fs'),
    DeepMerge = require("deep-merge"),
    merge = new DeepMerge(function mergeStrategy(target, source) {
        return target;
    });

// force require to not cache the json files, otherwise it will not flush the file contents when it changes
function requireUncached(module) {
    delete require.cache[require.resolve(module)];
    return require(module);
}

if (!source || !dest|| !mode) {
    console.log("Parameters are required: source, destination, mode");
    process.exit(1);
}

if (!modeMap[mode]) {
    console.log("Invalid mode:", mode, ", Valid modes:", Object.keys(modeMap).join(', '));
    process.exit(2);
}

sourceJson = requireUncached(source);
destJson = requireUncached(dest);
if (exclude) {
    excludeJson = requireUncached(exclude);
}

if (!sourceJson || !destJson || !Object.keys(sourceJson).length || !Object.keys(destJson).length) {
    console.log("Source and/or destination file is empty!");
    process.exit(3);
}

function convertFlatToObject(obj, key, value) {
    var parts = key.split('.'),
        len = parts.length,
        i;
    if (len === 1) {
        obj[key] = value;
    } else {
        for (i = 0; i < len; i += 1) {
            if (i === len - 1) {
                obj[parts[i]] = value;
            } else {
                obj = obj[parts[i]] = obj[parts[i]] || {};
            }
        }
    }
}

function checkMissingUpdatedKeys(objA, objB, mapRoot, result, mode) {
    var keys = Object.keys(objA),
        i,
        len,
        count = 0;
    for (i = 0, len = keys.length; i < len; i += 1) {
        if (!objB) {
            if (typeof objA[keys[i]] === 'object') {
                count += checkMissingUpdatedKeys(objA[keys[i]], null, mapRoot + keys[i] + '.', result, mode);
            } else {
                count += 1;
                convertFlatToObject(result, mapRoot + keys[i], objA[keys[i]]);
            }
        } else if (typeof objA[keys[i]] === 'object') {
            count += checkMissingUpdatedKeys(objA[keys[i]], objB[keys[i]], mapRoot + keys[i] + '.', result, mode);
        } else if (mode === '-u') {
            if (objA[keys[i]] !== objB[keys[i]]) {
                count += 1;
                convertFlatToObject(result, mapRoot + keys[i], objA[keys[i]]);
            }
        } else if (mode === '-m' && (objA[keys[i]] === objB[keys[i]] || !objB[keys[i]])) {
            count += 1;
            convertFlatToObject(result, mapRoot + keys[i], objA[keys[i]]);
        } else if (mode === '-d' && !objB[keys[i]]) {
            count += 1;
            convertFlatToObject(result, mapRoot + keys[i], objA[keys[i]]);
        }
    }
    return count;
}

function replaceValues(obj, val) {
    var keys = Object.keys(obj),
        i,
        len = keys.length;
    for (i = 0; i < len; i += 1) {
        if (typeof obj[keys[i]] === 'object') {
            replaceValues(obj[keys[i]], val);
        } else {
            obj[keys[i]] = val;
        }
    }
}

function removeKeys(obj) {
    var keys = Object.keys(obj),
        i,
        len = keys.length,
        count = 0;
    for (i = 0; i < len; i += 1) {
        if (typeof obj[keys[i]] === 'object') {
            count += removeKeys(obj[keys[i]]);
        } else if (obj[keys[i]] === removeFlag) {
            count += 1;
            delete obj[keys[i]];
        }
    }
    return count;
}

function removeEmptyObjects(obj) {
    var keys = Object.keys(obj),
        i,
        len = keys.length;
    for (i = 0; i < len; i += 1) {
        if (typeof obj[keys[i]] === 'object') {
            if (!Object.keys(obj[keys[i]]).length) {
                delete obj[keys[i]];
                emptyExists = true;
            } else {
                removeEmptyObjects(obj[keys[i]]);
            }
        }
    }
}

function exportData(s, d) {
    var ret = '',
        sflat = {},
        dflat = {},
        flatten = function (obj, flat, keydot) {
            Object.keys(obj).forEach(function (key) {
                if (typeof obj[key] === 'object') {
                    keydot.push(key);
                    flatten(obj[key], flat, keydot);
                } else {
                    flat[keydot.concat([key]).join('.')] = obj[key];
                }
            });
            if (keydot.length) {
                keydot.pop();
            }
        };
    flatten(s, sflat, []);
    flatten(d, dflat, []);
    Object.keys(dflat).forEach(function (key) {
        if (sflat[key]) {
            ret += sflat[key] + '|' + dflat[key] + '\n';
        }
    });
    return ret;
}

// use the source path to build the new file path
filePath = source.split('/');
filePath.pop();
filePath.push(modeMap[mode] + Date.now() + (mode === '-e' ? '.txt' : '.json'));
filePath = filePath.join('/');

if (mode === '-s') {
    destJson = merge(destJson, sourceJson);
    fs.writeFileSync(filePath, JSON.stringify(destJson, null, 4));
} else if (mode === '-r') {
    // replace the values with a dummy value
    replaceValues(sourceJson, removeFlag);
    destJson = merge(sourceJson, destJson);
    // remove the keys that should be deleted
    removeKeys(destJson);
    fs.writeFileSync(filePath, JSON.stringify(destJson, null, 4));
} else if (mode === '-e') {
    fs.writeFileSync(filePath, exportData(sourceJson, destJson));
} else {
    console.log('Found:', checkMissingUpdatedKeys(sourceJson, destJson, '', i18n, mode), 'keys');
    if (excludeJson) {
        replaceValues(excludeJson, removeFlag);
        i18n = merge(excludeJson, i18n);
        removedCount = removeKeys(i18n);
        if (removedCount) {
            console.log('Pruned:', removedCount, 'keys');
        }
        while (emptyExists) {
            emptyExists = false;
            removeEmptyObjects(i18n);
        }
    }
    fs.writeFileSync(filePath, JSON.stringify(i18n, null, 4));
}

console.log('File:', filePath);
