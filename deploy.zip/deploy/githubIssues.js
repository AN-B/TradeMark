var async = require('async'),
    GitHubApi = require('github'),
    github = new GitHubApi({
        version: '3.0.0',
        protocol: 'https'
    });

github.authenticate({
    type: "oauth",
    token: process.env.GITHUB_TOKEN
});

function getAllItems (action, callback) {
    var allItems = [],
        lastResponse;
    async.doWhilst(
        function (callback) {
            action.cmd(action.params, function (err, data) {
                if (err) {
                    callback('Error getting items: ' + err);
                } else {
                    allItems = allItems.concat(data);
                    lastResponse = data;
                    action.params.page += 1;
                    callback();
                }
            });
        },
        function () {
            return github.hasNextPage(lastResponse);
        },
        function (err) {
            if (err) {
                callback(err);
            } else {
                callback(null, allItems);
            }
        }
    );
};

function getReleaseIssues(params, callback) {
    getAllItems({
        cmd: github.issues.getAllMilestones,
        params: {
            user: 'HighGroundInc',
            repo: 'hgapp',
            filter: 'all',
            state: 'open',
            per_page: 100,
            page: 1
        }
    }, function (error, allMilestones) {
        var theMilestone;
        if (error) {
            callback(error);
        } else if (allMilestones) {
            theMilestone = allMilestones.filter(function(milestone) {
                return milestone.title === params.milestoneName;
            });
            if (theMilestone && theMilestone.length === 1) {
                getAllItems({
                    cmd: github.issues.repoIssues,
                    params: {
                        user: 'HighGroundInc',
                        repo: 'hgapp',
                        filter: 'all',
                        state: 'open',
                        milestone: theMilestone[0].number,
                        per_page: 100,
                        page: 1
                    }
                }, function (error, allIssues) {
                    if (error) {
                        callback(error);
                    } else if (allIssues) {
                        getAllItems({
                            cmd: github.issues.getLabels,
                            params: {
                                user: 'HighGroundInc',
                                repo: 'hgapp',
                                filter: 'all',
                                per_page: 100,
                                page: 1
                            }
                        }, function (error, labels) {
                            var customerRequests,
                                issueTitles,
                                releaseLabel;
                            if (error) {
                                callback(error);
                            } else if (labels) {
                                releaseLabel = labels.filter(function (label) {
                                    return label.name === '-RELEASED-';
                                });
                                allIssues = allIssues.sort(function (a, b) {
                                    return a.number - b.number;
                                });
                                // gather the customer requests
                                customerRequests = allIssues.filter(function (issue) {
                                    return issue.labels.filter(function (label) {
                                            return label.name === '-CUST REQ-';
                                        }).length > 0;
                                });
                                customerRequests = customerRequests.map(function (issue) {
                                    return ['#' + issue.number, issue.title].join(' ');
                                });
                                // gather all the issues
                                issueTitles = allIssues.map(function (issue) {
                                    return ['#' + issue.number, issue.title].join(' ');
                                });
                                callback(null, {
                                    cr: customerRequests,
                                    ai: issueTitles,
                                    allIssues: allIssues,
                                    releaseLabel: releaseLabel,
                                    milestoneNum: theMilestone[0].number
                                });
                            }
                        });
                    }
                });
            } else {
                callback('Error >>> Milestone (' + milestoneName + ') not found.');
            }
        }
    });
}

function labelAndCloseIssues(params, callback) {
    async.eachSeries(params.allIssues, function (issue, cb) {
        issue.labels.push(params.releaseLabel[0]);
        console.log(p);
        github.issues.edit({
            user: 'HighGroundInc',
            repo: 'hgapp',
            number: parseInt(issue.number, 10),
            labels: issue.labels.map(function (label) {
                return label.name;
            }),
            state: 'closed'
        }, function (error) {
            if (error) {
                cb(error);
            } else {
                cb();
            }
        });
    }, function(err) {
        if (err) {
            callback(err);
        } else {
            callback();
        }
    });
}

function closeMilestone(params, callback) {
    github.issues.updateMilestone({
        user: 'HighGroundInc',
        repo: 'hgapp',
        number: parseInt(params.milestoneNum, 10),
        state: 'closed'
    }, function (error, resp) {
        if (error) {
            callback(error);
        } else {
            callback(null, resp);
        }
    })
}

exports.getReleaseIssues = getReleaseIssues;
exports.labelAndCloseIssues = labelAndCloseIssues;
exports.closeMilestone = closeMilestone;
