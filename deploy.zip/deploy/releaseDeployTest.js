// run this script using nodemon while watching the deploy directory
// nodemon --watch projects/hgapp/deploy projects/hgapp/deploy/releaseDeployTest.js
var CronJob = require('cron').CronJob,
    exec = require('child_process').exec,
    days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'],
    arg = process.argv[2] || 'sun',
    hour = process.argv[3] || '23',
    minute = process.argv[4] || '25',
    day = days.indexOf(arg.toLowerCase()),
    chronA = ['00', minute, hour, '* *', day].join(' '),
    chronB = ['00', (parseInt(minute, 10) + 2).toString(), hour, '* *', day].join(' ');

function deployTest() {
    console.log('Deploying to dev environment...');
    exec('/bin/sh ~/projects/hgapp/deploy/hgndeploy.sh dev projects ccf=yes,srr=yes,rnm=no,rut=no,bcc=yes,rds=yes,uhc=yes,uev=yes,rdm=no,srn=no');
    console.log('Done.');
}

// this script does a final git pull 5 minutes before deployment, just in case we need to switch off the deployment
// any changes will restart this script
function finalScriptCheck() {
    console.log('Checking if there are any final script changes before the deploy...');
    exec('cd ~/projects/hgapp');
    exec('git pull');
    exec('cd ~');
    console.log('Done.');
}

// run script check job at 5 minutes before deployment
console.log('Setting git pull job on ' + chronA + '...');
new CronJob(
    chronA,
    finalScriptCheck,
    function () {
        console.log('Git pull completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');

// run dev deployment job at exactly the half hour mark
console.log('Setting deployment job for dev on ' + chronB + '...');
new CronJob(
    chronB,
    deployTest,
    function () {
        console.log('Deployment to dev completed.');
    },
    true,
    'America/Chicago'
);
console.log('Done.');
