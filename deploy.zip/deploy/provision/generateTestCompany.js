/*jslint node:true es5:true*/
'use strict';

var nameDoc = require('./names.js'),
    rl = require('readline'),
    prompts = rl.createInterface(process.stdin, process.stdout),
    fnCount = nameDoc.firstNames.length,
    lnCount = nameDoc.lastNames.length;

function generateNames(params) {
    var i,
        fullName,
        nameCheck = [],
        nameArray = [],
        fName,
        lName,
        num = parseInt(params.num, 10);
    for (i = 0; i < num; i += 1) {
        fName = nameDoc.firstNames[Math.floor(Math.random() * fnCount)];
        lName = nameDoc.lastNames[Math.floor(Math.random() * lnCount)];
        fullName = fName + ' ' + lName;
        if (nameCheck.indexOf(fullName) === -1) {
            nameCheck.push(fullName);
            nameArray.push({
                first: fName,
                last: lName,
                domain: fName.substring(0, 1).toLowerCase() + lName.toLowerCase() + "@" + params.dom.toLowerCase()
            });
        } else {
            // instead of using another loop, increment the threshold if a dupe is found
            num += 1;
        }
    }
    //console.log(nameCheck);
    return nameArray.sort(function (a, b) {
        return a.last < b.last ? -1 : 1;
    });
}

console.log('\nGenerate Test Company Utility\n');

prompts.question('How many users? ', function (numUsers) {
    prompts.question('Domain name? ', function (domain) {
        var users = generateNames({
            num: numUsers,
            dom: domain
        });
        console.log(users.length);
        console.log(users);
        process.exit();
    });
});

//console.log(generateNames(20000).length);
