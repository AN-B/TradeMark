/*jslint node:true es5:true*/
'use strict';

var departments = [
        {
            name: 'Accounting',
            positions: [
                'CFO',
                'VP Finance',
                'Accountant'
            ]
        },
        {
            name: 'Marketing',
            positions: [
                'CMO',
                'VP Marketing',
                'Marketing Director',
                'Staff Writer',
                'Illustrator'
            ]
        },
        {
            name: 'Human Resources',
            positions: [
                'CHRO',
                'VP Staffing',
                'Senior Recruiter',
                'Recruiter'
            ]
        },
        {
            name: 'Sales',
            positions: [
                'SVP Sales',
                'VP Sales',
                'Sales Representative',
                'Sales Manager',
                'Business Development'
            ]
        },
        {
            name: 'Product Development',
            positions: [
                'Director of Product',
                'Project Manager',
                'Senior Business Analyst',
                'Business Analyst'
            ]
        },
        {
            name: 'Engineering',
            positions: [
                'CTO',
                'CIO',
                'SVP Engineering',
                'VP Engineering',
                'Senior Architect',
                'Senior Developer',
                'Software Developer',
                'DevOps Manager',
                'Development Manager',
                'DevOps Tech'
            ]
        },
        {
            name: 'Quality Assurance',
            positions: [
                'QA Director',
                'QA Manager',
                'QA Tech'
            ]
        },
        {
            name: 'Design',
            positions: [
                'Art Director',
                'UX Architect',
                'UX Developer',
                'UI Architect',
                'UI Developer',
                'Illustrator'
            ]
        },
        {
            name: 'Administration',
            positions: [
                'Admin Director',
                'Receptionist',
                'Executive Assistant',
                'Purchasing Agent'
            ]
        },
        {
            name: 'Custom Success',
            positions: [
                'Account Representative',
                'Account Manager',
                'Account Support'
            ]
        },
        {
            name: 'Executives',
            positions: [
                'CEO',
                'COO'
            ]
        }
    ],
    locations = [
        'New York',
        'Chicago',
        'Houston',
        'Philadelphia',
        'Phoenix',
        'San Antonio',
        'San Diego',
        'Dallas',
        'San Jose',
        'Austin',
        'Jacksonville',
        'San Francisco',
        'Indianapolis',
        'Columbus',
        'Fort Worth',
        'Charlotte',
        'Detroit',
        'El Paso',
        'Seattle',
        'Denver',
        'Washington',
        'Memphis',
        'Boston',
        'Nashville',
        'Baltimore',
        'Oklahoma City',
        'Portland',
        'Las Vegas',
        'Louisville',
        'Milwaukee',
        'Albuquerque',
        'Tucson',
        'Fresno',
        'Sacramento',
        'Long Beach',
        'Kansas City',
        'Mesa',
        'Atlanta',
        'Virginia Beach',
        'Omaha',
        'Colorado Springs',
        'Raleigh',
        'Miami',
        'Oakland',
        'Minneapolis',
        'Tulsa',
        'Cleveland',
        'Wichita',
        'New Orleans',
        'Arlington'
    ],
    roles = [
        'Employee',
        'Manager',
        'Director',
        'Executive',
        'Admin'
    ];

module.exports = {
    departments: departments,
    locations: locations,
    roles: roles
};
