/*jslint node: true, plusplus: true, stupid: true, nomen: true, indent: 4, maxlen: 80 */
"use strict";

var cache = {},
    fs = require('fs'),
    path = require('path'),
    vm = require('vm');

module.exports = function (file, mocks, context) {
    var contents,
        script;
    mocks = mocks || {};
    context = context || {};
    if (!cache[file]) {
        file = path.resolve(file);
        cache[file] = fs.readFileSync(file, 'utf8');
        if (module.exports.onload) {
            cache[file] = module.exports.onload(file, cache[file]);
        }
    }
    script = vm.createScript(cache[file], file);
    context.require = function (a) {
        if (mocks[a]) {
            return require(path.resolve(mocks[a]));
        }
    };
    context.module = {
        exports : {}
    };
    script.runInNewContext(context);
    return context.module.exports;
};

module.exports.onload = function (file, content) {
    return content;
};