var tests = [];
for (var file in window.__karma__.files) {
    if (/spec\.js$/.test(file)) {
        tests.push(file);
    }
}
requirejs.config({
    // Karma serves files from '/base'
    baseUrl: '/base',

    paths: {
        'angular': 'static/lib/angular/angular',
        'angular-resource': 'static/lib/angular/angular-resource.min',
        'angular-mocks': 'static/lib/angular/angular-mocks',
        'public-app': 'unitTests/app/public-app',
        'd3': 'unitTests/ui-mocks/d3',
        'fingerprint': 'static/lib/fingerprint.min',
        'static/lib/plugins/jquery.autosize.min': 'static/lib/plugins/jquery.autosize.min',
        'templates/shared': 'static/templates/shared',
        'unitTests/ui-mocks/qtip.mock': 'unitTests/ui-mocks/qtip.mock',
        'text': 'static/lib/require-text',
        'json': 'static/lib/require-json',
        'environment': 'unitTests/ui-mocks/environment.json'
    },
    shim: {
        'angular': {
            exports: 'angular'
        },
        'angular-resource': {
            exports: 'angular-resource',
            deps: ['angular']
        },
        'angular-mocks': {
            exports: 'angular-mocks',
            deps: ['angular']
        },
        'public-app': {
            deps: ['angular']
        },
        'static/lib/angular/angular-translate.min': {
            deps: ['angular']
        },
        'static/lib/angular/angular-translate-loader-static-files.min': {
            deps: ['angular', 'static/lib/angular/angular-translate.min']
        },
        'static/lib/plugins/jquery.autosize.min': {
            deps: ['jquery']
        },
        'unitTests/ui-mocks/qtip.mock': {
            deps: ['jquery']
        }
    },
    priority: [
        'angular',
        'jquery'
    ],
    // ask Require.js to load these files (all our tests)
    deps: tests,

    // start test run, once Require.js is done
    callback: window.__karma__.start
});

