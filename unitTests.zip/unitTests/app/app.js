define(['angular',
        'static/source/hgapp/controllers',
        'static/source/hgapp/directives',
        'static/source/core/controllers',
        'static/source/hgapp/services',
        'static/source/hgapp/filters',
        'unitTests/app/dialogs',
        'static/source/hgapp/ctrl.services',
        'unitTests/ui-mocks/en.json',
        'angular-mocks',
        'unitTests/ui-mocks/qtip.mock',
        'static/lib/angular/ui-bootstrap-0.8.0.min',
        'static/lib/angular/ui-bootstrap-tpls-0.8.0.min',
        'static/lib/angular/angular-ui-utils.min',
        'static/lib/angular/angular-ui-utils-ieshiv.min',
        'static/lib/angular/angular-route',
        'static/lib/angular/angular-animate.min',
        'static/lib/angular/ui-date',
        'static/lib/angular/select2',
        'static/lib/angular/tinymce',
        'static/lib/angular/sortable',
        'static/lib/angular/angular-ui-router',
        'static/lib/angular/tinymce',
        'static/source/core/prototypes',
        'static/lib/angular/angular-sanitize.min',
        'unitTests/ui-mocks/pusher',
        'static/lib/angular/angular-translate.min',
        'static/lib/plugins/autosize.min',
        'static/lib/angular/angular-translate-loader-static-files.min',
        'static/lib/angular/angular-toastr.min',
        'autosize',
        'static/source/hgapp/components'
    ],
    function (angular,
              controllers,
              directives,
              maincontrollers,
              services,
              filters,
              dialogs,
              ctrlServices,
              enJson) {
        angular.module("hgapp-app", [
            'pascalprecht.translate',
            'ui.utils',
            'ngRoute',
            'ngAnimate',
            'ngSanitize',
            'ui.select2',
            'ui.date',
            'ui.router',
            'ui.tinymce',
            'toastr',
            'main-controllers',
            'hgapp-controllers',
            'hgapp-directives',
            'ui.bootstrap',
            'hgapp-services',
            'hgapp.ctrl.services',
            'hgapp-filters',
            'hgapp.components',
        ]).config(['$translateProvider', function ($translateProvider) {
            $translateProvider.translations('en', enJson.get());
            $translateProvider.preferredLanguage('en');
        }]).run(['$rootScope', function ($rootScope) {
            $rootScope.javascriptDirectory = [''];
            $rootScope.imageStore = ['a'];
            $rootScope.imageStoreBadges = ['a'];
        }]);
        document.cookie = "UserToken=oeschger";
        controllers.init();
        services.init();
        directives.init();
        maincontrollers.init();
        filters.init();
        ctrlServices.init();
        dialogs.init();
    });

