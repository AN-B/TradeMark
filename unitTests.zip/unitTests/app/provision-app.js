define(['angular',
        'static/source/hgapp/directives',
        'static/source/hgapp/filters',
        'static/source/provision/controllers',
        'static/source/provision/services',
        'static/source/provision/filters',
        'unitTests/ui-mocks/en.json',
        'static/lib/angular/ui-bootstrap-tpls-0.8.0.min',
        'static/lib/angular/angular-ui-utils.min',
        'static/lib/angular/angular-ui-utils-ieshiv.min',
        'static/lib/angular/angular-route',
        'static/lib/angular/tinymce',
        'static/source/core/prototypes',
        'static/lib/angular/angular-sanitize.min',
        'static/lib/angular/angular-translate.min',
        'static/lib/angular/angular-toastr.min',
        'unitTests/ui-mocks/qtip.mock',
        'autosize'],
    function (angular,
              directives,
              filters,
              provisionCtrl,
              provisionSrvc,
              provisionFilters,
              enJson) {
        angular.module("provision-app", [
            'pascalprecht.translate',
            'ui.utils',
            'ngRoute',
            'toastr',
            'ngSanitize',
            'ui.bootstrap',
            'provision-controllers',
            'provision-services',
            'hgapp-directives',
            'provision-filters'
        ]).config(['$translateProvider', function ($translateProvider) {
            $translateProvider.translations(enJson.get());
            $translateProvider.preferredLanguage('en');
        }]).run(['$rootScope', function ($rootScope) {
            $rootScope.javascriptDirectory = [''];
            $rootScope.imageStore = ['a'];
            $rootScope.imageStoreBadges = ['a'];
        }]);
        document.cookie = "UserToken=oeschger";
        provisionCtrl.init({imageStore: 'blah'});
        directives.init();
        filters.init();
        provisionFilters.init();
        provisionSrvc.init();
    });