define(['angular'],
    function(angular){
        function init() {
            return angular.module('dialogs', []);

        }
        return {
            init: init
        }
    });