define(['angular',
        'static/source/display/controllers',
        'static/source/display/services',
        'unitTests/ui-mocks/en.json',
        'static/lib/angular/ui-bootstrap-tpls-0.8.0.min',
        'static/lib/angular/angular-ui-utils.min',
        'static/lib/angular/angular-ui-utils-ieshiv.min',
        'static/lib/angular/angular-route',
        'static/lib/angular/angular-animate.min',
        'static/lib/angular/tinymce',
        'static/source/core/prototypes',
        'static/lib/angular/angular-sanitize.min',
        'static/lib/angular/angular-translate.min',
        'static/lib/angular/angular-toastr.min',
        'unitTests/ui-mocks/qtip.mock'],
    function (angular,
              displayCtrl,
              displaySrvc,
              enJson) {
        angular.module("display-app", [
            'pascalprecht.translate',
            'ui.utils',
            'ngRoute',
            'ngAnimate',
            'ngSanitize',
            'ui.tinymce',
            'toastr',
            'ui.bootstrap',
            'display-controllers',
            'display-services'
        ]).config(['$translateProvider', function ($translateProvider) {
            $translateProvider.translations(enJson.get());
            $translateProvider.preferredLanguage('en');
        }]).run(['$rootScope', function ($rootScope) {
            $rootScope.javascriptDirectory = [''];
            $rootScope.imageStore = ['a'];
            $rootScope.imageStoreBadges = ['a'];
        }]);
        displayCtrl.init({imageStore: 'blah'});
        displaySrvc.init();
    });