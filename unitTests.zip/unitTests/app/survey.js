define(['angular',
        'static/source/survey/controllers',
        'static/source/survey/services',
        'unitTests/ui-mocks/en.json',
        'static/lib/angular/angular-ui-utils.min',
        'static/lib/angular/angular-route',
        'static/lib/angular/angular-animate.min',
        'static/lib/angular/ui-date',
        'static/lib/angular/select2',
        'static/lib/angular/tinymce',
        'static/lib/angular/sortable',
        'static/lib/angular/angular-ui-router',
        'static/lib/angular/tinymce',
        'static/source/core/prototypes',
        'static/lib/angular/angular-sanitize.min',
        'static/lib/angular/angular-translate.min',
        'static/lib/angular/angular-toastr.min'],
    function (angular,
              publicCtrl,
              publicSrvc,
              enJson) {
        angular.module("survey.app", [
            'pascalprecht.translate',
            'ui.utils',
            'ngRoute',
            'ngAnimate',
            'toastr',
            'ngSanitize',
            'ui.select2',
            'ui.date',
            'ui.router',
            'ui.tinymce',
            'ui.bootstrap',
            'survey.controllers',
            'survey.services'
        ]).config(['$translateProvider', function ($translateProvider) {
            $translateProvider.translations(enJson.get());
            $translateProvider.preferredLanguage('en');
        }]).run(['$rootScope','$templateCache', function ($rootScope, $templateCache) {

            $templateCache.put('templates/Public/Main/void.html', '<div></div>');
            $rootScope.javascriptDirectory = [''];
            $rootScope.imageStore = ['a'];
            $rootScope.imageStoreBadges = ['a'];
        }]);
        document.cookie = "UserToken=oeschger";
    });