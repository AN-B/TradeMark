var tests = [];
for (var file in window.__karma__.files) {
    if (/spec\.js$/.test(file)) {
        tests.push(file);
    }
}
requirejs.config({
    // Karma serves files from '/base'
    baseUrl: '/base',

    paths: {
        'jquery': 'static/lib/jquery-1.10.2.min',
        'angular': 'static/lib/angular/angular',
        'static/lib/plugins/spectrum.min': 'static/lib/plugins/spectrum.min',
        'angular-resource': 'static/lib/angular/angular-resource.min',
        'angular-mocks': 'static/lib/angular/angular-mocks',
        'display-app': 'unitTests/app/display-app',
        'd3': 'unitTests/ui-mocks/d3',
        'fingerprint': 'static/lib/fingerprint.min',
        'static/lib/angular/ui-bootstrap-tpls-0.8.0.min': 'static/lib/angular/ui-bootstrap-tpls-0.8.0.min',
        'static/lib/angular/angular-ui-utils.min': 'static/lib/angular/angular-ui-utils.min',
        'templates/shared': 'static/templates/shared',
        'unitTests/ui-mocks/qtip.mock': 'unitTests/ui-mocks/qtip.mock',
        'text': 'static/lib/require-text',
        'json': 'static/lib/require-json',
        'environment': 'unitTests/ui-mocks/environment.json'
    },
    shim: {
        'angular': {
            exports: 'angular'
        },
        'jquery': {
            exports: 'jquery'
        },
        'angular-resource': {
            exports: 'angular-resource',
            deps: ['angular']
        },
        'angular-mocks': {
            exports: 'angular-mocks',
            deps: ['angular']
        },
        'public-app': {
            deps: ['angular']
        },
        'static/lib/angular/ui-bootstrap-tpls-0.8.0.min': {
            deps: ['angular']
        },
        'static/lib/angular/angular-ui-utils.min': {
            deps: ['angular']
        },
        'static/lib/angular/angular-translate.min': {
            deps: ['angular']
        },
        'static/lib/angular/angular-route': {
            deps: ['angular']
        },
        'static/lib/angular/angular-sanitize.min': {
            deps: ['angular']
        },
        'static/lib/angular/angular-toastr.min': {
            deps: ['angular']
        },
        'static/lib/angular/angular-animate.min': {
            deps: ['angular']
        },
        'static/lib/angular/angular-translate-loader-static-files.min': {
            deps: ['angular', 'static/lib/angular/angular-translate.min']
        },
        'unitTests/ui-mocks/qtip.mock': {
            deps: ['jquery']
        }
    },
    priority: [
        'angular',
        'jquery'
    ],
    // ask Require.js to load these files (all our tests)
    deps: tests,

    // start test run, once Require.js is done
    callback: window.__karma__.start
});
