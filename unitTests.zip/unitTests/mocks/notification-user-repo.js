/*jslint node:true es5:true*/
"use strict";
function getMembersByUserId (id, callback) {
	var date = new Date();
	callback(null, [{
		   "ApprovedOrDeniedBy": null,
		   "CreatedBy": "709da94e-4fb7-4bf1-a882-58f1773fcbe7",
		   "CreatedDate": 1357242868008,
		   "DefaultPaymentProfileId": null,
		   "MyManagers": [],
		   "EndingDate": null,
		   //"ExperiencePoint": NumberInt(0),
		   "FirstName": "Gary",
		   "FollowedMemberIds": {
		     "0": "a79dfa57-9740-4158-bc3c-fa8613e302c6",
		     "1": "473d6327-c760-4490-8ec4-8edc459643ef",
		     "2": "38ff8fba-e87b-4432-976b-bd334808f083",
		     "3": "a410a68f-8650-403c-9410-eee8c5a22912",
		     "4": "e55c902d-9166-4739-a9cc-ac8f4c670abb",
		     "5": "4be2312a-9a4b-461b-91c3-9adc7522bae0",
		     "6": "9e32b6f5-351e-4c64-b0c9-5e5132b10baa",
		     "7": "df6cdb63-763c-4bea-b676-ce526235e3e5",
		     "8": "e47eea0d-cade-4626-901d-f6a8802f45e6",
		     "9": "25bdb234-f402-4c47-b005-51f68386beef",
		     "10": "2fa91703-1e77-4967-94e3-2be22a8236be",
		     "11": "60716374-ca8b-4e8e-8d4f-aac7bef5a9a4",
		     "12": "6baa2cd0-e442-4b8a-9221-011bf5bfde91",
		     "13": "40104EE5-19ED-41C8-89C1-CBC4CA531C63",
		     "14": "ae8b1224-4b13-46c2-b1b9-ede47dc9f12a",
		     "15": "6c85b89b-860b-454f-b6a5-9d6839477972",
		     "16": "e7bdedd9-009e-4066-9708-7887ee262102",
		     "17": "de795457-f684-4898-915a-5368a1d772a4",
		     "18": "5d778cc1-880c-47fd-a339-0fba3cf93f07",
		     "19": "217b05a0-4921-4a37-8292-0f0d881629e2",
		     "20": "ec390428-9a81-4d96-8f27-3585a1574a74",
		     "21": "fb07157d-36fb-4a05-94f6-045154149493",
		     "22": "478b7e2f-64e0-462b-86c8-195633158f45",
		     "23": "1fb9ba6c-641b-4634-bcfd-ccff47119531",
		     "24": "0e4e7e81-977f-4833-b428-a4eb2b309950",
		     "25": "df447526-4b0a-4617-8696-ca8e7f306d38",
		     "26": "dc61d315-6a0b-42f4-98b7-25fd847ec475" 
		  },
		   "FullName": "Gang Wei",
		   "GroupDepartmentId": null,
		   "GroupDepartmentName": "Development",
		   "GroupId": "c9c33673-51fe-46f6-af61-571551d60d27",
		   //"GroupLevelId": NumberLong(3),
		   "GroupName": "Fooda",
		   "GroupRoleId": "GroupAdmin",
		   "GroupRoleName": null,
		   "InvitedBy": "709da94e-4fb7-4bf1-a882-58f1773fcbe7",
		   "LastName": "Wei",
		   "MembershipStatus": "Active",
		   "ModifiedBy": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		   "ModifiedDate": 1357242868008,
		   "RolesInGroup": [
		     	"HGAdmin"
		  ],
		   "StartingDate": date.getTime(),
		   "Title": null,
		   "UserId": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		   //"__v": NumberLong(2),
		   //"_id": ObjectId("50e5e1f47c6ac8b969000678"),
		   "hgId": "bda249ee-784e-48ca-bcb6-13e36d8c424e" 
		},{
		   "ApprovedOrDeniedBy": null,
		   "CreatedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
		   "CreatedDate": 1357242866466,
		   "DefaultPaymentProfileId": null,
		   "MyManagers": [
		     
		  ],
		   "EndingDate": null,
		   "FirstName": "Gary",
		   "FullName": "Wei, Gary",
		   "GroupDepartmentId": null,
		   "GroupDepartmentName": "Development",
		   "GroupId": "69FF7C77-241C-4F00-A633-D344446BE8E8",
		  // "GroupLevelId": NumberInt(3),
		   "GroupName": "HighGround",
		   "GroupRoleId": "GroupAdmin",
		   "GroupRoleName": null,
		   "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
		   "LastName": "May",
		   "MembershipStatus": "Active",
		   "ModifiedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
		   "ModifiedDate": 1357242866466,
		   "RolesInGroup": [
		     "Executive"
		 	],
		   "StartingDate": null,
		   "Title": null,
		   "UserId": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		   //"_id": ObjectId("50e5e1f27c6ac8b969000627"),
		   "hgId": "586e2932-4da6-408c-877f-6f842d67d34d" 
		}]);
}
function getRecipientsByUserIds(ids, callback) {
	var date = new Date(),
		retVal = [],
		meta = [{
			"AvatarVersion": 1368632136300,
		   "CreatedBy": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		   "CreatedDate": 1357242807877,
		   "Flags": {
			 "TutorialPending": false,
			 "WelcomeBadgePending": false
		  },
		   "LastLoginTime": 1369772568583,
		   "LowercaseUserName": "gary@fooda.com",
		   "ModifiedBy": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		   "ModifiedDate": 1357242807877,
		   "MyMemberships": null,
		   "Preference": {
			 "Channels": {
			   "0": "Recognize",
			   "1": "Perform",
			   "2": "Motivate"
			},
			 "DefaultChannel": "",
			 "DefaultGroupId": "c9c33673-51fe-46f6-af61-571551d60d27",
			 "HomeZip": "",
			 "NickName": "Gary",
			 "Photo": null,
			 "WorkZip": ""
		  },
		   "UserContext": {
			 "CurrentGroupId": null,
			 "CurrentGroupName": null,
			 "MemberIdInGroup": null,
			 "MemberTitleInGroup": null
		  },
		   "UserFinance": {
			 "SpendingAccountBalance": null,
			 "TransferAccountBalanceInGroup": null,
			 "PaymentProfiles": {
				 "FriendlyName": "my cr card"
			 }
		  },
		   "UserName": "gary@fooda.com",
		   "UserPersonal": {
			 "Address": null,
			 "Birthdate": 1211950800000,
			 "FirstName": "Gary",
			 "FullName": "Wei, Gary",
			 "LastName": "May",
			 "PrimaryEmail": "gary@fooda.com"
		  },
		   "UserToken": null,
		   "WelcomeBadgePending": false,
		   "hgId": "D79FB934-15A3-4954-B9A4-2D044EEBC132"
		},{
		  "AvatarVersion": 1369158974094,
		  "CreatedBy": "CD9DA97E-EF9E-47B0-9ACD-E71A38CC9804",
		  "CreatedDate": 1357242807870,
		  "Flags": {
			"TutorialPending": false,
			"WelcomeBadgePending": false
		  },
		  "LastLoginTime": 1369754896343,
		  "LowercaseUserName": "katrina@fooda.com",
		  "ModifiedBy": "CD9DA97E-EF9E-47B0-9ACD-E71A38CC9804",
		  "ModifiedDate": 1357242807870,
		  "MyMemberships": null,
		  "Preference": {
			"Channels": [
			  "Recognize",
			  "Perform",
			  "Motivate"
			],
			"DefaultChannel": "",
			"DefaultGroupId": "c9c33673-51fe-46f6-af61-571551d60d27",
			"HomeZip": null,
			"NickName": "Katrina",
			"Photo": null,
			"WorkZip": null
		  },
		  "UserContext": {
			"CurrentGroupId": null,
			"CurrentGroupName": null,
			"MemberIdInGroup": null,
			"MemberTitleInGroup": null
		  },
		  "UserFinance": {
			"SpendingAccountBalance": null,
			"TransferAccountBalanceInGroup": null,
			"PaymentProfiles": [
			  {
				"FriendlyName": "test 1"
			  },
			  {
				"FriendlyName": "test"
			  }
			]
		  },
		  "UserName": "katrina@fooda.com",
		  "UserPersonal": {
			"Address": null,
			"Birthdate": 1211950800000,
			"FirstName": "Katrina",
			"FullName": "Katrina Manoshin",
			"LastName": "Manoshin",
			"PrimaryEmail": "katrina@fooda.com"
		  },
		  "UserToken": null,
		  "hgId": "CD9DA97E-EF9E-47B0-9ACD-E71A38CC9804"
		},{
			"AvatarVersion": 1369158974094,
			"CreatedBy": "CD9DA97E-EF9E-47B0-9ACD-E71A38CC9804",
			"CreatedDate": 1357242807870,
			"Flags": {
				"TutorialPending": false,
				"WelcomeBadgePending": false
			},
			"LastLoginTime": 1369754896343,
			"LowercaseUserName": "philip@highground.com",
			"ModifiedBy": "CD9DA97E-EF9E-47B0-9ACD-E71A38CC9804",
			"ModifiedDate": 1357242807870,
			"MyMemberships": null,
			"Preference": {
				"Channels": [
					"Recognize",
					"Perform",
					"Motivate"
				],
				"DefaultChannel": "",
				"DefaultGroupId": "c9c33673-51fe-46f6-af61-571551d60d27",
				"HomeZip": null,
				"NickName": "Philip",
				"Photo": null,
				"WorkZip": null
			},
			"UserContext": {
				"CurrentGroupId": null,
				"CurrentGroupName": null,
				"MemberIdInGroup": null,
				"MemberTitleInGroup": null
			},
			"UserFinance": {
				"SpendingAccountBalance": null,
				"TransferAccountBalanceInGroup": null,
				"PaymentProfiles": [
					{
						"FriendlyName": "test 1"
					},
					{
						"FriendlyName": "test"
					}
				]
			},
			"UserName": "philip@highground.com",
			"UserPersonal": {
				"Address": null,
				"Birthdate": 1211950800000,
				"FirstName": "Philip",
				"FullName": "Philip Plekhanov",
				"LastName": "Plekhanov",
				"PrimaryEmail": "philip@highground.com"
			},
			"UserToken": null,
			"hgId": "d2c38720-a119-11e2-b177-7d64c8315189"
		}],
		found = false;

	ids.forEach(function(id, i) {
		meta.forEach(function(rec, x) {
			if (id === rec.hgId) {
				retVal.push(rec);
				found = true;
			}
		});
	});
	if (found) {
		callback(null, retVal);
	}

}
function geRecipientsByGroupId(id, callback) {
	var date = new Date();
	callback(null, [{
		"ApprovedOrDeniedBy": null,
		"CreatedBy": "709da94e-4fb7-4bf1-a882-58f1773fcbe7",
		"CreatedDate": 1357242868008,
		"DefaultPaymentProfileId": null,
		"MyManagers": [],
		"EndingDate": null,
		//"ExperiencePoint": NumberInt(0),
		"FirstName": "Gary",
		"FollowedMemberIds": {
			"0": "a79dfa57-9740-4158-bc3c-fa8613e302c6",
			"1": "473d6327-c760-4490-8ec4-8edc459643ef",
			"2": "38ff8fba-e87b-4432-976b-bd334808f083",
			"3": "a410a68f-8650-403c-9410-eee8c5a22912",
			"4": "e55c902d-9166-4739-a9cc-ac8f4c670abb",
			"5": "4be2312a-9a4b-461b-91c3-9adc7522bae0",
			"6": "9e32b6f5-351e-4c64-b0c9-5e5132b10baa",
			"7": "df6cdb63-763c-4bea-b676-ce526235e3e5",
			"8": "e47eea0d-cade-4626-901d-f6a8802f45e6",
			"9": "25bdb234-f402-4c47-b005-51f68386beef",
			"10": "2fa91703-1e77-4967-94e3-2be22a8236be",
			"11": "60716374-ca8b-4e8e-8d4f-aac7bef5a9a4",
			"12": "6baa2cd0-e442-4b8a-9221-011bf5bfde91",
			"13": "40104EE5-19ED-41C8-89C1-CBC4CA531C63",
			"14": "ae8b1224-4b13-46c2-b1b9-ede47dc9f12a",
			"15": "6c85b89b-860b-454f-b6a5-9d6839477972",
			"16": "e7bdedd9-009e-4066-9708-7887ee262102",
			"17": "de795457-f684-4898-915a-5368a1d772a4",
			"18": "5d778cc1-880c-47fd-a339-0fba3cf93f07",
			"19": "217b05a0-4921-4a37-8292-0f0d881629e2",
			"20": "ec390428-9a81-4d96-8f27-3585a1574a74",
			"21": "fb07157d-36fb-4a05-94f6-045154149493",
			"22": "478b7e2f-64e0-462b-86c8-195633158f45",
			"23": "1fb9ba6c-641b-4634-bcfd-ccff47119531",
			"24": "0e4e7e81-977f-4833-b428-a4eb2b309950",
			"25": "df447526-4b0a-4617-8696-ca8e7f306d38",
			"26": "dc61d315-6a0b-42f4-98b7-25fd847ec475"
		},
		"FullName": "Gang Wei",
		"GroupDepartmentId": null,
		"GroupDepartmentName": "Development",
		"GroupId": "c9c33673-51fe-46f6-af61-571551d60d27",
		//"GroupLevelId": NumberLong(3),
		"GroupName": "Fooda",
		"GroupRoleId": "GroupAdmin",
		"GroupRoleName": null,
		"InvitedBy": "709da94e-4fb7-4bf1-a882-58f1773fcbe7",
		"LastName": "Wei",
		"MembershipStatus": "Active",
		"ModifiedBy": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		"ModifiedDate": 1357242868008,
		"RolesInGroup": [
			"HGAdmin"
		],
		"StartingDate": date.getTime(),
		"Title": null,
		"UserId": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		//"__v": NumberLong(2),
		//"_id": ObjectId("50e5e1f47c6ac8b969000678"),
		"hgId": "bda249ee-784e-48ca-bcb6-13e36d8c424e"
	},{
		"ApprovedOrDeniedBy": null,
		"CreatedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
		"CreatedDate": 1357242866466,
		"DefaultPaymentProfileId": null,
		"MyManagers": [

		],
		"EndingDate": null,
		"FirstName": "Gary",
		"FullName": "Wei, Gary",
		"GroupDepartmentId": null,
		"GroupDepartmentName": "Development",
		"GroupId": "69FF7C77-241C-4F00-A633-D344446BE8E8",
		// "GroupLevelId": NumberInt(3),
		"GroupName": "HighGround",
		"GroupRoleId": "GroupAdmin",
		"GroupRoleName": null,
		"InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
		"LastName": "May",
		"MembershipStatus": "Active",
		"ModifiedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
		"ModifiedDate": 1357242866466,
		"RolesInGroup": [
			"Executive"
		],
		"StartingDate": null,
		"Title": null,
		"UserId": "D79FB934-15A3-4954-B9A4-2D044EEBC132",
		//"_id": ObjectId("50e5e1f27c6ac8b969000627"),
		"hgId": "586e2932-4da6-408c-877f-6f842d67d34d"
	}]);
}
module.exports = {
	getMembersByUserId: getMembersByUserId,
	getRecipientsByUserIds: getRecipientsByUserIds,
	geRecipientsByGroupId: geRecipientsByGroupId
}