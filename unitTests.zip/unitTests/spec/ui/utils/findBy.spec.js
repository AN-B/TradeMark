define(['static/source/core/prototypes'],function(){
    describe("findBy spec -> ", function(){

        it("Test 1  should return object if match fount", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.findBy('id', 1);
            expect(test.id).toBe(1);
        });
        it("Test 2  should return undefined if no matching values found", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.findBy('id', 2);

            expect(test).not.toBeDefined();
        });
        it("Test 3  should return undefined if value is not passed", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.findBy('id');
            expect(test).not.toBeDefined();
        });
        it("Test 4 should return undefined if no params passed", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.findBy();
            expect(test).not.toBeDefined();
        });
        it("Test 5 should return undefined if no matching values found", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.findBy(1, 'id');
            expect(test).not.toBeDefined();
        });
        it("Test 6 should return first found object", function(){
            var obj = [{id : 1, test: 'first'}, {id : 1, test: 'second'}],
                test = obj.findBy('id', 1);
            expect(test.test).toBe('first');
        });
        it("Test 7 should return first found object", function(){
            var obj = [{id : 1, test: 'first'}, {id : 1, test: 'second'}],
                test = obj.findBy('id', 1);
            expect(test.test).toBe('first');
        });
        it("Test 8 should return first found object", function(){
            var obj = [{id : 1, test: 'first'}, {id : 1, test: 'second'}],
                test = obj.findBy('id', 1);
            if (test) {
                test.selected = true;
            }
            expect(obj[0].selected).toBeTruthy();
        });

        it("Test 9 should return first found object", function(){
            var test = [{id : 1, test: {name: 'first'}}, {id : 1, test: {name: 'second'}}].findBy('test.name', 'first');
            expect(test.id).toBe(1);
        });
        it("Test 10 should return first found object", function(){
            var test = [{id : 1, test: {name: 'first'}}, {id : 1, test: {name: 'second'}}].findBy('test.name.gary', 'first');
            expect(test).not.toBeDefined();
        });
        it("Test 11 should return first found object", function(){
            var test = [{id : 1, test: 'first'}, {id : 1, test: 'second'}].findBy('test.name', 'first');
            expect(test).not.toBeDefined();
        });



    });
});