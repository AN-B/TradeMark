define(['static/source/hgapp/util/css-util'], function(util){
	describe("css util spec -> ", function(){

		it("Test 1  return value should be empty", function(){
			var test = util.getAvatarClass(1, 4);
			expect(test).toBeFalsy();
		});
		it("Test 2  return value to be size2-4", function(){
			var test = util.getAvatarClass(2, 4);
			expect(test).toBe('size2-4');
		});
		it("Test 3 return value to be size3-2", function(){
			var test = util.getAvatarClass(3, 2);
			expect(test).toBe('size3-2');
		});
		it("Test 4 return value to be size4", function(){
			var test = util.getAvatarClass(4, 2);
			expect(test).toBe('size4');
		});
		it("Test 5 return value to be size4", function(){
			var test = util.getAvatarClass(0, 2);
			expect(test).toBe('size4');
		});
		it("Test 6 return value to be size4", function(){
			var test = util.getAvatarClass(10, 2);
			expect(test).toBe('size4');
		});
	});
});
