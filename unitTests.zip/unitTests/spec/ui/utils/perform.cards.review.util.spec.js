define([
    'static/source/hgapp/util/perform-cards-reviews-util',
    'unitTests/ui-mocks/review.json'], function(util, json){
    var reviews;
    beforeEach(function(){
        reviews = json.getJsonForUtil();
    });
    xdescribe("perform cards review util spec -> ", function(){
        it("Test 1: tooltip text should be defined for the 2nd element of the review array", function(){
            var test = util.getTooltipText(reviews);
            expect(test.Reviews[0].tooltipText).not.toBeDefined();
            expect(test.Reviews[1].tooltipText).toBeDefined();
            expect(test.Reviews[0].TotalOptionalQuestions).not.toBeDefined();
            expect(test.Reviews[0].TotalRequiredQuestions).not.toBeDefined();
            expect(test.Reviews[0].AnsweredRequiredQuestions).not.toBeDefined();
            expect(test.Reviews[1].TotalOptionalQuestions).not.toBeDefined();
            expect(test.Reviews[1].TotalRequiredQuestions).not.toBeDefined();
            expect(test.Reviews[1].AnsweredRequiredQuestions).not.toBeDefined();
        });
        it("Test 2: tooltip text should display required question number", function(){
            var test = util.getTooltipText(reviews);
            expect(test.Reviews[1].tooltipText).toBe('0 of 1 required question answered<br/>');
        });
        it("Test 3: tooltip text should display required question number", function(){
            reviews.Reviews[1].TotalRequiredQuestions = 10;
            var test = util.getTooltipText(reviews);
            expect(test.Reviews[1].tooltipText).toBe('0 of 10 required questions answered<br/>');
        });
        it("Test 4: tooltip text should display optional question number", function(){
            reviews.Reviews[1].TotalOptionalQuestions = 10;
            var test = util.getTooltipText(reviews);
            expect(test.Reviews[1].tooltipText).toBe('0 of 1 required question answered<br/>Optional questions - 10');
        });
    });
});