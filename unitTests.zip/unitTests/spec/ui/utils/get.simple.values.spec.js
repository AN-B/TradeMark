define(function(){
    describe("get simple values spec -> ", function(){

        it("Test 1  should return array of one", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.getSimpleValues('id');
            expect(test[0]).toBe(1);
        });
        it("Test 2  should return empty array if no properties found", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.getSimpleValues('123');
            expect(test.length).toBe(0);
        });
        it("Test 3 should return array of 4 items", function(){
            var obj = [{id : 1, test: 'test'}, {id : 2, test: 'test'}, {id : 3, test: 'test'}, {id : 4, test: 'test'}],
                test = obj.getSimpleValues('id');
            expect(test.length).toBe(4);
        });
    });
});