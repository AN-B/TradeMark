define([
    'angular',
    'static/source/core/utility/ng-listener-util',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular, listiner){

    describe('Util listiner spec controller spec', function() {
        var ctrl1,
            ctrl2,
            scope1,
            rootScope,
            scope2,
            event = 'blah',
            ctrl = function($scope){
                    listiner.register($scope, event, function(){

                    });
                };
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));

        beforeEach(inject(function ($injector, $controller, $rootScope) {
            rootScope = $rootScope;
            scope1 = $rootScope.$new();
            scope2 = $rootScope.$new();
            ctrl1 = $controller(ctrl, {$scope: scope1});
            ctrl2 = $controller(ctrl, {$scope: scope2});

        }));
        afterEach(function () {
            scope1.$digest();
            scope2.$digest();
        });
        it('Test 1: both test controller should be defined', function (){
            expect(ctrl1).toBeDefined();
            expect(ctrl2).toBeDefined();
        });
        it('Test 2: destroy event for controller #2 should not destroy events for #1', function (){
            expect(listiner.events[scope1.$id][event]).toBeDefined();
            expect(listiner.events[scope2.$id][event]).toBeDefined();
            scope1.$broadcast('$destroy');
            expect(listiner.events[scope1.$id][event]).not.toBeDefined();
            expect(listiner.events[scope2.$id][event]).toBeDefined();
        });
    });
});