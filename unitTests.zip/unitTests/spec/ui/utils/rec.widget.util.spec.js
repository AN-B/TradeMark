define(['static/source/hgapp/util/rec-widget-util',
	'unitTests/ui-mocks/group.json',
	'unitTests/ui-mocks/badge.json',
	'unitTests/ui-mocks/dto.service.json',
	'unitTests/ui-mocks/recognition.request.object.json',
	'unitTests/ui-mocks/recognition.templates.json',
	'unitTests/ui-mocks/user.json'],function(util, groupJson, badgeJson, dtoJson, request, templatesJson, userJson){
	describe("rec.widget.util.spec ->", function(){
		var recipients;
		beforeEach(function(){
		});
		it("Test 1 getRecipients should return array of 0 element if empty array was passed", function(){
			var meta = [],
				test = util.getRecipients(meta);
			expect(test.length).toBe(0);
		});
		it("Test 2 getRecipients should return array of 1 element if array with one selected item was passed", function(){
			var meta = [{Selected: true}, {Selected: false}],
				test = util.getRecipients(meta);
			expect(test.length).toBe(1);
		});
		it("Test 3 resolveRecipients should not select any recipients if selected array is empty", function(){
			var test = util.resolveRecipients([], dtoJson.getRecipients());
			test.forEach(function(item){
				expect(item.Selected).toBeFalsy();
			});
		});
		it("Test 4 resolveRecipients should select 2 recipients", function(){
			var selected = [{Id: '9c0cd910-cc94-11e2-863c-278252e8a19f', Selected: true}, {Id: 'be97cac0-302c-11e3-91d2-dd5c4c401983', Selected: true}],
				test = util.resolveRecipients(selected, dtoJson.getRecipients());
			expect(test.length).toBe(19);
			expect(test[0].Selected).toBeTruthy();
			expect(test[1].Selected).toBeTruthy();
			expect(test[2].Selected).toBeFalsy();
		});
		it("Test 5 getBadgeDto should return array of 3 objects", function(){
			util.getBadgeDto(badgeJson.getBadges(), '', 'Account Management', function(data){
				expect(data.length).toBe(1);
				data.forEach(function(item){
					expect(item.Selected).toBeFalsy();
				});
			});

		});
		it("Test 7 getBadgeDto should return array of 1 slide", function(){
			util.getBadgeDto(badgeJson.getBadges(),'4ef7b080-a1ee-11e2-b9ee-293826524e46','Account Management', function(data){
				expect(data.length).toBe(1);
				expect(data[0].Selected).toBeTruthy();
			});
		});
		it("Test 8 getCategories should return array of 1 slides with 2 elements in the slide", function(){
			var test = util.getCategories({
                data: badgeJson.getBadges(),
                fgid: 0
            }, 'Account Management');
			expect(test.length).toBe(3);
			expect(test[1].Selected).toBeTruthy();
			test = util.getCategories({
                data: badgeJson.get18Badges(),
                fgid: 0
            }, 'Account Management');
			expect(test[1].Selected).toBeTruthy();
		});
		it("Test 9 setSelectedCategory should select category on category json", function(){
			var test = util.getCategories({
                data: badgeJson.getBadges(),
                fgid: 0
            }, 'Account Management');
			expect(test.length).toBe(3);
			expect(test[1].Selected).toBeTruthy();
			test = util.setSelectedCategory(test, 'Account Finance');
			expect(test[0].Selected).toBeTruthy();
			expect(test[1].Selected).toBeFalsy();
		});
		it("Test 10 cleanRequest should set template properties to empty if category don't match", function(){
			var test = request.getCustom();
			expect(test.Template.Category).toBe('Custom');
			expect(test.Template.ImageId.length).not.toBe(0);
			test = util.cleanRequest(test, ['Everyday']);
			expect(test.Template.ImageId.length).toBe(0);

			test = request.getCustom();
			expect(test.Template.Category).toBe('Custom');
			expect(test.Template.ImageId.length).not.toBe(0);
			test = util.cleanRequest(test, ['Everyday', 'Custom']);
			expect(test.Template.ImageId.length).not.toBe(0);

			test = request.getValue();
			expect(test.Template.Category).toBe('Value');
			expect(test.Template.ImageId.length).not.toBe(0);
			expect(test.Template.hgId.length).not.toBe(0);
			test = util.cleanRequest(test, ['Everyday', 'Custom']);
			expect(test.Template.ImageId.length).toBe(0);
			expect(test.Template.hgId.length).toBe(0);
		});
		it("Test 11 getValueTemplatesDto should return array of 2 slides and first element of slide 1 should be selected", function(){
			var test = util.getValueTemplatesDto(templatesJson.getValue().Templates, 'ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
			expect(test[0].Selected).toBeTruthy();
			expect(test[0].hgId).toBe('ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
			expect(test.length).toBe(9);
		});
		it("Test 12 toggleValueTemplate should toggle selected", function(){
			var test = util.getValueTemplatesDto(templatesJson.getValue().Templates, 'ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
			expect(test[0].Selected).toBeTruthy();
			expect(test[0].hgId).toBe('ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
			test = util.toggleValueTemplate(test, 'ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
			expect(test[0].Selected).toBeFalsy();
			test = util.toggleValueTemplate(test, 'ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
			expect(test[0].Selected).toBeTruthy();
			test = util.toggleValueTemplate(test, 'c4c5bc20-3da8-11e3-8e3f-3b48bfc048fd');
			expect(test[0].Selected).toBeFalsy();
			expect(test[1].Selected).toBeTruthy();
		});
		it("Test 13 getSubValuesDto shluld get sub value dto", function(){
			util.getSubValuesDto(templatesJson.getValue().Templates, 'ba2b5950-3da8-11e3-8e3f-3b48bfc048fd', '5107ders-fbab-11e2-bad3-999e6df490a1', function(data){
				var test = data;
				expect(test.length).toBe(10);
				expect(test[0].Selected).toBeTruthy();
			});

		});
		it("Test 14 toggleSubValues should toggle sub value selection", function(){
			util.getSubValuesDto(templatesJson.getValue().Templates, 'ba2b5950-3da8-11e3-8e3f-3b48bfc048fd', '5107ders-fbab-11e2-bad3-999e6df490a1', function(data){
				var test = data;
				expect(test.length).toBe(10);
				expect(test[0].Selected).toBeTruthy();
				test = util.toggleSubValues(test, '5107ders-fbab-11e2-bad3-999e6df490a1');
				expect(test[0].Selected).toBeFalsy();
				test = util.toggleSubValues(test, '4f0awedw-a1ee-11e2-b9ee-293826524e46');
				expect(test[1].Selected).toBeTruthy();
				test = util.toggleSubValues(test, '4f0awedw-a1ee-11e2-b9ee-293826524e46');
				expect(test[1].Selected).toBeFalsy();
			});
		});
		it("Test 15 getPermissions should return array of elements", function(){
			var test = util.getPermissions(userJson.getCu().UserContext.AggregatedSecuredTabs.recognizeTabs);
			expect(test.length).toBe(5);
		});

	});
});