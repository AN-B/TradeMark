define(['static/source/hgapp/util/motivate-group-util', 'unitTests/ui-mocks/kapow.response.mock'], function(util, mock){
    describe("motivate group util spec", function(){
        var meta;
        beforeEach(function(){
            meta = mock.get().product;
        });
        it("it should return array with length of 26 and first elements short description should be 20 + 3", function(){
            waitsFor(function() {
                return util.trimDesc(meta, 20);
            }, 25);
            runs( function () {
                expect(meta.length).toBe(26);
                expect(meta[0].shortdescription.length).toBe(23);
                expect(meta[0].shortdescription.substring(20, 23)).toBe('...');
                expect(meta[meta.length - 1].shortdescription.length).toBe(23);
            });
        });
        it("it should return array with length of 26 and first elements short description should be 2 + 3", function(){
            waitsFor(function() {
                return util.trimDesc(meta, 2);
            }, 25);
            runs( function () {
                expect(meta.length).toBe(26);
                expect(meta[0].shortdescription.length).toBe(5);
                expect(meta[0].shortdescription.substring(2, 5)).toBe('...');
                expect(meta[meta.length - 1].shortdescription.length).toBe(5);
            });
        });
        it("it should return array with length of 26 and first elements short description should be 5 + 3", function(){
            waitsFor(function() {
                return util.trimDesc(meta, 5);
            }, 25);
            runs( function () {
                expect(meta.length).toBe(26);
                expect(meta[0].shortdescription.length).toBe(8);
                expect(meta[0].shortdescription.substring(0, 4)).toBe('take');
                expect(meta[meta.length - 1].shortdescription.length).toBe(8);
            });
        });
    });
});
