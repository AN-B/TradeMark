define([
    'static/source/hgapp/util/perform-review-util',
    'unitTests/ui-mocks/perform.merge.mock',
    'static/source/core/prototypes'
], function(util, mock){
    describe("Perform review util spec  -> ", function(){

        it("Test 1 it should set answer text to server or cache if cache text is null", function(){
            var test = util.mergeSections(mock.server(), mock.cache());
            expect(test[0].Questions[0].Answers[0].Text).toBe('test cache');
            expect(test[0].Questions[1].Answers[0].Text).toBe('test server');
        });
        it("Test 2 it should set answer selected value to server or cache if cache selected value length is greater than 0", function(){
            var test = util.mergeSections(mock.server(), mock.cache());
            expect(test[0].Questions[2].Answers[0].SelectedValues.length).toBe(1);
            expect(test[0].Questions[3].Answers[0].SelectedValues.length).toBe(1);
        });
        it("Test 3 it should set answer tarck id to server or cache if cache track id exists", function(){
            var test = util.mergeSections(mock.server(), mock.cache());
            expect(test[0].Questions[5].TrackId).toBe('test track id');
            expect(test[0].Questions[5].track).toBeDefined();
        });

    });
});
