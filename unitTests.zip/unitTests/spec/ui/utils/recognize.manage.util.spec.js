define(['static/source/hgapp/util/recognize-manage-util',
	'unitTests/ui-mocks/recognition.templates.json'], function(util, recognitionTemplates){
    describe("recognize manage util spec", function(){
        var testString;
        beforeEach(function(){
            testString = '';
        });
        it("Test 1: getBadgeUrl should return a URL of the badge image. The url should contains '/badges/original/' or '/badges/group/', depending on the parameter sent to the funciton.", function(){
            var meta = [],
            	urlOrig,
            	urlGroup;
            runs(function() {
            	meta = recognitionTemplates.getEveryday();
                urlOrig = util.getBadgeUrl('ForegroundFilename', meta[0], 'imgstore', 'imgversion');
                urlGroup = util.getBadgeUrl('text', meta[0], 'imgstore', 'imgversion');
            }, 10);
            waitsFor(function(){
                return urlOrig + urlGroup;
            }, 10);
            runs( function () {
                expect(urlOrig.indexOf('/badges/original/')).toBeGreaterThan(-1);
                expect(urlGroup.indexOf('/badges/group/')).toBeGreaterThan(-1);
            });

        });
        it("Test 2: getTemplateDTO should return a template object with 2 image Urls.", function(){
            var template = {},
            	meta = [],
            	urlFore,
            	urlBack;
            runs(function() {
            	meta = recognitionTemplates.getEveryday();
            	template = util.getTemplateDTO(meta[0], 'imgstore', 'imgversion');
                urlFore = template.ForeGroundBadgeUrl;
                urlBack = template.BackGroundBadgeUrl;
            }, 10);
            waitsFor(function(){
                return urlFore + urlBack;
            }, 10);
            runs( function () {
                expect(urlFore.indexOf('/badges/original/')).toBeGreaterThan(-1);
                expect(urlBack.indexOf('/badges/original/')).toBeGreaterThan(-1);
            });

        });
        it("Test 3: getEverydayTemplates should return an array of templates. The number of templates should be equal to the number of objects for 'meta'.", function(){
            var templates = [],
            	meta = [];
            runs(function() {
            	meta = recognitionTemplates.getEveryday();
                util.getEverydayTemplates(meta, 'imgstore', 'imgversion', function(data) {
                	templates = data; 
                });
            }, 10);
            waitsFor(function(){
                return templates;
            }, 10);
            runs( function () {
                expect(templates.length).toBe(meta.length);
                expect(templates[0].ForeGroundBadgeUrl.length).toBeGreaterThan(0);
                expect(templates[0].BackGroundBadgeUrl.length).toBeGreaterThan(0);
            });

        });

        it("Test 4: getValuesTemplates should return an array of templates. The number of templates should be equal to the number of objects for 'meta'.", function(){
            var templates = [],
                meta = [],
                valuetemplates,
                templatesWithoutSubValues = [],
                templatesWithSubValues = [];
            runs(function() {
                valuetemplates = recognitionTemplates.getValue();
                meta = valuetemplates.Templates;
                util.getValuesTemplates(meta, 'imgstore', 'imgversion', function(data) {
                    templates = data;
                    templatesWithSubValues = templates.filter(function (template) {
                        return template.SubValues && template.SubValues.length > 0;
                    });
                    templatesWithoutSubValues = templates.filter(function (template) {
                        return !template.SubValues || template.SubValues.length === 0;
                    });
                });
            }, 10);
            waitsFor(function(){
                return templates;
            }, 10);
            runs( function () {
                expect(templates.length).toBe(meta.length);
                expect(templatesWithoutSubValues[0].ForeGroundBadgeUrl.length).toBeGreaterThan(0);
            });
        });
        it("Test 5: getEverydayTemplates should return an empty array of templates, if meta is empty array", function(){
            var templates = [],
                meta = [],
                val;
            runs(function() {
                meta = recognitionTemplates.getEveryday();
                util.getEverydayTemplates([], 'imgstore', 'imgversion', function(data) {
                    templates = data;
                    val = 'done';
                });
            });
            waitsFor(function(){
                return val;
            }, 2);
            runs(function () {
                expect(templates.length).toBe(0);
            });
        });
                //the below logics are moved to util 3/14
        // it('Test 6 getBadgeUrl should return url for the group badges', function (){
        //  scope.init();
        //  httpBackend.flush();
        //  scope.templates[0].ImageId = 'test';
        //  var ret = scope.getBadgeUrl(0);
        //  expect(ret.indexOf('group') !== -1).toBeTruthy();
        // });
        // it('Test 7 getBadgeUrl should return url for the original badges', function (){
        //  scope.init();
        //  httpBackend.flush();
        //  scope.templates[0].BackgroundFilename = 'test';
        //  var ret = scope.getBadgeUrl(0, "BackgroundFilename");
        //  expect(ret.indexOf('original') !== -1).toBeTruthy();
        // });


        //the below logics have been moved to util
        // it('Test 5 getRecImagePath should return url for the group badges', function (){
        //  var ret = scope.getRecImagePath('imageId','','groupId');
        //  expect(ret.indexOf('group') !== -1).toBeTruthy();
        // });
        // it('Test 6 getRecImagePath should return url for the original badges', function (){
        //  var ret = scope.getRecImagePath('imageId','filename','groupId');
        //  expect(ret.indexOf('original') !== -1).toBeTruthy();
        // });
        // it('Test 7 getRecImagePath should empty string', function (){
        //  var ret = scope.getRecImagePath('','','');
        //  expect(ret.length).toBe(0);
        // });


        // the below logics have been moved to util
        // it('Test 5 getBadgeUrl should return url for the group badges', function (){
        //  scope.init();
        //  httpBackend.flush();
        //  var ret = scope.getBadgeUrl(0);
        //  expect(ret.indexOf('group') !== -1).toBeTruthy();
        // });
        // it('Test 6 getBadgeUrl should return url for the original badges', function (){
        //  scope.init();
        //  httpBackend.flush();
        //  scope.templates[0].fileName = 'test';
        //  var ret = scope.getBadgeUrl(0, "ForegroundFilename");
        //  expect(ret.indexOf('original') !== -1).toBeTruthy();
        // });
    });
});
