define(function(){
    describe("filterBy spec -> ", function(){

        it("Test 1  should return array if match is found", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.filterBy('id', 1);
            expect(test[0].id).toBe(1);
            expect(test[0].id).toBe(1);
        });
        it("Test 2  should return empty array if no matching values found", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.filterBy('id', 2);

            expect(test.length).toBe(0);
        });
        it("Test 3  should return empty array if value is not passed", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.filterBy('id');
            expect(test.length).toBe(0);
        });
        it("Test 4 should return empty array if no params passed", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.filterBy();
            expect(test.length).toBe(0);
        });
        it("Test 5 should return empty array if no matching values found", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.filterBy(1, 'id');
            expect(test.length).toBe(0);
        });
        it("Test 6 should return array of 2 items", function(){
            var obj = [{id : 1, test: 'first'}, {id : 1, test: 'second'}, {id : 2, test: 'third'}],
                test = obj.filterBy('id', 1);
            expect(test.length).toBe(2);
            expect(test[1].test).toBe('second');
        });
    });
});