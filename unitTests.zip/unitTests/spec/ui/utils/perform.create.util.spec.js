define(['static/source/hgapp/util/perform-card-create-util',
	'unitTests/ui-mocks/perform.question.library.json',
	'unitTests/ui-mocks/perform.card.edit.json'], function(util, questLibrary, card){
    describe("Perform card create util spec", function(){
        var cardMock,
            questMock;
        beforeEach(function(){
			questMock = questLibrary.get();
			cardMock = card.get();
        });
        it("getAnswerTemplate should return empty array for AnswerSelectors if question.AnswerType is not in answer types array", function(){
            var question = {AnswerType: 'Paragraph'};
            waitsFor(function() {
                return util.getAnswerTemplate(question);
            }, 10);
            runs( function () {
                expect(question.AnswerSelectors.length).toBe(0);
            });

        });
        it("getAnswerTemplate should return empty array for AnswerSelectors if question.AnswerType is not in answer types array", function(){
            var question = {AnswerType: ''};
            waitsFor(function() {
                return util.getAnswerTemplate(question);
            }, 10);
            runs( function () {
                expect(question.AnswerSelectors.length).toBe(0);
            });
        });
        it("getAnswerTemplate should return empty array for AnswerSelectors if question.AnswerType is not in answer types array", function(){
            var question = {AnswerType: 'ScaleRating'};
            waitsFor(function() {
               return util.getAnswerTemplate(question);
            }, 10);
            runs( function () {
                expect(question.AnswerSelectors.length).toBe(1);
            });
        });
        it("getAnswerTemplate should return empty array for AnswerSelectors if question.AnswerType is not in answer types array", function(){
            var question = {AnswerType: 'RadioButton'};
            waitsFor(function() {
                return util.getAnswerTemplate(question);
            }, 10);
            runs( function () {
                expect(question.AnswerSelectors.length).toBe(1);
            });
        });
        it("getAnswerTemplate should return empty array for AnswerSelectors if question.AnswerType is not in answer types array", function(){
            var question = {AnswerType: 'CheckBox'};
            waitsFor(function() {
                return util.getAnswerTemplate(question);
            }, 100);
            runs( function () {
                expect(question.AnswerSelectors.length).toBe(1);
            });
        });
        it("getAnswerTemplate should return empty array for AnswerSelectors if question.AnswerType is not in answer types array", function(){
            var question = {AnswerType: 'Option'};
            waitsFor(function() {
                return util.getAnswerTemplate(question);
            }, 100);
            runs( function () {
                expect(question.AnswerSelectors.length).toBe(1);
            });
        });
        it("should set selected first question in question array", function(){
            var ret;
            runs(function() {
                ret = util.setSelectedQuest(questMock, '5e262cd1-26f5-11e3-895a-4b3c71e041ac');
            });
            waitsFor(function(){
                return ret;
            }, 10);
            runs(function() {
                expect(ret[0].selected).toBeTruthy();
                expect(ret[1].selected).toBeFalsy();
            });

        });
        it("should set selected second question in question array", function(){
            var ret;
            runs(function() {
                ret = util.setSelectedQuest(questMock, '5e26a200-26f5-11e3-895a-4b3c71e041ac');
            });
            waitsFor(function(){
                return ret;
            }, 10);

            runs(function() {
                expect(ret[1].selected).toBeTruthy();
                expect(ret[0].selected).toBeFalsy();
            });
        });
        it("shouldn't select any questions", function(){
            var ret;
            runs(function() {
                ret = util.setSelectedQuest(questMock);
            });
            waitsFor(function(){
                return ret;
            }, 10);
            runs(function() {
                expect(ret[1].selected).toBeFalsy();
                expect(ret[0].selected).toBeFalsy();
            });

        });
        it("should return se question in question array", function(){
            var test;
            runs(function(){
                questMock[0].selected = true;
                test = util.getSelectedQuest(questMock);
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test.selected).toBeTruthy();
                expect(test.hgId).toBe('5e262cd1-26f5-11e3-895a-4b3c71e041ac');
                expect(test.Category).toBeTruthy('Advocating Causes');
            });

        });
        it("should return second question in question array", function(){
            var test;
            runs(function(){
                questMock[1].selected = true;
                test = util.getSelectedQuest(questMock);
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test.selected).toBeTruthy();
                expect(test.hgId).toBe('5e26a200-26f5-11e3-895a-4b3c71e041ac');
                expect(test.Category).toBeTruthy('Analysis/Reasoning');
            });

        });
        it("shouldn't select any questions", function(){

            var test;
            runs(function(){
                questMock[1].selected = false;
                questMock[0].selected = false;
                test = util.getSelectedQuest(questMock);
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test.hgId).toBeUndefined();
            });

        });
        it("should return empty array when getFilteredQuestions is called and filter is undefined", function(){
            var test;
            runs(function(){
                test = util.getFilteredQuestions(questMock);
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test).toBeDefined();
                expect(test.length).toBe(0);
            });
        });
        it("should return array of 4 element when getFilteredQuestions is called and filter is ScaleRating", function(){
            var test;
            runs(function(){
                test = util.getFilteredQuestions(questMock, 'ScaleRating');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test).toBeDefined();
                expect(test[0].AnswerType).toBe('ScaleRating');
                expect(test.length).toBe(4);
            });
        });
        it("should return array of 2 elements when getFilteredQuestions is called and filter is SomethingElse", function(){
            var test;
            runs(function(){
                test = util.getFilteredQuestions(questMock, 'SomethingElse');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test).toBeDefined();
                expect(test[0].AnswerType).toBe('SomethingElse');
                expect(test.length).toBe(2);
            });
        });
        it("should return array of 4 element when getFilteredQuestions is called and filter is ScaleRating", function(){
            var test;
            runs(function(){
                test = util.getFilteredQuestions(questMock, 'ScaleRating');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test).toBeDefined();
                expect(test[0].AnswerType).toBe('ScaleRating');
                expect(test.length).toBe(4);
            });
        });
        it("should return array of 0 elements when getCategoryList is called and filter is null", function(){
            var test;
            runs(function(){
                test = util.getCategoryList(questMock);
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test).toBeDefined();
                expect(test.length).toBe(0);
            });
        });
        it("should return array of 4 elements when getCategoryList is called and filter is ScaleRating", function(){
            var test;
            runs(function(){
                test = util.getCategoryList(questMock, 'ScaleRating');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test[0]).toBe('Advocating Causes');
                expect(test[3]).toBe('Writing');
                expect(test.length).toBe(4);
            });
        });
        it("should return array of 1 element when getCategoryList is called and filter is SomethingElse", function(){
            var test;
            runs(function(){
                test = util.getCategoryList(questMock, 'SomethingElse');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test[0]).toBe('Writing');
                expect(test[1]).toBe('Thinking');
                expect(test.length).toBe(2);
            });
        });
        it("should return array of 2 elements when getAnswerTypeList", function(){
            var test;
            runs(function(){
                test = util.getAnswerTypeList(questMock);
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test[0]).toBe('ScaleRating');
                expect(test[1]).toBe('SomethingElse');
                expect(test.length).toBe(2);
            });
        });
        it("should return array of 0 elements when getAnswerTypeList when passing empty array", function(){
            var test;
            runs(function(){
                test = util.getAnswerTypeList([]);
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test.length).toBe(0);
            });
        });
        it("should set second elements property selected in the questMock array to false", function(){
            var test;
            runs(function(){
                questMock[1].selected = true;
                expect(questMock[1].selected).toBeTruthy();
                test = util.removeQuest(questMock, '5e26a200-26f5-11e3-895a-4b3c71e041ac');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test[1].selected).toBeFalsy();
                expect(test[1].hgId).toBe('5e26a200-26f5-11e3-895a-4b3c71e041ac');
            });
        });
        it("getDefaultAnswers should return array of 5 elements when value 'ScaleRating' is passed", function(){
            var test;
            runs(function(){
                test = util.getDefaultAnswers('ScaleRating');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test.length).toBe(5);
                expect(test[0].Text).toBe('Strongly Disagree');
                expect(test[0].Value).toBe(1);
                expect(test[4].Text).toBe('Strongly Agree');
                expect(test[4].Value).toBe(5);
            });
        });
        it("getDefaultAnswers should return empty array when value 'Blah' is passed", function(){
            var test;
            runs(function(){
                test = util.getDefaultAnswers('Blah');
            });
            waitsFor(function(){
                return test;
            }, 10);
            runs(function(){
                expect(test.length).toBe(0);
            });
        });
		it("should set focus of the first elements property focus to true and and second element to false", function(){
			var test;
			runs(function(){
				cardMock.QnSs[1].focus = true;
				expect(cardMock.QnSs[1].focus).toBeTruthy();
				expect(cardMock.QnSs[0].hgId).toBe("72a3c131-101c-11e3-bba0-8d9c8faa9d96");
				expect(cardMock.QnSs[1].hgId).toBe("72a3c132-101c-11e3-bba0-8d9c8faa9d96");
				test = util.moveUp(cardMock.QnSs, 1);
			});
			waitsFor(function(){
				return test;
			}, 10);
			runs(function(){
				expect(test[1].hgId).toBe("72a3c131-101c-11e3-bba0-8d9c8faa9d96");
				expect(test[0].hgId).toBe("72a3c132-101c-11e3-bba0-8d9c8faa9d96");
				expect(test[0].focus).toBeTruthy();
				expect(test[1].focus).toBeFalsy();
			});
		});
		it("should set focus of the first elements property focus to false and and second element to true", function(){
			var test;
			runs(function(){
				cardMock.QnSs[0].focus = true;
				expect(cardMock.QnSs[0].focus).toBeTruthy(true);
				expect(cardMock.QnSs[1].focus).toBeFalsy(false);
				expect(cardMock.QnSs[0].hgId).toBe("72a3c131-101c-11e3-bba0-8d9c8faa9d96");
				expect(cardMock.QnSs[1].hgId).toBe("72a3c132-101c-11e3-bba0-8d9c8faa9d96");
				test = util.moveDown(cardMock.QnSs, 0);
			});
			waitsFor(function(){
				return test;
			}, 10);
			runs(function(){
				expect(test[0].hgId).toBe("72a3c132-101c-11e3-bba0-8d9c8faa9d96");
				expect(test[1].hgId).toBe("72a3c131-101c-11e3-bba0-8d9c8faa9d96");
				expect(test[0].focus).toBeFalsy();
				expect(test[1].focus).toBeTruthy();
			});
		});
    });
});