define(function(){
    describe("spliceBy spec -> ", function(){

        it("Test 1 should remove 1 element", function(){
            var obj = [{id : 1, test: 'test'}],
                test = obj.spliceBy('id', 1);
            expect(test.length).toBeFalsy();
        });
        it("Test 2 should not remove any", function(){
            var obj = [{id : 2, test: 'test'}],
                test = obj.spliceBy('id', 1);
            expect(test.length).toBe(1);
        });
        it("Test 3 should not remove any", function(){
            var obj = [{id : 2, test: 'test'}],
                test = obj.spliceBy('id');
            expect(test.length).toBe(1);
        });
        it("Test 4 should remove only one matching element", function(){
            var obj = [{id : 2, test: 'test'}, {id : 1, test: 'test'}, {id : 2, test: 'test'}],
                test = obj.spliceBy('id', 2);
            expect(test.length).toBe(2);
        });
        it("Test 5 should not remove any ", function(){
            var obj = [{id : 2, test: 'test'}],
                test = obj.spliceBy();
            expect(test.length).toBe(1);
        });
    });
});