define(['static/source/core/prototypes'],function(){
    describe("Number spec -> ", function(){

        it("Test 1 ", function(){
            var test = 1;
            expect(test.between(0, 19)).toBeTruthy();
        });
        it("Test 2 ", function(){
            var test = 100;
            expect(test.between(0, 19)).toBeFalsy();
        });
        it("Test 2 ", function(){
            var test = 100;
            expect(test.isIn([0, 19])).toBeFalsy();
        });
        it("Test 2 ", function(){
            var test = 100;
            expect(test.isIn([0, 19, 100])).toBeTruthy();
        });
    });
});