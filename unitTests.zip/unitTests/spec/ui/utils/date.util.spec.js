define(['static/source/hgapp/util/dateUtil'], function(util){
    describe("date util spec -> ", function(){

        it("Test 1  ", function(){
            var date = new Date();
            test = util.getDiff(date);
            expect(test.weeks).toBe(0);
            expect(test.days).toBe(0);
            expect(test.month).toBe(0);
            expect(test.today).toBeTruthy();
        });
        it("Test 2  ", function(){
            var d = new Date(),
                date = new Date(d.setDate(d.getDate() - 5));
            test = util.getDiff(date);
            expect(test.past).toBeTruthy();
            expect(test.days).toBe(5);
            expect(test.singular).toBeFalsy();
        });
        it("Test 3  ", function(){
            var d = new Date(),
                date = new Date(d.setMonth(d.getMonth() - 5));
            test = util.getDiff(date);
            expect(test.past).toBeTruthy();
            expect(test.singular).toBeFalsy();
            expect(test.month).toBe(4);
        });
        it("Test 4  ", function(){
            var d = new Date(),
                date = new Date(d.setDate(d.getDate() - 14));
            test = util.getDiff(date);
            expect(test.past).toBeTruthy();
            expect(test.weeks).toBe(2);
            expect(test.singular).toBeFalsy();
        });
        it("Test 5  ", function(){
            var d = new Date(),
                date = new Date(d.setMonth(d.getMonth() - 14));
            test = util.getDiff(date);
            expect(test.past).toBeTruthy();
            expect(test.years).toBe(1);
            expect(test.singular).toBeTruthy();
        });

        it("Test 6  ", function(){
            var d = new Date(),
                date = new Date(d.setDate(d.getDate() + 5));
            test = util.getDiff(date);
            expect(test.future).toBeTruthy();
            expect(test.days).toBe(5);
            expect(test.singular).toBeFalsy();
        });
        it("Test 7  ", function(){
            var d = new Date(),
                date = new Date(d.setDate(d.getDate() + 14));
            test = util.getDiff(date);
            expect(test.future).toBeTruthy();
            expect(test.weeks).toBe(2);
            expect(test.singular).toBeFalsy();
        });
        it("Test 8  ", function(){
            var d = new Date(),
                date = new Date(d.setMonth(d.getMonth() + 3));
            test = util.getDiff(date);
            expect(test.future).toBeTruthy();
            expect(test.singular).toBeFalsy();
            expect(test.month).toBe(2);
        });
        it("Test 9  ", function(){
            var d = new Date(),
                date = new Date(d.setMonth(d.getMonth() + 14));
            test = util.getDiff(date);
            expect(test.future).toBeTruthy();
            expect(test.years).toBe(1);
            expect(test.singular).toBeTruthy();
        });

    });
});