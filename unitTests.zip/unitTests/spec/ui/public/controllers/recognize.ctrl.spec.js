define([
    'unitTests/ui-mocks/public.recog.json',
    'unitTests/ui-mocks/user.json',
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'public-app'], function(mock, userJson, cache){
    describe('Recognise public controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            publicRecognitionSrvc,
            userSrvc;

        beforeEach(module("public-app"));
        beforeEach(module("public-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, PublicRecognitionSrvc, UserSrvc) {
            rootScope = $rootScope;
            publicRecognitionSrvc = PublicRecognitionSrvc;
            userSrvc = UserSrvc;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/PublicRecognition/GetPublicUserInfoByMemberId?mId=foo')
                .respond(200, mock.GetPublicUserInfoByMemberId());
            httpBackend.whenPOST('/svc/PublicRecognition/GetTemplatesForMember')
                .respond(200, mock.getTemplates());
            httpBackend.whenPOST('/svc/PublicRecognition/GetRecognitionMessageTemplates')
                .respond(200, mock.messages());
            
            routeParams.userGuid = 'foo';
            cache.clear('user');
            scope = $rootScope.$new();
            ctrl = $controller('PublicRecognizeCtrl', {
                $scope: scope
            });
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2: Init should call backend', function () {
            spyOn(publicRecognitionSrvc, 'getPublicUserInfo').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(publicRecognitionSrvc.getPublicUserInfo).toHaveBeenCalled();
        });
        it('Test 3: On clear, the form should be cleared', function () {
            var defaultRecog = {
                TemplateIds: [],
                RecipientMemberIds: ['foo'],
                CompanyRating: 0,
                MemberRating: 0,
                Email: ''
            };
            scope.init();
            httpBackend.flush();
            scope.recognition = {
                FullName: "Amie Chen",
                CompanyName: "Example, Inc",
                Email: "hi@example.com",
                Message: "Cat General has some fuzzy problems",
                CompanyRating: "5",
                MemberRating: "4"
            };
            scope.Clear();
            expect(scope.recognition).toEqual(defaultRecog);
        });
    });
});