define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'public-app'], function(mock, userJson, cache){
    describe('Forgot password controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            backend,
            routeParams,
            location,
            userSrvc;

        beforeEach(module("public-app"));
        beforeEach(module("public-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, UserSelfSrvc) {
            rootScope = $rootScope;
            userSrvc = UserSelfSrvc;
            routeParams = $routeParams;
            backend = $injector.get("$httpBackend");
            location = $injector.get("$location");
            backend.whenPOST('/svc/User/RequestResetPassword')
                .respond(200, {});
            scope = $rootScope.$new();
            ctrl = $controller('PasswordForgotCtrl', {
                $scope: scope
            });
        }));
        afterEach(function () {
           scope.$digest();
            backend.verifyNoOutstandingExpectation();
            backend.verifyNoOutstandingRequest();
        });
        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2: validation should return invalid request', function () {
            expect(scope.validate({}).invalid).toBeTruthy();
        });
        it('Test 3: validation should return valid request', function () {
            expect(scope.validate({persistEmail: 'test'}).invalid).toBeFalsy();
        });
        it('Test 4: it should not call user service', function () {
            spyOn(userSrvc, 'forgotPassword').andCallThrough();
            scope.submit({});
            expect(userSrvc.forgotPassword).not.toHaveBeenCalled();
        });
        it('Test 5: it should call user service and redirect user', function () {
            spyOn(userSrvc, 'forgotPassword').andCallThrough();
            spyOn(location, 'path').andCallFake(angular.noop);
            scope.submit({persistEmail: 'test'});
            backend.flush();
            expect(userSrvc.forgotPassword).toHaveBeenCalledWith({UserName: 'test'});
            expect(location.path).toHaveBeenCalledWith('/PasswordResetEmail/test');
        });
    });
});