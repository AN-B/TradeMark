define([
    'unitTests/ui-mocks/api.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'
], function (apiJson) {
    describe('Provisioning Company API Controller Spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            provisionApiSrvc;

        beforeEach(module('provision-app'));
        beforeEach(module('provision-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, ProvisioningApiSrvc) {
            provisionApiSrvc = ProvisioningApiSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            httpBackend.whenGET('/svc/API/GetAvailableServices')
                .respond(200, apiJson.getAvailableServices());
            httpBackend.whenGET('/svc/API/GetClientAPIKeys?groupId=foobar')
                .respond(200, apiJson.getClientAPIKeys());
            httpBackend.whenPOST('/svc/API/CreateAPISettings')
                .respond(200, apiJson.getNewAPIKey());
            httpBackend.whenPOST('/svc/API/UpdateClientAPISettings')
                .respond(200, {});  //empty object for now, but it returns the updated key

            ctrl = $controller('ProvisioningCompanyAPISettingsCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 provisioning api controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2 should have list of available services after init', function () {
            scope.init();
            httpBackend.flush();
            expect(scope.availableServices).toBeDefined();
            expect(scope.availableServices).toEqual(apiJson.getAvailableServices());
        });

        it('Test 3 setting groupId should get list of current keys', function () {
            scope.GroupId = 'foobar';
            httpBackend.flush();
            expect(scope.APIKeys).toBeDefined();
            expect(scope.APIKeys).toEqual(apiJson.getClientAPIKeys());
        });

        it('Test 4 generate new key should add to existing APIKeys', function () {
            scope.GroupId = 'foobar';
            httpBackend.flush();
            expect(scope.APIKeys).toBeDefined();
            expect(scope.APIKeys).toEqual(apiJson.getClientAPIKeys());

            scope.newKeyVersion = '1.0';
            scope.newKeyServices = ['default'];
            scope.generateNewKey();
            httpBackend.flush();
            expect(scope.APIKeys.length).toBe(2);
            expect(scope.APIKeys[1]).toEqual(apiJson.getNewAPIKey());
        });

        it('Test 5 should update key and get list of current keys', function () {
            scope.GroupId = 'foobar';
            httpBackend.flush();
            expect(scope.APIKeys).toBeDefined();
            expect(scope.APIKeys).toEqual(apiJson.getClientAPIKeys());

            scope.updateAPIKey(0);
            httpBackend.flush();
            expect(scope.APIKeys).toBeDefined();
            expect(scope.APIKeys).toEqual(apiJson.getClientAPIKeys());
        })
    });

});