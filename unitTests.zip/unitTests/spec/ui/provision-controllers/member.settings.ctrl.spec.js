define(['angular',
        'angular-mocks',
        'angular-resource',
        'provision-app'],
    function () {
        describe('Provisioning Member Settings edit controller spec ->', function() {
            var memberSettingsSrvc,
                memberService,
                backend,
                scope,
                rootScope,
                location,
                toast,
                timeout,
                ctrl;

            beforeEach(module("provision-app"));
            beforeEach(inject(function ($controller, $rootScope, $location, $injector, ProvisioningMemberSettingsSrvc, provisionMemberSrvc, ToastrSrvc) {
                backend = $injector.get("$httpBackend");
                timeout = $injector.get("$timeout");
                memberSettingsSrvc = ProvisioningMemberSettingsSrvc;
                memberService = provisionMemberSrvc;
                toast = ToastrSrvc;
                rootScope = $rootScope;
                scope = rootScope.$new();
                location = $location;
                ctrl = $controller('ProvisioningMemberSettingsCtrl', {
                    $scope: scope
                });

                backend.whenGET('/svc/GlobalAdmin/GetAllPermissions/')
                    .respond(200, [{Description: "1 Permission", MemberPermission: "OffBoarded", Name: "OffBoarded", SecuredTabs: {}}]);
                backend.whenPOST('/svc/Group/SetRolesAndPermissionsForMembers').respond(200, 'hello');
                backend.whenPOST('/svc/Member/GetMembersPermissionsByMemberIds').respond(200, {RemovedPermissions: {test: true, test2: true}, AddedPermissions: {rest: true}});

            }));
            afterEach(function () {
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });

            it('Test 1: Controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2: init should initialize model', function (){
                var model = {};
                scope.init(model);
                backend.flush();
                expect(model.group).toBeDefined();
                expect(model.permissions).toBeDefined();
            });
            it('Test 3: clear should remove members ids', function (){
                var model = scope.clear({request: {memberIds:['Bob']}});
                expect(model.request.memberIds.length).toBeFalsy();
            });
            it('Test 4: removePermission remove object from the array', function (){
                var test = scope.removePermission('Bob', [{Name: 'Bob'}]);
                expect(test.length).toBeFalsy();
            });
            it('Test 5: selectPermission add object from the array', function (){
                var test = scope.selectPermission({Name: 'Bob'} , []);
                expect(test.length).toBe(1);
            });
            it('Test 6: selectPermission should not add object from the array if object exists in the array', function (){
                var test = scope.selectPermission({Name: 'Bob'} , [{Name: 'Bob'}]);
                expect(test.length).toBe(1);
            });
            it('Test 7: updatePermissions update permissions', function (){
                spyOn(memberSettingsSrvc, 'updateMemberPermissions').andCallThrough();
                spyOn(toast, 'success').andCallThrough();
                var model = {groupId: 'test', request: {addPermissions: [{Name: "test"}], removePermissions: [{Name: 'test1'}], memberIds: ['test']}};
                scope.updatePermissions(model);
                backend.flush();
                expect(model.request.memberIds.length).toBeFalsy();
                expect(memberSettingsSrvc.updateMemberPermissions).toHaveBeenCalled();
                expect(toast.success).toHaveBeenCalledWith('hello');
            });
            it('Test 8: group.onSelect should initialize user', function (){
                var model = {};
                scope.init(model);
                backend.flush();
                model.group.onSelect({Id: 'test'});
                expect(model.user).toBeDefined();
                expect(model.groupId).toBe('test');
                expect(model.request.memberIds).toBeDefined();
            });
            it('Test 9: group.onSelect should clear  model', function (){
                var model = {};
                scope.init(model);
                backend.flush();
                model.group.deSelect();
                expect(model.user).not.toBeDefined();
                expect(model.groupId).not.toBeDefined();
                expect(model.request).not.toBeDefined();
            });
            it('Test 10: group.onSelect should clear model', function (){
                var model = {};
                scope.init(model);
                backend.flush();
                model.group.deSelect();
                expect(model.user).not.toBeDefined();
                expect(model.groupId).not.toBeDefined();
                expect(model.request).not.toBeDefined();
            });
            it('Test 11: user.onSelect should initialize model', function (){
                spyOn(memberService, 'getMembersPermissions').andCallThrough();
                var model = {permissions: [{Name: 'test'}]};
                scope.clear(model);
                model.user.onSelect({Id: "Bob"});
                timeout.flush();
                backend.flush();
                expect(model.request.addPermissions.length).toBe(0);
                expect(model.request.removePermissions.length).toBe(1);
                expect(memberService.getMembersPermissions).toHaveBeenCalled();
            });
            it('Test 12: user.deSelect should clear model', function (){
                spyOn(memberService, 'getMembersPermissions').andCallThrough();
                var model = {permissions: [{Name: 'test'}], request: {memberIds: []}};
                scope.clear(model);
                model.request.memberIds = ["Bob", "Tod"];
                model.user.deSelect({Id: "Bob"});
                timeout.flush();
                backend.flush();
                expect(model.request.addPermissions.length).toBe(0);
                expect(model.request.removePermissions.length).toBe(1);
                expect(memberService.getMembersPermissions).toHaveBeenCalled();
            });
            it('Test 13: user.deSelect should clear model', function (){
                spyOn(memberService, 'getMembersPermissions').andCallThrough();
                var model = {permissions: [{Name: 'test'}], request: {memberIds: []}};
                scope.clear(model);
                model.request.memberIds = ["Bob"];
                model.user.deSelect({Id: "Bob"});
                expect(memberService.getMembersPermissions).not.toHaveBeenCalled();
            });
        });
    });