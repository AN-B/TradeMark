define([
    'unitTests/ui-mocks/permissions.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'
], function (permissionsJson) {
    describe('Provisioning Role Controller Spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            ProvisioningRoleSettingsService,
            ProvisioningMemberSettingsService,
            ProvisioningCompanySettingsService;

        beforeEach(module('provision-app'));
        beforeEach(module('provision-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, ProvisioningRoleSettingsSrvc, ProvisioningMemberSettingsSrvc, ProvisioningCompanySettingsSrvc) {
            ProvisioningRoleSettingsService = ProvisioningRoleSettingsSrvc;
            ProvisioningMemberSettingsService= ProvisioningMemberSettingsSrvc;
            ProvisioningCompanySettingsService = ProvisioningCompanySettingsSrvc;

            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            httpBackend.whenGET('/svc/GlobalAdmin/GetAllPermissions/')
                .respond(200, permissionsJson.getMemberPermission());
            httpBackend.whenGET('/svc/GlobalAdmin/GetRolesPermissionsTabs/')
                .respond(200, permissionsJson.getRolesPermissionsTabs());
            httpBackend.whenPOST('/svc/Group/AddRolePermission')
                .respond(200, {message: 'Permission(s) for role updated.'});

            ctrl = $controller('ProvisioningRolePermissionSettingsCtrl', {$scope: scope});

        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Provisioning role setting controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: should have list of available permissions after init', function (){
            spyOn(ProvisioningMemberSettingsService, 'getPermissions').andCallThrough();
            spyOn(ProvisioningCompanySettingsService, 'getRolesPermissionsTabs').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(ProvisioningMemberSettingsService.getPermissions).toHaveBeenCalled();
            expect(scope.Roles).toEqual([]);
        });

        it('Test 3 should call addNewPermissions', function () {
            scope.model = {Selected: true};
            scope.model.GroupId = '3cf21720-9cd2-11e2-a3a4-25024474fe63';
            scope.listAddedPermissions = [{"Name": "AdminReports"}];
            scope.Roles = permissionsJson.getRolesPermissionsTabs().Roles;
            scope.Roles[0].selected = true;
            spyOn(ProvisioningRoleSettingsService, 'addRolePermissions').andCallThrough();
            scope.addNewPermissions();
            httpBackend.flush();
            expect(ProvisioningRoleSettingsService.addRolePermissions).toHaveBeenCalled();
        });

        it('Test 4 should select role', function () {
            scope.model.GroupId = '3cf21720-9cd2-11e2-a3a4-25024474fe63';
            scope.Roles = permissionsJson.getRolesPermissionsTabs().Roles;
            spyOn(ProvisioningMemberSettingsService, 'getPermissions').andCallThrough();
            spyOn(ProvisioningCompanySettingsService, 'getRolesPermissionsTabs').andCallThrough();
            scope.init();
            httpBackend.flush();
            scope.toggleRole('Employee');
            expect(scope.model.Selected).toBe(true);
            expect(scope.Roles[scope.Roles.objectIndexOf('Employee', 'Role')].selected).toBe(true);
        });
        it('Test 5 should deselect role', function () {
            scope.model.GroupId = '3cf21720-9cd2-11e2-a3a4-25024474fe63';
            scope.Roles = permissionsJson.getRolesPermissionsTabs().Roles;
            scope.toggleRole('Employee');
            scope.toggleRole('Manager');
            expect(scope.Roles[scope.Roles.objectIndexOf('Employee', 'Role')].selected).toBe(undefined);
            expect(scope.Roles[scope.Roles.objectIndexOf('Manager', 'Role')].selected).toBe(true);
            
        });
        it('Test 6 should remove Permission', function () {
            scope.listAddedPermissions = [{"Id": "AdminReports"}, {"Id": "Test1"}];
            scope.removePermission('Test1');
            expect(scope.listAddedPermissions.length).toBe(1);

        });
        it('Test 7 should add Permission', function () {
            scope.listAddedPermissions = [{"Id": "AdminReports", "Name": "AdminReports", "Description": "Permissions specific to off-boarded users"}];
            scope.PermissionDesc['Basic'] = "Permissions specific to Basic users";
            scope.onSelectPermission('Basic');
            expect(scope.listAddedPermissions.length).toBe(2);
        });
    });
});