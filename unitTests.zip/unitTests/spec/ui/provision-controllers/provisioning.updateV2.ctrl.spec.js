define([
    'angular',
    'angular-resource',
    'provision-app'
], function () {
    describe('Provisioning Update V2 Controller Spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            routeParams,
            toastrSrvc;

        beforeEach(module('provision-app'));
        beforeEach(module('provision-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, ToastrSrvc) {
            httpBackend = $injector.get('$httpBackend');
            rootScope = $rootScope;
            scope = $rootScope.$new();
            toastrSrvc = ToastrSrvc;
            routeParams = $injector.get("$routeParams");
            ctrl = $controller('ProvisioningUpdateV2Ctrl', {
                $scope: scope
            });
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning Update V2 setting controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 check template File path', function () {
            expect(scope.templateFilePath.indexOf(rootScope.imageStore[0] + '/files/ProvisionUpdate-Template.xlsx')).toBeGreaterThan(-1);
        });
        it('Test 3 upload completion', function () {
            spyOn(toastrSrvc, 'success').andCallThrough();
            scope.completeFunction('test.xlsx');
            expect(toastrSrvc.success).toHaveBeenCalledWith('test.xlsx Successfully Uploaded.');
        });
        it('Test 4 load with route', function () {
            routeParams.Id = '11111';
            scope.init();
            expect(scope.options).toBeDefined();
            expect(scope.options.url).toBe('/svc/Provision/UpdateGroup?groupId=11111');
        });
        it('Test 5 test groupSelected', function () {
            scope.search.groupMeta.onSelect({Id: 'test'});
            expect(scope.search.groupMeta.groupId).toBe('test');
        });
        it('Test 6 test groupDeSelected', function () {
            scope.search.groupMeta.deSelect('test');
            expect(scope.search.groupMeta.groupId).not.toBeDefined();
        });
    });
});