define([
    'unitTests/ui-mocks/useractivity.metrics.mock',
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'], function(useractivityMetricsMock) {

    describe('Provisioning metrics user activity controller spec ->', function () {
        var scope,
            ctrl,
            httpBackend,
            metricsSrvc,
            rootScope,
            win,
            startDate,
            endDate;

        beforeEach(module("provision-app"));
        beforeEach(module("provision-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, MetricsSrvc) {
            httpBackend = $injector.get("$httpBackend");
            win = $injector.get("$window");
            win.Highcharts = {
                Chart : function () {
                    return {
                        sum: function(arg) {}
                    };
                }
            };
            metricsSrvc = MetricsSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            ctrl = $controller('ProvisioningMetricsUserActivityCtrl', {$scope: scope});

            var today = new Date();
            today.setMonth(today.getMonth() -1);
            startDate = new Date(today);
            endDate = new Date();
            startDate = [startDate.getMonth() + 1, "/", startDate.getDate(), "/", startDate.getFullYear()].join('');
            endDate = [endDate.getMonth() + 1, "/", endDate.getDate(), "/", endDate.getFullYear()].join('');
            httpBackend.whenGET(new RegExp('/svc/Metrics/GetUserActivityPctMetrics'))
                .respond(200, useractivityMetricsMock.getGeneralUerActivityMetrics());
            scope.PageOptions = {};
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning metrics user activity controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2: Init should call backend and retrieve user activity metrics', function () {
            spyOn(metricsSrvc, 'getHighcharts').andCallThrough();
            spyOn(metricsSrvc, 'getUserActivityPctMetrics').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.Summary).toBeDefined();
            expect(metricsSrvc.getHighcharts).toHaveBeenCalled();
            expect(metricsSrvc.getUserActivityPctMetrics).toHaveBeenCalled();
        });
        it('Test 3: dateOptions onSelect should be called and retrieve user activity metrics', function () {
            scope.init();
            httpBackend.flush();
            scope.Summary = null;
            spyOn(metricsSrvc, 'getUserActivityPctMetrics').andCallThrough();
            scope.PageOptions.StartDate = new Date(startDate);
            scope.PageOptions.EndDate = new Date(endDate);
            scope.datepickerOpts1.onSelect();
            httpBackend.flush();
            expect(scope.Summary).toBeDefined();
            expect(metricsSrvc.getUserActivityPctMetrics).toHaveBeenCalled();
        });
        it('Test 4: groupMeta onSelect should be called with a group id and retrieve user activity metrics', function () {
            scope.init();
            httpBackend.flush();
            scope.Summary = null;
            spyOn(metricsSrvc, 'getUserActivityPctMetrics').andCallThrough();
            scope.PageOptions.StartDate = new Date(startDate);
            scope.PageOptions.EndDate = new Date(endDate);
            scope.groupMeta.onSelect({
                Id: '3cf21720-9cd2-11e2-a3a4-25024474fe63'
            });
            httpBackend.flush();
            expect(scope.Summary).toBeDefined();
            expect(metricsSrvc.getUserActivityPctMetrics).toHaveBeenCalled();
        });
        it('Test 5: groupMeta deselect should be called and retrieve user activity metrics', function () {
            scope.init();
            httpBackend.flush();
            scope.Summary = null;
            spyOn(metricsSrvc, 'getUserActivityPctMetrics').andCallThrough();
            scope.PageOptions.StartDate = new Date(startDate);
            scope.PageOptions.EndDate = new Date(endDate);
            scope.groupMeta.deSelect();
            httpBackend.flush();
            expect(scope.Summary).toBeDefined();
            expect(metricsSrvc.getUserActivityPctMetrics).toHaveBeenCalled();
        });
    });
});