define([
        'unitTests/ui-mocks/tutorial.json',
        'static/source/core/collectionCache',
        'angular',
        'angular-mocks',
        'angular-resource',
        'provision-app'],
    function (tutorialJson, cache) {
        describe('Tutorial summary controller spec ->', function() {
            var provisioningTutorialService,
                httpBackend,
                scope,
                rootScope,
                location,
                ctrl;

            beforeEach(module("provision-app"));
            beforeEach(inject(function ($controller, $rootScope, $location, $injector, ProvisioningTutorialSrvc) {
                httpBackend = $injector.get("$httpBackend");
                provisioningTutorialService = ProvisioningTutorialSrvc;
                rootScope = $rootScope;
                scope = rootScope.$new();
                location = $location;
                ctrl = $controller('ProvisioningTutorialSummaryCtrl', {
                    $scope: scope
                });
                httpBackend.whenGET('/svc/Tutorial/GetTutorialStepsAll')
                    .respond(200, {});
                httpBackend.whenPOST('/svc/Tutorial/DeleteTutorialStep')
                    .respond(200, 'Tutorial step successfully deleted.');
            }));
            afterEach(function () {
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('1. Tutorial summary controller should exist', function (){
                expect(ctrl).toBeDefined();
            });

            it('2. init should call getTutorialStepsAll', function () {
                spyOn(provisioningTutorialService, 'getTutorialStepsAll').andCallThrough();
                scope.init();
                httpBackend.flush();
                expect(provisioningTutorialService.getTutorialStepsAll).toHaveBeenCalled();
            });

            it('3. deleteTutorialStep should call deleteTutorialStep svc', function () {
                scope.tutorials = [{stepNumber:1},{stepNumber:1},{stepNumber:1}];
                scope.selectedStep = {hgId: '639ea0f1-340c-4beb-ab1d-b3410cca061d'};
                spyOn(provisioningTutorialService, 'deleteTutorialStep').andCallThrough();
                scope.deleteTutorialStep();
                httpBackend.flush();
                expect(provisioningTutorialService.deleteTutorialStep).toHaveBeenCalled();
            });
        });
    });