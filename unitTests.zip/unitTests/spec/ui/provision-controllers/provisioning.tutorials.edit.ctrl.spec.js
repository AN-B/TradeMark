define([
        'unitTests/ui-mocks/tutorial.json',
        'static/source/core/collectionCache',
        'angular',
        'angular-mocks',
        'angular-resource',
        'provision-app'],
    function (tutorialJson, cache) {

        describe('Tutorial edit controller spec ->', function() {
            var provisioningTutorialService,
                httpBackend,
                scope,
                rootScope,
                location,
                ctrl;

            beforeEach(module("provision-app"));
            beforeEach(inject(function ($controller, $rootScope, $location, $injector, ProvisioningTutorialSrvc) {
                httpBackend = $injector.get("$httpBackend");
                provisioningTutorialService = ProvisioningTutorialSrvc;
                rootScope = $rootScope;
                scope = rootScope.$new();
                location = $location;
                ctrl = $controller('ProvisioningTutorialEditCtrl', {
                    $scope: scope
                });

                httpBackend.whenGET('/svc/Tutorial/GetTutorialStepsAll')
                    .respond(200, [{stepName:1},
                        {stepName:2},
                        {stepName:3}]);
            }));
            afterEach(function () {
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('Tutorial summary controller should exist', function (){
                expect(ctrl).toBeDefined();
            });

            it('init should call getTutorialStepsAll svc', function () {
                spyOn(provisioningTutorialService, 'getTutorialStepsAll').andCallThrough();
                scope.init();
                httpBackend.flush();
                expect(provisioningTutorialService.getTutorialStepsAll).toHaveBeenCalled();
            });

//            it('', function () {
//
//            });

        });
    });