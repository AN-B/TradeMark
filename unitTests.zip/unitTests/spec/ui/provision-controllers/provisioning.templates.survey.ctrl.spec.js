define(['angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'
], function () {
    describe('Provisioning Template Survey Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend;

        beforeEach(module('provision-app'));
        beforeEach(module('provision-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            ctrl = $controller('ProvisioningTemplatesSurveyCtrl', {$scope: scope});
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Provisioning survey controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

    });
});