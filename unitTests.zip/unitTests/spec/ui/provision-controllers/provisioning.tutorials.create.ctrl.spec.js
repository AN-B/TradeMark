define([
        'unitTests/ui-mocks/tutorial.json',
        'static/source/core/collectionCache',
        'angular',
        'angular-mocks',
        'angular-resource',
        'provision-app'],
    function (tutorialJson, cache) {
        describe('Tutorial create controller spec ->', function() {
            var provisioningTutorialService,
                httpBackend,
                scope,
                rootScope,
                location,
                ctrl;

            beforeEach(module("provision-app"));
            beforeEach(inject(function ($controller, $rootScope, $location, $injector, ProvisioningTutorialSrvc) {
                httpBackend = $injector.get("$httpBackend");
                provisioningTutorialService = ProvisioningTutorialSrvc;
                rootScope = $rootScope;
                scope = rootScope.$new();
                location = $location;
                ctrl = $controller('ProvisioningTutorialCreateCtrl', {
                    $scope: scope
                });

                httpBackend.whenPOST('/svc/Tutorial/CreateTutorialStep')
                    .respond(200, {});
            }));
            afterEach(function () {
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('Tutorial create controller should exist', function (){
                expect(ctrl).toBeDefined();
            });

            it('submit should call createTutorialStep when form is valid', function () {
                scope.hgTutorialCreateForm = {};
                scope.hgTutorialCreateForm.$valid = true;
                scope.displayButtons = true;
                scope.tutorial = {stepNumber:1, name:'some tutorial'};
                spyOn(provisioningTutorialService, 'createTutorialStep').andCallThrough();
                scope.submit();
                httpBackend.flush();
                expect(provisioningTutorialService.createTutorialStep).toHaveBeenCalled();
                expect(scope.tutorial).toEqual({});
            });
        });
    });