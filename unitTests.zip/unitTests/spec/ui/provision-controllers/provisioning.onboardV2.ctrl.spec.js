define([
    'angular',
    'angular-resource',
    'provision-app'
], function () {
    describe('Provisioning Onboard V2 Controller Spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            toastrSrvc;

        beforeEach(module('provision-app'));
        beforeEach(module('provision-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, ToastrSrvc) {
            httpBackend = $injector.get('$httpBackend');
            rootScope = $rootScope;
            scope = $rootScope.$new();
            toastrSrvc = ToastrSrvc;
            ctrl = $controller('ProvisioningOnboardV2Ctrl', {
                $scope: scope
            });
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning Onboard V2 setting controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 check template File path', function () {
            expect(scope.templateFilePath.indexOf(rootScope.imageStore[0] + '/files/ProvisionOnBoard-Template.xlsx')).toBeGreaterThan(-1);
        });
        it('Test 3 upload completion', function () {
            spyOn(toastrSrvc, 'success').andCallThrough();
            scope.completeFunction('test.xlsx');
            expect(toastrSrvc.success).toHaveBeenCalledWith('test.xlsx Successfully Uploaded.');
        });
    });
});