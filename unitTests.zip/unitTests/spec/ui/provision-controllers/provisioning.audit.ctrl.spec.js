define([
    'unitTests/ui-mocks/audit.mock',
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'], function(auditMock) {

    describe('Provisioning audit controller spec ->', function () {
        var scope,
            ctrl,
            httpBackend,
            provisioningCompanySettingsSrvc,
            rootScope,
            startDate,
            endDate;

        beforeEach(module("provision-app"));
        beforeEach(module("provision-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProvisioningCompanySettingsSrvc) {
            httpBackend = $injector.get("$httpBackend");
            provisioningCompanySettingsSrvc = ProvisioningCompanySettingsSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            ctrl = $controller('ProvisioningAuditCtrl', {
                $scope: scope,
                $location: $injector.get("$location"),
                getAuditLogs: ProvisioningCompanySettingsSrvc.getMemberAuditLogs,
                getSearchTerms: ProvisioningCompanySettingsSrvc.getMemberRolesSearchTerms
            });
            startDate = new Date(1456120800000);
            endDate = new Date(1456207200000);
            httpBackend.whenGET('/svc/Provision/GetMemberRoles')
                .respond(200, ["OffBoarded", "Employee", "Manager", "Director", "Executive", "Admin", "Owner", "ResellerAdmin"])
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning audit controller should exist', function () {
            expect(ctrl).toBeDefined();
         });
        it('Test 2: it should set a group id when a group is selected', function () {
            scope.init();
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            expect(scope.search.userMeta.groupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            expect(scope.pageEnv.GroupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
        });
        it('Test 3: it should unset group ID if a group is deselected', function () {
            scope.init();
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            scope.search.groupMeta.deSelect();
            expect(scope.search.userMeta.groupId).not.toBeDefined();
            expect(scope.pageEnv.GroupId).not.toBeDefined();
            expect(scope.search.userMeta.selected.length).toBe(0);
        });
        it('Test 4: it should get member audit logs when a member is chosen', function () {
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&Skip=0&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(0, 30));
            scope.init();
            scope.pageEnv.EntityType = 'MemberRole';
            scope.pageEnv.ActivityType = 'MemberRoleChanged';
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            expect(scope.search.userMeta.groupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            expect(scope.pageEnv.GroupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            scope.search.userMeta.onSelect({
                RolesInGroup: ['Manager'],
                UserId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Id: '42b85af2-a8c5-11e5-82c9-49bc646720dd',
                Name: 'Tom Mitic',
                AvatarId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Description: 'Product Engineering',
                Type: 'Member'
            });
            httpBackend.flush();
            expect(scope.pageEnv.EntityId).toBe('42b85af2-a8c5-11e5-82c9-49bc646720dd');
            expect(scope.loaded).toBe(true);
            expect(scope.pageEnv.Take).toBe(30);
            expect(scope.AuditLogs.length).toBe(30);
            expect(scope.isMore).toBe(true);
        });
        it('Test 5: it should get all search terms for Member Roles', function () {
            httpBackend.whenGET('/svc/Provision/GetMemberRoles')
                .respond(200, auditMock.getMemberRoles());
            scope.getSearchTerms();
            httpBackend.flush();
            expect(scope.SearchTerms.length).toBe(8);

        });
        it('Test 6: it should get member audit logs with a search term', function () {
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&Skip=0&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(0, 30));
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&SearchTerm=Manager&Skip=0&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(31, 41));
            scope.init();
            scope.pageEnv.EntityType = 'MemberRole';
            scope.pageEnv.ActivityType = 'MemberRoleChanged';
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            expect(scope.search.userMeta.groupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            expect(scope.pageEnv.GroupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            scope.search.userMeta.onSelect({
                RolesInGroup: ['Manager'],
                UserId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Id: '42b85af2-a8c5-11e5-82c9-49bc646720dd',
                Name: 'Tom Mitic',
                AvatarId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Description: 'Product Engineering',
                Type: 'Member'
            });
            httpBackend.flush();
            scope.pageEnv.SearchTerm = 'Manager';
            scope.filterResults();
            httpBackend.flush();
            expect(scope.pageEnv.EntityId).toBe('42b85af2-a8c5-11e5-82c9-49bc646720dd');
            expect(scope.loaded).toBe(true);
            expect(scope.pageEnv.Take).toBe(0);
            expect(scope.AuditLogs.length).toBe(10);
            expect(scope.isMore).toBe(true);
            expect(scope.pageEnv.StartDate).toBeUndefined();
            expect(scope.pageEnv.EndDate).toBeUndefined();
        });
        it('Test 7: it should get member audit logs with a search term, start date and end date', function () {
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&Skip=0&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(0, 30));
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EndDate=2016-02-23T06:00:00.000Z&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&SearchTerm=Manager&Skip=0&StartDate=2016-02-22T06:00:00.000Z&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(31, 50));
            scope.init();
            scope.pageEnv.EntityType = 'MemberRole';
            scope.pageEnv.ActivityType = 'MemberRoleChanged';
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            expect(scope.search.userMeta.groupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            expect(scope.pageEnv.GroupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            scope.search.userMeta.onSelect({
                RolesInGroup: ['Manager'],
                UserId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Id: '42b85af2-a8c5-11e5-82c9-49bc646720dd',
                Name: 'Tom Mitic',
                AvatarId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Description: 'Product Engineering',
                Type: 'Member'
            });
            httpBackend.flush();
            scope.pageEnv.SearchTerm = 'Manager';
            scope.datePicker.EndDate = new Date('2016-02-23T06:00:00.000Z');
            scope.datePicker.StartDate = new Date('2016-02-22T06:00:00.000Z');
            scope.filterResults();
            httpBackend.flush();
            expect(scope.pageEnv.EntityId).toBe('42b85af2-a8c5-11e5-82c9-49bc646720dd');
            expect(scope.loaded).toBe(true);
            expect(scope.pageEnv.Take).toBe(0);
            expect(scope.AuditLogs.length).toBe(19);
            expect(scope.isMore).toBe(true);
            expect(scope.pageEnv.StartDate).toBe('2016-02-22T06:00:00.000Z');
            expect(scope.pageEnv.EndDate).toBe('2016-02-23T06:00:00.000Z');
        });
        it('Test 8: it should get member audit logs when when scrolled', function () {
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&Skip=0&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(0, 30));
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&Skip=30&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(30, 50));
            scope.init();
            scope.pageEnv.EntityType = 'MemberRole';
            scope.pageEnv.ActivityType = 'MemberRoleChanged';
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            expect(scope.search.userMeta.groupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            expect(scope.pageEnv.GroupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            scope.search.userMeta.onSelect({
                RolesInGroup: ['Manager'],
                UserId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Id: '42b85af2-a8c5-11e5-82c9-49bc646720dd',
                Name: 'Tom Mitic',
                AvatarId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Description: 'Product Engineering',
                Type: 'Member'
            });
            httpBackend.flush();
            expect(scope.pageEnv.EntityId).toBe('42b85af2-a8c5-11e5-82c9-49bc646720dd');
            expect(scope.loaded).toBe(true);
            expect(scope.pageEnv.Take).toBe(30);
            expect(scope.AuditLogs.length).toBe(30);
            expect(scope.isMore).toBe(true);
            scope.$broadcast('bottomScroll');
            httpBackend.flush();
            expect(scope.pageEnv.Skip).toBe(30);
            expect(scope.AuditLogs.length).toBe(50);
            expect(scope.pageEnv.Take).toBe(0);
        });
        it('Test 9: it should hide member audit logs when member is deselected', function () {
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&Skip=0&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(0, 30));
            scope.init();
            scope.pageEnv.EntityType = 'MemberRole';
            scope.pageEnv.ActivityType = 'MemberRoleChanged';
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            expect(scope.search.userMeta.groupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            expect(scope.pageEnv.GroupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            scope.search.userMeta.onSelect({
                RolesInGroup: ['Manager'],
                UserId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Id: '42b85af2-a8c5-11e5-82c9-49bc646720dd',
                Name: 'Tom Mitic',
                AvatarId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Description: 'Product Engineering',
                Type: 'Member'
            });
            httpBackend.flush();
            expect(scope.pageEnv.EntityId).toBe('42b85af2-a8c5-11e5-82c9-49bc646720dd');
            expect(scope.loaded).toBe(true);
            expect(scope.pageEnv.Take).toBe(30);
            expect(scope.AuditLogs.length).toBe(30);
            expect(scope.isMore).toBe(true);
            scope.search.userMeta.deSelect();
            expect(scope.AuditLogs.length).toBe(0);
            expect(scope.loaded).toBe(false);
            expect(scope.isMore).toBe(false);
            expect(scope.pageEnv.SearchTerm).toBeUndefined();
            expect(scope.datePicker.StartDate).toBeUndefined();
            expect(scope.datePicker.EndDate).toBeUndefined();
            expect(scope.pageEnv.StartDate).toBeUndefined();
            expect(scope.pageEnv.EndDate).toBeUndefined();
        });
        it('Test 10: it should hide member audit logs when a group is deselected', function () {
            httpBackend.whenGET(
                '/svc/Provision/GetFilteredMemberEntityActivities?ActivityType=MemberRoleChanged&EntityId=42b85af2-a8c5-11e5-82c9-49bc646720dd&EntityType=MemberRole&GroupId=3cf21720-9cd2-11e2-a3a4-25024474fe63&Skip=0&Take=30')
                .respond(200, auditMock.getAuditLogs().slice(0, 30));
            scope.init();
            scope.pageEnv.EntityType = 'MemberRole';
            scope.pageEnv.ActivityType = 'MemberRoleChanged';
            scope.search.groupMeta.onSelect({
                Id: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Name: "UAT Mercury Industries",
                AvatarId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                Type: "Group"
            });
            expect(scope.search.userMeta.groupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            expect(scope.pageEnv.GroupId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
            scope.search.userMeta.onSelect({
                RolesInGroup: ['Manager'],
                UserId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Id: '42b85af2-a8c5-11e5-82c9-49bc646720dd',
                Name: 'Tom Mitic',
                AvatarId: '42b85af0-a8c5-11e5-82c9-49bc646720dd',
                Description: 'Product Engineering',
                Type: 'Member'
            });
            httpBackend.flush();
            expect(scope.pageEnv.EntityId).toBe('42b85af2-a8c5-11e5-82c9-49bc646720dd');
            expect(scope.loaded).toBe(true);
            expect(scope.pageEnv.Take).toBe(30);
            expect(scope.AuditLogs.length).toBe(30);
            expect(scope.isMore).toBe(true);
            scope.search.groupMeta.deSelect();
            expect(scope.AuditLogs.length).toBe(0);
            expect(scope.search.userMeta.groupId).toBeUndefined();
            expect(scope.pageEnv.GroupId).toBeUndefined();
            expect(scope.search.userMeta.selected.length).toBe(0);
            expect(scope.loaded).toBe(false);
            expect(scope.isMore).toBe(false);
            expect(scope.pageEnv.SearchTerm).toBeUndefined();
            expect(scope.datePicker.StartDate).toBeUndefined();
            expect(scope.datePicker.EndDate).toBeUndefined();
            expect(scope.pageEnv.StartDate).toBeUndefined();
            expect(scope.pageEnv.EndDate).toBeUndefined();
        });
    });
});