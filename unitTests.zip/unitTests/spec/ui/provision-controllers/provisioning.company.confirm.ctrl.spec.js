define([
    'unitTests/ui-mocks/provisioning.company.json',
    'angular',
    'angular-resource',
    'provision-app'
], function (companyJson) {
    describe('Provisioning Confirm Controller Spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            toastrSrvc,
            routeParams,
            provisioningCompanySrvc;

        beforeEach(module('provision-app'));
        beforeEach(module('provision-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, ToastrSrvc, ProvisioningCompanySrvc) {
            httpBackend = $injector.get('$httpBackend');
            rootScope = $rootScope;
            routeParams = $injector.get('$routeParams');
            provisioningCompanySrvc = ProvisioningCompanySrvc;
            scope = $rootScope.$new();
            toastrSrvc = ToastrSrvc;
            ctrl = $controller('ProvisioningOnboardConfirmCtrl', {
                $scope: scope
            });
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning Confirm setting controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 cancel', function () {
            httpBackend.whenPOST("/svc/Provision/CancelValidatedFile")
                .respond(200, {});
            spyOn(provisioningCompanySrvc, 'cancelValidatedFile').andCallThrough();
            scope.cancel();
            httpBackend.flush();
            expect(provisioningCompanySrvc.cancelValidatedFile).toHaveBeenCalled();
        });
        it('Test 3 confirm', function () {
            httpBackend.whenPOST("/svc/Provision/ProcessValidatedFile")
                .respond(200, {});
            spyOn(provisioningCompanySrvc, 'processValidatedFile').andCallThrough();
            scope.confirm();
            expect(provisioningCompanySrvc.processValidatedFile).toHaveBeenCalled();
            httpBackend.flush();
        });
        it('Test 4 init with route', function () {
            httpBackend.whenGET("/svc/Provision/GetFileConfirmationDetails?Id=11111")
                .respond(200, companyJson.getFileConfirmationDetails());
            routeParams.Id = '11111';
            spyOn(provisioningCompanySrvc, 'getFileConfirmationDetails').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(provisioningCompanySrvc.getFileConfirmationDetails).toHaveBeenCalled();
        });
    });
});