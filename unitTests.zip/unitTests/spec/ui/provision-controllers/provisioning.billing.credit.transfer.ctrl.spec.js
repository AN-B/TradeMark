define([
    'unitTests/ui-mocks/provision.credit.transfer.request.mock',
    'unitTests/ui-mocks/group.json',
    'static/source/provision/validation/billing-credit-transfer-validation',//Do I need this define?
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'], function(postRequest, groupJSON, val){

    describe('Provisioning credit transfer controller spec ->', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            newsService,
            validation,
            provisionBillingAdminSrvc,
            rootScope;

        beforeEach(module("provision-app"));
        beforeEach(module("provision-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProvisioningBillingAdminSrvc) {
            httpBackend = $injector.get("$httpBackend");
            validation = val;
            provisionBillingAdminSrvc = ProvisioningBillingAdminSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            ctrl = $controller('ProvisioningCreditsTransferCtrl', {$scope: scope});

            httpBackend.whenPOST('/svc/Provision/TransferCredits')
                .respond(200, {message: 'success'}); //UPDATE WITH ACTUAL RESPONSE
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning credit transfer controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: scope.request.SameUser to switch from False to True after triggering scope.SetSameUser(true)', function (){
            scope.request = postRequest.getMockup();
            scope.setSameUser(1);
            expect(scope.request.SameUser).toBe(true);
        });
        it('Test 6: Transfer Credits function to not make service call if request is invalid', function (){
            scope.request.notValid = true;
            spyOn(provisionBillingAdminSrvc, 'transferCredits').andCallThrough();
            scope.transferCredits();
            expect(provisionBillingAdminSrvc.transferCredits).not.toHaveBeenCalled();
        });
        it('Test 7: Transfer Credits function to make service call if request is valid', function (){
            scope.request = postRequest.getMockup();
            spyOn(provisionBillingAdminSrvc, 'transferCredits').andCallThrough();
            scope.transferCredits();
            httpBackend.flush();
            expect(provisionBillingAdminSrvc.transferCredits).toHaveBeenCalled();
        });

    })
});