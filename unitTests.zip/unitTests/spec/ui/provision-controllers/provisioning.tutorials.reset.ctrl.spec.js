define([
        'unitTests/ui-mocks/tutorial.json',
        'static/source/core/collectionCache',
        'angular',
        'angular-mocks',
        'angular-resource',
        'provision-app'],
    function (tutorialJson, cache) {
        describe('Tutorial reset controller spec ->', function() {
            var provisioningTutorialService,
                groupService,
                httpBackend,
                scope,
                rootScope,
                location,
                ctrl;

            beforeEach(module("provision-app"));
            beforeEach(inject(function ($controller, $rootScope, $location, $injector, ProvisioningTutorialSrvc, GroupSrvc) {
                httpBackend = $injector.get("$httpBackend");
                provisioningTutorialService = ProvisioningTutorialSrvc;
                groupService = GroupSrvc;
                rootScope = $rootScope;
                scope = rootScope.$new();
                location = $location;
                ctrl = $controller('ProvisioningTutorialResetCtrl', {
                    $scope: scope
                });

                httpBackend.whenGET('/svc/Group/GetCurrentGroupMembersDTO?es=false&io=false&status=Active')
                    .respond(200, {});
                httpBackend.whenGET('/svc/Tutorial/ResetTutorialsAll')
                    .respond(200, 'All tutorials have been successfully reset for all members.');
                httpBackend.whenPOST('/svc/Tutorial/ResetTutorialsByMember')
                    .respond(200, 'All tutorials have been successfully reset');
            }));
            afterEach(function () {
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('Tutorial summary controller should exist', function (){
                expect(ctrl).toBeDefined();
            });

            it('init should call getTutorialStepsAll', function () {
                spyOn(groupService, 'getCurrentGroupMembersDTO').andCallThrough();
                scope.init();
                httpBackend.flush();
                expect(groupService.getCurrentGroupMembersDTO).toHaveBeenCalled();
            });

            it('resetTutorialsAll should call resetTutorialsAll and clear selected', function () {
                scope.selectedMember = 'Member One';
                spyOn(provisioningTutorialService, 'resetTutorialsAll').andCallThrough();
                scope.resetTutorialsAll();
                httpBackend.flush();
                expect(provisioningTutorialService.resetTutorialsAll).toHaveBeenCalled();
                expect(scope.selectedMember).toEqual(null);
            });

            it('setSelected should set scope.Selected to selected id of member', function () {
                scope.setSelected('23310b40-9cd5-11e2-a3a4-25024474fe63');
                expect(scope.Selected).toEqual('23310b40-9cd5-11e2-a3a4-25024474fe63');
            });

            it('clear should clear out selectedMember', function () {
                scope.selectedMember = 'a32f4gfa4wae';
                scope.clear();
                expect(scope.selectedMember).toEqual(null);
            });

            it('ResetTutorialsByMember should call ResetTutorialsByMember', function () {
                spyOn(provisioningTutorialService, 'ResetTutorialsByMember').andCallThrough();
                scope.Selected = '1';
                scope.SelectedTutorials = [{Suite: 1}, {Suite: 2}];
                scope.ResetTutorialsByMember();
                httpBackend.flush();
                expect(provisioningTutorialService.ResetTutorialsByMember).toHaveBeenCalled();
            });

        });
    });