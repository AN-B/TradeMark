define([
    'unitTests/ui-mocks/provision.custom.certificates.mock',
    'unitTests/ui-mocks/group.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'], function(postRequest, groupJSON) {

    describe('Provisioning credit transfer controller spec ->', function () {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            newsService,
            provisionBillingAdminSrvc,
            rootScope;

        beforeEach(module("provision-app"));
        beforeEach(module("provision-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProvisioningBillingAdminSrvc) {
            httpBackend = $injector.get("$httpBackend");
            provisionBillingAdminSrvc = ProvisioningBillingAdminSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            ctrl = $controller('ProvisioningCustomCertificatesCtrl', {$scope: scope});

            httpBackend.whenGET('/svc/Group/GetCurrentGroupMembersDTO?GroupId=0fcf94f0-c899-11e2-a219-23009d0bbe48&includeCredit=true&es=false')
                .respond(200, groupJSON.getCurrentMembersDto());
            httpBackend.whenPOST('/svc/Provision/SaveCustomCertificates')
                .respond(200, {message: 'success'}); //UPDATE WITH ACTUAL RESPONSE
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning custom certificates controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: Uploading a file switches $scope.fileUploaded to true;', function () {
           scope.completeFunction('test.zip', null);
           expect(scope.fileUploaded).toBe(true);
        });
        it('Test 3: Expect clearEventMessage to set reset scope.Message', function () {
          scope.Message = postRequest.getMessages();
          expect(scope.Message.length).toBeGreaterThan(1);
          scope.clearEventMessage();
          expect(scope.Message.length).toBe(0);
        });
        it('Test 4: Provision Certificates is called if request is valid', function (){
            scope.request = postRequest.getRequest();
            scope.request.valid = true;
            spyOn(provisionBillingAdminSrvc, 'saveCustomCertificates').andCallThrough();
            scope.provisionCerts();
            httpBackend.flush();
            expect(provisionBillingAdminSrvc.saveCustomCertificates).toHaveBeenCalled();
        });
        it('Test 5: Provision Certificates is not called if request is invalid', function (){
            scope.request = postRequest.getRequest();
            scope.request.valid = false;
            spyOn(provisionBillingAdminSrvc, 'saveCustomCertificates').andCallThrough();
            scope.provisionCerts();
            expect(provisionBillingAdminSrvc.saveCustomCertificates).not.toHaveBeenCalled();
        });


    })
});
