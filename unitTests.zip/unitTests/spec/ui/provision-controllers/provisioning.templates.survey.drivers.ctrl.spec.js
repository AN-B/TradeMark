define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/survey.drivers.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'
], function (userJson, surveyDriverJson) {
    describe('Provisioning Template Survey Driver Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend;

        beforeEach(module('provision-app'));
        beforeEach(module('provision-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, ProvisioningSurveySrvc) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            provisioningSurveySrvc = ProvisioningSurveySrvc;
            httpBackend = $injector.get('$httpBackend');
            ctrl = $controller('ProvisioningTemplatesSurveyDriversCtrl', {$scope: scope});
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Provisioning survey controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: init() should call backend', function () {
            httpBackend.whenGET("/svc/Survey/GetGlobalSurveyDrivers")
                .respond(200, surveyDriverJson.getSurveyDrivers());
            spyOn(provisioningSurveySrvc, 'getSurveyDrivers').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.surveyDrivers.length).toBe(4);
        });
        it('Test 3: addNewDriver() should add new driver to drivers array', function () {
            httpBackend.whenGET("/svc/Survey/GetGlobalSurveyDrivers")
                .respond(200, surveyDriverJson.getSurveyDrivers());
            spyOn(provisioningSurveySrvc, 'getSurveyDrivers').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.surveyDrivers.length).toBe(4);
            expect(scope.surveyDrivers[0].hgId).toBeDefined();
            scope.addNewDriver();
            expect(scope.model.selectedIndex).toBe(0);
            expect(scope.surveyDrivers.length).toBe(5);
            expect(scope.surveyDrivers[0].hgId).not.toBeDefined();
        });
        it('Test 4: setSelected will set scope.model.selectedIndex', function () {
            httpBackend.whenGET("/svc/Survey/GetGlobalSurveyDrivers")
                .respond(200, surveyDriverJson.getSurveyDrivers());
            spyOn(provisioningSurveySrvc, 'getSurveyDrivers').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.surveyDrivers.length).toBe(4);
            expect(scope.model.selectedIndex).toBeUndefined();
            scope.setSelected(scope.surveyDrivers[0].hgId, 0);
            expect(scope.model.selectedIndex).toBe('a2bf5070-e449-11e4-a184-87fb91927d2e');
        });
        it('Test 5: saveDriver() should call saveSurveyDriver if form is valid', function () {
            httpBackend.whenGET("/svc/Survey/GetGlobalSurveyDrivers")
                .respond(200, surveyDriverJson.getSurveyDrivers());
            spyOn(provisioningSurveySrvc, 'getSurveyDrivers').andCallThrough();
            scope.init();
            httpBackend.flush();
            spyOn(provisioningSurveySrvc, 'saveSurveyDriver').andCallThrough();
            scope.model.selectedIndex = 0;
            httpBackend.whenPOST("/svc/Survey/SaveSurveyDriver")
                .respond(200, {value: 'saved'});
            scope.saveDriver();
            httpBackend.flush();
            expect(provisioningSurveySrvc.saveSurveyDriver).toHaveBeenCalled();
        });
        xit('Test 6: clear() should clear selectedIndex', function () {
            httpBackend.whenGET("/svc/Survey/GetGlobalSurveyDrivers")
                .respond(200, surveyDriverJson.getSurveyDrivers());
            spyOn(provisioningSurveySrvc, 'getSurveyDrivers').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.surveyDrivers.length).toBe(4);
            scope.setSelected(scope.surveyDrivers[0].hgId, 0);
            expect(scope.model.selectedIndex).toBe(0);
            scope.clear();
            httpBackend.flush();
            expect(scope.model.selectedIndex).toBeFalsy();
        });
    });
});