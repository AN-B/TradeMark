define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('fb list profile filter spec ->', function() {
        var format;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-filters"));
        beforeEach(inject(function ($compile, $injector, $filter) {
            format = $filter('fblistprofile');
        }));
        it('Test 1 filter should be defined', function() {
            expect(format).toBeDefined();
        });
        it('Test 2', function() {
            expect(format('Closed')).toBe('profile.cf.tcbp');
        });
        it('Test 3', function() {
            expect(format('Completed')).toBe('profile.cf.tpbp');
        });
        it('Test 4', function() {
            expect(format('Declined')).toBe('profile.cf.tdbp');
            expect(format('Declined', true)).toBe('profile.cf.trbp');
        });
        it('Test 5', function() {
            expect(format('Expired')).toBe('profile.cf.tebp');
        });
        it('Test 6', function() {
            expect(format('InProgress')).toBe('profile.cf.twfp');
            expect(format('InProgress', true)).toBe('profile.cf.trbp');
        });
        it('Test 7', function() {
            expect(format('Requesting')).toBe('profile.cf.twfp');
            expect(format('Requesting', true)).toBe('profile.cf.trbp');
        });
        it('Test 8', function() {
            expect(format('SubjectRated')).toBe('profile.cf.tpbp');
            expect(format('SubjectRated', true)).toBe('profile.cf.trbp');
        });
        it('Test 9', function() {
            expect(format('Submitted')).toBe('profile.cf.tpbp');
            expect(format('Submitted', true)).toBe('profile.cf.trbp');
        });
    });
});
