define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('formatNumber filter spec ->', function() {
        var format;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-filters"));
        beforeEach(inject(function ($compile, $injector, $filter) {
            format = $filter('formatNumber');
        }));
        it('Test 1 filter should be defined', function() {
            expect(format).toBeDefined();
        });
        it('Test 2', function() {
            var test = format(1.000);
            expect(test.toString()).toBe('1');
        });
        it('Test 3', function() {
            var test = format(1.0001);
            expect(test.toString()).toBe('1.0001');
        });
        it('Test 4', function() {
            var test = format('test');
            expect(test).not.toBeDefined();
        });
        it('Test 5', function() {
            var test = format('123');
            expect(test).toBe(123);
        });
        it('Test 6', function() {
            var test = format('123.22');
            expect(test).toBe(123.22);
        });
        it('Test 7', function() {
            var test = format('test123.22');
            expect(test).not.toBeDefined();
        });
        it('Test 8', function() {
            var test = format('123.22xckkjkjdkj');
            expect(test).toBe(123.22);
        });
        it('Test 9', function() {
            var test = format('123xckkjkjdkj');
            expect(test).toBe(123);
        });
        it('Test 10', function() {
            var test = format('ddssd123xckkjkjdkj1221');
            expect(test).not.toBeDefined();
        });
        it('Test 10', function() {
            var test = format(1.23, {decimal: 0});
            expect(test).toBe('1');
        });
    });
});