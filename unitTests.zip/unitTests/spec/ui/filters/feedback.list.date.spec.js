define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('fb list date filter spec ->', function() {
        var format;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-filters"));
        beforeEach(inject(function ($compile, $injector, $filter) {
            format = $filter('fblistdate');
        }));
        it('Test 1 filter should be defined', function() {
            expect(format).toBeDefined();
        });
        it('Test 2', function() {
            expect(format('Requesting')).toBe('profile.cf.rbd');
        });
        it('Test 3', function() {
            expect(format('Requesting', 'something')).toBe('profile.cf.cmd');
        });
        it('Test 4', function() {
            expect(format('InProgress')).toBe('profile.cf.dud')
        });
        it('Test 5', function() {
            expect(format('InProgress', true)).toBe('profile.cf.cmd');
        });
        it('Test 6', function() {
            expect(format('Declined', true)).toBe('profile.cf.dbd');
            expect(format('Declined')).toBe('profile.cf.dbd');
        });
        it('Test 7', function() {
            expect(format('Expired')).toBe('profile.cf.exd');
        });
        it('Test 8', function() {
            expect(format('Submitted')).toBe('profile.cf.sd');
        });
        it('Test 9', function() {
            expect(format('SubjectRated')).toBe('profile.cf.sd');
        });
        it('Test 10', function() {
            expect(format('Completed')).toBe('profile.cf.cmo');
        });
        it('Test 11', function() {
            expect(format('Closed')).toBe('profile.cf.exd');
        });
        it('Test 12', function() {
            expect(format('Archived')).toBe('profile.cf.ard');
        });
    });
});