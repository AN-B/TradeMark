define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('userSearch filter spec ->', function() {
        var userSearch,
            meta;
        beforeEach(function () {
            meta = [
                {
                    AvatarId : "00db8060-d434-11e3-938d-991324c83af7",
                    Department: "",
                    Id: "00db8062-d434-11e3-938d-991324c83af7",
                    Name: "Akash kale",
                    Selected: false,
                    Type: "Member",
                    exclude: false,
                    hover: false,
                    sortOrder: 0
                },
                {
                    AvatarId : "00db8g60-d434-11e3-938d-99f324c83af7",
                    Department: "QA",
                    Id: "00db8062-d434-11e3-938d-991324c83af7",
                    Name: "Susan Ross",
                    Selected: false,
                    Type: "Member",
                    exclude: false,
                    hover: false,
                    sortOrder: 1
                },
                {
                    AvatarId : "00db80e0-d434-11ee-938d-99132ec83af7",
                    Department: "Development",
                    Id: "00db8062-d434-11e3-938d-991324c83af7",
                    Name: "Larry",
                    Selected: false,
                    Type: "Member",
                    exclude: false,
                    hover: false,
                    sortOrder: 2
                },
                {
                    AvatarId : "00db80e0-d434-11ee-938d-99132ec83af7",
                    Department: "",
                    Id: "00db8062-d434-11e3-938d-991324c83af7",
                    Name: "Code Monkeys",
                    Selected: false,
                    Type: "Team",
                    exclude: false,
                    hover: false,
                    sortOrder: 3
                },
                {
                    AvatarId : "00db8gsd0-d434-11e3-938d-99f324c83af7",
                    Department: "QA",
                    Id: "00dwed062-d434-11e3-938d-991324c83af7",
                    Name: "Susan Blah",
                    Selected: false,
                    Type: "Member",
                    exclude: false,
                    hover: false,
                    sortOrder: 1
                },
                {
                    AvatarId : "00dwegsd0-d434-11e3-938d-99f324c83af7",
                    Department: "QA",
                    Id: "hsdhgsdh-d434-11e3-938d-991324c83af7",
                    Name: "Susan Foo",
                    Selected: false,
                    Type: "Member",
                    exclude: false,
                    hover: false,
                    sortOrder: 1
                }
            ];
        });

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-filters"));
        beforeEach(inject(function ($compile, $injector, $filter) {
            userSearch = $filter('userSearch');
        }));
        it('Test 1 filter should be defined', function() {
            expect(userSearch).toBeDefined();
        });
        it('Test 2 it should return only members', function() {
            var test = userSearch(meta, 'Member');
            expect(test.length).toBe(5);
        });
        it('Test 3 it should return only members that are not selected', function() {
            meta[0].Selected = true;
            var test = userSearch(meta, 'Member');
            expect(test.length).toBe(4);
            expect(test[0].Name).toBe('Susan Ross');
        });
        it('Test 4 it should return only members that are not excluded', function() {
            meta[0].exclude = true;
            var test = userSearch(meta, 'Member');
            expect(test.length).toBe(4);
            expect(test[0].Name).toBe('Susan Ross');
        });
        it('Test 5 it should return 2nd object in the array', function() {
            var test = userSearch(meta, 'Susan');
            expect(test.length).toBe(3);
            expect(test[0].Name).toBe('Susan Ross');
        });
        it('Test 6 it should not return matching excluded', function() {
            meta[1].exclude = true;
            var test = userSearch(meta, 'Susan');
            expect(test.length).toBe(2);
        });
        it('Test 7 it should return search matching department qa', function() {
            var test = userSearch(meta, 'qa');
            expect(test.length).toBe(3);
            expect(test[0].Department).toBe('QA');
        });
        it('Test 8 it should return empty array', function() {
            var test = userSearch(meta, '');
            expect(test.length).toBe(0);
        });
        it('Test 9 it should return 2 records when changing limit to 2', function() {
            var test = userSearch(meta, 'Susan', 2);
            expect(test.length).toBe(2);
        });
        it('Test 10 it should return 3 records when changing limit to 3', function() {
            var test = userSearch(meta, 'Susan', 3);
            expect(test.length).toBe(3);
        });
    });
});