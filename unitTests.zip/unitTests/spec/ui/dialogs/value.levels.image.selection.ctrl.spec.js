define([
	'static/source/core/utility/arrayUtil',
	'unitTests/ui-mocks/badge.json',
	'static/source/core/collectionCache',
    'unitTests/ui-mocks/modal',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(arrayUtil, badges, cache, modalMock){

	describe('Value levels image selection dialog controller spec -> ', function() {
		var scope,
			ctrl,
			modal,
			httpBackend,
			rootScope,
			badgeAdminSrvc;

		beforeEach(function(){
			module("hgapp-app");
			module('ui.bootstrap');
		});
		beforeEach(inject(function ($injector, $controller, $rootScope, BadgeAdminSrvc) {

			modal = modalMock;
			badgeAdminSrvc = BadgeAdminSrvc;

			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenGET("/svc/Badge/GetBadgesForValueBorder")
				.respond(200, badges.valueLevelsBorder());

			scope = $rootScope.$new();
			ctrl = $controller('ValueLevelImageSelectionDlgCtrl', {$scope: scope, $modalInstance: modal, BadgeAdminSrvc: badgeAdminSrvc});
		}));
		afterEach(function () {
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
			rootScope.$digest();
		});
		it('Test 1 dialog controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
		it('Test 2 when calling init it should hydrate badges', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.badges.length).toBe(9);
		});
		it('Test 3 addBadge it should call close dialog with first badge in the badges', function (){
			scope.init();
			httpBackend.flush();
			spyOn(arrayUtil, 'getObjByProp').andCallThrough();
			spyOn(modal, 'close').andCallThrough();
			scope.addBadge('9a292ef0-770c-11e3-979e-77ff3cba7106');
			expect(modal.close).toHaveBeenCalledWith(scope.badges[0]);
		});;
		it('Test 4 getBadgeUrl it should return image url', function (){
			var test = scope.getBadgeUrl('test.svg');
			expect(test.indexOf('/badges/original/test.svg')).toBe(1);
		});
		it('Test 5 applyFilter should change searchFilter value', function (){
			scope.applyFilter('blah');
			expect(scope.searchBadge).toBe('blah');
		});

	});
});