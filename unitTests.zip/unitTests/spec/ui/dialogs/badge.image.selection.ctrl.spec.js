define([
	'unitTests/ui-mocks/badge.json',
	'static/source/core/collectionCache',
    'unitTests/ui-mocks/modal',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(badges, cache, modalMock){

	describe('badge image selection dialog controller spec -> ', function() {
		var scope,
			ctrl,
			modal,
			httpBackend,
			rootScope,
            timeOut,
            q;

		beforeEach(function(){
			module("hgapp-app");
			module('ui.bootstrap');
		});

        function service() {
            return function () {
                var deferred = q.defer();
                deferred.resolve(badges.getValueBadges());
                return deferred.promise;
            };
        }

		beforeEach(inject(function ($injector, $controller, $rootScope, $timeout) {

			modal = modalMock;
            timeOut = $timeout;
            q = $injector.get("$q");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenGET("/svc/Badge/GetBadgesForValuesIcon?skip=0&take=36")
				.respond(200, badges.getValueBadges());
			scope = $rootScope.$new();
			ctrl = $controller('BadgeImageSelectionDlgCtrl', {$scope: scope, $modalInstance: modal, $timeout: timeOut, service: service()});
		}));
		afterEach(function () {
			rootScope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 dialog controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
		it('Test 2 when calling init it should hydrate badges', function (){
			scope.init();
            scope.$digest();
			expect(scope.badges.length).toBe(36);
		});
		it('Test 3 addBadge it should call close dialog with first badge in the badges', function (){
			scope.badges = badges.getValueBadges().badges;
			expect(scope.badges.length).toBe(36);
			spyOn(modal, 'close').andCallThrough();
			scope.addBadge('4d262350-a0c6-11e2-a665-cf2c2ef6e160');
			expect(modal.close).toHaveBeenCalledWith(scope.badges[0]);
		});
		it('Test 4 applyFilter should change searchFilter value', function (){
			scope.applyFilter('blah');
			expect(scope.searchBadge).toBeFalsy();
		});

	});
});