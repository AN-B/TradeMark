define([
	'unitTests/ui-mocks/user.json',
	'static/source/core/enums/events',
    'unitTests/ui-mocks/modal',
    'static/source/core/collectionCache',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(userJson, events, modalMock, cache){

	describe('Avatar upload dialog controller spec -> ', function() {
		var scope,
			ctrl,
			modal,
			httpBackend,
			rootScope,
			uploadSrvc,
			userSrvc,
            userSelfSrvc,
			timeout;

		beforeEach(function(){
			module("hgapp-app");
			module('ui.bootstrap');
		});

		beforeEach(inject(function ($injector, $controller, $rootScope, UserSelfSrvc, UserSrvc, UploadSrvc) {
            modal = modalMock;
			userSelfSrvc = UserSelfSrvc;
            uploadSrvc = UploadSrvc;
			userSrvc = UserSrvc;
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
            cache.clear('user');

			var accountId = 'someguid';

			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
            httpBackend.whenPOST('/svc/UserSelf/UpdateAvatarVersion')
                .respond(200, new Date().getTime().toString());
			httpBackend.whenPOST("/svc/Upload/ProcessAndCropImage")
				.respond(200, 'file uploaded');

			scope = $rootScope.$new();
			ctrl = $controller('UserAvatarUploadCtrl', {
                $scope: scope,
                accountId: accountId,
                admin: false,
                $modalInstance: modal,
                UploadSrvc: uploadSrvc
            });
		}));
		afterEach(function () {
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
			rootScope.$digest();
		});
		it('Test 1 Avatar upload dialog controller should exist', function (){
			expect(ctrl).toBeDefined();
			expect(typeof scope.imgSelectModel.onSelectEnd === 'function').toBeTruthy();
		});
		it('Test 2 closeDialog() should close dialog and broadcast', function (){
			spyOn(rootScope, '$broadcast').andCallThrough();
			spyOn(modal, 'close').andCallThrough();
			spyOn(userSrvc, 'getUser').andCallThrough();
			scope.closeDialog('test');
			httpBackend.flush();
			expect(userSrvc.getUser).toHaveBeenCalled();
			expect(modal.close).toHaveBeenCalledWith('test');
		});
		it('Test 3 fileUploaderSubmit() expect fileUploaded to be false', function (){
			scope.fileUploaded = true;
			scope.selectorImg = {};
			scope.selectorImg.cancelSelection = function (){};
			spyOn(scope.selectorImg, 'cancelSelection').andCallThrough();
			scope.fileUploaderSubmit();
			expect(scope.selectorImg.cancelSelection).toHaveBeenCalled();
		});
		it('Test 4 uploadCompleted() expect fileUploaded to be true', function (){
			spyOn(rootScope, '$broadcast').andCallThrough();
			scope.uploadCompleted('test.jpg');
			expect(rootScope.$broadcast).toHaveBeenCalledWith('imageUploaded', rootScope.imageStore[0] + '/tmp/test.jpg');
			expect(scope.fileUploaded).toBeTruthy();
			expect(scope.ImagePostData.originalName).toBe('test.jpg');
			expect(scope.ImagePostData.userGuid).toBe('someguid');
		});
		it('Test 5 saveCroppedImage() expect avatarPost to be posted to the server', function (){
			scope.fileUploaded = true;
			spyOn(uploadSrvc, 'processAndCropImage').andCallThrough();
			spyOn(scope, 'closeDialog').andCallThrough();
			scope.saveCroppedImage();
			httpBackend.flush();
			expect(uploadSrvc.processAndCropImage).toHaveBeenCalled();
			expect(scope.closeDialog).toHaveBeenCalledWith('file uploaded');
		});
		it('Test 6 saveCroppedImage() expect service function not to be called', function (){
			scope.fileUploaded = false;
			spyOn(uploadSrvc, 'processAndCropImage').andCallThrough();
			spyOn(scope, 'closeDialog').andCallThrough();
			scope.saveCroppedImage();
			expect(uploadSrvc.processAndCropImage).not.toHaveBeenCalled();
			expect(scope.closeDialog).not.toHaveBeenCalled();
		});
	});
});
