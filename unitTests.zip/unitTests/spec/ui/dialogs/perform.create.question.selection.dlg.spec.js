define([
    'unitTests/ui-mocks/perform.question.library.json',
    'unitTests/ui-mocks/modal',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(cardJson, modalMock){

    describe('Perform card library create question select dialog controller spec -> ', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            rootScope,
			questionSelection,
            params,
			modal,
			service;

        beforeEach(function(){
            module("hgapp-app");
            module('ui.bootstrap');
        });

        beforeEach(inject(function ($injector, $controller, $rootScope) {
			modal =  modalMock;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            service = $injector.get('PerformSrvc');
            params = {
                QuestionId: '5e26a200-26f5-11e3-895a-4b3c71e041ac',
                AnswerType: ''
            };
            httpBackend.whenGET("/svc/Performance/GetQuestionLibrary")
                .respond(200, cardJson.get());

            scope = $rootScope.$new();
            ctrl = $controller('QuestionSelectionDlg', {$scope: scope, $modalInstance: modal, params: params, $timeout: timeout, PerformSrvc: service});
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
            rootScope.$digest();
        });
        it('Test 1 Perform card library create question selection dialog controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 should call getQuestionLibrary when scope getQuestions called', inject(function (_PerformSrvc_){
            var callback = jasmine.createSpy();
            service = _PerformSrvc_;
            spyOn(service, 'getQuestionLibrary').andCallThrough();
            scope.getQuestions(callback);
            waitsFor(function() {
                return callback.callCount > 0;
            }, 10);
            httpBackend.flush();
            runs(function() {
                expect(callback).toHaveBeenCalled();
                expect(service.getQuestionLibrary).toHaveBeenCalled();
            });
        }));
        it('Test 3 Question Id should be 5e26a200-26f5-11e3-895a-4b3c71e041ac', function (){
            expect(scope.QuestionId).toBe('5e26a200-26f5-11e3-895a-4b3c71e041ac');
        });
        it('Test 4 scope.AnswerType should be ScaleRating if nothing is passed from the controller', function (){
            expect(scope.AnswerType).toBe('ScaleRating');
        });
        it('Test 5 should populate scope objects when init() called', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.questions.length).toBe(4);
            expect(scope.categories.length).toBe(4);
            expect(scope.answerTypes.length).toBe(2);
        });
        it('Test 6 should set property selected of first element to false when remove() called', function (){
            scope.init();
            httpBackend.flush();
            scope.questions[0].selected = true;
            expect(scope.questions[0].selected).toBeTruthy();
            scope.remove('5e262cd1-26f5-11e3-895a-4b3c71e041ac');
            expect(scope.questions[0].selected).toBeFalsy();
        });
        it('Test 7 should populate scope objects when add() called', function (){
            scope.init();
            httpBackend.flush();
            spyOn(scope, 'close').andCallThrough();
            expect(scope.questions[0].selected).toBeFalsy();
            scope.add('5e262cd1-26f5-11e3-895a-4b3c71e041ac');
            expect(scope.questions[0].selected).toBeTruthy();
            expect(scope.close).toHaveBeenCalled();
        });
        it("Test 8 should change AnswerType value to ScaleRating if scope.answerTypes doesn't contain AnswerType", function (){
            scope.AnswerType = 'Test';
            scope.init();
            httpBackend.flush();
            expect(scope.AnswerType).toBe('ScaleRating');
        });
        it("Test 9 shouldn't change AnswerType value to ScaleRating if scope.answerTypes contain AnswerType", function (){
            scope.AnswerType = 'SomethingElse';
            scope.init();
            httpBackend.flush();
            expect(scope.AnswerType).toBe('SomethingElse');
        });
        it("Test 10 shouldn't change AnswerType value to ScaleRating if scope.answerTypes contain AnswerType", function (){
            scope.AnswerType = 'SomethingElse';
            scope.init();
            httpBackend.flush();
            expect(scope.AnswerType).toBe('SomethingElse');
        });
        it("Test 11 should change categorySelected to 'Advocating Causes' and questions length should be 1", function (){
            scope.setCategoryType('Advocating Causes');
            httpBackend.flush();
            expect(scope.questions.length).toBe(1);
            expect(scope.questions[0].Category).toBe('Advocating Causes');
            expect(scope.categorySelected).toBe('Advocating Causes');
        });
        it("Test 12 should change categorySelected to empty and questions length should be 4", function (){
            scope.setCategoryType('');
            httpBackend.flush();
            expect(scope.questions.length).toBe(4);
            expect(scope.questions[1].Category).toBe('Analysis/Reasoning');
            expect(scope.categorySelected.length).toBe(0);
        });
    });
});
