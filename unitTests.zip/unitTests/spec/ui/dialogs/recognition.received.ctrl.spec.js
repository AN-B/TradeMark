define([
    'unitTests/ui-mocks/modal',
    'unitTests/ui-mocks/recognition.json',
    'static/source/hgapp/controllers/dialogs/recognition-received',
    'angular',
    'hgapp-app',
    'angular-mocks'
], function(modalMock, recognitionJson, recognitionReceivedCtrl) {
    describe('Recognition received modal', function () {
        var scope,
            rootScope,
            controller,
            ctrl,
            modal,
            httpBackend,
            recognitionSrvc,
            notificationSrvc,
            params;

        beforeEach(function() {
            module("hgapp-app");
        });
        beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionSrvc, NotificationSrvc) {
            modal = modalMock;
            controller = $controller;
            recognitionSrvc = RecognitionSrvc;
            notificationSrvc = NotificationSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get("$httpBackend");
            ctrl = controller(recognitionReceivedCtrl, {
                $scope: scope,
                $modalInstance: modal,
                RecognitionSrvc: recognitionSrvc,
                NotificationSrvc: notificationSrvc,
                params: recognitionJson.getRecognitionModalParams()
            });

        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
            rootScope.$digest();
        });

        it('Recognition received controller should load recognition', function () {
            httpBackend.whenGET('/svc/Recognition/GetRecognitionById?RecognitionId=295d2c30-f259-11e3-851e-e1dd1a3833aa&Viewee=')
                .respond(200, recognitionJson.getRecognition());
            httpBackend.whenPOST('/svc/Notification/ViewNotification')
                .respond(200);
            httpBackend.flush();

            expect(scope.recognition).toEqual(recognitionJson.getRecognition());
            expect(scope.pointsAndCredits).toBe(true);
            expect(scope.loaded).toBe(true);
        });

        it('company name should be set when public recognition', function () {
            httpBackend.whenGET('/svc/Recognition/GetRecognitionById?RecognitionId=295d2c30-f259-11e3-851e-e1dd1a3833aa&Viewee=')
                .respond(200, recognitionJson.getPublicRecognition());
            httpBackend.whenPOST('/svc/Notification/ViewNotification')
                .respond(200);
            httpBackend.flush();

            expect(scope.recognition).toEqual(recognitionJson.getPublicRecognition());
            expect(scope.pointsAndCredits).toBe(false);
            expect(scope.loaded).toBe(true);
            expect(scope.companyName).toEqual(' (Mercury Industries)');
        });

        it('should set scope.loaded to false on close and call notification srvc', function () {
            httpBackend.whenGET('/svc/Recognition/GetRecognitionById?RecognitionId=295d2c30-f259-11e3-851e-e1dd1a3833aa&Viewee=')
                .respond(200, recognitionJson.getRecognition());
            httpBackend.whenPOST('/svc/Notification/ViewNotification')
                .respond(200);
            httpBackend.flush();

            spyOn(notificationSrvc, 'viewNotification').andCallThrough();

            scope.Close();
            httpBackend.flush();
            expect(scope.loaded).toBe(false);
            expect(notificationSrvc.viewNotification).toHaveBeenCalled();
        });
    });
});