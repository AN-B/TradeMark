define([
    'static/source/core/enums/events',
    'unitTests/ui-mocks/modal',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (events, modalMock) {

    describe('Team avatar upload dialog controller spec -> ', function () {
        var scope,
            ctrl,
            modal,
            httpBackend,
            rootScope,
            userSelfSrvc,
            uploadSrvc,
            compile;

        beforeEach(function () {
            module("hgapp-app");
            module('ui.bootstrap');
        });
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSelfSrvc, $compile, UploadSrvc) {
            modal = modalMock;
            userSelfSrvc = UserSelfSrvc;
            uploadSrvc = UploadSrvc;
            compile = $compile;
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            var teamId = 'someguid';
            httpBackend.whenPOST("/svc/Upload/ProcessAndCropImage")
                .respond(200, 'file uploaded');
            scope = $rootScope.$new();
            ctrl = $controller('TeamAvatarUploadCtrl', {
                $scope: scope,
                teamId: teamId,
                $modalInstance: modal,
                UploadSrvc: uploadSrvc
            });
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
            rootScope.$digest();
        });
        it('Test 1 Team avatar upload dialog controller should exist', function () {
            expect(ctrl).toBeDefined();
            expect(typeof scope.imgSelectModel.onSelectEnd === 'function').toBeTruthy();
        });
        it('Test 2 closeDialog() should close dialog and broadcast', function () {
            spyOn(rootScope, '$broadcast').andCallThrough();
            spyOn(modal, 'close').andCallThrough();
            scope.closeDialog('test');
            expect(modal.close).toHaveBeenCalledWith('test');
            expect(rootScope.$broadcast).toHaveBeenCalledWith(events.HgAppAvatarUpdated);
        });
        it('Test 3 fileUploaderSubmit() expect fileUploaded to be false', function () {
            scope.fileUploaded = true;
            scope.selectorImg = {};
            scope.selectorImg.cancelSelection = function () {
            };
            spyOn(scope.selectorImg, 'cancelSelection').andCallThrough();
            scope.fileUploaderSubmit();
            expect(scope.fileUploaded).toBeFalsy();
            expect(scope.selectorImg.cancelSelection).toHaveBeenCalled();
        });
        it('Test 4 uploadCompleted() expect fileUploaded to be true', function () {
            spyOn(rootScope, '$broadcast').andCallThrough();
            scope.uploadCompleted('test.jpg');
            expect(rootScope.$broadcast).toHaveBeenCalledWith('imageUploaded', rootScope.imageStore[0] + '/tmp/test.jpg');
            expect(scope.fileUploaded).toBeTruthy();
            expect(scope.ImagePostData.originalName).toBe('test.jpg');
            expect(scope.ImagePostData.defaultFileName).toBe('someguid');
            expect(scope.ImagePostData.imgDirectory).toBe('team');
        });
        it('Test 5 saveCroppedImage() expect ImagePostData to be posted to the server', function () {
            scope.fileUploaded = true;
            spyOn(uploadSrvc, 'processAndCropImage').andCallThrough();
            spyOn(scope, 'closeDialog').andCallThrough();
            scope.saveCroppedImage();
            httpBackend.flush();
            expect(uploadSrvc.processAndCropImage).toHaveBeenCalled();
            expect(scope.closeDialog).toHaveBeenCalledWith('file uploaded');
        });
        it('Test 6 saveCroppedImage() expect service function not to be called', function () {
            scope.fileUploaded = false;
            spyOn(uploadSrvc, 'processAndCropImage').andCallThrough();
            spyOn(scope, 'closeDialog').andCallThrough();
            scope.saveCroppedImage();
            expect(uploadSrvc.processAndCropImage).not.toHaveBeenCalled();
            expect(scope.closeDialog).not.toHaveBeenCalled();
        });
    });
});
