define([
	'unitTests/ui-mocks/track.json',
	'static/source/hgapp/util/perform-review-util',
    'unitTests/ui-mocks/modal',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(trackJson, util, modalMock){

	describe('Track selection dialog controller spec -> ', function() {
		var scope,
			ctrl,
			modal,
			httpBackend,
			rootScope,
			userSelfSrvc,
			userSrvc;

		beforeEach(function(){
			module("hgapp-app");
			module('ui.bootstrap');
		});

		beforeEach(inject(function ($injector, $controller, $rootScope, UserSelfSrvc, UserSrvc) {

			modal = modalMock;

			userSelfSrvc = UserSelfSrvc;
			userSrvc = UserSrvc;

			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			var params = {
				reviewId: 'something',
				title: 'titleSomething'
			};
			httpBackend.whenGET("/svc/Track/GetTracksForReview?ReviewId=something")
				.respond(200, trackJson.getTracksForReview());
			scope = $rootScope.$new();
			ctrl = $controller('TrackSelectionDlgCtrl', {$scope: scope, params: params, $modalInstance: modal});
		}));
		afterEach(function () {
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
			rootScope.$digest();
		});
		it('Test 1 track selection dialog controller should exist', function (){
			expect(ctrl).toBeDefined();
			expect(scope.title).toBe('titleSomething');
		});
		it('Test 2 calling init() should call backend', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.tracks.length).toBe(2);
		});
		it('Test 3 calling removeAndClose() should call close with empty params', function (){
			spyOn(modal,"close").andCallThrough();
			scope.removeAndClose();
			expect(modal.close).toHaveBeenCalledWith();
		});
		it('Test 3 calling removeAndClose() should call close with empty params', function (){
			spyOn(modal,"close").andCallThrough();
			scope.removeAndClose();
			expect(modal.close).toHaveBeenCalledWith();
		});
		it('Test 4 calling addAndClose() should call close with first track in the tracks array', function (){
			scope.init();
			httpBackend.flush();
			spyOn(modal,"close").andCallThrough();
			scope.addAndClose('4c3a2030-6417-11e3-91a0-75859541cdd1');
			var track = util.getTrackDto(scope.tracks[0]);
			expect(modal.close).toHaveBeenCalledWith(track);
		});
	});
});