define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/modal',
    'unitTests/ui-mocks/productItem.templates.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, modalMock, productItemsJson){

    describe('Give gift dialog controller spec -> ', function() {
        var scope,
            modal,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            productItemSrvc,
            userSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, UserSrvc, ProductItemSrvc) {
            modal = modalMock;
            userSrvc  = UserSrvc;
            productItemSrvc = ProductItemSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET("/svc/User/Login").respond(200, userJson.getCu());
            httpBackend.whenPOST("/svc/ProductItem/GetProductItemsForGifting").respond(200, productItemsJson.getAll());

            scope = $rootScope.$new();
            ctrl = $controller('GiveGiftCtrl', {
                $rootScope: rootScope,
                $scope: scope,
                $modalInstance: modal,
                currentUser: userJson.getCu()
            });
            userSrvc.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('selectGift() should close modal and return ProductId, Member', function () {
            scope.selectedMember = 'Bob';
            spyOn(modal, 'close').andCallThrough();
            scope.selectGift(productItemsJson.getAll()[0].hgId);
            expect(modal.close).toHaveBeenCalledWith({ProductId: productItemsJson.getAll()[0].hgId, Member: 'Bob'});
        });

        it('Close() should dismiss modal', function () {
            spyOn(modal, 'dismiss').andCallThrough();
            scope.Close();
            expect(modal.dismiss).toHaveBeenCalledWith();
        });
    });
});