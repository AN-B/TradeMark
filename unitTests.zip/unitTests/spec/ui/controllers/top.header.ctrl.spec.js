define([
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/teams.json',
    'static/source/core/enums/events',
    'unitTests/ui-mocks/user.json',
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(groupJson, teamJson, events, userJson, cache){

    describe('Top header controller spec', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            location,
            routeParams,
            UserService;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc) {
            UserService = UserSrvc;
            location = $injector.get("$location");
            timeout = $injector.get("$timeout");
            routeParams = $injector.get("$routeParams");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            ctrl = $controller('HgAppTopHeaderCtrl', {$scope: scope});
            cache.clear('user');
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Notification/GetUnViewedRecognition')
                .respond(200, {});

            UserService.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 topheader controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

        it('Test 2 on HgImpAppNotificationsViewed view important notification', function () {
            scope.model.impMessageCount = 5;
            scope.$broadcast(events.HgImpAppNotificationsViewed, 2);
            expect(scope.model.impMessageCount).toBe(2);
        });
    });
});
