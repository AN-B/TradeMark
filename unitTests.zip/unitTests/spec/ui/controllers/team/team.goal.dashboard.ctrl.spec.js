define([
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (cache) {
    describe('team tab goal dashboard spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            location;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, $timeout, ManagerAlertSrvc, GoalsAdminSrvc) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            managerAlertSrvc = ManagerAlertSrvc;
            goalAdminSrvc = GoalsAdminSrvc;
            ctrl = $controller('TeamGoalDashboardCtrl', {$scope: scope});
            httpBackend = $injector.get('$httpBackend');
            location = $injector.get("$location");
            timeout = $injector.get('$timeout');
            httpBackend.whenGET('/svc/ManagerAlert/GetFiltersByMemberId?memberId=123')
                    .respond(200, [{data: [{id: '123', name: 'test'}], isDisplay: true}]);

            httpBackend.whenGET('/svc/ManagerAlert/GetTeamAlignedGoalsById?goalId=5&skip=0&sortCol=Name&sortDir=asc&take=10')
                    .respond(200, []);

            httpBackend.whenGET('/svc/ManagerAlert/GetTeamGoalsDashboardStats?memberId=123')
                    .respond(200, {AtRisk:1, Behind:1, OnTrack:7, OpenGoals:9});
            httpBackend.whenGET('/svc/Goal/GetDashboardAlignedGoals')
                    .respond(200, [{Name: 'Company goal', Owner: 'Vip'}]);
            httpBackend.whenGET('/svc/ManagerAlert/GetGoalActivity?interval=7&memberId=123')
                    .respond(200, {series:[{name: 'Direct Reports', data: []}]});

            httpBackend.whenGET('svc/ManagerAlert/GetTeamDashboardStats?memberId=123')
                .respond(200, []);



        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 - TeamGoalDashboardCtrl should exist', function () {
            expect(ctrl).toBeDefined();
        });
        xit('Test 2 - change userInfo should get manager Alerts', function () {
            spyOn(managerAlertSrvc,'getFiltersByMemberId').andCallThrough();
            spyOn(goalAdminSrvc,'getDashboardAlignedGoals').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            expect(scope.filters.length).toBe(1);
            expect(scope.stats.AtRisk).toBe(1);
            expect(scope.alignedGoals.length).toBe(1);
            expect(scope.chartData.series).toBeDefined();
            expect(managerAlertSrvc.getFiltersByMemberId).toHaveBeenCalled();
            expect(goalAdminSrvc.getDashboardAlignedGoals).toHaveBeenCalled();
        });
        xit('Test 3 - showAlignedGoals', function () {
            httpBackend.whenGET('/svc/Goal/GetDashboardAlignedGoalsById?goalId=5&skip=0&take=10')
                    .respond(200, [{Department: 'test', Name:' team goal'}]);
            spyOn(goalAdminSrvc,'getDashboardAlignedGoalById').andCallThrough();
            scope.showAlignedGoals(5);
            httpBackend.flush();
            expect(scope.model.viewAlignGoals).toBeTruthy;
            expect(scope.alignedGoalsById.length).toBe(1);
            expect(scope.model.grid.align.goalId).toBe(5);
            expect(goalAdminSrvc.getDashboardAlignedGoalById).toHaveBeenCalled();
        });
        xit('Test 4 - showActivity', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetGoalActivity?interval=14&memberId=123')
                    .respond(200, {series:[{name: 'Direct Reports', data: []}]});
            spyOn(managerAlertSrvc,'getGoalActivity').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.showActivity(14);
            httpBackend.flush();
            expect(scope.chartData.series).toBeDefined();
            expect(managerAlertSrvc.getGoalActivity).toHaveBeenCalled();
        });
        xit('Test 5 - closeGoals', function () {
            scope.closeGoals('viewAlignGoals');
            expect(scope.model.viewAlignGoals).not.toBeDefined();
        });
        xit('Test 6 - showGoals', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetTeamDashboardGoals?memberId=123&progressStatus=AtRisk&skip=0&sortCol=Name&sortDir=asc&take=10')
                    .respond(200, {count: 1, goals: [{hgId: '1', Name: 'goal'}]});
            spyOn(managerAlertSrvc,'getTeamDashboardGoals').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.showGoals('AtRisk', 1);
            httpBackend.flush();
            expect(scope.model.viewGoals).toBeTruthy;
            expect(scope.goals.length).toBe(1);
            expect(managerAlertSrvc.getTeamDashboardGoals).toHaveBeenCalled();
        });
        xit('Test 7 - updateStats', function () {
            spyOn(managerAlertSrvc,'getGoalDashboardStats').andCallThrough();
            spyOn(goalAdminSrvc,'getDashboardAlignedGoals').andCallThrough();
            spyOn(managerAlertSrvc,'getGoalActivity').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.updateStats({data: [{id: '123', name: 'test'}], isDisplay: true, model: 'departmentId'});
            httpBackend.flush();
            expect(scope.stats.AtRisk).toBe(1);
            expect(scope.alignedGoals.length).toBe(1);
            expect(scope.chartData.series).toBeDefined();
            expect(managerAlertSrvc.getGoalDashboardStats).toHaveBeenCalled();
            expect(goalAdminSrvc.getDashboardAlignedGoals).toHaveBeenCalled();
            expect(managerAlertSrvc.getGoalActivity).toHaveBeenCalled();
        });
        xit('Test 8 - sortByColumn goals', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetTeamDashboardGoals?memberId=123&skip=0&sortCol=Name&sortDir=desc&take=10')
                    .respond(200, {count: 1, goals: [{hgId: '1', Name: 'goal'}]});
            spyOn(managerAlertSrvc,'getTeamDashboardGoals').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.sortByColumn('goals', 'Name', 'desc');
            httpBackend.flush();
            expect(scope.model.grid.goals.sortCol).toBe('Name');
            expect(scope.model.grid.goals.sortDir).toBe('desc');
            expect(managerAlertSrvc.getTeamDashboardGoals).toHaveBeenCalled();
        });
        xit('Test 9 - pagingGrid', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetTeamDashboardGoals?memberId=123&skip=10&sortCol=Name&sortDir=asc&take=10')
                    .respond(200, {count: 1, goals: [{hgId: '1', Name: 'goal'}]});
            spyOn(managerAlertSrvc,'getTeamDashboardGoals').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.pagingGrid('goals', 1);
            httpBackend.flush();
            expect(scope.model.grid.goals.skip).toBe(10);
            expect(managerAlertSrvc.getTeamDashboardGoals).toHaveBeenCalled();
        });
    });
});