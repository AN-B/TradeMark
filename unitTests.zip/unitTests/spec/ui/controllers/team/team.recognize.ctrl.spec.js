define([
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (cache) {
    describe('team tab action recognize spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            location;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, $timeout, ManagerAlertSrvc) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            managerAlertSrvc = ManagerAlertSrvc;
            ctrl = $controller('TeamRecognizeCtrl', {$scope: scope});
            httpBackend = $injector.get('$httpBackend');
            location = $injector.get("$location");
            timeout = $injector.get('$timeout');
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 - TeamRecognizeCtrl should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 - change userInfo should get recognize Stats', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetRecognizeTeamStats?memberId=123&search=&skip=0&take=9')
                    .respond(200, [1,2,3]);
            spyOn(managerAlertSrvc,'getRecognizeTeamStats').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            expect(scope.stats.length).toBe(3);
            expect(managerAlertSrvc.getRecognizeTeamStats).toHaveBeenCalled();              
        });
        it('Test 3 - loadDirectReports' , function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetRecognizeTeamStats?memberId=123&search=&skip=0&take=9')
                    .respond(200, {alerts: [1,2,3], weight: [1,2,3]});
            spyOn(location, 'path').andCallFake(function(){});
            var user = {
                UserId: '125',
                FullName: 'test',
                Position: 'Position',
                hgId: '125'
            },
            memberBreadcrumb;
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            cache.set('memberBreadcrumb', [
                { hgId : '123', UserId : '123', FullName : 'test', Position : 'Position' },
                { hgId : '124', UserId : '124', FullName : 'test', Position : 'Position' },
                { hgId : '125', UserId : '125', FullName : 'test', Position : 'Position' }]);
            scope.loadDirectReports(user);
            httpBackend.flush();
            memberBreadcrumb = cache.get('memberBreadcrumb');
            expect(memberBreadcrumb.length).toBe(2);
            expect(location.path).toHaveBeenCalledWith('/Team/Recognize/125');          
        });
        xit('Test 4 - change searchTerm should get recognize Stats', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetRecognizeTeamStats?memberId=123&search=test&skip=0&take=9')
                    .respond(200, [1,2,3]);
            spyOn(managerAlertSrvc,'getRecognizeTeamStats').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.model.searchTerm = 'test';
            scope.$digest();
            timeout.flush();
            httpBackend.flush();
            expect(scope.stats.length).toBe(6);
            expect(managerAlertSrvc.getRecognizeTeamStats).toHaveBeenCalled();              
        });
        it('Test 5 - change bottomScroll should get next set of recognize Stats', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetRecognizeTeamStats?memberId=123&search=&skip=0&take=9')
                    .respond(200, [1,2,3,4,5,6,7,8,9]);
            httpBackend.whenGET('/svc/ManagerAlert/GetRecognizeTeamStats?memberId=123&search=&skip=9&take=9')
                    .respond(200, [4,5,6]);
            spyOn(managerAlertSrvc,'getRecognizeTeamStats').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            expect(scope.stats.length).toBe(9);
            scope.$broadcast('bottomScroll');
            timeout.flush();
            httpBackend.flush();
            expect(scope.stats.length).toBe(12);
            expect(managerAlertSrvc.getRecognizeTeamStats).toHaveBeenCalled();              
        });
    });
});