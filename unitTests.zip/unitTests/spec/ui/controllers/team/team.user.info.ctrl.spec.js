define([
    'static/source/core/collectionCache',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (cache, userJson) {
    describe('team tab user info spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            location;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, MemberSrvc) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            userSvc = UserSrvc;
            memberSvc = MemberSrvc;
            ctrl = $controller('TeamUserInfoCtrl', {$scope: scope});
            httpBackend = $injector.get('$httpBackend');
            location = $injector.get("$location");
            cache.clear('user');
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 - TeamUserInfoCtrl should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 - init()', function () {
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            spyOn(userSvc, 'getUser').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userSvc.getUser).toHaveBeenCalled();
            expect(scope.model.userInfo.FullName).toBe('Tuan Pham-Barnes');
        });

    });
});