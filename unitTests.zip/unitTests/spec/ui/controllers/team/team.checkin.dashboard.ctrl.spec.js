define([
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (cache) {
    describe('team tab checkin dashboard spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            location;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, $timeout, ManagerAlertSrvc) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            managerAlertSrvc = ManagerAlertSrvc;
            ctrl = $controller('TeamCheckinDashboardCtrl', {$scope: scope});
            httpBackend = $injector.get('$httpBackend');
            location = $injector.get("$location");
            timeout = $injector.get('$timeout');
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckinFilters?memberId=123')
                    .respond(200, [{data: [{id: '123', name: 'test'}], isDisplay: true}]);
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=0&sortCol=OwnerName&sortDir=asc&take=10')
                    .respond(200, [{CycleId: '123', CycleTitle: 'test'},{CycleId: '124', CycleTitle: 'test1'}]);
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=0&sortCol=OwnerName&sortDir=asc&status=Archived&take=10')
                .respond(200, [{CycleId: '123', CycleTitle: 'test'},{CycleId: '124', CycleTitle: 'test1'}]);
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=0&sortCol=OwnerName&sortDir=asc&status=Completed&take=10')
                .respond(200, [{CycleId: '123', CycleTitle: 'test'},{CycleId: '124', CycleTitle: 'test1'}]);
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=10&sortCol=OwnerName&sortDir=asc&status=Completed&take=10')
                .respond(200, [{CycleId: '123', CycleTitle: 'test'},{CycleId: '124', CycleTitle: 'test1'}]);
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckinsStats?memberId=123')
                    .respond(200, {Completed:1, NeedsYourAction:1, WaitingOnEmployee:7, Archived:9});
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckinActivity?interval=7&memberId=123')
                    .respond(200, {series:[{name: 'Direct Reports', data: []}]});
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckinActivity?interval=14&memberId=123')
                    .respond(200, {series:[{name: 'Direct Reports', data: []}]});

        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 - TeamCheckinDashboardCtrl should exist', function () {
            expect(ctrl).toBeDefined();
        });
        xit('Test 2 - change userInfo should get filters and checkins and stats and chart', function () {
            spyOn(managerAlertSrvc,'getDashboardCheckinFilters').andCallThrough();
            spyOn(managerAlertSrvc,'getDashboardCheckinStats').andCallThrough();
            spyOn(managerAlertSrvc,'getDashboardCheckins').andCallThrough();
            spyOn(managerAlertSrvc,'getDashboardCheckinActivity').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            expect(scope.filters.length).toBe(1);
            expect(scope.stats.Completed).toBe(1);
            expect(scope.checkins.length).toBe(2);
            expect(scope.chartData.series).toBeDefined();
            expect(managerAlertSrvc.getDashboardCheckinFilters).toHaveBeenCalled();
            expect(managerAlertSrvc.getDashboardCheckinStats).toHaveBeenCalled();
            expect(managerAlertSrvc.getDashboardCheckins).toHaveBeenCalled();
            expect(managerAlertSrvc.getDashboardCheckinActivity).toHaveBeenCalled();
        });
        it('Test 3 - showActivity', function () {
            httpBackend.whenGET('/svc/ManagerAlert/getDashboardCheckinActivity?interval=14&memberId=123')
                    .respond(200, {series:[{name: 'Direct Reports', data: []}]});
            spyOn(managerAlertSrvc,'getDashboardCheckinActivity').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.showActivity(14);
            httpBackend.flush();
            expect(scope.chartData.series).toBeDefined();
            expect(managerAlertSrvc.getDashboardCheckinActivity).toHaveBeenCalled();
        });
        it('Test 4 - updateCheckins', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=0&sortCol=Name&sortDir=asc&status=Archived&take=10')
                    .respond(200, {count: 1, checkins: [{hgId: '1', OwnerName: 'goal'}]});
            spyOn(managerAlertSrvc,'getDashboardCheckins').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.updateCheckins('Archived');
            httpBackend.flush();
            expect(managerAlertSrvc.getDashboardCheckins).toHaveBeenCalled();
        });
        it('Test 5 - updateStats', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=0&sortCol=Name&sortDir=asc&status=Completed&take=10')
                    .respond(200, {count: 2, checkins: [{CycleId: '123', CycleTitle: 'test'},{CycleId: '124', CycleTitle: 'test1'}]});
            spyOn(managerAlertSrvc,'getDashboardCheckinStats').andCallThrough();
            spyOn(managerAlertSrvc,'getDashboardCheckins').andCallThrough();
            spyOn(managerAlertSrvc,'getDashboardCheckinActivity').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.updateStats({
                data: [{id: 1, name: 'test'}],
                model: 'departmentId',
                isDisplay: true
            });
            httpBackend.flush();
            expect(scope.stats.Completed).toBe(1);
            expect(scope.chartData.series).toBeDefined();
            expect(managerAlertSrvc.getDashboardCheckinStats).toHaveBeenCalled();
            expect(managerAlertSrvc.getDashboardCheckins).toHaveBeenCalled();
            expect(managerAlertSrvc.getDashboardCheckinActivity).toHaveBeenCalled();
        });
        it('Test 6 - sortByColumn checkin', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=0&sortCol=OwnerName&sortDir=desc&status=Completed&take=10')
                    .respond(200, {count: 2, checkins: [{CycleId: '123', CycleTitle: 'test'},{CycleId: '124', CycleTitle: 'test1'}]});
            spyOn(managerAlertSrvc,'getDashboardCheckins').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.sortByColumn('checkin', 'OwnerName', 'desc');
            httpBackend.flush();
            expect(scope.model.grid.sortCol).toBe('OwnerName');
            expect(scope.model.grid.sortDir).toBe('desc');
            expect(managerAlertSrvc.getDashboardCheckins).toHaveBeenCalled();
        });
        it('Test 7 - pagingGrid', function () {
            httpBackend.whenGET('/svc/ManagerAlert/GetDashboardCheckins?memberId=123&skip=10&sortCol=Name&sortDir=asc&status=Completed&take=10')
                    .respond(200, {count: 1, checkins: [{hgId: '1', OwnerName: 'test'}]});
            spyOn(managerAlertSrvc,'getDashboardCheckins').andCallThrough();
            scope.model.userInfo = {
                UserId: '123',
                FullName: 'test',
                Position: 'Position',
                hgId: '123'
            };
            scope.$broadcast('model.userInfo');
            httpBackend.flush();
            scope.pagingGrid('checkin', 1);
            httpBackend.flush();
            expect(scope.model.grid.skip).toBe(10);
            expect(managerAlertSrvc.getDashboardCheckins).toHaveBeenCalled();
        });
    });
});