define([
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(groupJson, userJson){

    describe('Profile Company controller spec', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            rootScope,
            groupService;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, GroupSrvc) {
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            groupService = GroupSrvc;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET("/svc/User/Login")
                .respond(200, userJson.getCu());
            httpBackend.whenGET("/svc/Group/GetCurrentGroup")
                .respond(200, groupJson.getCurrentGroup());
            httpBackend.whenGET("/svc/Member/GetAllSubordinates")
                .respond(200, []);
            httpBackend.whenGET("/svc/Member/HasSubordinateMembers")
                .respond(200, {HasSubordinateMembers: true});
            scope = $rootScope.$new();
            ctrl = $controller('ProfileCompanyCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Profile Company controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 1 should call init()', function (){
            spyOn(groupService, 'getCurrentGroup').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.company).toBeDefined();
        });
    });
});