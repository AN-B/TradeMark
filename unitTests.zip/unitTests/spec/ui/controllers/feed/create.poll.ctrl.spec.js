define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function () {

    describe('Create Poll Ctrl spec', function() {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            http,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            scope = $rootScope.$new();
            rootScope = $rootScope;
            http = $injector.get('$http');
            location = $injector.get("$location");
            httpBackend = $injector.get("$httpBackend");
            ctrl = $controller('CreatePollCtrl', {$scope: scope});
            httpBackend.whenPOST('/svc/Poll/CreatePoll')
                .respond(200, {});
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: CreatePoll controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: init() should initialize scope.search', function () {
            scope.init();
            expect(scope.search).toBeDefined;
        });
        it('Test 3: backToFeed should call location.path', function () {
            rootScope.isHistory = false;
            scope.backToFeed();
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 4: addAnswerOption should increment index and add an answer option to the array', function () {
            scope.addAnswerOption();
            expect(scope.model.AnswerOptions.length).toBe(3);
            expect(scope.model.AnswerOptions[2].Value).toBe(2);
        });
        it('Test 5: removeAnswerOption should remove one answer option', function () {
            scope.removeAnswerOption(2);
            expect(scope.model.AnswerOptions.length).toBe(2);
        });
        it('Test 6: validation should succeed', function () {
            spyOn(scope, 'backToFeed').andCallFake(function () {});
            scope.init();
            scope.search.userMeta.selected.push('test');
            scope.model.Question = 'test';
            scope.model.AnswerOptions[0].Text = 'test1';
            scope.model.AnswerOptions[1].Text = 'test2';
            scope.model.StartDate = new Date(Date.now() + 86400000);
            scope.model.EndDate = new Date(scope.model.StartDate.getTime() + 86400000);
            scope.createPoll();
            expect(scope.model.Participants.length).toBe(1);
            httpBackend.flush();
            expect(scope.backToFeed).toHaveBeenCalled();
        });
        it('Test 7: validation should fail with questionInvalid', function () {
            scope.init();
            scope.search.userMeta.selected.push('test');
            scope.createPoll();
            expect(scope.model.questionInvalid).toBe(true);
        });
        it('Test 8: validation should fail with startDateInvalid', function () {
            scope.init();
            scope.search.userMeta.selected.push('test');
            scope.model.StartDate = new Date(Date.now() - 86400000);
            scope.createPoll();
            expect(scope.model.startDateInvalid).toBe(true);
        });
        it('Test 9: validation should fail with endDateInvalid', function () {
            scope.init();
            scope.search.userMeta.selected.push('test');
            scope.model.StartDate = new Date();
            scope.model.EndDate = new Date(scope.model.StartDate.getTime() + 86400000*6);
            scope.createPoll();
            expect(scope.model.endDateInvalid).toBe(true);
        });
        it('Test 10: validation should fail with endDateInvalid', function () {
            scope.init();
            scope.search.userMeta.selected.push('test');
            scope.model.StartDate = new Date();
            scope.model.EndDate = new Date(scope.model.StartDate.getTime() - 86400000);
            scope.createPoll();
            expect(scope.model.endDateInvalid).toBe(true);
        });
        it('Test 11: validation should fail with participantsInvalid', function () {
            scope.init();
            scope.model.StartDate = new Date(Date.now() + 86400000);
            scope.model.EndDate = new Date(scope.model.StartDate.getTime() + 86400000);
            scope.createPoll();
            expect(scope.model.participantsInvalid).toBe(true);
        });
        it('Test 12: validation should fail with answerOptionsInvalid', function () {
            scope.init();
            scope.model.AnswerOptions = [{Text: 'test'}, {Text: 'test'}];
            scope.model.StartDate = new Date(Date.now() + 86400000);
            scope.model.EndDate = new Date(scope.model.StartDate.getTime() + 86400000);
            scope.createPoll();
            expect(scope.model.answerOptionsInvalid[1].invalid).toBe(true);
        });
    });
});
