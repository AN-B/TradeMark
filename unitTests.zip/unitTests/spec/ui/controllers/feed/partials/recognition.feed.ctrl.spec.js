define([
    'static/source/core/enums/events',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/teams.json',
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/feed.json',
    'unitTests/ui-mocks/comments.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (events, userJson, teamsJson, groupJson, feedJson, commentsJson) {

    describe('Recognition Feed controller spec -> ', function () {
        var scope,
            ctrl,
            rootScope,
            backend,
            routeParams,
            recognitionSrvc,
            commentSrvc,
            groupSrvc,
            userSrvc,
            feedSrvc,
            comment,
            currentTime,
            toastrSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, FeedSrvc, CommentSrvc, GroupSrvc,
                                    UserSrvc, RecognitionSrvc, ToastrSrvc) {
            comment = feedJson.get().feeds[10].comments[0];
            feedSrvc = FeedSrvc;
            commentSrvc = CommentSrvc;
            groupSrvc = GroupSrvc;
            userSrvc = UserSrvc;
            recognitionSrvc = RecognitionSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            toastrSrvc = ToastrSrvc;
            backend = $injector.get("$httpBackend");
            backend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            backend.whenGET('/svc/Team/GetTeamsOwnOrBelong').respond(200, teamsJson.getTeamsForFeeds());
            backend.whenGET('/svc/Group/GetCurrentGroupMembersDTO?es=true&io=true&status=Active').respond(200, groupJson.getCurrentMembersDto());
            backend.whenPOST('/svc/Group/GetOffBoardedMemberIds').respond(200, {value: 'done'});
            backend.whenGET('/svc/Feed/GetCompanyFeed?skip=0&take=20').respond(200, feedJson.get());
            backend.whenPOST('/svc/Feed/GetFeedByMemberId').respond(200, feedJson.get());
            backend.whenPOST('/svc/Comment/GetCommentsByEntityIds').respond(200, commentsJson.getCommentsForFeeds());
            backend.whenPOST("/svc/Comment/CommentBatch").respond(200, {});
            backend.whenPOST("/svc/Comment/CommentRecognition").respond(200, {});
            backend.whenGET("/svc/Comment/GetCommentByBatchId?BatchId=test").respond(200, [{
                CreatedDate: '1234',
                Comment: 'test',
                UserId: 'abac-123'
            }]);
            backend.whenPOST("/svc/Comment/Like").respond(200, {});
            backend.whenPOST("/svc/Recognition/HideRecognition").respond(200, {value: 'done'});
            backend.whenPOST("/svc/Recognition/DeleteRecognition").respond(200, {value: 'done'});
            backend.whenPOST("/svc/Recognition/GetOffBoardedMemberIdsFromMemberIds").respond(200, {});
            backend.whenPOST("/svc/Comment/DeleteComment").respond(200, {value: 'done'});
            backend.whenPOST("/svc/Recognition/Congrat").respond(200, {value: 'done'});
            backend.whenGET("/svc/Survey/GetMyPendingPulseSurvey").respond(200, {value: [1, 2, 3]});
            backend.whenGET("/svc/Group/GetCommentIntervalSetting").respond(200, {CommentEditInterval: 30000});
            backend.whenPOST("/svc/Comment/EditComment").respond(200, feedJson.commentJson());
            backend.whenPOST("/svc/Recognition/AddPointsToRecognitions").respond(200, 'done');

            scope = $rootScope.$new();
            scope.userData = {
                memberId: 'test'
            };
            ctrl = $controller('RecognitionFeedCtrl', {$scope: scope});
            userSrvc.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            backend.verifyNoOutstandingExpectation();
            backend.verifyNoOutstandingRequest();
        });
        it('Test 1: Recognition Feed controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: Recognition Feed controller should call initFeed()', function (){
            spyOn(userSrvc, 'getUser').andCallThrough();
            scope.initFeed();
            backend.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
            expect(scope.userData).toBeDefined();
        });
        it('Test 3: Recognition Feed controller should call getCompanyFeed if type == Company', function (){
            scope.$parent.feedType = 'company';
            spyOn(feedSrvc, 'getCompanyFeed').andCallThrough();
            scope.initFeed();
            backend.flush();
            expect(feedSrvc.getCompanyFeed).toHaveBeenCalled();
            expect(scope.feeds).toBeDefined();
        });
        it('Test 4: Recognition Feed controller should call getFeedByMemberId if type != Company', function (){
            scope.$parent.feedType = 'profile';
            routeParams.memberId = 'ede16340-c87b-11e2-aa05-198054fd4117';
            spyOn(feedSrvc, 'getFeedByMemberId').andCallThrough();
            scope.initFeed();
            backend.flush();
            expect(feedSrvc.getFeedByMemberId).toHaveBeenCalledWith({skip : 0, take : 20, TeamId : undefined, memberId: 'ede16340-c87b-11e2-aa05-198054fd4117'});
            expect(scope.feeds).toBeDefined();
        });
        it('Test 5: Recognition Feed controller hide recognition', function (){
            spyOn(recognitionSrvc, 'hideRecognition').andCallThrough();
            scope.hideRecognition(0,1);
            backend.flush();
            expect(recognitionSrvc.hideRecognition).toHaveBeenCalledWith({RecognitionId: 0, batchId: 1});
        });
        it('Test 6: Recognition Feed controller delete recognition', function (){
            spyOn(recognitionSrvc, 'deleteRecognition').andCallThrough();
            scope.deleteRecognition(0,1);
            backend.flush();
            expect(recognitionSrvc.deleteRecognition).toHaveBeenCalledWith({RecognitionId: 0, batchId: 1});
        });
        it('Test 7: Recognition Feed controller delete comment', function (){
            spyOn(commentSrvc, 'deleteComment').andCallThrough();
            scope.deleteComment(123);
            backend.flush();
            expect(commentSrvc.deleteComment).toHaveBeenCalledWith({CommentId: 123});
        });
        it('Test 8: Recognition Feed controller submit comment', function (){
            scope.initFeed();
            spyOn(commentSrvc, 'commentBatch').andCallThrough();
            backend.flush();
            scope.submitComment({comment: 'blah'}, '4d7e26a0-9985-11e3-a57e-ef0c5cd920f3');
            backend.flush();
            expect(commentSrvc.commentBatch).toHaveBeenCalledWith(
                {
                    Comment: 'blah',
                    EntityId: '4d7e26a0-9985-11e3-a57e-ef0c5cd920f3',
                    IsPublic: true,
                    EntityType: 'Recognition'
                });
        });

        it('Test 9: Recognition Feed controller congrats', function (){
            var feed = {
                    hgId: '909',
                    batchId: '909',
                    isCongrats: false,
                    comments: [],
                    congratMemberIds: [],
                    congratsCount: 0
                },
                congratsProcessed = [];
            spyOn(recognitionSrvc, 'congrats').andCallThrough();
            scope.congrats(feed);
            backend.flush();
            expect(recognitionSrvc.congrats).toHaveBeenCalledWith({RecognitionIds: feed.hgId});
            expect(feed.MeCongrated).toBeTruthy();
            expect(feed.congratsCount).toBe(1);
        });
        it('Test 10: toggleVisible should call GetCommentByBatchId to get more comments if comments length less than commentCount', function (){
            scope.isIso = false;
            var feed = {batchId: 'test', commentCount: 5, commentStart: 3, comments: [1, 2, 3]};
            spyOn(commentSrvc, 'getCommentsByBatchId').andCallThrough();
            scope.toggleVisible(feed);
            backend.flush();
            expect(commentSrvc.getCommentsByBatchId).toHaveBeenCalledWith('test');
        });
        it('Test 11: toggleEdit should toggle the visibility of edit block', function (){
            scope.toggleEdit(comment);
            expect(comment.newComment.comment.html).toBe('old comment');
            expect(comment.showEditDiv).toBeTruthy();
        });
        it('Test 12: cancelEditComment should cancel the edit block and the new comment', function (){
            scope.cancelEditComment(comment);
            expect(comment.newComment).toBe();
            expect(comment.showEditDiv).toBe();
        });
        it('Test 13: editComment should edit the old comment if change made in comment is under commenteditintevral', function (){
            backend.whenPOST("/svc/Comment/EditComment").respond(200, commentsJson.getCommentsForFeeds()[5]);
            scope.initFeed();
            backend.flush();
            currentTime = Date.now();

            comment.newComment = {comment: {html: 'Hello World'}};
            comment.ModifiedDate = currentTime + 120;
            comment.isEdit = true;
            spyOn(commentSrvc, 'editComment').andCallThrough();
            spyOn(toastrSrvc, 'success').andCallThrough();
            scope.editComment({comment: {html: 'Hello World'}},comment);
            backend.flush();
            expect(commentSrvc.editComment).toHaveBeenCalledWith(comment);
            expect(toastrSrvc.success).toHaveBeenCalledWith('profile.partials.rec.fee.che');
        });
        it('Test 14: editComment should not edit the old comment if change made in comment is not under commenteditintevral', function (){
            currentTime = Date.now();
            comment.ModifiedDate = currentTime + 120;
            spyOn(toastrSrvc, 'error').andCallThrough();
            comment.ModifiedDate = currentTime - 120;
            scope.editComment({comment:{html:""}}, comment);
            expect(comment.newComment).toBeFalsy();
            expect(comment.showEditDiv).toBeFalsy();
            expect(toastrSrvc.error).toHaveBeenCalledWith('profile.partials.rec.fee.bcm');
        });
        it('Test 15: add points to Recognitions', function (){
            var feed = feedJson.get().feeds[0];
            spyOn(recognitionSrvc, 'addPointsToRecogntions').andCallThrough();
            feed.AddPoints = 10;
            scope.addPointstoRecognitions(feed);
            backend.flush();
            expect(recognitionSrvc.addPointsToRecogntions).toHaveBeenCalled();
            expect(feed.actualPointValue).toBe(10);
        });
        it('Test 16 should call backend if user didnt like comment yet', function (){
            spyOn(commentSrvc, 'likeComment').andCallThrough();
            var comment = {LikedMembers: [], hgId: 'test'};
            scope.likeComment(comment);
            backend.flush();
            expect(comment.LikedMembers[0].MemberId).toBe('test');
            expect(commentSrvc.likeComment).toHaveBeenCalled();
        });
        it('Test 17 Test 16 should not call backend if user like comment', function (){
            spyOn(commentSrvc, 'likeComment').andCallThrough();
            var comment = {LikedMembers: [{MemberId: 'test'}], hgId: 'test'};
            scope.likeComment(comment);
            expect(commentSrvc.likeComment).not.toHaveBeenCalled();
        });

    });
});
