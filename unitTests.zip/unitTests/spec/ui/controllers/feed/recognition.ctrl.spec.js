define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/profile.recognition.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, recJson){

    describe('Profile recognitions controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            recognitionSrvc,
            userSrvc,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, UserSrvc, RecognitionSrvc) {
            userSrvc  = UserSrvc;
            recognitionSrvc = RecognitionSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            location = $injector.get("$location");
            scope = $rootScope.$new();
            userSrvc.clearUserCache();
            scope.model = {};
            ctrl = $controller('RecognitionCtrl', {
                $scope: scope
            });
            scope
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: should call backend and populate memberRecognitions', function (){
            httpBackend.whenGET('/svc/Recognition/GetMemberRecogntions?memberId=d2e0d320-a119-11e2-b177-7d64c8315189&take=3')
                .respond(200, recJson.getInitRecognitions());
            spyOn(userSrvc, 'getUser').andCallThrough();
            spyOn(recognitionSrvc, 'getMemberRecogntions').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
            expect(scope.model).toBeDefined();
            expect(recognitionSrvc.getMemberRecogntions).toHaveBeenCalled();
            expect(scope.memberRecognitions).toBeDefined();
            expect(scope.memberRecognitions.counts).toBeDefined();
            expect(scope.memberRecognitions.company).toBeDefined();
            expect(scope.memberRecognitions.value).toBeDefined();
        });
        it('Test 2: navigateToRecog should call location.path', function (){
            spyOn(location, 'path').andCallFake(function(){});
            scope.navigateToRecog('test');
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 3: getRecognitionsByCategory() should call backend populate scope object', function (){
            httpBackend.whenGET('/svc/Recognition/GetMemberCompany?skip=3&take=3')
                .respond(200, recJson.getCompany());
            spyOn(recognitionSrvc, 'getRecognitionsByCategory').andCallThrough();
            scope.getRecognitionsByCategory('company', 1);
            httpBackend.flush();
            expect(scope.memberRecognitions.company).toBeDefined();
            expect(scope.memberRecognitions.company.length > 0).toBeTruthy();
            expect(recognitionSrvc.getRecognitionsByCategory).toHaveBeenCalledWith({category : 'company', memberId: undefined, skip: 3, take: 3});
        });
    });
});

