define([
    'unitTests/ui-mocks/poll.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (pollJson) {

    describe('Polls Ctrl spec', function() {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            http,
            timeout,
            window;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            scope = $rootScope.$new();
            rootScope = $rootScope;
            http = $injector.get('$http');
            httpBackend = $injector.get("$httpBackend");
            timeout = $injector.get('$timeout');
            window = $injector.get('$window');
            ctrl = $controller('PollsCtrl', {$scope: scope});
            httpBackend.whenGET('/svc/Poll/GetMyPolls')
                .respond(200, pollJson.getMyPolls());
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Polls controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: init should call getMyPolls() and startTimer()', function (){
            scope.init();
            expect(scope.model.selectedPoll).toBe(0);
            httpBackend.flush();
            timeout.flush();
            expect(scope.polls.length).toBe(1);
            expect(scope.timer).toBeDefined();
        });
        it('Test 3: setSelectedPoll should set model.selectedPoll and setTimerLabels', function () {
            scope.polls = pollJson.getMyPolls();
            scope.polls[0].EndDate = Date.now() + 86500000;
            scope.setSelectedPoll(0);
            expect(scope.model.selectedPoll).toBe(0);
            timeout.flush();
            expect(scope.model.timeRemaining).toBe(1);
            expect(scope.model.timeAlmostOut).toBe(false);
        });
        it('Test 4: setSelectedPoll should set model.selectedPoll and setTimerLabels', function () {
            scope.polls = pollJson.getMyPolls();
            scope.polls[0].EndDate = Date.now() + 7201000;
            scope.setSelectedPoll(0);
            expect(scope.model.selectedPoll).toBe(0);
            timeout.flush();
            expect(scope.model.timeRemaining).toBe(2);
            expect(scope.model.timeAlmostOut).toBe(false);
        });
        it('Test 5: setSelectedPoll should set model.selectedPoll and setTimerLabels', function () {
            scope.polls = pollJson.getMyPolls();
            scope.polls[0].EndDate = Date.now() + 1801000;
            scope.setSelectedPoll(0);
            expect(scope.model.selectedPoll).toBe(0);
            timeout.flush();
            expect(scope.model.timeRemaining).toBe(30);
            expect(scope.model.timeAlmostOut).toBe(true);
        });
        it('Test 6: PollUpdatedListener', function () {
            spyOn(scope, '$broadcast').andCallThrough();
            scope.polls = pollJson.getMyPolls();
            rootScope.$broadcast('PollUpdated', {
                Result: {
                    PollQuestionId: 'ba042280-7100-11e5-b54a-a17009f8745a',
                    OutstandingVotes: 1,
                    result: [
                        {"Vote":5},
                        {"Vote":6}
                    ]
                }
            });
            timeout.flush();
            expect(scope.polls[0].OutstandingVotes).toEqual(1);
            expect(scope.polls[0].AnswerResults[0].Vote).toEqual(5);
            expect(scope.polls[0].AnswerResults[1].Vote).toEqual(6);
            expect(scope.$broadcast).toHaveBeenCalled();

        });
    });
});
