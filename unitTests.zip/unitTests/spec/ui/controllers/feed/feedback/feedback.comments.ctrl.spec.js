define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/feedback.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, feedbackJson){

    describe('feedback comments controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            backend,
            routeParams,
            feedbackSrvc,
            userSrvc,
            location,
            timeout,
            sce;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, FeedbackSrvc, UserSrvc, $timeout) {
            feedbackSrvc  = FeedbackSrvc;
            userSrvc = UserSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            backend = $injector.get("$httpBackend");
            location = $injector.get("$location");
            timeout = $timeout;
            sce = $injector.get("$sce");
            backend.whenGET('/svc/Feedback/Get?batchId=test&memberId=test')
                .respond(200, feedbackJson.getDetail());
            backend.whenPOST('/svc/Feedback/Comment')
                .respond(200, {});
            backend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            routeParams.batchId = 'test';
            routeParams.memberId = 'test';
            scope = $rootScope.$new();
            userSrvc.clearUserCache();
            ctrl = $controller('FeedbackCommentsCtrl', {
                $scope: scope
            });
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            routeParams.batchId = '';
            routeParams.memberId = '';
            scope.$digest();
            backend.verifyNoOutstandingExpectation();
            backend.verifyNoOutstandingRequest();
        });

        it('Test 1: controller should be defined', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: getUnsafeHtml should call $sce.trustAsHtml', function (){
            spyOn(sce,'trustAsHtml').andCallThrough();
            var test = scope.getUnsafeHtml('<div></div>');
            expect(sce.trustAsHtml).toHaveBeenCalled();
        });
        it('Test 3: initComments should call backend', function (){
            scope.initComments();
            backend.flush();
            expect(scope.feedback).toBeDefined();
        });
        it('Test 4: submitComment should call backend', function (){
            spyOn(feedbackSrvc, 'comment').andCallThrough();
            scope.feedback = feedbackJson.getDetail();

            scope.request = {comment: 'test'};
            scope.submitComment(scope.request);
            backend.flush();
            expect(scope.feedback.Comments.length).toBe(3);
            expect(feedbackSrvc.comment).toHaveBeenCalled();
        });
        it('Test 5: submitComment should call backend', function (){
            spyOn(feedbackSrvc, 'comment').andCallThrough();
            scope.feedback = feedbackJson.getDetail();
            scope.request = {comment: ''};
            scope.submitComment(scope.request);
            expect(scope.feedback.Comments.length).toBe(2);
            expect(feedbackSrvc.comment).not.toHaveBeenCalled();
        });
        it('Test 6: $destroy should destroy listeners', function (){
            spyOn(scope,'notificationEvent').andCallThrough();
            scope.$broadcast('$destroy');
            expect(scope.notificationEvent).toHaveBeenCalled();
        });
        it('Test 7: on newFeedbackComment it should call backend and get comments if entity id is equal hgid of the conversation', function (){
            scope.feedback = {hgId: 'test'};
            backend.whenGET('/svc/Feedback/GetCommentsByEntityId?EntityId=test')
                .respond(200, [{}]);

            spyOn(feedbackSrvc,'getCommentsByEntityId').andCallThrough();
            scope.$broadcast('newFeedbackComment', 'test');
            backend.flush();
            expect(feedbackSrvc.getCommentsByEntityId).toHaveBeenCalled();
            expect(scope.feedback.Comments.length).toBe(1);

        });
        it('Test 8: on newFeedbackComment it should not call backend and get comments if entity id is not equal hgid of the conversation', function (){
            spyOn(feedbackSrvc,'getCommentsByEntityId').andCallThrough();
            scope.$broadcast('newFeedbackComment', 'test');
            expect(feedbackSrvc.getCommentsByEntityId).not.toHaveBeenCalled();

        });
    });
});