define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/feedback.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, feedbackJson){

    describe('Profile feedback controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            backend,
            routeParams,
            feedbackSrvc,
            userSrvc,
            location,
            timeout,
            sce;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, FeedbackSrvc, UserSrvc, $timeout) {
            feedbackSrvc  = FeedbackSrvc;
            userSrvc = UserSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            backend = $injector.get("$httpBackend");
            location = $injector.get("$location");
            timeout = $timeout;
            sce = $injector.get("$sce");
            backend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());

            scope = $rootScope.$new();
            userSrvc.clearUserCache();
            ctrl = $controller('ProfileFeedbackCtrl', {
                $scope: scope
            });
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
            backend.verifyNoOutstandingExpectation();
            backend.verifyNoOutstandingRequest();
        });

        it('Test 1: controller should be defined', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: initFeedback should call backend and populate scope.feedbacks object', function (){
            spyOn(userSrvc,'getUser').andCallThrough();
            spyOn(feedbackSrvc,'getByUserId').andCallThrough();

            backend.whenGET('/svc/Feedback/GetByUserId?&userId=d2e0d320-a119-11e2-b177-7d64c8315189&skip=0&take=10')
                .respond(200, feedbackJson.getByUserId());
            scope.initFeedback();
            backend.flush();
            expect(feedbackSrvc.getByUserId).toHaveBeenCalled();
            expect(userSrvc.getUser).toHaveBeenCalled();
        });
        it('Test 3: getUnsafeHtml should call $sce.trustAsHtml', function (){
            spyOn(sce,'trustAsHtml').andCallThrough();
            var test = scope.getUnsafeHtml('<div></div>');
            expect(sce.trustAsHtml).toHaveBeenCalled();
        });
        it('Test 4: $scope.watches.bottomScroll watch should trigger call to backend if there is isData true', function (){
            backend.whenGET('/svc/Feedback/GetByUserId?&userId=test&skip=0&take=10')
                .respond(200, feedbackJson.getByUserId());
            scope.currentMemberId = 'test';
            scope.watches.isData = true;
            spyOn(feedbackSrvc,'getByUserId').andCallThrough();
            scope.$broadcast('bottomScroll');
            backend.flush();
            expect(feedbackSrvc.getByUserId).toHaveBeenCalled();
        });
        it('Test 5: $scope.watches.bottomScroll watch should not trigger call to backend if there is isData false', function (){
            scope.watches.isData = false;
            spyOn(feedbackSrvc,'getByUserId').andCallThrough();
            scope.$broadcast('bottomScroll');
            expect(feedbackSrvc.getByUserId).not.toHaveBeenCalled();
        });
        it('Test 6: $destroy should destroy listeners', function (){
            spyOn(scope.watches,'bottomScroll').andCallThrough();
            scope.$broadcast('$destroy');
            expect(scope.watches.bottomScroll).toHaveBeenCalled();
        });
        it('Test 7: should call backend when search is greater than 3 char', function (){
            backend.whenGET('/svc/Feedback/GetByUserId?&userId=test&skip=0&take=10&search=tyt')
                .respond(200, feedbackJson.getByUserId());
            spyOn(feedbackSrvc,'getByUserId').andCallThrough();
            scope.setWatch();
            scope.currentMemberId = 'test';
            scope.watches.search = 'tyt';
            scope.$digest();
            expect(scope.watches.timeout).toBeDefined();
            timeout.flush();
            backend.flush();
            expect(feedbackSrvc.getByUserId).toHaveBeenCalled();
        });
        it('Test 8: should call backend when search is empty', function (){
            backend.whenGET('/svc/Feedback/GetByUserId?&userId=test&skip=0&take=10')
                .respond(200, feedbackJson.getByUserId());
            spyOn(feedbackSrvc,'getByUserId').andCallThrough();
            scope.setWatch();
            scope.currentMemberId = 'test';
            scope.watches.search = '';
            scope.$digest();
            expect(scope.watches.timeout).toBeDefined();
            timeout.flush();
            backend.flush();
            expect(feedbackSrvc.getByUserId).toHaveBeenCalled();
        });
        it('Test 9: should not call backend when search is 2 char', function (){
            backend.whenGET('/svc/Feedback/GetByUserId?&userId=test&skip=0&take=10')
                .respond(200, feedbackJson.getByUserId());
            spyOn(feedbackSrvc,'getByUserId').andCallThrough();
            scope.setWatch();
            scope.currentMemberId = 'test';
            scope.watches.search = '22';
            scope.$digest();
            expect(feedbackSrvc.getByUserId).not.toHaveBeenCalled();
        });
        it('Test 10: cancel timeout will be called if search string changes before timeout runs out', function (){
            backend.whenGET('/svc/Feedback/GetByUserId?&userId=test&skip=0&take=10')
                .respond(200, feedbackJson.getByUserId());
            spyOn(timeout,'cancel').andCallThrough();
            scope.setWatch();
            scope.currentMemberId = 'test';
            scope.watches.search = '222';
            scope.$digest();
            scope.watches.search = '2299';
            scope.$digest();
            expect(timeout.cancel).toHaveBeenCalled();
        });
        it('Test 11: on newFeedbackNotification event expect backend service to be called', function (){
            backend.whenGET('/svc/Feedback/GetDTOByEntityId?EntityId=test')
                .respond(200, feedbackJson.getByUserId()[0]);
            spyOn(feedbackSrvc, 'getDTOByEntityId').andCallThrough();
            scope.$broadcast('newFeedbackNotification', 'test');
            backend.flush();
            expect(feedbackSrvc.getDTOByEntityId).toHaveBeenCalled();
            expect(scope.feedbacks.length).toBe(1);
        });
    });
});
