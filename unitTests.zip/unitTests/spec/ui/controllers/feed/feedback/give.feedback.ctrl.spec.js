define([
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(groupJson, userJson){

    describe('Profile give feedback controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            feedbackSrvc,
            groupSrvc,
            location,
            window,
            userSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, FeedbackSrvc, GroupSrvc, UserSrvc) {
            feedbackSrvc  = FeedbackSrvc;
            groupSrvc = GroupSrvc;
            userSrvc = UserSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            window = $injector.get('$window');
            routeParams.memberId = '2de4bbf0-a0c6-11e2-a665-cf2c2ef6e160';
            location = $injector.get("$location");
            httpBackend.whenPOST('/svc/AutoComplete/GetPreSelectedItems')
                .respond(200, groupJson.getCurrentMembersDto());
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenPOST('/svc/Feedback/Create')
                .respond(200, 'done');

            scope = $rootScope.$new();
            ctrl = $controller('GiveFeedbackCtrl', {
                $scope: scope
            });
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            userSrvc.clearUserCache();
            routeParams.memberId = '';
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: controller should be defined', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: backToFeed should call location.path', function (){
            scope.backToFeed();
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 3: scope.searchMeta should be populated when init called', function (){
            spyOn(userSrvc,'getUser').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
        });
        it('Test 5: feedback.create should not be called if request is invalid', function (){
            spyOn(feedbackSrvc, 'create').andCallThrough();
            scope.feedback = {
                Subject: '',
                Recipients: []
            };
            scope.giveFeedback();
            expect(scope.feedback.invalidSubject).toBeTruthy();
            expect(scope.feedback.invalidRecipients).toBeTruthy();
            expect(feedbackSrvc.create).not.toHaveBeenCalled();
        });
        it('Test 6: feedback.create should be called if request is valid', function (){
            spyOn(feedbackSrvc, 'create').andCallThrough();
            scope.feedback = {
                Subject: 'test',
                Recipients: [{name: 'test'}]
            };

            scope.giveFeedback();
            httpBackend.flush();
            expect(feedbackSrvc.create).toHaveBeenCalled();
        });

    });
});