define([
    'unitTests/ui-mocks/modal',
    'unitTests/ui-mocks/recipients.delete.list.dlg.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(modalMock, recipients){

    describe('Recipient delete list dialog controller spec -> ', function() {
        var scope,
            modal,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            recognitionSrvc,
            userSrvc,
            recipient = recipients.getRecipients();

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, UserSrvc, RecognitionSrvc) {
            modal = modalMock;
            userSrvc  = UserSrvc;
            recognitionSrvc = RecognitionSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenPOST("/svc/Recognition/DeleteSingleRecognition").respond(200,{value: 'done'});
            httpBackend.whenPOST("/svc/Recognition/DeleteRecognition").respond(200,{value: 'done'});

            scope = $rootScope.$new();

            ctrl = $controller('RecipientsDeleteListDlgCtrl', {
                $rootScope: rootScope,
                $scope: scope,
                $modalInstance: modal,
                recipients:recipient,
                hgId: ["0"],
                batchId : "1"
            });
            userSrvc.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Recipient delete list dialog controller delete single recognition', function (){
            spyOn(recognitionSrvc, 'deleteSingleRecognition').andCallThrough();
            scope.deleteSingleRecognition(0,1);
            httpBackend.flush();
            expect(recognitionSrvc.deleteSingleRecognition).toHaveBeenCalledWith({RecognitionId: 0, batchId: 1});
        });
        it('Test 2: Recipient delete list dialog delete group recognition', function (){
            spyOn(recognitionSrvc, 'deleteRecognition').andCallThrough();
            scope.deleteRecognition(0,1);
            httpBackend.flush();
            expect(recognitionSrvc.deleteRecognition).toHaveBeenCalledWith({RecognitionId: 0, batchId: 1});
        });
        it('Test 3 : closeDialog() should close dialog', function () {
            spyOn(modal, 'dismiss').andCallThrough();
            scope.closeRecipientsDialog();
            expect(modal.dismiss).toHaveBeenCalledWith();
        });
    });
});