define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/survey.json',
    'static/source/core/enums/events',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (userJson, surveyJson, events) {

    describe('Pulse Survey Ctrl spec', function() {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            http,
            userService,
            surveySrvc,
            q,
            timeout,
            routeParams;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, SurveySrvc) {
            scope = $rootScope.$new();
            rootScope = $rootScope;
            userService = UserSrvc;
            surveySrvc = SurveySrvc;
            http = $injector.get('$http');
            httpBackend = $injector.get("$httpBackend");
            timeout = $injector.get("$timeout");
            routeParams = $injector.get("$routeParams");
            q = $injector.get("$q");
            ctrl = $controller('PulseSurveyCtrl', {$scope: scope});
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Survey/GetMyPendingPulseSurvey')
                .respond(200, {hgId: 'test'});
            httpBackend.whenPOST('/svc/Survey/AnswerPulseSurvey')
                .respond(200, {Points: 100});
            httpBackend.whenPOST('/svc/Survey/DismissPulseSurvey')
                .respond(200, {test: 'test'});
            userService.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: PulseSurveyCtrl controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: init should call scope.answerPulseQuestions() ', function (){
            spyOn(scope, 'answerPulseQuestions').andCallFake(function () {});
            routeParams.surveyAnswerId = 'test';
            routeParams.answer = 'test';
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.userData.surveyEnabled).toBe(true);
            expect(scope.pulseSurvey).toEqual({hgId: 'test'});
            expect(scope.answerPulseQuestions).toHaveBeenCalled();
        });
        it('Test 3: answerPulseQuestions() should validate true', function () {
            scope.pulseSurvey = surveyJson.getGroupPulseSurveyTemplate().Template.PulseQuestions[0];
            scope.answerPulseQuestions(0);
            httpBackend.flush();
            timeout.flush();
            expect(scope.pulseSurvey.Points).toEqual(100);
            expect(scope.pulseSurvey.AnswerValue).toBe(0);
            expect(scope.dismissPulseSurveyUI).toBe(true);
        });
        it('Test 3: answerPulseQuestions() with forSalesDemo===true', function () {
            scope.pulseSurvey = {};
            rootScope.forSalesDemo = true;
            scope.answerPulseQuestions(0);
            timeout.flush();
            expect(scope.pulseSurvey.Points).toEqual(150);
            expect(scope.dismissPulseSurveyUI).toBe(true);
        });
        it('Test 4: dismissPulseSubmitted() should delete scope.pulseSurvey', function () {
            scope.pulseSurvey = {test: 'test'};
            scope.dismissPulseSubmitted();
            expect(scope.pulseSurvey).not.toBeDefined();
        });
        it('Test 5: dismissPulse should delete pulseSurvey', function () {
            scope.pulseSurvey = {hgId: 'test'};
            scope.dismissPulse();
            httpBackend.flush();
            timeout.flush();
            expect(scope.pulseSurvey).not.toBeDefined();
        });
        it('Test 6: dismissPulse should delete pulseSurvey with forSalesDemo true', function () {
            rootScope.forSalesDemo = true;
            scope.pulseSurvey = {hgId: 'test'};
            scope.dismissPulse();
            expect(scope.pulseSurvey).not.toBeDefined();
        });
    });
});
