define([
    'unitTests/ui-mocks/recognition.detail.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(recJson){

    describe('Recognition detail controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            recognitionSrvc,
            commentsSrvc,
            location,
            modal,
            returnModel = {
                result: {
                    then: function (request) {
                        request = request;
                    }
                }
            };

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, RecognitionSrvc, CommentSrvc) {
            recognitionSrvc = RecognitionSrvc;
            commentsSrvc = CommentSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            location = $injector.get("$location");
            modal = $injector.get('$modal');
            httpBackend.whenGET('/svc/Recognition/GetRecognitionById?RecognitionId=123&Viewee=test').respond(200, recJson.get());
            routeParams.memberId = 'test';
            routeParams.recogId = '123';
            scope = $rootScope.$new();
            ctrl = $controller('RecognitionDetailsCtrl', {
                $scope: scope
            });
            scope.currentMemberId = 'test';
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
            routeParams.memberId = '';
            routeParams.recogId = '';
        });

        it('Test 1: init() should call backend and get recognition entity', function (){
            spyOn(recognitionSrvc, 'getRecognitionById').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.recognition).toBeDefined();
            expect(recognitionSrvc.getRecognitionById).toHaveBeenCalled();
        });
        it('Test 2: back() should navigate back to profile recognitions', function (){
            scope.back();
            expect(location.path).toHaveBeenCalledWith('Profile/Recognition/');
        });
        it('Test 3: submitComment should save comment', function (){
            httpBackend.whenPOST('/svc/Comment/CommentBatch').respond(200, {});
            scope.recognition = recJson.get();
            scope.submitComment({comment: 'test123'}, routeParams.recogId);
            httpBackend.flush();
            expect(scope.recognition.comments.length).toBe(4);
            expect(scope.recognition.commentCount).toBe(6);
        });
        it('Test 4: showAllComments should show more/less comments', function (){
            httpBackend.whenGET('/svc/Comment/GetCommentByBatchId?BatchId=456').respond(200, recJson.getComments());
            spyOn(commentsSrvc, 'getCommentsByBatchId').andCallThrough();
            scope.recognition = recJson.get();
            scope.showAllComments();
            httpBackend.flush();
            expect(scope.recognition.comments.length).toBe(3);
        });
        it('Test 5: congrats should add like to recognition', function (){
            httpBackend.whenPOST('/svc/Recognition/Congrat').respond(200, {});
            spyOn(recognitionSrvc, 'congrats').andCallThrough();
            scope.recognition = recJson.get();
            scope.congrats();
            httpBackend.flush();
            expect(scope.recognition.MeCongrated).toBeTruthy();
            expect(scope.recognition.congratsCount).toBe(3);
            expect(recognitionSrvc.congrats).toHaveBeenCalled();
        });
        it('Test 6: openLikerList should open liker dialog', function (){
            spyOn(modal, 'open').andCallFake(function () {});
            scope.openLikerList();
            expect(modal.open).toHaveBeenCalled();
        });
        it('Test 7: openPreviewCertificateDlg should open certificate dialog', function (){
            spyOn(modal, 'open').andCallFake(function () {});
            scope.openPreviewCertificateDlg();
            expect(modal.open).toHaveBeenCalled();
        });
        it('Test 8: likeComment should add like to comment', function (){
            httpBackend.whenPOST('/svc/Comment/Like').respond(200, {});
            spyOn(commentsSrvc, 'likeComment').andCallThrough();
            scope.recognition = recJson.get();
            scope.likeComment(recJson.getComments()[0]);
            httpBackend.flush();
            expect(commentsSrvc.likeComment).toHaveBeenCalled();
        });
        it('Test 9: addPointstoRecognitions should add points to recognition', function (){
            httpBackend.whenPOST('/svc/Recognition/AddPointsToRecognitions').respond(200, 'done');
            httpBackend.whenGET('/svc/Comment/GetCommentByBatchId?BatchId=456').respond(200, recJson.getComments());
            spyOn(recognitionSrvc, 'addPointsToRecogntions').andCallThrough();
            scope.recognition = recJson.get();
            scope.recognition.AddPoints = 10;
            scope.addPointstoRecognitions();
            httpBackend.flush();
            expect(recognitionSrvc.addPointsToRecogntions).toHaveBeenCalled();
        });
        it('Test 10: openGiftModal should open gift dialog', function (){
            spyOn(modal, 'open').andReturn(returnModel);
            scope.recognition = recJson.get();
            scope.openGiftModal();
            expect(modal.open).toHaveBeenCalled();
        });
    });
});
