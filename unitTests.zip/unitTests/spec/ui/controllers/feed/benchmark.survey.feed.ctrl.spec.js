define([
    'unitTests/ui-mocks/user.json',
    'static/source/core/enums/events',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (userJson, events) {

    describe('Benchmark Survey Feed Ctrl controller spec', function() {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            http,
            userService,
            surveySrvc,
            q;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, SurveySrvc) {
            scope = $rootScope.$new();
            rootScope = $rootScope;
            userService = UserSrvc;
            surveySrvc = SurveySrvc;
            http = $injector.get('$http');
            httpBackend = $injector.get("$httpBackend");
            q = $injector.get("$q");
            ctrl = $controller('BenchmarkSurveyFeedCtrl', {$scope: scope});
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            userService.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 BenchmarkSurvey Feed Ctrl Search controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 should call init()', function () {
            // mock UserSrvc.getUser() to avoid caching
            spyOn(userService, 'getUser').andCallFake(function () {
                var deferred = q.defer();
                http({
                        url: '/svc/User/Login',
                        method: 'GET',
                    }).then(function (response) {
                        deferred.resolve(response.data);
                    }, function (response) {
                        deferred.reject(response);
                    });
                return deferred.promise;
            });
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
        });
        it('Test 3 should set scope.flags.benchmarkSurvey to false on HgAppBenchmarkSurveyComplete event', function () {
            scope.flags.benchmarkSurvey = true;
            rootScope.$broadcast(events.HgAppBenchmarkSurveyComplete);
            expect(scope.flags.benchmarkSurvey).toBe(false);
        });
        it('Test 4 should set scope.flags.benchmarkSurvey to true on HgAppSurveyCreated event', function () {
            rootScope.$broadcast(events.HgAppSurveyCreated);
            expect(scope.flags.benchmarkSurvey).toBe(true);
        });
        it('Test 5 should destroy listeners on $destroy', function () {
            spyOn(scope, 'surveyStartListener').andCallThrough();
            spyOn(scope, 'surveyCompleteListener').andCallThrough();
            scope.$broadcast('$destroy');
            expect(scope.surveyStartListener).toHaveBeenCalled();
            expect(scope.surveyCompleteListener).toHaveBeenCalled();
        });
    });
});