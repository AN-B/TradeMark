define([
	'unitTests/ui-mocks/recognition.templates.json',
	'unitTests/ui-mocks/group.admin.json',
    'unitTests/ui-mocks/user.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(recogTemplate, admin, user){

	describe('Recognitions Value Levels controller spec -> ', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			location,
			routeParams,
			recSrvc,
			groupSrvc;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionSrvc, GroupAdminSrvc) {
			recSrvc = RecognitionSrvc;
			groupSrvc = GroupAdminSrvc;
			location = $injector.get("$location");
			timeout = $injector.get("$timeout");
			routeParams = $injector.get("$routeParams");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenGET('/svc/GroupAdmin/GetValueLevelSetting')
				.respond(200, admin.GetValueLevelSetting());
			httpBackend.whenPOST('/svc/GroupAdmin/SaveValueLevelSetting')
				.respond(200, admin.GetValueLevelSetting());
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, user.getCu());

			scope = $rootScope.$new();
			ctrl = $controller('ValueRecLevelsCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 Recognitions Value Levels controller should exist', function (){
			expect(ctrl).toBeDefined();
			expect(scope.Periods.length).toBe(6);
		});
		it('Test 2 save levels to call saveValueLevelSettings', function (){
			scope.init();
			httpBackend.flush();
			spyOn(groupSrvc, 'saveValueLevelSettings').andCallThrough();
			spyOn(recSrvc, 'clearRecognitionTemplateCache').andCallThrough();
			scope.saveLevels();
			httpBackend.flush();
			expect(recSrvc.clearRecognitionTemplateCache).toHaveBeenCalledWith('Values');
			expect(groupSrvc.saveValueLevelSettings).toHaveBeenCalled();
			expect(scope.selectedIndex).toBe(-1);
		});
		it('Test 3 toggleLevels to call saveValueLevelSettings', function (){
			scope.init();
			httpBackend.flush();
			spyOn(groupSrvc, 'saveValueLevelSettings').andCallThrough();
			spyOn(recSrvc, 'clearRecognitionTemplateCache').andCallThrough();
			scope.saveLevels();
			httpBackend.flush();
			expect(recSrvc.clearRecognitionTemplateCache).toHaveBeenCalledWith('Values');
			expect(groupSrvc.saveValueLevelSettings).toHaveBeenCalled();
		});
		it('Test 4 cancelLevels should set index to -1 and call init', function (){
			spyOn(scope, 'init').andCallThrough();
			scope.cancelLevels();
			httpBackend.flush();
			expect(scope.init).toHaveBeenCalled();
			expect(scope.selectedIndex).toBe(-1);
		});
		it('Test 5 setIndex should set selectedIndex', function (){
			scope.setIndex(1);
			expect(scope.selectedIndex).toBe(1);
		});
		it('Test 6 getBadgeImagePath should return original badge path if file name', function (){
			var level = {
					Filename: 'test.svg'
				},
				test = scope.getBadgeImagePath(level);
			expect(test.indexOf('/original/')).toBe(8);
		});
		it('Test 7 getBadgeImagePath should return original badge path if file name', function (){
			var level = {
					Filename: 'test.svg'
				},
				test = scope.getBadgeImagePath(level);
			expect(test.indexOf('/original/')).toBe(8);
		});
		it('Test 8 getBadgeImagePath should return group badge path if there is image id', function (){
			scope.init();
			httpBackend.flush();
			var level = {
					ImageId: 'blah'
				},
				test = scope.getBadgeImagePath(level);

			expect(test.indexOf('/group/')).toBe(8);
		});
		it('Test 9 getBadgeImagePath should return empty string if there is image id or file name', function (){
			var level = {
				},
				test = scope.getBadgeImagePath(level);

			expect(test).toBeFalsy();

		});
	});
});