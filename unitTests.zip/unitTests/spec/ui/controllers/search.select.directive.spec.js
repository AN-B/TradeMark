define([
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(){

	describe('Search directive controller spec ->', function() {
		var scope,
			ctrl,
			timeout,
			filter,
			meta,
			rootScope;

		beforeEach(function(){
			meta = [
				{
					Id: 1,
					Name: 'George',
					AvatarId: '',
					Type: 'Member'
				},
				{
					Id: 2,
					Name: 'Larry',
					AvatarId: '',
					Type: 'Member'
				}
			];
		});
		beforeEach(module("hgapp-app"));
		beforeEach(module("main-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope) {
			timeout = $injector.get("$timeout");
			filter = $injector.get("$filter");
			rootScope = $rootScope;
			scope = rootScope.$new();
			scope.meta = meta;
			ctrl = $controller('SearchDirectiveCtrl', {$scope: scope});
		}));
		it('Test 2 when calling selectItem(1) searchMeta item 1 should be selected', function() {
			spyOn(rootScope, "$broadcast");
			scope.selectItem(1);
			expect(scope.meta[0].Selected).toBeTruthy();
			expect(scope.searchFilter).toBeFalsy();
			expect(scope.selected.length).toBe(1);
			expect(rootScope.$broadcast).toHaveBeenCalled();
		});
		it('Test 3 when calling deselectItem(1) searchMeta item 1 should be deselected', function() {
			scope.selectItem(1);
			expect(scope.meta[0].Selected).toBeTruthy();
			spyOn(rootScope, "$broadcast");
			scope.deselectItem(1);
			expect(scope.meta[0].Selected).toBeFalsy();
			expect(scope.searchFilter).toBeFalsy();
			expect(scope.searchItems.length).toBe(0);
			expect(rootScope.$broadcast).toHaveBeenCalled();
		});
		it('Test 4 when calling selectAll searchMeta all items should be selected', function() {
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			expect(scope.meta[0].Selected).toBeFalsy();
			expect(scope.meta[1].Selected).toBeFalsy();
			scope.searchFilter = 'Member';
			scope.selectAll();
			expect(scope.meta[0].Selected).toBeTruthy();
			expect(scope.meta[1].Selected).toBeTruthy();
			expect(scope.searchFilter).toBeFalsy();

		});
		it('Test 5 when calling selectAll and filter is under 1 characters searchMeta all items should be deselected', function() {
			expect(scope.meta[0].Selected).toBeFalsy();
			expect(scope.meta[1].Selected).toBeFalsy();
			scope.searchFilter = '';
			scope.selectAll();
			expect(scope.meta[0].Selected).toBeFalsy();
			expect(scope.meta[1].Selected).toBeFalsy();
			expect(scope.searchFilter).toBeFalsy();
		});
		it('Test 6 hideSearch should be true after calling setHideSearch', function() {
			expect(scope.hideSearch).toBeFalsy();
			scope.setHideSearch('blah');
			timeout.flush();
			expect(scope.hideSearch).toBeTruthy();
		});
		it('Test 7 hideSearch should be false after calling setHideSearch and not passing anything', function() {
			expect(scope.hideSearch).toBeFalsy();
			scope.setHideSearch();
			expect(scope.hideSearch).toBeFalsy();
		});
		it('Test 8 clearAll should clear all the items from selected', function() {
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			scope.searchFilter = 'Member';
			spyOn(rootScope, "$broadcast");
			scope.selectAll();
			expect(scope.meta[0].Selected).toBeTruthy();
			expect(scope.meta[1].Selected).toBeTruthy();
			expect(scope.searchFilter).toBeFalsy();
			expect(rootScope.$broadcast).toHaveBeenCalled();
			scope.clearAll();
			expect(scope.meta[0].Selected).toBeFalsy();
			expect(scope.meta[1].Selected).toBeFalsy();
			expect(scope.searchFilter).toBeFalsy();
			expect(rootScope.$broadcast).toHaveBeenCalled();
		});
		xit('Test 9 when changing searchFilter selected items should hydrate searchItems based on filter', function() {
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			expect(scope.searchItems.length).toBe(0);
			expect(scope.limit).toBe(2);
			scope.searchFilter = "Member";
			scope.$digest();
			expect(scope.searchItems.length).toBe(2);
		});
		it('Test 10 when changing searchFilter selected items should hydrate meta based on filter', function() {
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			expect(scope.meta[0].Selected).toBeFalsy();
			expect(scope.limit).toBe(2);
			scope.searchFilter = "M";
			scope.$digest();
			expect(scope.meta[0].Selected).toBeFalsy();
		});
		xit('Test 11 select next should select next element in the array', function() {
			var event = {target: {localName: 'input'}};
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			scope.searchFilter = "Member";
			scope.$digest();
			expect(scope.meta[0].hover).toBeTruthy();
			scope.selectNext(event);
			timeout.flush();
			expect(scope.meta[1].hover).toBeTruthy();
		});
		xit('Test 12 select next will not select the next element in the array if returned filtered array length is 1', function() {
			var event = {target: {localName: 'input'}};
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			scope.searchFilter = "George";
			scope.$digest();
			expect(scope.meta[0].hover).toBeTruthy();
			scope.selectNext(event);
			timeout.flush();
			expect(scope.meta[0].hover).toBeTruthy();
		});
		xit('Test 13 selectPrev should select previous item in the array', function() {
			var event = {target: {localName: 'input'}};
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			scope.searchFilter = "Member";
			scope.$digest();
			expect(scope.meta[0].hover).toBeTruthy();
			scope.selectNext(event);
			timeout.flush();
			expect(scope.meta[1].hover).toBeTruthy();
			scope.selectPrev(event);
			timeout.flush();
			expect(scope.meta[0].hover).toBeTruthy();
		});
		xit('Test 14 select previous should not select previous item in meta array if filtered array length is 1', function() {
			var event = {target: {localName: 'input'}};
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			scope.searchFilter = "George";
			scope.$digest();
			expect(scope.meta[0].hover).toBeTruthy();
			scope.selectPrev(event);
			timeout.flush();
			expect(scope.meta[0].hover).toBeTruthy();
		});
		it('Test 15 select next should not select next item in the array if its a last item in the meta array', function() {
			var event = {target: {localName: 'input'}};
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			scope.searchFilter = "Member";
			scope.$digest();
			scope.meta[1].hover = true;
			expect(scope.meta[1].hover).toBeTruthy();
			scope.selectNext(event);
			timeout.flush();
			expect(scope.meta[1].hover).toBeTruthy();
		});
		xit('Test 16 select previous should not select previous item if its a first item in the array', function() {
			var event = {target: {localName: 'input'}};
			scope.initSearch({select: meta, eventName: 'something', mode: 'multi'});
			scope.searchFilter = "Member";
			scope.$digest();
			scope.meta[1].hover = true;
			expect(scope.meta[0].hover).toBeTruthy();
			scope.selectPrev(event);
			timeout.flush();
			expect(scope.meta[0].hover).toBeTruthy();
		});
	});
});