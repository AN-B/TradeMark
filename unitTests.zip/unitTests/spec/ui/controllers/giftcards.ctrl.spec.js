define([
	'unitTests/ui-mocks/giftcards.json',
    'unitTests/ui-mocks/user.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(giftcardsJson, userJson, events){

	describe('Giftcards controller spec', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope) {
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			scope = $rootScope.$new();
			ctrl = $controller('MotivateGiftCardsCtrl', {$scope: scope, country: 'USA'});
			httpBackend.whenGET("/svc/Redeem/GetAvailableCodeGiftcardsGroupByIssuer?Country=USA")
                .respond(200, giftcardsJson.getAvailableCodeGiftcardsByIssuer());
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1: Giftcards controller should exist', function (){
			httpBackend.flush();
			expect(ctrl).toBeDefined();
		});
	});
});