define([
	'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/teams.json',
    'unitTests/ui-mocks/productItem.templates.json',
	'unitTests/ui-mocks/recognition.templates.json',
	'unitTests/ui-mocks/recognition.request.object.json',
	'unitTests/ui-mocks/badge.json',
	'unitTests/ui-mocks/user.json',
	'unitTests/ui-mocks/dto.service.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(groupJson, teamsJson, productItems, templatesJson, recJson, badgeJson, userJson, dtoJson){

	describe('Give Achievement recognition controller spec -> ', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			service,
            prodSrvc,
			routeParams,
			count = 0,
			testCount = function () {
				count += 1;
				return 'Test ' + count + ': ';
			};

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, ProductItemSrvc, RecognitionSrvc, UserSrvc, $routeParams) {
			routeParams = $routeParams;
            prodSrvc = ProductItemSrvc;
			service = RecognitionSrvc;
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
            UserSrvc.clearUserCache();

			httpBackend.whenGET('/svc/Recognition/GetUserAchievementTemplates')
				.respond(200, templatesJson.getAchievement());
			httpBackend.whenGET('/svc/Group/GetCurrentGroupMembers?status=Active&es=true')
				.respond(200, groupJson.getCurrentGroupMembers());
			httpBackend.whenGET('/svc/UI/GetRecipientCandidates')
				.respond(200, dtoJson.getRecipients());
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/ProductItem/GetProductById?Id=5f4dd850-c403-11e3-a9c0-71c4281b4207')
                .respond(200, productItems.getNew());

			httpBackend.whenPOST('/svc/Recognition/GiveEverydayRecognition')
				.respond(200, 'Everyday');
			httpBackend.whenPOST('/svc/Recognition/GiveValueRecognition')
				.respond(200, 'Value');
			httpBackend.whenPOST('/svc/Recognition/GiveCustomizedRecognition')
				.respond(200, 'Custom');
			httpBackend.whenPOST('/svc/Recognition/GiveAchievementRecognition')
				.respond(200, 'Achievement');
			scope = $rootScope.$new();
			ctrl = $controller('GiveAchievementCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1: Recognition  controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
		it('Test 2: global variable should be initialized', function (){
			expect(scope.hideRecognitions).toBeFalsy();
		});
		it('Test 3: should call initRec()', function (){
			scope.getTemplates();
			scope.initRec();
			httpBackend.flush();
			expect(scope.templates.length).toBe(3);
			expect(scope.search.userMeta.type).toBe('MemberAndDepartmentandLocation');
			expect(scope.search.userMeta.selected.length).toBe(0);
		});
        it('Test 4: should call service method giveAchievementRec if request is valid and gift stock is >= recipients.length', function (){
            scope.initRec(recJson.getAchievement());
            scope.giftSelected = true;
            scope.request.Recipients.length = 1;
            scope.giftStock = 100;
            httpBackend.flush();
            spyOn(service, 'giveAchievementRec').andCallThrough();
            spyOn(scope, 'clear').andCallThrough();
            scope.giveRecognition();
            httpBackend.flush();
            expect(service.giveAchievementRec).toHaveBeenCalled();
            expect(scope.clear).toHaveBeenCalled();
        });
        it('Test 5: should not call service method giveAchievementRec if gift stock is < recipients.length', function (){
			scope.request = recJson.getAchievement();
            scope.initRec();
            scope.request.MoreOptions.gift = {
                AvailableNumber : 0
            };
            scope.request.MoreOptions.giftId = '5f4dd850-c403-11e3-a9c0-71c4281b4207';
            scope.request.Recipients.length = 100;
            spyOn(service, 'giveAchievementRec').andCallThrough();
            spyOn(scope, 'clear').andCallThrough();
            scope.giveRecognition();
            httpBackend.flush();
            expect(service.giveAchievementRec).not.toHaveBeenCalled();
            expect(scope.clear).not.toHaveBeenCalled();
        });
		it('Test 6: should not call service method giveAchievementRec if request is invalid', function (){
			scope.request = recJson.getAchievement();
            scope.giftSelected = false;
			scope.getTemplates();
			scope.initRec();
			httpBackend.flush();
			scope.toggleRec('d9fe5250-3da8-11e3-8e3f-3b48bfc048fd');
			scope.request.Level = '';
			spyOn(service, 'giveAchievementRec').andCallThrough();
			spyOn(scope, 'clear').andCallThrough();
			scope.giveRecognition();
			expect(service.giveAchievementRec).not.toHaveBeenCalled();
			expect(scope.clear).not.toHaveBeenCalled();
		});
		//toggleRec
		it('Test 7: should toggle recognition when toggleRec is called', function (){
			scope.getTemplates();
			scope.initRec(recJson.getAchievement());
			httpBackend.flush();
			scope.toggleRec('d9fe5250-3da8-11e3-8e3f-3b48bfc048fd');
			expect(scope.request.Template.hgId).toBe('d9fe5250-3da8-11e3-8e3f-3b48bfc048fd');
			expect(scope.request.Level).toBe('');
			expect(scope.templates[0].Selected).toBeTruthy();
			expect(scope.templates[1].Selected).toBeFalsy();
		});
		it('Test 9: should resolve recipient if member id is passed', function (){
			routeParams.memberId = 'c15985d0-aea6-11e2-b79d-512ef31a350a';
			scope.initRec();
			httpBackend.flush();
			expect(scope.enableSearch).toBeTruthy();
			expect(scope.search.userMeta.preSelected.length).toBe(1);
		});
		it('Test 10: clear() should call cache.clear and broadcast to hide recognitions ', function (){
			spyOn(rootScope, '$broadcast').andCallThrough();
			scope.clear();
			expect(rootScope.$broadcast).toHaveBeenCalledWith('hideRecognitions');
		});
	});
});