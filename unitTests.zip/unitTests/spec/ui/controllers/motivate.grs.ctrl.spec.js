define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function () {
    describe('MotivateGRSCtrl spec -> ', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            window,
            q,
            service;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, $window, GRSSrvc) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            window = $window;
            service = GRSSrvc;
            q = $injector.get("$q");
            ctrl = $controller('MotivateGRSCtrl', {
                $scope: scope,
                $window: window
            });

            httpBackend = $injector.get('$httpBackend');

        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2: generateToken() should call backend', function () {
            spyOn(window, 'open').andCallFake(function () {
                return { location: function () {} };
            });
            scope.generateToken();
            httpBackend.whenGET('/svc/GRS/GetStorefrontSSOUrl')
                .respond(200, {"url": "http://foo.bar"});
            httpBackend.flush();
            expect(window.open).toHaveBeenCalled();
            expect(scope.model.storefrontError).toBeUndefined();
        });

        it('Test 3: generateToken() should display error', function () {
            spyOn(window, 'open').andCallFake(function () {
                return { close: function () {} };
            });
            spyOn(service, 'getStorefrontSSOUrl').andCallFake(function(param){
                var deferred = q.defer();
                deferred.reject({data: 'motivate.grs.ess'});
                return deferred.promise;
            });
            scope.generateToken();
            expect(window.open).toHaveBeenCalled();
        });
    });
});