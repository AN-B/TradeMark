define([
	'unitTests/ui-mocks/user.json',
	'unitTests/ui-mocks/user.transactions.json',
	'unitTests/ui-mocks/group.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(userJson, tranJson, groupJson){

	describe('Credits transactions controller spec ->', function() {
		var scope,
			ctrl,
			timeout,
			httpBackend,
			rootScope;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope) {
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
			httpBackend.whenGET('/svc/Group/GetCurrentGroup')
				.respond(200, groupJson.getCurrentGroup());
			httpBackend.whenGET('/svc/GroupAdmin/SaveCreditSetting')
				.respond(200, 'abc');
			httpBackend.whenPOST('/svc/Transaction/GetTransactionsForUser')
				.respond(200, tranJson.get());
			httpBackend.whenPOST('/svc/Transaction/GetTransactionsForGroup')
				.respond(200, tranJson.get());
			httpBackend.whenPOST('/svc/Transaction/GetTransactionsAll')
				.respond(200, tranJson.get());

			scope = $rootScope.$new();
			ctrl = $controller('AdminCreditsTransactionsCtrl', {
				$scope: scope,
				transMode: 'admin',
				unit: 'Credit',
				pAdminService: function () { return null; },
				ptabs: function () { return null; }
			});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
		});
		it('Test 1 Credits transactions controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
		it('Test 2 getCreditsAbs', function (){
			var val = scope.getCreditsAbs(-1);
			expect(val).toBe('(1)');
		});
		it('Test 3 getTypeLabel', function (){
			var creditObject = {
				CreditQuantity : 1,
				Type: 'Transfer'
			}, initialValue = creditObject.Type;
			creditObject.Type = scope.getTypeLabel(creditObject);
			expect(creditObject.Type).toBe(initialValue + ' ' + '(credit)')
		});
		it('Test 4 getReferenceNumbers', function (){
			var params = {
				ReferenceNumbers : [{TypeName: 'testType', Value: 'testValue'}],
				Type: 'Credit'
			},
			reference = [];
			reference = scope.getReferenceNumbers(params);
			expect(reference.length > 0).toBeTruthy();
		});
		xit('Test 5 exportExcel', function (){
			scope.pageEnv = {
				StartDate : 123,
				EndDate: 456,
				SearchTerm: 'Cu',
				unit: 'Credit'
			};
			var params = [],
				url = '/svc/Transaction/ExportTransactionsFor';
			scope.exportExcel();
		});
	});
});
