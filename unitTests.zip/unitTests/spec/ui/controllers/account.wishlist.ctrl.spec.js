define([
    'unitTests/ui-mocks/user.json',
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (userJson, cache) {

    describe('Account wishlist controller spec', function() {
        var scope,
            ctrl,
            userSvc,
            httpBackend,
            location;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $rootScope, $controller, UserSrvc) {
            userSvc = UserSrvc;
            location = $injector.get("$location");
            scope = $rootScope.$new();
            ctrl = $controller('UserAccountWishListCtrl', {$scope: scope});
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('ctrl should be defined', function () {
            expect(ctrl).toBeDefined();
        });
        it('init should call UserSrvc and redirect if user does not have wishlist permission', function () {
            spyOn(userSvc, 'getUser').andCallThrough();
            spyOn(location, 'path').andCallFake(function(){});
            scope.init();
            httpBackend.flush();
            expect(userSvc.getUser).toHaveBeenCalled();
            expect(scope.ownerId).toBeDefined();
            expect(scope.wishList).toBeFalsy();
            expect(location.path).toHaveBeenCalledWith('/User/Account');
        });
    });
});