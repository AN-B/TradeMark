define([
    'unitTests/ui-mocks/teams.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(teamJson){

    describe('teams edit controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            location,
            backend,
            routeParams,
            teamSrvc,
            modalMock = {
                result: {
                    then: function (request) {
                        request = request;
                    }
                }
            },
            modal;


        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            rootScope = $rootScope;
            teamSrvc = $injector.get('TeamSrvc');
            location = $injector.get('$location');
            backend = $injector.get("$httpBackend");
            routeParams = $injector.get("$routeParams");
            modal = $injector.get('$modal');
            scope = $rootScope.$new();
            backend.whenGET('/svc/Team/GetTeamById?tId=9fa84960-302b-11e3-91d2-dd5c4c401983')
                .respond(200, teamJson.getTeamById());

            backend.whenPOST('/svc/Team/SaveTeam').respond(200, {});
            ctrl = $controller('UserTeamsEditCtrl', {
                $scope: scope,
                $location: location,
                mode: {create: true}
            });
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
        });
        it('Test 1: controller should be defined', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: init should call backend getTeamById', function (){
            routeParams.teamId = '9fa84960-302b-11e3-91d2-dd5c4c401983';
            spyOn(teamSrvc, 'getTeamById').andCallThrough();
            scope.init();
            backend.flush();
            expect(teamSrvc.getTeamById).toHaveBeenCalledWith(routeParams.teamId);
            expect(scope.model.caption).toBe('Create Team');
            expect(scope.team.hgId).toBe(routeParams.teamId);
        });
        it('Test 3: init should call backend getTeamById hgId should not be defined if mode is duplicate', function (){
            routeParams.teamId = '9fa84960-302b-11e3-91d2-dd5c4c401983';
            scope.model.mode.duplicate = true;
            spyOn(teamSrvc, 'getTeamById').andCallThrough();
            scope.init();
            backend.flush();
            expect(teamSrvc.getTeamById).toHaveBeenCalledWith(routeParams.teamId);
            expect(scope.model.caption).toBe('Create Team');
            expect(scope.team.hgId).not.toBeDefined();
        });
        it('Test 4: init should not call backend getTeamById if mode is create', function (){
            scope.model.mode.create = true;
            spyOn(teamSrvc, 'getTeamById').andCallThrough();
            scope.init();
            expect(teamSrvc.getTeamById).not.toHaveBeenCalled();
            expect(scope.team.hgId).not.toBeDefined();
        });
        it('Test 5: validateName should return invalid if team.Name is undefined', function (){
            var team = scope.validateName({});
            expect(team.invalid).toBeTruthy();
            expect(team.invalidName).toBeTruthy();
            expect(scope.model.caption).toBe('Not Yet');
        });

        it('Test 6: validateName should return valid if team.Name is defined', function (){
            var team = scope.validateName({Name: 'test'});
            expect(team.invalid).toBeFalsy();
            expect(team.invalidName).toBeFalsy();
            expect(scope.model.caption).toBe('Create Team');
        });
        it('Test 7: should submit valid request', function (){
            spyOn(teamSrvc, 'saveTeam').andCallThrough();
            scope.submit(teamJson.getTeamById());
            backend.flush();
            expect(teamSrvc.saveTeam).toHaveBeenCalled();
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 8: should not submit invalid request', function (){
            spyOn(teamSrvc, 'saveTeam').andCallThrough();
            scope.submit({TeamMembers: [], ChildTeams: []});
            expect(teamSrvc.saveTeam).not.toHaveBeenCalled();
            expect(location.path).not.toHaveBeenCalled();
        });
        it('Test 9: openAvatarDialog should open modal dialog', function (){
            var mock = modalMock;
            spyOn(modal, 'open').andReturn(mock);
            scope.openAvatarDialog({hgId: 'test'})
            expect(modal.open).toHaveBeenCalled();
        });
        it('Test 10: it should select and deselect ChildTeams', function (){
            scope.init();
            scope.model.teamSearch.onSelect({Name: 'test', Id: 'test'});
            expect(scope.team.ChildTeams.length).toBe(1);
            scope.model.teamSearch.deSelect({Name: 'test', Id: 'test'});
            expect(scope.team.ChildTeams.length).toBe(0);
        });
        it('Test 11: it should select and deselect TeamMembers', function (){
            scope.init();
            scope.model.memberSearch.onSelect({Name: 'test', Id: 'test'});
            expect(scope.team.TeamMembers.length).toBe(1);
            scope.model.memberSearch.deSelect({Name: 'test', Id: 'test'});
            expect(scope.team.TeamMembers.length).toBe(0);
        });

    });
});