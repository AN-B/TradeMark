define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, validation){

    describe('Preferences controller spec -> ', function() {
        var scope,
            backend,
            ctrl;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            scope = $rootScope.$new();
            backend = $injector.get('$httpBackend');
            backend.whenGET('/svc/Member/GetMyPreference').respond(200, {});
            backend.whenGET('/svc/User/Login').respond(200, {});
            ctrl = $controller('UserPreferencesCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
        });
        it('Test 1: controller should be defined', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: it should set flags to true if OptOutPublicRec is truthy', function (){
            var test = scope.setFlags({OptOutPublicRec: true});
            expect(test.SuppressBirthday).toBeTruthy();
            expect(test.SuppressAnniversary).toBeTruthy();
        });
        it('Test 3: it should not change flags if OptOutPublicRec is falsy', function (){
            var test = scope.setFlags({SuppressBirthday: true, OptOutPublicRec: false});
            expect(test.SuppressAnniversary).toBeFalsy();
        });

    });
});
