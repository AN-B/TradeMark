define([
    'unitTests/ui-mocks/user.json',
    'static/source/hgapp/validation/account.payment.info.validation',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, validation){

    describe('Account payment info controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            location,
            backend,
            userSrvc,
            creditSrvc,
            q;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, CreditSrvc) {
            creditSrvc = CreditSrvc;
            userSrvc = UserSrvc;
            rootScope = $rootScope;
            location = $injector.get('$location');
            q = $injector.get('$q');
            scope = $rootScope.$new();
            backend = $injector.get('$httpBackend');
            backend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            ctrl = $controller('UserAccountPaymentInfoCtrl', {$scope: scope});
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
        });
        it('Test 1: controller should be defined', function (){
            expect(ctrl).toBeDefined();
            expect(scope.validate).toBe(validation.validate);
            expect(scope.validateZip).toBe(validation.validateZip);
            expect(scope.validateCvv).toBe(validation.validateCvv);
        });
        it('Test 2: ', function (){
            spyOn(userSrvc, 'getUser').andCallThrough();
            scope.init();
            backend.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
            expect(scope.mycards.length).toBeTruthy();
            expect(scope.PaymentInfo.Type).toBe(scope.PaymentType.Credit.type);
        });
        it('Test 3: init should call user service', function (){
            spyOn(userSrvc, 'getUser').andCallThrough();
            scope.init();
            backend.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
            expect(scope.mycards.length).toBeTruthy();
            expect(scope.PaymentInfo.Type).toBe(scope.PaymentType.Credit.type);
        });
        it('Test 4: validateCC should call validateCreditcard and getCardTypeName', function (){
            spyOn(validation, 'validateCreditcard').andCallFake(function(){return {};});
            spyOn(validation, 'getCardTypeName').andCallFake(function(){return {};});
            var test = scope.validateCC({});
            expect(validation.validateCreditcard).toHaveBeenCalled();
            expect(validation.getCardTypeName).toHaveBeenCalled();
        });
        it('Test 5: actionDefaultOn should set cards properties', function (){
            var test = scope.actionDefaultOn({});
            expect(test.deleteOn).toBeFalsy();
            expect(test.defaultOn).toBeTruthy();
            expect(test.actionCaption).toBeDefined();
        });
        it('Test 6: actionDeleteOn should set cards properties', function (){
            var test = scope.actionDeleteOn({});
            expect(test.deleteOn).toBeTruthy();
            expect(test.defaultOn).toBeFalsy();
            expect(test.actionCaption).toBeDefined();
        });
        it('Test 7: closeAction should set cards properties', function (){
            var test = scope.closeAction({defaultOn: true, deleteOn: true});
            expect(test.deleteOn).toBeFalsy();
            expect(test.defaultOn).toBeFalsy();
        });
        it('Test 8: updateCard should call CreditSrvc.setDefaultPaymentProfile', function (){
            scope.init();
            backend.flush();
            spyOn(creditSrvc, 'setDefaultPaymentProfile').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve({PaymentProfiles: [], DefaultPaymentProfileId: {}});
                return deferred.promise;
            });
            scope.updateCard({defaultOn: true, HgId: '123'});
            expect(creditSrvc.setDefaultPaymentProfile).toHaveBeenCalled();
        });
        it('Test 9: updateCard should call CreditSrvc.deletePaymentProfile', function (){
            scope.init();
            backend.flush();
            spyOn(creditSrvc, 'deletePaymentProfile').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve({PaymentProfiles: [], DefaultPaymentProfileId: {}});
                return deferred.promise;
            });
            scope.updateCard({deleteOn: true, HgId: '123'});
            expect(creditSrvc.deletePaymentProfile).toHaveBeenCalled();
        });
        it('Test 10: clear should clear payment info', function (){
            scope.PaymentInfo = {test: '213'};
            scope.clear();
            expect(scope.PaymentInfo.test).not.toBeDefined();

        });
        it('Test 11: it should not submit invalid request', function (){
            var test = {};
            spyOn(creditSrvc, 'addPaymentProfile').andCallFake(function(){return {};});
            spyOn(validation, 'validateRequest').andCallThrough();
            scope.submit(test);
            expect(creditSrvc.addPaymentProfile).not.toHaveBeenCalled();
            expect(validation.validateRequest).toHaveBeenCalled();
            expect(test.invalid).toBeTruthy();

        });

        it('Test 12: it should not submit invalid request', function (){
            var test = {};
            scope.init();
            backend.flush();
            spyOn(creditSrvc, 'addPaymentProfile').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve({PaymentProfiles: [], DefaultPaymentProfileId: {}});
                return deferred.promise;
            });
            spyOn(validation, 'validateRequest').andCallFake(function(){
                return {invalid: false};
            });
            scope.submit(test);
            expect(creditSrvc.addPaymentProfile).toHaveBeenCalled();
        });

    });
});
