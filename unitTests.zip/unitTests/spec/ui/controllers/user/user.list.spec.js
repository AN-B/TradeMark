define([
    'unitTests/ui-mocks/modal',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(modal){

    describe('User List controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            rootScope = $rootScope;
            location = $injector.get('$location');
            scope = $rootScope.$new();
            ctrl = $controller('UserList', {
                $scope: scope,
                $location: location,
                $modalInstance: modal,
                params: {}

            });
            spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
        });
        it('Test 1: controller should be defined', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: should call dismiss', function (){
            spyOn(modal, 'dismiss').andCallThrough();
            scope.close();
            expect(modal.dismiss).toHaveBeenCalled();
        });
        it('Test 3: navigateProfile should navigate to profile', function (){
            spyOn(modal, 'dismiss').andCallThrough();
            scope.navigateProfile('test');
            expect(modal.dismiss).toHaveBeenCalled();
            expect(location.path).toHaveBeenCalledWith("Profile/Feed/test");
        });
    });
});