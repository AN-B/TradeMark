define(['unitTests/ui-mocks/survey.questions.json',
        'unitTests/ui-mocks/modal',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function (surveyJson, modalMock) {

        describe('Take Benchmark Survey controller spec', function () {
            var scope,
                ctrl,
                httpBackend,
                surveyService,
                modal,
                toastrSrvc,
                rootScope;

            beforeEach(module('hgapp-app'));
            beforeEach(module('hgapp-controllers'));
            beforeEach(inject(function ($injector, $controller, $rootScope, SurveySrvc, ToastrSrvc) {
                scope = $rootScope.$new();
                rootScope = $rootScope;
                modal = modalMock;
                ctrl = $controller('TakeBenchmarkSurveyCtrl', {
                    $scope: scope,
                    $modalInstance: modal
                });
                surveyService = SurveySrvc;
                httpBackend = $injector.get('$httpBackend');
                toastrSrvc = ToastrSrvc;
            }));
            afterEach(function () {
                scope.$digest();
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('Controller should exist', function () {
                expect(ctrl).toBeDefined();
            });

            it('init() should load survey questions', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());
                spyOn(surveyService, 'getAllMyBenchmarkSurveyQuestions').andCallThrough();

                scope.init();
                httpBackend.flush();

                expect(surveyService.getAllMyBenchmarkSurveyQuestions).toHaveBeenCalled();
                expect(scope.model.questions.length).toEqual(surveyJson.getSurveyQuestions().Questions.length);
                expect(scope.model.showIntro).toBeTruthy();
            });

            it('init() should not show intro if survey already started', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getHalfCompletedSurvey());

                scope.init();
                httpBackend.flush();

                expect(scope.model.showIntro).toBeFalsy();
                expect(scope.model.showOutro).toBeFalsy();
            });

            it('init() should show outro if zero survey questions', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, {});

                scope.init();
                httpBackend.flush();

                expect(scope.model.showOutro).toBeTruthy();
                expect(scope.model.showIntro).toBeFalsy();
            });
            it('init() should set last viewed index', function () {
                var response = surveyJson.getSurveyQuestions();
                    response.LastViewedIndex = 1;
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, response);
                spyOn(surveyService, 'getAllMyBenchmarkSurveyQuestions').andCallThrough();

                scope.init();
                httpBackend.flush();
                expect(scope.model.index).toBe(1);
            });
            it('init() should set immediately show outro', function () {
                var response = surveyJson.getSurveyQuestions();
                    response.LastViewedIndex = response.Questions.length;
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, response);
                spyOn(surveyService, 'getAllMyBenchmarkSurveyQuestions').andCallThrough();

                scope.init();
                httpBackend.flush();
                expect(scope.model.showOutro).toBeTruthy();
            });
            it('startSurvey() should set showIntro to false and call service', function () {
                httpBackend.whenPOST('/svc/Survey/StartBenchmarkSurvey').respond(200, {message: 'done'});
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());
                spyOn(surveyService, 'startBenchmarkSurvey').andCallThrough();

                scope.init();
                httpBackend.flush();
                scope.startSurvey();
                httpBackend.flush();

                expect(scope.model.showIntro).toBeFalsy();
                expect(surveyService.startBenchmarkSurvey).toHaveBeenCalledWith({
                    SurveyId: surveyJson.getSurveyQuestions().Questions[0].SurveyId,
                    RecurrenceId: surveyJson.getSurveyQuestions().Questions[0].RecurrenceId,
                    CurrentRoundId: surveyJson.getSurveyQuestions().Questions[0].CurrentRoundId
                });
            });

            it('isCurrentIndex() should check against model.index', function () {
                scope.model.index = 42;
                expect(scope.isCurrentIndex(42)).toBeTruthy();
                expect(scope.isCurrentIndex(2)).toBeFalsy();
            });

            it('isQuestionAnswered() should check for AnswerValue property', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());

                scope.init();
                httpBackend.flush();

                scope.model.questions[0].AnswerValue = 'foobar';
                expect(scope.isQuestionAnswered(0)).toBeTruthy();
                expect(scope.isQuestionAnswered(1)).toBeFalsy();
            });

            it('nextQuestion() should call service with only index if no answer given', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());
                httpBackend.whenPOST('/svc/Survey/SubmitBenchmarkSurveyQuestion')
                    .respond(200, {});
                spyOn(surveyService, 'submitQuestion').andCallThrough();

                scope.init();
                httpBackend.flush();

                scope.nextQuestion();
                httpBackend.flush();
                expect(surveyService.submitQuestion).toHaveBeenCalledWith({surveyAnswer:null, index: 1});
            });
            it('nextQuestion() should show outro and broadcast survey complete if the survey has been completed', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());
                httpBackend.whenPOST('/svc/Survey/SubmitBenchmarkSurveyQuestion')
                    .respond(200, {SurveyCompleted: true});
                spyOn(rootScope, '$broadcast').andCallThrough();
                scope.init();
                httpBackend.flush();
                scope.model.index = 1;
                scope.nextQuestion();
                httpBackend.flush();
                expect(scope.model.showOutro).toBeTruthy();
                expect(rootScope.$broadcast).toHaveBeenCalledWith("HgAppBenchmarkSurveyComplete");
            });
            it('nextQuestion() should call answer service and increment index', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());
                httpBackend.whenPOST('/svc/Survey/SubmitBenchmarkSurveyQuestion')
                    .respond(200, {Points: 42});
                spyOn(surveyService, 'submitQuestion').andCallThrough();
                spyOn(toastrSrvc, 'success').andCallThrough();

                scope.init();
                httpBackend.flush();

                scope.model.questions[0].AnswerValue = 3;
                scope.nextQuestion();
                httpBackend.flush();

                expect(surveyService.submitQuestion).toHaveBeenCalledWith({surveyAnswer: scope.model.questions[0], index: 1});
                expect(toastrSrvc.success).toHaveBeenCalledWith(['survey.benchmark.rps', {points: 42}]);
                expect(scope.model.index).toBe(1);
            });
            it('prevQuestion() should show outro and broadcast survey complete if survey is complete', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());
                httpBackend.whenPOST('/svc/Survey/SubmitBenchmarkSurveyQuestion')
                    .respond(200, {SurveyCompleted: true});
                spyOn(surveyService, 'submitQuestion').andCallThrough();
                spyOn(rootScope, '$broadcast').andCallThrough();
                scope.init();
                httpBackend.flush();
                scope.model.index = 1;
                scope.model.questions[0].AnswerValue = 3;
                scope.model.questions[1].AnswerValue = 3;
                scope.prevQuestion();
                httpBackend.flush();

                expect(surveyService.submitQuestion).toHaveBeenCalledWith({surveyAnswer: scope.model.questions[1], index: 0});
                expect(scope.model.showOutro).toBeTruthy();
                expect(rootScope.$broadcast).toHaveBeenCalledWith("HgAppBenchmarkSurveyComplete");
            });
            it('prevQuestion() should hide outro if survey is not completed', function () {
                httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions')
                    .respond(200, surveyJson.getSurveyQuestions());
                httpBackend.whenPOST('/svc/Survey/SubmitBenchmarkSurveyQuestion')
                    .respond(200, {});
                scope.init();
                httpBackend.flush();
                scope.model.index = 1;
                scope.model.showOutro = true;
                scope.model.questions[1].AnswerValue = 3;
                scope.prevQuestion();
                httpBackend.flush();

                expect(scope.model.showOutro).toBeFalsy();
            });
            it('should call finishBenchmarkSurvey() and then close the modal', function () {
                spyOn(scope, 'close').andCallThrough();
                httpBackend.whenPOST('/svc/Survey/FinishBenchmarkSurvey')
                    .respond(200, {});
                scope.finishSurvey();
                httpBackend.flush();
                expect(scope.close).toHaveBeenCalled();
            });
            it('close() should close', function () {
                spyOn(modal, 'dismiss').andCallThrough();
                scope.close();
                expect(modal.dismiss).toHaveBeenCalled();
            });
        });
    });