define([
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/metrics.json',
    'unitTests/ui-mocks/member.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(groupJson, userJson, metricsJson, memberJson){

    describe('Profile User controller spec', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            rootScope,
            routeParams,
            userService,
            memberSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, MetricsSrvc, MemberSrvc, $routeParams) {
            routeParams = $routeParams;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            userService = UserSrvc;
            metricsSrvc = MetricsSrvc;
            memberSrvc = MemberSrvc;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET("/svc/Member/GetProfileMemberRecordById?MemberId='ede16340-c87b-11e2-aa05-198054fd4117'")
                .respond(200, memberJson.getProfileMemberRecordById());
            httpBackend.whenGET("/svc/Goal/GetCycleOverviewByMemberId?memberId=ede16340-c87b-11e2-aa05-198054fd4117")
                .respond(200, {});
            httpBackend.whenGET("/svc/Goal/GetCycleOverviewByMemberId?memberId=d2e0d320-a119-11e2-b177-7d64c8315189")
                .respond(200, {});
            httpBackend.whenGET("/svc/Metrics/GetMyMetrics")
                .respond(200, metricsJson.getMyMetrics());
            scope = $rootScope.$new();
            ctrl = $controller('ProfileUserCtrl', {$scope: scope});
            userService.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Profile User controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 1 should call init() with memberId', function (){
            routeParams.memberId = 'ede16340-c87b-11e2-aa05-198054fd4117';
            spyOn(userService, 'getUser').andCallThrough();
            spyOn(memberSrvc, 'getProfileMemberRecordById').andCallThrough();
            spyOn(metricsSrvc, 'getMyMetrics').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
            expect(metricsSrvc.getMyMetrics).toHaveBeenCalled();
            expect(scope.currentMember).toBeDefined();
        });
        it('Test 2 should call init() without memberId', function (){
            spyOn(userService, 'getUser').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
            expect(scope.currentMember).toBeDefined();
        });
        it('Test 3 should mymetrics should be defined', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.mymetrics).toBeDefined();
        });
        it('Test 4 recognitions should increase for RecognitionReceived pusher message', function (){
            spyOn(userService, 'getUser').andCallThrough();
            spyOn(memberSrvc, 'getProfileMemberRecordById').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
            expect(scope.currentMember).toBeDefined();
            rootScope.$broadcast('RecognitionReceived', {MemberId : 'ede16340-c87b-11e2-aa05-198054fd4117'});
            expect(scope.mymetrics).toBeDefined();
            expect(scope.mymetrics.RecognitionReceived).toBe(148);
            scope.$broadcast('$destroy');
        });
        it('Test 5 hould increase for FeedbackCreated pusher message ', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.currentMember).toBeDefined();
            rootScope.$broadcast('FeedbackCreated');
            expect(scope.mymetrics).toBeDefined();
            expect(scope.mymetrics.AdviceReceived).toBe(1);
            scope.$broadcast('$destroy');
        });
        it('Test 6 should listener CoachingNoteReceived', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.currentMember).toBeDefined();
            rootScope.$broadcast('CoachingNoteReceived');
            expect(scope.mymetrics).toBeDefined();
            expect(scope.mymetrics.AdviceReceived).toBe(1);
            scope.$broadcast('$destroy');
        });
        it('Test 7 should listener ReviewCompleted', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.currentMember).toBeDefined();
            rootScope.$broadcast('ReviewCompleted');
            expect(scope.mymetrics).toBeDefined();
            expect(scope.mymetrics.ReviewsCompleted).toBe(0);
            scope.$broadcast('$destroy');
        });
    });
});