define([
    'static/source/core/enums/events',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/teams.json',
    'unitTests/ui-mocks/group.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(events, userJson, teamsJson, groupJson){

    describe('Track "easy" controller spec -> ', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            routeParams,
            recognitionSrvc,
            careerTrackSrvc,
            pojoSrvc,
            badgeAdminSrvc,
            groupSrvc,
            teamSrvc,
            modal,
            confirmCallBack,
            returnModel = {
                result: {
                    then: function (confirmCallBackParam) {
                        confirmCallBack = confirmCallBackParam;
                    }
                }
            };

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, RecognitionSrvc, CareerTrackSrvc, PojoSrvc, BadgeAdminSrvc, GroupSrvc, TeamSrvc, $modal) {
            recognitionSrvc = RecognitionSrvc;
            careerTrackSrvc = CareerTrackSrvc;
            pojoSrvc = PojoSrvc;
            badgeAdminSrvc = BadgeAdminSrvc;
            groupSrvc = GroupSrvc;
            teamSrvc = TeamSrvc;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Team/GetTeamsOwnOrBelong')
                .respond(200, teamsJson.getTeamsForFeeds());
            httpBackend.whenGET('/svc/Group/GetCurrentGroupMembersDTO?es=true&status=Active')
                .respond(200, groupJson.getCurrentMembersDto());

            scope = $rootScope.$new();
            ctrl = $controller('TrackEasyCtrl', {$scope: scope});
            modal = $modal;
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Track "easy" controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: Sets a member manager when the member has no managers', function () {
            httpBackend.whenPOST('/svc/Member/SetMemberManager')
                .respond(200, {
                    MyManagers: [{
                        "FullName" : "Cristinaa simon",
                        "UserId" : "972ff240-ece3-11e3-bfec-05f22a659a87",
                        "MemberId" : "972ff242-ece3-11e3-bfec-05f22a659a87"
                    }]
                });
            scope.manager = null;
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openManagerDialog();
            expect(modal.open).toHaveBeenCalled();
            confirmCallBack(['2331f5a0-9cd5-11e2-a3a4-25024474fe63']);
            httpBackend.flush();
            expect(scope.manager).toBeDefined();
        });
    });
});