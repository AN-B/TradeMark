define([
    'static/source/core/enums/events',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(events, userJson){

    describe('Track controller spec -> ', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            careerTrackSrvc,
            pojoSrvc,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, CareerTrackSrvc, PojoSrvc) {
            careerTrackSrvc = CareerTrackSrvc;
            pojoSrvc = PojoSrvc;
            timeout = $injector.get("$timeout");
            location = $injector.get("$location");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('templates/Public/Main/error/missing.html')
                        .respond(200, '<div></div>');
            scope = $rootScope.$new();
            ctrl = $controller('TrackCtrl', {$scope: scope});
           // spyOn(location, 'path').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
                            
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();

        });
        // it('Test 1: Track controller should exist', function (){
        //     expect(ctrl).toBeDefined();

        // });

  //       it('Test 2 finishMilestone should call UpdateMileStone, function (){
		// 	scope.init();
		// 	httpBackend.flush();
		// 	scope.selectedIndex = 0;
		// 	spyOn(service, 'UpdateMileStone').andCallThrough();
		// 	scope.save();
		// 	httpBackend.flush();
		// 	expect(service.UpdateMileStone).toHaveBeenCalled();
		// });
		
		// it('Test 3 declineMileStone should not call UpdateMileStone if declineReason is not filled', function (){
		// 	scope.init();
		// 	httpBackend.flush();
		// 	spyOn(service, 'saveTemplate').andCallThrough();
		// 	spyOn(scope, 'clear').andCallThrough();
		// 	scope.save();
		// 	expect(service.saveTemplate).not.toHaveBeenCalled();
		// 	expect(scope.clear).not.toHaveBeenCalled();
		// });
		
		// it('Test 4 declineMileStone should not call UpdateMileStone if declineReason is not filled', function (){
		// });
        // it('Test 5 UpdateNumericValue should call UpdateMileStone when the value is equal to or greater than 0', function (){
        // });
        // it('Test 6 ShiftNumericValue should call UpdateNumericValue when the value is equal to or greater than 0', function (){
        // });
        // it('Test 7 previewTrackEditable should return true if all the criterias are met', function (){
        // });
    });
});