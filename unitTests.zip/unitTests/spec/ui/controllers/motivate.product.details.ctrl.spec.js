define([
    'unitTests/ui-mocks/productItem.templates.json',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/wish.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(productItemsJson, userJson, wishJson){

    describe('Motivate Product Detail Controller spec -> ', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            modalSeviceMock,
            modalResult,
            service,
            wishListSrvc,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProductItemSrvc, WishListSrvc) {
            modalResult = {
                then: function(callback) {
                    callback("success");
                }
            };

            modalSeviceMock = {
                open: function(options) {

                }
            };

            location = $injector.get("$location");
            service = ProductItemSrvc;
            wishListSrvc = WishListSrvc;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            ctrl = $controller('MotivateProductDetailsCtrl', {$scope: scope, $modal: modalSeviceMock});

            httpBackend.whenGET('/svc/ProductItem/GetProductById?Id=21f61c10-c403-11e3-a9c0-71c4281b4208')
                .respond(200, productItemsJson.getAllCampaignItems()[0]);
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenPOST('/svc/ProductItem/BackTheCampaign')
                .respond(200, {Item: productItemsJson.getAllCampaignItems()[0]});
            httpBackend.whenGET('/svc/WishList/GetWishByItemId?ItemId='+ productItemsJson.getAllCampaignItems()[0].hgId)
                .respond(200, wishJson.getSingleWish());

            spyOn(location, 'path').andCallFake(function(){});

        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });


        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2: init() should call backend', function () {
            scope.productId = productItemsJson.getAllCampaignItems()[0].hgId;
            scope.init();
            httpBackend.flush();
            expect(scope.product.CampaignItem.FundingGoal).toBe(100);
            expect(scope.product.backer.Length).toBe(1);
            expect(scope.product.ProductType).toBe('Campaign');
        });

        it('Test 3: purchase() should call backTheCampaign if ProductType is "campaign"', function () {
            scope.productId = productItemsJson.getAllCampaignItems()[0].hgId;
            scope.product = productItemsJson.getAllCampaignItems()[0];
            scope.product.PledgePoint = 10;
            scope.product.hgId = "21f61c10-c403-11e3-a9c0-71c4281b4208";
            scope.user = userJson.getCu();
            spyOn(modalSeviceMock, "open").andReturn({ result: modalResult });
            spyOn(service,'backTheCampaign').andCallThrough();
            spyOn(service,'clearCache').andCallThrough();
            scope.purchase();
            httpBackend.flush();
            expect(modalSeviceMock.open).toHaveBeenCalled();
            expect(service.backTheCampaign).toHaveBeenCalled();
            expect(service.clearCache).toHaveBeenCalled();
            expect(location.path).toHaveBeenCalledWith('/Motivate/Rewards');
        });
    });
});
