define([
	'unitTests/ui-mocks/group.json',
	'unitTests/ui-mocks/teams.json',
	'unitTests/ui-mocks/recognition.templates.json',
	'unitTests/ui-mocks/recognition.request.object.json',
	'unitTests/ui-mocks/badge.json',
	'unitTests/ui-mocks/user.json',
	'unitTests/ui-mocks/dto.service.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(groupJson, teamsJson, templatesJson, recJson, badgeJson, userJson, dtoJson){

	describe('Give custom recognition controller spec -> ', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			service,
			routeParams,
            groupService,
			count = 0,
			testCount = function () {
				count += 1;
				return 'Test ' + count + ': ';
			};

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionSrvc, $routeParams, GroupSrvc, UserSrvc) {
			routeParams = $routeParams;
			service = RecognitionSrvc;
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
            groupService = GroupSrvc;
			httpBackend = $injector.get("$httpBackend");
            UserSrvc.clearUserCache();

			httpBackend.whenGET('/svc/Badge/GetBadgesForCustomizedRecognition')
				.respond(200, badgeJson.getBadges());
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
			httpBackend.whenGET('/svc/UI/GetRecipientCandidates')
				.respond(200, dtoJson.getRecipients());
            httpBackend.whenGET('/svc/Group/GetCurrentGroup')
                .respond(200, groupJson.getCurrentGroup());
			httpBackend.whenPOST('/svc/Recognition/GiveEverydayRecognition')
				.respond(200, 'Everyday');
			httpBackend.whenPOST('/svc/Recognition/GiveValueRecognition')
				.respond(200, 'Value');
			httpBackend.whenPOST('/svc/Recognition/GiveCustomizedRecognition')
				.respond(200, 'Custom');
			httpBackend.whenPOST('/svc/Recognition/GiveAchievementRecognition')
				.respond(200, 'Achievement');
			scope = $rootScope.$new();
			ctrl = $controller('GiveCustomCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1: Recognition child controller should exist', function (){
			expect(scope.interval).toBe(8);
			expect(ctrl).toBeDefined();
		});
		it('Test 2: global variable should be initialized', function (){
			expect(scope.hideRecognitions).toBeFalsy();
		});
		it('Test 3: should call initRec()', function (){
            spyOn(groupService, 'getCurrentGroup').andCallThrough();
			scope.initRec();
			httpBackend.flush();
            expect(groupService.getCurrentGroup).toHaveBeenCalled();
            expect(scope.search.userMeta.type).toBe('MemberAndDepartmentandLocation');
			expect(scope.search.userMeta.selected.length).toBe(0);
			expect(scope.isAchievement).toBeTruthy();
		});
		it('Test 4: if there is a cached object it should resolve objects from the cache', function (){
			scope.initRec(recJson.getCustom());
			httpBackend.flush();
			expect(scope.search.userMeta.preSelected.length).toBe(1);
		});
		it('Test 5: iniRec will modify meta if custom selection returned from cache', function(){
			scope.initRec(recJson.getCustom());
			httpBackend.flush();
			expect(scope.categories.length).toBe(3);
			expect(scope.categories[0].Selected).toBeTruthy();
			expect(scope.badges.length).toBe(1);
			expect(scope.badges[0].Selected).toBeTruthy();
		});
		it('Test 6: should not call service method giveCustomizedRec if request is invalid', function (){
			scope.request = recJson.getCustom();
			scope.request.Template.ImageId = '';
			spyOn(service, 'giveCustomizedRec').andCallThrough();
			spyOn(scope, 'clear').andCallThrough();
			scope.giveRecognition();
			expect(service.giveCustomizedRec).not.toHaveBeenCalled();
			expect(scope.clear).not.toHaveBeenCalled();
		});
		it('Test 7: should not call service method giveValueRec if request is invalid', function (){
			scope.request = recJson.getValue();
			scope.request.Template.hgId = '';
			spyOn(service, 'giveValueRec').andCallThrough();
			spyOn(scope, 'clear').andCallThrough();
			scope.giveRecognition();
			expect(service.giveValueRec).not.toHaveBeenCalled();
			expect(scope.clear).not.toHaveBeenCalled();
		});
		it('Test 8: setSelectedCategory should toggle selected category', function(){
			scope.initRec(recJson.getCustom());
			httpBackend.flush();
			expect(scope.categories.length).toBe(3);
			expect(scope.categories[0].Selected).toBeTruthy();
			scope.request.Template.hgId = 'blah';
			scope.request.Level = 'blah';
			scope.request.Template.Category = 'blah';
			scope.setSelectedCategory('Achivement');
			expect(scope.categories[0].Selected).toBeFalsy();
			expect(scope.categories[2].Selected).toBeTruthy();
			expect(scope.request.Template.Category).toBe('Custom');
			expect(scope.request.Template.hgId).toBeFalsy();
			expect(scope.request.Level).toBeFalsy();
		});
		it('Test 10: incrementCategory() should increment categoryStart and categoryEnd', function (){
			expect(scope.categoryStart).toBe(0);
			expect(scope.categoryEnd).toBe(8);
			scope.incrementCategory();
			expect(scope.categoryStart).toBe(8);
			expect(scope.categoryEnd).toBe(16);
		});
		it('Test 11: decrementCategory() should decrement categoryStart and categoryEnd', function (){
			scope.incrementCategory();
			expect(scope.categoryStart).toBe(8);
			expect(scope.categoryEnd).toBe(16);
			scope.decrementCategory();
			expect(scope.categoryStart).toBe(0);
			expect(scope.categoryEnd).toBe(8);
		});
		it('Test 12: incrementBadge() should increment badgeStart and badgeEnd', function (){
			expect(scope.badgeStart).toBe(0);
			expect(scope.badgeEnd).toBe(9);
			scope.incrementBadge();
			expect(scope.badgeStart).toBe(9);
			expect(scope.badgeEnd).toBe(18);
		});
		it('Test 13: decrementBadge() should decrement badgeStart and badgeEnd', function (){
			scope.incrementBadge();
			expect(scope.badgeStart).toBe(9);
			expect(scope.badgeEnd).toBe(18);
			scope.decrementBadge();
			expect(scope.badgeStart).toBe(0);
			expect(scope.badgeEnd).toBe(9);
		});
		it('Test 14: should resolve recipient if member id is passed', function (){
			routeParams.memberId = 'c139a1c0-aea6-11e2-b79d-512ef31a350a';
			scope.initRec();
			httpBackend.flush();
			expect(scope.enableSearch).toBeTruthy();
			expect(scope.search.userMeta.preSelected.length).toBe(1);
		});
		it('Test 15: clear() should call cache.clear and broadcast to hide recognitions ', function (){
			spyOn(rootScope, '$broadcast').andCallThrough();
			scope.clear();
			expect(rootScope.$broadcast).toHaveBeenCalledWith('hideRecognitions');
		});
	});
});
