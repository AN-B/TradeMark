define([
    'unitTests/ui-mocks/modal',
    'unitTests/ui-mocks/recognition.json',
    'unitTests/ui-mocks/likers.list.dlg.ctrl.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (modalMock, recognitionJson, likers) {

    describe('Likers list dialog controller spec -> ', function () {
        var scope,
            modal,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            recognitionSrvc,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, RecognitionSrvc, $location) {
            modal = modalMock;
            recognitionSrvc = RecognitionSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            location = $location;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/Recognition/GetLikedMembers?recordId=b51f10d0-f259-11e3-851e-e1dd1a3833aa&skip=10&type=Congrat')
                .respond(200, recognitionJson.getRecognition());
            scope = $rootScope.$new();
            ctrl = $controller('LikersListCtrl', {
                $rootScope: rootScope,
                $scope: scope,
                $modalInstance: modal,
                params: likers
            });
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        xit('Test 1: showMore() should load more ten likers list', function () {
            spyOn(recognitionSrvc, 'getLikeMember').andCallThrough();
            scope.recognitionId = "b51f10d0-f259-11e3-851e-e1dd1a3833aa";
            scope.congratMemberNames = [];
            scope.showMore();
            expect(recognitionSrvc.getLikeMember).toHaveBeenCalledWith({recordId: scope.recognitionId, skip: 10, type: 'Congrat'});
            httpBackend.flush();
            expect(scope.congratMemberNames).toBeTruthy();
        });
        it('Test 2 : close() should close dialog', function () {
            spyOn(modal, 'dismiss').andCallThrough();
            scope.close();
            expect(modal.dismiss).toHaveBeenCalledWith();
        });
        it('Test 3 : navigateProfile() should navigate to profile feed', function () {
            spyOn(modal, 'dismiss').andCallThrough();
            scope.navigateProfile(recognitionJson.getRecognition().recipients[0].hgId);
            expect(modal.dismiss).toHaveBeenCalledWith();
            location.path('Profile/Feed/962f0220-d9b4-11e2-9d80-8b35d1bed369');
        });
        it('Test 3 : recognizeMember() should navigate to profile feed', function () {
            spyOn(modal, 'dismiss').andCallThrough();
            scope.recognizeMember(recognitionJson.getRecognition().recipients[0].hgId);
            expect(modal.dismiss).toHaveBeenCalledWith();
            location.path('Recognize/Profile/GiveEveryday/962f0220-d9b4-11e2-9d80-8b35d1bed369');
        });
    });
});