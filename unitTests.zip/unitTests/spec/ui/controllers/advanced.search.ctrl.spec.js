define([
    'unitTests/ui-mocks/feed.search.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (feedSearchJson, user) {

    describe('Advanced Search controller spec', function() {
        var scope,
            ctrl,
            httpBackend,
            feedService;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, FeedSrvc) {
            scope = $rootScope.$new();
            feedService = FeedSrvc;
            httpBackend = $injector.get("$httpBackend");
            ctrl = $controller('AdvancedSearchCtrl', {$scope: scope});
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, user.getCu());
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 Advanced Search controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 should call init()', function () {
            httpBackend.whenGET("/svc/Feed/GetMemberDefaultFeedSearch")
                .respond(200, feedSearchJson.getDefaultFeedSearch());
            spyOn(feedService, 'getDefaultFeedSearch').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(feedService.getDefaultFeedSearch).toHaveBeenCalled();
            expect(scope.model.DefaultSearch).toEqual(true);
        });
        it('Test 3: clear() should call backend', function () {
            scope.model.SearchTerm = "Test";
            httpBackend.whenPOST('/svc/Feed/SaveMemberFeedSearch')
                .respond(200, feedSearchJson.getEmptyFeedSearch());
            spyOn(feedService, 'saveFeedSearch').andCallThrough();
            scope.clear();
            httpBackend.flush();
            expect(feedService.saveFeedSearch).toHaveBeenCalledWith({});
            expect(scope.model.SearchTerm).toEqual(undefined);
        });
        it('Test 4: saveSearch() should call backend', function () {
            scope.model.SearchTerm = "Test 2";
            httpBackend.whenPOST('/svc/Feed/SaveMemberFeedSearch')
                .respond(200, feedSearchJson.getDefaultFeedSearch());
            spyOn(feedService, 'saveFeedSearch').andCallThrough();
            scope.saveSearch();
            httpBackend.flush();
            expect(feedService.saveFeedSearch).toHaveBeenCalledWith(scope.model);
        });
        it('Test 5: showSearch', function () {
            scope.showSearch();
            expect(scope.showSearch).toBeTruthy();
        });
    });
});