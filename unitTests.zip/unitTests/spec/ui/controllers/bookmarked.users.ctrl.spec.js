define([
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (groupJson, userJson, cache) {

    describe('Bookmarked Users controller spec', function() {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            userService,
            memberService,
            groupService;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, MemberSrvc, GroupSrvc) {
            rootScope = $rootScope;
            userService = UserSrvc;
            memberService = MemberSrvc;
            groupService = GroupSrvc;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());

            httpBackend.whenPOST("/svc/Member/PinMember")
                .respond(200, {});
            httpBackend.whenPOST("/svc/Member/UnpinMember")
                .respond(200, {});
            httpBackend.whenGET("/svc/Group/GetCurrentGroupMembersDTO?es=false&status=Active")
                .respond(200, groupJson.getCurrentMembersDto());
            httpBackend.whenGET("/svc/Member/GetMyBookedMarkedMembers")
                .respond(200, groupJson.getCurrentMembersDto());
            httpBackend.whenGET("/svc/Member/GetMyBookmarkedTeams")
                .respond(200, groupJson.getMyBookmarkedTeams());
            httpBackend.whenGET("/svc/UI/GetMembersAndDepartments")
                .respond(200, groupJson.getMembersAndDepartments());
            cache.clear('user');
            scope = $rootScope.$new();
            ctrl = $controller('BookedmarkedUsersCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Bookmarked Users controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 1 should call initUsers()', function (){
            spyOn(userService, 'getUser').andCallThrough();
            spyOn(memberService, 'getMyBookmarkedMembers').andCallThrough();
            spyOn(groupService, 'getCurrentGroupMembersDTO').andCallThrough();
            scope.initUsers();
            httpBackend.flush();
            scope.$digest();
            expect(userService.getUser).toHaveBeenCalled();
            expect(scope.bookedmarkedUsers.length).toBe(6);
            expect(scope.search.userMeta.type).toBe('MemberAndDepartment');
        });
    });
});