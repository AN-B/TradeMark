define([
	'unitTests/ui-mocks/review.json',
	'unitTests/ui-mocks/user.json',
    'static/source/core/collectionCache',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(reviewJson, users, cache){

	describe('Perform Cards Review controller spec', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			location,
			routeParams,
			performSrvc,
			userSrvc,
			q;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, PerformSrvc, UserSrvc) {
			performSrvc = PerformSrvc;
			userSrvc = UserSrvc;
			location = $injector.get("$location");
			timeout = $injector.get("$timeout");
			routeParams = $injector.get("$routeParams");
			q = $injector.get("$q");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");

            cache.clear('user');
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, users.getCu());
			httpBackend.whenPOST('/svc/Performance/GetReviewsForMember')
				.respond(200, reviewJson.getMyReviews());
            httpBackend.whenGET('/svc/Member/GetAllSubordinates')
                .respond(200, []);

			scope = $rootScope.$new();

			ctrl = $controller('PerformCardsReviewsCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 Perform Cards Review controller should exist', function (){
			expect(ctrl).toBeDefined();
			expect(scope.isMore).toBeTruthy();
			expect(scope.pendingSkip).toBe(0);
			expect(scope.take).toBe(10);
			expect(scope.pendingLimitTo).toBe(10);
			expect(scope.completedLimitTo).toBe(10);
		});
		it('Test 2 init() should call backend', function (){
			spyOn(userSrvc, 'getUser').andCallThrough();
			spyOn(performSrvc, 'getReviewsForMember').andCallThrough();
			scope.init();
			httpBackend.flush();
			expect(userSrvc.getUser).toHaveBeenCalled();
			expect(performSrvc.getReviewsForMember).toHaveBeenCalledWith({pending : true, skip: 0, take: 10, memberId : 'd2e0d320-a119-11e2-b177-7d64c8315189'});
			expect(scope.pendingReviews.length).toBe(10);
			expect(performSrvc.getReviewsForMember).toHaveBeenCalledWith({pending : false, skip: 0, take: 10, memberId : 'd2e0d320-a119-11e2-b177-7d64c8315189'});
			expect(scope.completedReviews.length).toBe(10);
			expect(scope.CycleTags.length).toBe(2);
		});
		it('Test 3 changing tagFilter  should call backend and tagFilter should be part of the query when bottomScroll', function (){
			spyOn(performSrvc, 'getReviewsForMember').andCallThrough();
			scope.init();
			httpBackend.flush();
			expect(scope.completedReviews.length).toBe(10);
			scope.model.tagFilter = 'test';
            scope.$digest();
			timeout.flush();
			httpBackend.flush();
			expect(performSrvc.getReviewsForMember).toHaveBeenCalledWith({pending : false, skip: 0, take: 10, tag: 'test', memberId : 'd2e0d320-a119-11e2-b177-7d64c8315189'});
			expect(scope.completedReviews.length).toBe(10);
		});
		it('Test 4 changing searchReview  should call backend and searchReview should be part of the query when bottomScroll', function (){
			spyOn(performSrvc, 'getReviewsForMember').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve(reviewJson.getMyReviews());
                return deferred.promise;
            });
			scope.search('test');
            timeout.flush();
			expect(performSrvc.getReviewsForMember).toHaveBeenCalled();			
		});
	});
});