define([
    'unitTests/ui-mocks/modal',
    'static/source/core/collectionCache',
    'unitTests/ui-mocks/tutorial.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (modalMock, cache, tutorialJson) {

    describe('Tutorial instance controller spec', function() {
        var scope,
            ctrl,
            rootScope,
            tutorialModel,
            tutorialGroupName,
            modal;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(module("ui.bootstrap"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            modal = modalMock;
            tutorialModel = tutorialJson.getTutorialModelNonStartOrEnd();
            window = $injector.get('$window');
            rootScope = $rootScope;
            scope = rootScope.$new();
            ctrl = $controller('TutorialInstanceCtrl', {
                $scope: scope,
                $window: window,
                $modalInstance: modal,
                params : {
                    tutorialModel: tutorialModel,
                    tutorialGroupName: tutorialGroupName
                }
            });
            scope.model = {
                loadPause : false
            };
        }));
        afterEach(function () {
            scope.$digest();
        });
        it('Tutorial instance controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

        it('Modal close should be called when scope.previous() and not the first step', function (){
            spyOn(modal, 'close').andCallThrough();
            scope.previous();
            expect(modal.close).toHaveBeenCalledWith(1);
        });

        it('Modal close should not be called when scope.previous() and is the first step', function (){
            scope.model.firstStep = true;
            spyOn(modal, 'close').andCallThrough();
            scope.previous();
            expect(modal.close).not.toHaveBeenCalled();
        });

        it('Modal close should be called when scope.next() and not the last step', function (){
            spyOn(modal, 'close').andCallThrough();
            scope.next();
            expect(modal.close).toHaveBeenCalledWith(3);
        });

        it('Modal close should not be called when scope.next() and is the last step', function (){
            scope.model.lastStep = true;
            spyOn(modal, 'close').andCallThrough();
            scope.next();
            expect(modal.close).not.toHaveBeenCalled();
        });

        it('Modal close should be called when scope.replay() and not the first step', function (){
            spyOn(modal, 'close').andCallThrough();
            scope.replay();
            expect(modal.close).toHaveBeenCalledWith(1);
        });

        it('Modal close should not be called when scope.replay() and is the first step', function (){
            scope.model.firstStep = true;
            spyOn(modal, 'close').andCallThrough();
            scope.replay();
            expect(modal.close).not.toHaveBeenCalled();
        });

        it('Modal dismiss should be called when scope.done() and is the last step', function (){
            scope.model.lastStep = true;
            spyOn(modal, 'dismiss').andCallThrough();
            scope.done();
            expect(modal.dismiss).toHaveBeenCalledWith(tutorialModel);
        });

        it('Modal dismiss should not be called when scope.done() and is not the last step', function (){
            spyOn(modal, 'dismiss').andCallThrough();
            scope.done();
            expect(modal.dismiss).not.toHaveBeenCalled();
        });
    });
});