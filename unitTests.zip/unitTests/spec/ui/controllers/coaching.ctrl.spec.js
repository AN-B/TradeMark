define([
    'unitTests/ui-mocks/user.json',
    'static/source/core/collectionCache',
    'unitTests/ui-mocks/modal',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'],
    function(userJson, cache, modalMock){

    describe('Coaching controller spec', function() {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            userService,
            memberService,
            coachingService,
            commentService;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, MemberSrvc, CoachingSrvc, CommentSrvc) {
            rootScope = $rootScope;
            userService = UserSrvc;
            memberService = MemberSrvc;
            coachingService = CoachingSrvc;
            commentService = CommentSrvc;
            modal = modalMock;

            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            httpBackend.whenPOST('/svc/Coaching/GetCoachingNotesForMember').respond(200, {});
            httpBackend.whenGET('/svc/Member/GetAllSubordinates').respond(200, {});
            httpBackend.whenPOST('/svc/Coaching/GiveCoachingNote').respond(200, {});
            httpBackend.whenPOST('/svc/Comment/CommentCoaching').respond(200, {});
            httpBackend.whenPOST('/svc/Comment/DeleteCoachingNote').respond(200, {});
            httpBackend.whenPOST('/svc/Comment/DeleteComment').respond(200, 'done');

            cache.clear('user');
            scope = $rootScope.$new();
            ctrl = $controller('CoachingCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Coaching controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

        it('Test 1 should call init() for logged in user', function (){
            spyOn(userService, 'getUser').andCallThrough();
            spyOn(coachingService, 'getCoachingNotes').andCallThrough();
            scope.$parent.memberId = null;
            scope.currentMemberId = 'd2c0ef10-a119-11e2-b177-7d64c8315189';
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
            expect(coachingService.getCoachingNotes).toHaveBeenCalled();
            expect(scope.isMember).toBeFalsy();
            expect(scope.Groups).toBeDefined();
        });
        it('Test 2 should call init() for navigated member', function (){
            spyOn(userService, 'getUser').andCallThrough();
            spyOn(memberService, 'getSubordinateMembers').andCallThrough();
            //spyOn(coachingService, 'getCoachingNotes').andCallThrough();
            scope.$parent.memberId = '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864';
            scope.currentMemberId = '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864';
            scope.isMember = true;
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
            expect(memberService.getSubordinateMembers).toHaveBeenCalled();
            //expect(coachingService.getCoachingNotes).toHaveBeenCalled();
            expect(scope.isMember).toBeTruthy();
            //expect(scope.Groups).toBeDefined();
        });
        it('Test 3 should cancel new note', function (){
            scope.cancelCoachingNote();
            expect(scope.NewNote.Comment.length).toBe(0);
        });
        it('Test 4 should give a coaching note', function (){
            scope.NewNote = {
                    Comment: '',
                    RecipientMemberId: '123',
                    Draft: false,
                    TrackId: '',
                    TrackTitle: '',
                    MilestoneId: '',
                    IsValid: true
                };
            scope.Groups = [];
            spyOn(coachingService, 'giveCoachingNotes').andCallThrough();
            scope.NewNote.Comment = 'blah';
            scope.giveCoachingNote();
            httpBackend.flush();
            expect(coachingService.giveCoachingNotes).toHaveBeenCalled();
        });
        it('Test 5 should remove selected track', function (){
            scope.NewNote = {
                    Comment: '',
                    RecipientMemberId: '123',
                    Draft: false,
                    TrackId: '',
                    TrackTitle: '',
                    MilestoneId: '',
                    IsValid: true
                };
            scope.removeTrack();
            expect(scope.NewNote.TrackId.length).toBe(0);
            expect(scope.NewNote.TrackTitle.length).toBe(0);
        });
        // it('Test 6 should open track dialog', function (){
        // });
        it('Test 7 should submit coaching comment', function (){
            var event = {
                    currentTarget : {
                        attributes : [],
                        value: 'blahh'
                }};
            scope.Groups = [
                {
                    Notes: []
                }];
            event.currentTarget.attributes['entity-id'] = '123';
            spyOn(commentService, 'commentCoaching').andCallThrough();
            scope.submitComment(event);
            httpBackend.flush();
            expect(commentService.commentCoaching).toHaveBeenCalled();
        });
        it('Test 8 should delete coaching note', function (){
            var group = {
                Notes: []
            },
            hgId = '123';
            spyOn(commentService, 'deleteCoachingNote').andCallThrough();
            scope.deleteCoachingNote(group, hgId);
            httpBackend.flush();
            expect(commentService.deleteCoachingNote).toHaveBeenCalled();
        });
        it('Test 9 should delete coaching comment', function (){
            var note = {
                Comments: []
            },
            hgId = '123';
            spyOn(commentService, 'deleteComment').andCallThrough();
            scope.deleteComment(note, hgId);
            httpBackend.flush();
            expect(commentService.deleteComment).toHaveBeenCalled();
        });
    });
});