define([
    'unitTests/ui-mocks/modal',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (modalMock) {

    describe('Add gift modal dialog controller spec -> ', function () {
        var scope,
            modal,
            ctrl,
            rootScope,
            backend,
            service,
            timeout,
            params = {
                selectGift: true,
                recipients: [{hgId: 'test', selected: true}]
            };

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProductItemSrvc) {
            service = ProductItemSrvc;
            modal = modalMock;
            rootScope = $rootScope;
            timeout = $injector.get("$timeout");
            backend = $injector.get("$httpBackend");
            backend.whenGET('/svc/ProductItem/GetProductItemsForGifting?search=abc&skip=0&take=0&userIds%5B%5D=test')
                .respond(200, [{hgId: 'prodId'}]);
            backend.whenGET('/svc/ProductItem/GetProductItemsForGifting?skip=0&take=0&userIds%5B%5D=test')
                .respond(200, [{hgId: 'prodId'}]);
            scope = $rootScope.$new();
            ctrl = $controller('AddGiftModalCtrl', {
                $scope: scope,
                $modalInstance: modal,
                params: params
            });
        }));
        afterEach(function () {
            scope.$digest();
            backend.verifyNoOutstandingExpectation();
            backend.verifyNoOutstandingRequest();
        });
        it('Test 1: controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2: search should not call getProductItemsForGifting if search string length is invalid', function () {
            spyOn(service, 'getProductItemsForGifting').andCallThrough();
            scope.search('a');
            expect(service.getProductItemsForGifting).not.toHaveBeenCalled();
        });
        it('Test 3: search should not call getProductItemsForGifting if search string length is invalid', function () {
            spyOn(service, 'getProductItemsForGifting').andCallThrough();
            scope.search('abc');
            timeout.flush();
            backend.flush();
            expect(scope.products.length).toBe(1);
            expect(service.getProductItemsForGifting).toHaveBeenCalled();
        });
        it('Test 4: search should call getProductItemsForGifting if search string length is valid', function () {
            spyOn(service, 'getProductItemsForGifting').andCallThrough();
            scope.search('abc');
            timeout.flush();
            backend.flush();
            expect(scope.products.length).toBe(1);
            expect(service.getProductItemsForGifting).toHaveBeenCalled();
        });
        it('Test 5: selectUsr should select user', function () {
            var user = {hgId: 'test'};
            scope.selectUsr(user);
            expect(user.selected).toBeTruthy();
        });
        it('Test 6: init should call getProductItemsForGifting if step is "gift"', function () {
            spyOn(service, 'getProductItemsForGifting').andCallThrough();
            scope.dlgModel = {step: 'gift',  recipients: [{hgId: 'test', selected: true}]};
            scope.init();
            backend.flush();
            expect(scope.products.length).toBe(1);
            expect(service.getProductItemsForGifting).toHaveBeenCalled();
        });
        it('Test 7: init should not call getProductItemsForGifting if step is "user"', function () {
            spyOn(service, 'getProductItemsForGifting').andCallThrough();
            scope.dlgModel = {step: 'user',  recipients: [{hgId: 'test', selected: true}]};
            scope.init();
            expect(service.getProductItemsForGifting).not.toHaveBeenCalled();
        });
        it('Test 8: selectProduct should set product', function () {
            var test = {hgId: 'prodId'};
            scope.selectProduct(test);
            expect(scope.dlgModel.step).toBe('confirm');
            expect(scope.product).toBe(test);
        });

        it('Test 9: done should call modal close', function () {
            var test = {hgId: 'prodId'};
            spyOn(modal, 'close').andCallThrough();
            scope.done(test);
            expect(modal.close).toHaveBeenCalled();
        });
        it('Test 10: cancel should call modal dismiss', function () {
            spyOn(modal, 'dismiss').andCallThrough();
            scope.cancel();
            expect(modal.dismiss).toHaveBeenCalled();
        });
    });
});