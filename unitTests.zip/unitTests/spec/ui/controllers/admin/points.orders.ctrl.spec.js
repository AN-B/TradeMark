define([
    'unitTests/ui-mocks/productOrder.templates.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (productOrdersjson, userCache) {
    describe('Issue Points Controller spec', function () {
        var scope,
            ctrl,
            rootScope,
            userService,
            httpBackend,
            productOrderSrvc;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProductOrderSrvc, UserSrvc) {
            productOrderSrvc = ProductOrderSrvc;
            rootScope = $rootScope;
            userService = UserSrvc;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            ctrl = $controller('AdminPointsOrdersCtrl', {$scope: scope});

            httpBackend.whenGET('/svc/User/Login').respond(200, userCache.getCu());
            httpBackend.whenPOST('/svc/ProductOrder/GetOrderForGroup')
                .respond(200, {orders: productOrdersjson.getAll()});
            httpBackend.whenPOST('/svc/ProductOrder/FulfillOrder')
                .respond(200, {orders: productOrdersjson.getAll()[1]});
            httpBackend.whenPOST('/svc/ProductOrder/CancelOrder')
                .respond(200, {orders: productOrdersjson.getAll()[0]});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it(' 1 controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it(' 2 init to get all product orders', function () {
            scope.filterOptions.filterText = '';
            scope.pagingOptions.pageSize = 15;
            scope.pagingOptions.currentPage = 1;
            scope.sortOptions = {
                fields: ["FriendlyId"],
                directions: ["desc"]
            };
            scope.Status = 'Cancelled';
            var args = {
                search: scope.filterOptions.filterText,
                take: scope.pagingOptions.pageSize,
                skip: (scope.pagingOptions.currentPage - 1) * scope.pagingOptions.pageSize,
                sortCol: scope.sortOptions.fields[0],
                sortDir: scope.sortOptions.directions[0],
                status : scope.Status
            };
            spyOn(productOrderSrvc, 'getProductOrders').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(productOrderSrvc.getProductOrders).toHaveBeenCalledWith(args);
            expect(scope.orders.length > 0).toBeTruthy();
        });
        it('3 test case for applyFilter', function () {
            spyOn(productOrderSrvc, 'getProductOrders').andCallThrough();
            scope.applyFilter('Cancelled');
            httpBackend.flush();
            expect(productOrderSrvc.getProductOrders).toHaveBeenCalledWith({
                search: '',
                take: 15,
                skip: 0,
                sortCol: 'FriendlyId',
                sortDir: 'desc',
                status : 'Cancelled'
            });
            expect(scope.orders.length > 0).toBeTruthy();
        });
        it('4 test case for updateStatus when action is fulfill order', function () {
            var row = {
                rowIndex : 1
            };
            scope.init();
            httpBackend.flush();
            spyOn(productOrderSrvc, 'fulfillOrder').andCallThrough();
            scope.updateStatus(row, 'Fulfill');
            httpBackend.flush();
            expect(productOrderSrvc.fulfillOrder).toHaveBeenCalledWith({
                OrderId: scope.orders[row.rowIndex].hgId
            });
        });
        it('5 test case for updateStatus when action is Cancel order', function () {
            var row = {
                rowIndex : 0
            };
            scope.init();
            httpBackend.flush();
            spyOn(productOrderSrvc, 'cancelOrder').andCallThrough();
            scope.updateStatus(row, 'Cancel');
            httpBackend.flush();
            expect(productOrderSrvc.cancelOrder).toHaveBeenCalledWith({
                OrderId: scope.orders[row.rowIndex].hgId,
                Note : ''
            });
        });
    });
});