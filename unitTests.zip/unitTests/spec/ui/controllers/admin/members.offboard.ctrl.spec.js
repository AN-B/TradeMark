define([
    'static/source/core/enums/events',
    'static/source/core/collectionCache',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/group.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(events, cache, userJson, groupJson){
    describe('Member offboard controller spec -> ', function() {
        var scope,
            ctrl,
            userService,
            memberService,
            httpBackend,
            rootScope;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            userService = $injector.get('UserSrvc');
            memberService = $injector.get('MemberSrvc');
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            cache.clear('user');
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Member/GetMemberOffboardInfo?MemberId=ede16340-c87b-11e2-aa05-198054fd4117&UserId=d2c0ef10-a119-11e2-b177-7d64c8315189')
                .respond(200, groupJson.getMemberOffboardInfo());
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Member/GetMyBookedMarkedMembers')
                .respond(200, groupJson.getCurrentGroupMembers());
            httpBackend.whenGET('/svc/Group/GetCreditMasterMember')
                .respond(200, groupJson.getCu());

            scope = $rootScope.$new();
            ctrl = $controller('AdminMembersOffBoardCtrl', {$scope: scope});
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 Members offboard controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

        it('Test 2 memberSelected() should get the email address', function (){
            spyOn(memberService, 'getMemberOffboardInfo').andCallThrough();
            scope.memberSelected({
                Id: groupJson.getCu().hgId,
                UserId: userJson.getCu().hgId
            });
            httpBackend.flush();
            expect(memberService.getMemberOffboardInfo).toHaveBeenCalledWith({
                MemberId: groupJson.getCu().hgId,
                UserId: userJson.getCu().hgId
            });
        });
       it('Test 3 changeNotificationEmail() should change UserEmailId to blank at changeEmail is true', function (){
            spyOn(memberService, 'getMemberOffboardInfo').andCallThrough();
            scope.memberSelected({
                Id: groupJson.getCu().hgId,
                UserId: userJson.getCu().hgId
            });
            httpBackend.flush();
            expect(memberService.getMemberOffboardInfo).toHaveBeenCalledWith({
                MemberId: groupJson.getCu().hgId,
                UserId: userJson.getCu().hgId
            });
            scope.model.changeEmail = true;
            scope.changeNotificationEmail();
            expect(scope.model.NewEmail).toBe(userJson.getCu().UserName);
        });
       it('Test 4 changeNotificationEmail() should set UserEmailId from cache at changeEmail is false', function (){
            scope.model.changeEmail = false;
            scope.changeNotificationEmail();
            expect(scope.model.NewEmail).toBeFalsy();
       });
    });
});