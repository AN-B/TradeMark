define([
	'unitTests/ui-mocks/user.json',
	'unitTests/ui-mocks/recognition.templates.json',
	'unitTests/ui-mocks/group.admin.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(userJson, recogTemplate, admin){

	describe('Create Recognitions Value controller spec -> ', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			location,
			routeParams,
			recAdminSrvc,
			recSrvc,
			gpAdminSrvc,
			confirmCallBack,
			modal,
            badgeAdminSrvc,
			returnModel = {
				result: {
					then: function (confirmCallBackParam) {
						confirmCallBack = confirmCallBackParam;
					}
				}
			};

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionAdminSrvc, RecognitionSrvc, GroupAdminSrvc, $modal, BadgeAdminSrvc) {
			modal = $modal;
			recAdminSrvc = RecognitionAdminSrvc;
			recSrvc = RecognitionSrvc;
            badgeAdminSrvc = BadgeAdminSrvc;
			gpAdminSrvc = GroupAdminSrvc;
			location = $injector.get("$location");
			timeout = $injector.get("$timeout");
			routeParams = $injector.get("$routeParams");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
			httpBackend.whenGET('/svc/UI/GetValueRecognitionTemplates?skip=0&take=10')
				.respond(200, recogTemplate.getValue());
			httpBackend.whenGET('/svc/GroupAdmin/GetValueLevelSetting')
				.respond(200, admin.GetValueLevelSetting());
			httpBackend.whenPOST('/svc/RecognitionAdmin/SaveTemplate')
				.respond(200, recogTemplate.getValue().Templates[0]);
			httpBackend.whenPOST('/svc/RecognitionAdmin/DeleteTemplate')
				.respond(200, {});
            httpBackend.whenGET('/svc/Recognition/GetTemplateByHgId?id=c4c5brt0-3da8-11e3-8e3f-3b48bfc048fd')
                .respond(200, {});
			scope = $rootScope.$new();
			ctrl = $controller('AdminRecognitionsValueCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 Settings Manage Recognition controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
		it('Test 2 init() should call backend and return an array of 9 value templates', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.templates.length).toBe(9);
		});
		it('Test 4 addNew should add new template to templates', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.templates.length).toBe(9);
			scope.addNew();
			expect(scope.templates.length).toBe(10);
			expect(scope.templates[scope.selectedIndex].hgId).toBeFalsy();
		});

		it('Test 5 setIndex should set selectedIndex', function (){
			scope.templates = [{
				SubValuesOn: [],
				SubValues: [{
					'Gold':{
						iconSvgURL :''
					}
				}]
			}];
			scope.setIndex(0);
			expect(scope.selectedIndex).toBe(0);
		});
		it('Test 6 toggleSubValue should remove sub values if length is greater than zero and add sub value if length is zero', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.templates[0].SubValues.length).toBe(10);
			scope.addNew();
			expect(scope.templates[0].SubValues.length).toBe(0);
			scope.toggleSubValue();
			expect(scope.templates[0].SubValues.length).toBe(1);
			//expect(scope.templates[0].SubValues.length).toBe(1);
			scope.toggleSubValue();
			expect(scope.templates[0].SubValues.length).toBe(0);
		});
		it('Test 7 deleteSubValue should delete sub value', function (){
			scope.init();
			httpBackend.flush();
			scope.selectedIndex = 0;
			expect(scope.templates[scope.selectedIndex].SubValues.length).toBe(10);
			scope.templates[scope.selectedIndex].SubValues[0].hgId = 'test';
			scope.deleteSubValue(0);
			expect(scope.templates[scope.selectedIndex].SubValues[0].hgId).not.toBe('test');
		});
		it('Test 8 save should call to save valid request', function (){
			scope.init();
			httpBackend.flush();
			scope.selectedIndex = 0;
			spyOn(recAdminSrvc, 'saveTemplate').andCallThrough();
			scope.save();
			httpBackend.flush();
			expect(recAdminSrvc.saveTemplate).toHaveBeenCalled();
		});
		it('Test 9 save should not call to save invalid request', function (){
			scope.init();
			httpBackend.flush();
			spyOn(recAdminSrvc, 'saveTemplate').andCallThrough();
			scope.addNew();
			scope.save();
			expect(recAdminSrvc.saveTemplate).not.toHaveBeenCalled();
		});
		it('Test 10 clear should clear empty item', function (){
			scope.init();
			httpBackend.flush();
			scope.addNew();
			expect(scope.templates.length).toBe(10);
			expect(scope.templates[0].hgId).not.toBeDefined();
			scope.clear(0);
			expect(scope.templates.length).toBe(9);
			expect(scope.templates[0].hgId).toBeDefined();
		});
		it('Test 11 deleteTemplate() should delete template from the scope templates and should call service', function (){
			scope.init();
			httpBackend.flush();
			spyOn(recAdminSrvc, 'deleteTemplate').andCallThrough();
			expect(scope.templates[0].hgId).toBe('ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
			scope.deleteTemplate(0);
			httpBackend.flush();
			expect(recAdminSrvc.deleteTemplate).toHaveBeenCalledWith({TemplateId: 'ba2b5950-3da8-11e3-8e3f-3b48bfc048fd'});
			expect(scope.templates[0].hgId).not.toBe('ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
		});
		it('Test 12 deleteTemplate() should delete template from the scope templates and should not call service', function (){
			scope.init();
			httpBackend.flush();
			scope.addNew();
			spyOn(recAdminSrvc, 'deleteTemplate').andCallThrough();
			spyOn(recSrvc, 'clearRecognitionTemplateCache').andCallThrough();
			expect(scope.templates[0].hgId).toBeFalsy();
			scope.deleteTemplate(0);
			expect(recAdminSrvc.deleteTemplate).not.toHaveBeenCalled();
			expect(recSrvc.clearRecognitionTemplateCache).not.toHaveBeenCalled();
			expect(scope.templates[0].hgId).toBe('ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
		});
		it('Test 13 spec for openBadgeDlg', function () {
			scope.selectedIndex = 0;
			scope.templates = [{
				isDirty: false
			}];
			spyOn(modal, 'open').andReturn(returnModel);
			scope.openBadgeDlg();
            expect(modal.open).toHaveBeenCalled();
			confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
			expect(scope.templates[scope.selectedIndex].isDirty).toBeTruthy();
		});
		it('Test 14 spec for openBadgeDlg with parameter subValue', function () {
			var subValue = {
				BadgeId: '',
				ForegroundFilename: '',
				badgeChosen: '',
				ForeGroundBadgeUrl: '',
				iconSvgURL: ''
			};
			scope.selectedIndex = 0;
			scope.templates = [{
				isDirty: false
			}];
			spyOn(modal, 'open').andReturn(returnModel);
			scope.openBadgeDlg(subValue);
            expect(modal.open).toHaveBeenCalled();
			confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
			expect(subValue.BadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
		});
		it('Test 15 broadcast cacheValues', function () {
			var data = {
				hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123',
				SubValues: []
			};
			scope.templates =[{
				hgId : 'a96e6030-3da8-11e3-8e3f-3b48bfc04123'
			}];
			scope.$broadcast('cacheValues', data);
			expect(data.hgId).toBe(scope.templates[0].hgId);
		});
		it('Test 16 spec for openBackgroundImageDialog', function () {
			scope.selectedIndex = 0;
			scope.init();
			spyOn(modal, 'open').andReturn(returnModel);
			scope.openBackgroundImageDialog();
			httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
			confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
			expect(scope.templates[scope.selectedIndex].BackgroundBadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
		});
		it('Test 17 clear should get the Value templates', function (){
			scope.templates = [{
				hgId: 'c4c5brt0-3da8-11e3-8e3f-3b48bfc048fd'
			}];
			scope.selectedIndex = 0;
			spyOn(recSrvc, 'getTemplateByHgId').andCallThrough();
			scope.clear(0);
			httpBackend.flush();
            expect(recSrvc.getTemplateByHgId).toHaveBeenCalled();
		});
        it('Test 18 spec for openSvgPartColorDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openSvgPartColorDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
        });
	});
});