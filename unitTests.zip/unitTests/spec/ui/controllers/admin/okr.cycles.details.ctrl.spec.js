define([
        'unitTests/ui-mocks/okr.cycle.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(okrJson, approveJson){

        describe('OKR cycle details controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                rootScope,
                goalAdminSrvc,
                goalSrvc,
                location,
                routeParams,
                timeout,
                q;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalsAdminSrvc, GoalSrvc) {
                rootScope = $rootScope;
                goalAdminSrvc = GoalsAdminSrvc;
                goalSrvc = GoalSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                timeout = $injector.get('$timeout');

                routeParams.cycledId = '123';
                scope = $rootScope.$new();
                ctrl = $controller('OkrCyclesDetailsCtrl', {$scope: scope});
            }));
            afterEach(function () {
                //delete routeParams.cycledId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 Okr cycle details controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 on init it should fetch cycle by id', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleDetailsById?CycleId=123')
                    .respond(200, okrJson.getDetails());
                spyOn(goalAdminSrvc, 'getCycleDetailById').andCallThrough();
                scope.init();
                backend.flush();
                expect(goalAdminSrvc.getCycleDetailById).toHaveBeenCalled();
                expect(scope.Cycle.Individuals.length).toBe(10);
            });
            it('Test 3 on loadTeamGoals it should fetch team goals by id', function (){

                backend.whenGET('/svc/Goal/GetGoalsForParticipantByCycleId?cId=123&id=123&skip=0&take=0&type=Team')
                    .respond(200, okrJson.getGoals());
                scope.Cycle = okrJson.getDetails();
                spyOn(goalSrvc, 'getGoalsForParticipantByCycleId').andCallThrough();
                scope.loadTeamGoals(scope.Cycle.Teams[0]);
                backend.flush();
                expect(goalSrvc.getGoalsForParticipantByCycleId).toHaveBeenCalled();
                expect(scope.Cycle.Teams[0].Goals.length).toBe(2);
            });
            it('Test 4 on loadIndividualGoals it should fetch next page member goals', function (){
                backend.whenGET('/svc/Goal/GetGoalsByCycleIdAndType?cId=123&search=&skip=10&take=10&type=Member')
                    .respond(200, okrJson.getGoals());
                scope.Cycle = okrJson.getDetails();
                spyOn(goalSrvc, 'getGoalsByCycleIdsAndType').andCallThrough();
                scope.loadIndividualGoals(1);
                backend.flush();
                expect(goalSrvc.getGoalsByCycleIdsAndType).toHaveBeenCalled();
                expect(scope.Cycle.Individuals.length).toBe(2);
            });
            it('Test 5 on loadIndividualGoals it should fetch previous member goals', function (){
                backend.whenGET('/svc/Goal/GetGoalsByCycleIdAndType?cId=123&search=&skip=0&take=10&type=Member')
                    .respond(200, okrJson.getGoals());
                scope.Cycle = okrJson.getDetails();
                spyOn(goalSrvc, 'getGoalsByCycleIdsAndType').andCallThrough();
                scope.loadIndividualGoals(-1);
                backend.flush();
                expect(goalSrvc.getGoalsByCycleIdsAndType).toHaveBeenCalled();
                expect(scope.Cycle.Individuals.length).toBe(2);
            });
            it('Test 6 on searchMember it should fetch member by keyword', function (){
                backend.whenGET('/svc/Goal/GetGoalsByCycleIdAndType?cId=123&search=&skip=0&take=10&type=Member')
                    .respond(200, okrJson.getGoals());
                scope.Cycle = okrJson.getDetails();
                spyOn(goalSrvc, 'getGoalsByCycleIdsAndType').andCallThrough();
                scope.searchTerm = 'test';
                scope.searchMember();
                timeout.flush();
                backend.flush();
                expect(goalSrvc.getGoalsByCycleIdsAndType).toHaveBeenCalled();
                expect(scope.Cycle.Individuals.length).toBe(2);
            });
            it('Test 7 on deleteCycle it should delete it', function (){
                backend.whenPOST('/svc/GoalCycle/DeleteCycle')
                    .respond(200, {});
                scope.Cycle = okrJson.getDetails();
                spyOn(goalAdminSrvc, 'deleteCycle').andCallThrough();
                scope.deleteCycle(scope.Cycle.hgId);
                backend.flush();
                expect(goalAdminSrvc.deleteCycle).toHaveBeenCalled();
            });
            it('Test 8 on searchTeam it should fetch team by keyword', function (){
                backend.whenGET('/svc/GoalCycle/GetTeamParticipantsForViewing?cId=123' +
                                '&search=test&skip=0&take=10')
                    .respond(200, okrJson.getTeamsForViewing());
                scope.Cycle = okrJson.getDetails();
                spyOn(goalAdminSrvc, 'getCycleTeamsForViewing').andCallThrough();
                scope.teamParticipants.searchTerm = 'test';
                scope.searchTeam();
                timeout.flush();
                backend.flush();
                expect(goalAdminSrvc.getCycleTeamsForViewing).toHaveBeenCalled();
            });
        });
    });