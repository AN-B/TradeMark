define([
    'unitTests/ui-mocks/pointEconomy.templates.json',
    'static/source/hgapp/util/dateUtil',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/autocomplete.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (pointEconomyJson, dateUtil, userCache, autocompleteJson) {
    describe('Transfter Points Controller spec', function () {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            pointService,
            groupService,
            userService,
            autoCompleteSrvc;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, PointSrvc, GroupSrvc, AutoCompleteSrvc) {
            pointService = PointSrvc;
            userService = UserSrvc;
            groupService = GroupSrvc;
            autoCompleteSrvc = AutoCompleteSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            ctrl = $controller('AdminTransferPointsCtrl', {$scope: scope});

            httpBackend.whenGET('/svc/User/Login').respond(200, userCache.getCu());
            httpBackend.whenGET('/svc/Member/GetPointMasterMember')
                .respond(200, {hgId: userCache.getCu().hgId, FullName: userCache.getCu().FullName, UserId: userCache.getCu().UserId});
            httpBackend.whenGET('/svc/Point/GetPointAccounts?MemberId=' + userCache.getCu().hgId)
                .respond(200, {"pointTransfer": {"Balance": 100}, "pointSpend": {"Balance": 50}});

            UserSrvc.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it(' 1 controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it(' 2 init should set To account properties', function () {
            scope.init();
            httpBackend.flush();
            expect(scope.model.toMemberId).toEqual(userCache.getCu().hgId);
            expect(scope.model.toMemberName).toEqual(userCache.getCu().FullName);
            expect(scope.toMemberPoints.Give).toEqual(100);
            expect(scope.toMemberPoints.Spend).toEqual(50);
            expect(scope.model.validation.isToIdInvalid).toEqual(false);
        });
        it(' 3 cancel event should reset page to default settings', function () {
            scope.cancel();
            httpBackend.flush();
            expect(scope.model.toMemberId).toEqual(userCache.getCu().hgId);
            expect(scope.model.toMemberName).toEqual(userCache.getCu().FullName);
            expect(scope.toMemberPoints.Give).toEqual(100);
            expect(scope.toMemberPoints.Spend).toEqual(50);
            expect(scope.model.validation.isToIdInvalid).toEqual(false);
        });
        it(' 4 check for FROM member selection', function () {
            scope.init();
            scope.fromMemberSelected({Id: userCache.getCu().hgId, Name: userCache.getCu().FullName});
            httpBackend.flush();
            expect(scope.model.fromPoints).toEqual(100);
            expect(scope.model.fromAccountType).toEqual('PointTransfer');
        });
        it(' 5 change FROM account Type change to PointTransfer', function () {
            scope.init();
            scope.fromMemberSelected({Id: userCache.getCu().hgId, Name: userCache.getCu().FullName});
            scope.fromAccountTypeChanged('PointTransfer');
            httpBackend.flush();
            expect(scope.model.fromPoints).toEqual(100);
            expect(scope.model.fromAccountType).toEqual('PointTransfer');
        });
        it(' 6 change TO account Type change to PointTransfer', function () {
            scope.init();
            scope.fromMemberSelected({Id: userCache.getCu().hgId, Name: userCache.getCu().FullName});
            scope.fromAccountTypeChanged('PointTransfer');
            httpBackend.flush();
            expect(scope.model.toPoints).toEqual(100);
            expect(scope.model.toAccountType).toEqual('PointTransfer');
        });
        it(' 7 check for invalid data', function () {
            scope.init();
            var model = {
                points: -5
            };
            scope.validate(model);
            httpBackend.flush();
            expect(model.validation.isPointsInvalid).toBeTruthy();
            expect(model.pointsError).toEqual("admin.poi.eco.pev");
        });
        it(' 8 check for invalid data', function () {
            scope.init();
            var model = {
                points:0
            };
            scope.validate(model);
            httpBackend.flush();
            expect(model.validation.isPointsInvalid).toBeTruthy();
        });
        it(' 9 check for invalid data', function () {
            scope.init();
            var model = {
                points:150,
                fromPoints: 100
            };
            scope.validate(model);
            httpBackend.flush();
            expect(model.validation.isPointsInvalid).toBeTruthy();
            expect(model.pointsError).toEqual("admin.poi.eco.tpl");
        });
        it(' 10 check for invalid data', function () {
            scope.init();
            var model = {
                points:25,
                fromPoints: 100,
                fromMemberId: userCache.getCu().hgId,
                toMemberId: userCache.getCu().hgId
            };
            scope.validate(model);
            httpBackend.flush();
            expect(model.validation.isToIdInvalid).toBeFalsy();
            expect(model.validation.isFromIdInvalid).toBeFalsy();
            expect(model.validation.isPointsInvalid).toBeFalsy();
        });
        it(' 11 check for invalid data', function () {
            spyOn(scope, 'validate').andCallThrough();
            spyOn(pointService, 'transferPoints').andCallThrough();
            scope.init();
            var model = {
                points:25,
                fromMemberId: userCache.getCu().hgId,
                fromUserId: userCache.getCu().UserId,
                fromAccountType: "PointTransfer",
                toMemberId: userCache.getCu().hgId,
                toUserId: userCache.getCu().UserId,
                toAccountType: "PointTransfer"
            };
            httpBackend.whenPOST('/svc/Point/TransferPoints').respond(200, {});
            scope.submit(model);
            httpBackend.flush();
            expect(scope.validate).toHaveBeenCalled();
            expect(pointService.transferPoints).toHaveBeenCalledWith({
                FromMemberId: model.fromMemberId,
                FromAccountType: model.fromAccountType,
                FromUserId: model.fromUserId,
                ToMemberId: model.toMemberId,
                ToAccountType: model.toAccountType,
                ToUserId: model.toUserId,
                Points: parseInt(model.points, 10)
            });
        });

    });
});