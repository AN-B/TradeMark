define([
    'unitTests/ui-mocks/perform.cycle.json',
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (cycleJson, groupJson, userJson) {

    describe('Perform Cards Cycle Details controller spec', function () {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            location,
            service,
            tagSrvc,
            toastrSrvc,
            routeParams,
            route;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/Hgapp/Main/default.html', '<div></div>');
            $templateCache.put('templates/Hgapp/Admin/perform-cardlibrary-library.html', '<div></div>')


        }));
        beforeEach(inject(function ($injector, $controller, $rootScope, PerformAdminSrvc, TagSrvc, ToastrSrvc, $route) {
            service = PerformAdminSrvc;
            tagSrvc = TagSrvc;
            route = $route;
            toastrSrvc = ToastrSrvc;
            location = $injector.get("$location");
            timeout = $injector.get("$timeout");
            routeParams = $injector.get("$routeParams");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Performance/GetDistinctDepartmentsByCycle?CardId=b1c00390-fe1b-11e3-809a-7722d475ba48&CycleId=10660990-53b7-11e3-9946-775ceaf8ea2d')
                .respond(200, cycleJson.getDistinctDepartmentsByCycle());
            httpBackend.whenGET('/svc/Performance/GetCycleDetailById?CardId=b1c00390-fe1b-11e3-809a-7722d475ba48&CycleId=10660990-53b7-11e3-9946-775ceaf8ea2d&DeptName=Development')
                .respond(200, cycleJson.getCycleDetail());
            httpBackend.whenPOST('/svc/Performance/CloseReview')
                .respond(200, cycleJson.getClosedReview());
            httpBackend.whenPOST('/svc/Tag/AddTag')
                .respond(200, 'added');
            httpBackend.whenPOST('/svc/Tag/RemoveEntityTag')
                .respond(200, 'removed');
            httpBackend.whenGET('/svc/Group/GetCurrentGroupMembers?status=Active&es=false')
                .respond(200, groupJson.getCurrentGroupMembers());
            scope = $rootScope.$new();
            ctrl = $controller('PerformCardsCyclesDetailsCtrl', {$scope: scope});
            scope.cycledId = '10660990-53b7-11e3-9946-775ceaf8ea2d';
            scope.model = {
                selectedDepartment: 'Development',
                selectedCard: 'b1c00390-fe1b-11e3-809a-7722d475ba48'
            };
            spyOn(route, 'reload').andCallFake(function(){});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Perform Cards Cycles Details controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2: getCycleDetail should call backend and return a cycle with an array of 1 review', function () {
            expect(scope.Cycle).not.toBeDefined();
            spyOn(service, 'getDistinctDepartmentsByCycle').andCallThrough();
            spyOn(service, 'getCycleDetailById').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(service.getDistinctDepartmentsByCycle).toHaveBeenCalledWith({CardId:'b1c00390-fe1b-11e3-809a-7722d475ba48', CycleId:'10660990-53b7-11e3-9946-775ceaf8ea2d'});
            expect(service.getCycleDetailById).toHaveBeenCalledWith({CardId:'b1c00390-fe1b-11e3-809a-7722d475ba48', CycleId:'10660990-53b7-11e3-9946-775ceaf8ea2d', DeptName:'Development'});
            expect(scope.Cycle.ReviewSummaries.length).toBe(1);
        });
        it('Test 3: closeReview should call backend and return a closed review in a specific json format', function () {
            scope.Cycle = cycleJson.getCycleDetail();
            scope.closeReview('106a7660-53b7-11e3-9946-775ceaf8ea2d');
            httpBackend.flush();
            expect(scope.Cycle.ReviewSummaries.length).toBe(1);
            expect(scope.Cycle.ReviewSummaries[0].StatusByAdminView).toBe('Closed');
        });
        it('Test 4: adding tag should call backend to add tag', function () {
            spyOn(tagSrvc, 'addTag').andCallThrough();
            spyOn(toastrSrvc, 'success').andCallThrough();
            scope.init();
            httpBackend.flush();
            routeParams.cycledId = '123';
            scope.Cycle.Tags.push('thanks');
            httpBackend.flush();
            expect(tagSrvc.addTag).toHaveBeenCalledWith({Name: 'thanks', EntityName: 'Cycle', EntityId: '123'});
            expect(toastrSrvc.success).toHaveBeenCalled();
        });
        it('Test 5: removing tag should call the backend to remove tag', function () {
            spyOn(toastrSrvc, 'success').andCallThrough();
            spyOn(tagSrvc, 'removeTag').andCallThrough();
            scope.init();
            httpBackend.flush();
            routeParams.cycledId = '123';
            scope.Cycle.Tags = [];
            httpBackend.flush();
            expect(tagSrvc.removeTag).toHaveBeenCalledWith({Name: 'cycle tag', EntityName: 'Cycle', EntityId: '123'});
            expect(toastrSrvc.success).toHaveBeenCalled();
        });
        it('Test 6: should call update cycle title', function () {
            httpBackend.whenPOST('/svc/Performance/UpdateCycleTitle')
                .respond(200, {});
            spyOn(toastrSrvc, 'success').andCallThrough();
            spyOn(service, 'updateCycleTitle').andCallThrough();
            scope.Cycle = {hgId: 'id'};
            scope.updateTitle('test', function(){});
            httpBackend.flush();
            expect(service.updateCycleTitle).toHaveBeenCalledWith({hgId: 'id', title: 'test'});
            expect(toastrSrvc.success).toHaveBeenCalled();
        });
    });
});