define(['unitTests/ui-mocks/productItem.templates.json',
        'unitTests/ui-mocks/modal',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(productItems, modalMock) {
        describe('Product Image upload dialog controller spec', function () {
            var scope, ctrl, modal, httpBackend, rootScope, uploadSrvc,
                productItem = productItems.getAll()[0];

            beforeEach(function () {
                module('hgapp-app');
                module('ui.bootstrap');
            });
            beforeEach(inject(function ($injector, $controller, $rootScope, UploadSrvc) {
                modal = modalMock;
                uploadSrvc = UploadSrvc;
                rootScope = $rootScope;
                scope = $rootScope.$new();
                httpBackend = $injector.get("$httpBackend");

                httpBackend.whenPOST('/svc/Upload/ProcessAndCropImage')
                    .respond(200, 'file uploaded');
                httpBackend.whenGET('/svc/Group/GetCurrentGroup')
                    .respond(200, { FriendlyGroupId: productItem.FriendlyGroupId});
                httpBackend.whenPOST('/svc/ProductItem/UpdateProductItemImage')
                    .respond(200, {});
                rootScope.imageStore = ['a'];
                rootScope.imageStoreBadges = ['a'];

                ctrl = $controller('ProductImageUploadCtrl', {
                    $rootScope: rootScope,
                    $scope: scope,
                    $modalInstance: modal,
                    UploadSrvc: uploadSrvc,
                    productItem: productItem
                });
            }));

            afterEach(function () {
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
                rootScope.$digest();
            });

            it('upload dialog controller should exist', function () {
                expect(ctrl).toBeDefined();
                expect(typeof scope.imgSelectModel.onSelectEnd === 'function').toBeTruthy();
                expect(scope.imgSelectModel.aspectRatio).toBe('16.18:10');
                expect(scope.imgWidth).toBe(300);
                expect(scope.imgHeight).toBe(300);
                expect(scope.productItem).toBeDefined();
            });

            it('closeDialog() should close dialog', function () {
                spyOn(modal, 'close').andCallThrough();

                scope.closeDialog('test');
                httpBackend.flush();

                expect(modal.close).toHaveBeenCalledWith('test');
            });

            it('fileUploaderSubmit() expect fileUploaded to be false', function () {
                scope.fileUploaded = true;
                scope.selectorImg = {};
                scope.selectorImg.cancelSelection = function(){};
                spyOn(scope.selectorImg, 'cancelSelection').andCallThrough();

                scope.fileUploaderSubmit();

                expect(scope.selectorImg.cancelSelection).toHaveBeenCalled();
                expect(scope.fileUploaded).toBeFalsy();
            });

            it('uploadCompleted() expect fileUploaded to be true', function () {
                spyOn(rootScope, '$broadcast').andCallThrough();

                scope.uploadCompleted('test.jpg');
                httpBackend.flush();

                expect(rootScope.$broadcast).toHaveBeenCalledWith('imageUploaded', rootScope.imageStoreBadges[0] + '/tmp/test.jpg');
                expect(scope.fileUploaded).toBeTruthy();
                expect(scope.ImagePostData.originalName).toBe('test.jpg');
                expect(scope.ImagePostData.imgDirectory).toBe('product/' + productItem.FriendlyGroupId);
            });

            it('saveCroppedImage() expect ImagePostData to be sent', function () {
                scope.fileUploaded = true;
                spyOn(uploadSrvc, 'processAndCropImage').andCallThrough();
                spyOn(scope, 'closeDialog').andCallThrough();

                scope.saveCroppedImage();
                httpBackend.flush();

                expect(uploadSrvc.processAndCropImage).toHaveBeenCalled();
                expect(scope.closeDialog).toHaveBeenCalledWith('file uploaded');
            });
            
        })
    });