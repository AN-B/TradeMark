define([
    'unitTests/ui-mocks/yammer.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (yammerJson, userJson) {
    describe('Admin Integration Yammer controller spec', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope,
            userSrvc,
            yammerSrvc,
            window;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, YammerSrvc) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            ctrl = $controller('AdminSettingsIntegrationsYammerCtrl', {$scope: scope});
            userSrvc = $injector.get('UserSrvc');
            yammerSrvc = YammerSrvc;
            userSrvc.clearUserCache();

            httpBackend = $injector.get('$httpBackend');
            httpBackend.whenGET('/svc/Yammer/GetYammerAuthStatus')
                .respond(200, yammerJson.getYammerAuthStatus());
            httpBackend.whenGET('/svc/Yammer/GetYammerAuthUrl')
                .respond(200, yammerJson.getYammerAuthUrl());
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());

        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Yammer Integration controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 1 if user does not have yammerIntegration permission scope.showYammerIntegration should be false', function () {
            var permissionSpy = spyOn(userSrvc, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                    callback(false);
                }),
                yammerSpy = spyOn(yammerSrvc, 'getYammerAuthStatus').andCallThrough();
            scope.init();
            expect(permissionSpy).toHaveBeenCalled();
            expect(yammerSpy).not.toHaveBeenCalled();
            expect(scope.flags.showYammerIntegration).toBeFalsy();
        });

        it('Test 2 if user does have yammerIntegration permission, then yammerAuthStatus should be called', function () {
            var permissionSpy = spyOn(userSrvc, 'hasPermission').andCallFake(function (tabGroupName, permission, callback) {
                    callback(true);
                }),
                yammerSpy = spyOn(yammerSrvc, 'getYammerAuthStatus').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(permissionSpy).toHaveBeenCalled();
            expect(yammerSpy).toHaveBeenCalled();
            expect(scope.flags.showYammerIntegration).toBeTruthy();
            expect(scope.yammerAuthStatus).toEqual(yammerJson.getYammerAuthStatus());
        });

        it('Test 3 authenticating Yammer should get the URL and then change window location', function () {
            var locationSpy = spyOn(scope, 'locationAssign').andCallFake(function () {
                //do nothing
            });
            scope.authenticateYammer();
            httpBackend.flush();
            expect(locationSpy).toHaveBeenCalledWith(yammerJson.getYammerAuthUrl());
        });
    });
});