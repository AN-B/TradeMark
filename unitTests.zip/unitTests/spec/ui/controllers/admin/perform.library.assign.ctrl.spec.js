define([
    'unitTests/ui-mocks/perform.cycle.json',
    'static/source/core/utility/ng-listener-util',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(cycleJson, listener){

    describe('Perform card library assign controller spec', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            rootScope,
            performAdminSrvc,
            userSrvc,
            pojoSrvc,
            q,
            dtoSrvc,
            performAssignCycleValidation;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            performAdminSrvc = $injector.get('PerformAdminSrvc');
            userSrvc = $injector.get('UserSrvc');
            pojoSrvc = $injector.get('PojoSrvc');
            q = $injector.get('$q');
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/UI/GetCurrentGroupMembersDTO?status=Active&es=false')
                .respond(200, [{test: 'test'}]);
            httpBackend.whenGET("/svc/PojoFactory/GetPojo/PerformanceCycle")
                .respond(200, cycleJson.getPojo());
            scope = $rootScope.$new();
            dtoSrvc = $injector.get('DtoSrvc');
            performAssignCycleValidation = $injector.get('PerformAssignCycleValidation');
            ctrl = $controller('PerformLibraryAssignCtrl', {$scope: scope});
            httpBackend.whenPOST('/svc/Performance/SaveCard')
                .respond(200, {});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 Perform card library assign controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 init should call UserSrvc.getUser and set flags', function () {
           spyOn(userSrvc, 'getUser').andCallFake(function () {
               var deferred = q.defer();
               timeout(function() {
                  deferred.resolve({UserContext: {
                      AggregatedSecuredTabs: {
                          adminTabs: ['recurringCycle', 'cycleSubTab']
                      }
                  }});
               });
               return deferred.promise;
           });
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
            expect(scope.IsRecurringCycle).toBeDefined();
            expect(scope.isCycleTab).toBeDefined();
        });
        it('Test 3 should call setWatch and setSearchMeta on every assignment if cycle is loaded from the cache', function () {
            var numEvents = listener.allEvents().length;
            spyOn(userSrvc, 'getUser').andCallFake(function () { return q.reject(); });
            spyOn(performAdminSrvc, 'getCycleCache').andCallFake(function () { return cycleJson.getCycle(); });
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(listener.allEvents().length > numEvents).toBeFalsy();
        });
    });
});
