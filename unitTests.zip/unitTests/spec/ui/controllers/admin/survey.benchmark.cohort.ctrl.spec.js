define(['unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/survey.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (userJson, surveyJson) {

    describe('Admin Survey Benchmark Cohort Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            routeParams,
            location,
            userService,
            surveySrvc;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, SurveySrvc) {
            userService = UserSrvc;
            surveySrvc = SurveySrvc
            rootScope = $rootScope;
            httpBackend = $injector.get('$httpBackend');
            routeParams = $injector.get('$routeParams');
            location = $injector.get('$location');
            scope = $rootScope.$new();
            ctrl = $controller('AdminSurveyBenchmarkCohortCtrl', {$scope: scope});
            userService.clearUserCache();
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Survey/GetBenchmarkQuestionAverages?')
                .respond(200, {});
            httpBackend.whenGET('/svc/Survey/GetBenchmarkQuestionAverages')
                .respond(200, {});
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2: $scope.init should set model data for department', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkQuestionDetailByDepartment?departmentId=test')
                .respond(200, surveyJson.getBenchmarkQuestionDetailByDepartment());
            routeParams.cohortType = 'Department';
            routeParams.cohortId = 'test';
            scope.init();
            expect(scope.model.cohortType).toEqual('Department');
            expect(scope.model.dataType).toEqual('Department');
            httpBackend.flush();
            expect(scope.model.cohortData).toBeDefined();
        });
        it('Test 3: $scope.init should set model data for location', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkQuestionDetailByLocation?locationId=test')
                .respond(200, surveyJson.getBenchmarkQuestionDetailByDepartment());
            routeParams.cohortType = 'Location';
            routeParams.cohortId = 'test';
            scope.init();
            expect(scope.model.cohortType).toEqual('Location');
            expect(scope.model.dataType).toEqual('Location');
            httpBackend.flush();
            expect(scope.model.cohortData).toBeDefined();
        });
        it('Test 4: $scope.init should set model data for role', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkQuestionDetailByRole?role=test')
                .respond(200, surveyJson.getBenchmarkQuestionDetailByDepartment());
            routeParams.cohortType = 'Role';
            routeParams.cohortId = 'test';
            scope.init();
            expect(scope.model.cohortType).toEqual('Role');
            expect(scope.model.dataType).toEqual('Role');
            httpBackend.flush();
            expect(scope.model.cohortData).toBeDefined();
        });
        it('Test 5: $scope.init should set model data for tenure', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkQuestionDetailByTenure?tenure=test')
                .respond(200, surveyJson.getBenchmarkQuestionDetailByDepartment());
            routeParams.cohortType = 'Tenure';
            routeParams.cohortId = 'test';
            scope.init();
            expect(scope.model.cohortType).toEqual('Tenure');
            expect(scope.model.dataType).toEqual('Tenure');
            httpBackend.flush();
            expect(scope.model.cohortData).toBeDefined();
        });
        it('Test 6: scope.clearSearch should reset scope.cohortSearch', function () {
            scope.cohortSearch = 'test';
            scope.clearSearch();
            expect(scope.cohortSearch).toEqual('');
        });
        it('Test 7: scope.onSelect should call scope.setCohort', function () {
            spyOn(location, 'path').andCallFake(function () {});
            scope.onSelect({Id: 'test'});
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 8: scope.back should change path', function () {
            spyOn(location, 'path').andCallFake(function () {});
            scope.back();
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 9: scope.getAutocompleteData should return search results', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkCohortTypeData?st=test')
                .respond(200, [{"Id":"test","Name":"test"}]);
            var result;
            scope.cohortSearch = 'test';
            result = scope.getAutocompleteData();
            httpBackend.flush();
            expect(result).toBeDefined();
        });
        it('Test 10: scope.getAutocompleteData should return empty array', function () {
            var result;
            scope.cohortSearch = '';
            result = scope.getAutocompleteData();
            expect(result).toEqual([]);
        });
    });
});
