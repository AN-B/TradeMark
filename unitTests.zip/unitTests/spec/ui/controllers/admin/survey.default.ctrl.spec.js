define(['unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (userJson) {
    describe('Admin Survey Default Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            surveySrvc,
            userSrvc,
            compile,
            timeout;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, $compile, SurveySrvc, UserSrvc) {
            surveySrvc = SurveySrvc;
            userSrvc = UserSrvc;
            rootScope = $rootScope;
            compile = $compile;
            timeout = $injector.get('$timeout');
            httpBackend = $injector.get('$httpBackend');
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            UserSrvc.clearUserCache();
            scope = $rootScope.$new();
            ctrl = $controller('AdminSurveyDefaultCtrl', {$scope: scope});
            scope.model = {};
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Admin Survey Pulse Template controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: should set scope.flags and scope.pulseSurvey', function (){
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.flags).toBeDefined();
        });
    });
});
