define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/survey.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (userJson, surveyJson) {
    describe('Admin Survey Pulse Results Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            routeParams,
            timeout;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('template/typeahead/typeahead-popup.html', '<div></div>')
        }));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, $routeParams) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            routeParams = $routeParams;
            httpBackend = $injector.get('$httpBackend');
            timeout = $injector.get('$timeout');

            window.Highcharts = {
                Chart : function () {

                },
                getOptions: function () {
                    return {colors: [{}]}
                }
            };
            ctrl = $controller('AdminSurveyPulseResultsCtrl', {$scope: scope});
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            spyOn(scope, 'drawMoodDivTreemap').andCallFake(function(){});
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Admin Survey Pulse Results controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: scope variables should be defined', function () {
            spyOn(scope, 'setDateRange').andCallFake(function () {});
            scope.init();
            expect(scope.search).toBeDefined();
            expect(scope.PageOptions).toBeDefined();
            expect(scope.dateRanges).toBeDefined();
            httpBackend.flush();
            expect(scope.flags).toBeDefined();
        });
        it('Test 3: setDateRange() should set scope.PageOptions', function () {
            spyOn(scope, 'loadAllMetrics').andCallFake(function () {});
            scope.PageOptions = {
                DateRange: 'LastYear'
            };
            scope.setDateRange();
            expect(scope.PageOptions.StartDate).toBeDefined();
            expect(scope.PageOptions.EndDate).toBeDefined();
        });
        it('Test 4: loadAllMetrics', function () {
            var date = new Date();
            spyOn(scope, 'loadAllMetrics').andCallFake(function(){
                scope.timeChart = {};
            });
            httpBackend.whenGET('/svc/Survey/GetPulseSurveyMetricsByTime?EndDate=' + date.getTime() + '&StartDate=' + date.getTime())
                .respond(200, {test: 'test'});
            httpBackend.whenGET('/svc/Survey/GetAggregatedPulseSurveyMetrics?EndDate=' + date.getTime() + '&StartDate=' + date.getTime())
                .respond(200, surveyJson.getAggregatedPulseSurveyMetrics());
            scope.PageOptions = {
                StartDate: date,
                EndDate: date
            };
            scope.loadAllMetrics();
            //httpBackend.flush();
            expect(scope.timeChart).toBeDefined();
        });
    });
});
