define([
    'unitTests/ui-mocks/okr.cycle.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (okrJson, userJson) {
        describe('Goals cycles edit controller spec', function () {
            var rootScope,
                goalsAdminSrvc,
                userSrvc,
                location,
                q,
                routeParams,
                backend,
                window,
                scope,
                ctrl,
                teamSrvc;


            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalsAdminSrvc, TeamSrvc, UserSrvc) {
                rootScope = $rootScope;
                teamSrvc = TeamSrvc;
                goalsAdminSrvc = GoalsAdminSrvc;
                userSrvc = UserSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                window = $injector.get("$window");
                timeout = $injector.get('$timeout');
                scope = $rootScope.$new();
                routeParams.cycledId = '123';
                ctrl = $controller('OkrCyclesEditCtrl', {$scope: scope});
            }));
            afterEach(function () {
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 goals cycle edit controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 on init it should add initial scope properties', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleForEditById?CycleId=123')
                    .respond(200, okrJson.getEditCycle());
                backend.whenGET('/svc/User/Login')
                    .respond(200, userJson.getCu());
                spyOn(goalsAdminSrvc, 'getCycleForEditById').andCallThrough();
                spyOn(userSrvc, 'getUser').andCallThrough();
                scope.cycleId = '123';
                scope.init();
                backend.flush();
                expect(goalsAdminSrvc.getCycleForEditById).toHaveBeenCalled();
                expect(userSrvc.getUser).toHaveBeenCalled();
                expect(scope.Cycle.hgId).toBe('123');
                expect(scope.Cycle.DeliveryMethods.length).toBe(3);
                expect(scope.search.ownerMeta.type).toBe('Member');
            });
            it('Test 3 loadMembers next page', function (){
                backend.whenGET('/svc/GoalCycle/GetMemberParticipantsForEdit?cId=123' +
                                '&skip=10&take=10')
                    .respond(200, okrJson.getMembers());
                scope.Cycle = okrJson.getEditCycle().Cycle;
                spyOn(goalsAdminSrvc, 'getCycleMembers').andCallThrough();
                scope.loadMembers(1);
                backend.flush();
                expect(goalsAdminSrvc.getCycleMembers).toHaveBeenCalled();
                expect(scope.Members.length).toBe(10);
            });
            it('Test 4 loadMembers prev page', function (){
                backend.whenGET('/svc/GoalCycle/GetMemberParticipantsForEdit?cId=123' +
                                '&skip=0&take=10')
                    .respond(200, okrJson.getMembers());
                scope.Cycle = okrJson.getEditCycle().Cycle;
                spyOn(goalsAdminSrvc, 'getCycleMembers').andCallThrough();
                scope.loadMembers(-1);
                backend.flush();
                expect(goalsAdminSrvc.getCycleMembers).toHaveBeenCalled();
                expect(scope.Members.length).toBe(10);
            });
            it('Test 5 backToList', function (){
                spyOn(location, 'path').andCallFake(function(){});
                scope.backToList();
                expect(location.path).toHaveBeenCalledWith('/Admin/Goals/Cycles/All');
            });
            it('Test 6 on searchMember it should fetch member by keyword', function (){
                backend.whenGET('/svc/GoalCycle/GetMemberParticipantsForEdit?cId=123' +
                                '&search=test&skip=0&take=10')
                    .respond(200, okrJson.getMembers());
                scope.Cycle = (okrJson.getEditCycle()).Cycle;
                spyOn(goalsAdminSrvc, 'getCycleMembers').andCallThrough();
                scope.memberGrid.searchTerm = 'test';
                scope.searchMember();
                timeout.flush();
                backend.flush();
                timeout.flush();
                expect(goalsAdminSrvc.getCycleMembers).toHaveBeenCalled();
                expect(scope.Members.length).toBe(10);
            });
            it('Test 7 switchTeams selectAll', function (){
                backend.whenPOST('/svc/GoalCycle/AddTeams')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'addTeams').andCallThrough();
                scope.Cycle = (okrJson.getEditCycle()).Cycle;
                scope.Teams = (okrJson.getEditCycle()).Teams;
                scope.editModel.teamSelectAll = true;
                scope.switchTeams();
                backend.flush();
                expect(goalsAdminSrvc.addTeams).toHaveBeenCalled();
                var selected = scope.Teams.filter( function(t) {
                    return t.IsInCycle;
                });
                expect(scope.Teams.length).toBe(selected.length);
            });
            it('Test 8 switchTeams unselectAll', function (){
                backend.whenPOST('/svc/GoalCycle/RemoveTeams')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'removeTeams').andCallThrough();
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.Teams = okrJson.getEditCycle().Teams;
                scope.editModel.teamSelectAll = false;
                scope.switchTeams();
                backend.flush();
                expect(goalsAdminSrvc.removeTeams).toHaveBeenCalled();
                var selected = scope.Teams.filter( function(t) {
                    return !t.IsInCycle;
                });
                expect(scope.Teams.length).toBe(selected.length);
            });
            it('Test 9 switchTeam - add team to cycle', function (){
                backend.whenPOST('/svc/GoalCycle/AddTeams')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'addTeams').andCallThrough();
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.Teams = okrJson.getEditCycle().Teams;
                scope.Teams[1].IsInCycle = true;
                scope.switchTeam(scope.Teams[1]);
                backend.flush();
                expect(goalsAdminSrvc.addTeams).toHaveBeenCalled();
            });
            it('Test 10 switchTeam - remove team from cycle', function (){
                backend.whenPOST('/svc/GoalCycle/RemoveTeams')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'removeTeams').andCallThrough();
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.Teams = okrJson.getEditCycle().Teams;
                scope.Teams[0].IsInCycle = false;
                scope.switchTeam(scope.Teams[0]);
                backend.flush();
                expect(goalsAdminSrvc.removeTeams).toHaveBeenCalled();
            });
            it('Test 11 switchMember - add member to cycle', function (){
                backend.whenPOST('/svc/GoalCycle/AddMember')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'addMember').andCallThrough();
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.Members = okrJson.getEditCycle().Members;
                scope.Members[0].IsInCycle = true;
                scope.switchMember(scope.Members[0]);
                backend.flush();
                expect(goalsAdminSrvc.addMember).toHaveBeenCalled();
            });
            it('Test 12 switchMember - remove member from cycle', function (){
                backend.whenPOST('/svc/GoalCycle/RemoveMember')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'removeMember').andCallThrough();
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.Members = okrJson.getEditCycle().Members;
                scope.Members[1].IsInCycle = false;
                scope.switchMember(scope.Members[1]);
                backend.flush();
                expect(goalsAdminSrvc.removeMember).toHaveBeenCalled();
            });
            it('Test 13 saveCycle', function (){
                backend.whenPOST('/svc/GoalCycle/UpdateGoalCycle')
                    .respond(200, {});
                backend.whenGET('/svc/GoalCycle/GetCycleForEditById?CycleId=123')
                    .respond(200, okrJson.getEditCycle());
                backend.whenGET('/svc/User/Login')
                    .respond(200, userJson.getCu());
                scope.cycleId = '123';
                spyOn(goalsAdminSrvc, 'saveCycle').andCallThrough();
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.saveCycle();
                backend.flush();
                expect(goalsAdminSrvc.saveCycle).toHaveBeenCalled();
            });
            it('Test 14 publishCycle', function (){
                backend.whenPOST('/svc/GoalCycle/PublishCycle')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'publishGoalCycle').andCallThrough();
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.publishCycle();
                backend.flush();
                expect(goalsAdminSrvc.publishGoalCycle).toHaveBeenCalledWith({CycleId: scope.Cycle.hgId});
            });
            it('Test 15 on searchTeam it should fetch team by keyword', function (){
                backend.whenGET('/svc/GoalCycle/GetTeamParticipantsForEdit?cId=123' +
                                '&search=test&skip=0&take=10')
                    .respond(200, okrJson.getTeams());
                scope.Cycle = okrJson.getEditCycle().Cycle;
                spyOn(goalsAdminSrvc, 'getCycleTeams').andCallThrough();
                scope.teamGrid.searchTerm = 'test';
                scope.searchTeam();
                timeout.flush();
                backend.flush();
                timeout.flush();
                expect(goalsAdminSrvc.getCycleTeams).toHaveBeenCalled();
                expect(scope.Teams.length).toBe(10);
            });
            it('Test 16 clear', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleForEditById?CycleId=123')
                    .respond(200, okrJson.getEditCycle());
                backend.whenGET('/svc/User/Login')
                    .respond(200, userJson.getCu());
                scope.Cycle = okrJson.getEditCycle().Cycle;
                scope.prestine = angular.copy(scope.Cycle);
                scope.cycleId = '123';
                scope.Cycle.Title = '123';
                scope.clear();
                backend.flush();
                expect(scope.editModel.isDirty).not.toBeDefined();
                expect(scope.Cycle.Title).toBe('New Cycle Draft');
            });
            it('Test 17 setDirty', function (){
                var model = {};
                scope.setDirty(model);
                expect(model.isDirty).toBeTruthy();
            });
            it('Test 18 loadMembers next page', function (){
                backend.whenGET('/svc/GoalCycle/GetTeamParticipantsForEdit?cId=123' +
                                '&skip=10&take=10')
                    .respond(200, okrJson.getTeams());
                scope.Cycle = okrJson.getEditCycle().Cycle;
                spyOn(goalsAdminSrvc, 'getCycleTeams').andCallThrough();
                scope.loadTeams(1);
                backend.flush();
                expect(goalsAdminSrvc.getCycleTeams).toHaveBeenCalled();
                expect(scope.Teams.length).toBe(10);
            });
            it('Test 19 loadTeams prev page', function (){
                backend.whenGET('/svc/GoalCycle/GetTeamParticipantsForEdit?cId=123' +
                                '&skip=0&take=10')
                    .respond(200, okrJson.getTeams());
                scope.Cycle = okrJson.getEditCycle().Cycle;
                spyOn(goalsAdminSrvc, 'getCycleTeams').andCallThrough();
                scope.loadTeams(-1);
                backend.flush();
                expect(goalsAdminSrvc.getCycleTeams).toHaveBeenCalled();
                expect(scope.Teams.length).toBe(10);
            });
            it('Test 20 on select it should get members and set department id', function (){
                backend.whenGET('/svc/GoalCycle/GetMemberParticipantsForEdit?cId=123&deptId=test&skip=0&take=10')
                    .respond(200, okrJson.getMembers());
                scope.Cycle = okrJson.getEditCycle().Cycle;
                spyOn(goalsAdminSrvc, 'getCycleMembers').andCallThrough();
                scope.onSelect({hgId: 'test'});
                backend.flush();
                expect(scope.memberGrid.deptId).toBe('test');
                expect(goalsAdminSrvc.getCycleMembers).toHaveBeenCalled();
                expect(scope.Members.length).toBe(10);
            });
            it('Test 21 ', function (){
                backend.whenGET('/svc/Team/GetDepartmentsAutocomplete?search=test')
                    .respond(200, []);
                spyOn(teamSrvc, 'getDepartmentsAutocomplete').andCallThrough();
                scope.searchAutocomplete('test');
                backend.flush();
                expect(teamSrvc.getDepartmentsAutocomplete).toHaveBeenCalledWith({search: 'test'});
            });
            it('Test 22 setWeightFlag should toggle GoalWeighting flag and set isDirty flag ', function (){
                var test = scope.setWeightFlag({});
                expect(test.GoalWeighting).toBeTruthy();
                expect(test.isDirty).toBeTruthy();
            });
    });
});