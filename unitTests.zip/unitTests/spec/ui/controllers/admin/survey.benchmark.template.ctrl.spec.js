define(['unitTests/ui-mocks/survey.json',
    'unitTests/ui-mocks/user.json',
    'static/source/core/enums/events',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (surveyJson, userJson, events) {
    describe('Admin Survey Benchmark Template Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            surveySrvc,
            userSrvc,
            compile,
            timeout,
            modal;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, $compile, SurveySrvc, UserSrvc) {
            window.Highcharts = {
                Chart : function () {
                    return {test: 'test'};
                }
            };
            surveySrvc = SurveySrvc;
            userSrvc = UserSrvc;
            rootScope = $rootScope;
            compile = $compile;
            timeout = $injector.get('$timeout');
            httpBackend = $injector.get('$httpBackend');
            modal = $injector.get('$modal');
            httpBackend.whenGET('/svc/Survey/GetGroupBenchmarkSurveyTemplate')
                .respond(200, surveyJson.getGroupBenchmarkSurveyTemplate());
            httpBackend.whenPOST('/svc/Survey/SaveGroupBenchmarkSurveyTemplate')
                .respond(200, surveyJson.getGroupBenchmarkSurveyTemplate());
            httpBackend.whenPOST('/svc/Survey/ScheduleBenchmarkSurvey')
                .respond(200, surveyJson.getGroupBenchmarkSurveyTemplate());
            httpBackend.whenPOST('/svc/Survey/CancelBenchmarkSurvey')
                .respond(200, surveyJson.getGroupBenchmarkSurveyTemplate());
            httpBackend.whenPOST('/svc/Survey/DisableBenchmarkSurvey')
                .respond(200, surveyJson.getGroupBenchmarkSurveyTemplate());
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            scope = $rootScope.$new();
            ctrl = $controller('AdminSurveyBenchmarkTemplateCtrl', {$scope: scope});
            scope.model = {};
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Admin Survey Benchmark Template controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

        it('Test 2: $scope.init should call backend and retrieve benchmark survey template', function () {
            spyOn(surveySrvc, 'getGroupBenchmarkSurveyTemplate').andCallThrough();
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.flags.showPoints).toBeDefined();
            expect(scope.flags.showPulseSurveySettings).toBeDefined();
            expect(scope.flags.showBenchmarkSurveySettings).toBeDefined();
            expect(surveySrvc.getGroupBenchmarkSurveyTemplate).toHaveBeenCalled();
            expect(scope.model.Template).toBeDefined();
        });

        it('Test 3: $scope.addQuestion should increment the DriverQuestions array length', function () {
            var length;
            scope.model.Template = surveyJson.setTemplate();
            length = scope.model.Template.DriverQuestions.length
            scope.addQuestion();
            expect(scope.model.Template.DriverQuestions.length).toBe(length + 1);
        });

        it('Test 4: $scope.removeQuestion should should set question status to "Deleted"', function () {
            var length;
            scope.model.Template = surveyJson.setTemplate();
            scope.addQuestion();
            length = scope.model.Template.DriverQuestions.length;
            scope.removeQuestion(scope.model.Template.DriverQuestions[1]);
            expect(scope.model.Template.DriverQuestions[1].Status).toEqual('Deleted');
        });

        it('Test 5: $scope.saveTemplate should call backend and save template when form is valid', function () {
            scope.model.Template = surveyJson.setTemplate();
            spyOn(surveySrvc, 'saveGroupBenchmarkSurveyTemplate').andCallThrough();
            scope.saveTemplate(true);
            httpBackend.flush();
            expect(surveySrvc.saveGroupBenchmarkSurveyTemplate).toHaveBeenCalled();
        });

        it('Test 6: $scope.saveTemplate should not call backend and save template when form is invalid', function () {
            scope.model.Template = surveyJson.setTemplate();
            spyOn(surveySrvc, 'saveGroupBenchmarkSurveyTemplate').andCallThrough();
            scope.saveTemplate(false);
            expect(surveySrvc.saveGroupBenchmarkSurveyTemplate).not.toHaveBeenCalled();
        });

        it('Test 7: $scope.scheduleSurvey should call backend to schedule a survey when form is valid', function () {
            scope.model.Template = surveyJson.setTemplate();
            spyOn(surveySrvc, 'scheduleBenchmarkSurvey').andCallThrough();
            scope.scheduleSurvey(true);
            httpBackend.flush();
            expect(surveySrvc.scheduleBenchmarkSurvey).toHaveBeenCalled();
        });

        it('Test 8: $scope.scheduleSurvey should not call backend to schedule a survey when form is invalid', function () {
            scope.model.Template = surveyJson.setTemplate();
            spyOn(surveySrvc, 'scheduleBenchmarkSurvey').andCallThrough();
            scope.scheduleSurvey(false);
            expect(surveySrvc.scheduleBenchmarkSurvey).not.toHaveBeenCalled();
        });

        it('Test 9: $scope.cancelSurvey should call backend to schedule a survey', function () {
            scope.model.Template = surveyJson.setTemplate();
            spyOn(surveySrvc, 'cancelBenchmarkSurvey').andCallThrough();
            scope.cancelSurvey();
            httpBackend.flush();
            expect(surveySrvc.cancelBenchmarkSurvey).toHaveBeenCalled();
        });

        it('Test 10: $scope.disableSurvey should call backend to schedule a survey', function () {
            scope.model.Template = surveyJson.setTemplate();
            spyOn(surveySrvc, 'disableBenchmarkSurvey').andCallThrough();
            scope.disableSurvey();
            httpBackend.flush();
            expect(surveySrvc.disableBenchmarkSurvey).toHaveBeenCalled();
        });

        it('Test 11: If user does not have MemberPoint permission, then $scope.flags.showPoints should be false', function () {
            spyOn(userSrvc, 'getUser').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
            expect(scope.flags.showPoints).toBeFalsy();
        });
        it('Test 12: totalPoints() should return correct number', function () {
            scope.init();
            httpBackend.flush();
            scope.model.Template = surveyJson.setTemplate();
            scope.model.Points = 2;
            expect(scope.totalPoints()).toEqual(8);
        });
        it('Test 13: should set PercentCompleted and redraw on HgAppSurveyCompleted', function () {
            scope.progressMeter = null;
            scope.$broadcast(events.HgAppSurveyCompleted, {PercentCompleted: 100});
            expect(scope.model.PercentCompleted).toEqual(100);
            expect(scope.progressMeter).toBeTruthy();
        });
        it('Test 14: previewSurvey', function () {
            spyOn(modal, 'open').andCallFake(function () {});
            scope.previewSurvey();
            expect(modal.open).toHaveBeenCalled();
        });
        it('Test 16: getTimeRemaining should return admin.sur.tpl.lth', function () {
            var templateResponse = surveyJson.getGroupBenchmarkSurveyTemplate();
            templateResponse.StartDate = new Date().getTime() - 84600000; // 23.5 hours ago
            templateResponse.DaysToLive = 1;
            templateResponse.Status = 'InProgress';
            httpBackend.whenPOST('/svc/Survey/SaveGroupBenchmarkSurveyTemplate')
                .respond(200, templateResponse);
            scope.model.Template = surveyJson.setTemplate();
            scope.saveTemplate(true);
            httpBackend.flush();
            expect(scope.model.timeLabel).toEqual("admin.sur.tpl.lth");
        });
        it('Test 17: getTimeRemaining should return admin.sur.tpl.hrs', function () {
            var templateResponse = surveyJson.getGroupBenchmarkSurveyTemplate();
            templateResponse.StartDate = new Date().getTime() - 81000000; // 22.5 hours ago
            templateResponse.DaysToLive = 1;
            templateResponse.Status = 'InProgress';
            httpBackend.whenPOST('/svc/Survey/SaveGroupBenchmarkSurveyTemplate')
                .respond(200, templateResponse);
            scope.model.Template = surveyJson.setTemplate();
            scope.saveTemplate(true);
            httpBackend.flush();
            expect(scope.model.timeLabel).toEqual("2admin.sur.tpl.hrs");
        });
        it('Test 18: getTimeRemaining should return admin.sur.tpl.dys', function () {
            var templateResponse = surveyJson.getGroupBenchmarkSurveyTemplate();
            templateResponse.StartDate = new Date().getTime(); // 2 days ago
            templateResponse.DaysToLive = 2;
            templateResponse.Status = 'InProgress';
            httpBackend.whenPOST('/svc/Survey/SaveGroupBenchmarkSurveyTemplate')
                .respond(200, templateResponse);
            scope.model.Template = surveyJson.setTemplate();
            scope.saveTemplate(true);
            httpBackend.flush();
            expect(scope.model.timeLabel).toEqual("2admin.sur.tpl.dys");
        });
    });
});
