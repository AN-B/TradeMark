define([
    'static/source/core/collectionCache',
    'unitTests/ui-mocks/okr.cycles.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(cache, okrJson){

        describe('OKR cycles controller spec', function() {
            var rootScope,
                goalsAdminSrvc,
                location,
                q,
                routeParams,
                backend,
                window,
                timeout,
                scope,
                ctrl;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalsAdminSrvc) {
                rootScope = $rootScope;
                goalsAdminSrvc = GoalsAdminSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                timeout = $injector.get("$timeout");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                window = $injector.get("$window");
                scope = $rootScope.$new();
                ctrl = $controller('OkrCyclesCtrl', {$scope: scope});
                routeParams.filter = 'All';

            }));
            afterEach(function () {
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 goals cycles controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 on init it should add initial scope properties', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                scope.init();
                backend.flush();
                expect(goalsAdminSrvc.getCycles).toHaveBeenCalledWith({take: 10, skip: 0,search: undefined, status: ''});
                expect(scope.goalsTabs['All']).toBeTruthy;
            });
            it('Test 3 on init it should add initial scope properties', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=Pending&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                routeParams.filter = 'Pending';
                scope.init();
                backend.flush();
                expect(goalsAdminSrvc.getCycles).toHaveBeenCalledWith({take: 10, skip: 0,search: undefined, status: 'Pending'});
                expect(scope.goalsTabs['All']).toBeTruthy;
            });
            it('Test 4 on bottomScroll event it should call backend', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                scope.setWatch();
                scope.$broadcast('bottomScroll');
                backend.flush();
                expect(goalsAdminSrvc.getCycles).toHaveBeenCalledWith({take: 10, skip: 0,search: undefined, status: ''});
            });
            it('Test 5 on bottomScroll event it should not call backend if eof is true', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                scope.setWatch();
                scope.eof = true;
                scope.$broadcast('bottomScroll');
                expect(goalsAdminSrvc.getCycles).not.toHaveBeenCalled();
            });
            it('Test 6 getCycles should be called with search empty if var passed to getSearchResults is undefined', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                scope.getSearchResults();
                timeout.flush();
                backend.flush();
                expect(goalsAdminSrvc.getCycles).toHaveBeenCalledWith({take: 10, skip: 0,search: '', status: ''});
            });
            it('Test 7 getCycles should be called with search empty if var passed to getSearchResults is undefined', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                spyOn(timeout, 'cancel').andCallThrough();
                scope.getSearchResults('');
                scope.getSearchResults('');
                expect(timeout.cancel).toHaveBeenCalled();
            });
            it('Test 8 getCycles should not be called if passed value length is 1', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                scope.getSearchResults('a');
                expect(goalsAdminSrvc.getCycles).not.toHaveBeenCalled();
            });
            it('Test 9 getCycles should not be called if passed value length is 2', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                scope.getSearchResults('ab');
                expect(goalsAdminSrvc.getCycles).not.toHaveBeenCalled();
            });
            it('Test 10 getCycles should be called with abc', function (){
                backend.whenGET('/svc/GoalCycle/GetCycleSummaries?search=abc&skip=0&status=&take=10')
                    .respond(200, okrJson.getCycles());
                spyOn(goalsAdminSrvc, 'getCycles').andCallThrough();
                scope.getSearchResults('abc');
                timeout.flush();
                backend.flush();
                expect(scope.Cycles.length).toBeTruthy();
                expect(goalsAdminSrvc.getCycles).toHaveBeenCalledWith({take: 10, skip: 0,search: 'abc', status: ''});
            });
            it('Test 11 it should redirect to edit ', function (){
                spyOn(location, 'path').andCallFake(function(){});
                scope.cycleListItemClick({Status: 'Draft', hgId: 'test'});
                expect(location.path).toHaveBeenCalledWith('/Admin/Goals/Cycles/Edit/test');
            });
            it('Test 12 it should redirect to Details', function (){
                spyOn(location, 'path').andCallFake(function(){});
                scope.cycleListItemClick({Status: 'test', hgId: 'test'});
                expect(location.path).toHaveBeenCalledWith('/Admin/Goals/Cycles/Details/test');
            });
        });
});