define([
    'unitTests/ui-mocks/recognition.templates.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(templatesJson, userJson){

    describe('Admin Recognitions System controller spec - >', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            location,
            routeParams,
            service,
            modal,
            confirmCallBack,
            returnModel = {
                result: {
                    then: function(test) {
                        confirmCallBack = test;
                    }
                }
            };

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionAdminSrvc, $modal, UserSrvc) {
            service = RecognitionAdminSrvc;
            modal = $modal;
            location = $injector.get("$location");
            timeout = $injector.get("$timeout");
            routeParams = $injector.get("$routeParams");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/RecognitionAdmin/GetMilestoneTemplates')
                .respond(200, templatesJson.getSystem());
            httpBackend.whenPOST('/svc/RecognitionAdmin/SaveServiceAward')
                .respond(200, templatesJson.getSystem()[0]);
            httpBackend.whenPOST('/svc/RecognitionAdmin/UpdateServiceAward')
                .respond(200, templatesJson.getSystem()[0]);
            httpBackend.whenPOST('/svc/RecognitionAdmin/DeleteServiceAward')
                .respond(200, {});
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            scope = $rootScope.$new();
            UserSrvc.clearUserCache();
            ctrl = $controller('AdminRecognitionsSystemCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 Admin Recognitions System controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 init function should call backend', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.templates.length).toBe(2);
        });
        it('Test 3 setIndex will set scope.selectedIndex to 0 when 0 is passed', function (){
            expect(scope.selectedIndex).toBe(-1);
            scope.templates = [{
                ForeGroundBadgeUrl: ''
            }];
            scope.setIndex(0);
            expect(scope.selectedIndex).toBe(0);
        });

        it('Test 4 should add new record to the templates object', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.templates.length).toBe(2);
            expect(scope.templates[0].hgId).toBeDefined();
            scope.addNew();
            expect(scope.templates.length).toBe(3);
            expect(scope.templates[0].hgId).not.toBeDefined();
        });
        it('Test 5 save should call new saveTemplate if template is valid', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            scope.templates[0] = {
                "Title":"service award 5",
                "Message": "test123",
                "Description":"",
                "Category":"System",
                "FriendlyGroupId":1,
                "PointValue":6,
                "CreditValue":6,
                "SubValues":[],
                "ForegroundFilename":"IconATV.svg",
                "BackgroundFilename":"BorderCardSpade.svg",
                "BadgeId":"7793d0e0-883f-11e3-8aee-2f0e4f4dbcac",
                "BackgroundBadgeId":"c84798f0-8d12-11e3-8e02-b9ba59330e1a",
                "YearsNumber":5
            };
            spyOn(service, 'saveServiceAward').andCallThrough();
            scope.save();
            httpBackend.flush();
            expect(service.saveServiceAward).toHaveBeenCalled();
        });
        it('Test 6 save should not call saveTemplate if template is invalid', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            spyOn(service, 'saveServiceAward').andCallThrough();
            spyOn(scope, 'cancel').andCallThrough();
            scope.save();
            expect(service.saveServiceAward).not.toHaveBeenCalled();
            expect(scope.cancel).not.toHaveBeenCalled();
        });
        it('Test 7 save should call new updateTemplate if template is valid', function (){
            scope.init();
            httpBackend.flush();
            scope.selectedIndex = 0;
            scope.templates[0].Title = "service award 123";
            spyOn(service, 'updateServiceAward').andCallThrough();
            scope.save();
            httpBackend.flush();
            expect(service.updateServiceAward).toHaveBeenCalled();
        });
        it('Test 8 cancel should delete new template', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            expect(scope.templates[0].hgId).not.toBeDefined();
            scope.cancel();
            expect(scope.templates[0].hgId).toBeDefined();
        });
        it('Test 9 cancel should clear selectedIndex', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.templates.length).toBe(2);
            scope.selectedIndex = 0;
            scope.cancel();
            expect(scope.templates.length).toBe(2);
            expect(scope.selectedIndex).toBe(-1);
        });
        it('Test 10 deleteServiceAward() should delete template from the scope templates and should call service', function (){
            scope.init();
            httpBackend.flush();
            spyOn(service, 'deleteServiceAward').andCallThrough();
            spyOn(service, 'clearMilestoneTemplateCache').andCallThrough();
            expect(scope.templates[0].hgId).toBe('eb367f20-2983-11e5-ad8a-65cef6744bfc');
            scope.deleteServiceAward(0);
            httpBackend.flush();
            expect(service.deleteServiceAward).toHaveBeenCalledWith({TemplateId: 'eb367f20-2983-11e5-ad8a-65cef6744bfc'});
            expect(service.clearMilestoneTemplateCache).toHaveBeenCalled();
            expect(scope.templates[0].hgId).not.toBe('eb367f20-2983-11e5-ad8a-65cef6744bfc');
        });
        it('Test 11 spec for openBadgeDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openIconImageDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
            confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
            expect(scope.templates[scope.selectedIndex].BadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
        });
        it('Test 12 spec for openBackgroundImageDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openBackgroundImageDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
            confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
            expect(scope.templates[scope.selectedIndex].BackgroundBadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
        });
    });
});
