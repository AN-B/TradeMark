define(['unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (userJson) {
    describe('Admin Survey Benchmark Results Listing Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, SurveySrvc) {
            userService = UserSrvc;
            surveySrvc = SurveySrvc
            rootScope = $rootScope;
            httpBackend = $injector.get('$httpBackend');
            scope = $rootScope.$new();
            ctrl = $controller('AdminSurveyBenchmarkCtrl', {$scope: scope});
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2: $scope.init should set $scope.model', function () {
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyResultList?skip=0&take=10').respond(200, [0,1,2]);
            spyOn(userService, 'getUser').andCallThrough();
            spyOn(surveySrvc, 'getResultList').andCallThrough();
            scope.init();
            httpBackend.flush();
            scope.$digest();
            expect(scope.model.length).toEqual(3);
        });
    });
});