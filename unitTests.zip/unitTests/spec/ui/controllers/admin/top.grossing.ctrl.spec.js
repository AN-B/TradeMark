define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function() {
        describe('Top grossing products controller spec', function() {
            var rootScope,
                location,
                backend,
                scope,
                ctrl,
                productSrvc;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, ProductOrderSrvc, ToastrSrvc) {
                rootScope = $rootScope;
                productSrvc = ProductOrderSrvc;
                toasterSrvc = ToastrSrvc;
                location = $injector.get("$location");
                backend = $injector.get("$httpBackend");
                scope = $rootScope.$new();
                ctrl = $controller('AdminTopGrossingCtrl', {$scope: scope});
            }));
            afterEach(function () {
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 - Top grossing products controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 - init ', function (){
                backend.whenGET('/svc/ProductOrder/GetTopProducts?endDate=&startDate=').respond(200, [1,2,3]);
                spyOn(productSrvc, 'getTopProducts').andCallThrough();
                scope.init();
                backend.flush();
                expect(scope.topProducts.length).toBe(3);
                expect(productSrvc.getTopProducts).toHaveBeenCalled();
            });
            it('Test 3 - filterResults ', function (){
                var start = new Date('10/01/2014').getTime(),
                    end = new Date('10/01/2015').getTime();
                backend.whenGET('/svc/ProductOrder/GetTopProducts?endDate=' + end + '&startDate=' + start).respond(200, [1,2,3,4]);
                spyOn(productSrvc, 'getTopProducts').andCallThrough();
                scope.model.StartDate = new Date('10/01/2014').getTime();
                scope.model.EndDate = new Date('10/01/2015').getTime();
                scope.filterResults();
                backend.flush();
                expect(scope.topProducts.length).toBe(4);
                expect(productSrvc.getTopProducts).toHaveBeenCalled();
            });
            it('Test 4 - exportExcel ', function (){
                backend.whenGET('/svc/ProductOrder/ExportTopProducts?endDate=&ext=xlsx&startDate=').respond(200, {});
                spyOn(productSrvc, 'exportTopProducts').andCallThrough();
                scope.exportExcel();
                backend.flush();
                expect(productSrvc.exportTopProducts).toHaveBeenCalled();
            });
    });
});