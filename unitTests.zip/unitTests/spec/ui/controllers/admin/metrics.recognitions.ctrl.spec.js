define([
    'static/source/provision/util/metrics-util',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/metrics',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (util, userJson, groupJson, metrics) {
    describe('Metrics recognitions controller spec -->', function () {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            metricsSrvc,
            q,
            ptabs = function(){
                return {
                    get: function(){
                        return true;
                    }
                };
            };
        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, MetricsSrvc) {
            metricsSrvc = MetricsSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Group/GetCurrentGroup')
                .respond(200, groupJson.getCurrentGroup());
            q = $injector.get("$q");
            ctrl = $controller('AdminMetricsRecognitionsCtrl', {$scope: scope, metricMode: 'admin', ptabs: ptabs});
            spyOn(metricsSrvc, 'getMyGroupRecognitionMetrics').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve(metrics.get());
                return deferred.promise;
            });
            spyOn(metricsSrvc, 'getHighcharts').andCallThrough();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test: 1 controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test: 2 dateRangeChanged call getMyGroupRecognitionMetrics', function () {
            scope.init();
            httpBackend.flush();
            scope.$digest();
            scope.dateRangeChanged(scope.PageOptions);
            expect(metricsSrvc.getMyGroupRecognitionMetrics).toHaveBeenCalled();
            expect(metricsSrvc.getHighcharts).toHaveBeenCalled();
        });
        it('Test: 3 startDateChanged call getMyGroupRecognitionMetrics', function () {
            scope.init();
            httpBackend.flush();
            scope.$digest();
            scope.startDateChanged(new Date());
            expect(metricsSrvc.getMyGroupRecognitionMetrics).toHaveBeenCalled();
            expect(metricsSrvc.getHighcharts).toHaveBeenCalled();
        });
        it('Test: 4 endDateChanged call getMyGroupRecognitionMetrics', function () {
            scope.init();
            httpBackend.flush();
            scope.$digest();
            scope.endDateChanged(new Date());
            expect(metricsSrvc.getMyGroupRecognitionMetrics).toHaveBeenCalled();
            expect(metricsSrvc.getHighcharts).toHaveBeenCalled();
        });
    });
});
