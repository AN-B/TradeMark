define([
	'static/source/core/enums/events',
	'unitTests/ui-mocks/perform.cycle.json',
    'unitTests/ui-mocks/group.json',
	'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/searchMeta.json',
    'static/source/core/collectionCache',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(events, cycleJson, groupJson, userJson, searchMetaJson, cache){

	describe('Perform cycles controller spec -> ', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			userService,
			performService,
            q;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, PerformAdminSrvc) {
			userService = UserSrvc;
			performService = PerformAdminSrvc;
			timeout = $injector.get("$timeout");
            q = $injector.get("$q");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
            cache.clear('user');
			cache.clear('cycleRequest');
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
			httpBackend.whenGET('/svc/Performance/GetGroupCycleSummaryCount')
				.respond(200, cycleJson.getCycleSummaryCount());
			httpBackend.whenGET('/svc/Performance/GetCycles?take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=10&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=20&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=30&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=40&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=50&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=60&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=70&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?tag=test&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=10&tag=test&take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?take=10')
				.respond(200, cycleJson.getCycles());
			httpBackend.whenGET('/svc/Performance/GetCycles?skip=10&take=10&title=test')
				.respond(200, cycleJson.getCycles());
			scope = $rootScope.$new();
			ctrl = $controller('PerformCardsCyclesCtrl', {$scope: scope});
			scope.allowSubTabs = {};

		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 perform cycles controller should exist', function (){
			expect(ctrl).toBeDefined();
			expect(scope.model.isMore).toBeTruthy();
			expect(scope.model.skip).toBe(0);
			expect(scope.model.take).toBe(10);
			expect(scope.model.limitTo).toBe(10);
			expect(scope.Summary.PendingCycles).toBe(0);
			expect(scope.Summary.InProgressReviews).toBe(0);
			expect(scope.Summary.CompletedReviews).toBe(0);
		});
		it('Test 2 init() should call backend', function (){
			spyOn(userService, 'getUser').andCallThrough();
			spyOn(performService, 'getGroupCycleSummaryCount').andCallThrough();
			spyOn(performService, 'getCycles').andCallThrough();
            scope.init();
			httpBackend.flush();
			expect(scope.isCycleTab).toBeFalsy();
			expect(userService.getUser).toHaveBeenCalled();
			expect(performService.getGroupCycleSummaryCount).toHaveBeenCalled();
			expect(performService.getCycles).toHaveBeenCalledWith({skip : 0, take : 10, isMore : true, limitTo : 10, startDate : null, endDate : null, tag : '', status : '', title : '', cardType : ''});
			expect(scope.Cycles.length).toBe(10);
			expect(scope.CycleTags.length).toBe(2);
		});
		it('Test 3 broadcast bottomScroll should increment limitTo and callbackend when cycles.length is less than limitTo', function (){
			spyOn(performService, 'getCycles').andCallThrough();
			expect(scope.model.limitTo).toBe(10);
			scope.init();
			httpBackend.flush();
			scope.$broadcast('bottomScroll');
			httpBackend.flush();
			expect(performService.getCycles).toHaveBeenCalledWith({ skip : 0, take : 10, isMore : true, limitTo : 10, startDate : null, endDate : null, tag : '', status : '', title : '', cardType : ''});
			expect(scope.model.limitTo).toBe(20);
			expect(scope.Cycles.length).toBe(20);
			scope.$broadcast('bottomScroll');
			expect(scope.model.limitTo).toBe(30);
			expect(scope.Cycles.length).toBe(20);
			scope.$broadcast('bottomScroll');
			expect(scope.model.limitTo).toBe(40);
			expect(scope.Cycles.length).toBe(20);
			scope.$broadcast('bottomScroll');
			expect(scope.model.limitTo).toBe(50);
			expect(scope.Cycles.length).toBe(20);
			scope.$broadcast('bottomScroll');
			expect(scope.model.limitTo).toBe(60);
			expect(scope.Cycles.length).toBe(20);
			scope.$broadcast('bottomScroll');
			httpBackend.flush();
			expect(scope.model.limitTo).toBe(70);
			expect(scope.Cycles.length).toBe(70);
			scope.$broadcast('bottomScroll');
			httpBackend.flush();
		});
		it('Test 4 changing tagFilter  should call backend and tagFilter should be part of the query when bottomScroll', function (){
			spyOn(performService, 'getCycles').andCallThrough();
			scope.init();
			httpBackend.flush();
			expect(scope.Cycles.length).toBe(10);
			scope.model.tagFilter = 'test';
			timeout.flush();
			httpBackend.flush();
			expect(performService.getCycles).toHaveBeenCalledWith({ skip : 0, take : 10, isMore : true, limitTo : 10, startDate : null, endDate : null, tag : 'test', status : '', title : '', cardType : ''});
			expect(scope.Cycles.length).toBe(10);
			scope.$broadcast('bottomScroll');
			timeout.flush();
			httpBackend.flush();
			expect(performService.getCycles).toHaveBeenCalledWith({ skip : 0, take : 10, isMore : true, limitTo : 10, startDate : null, endDate : null, tag : 'test', status : '', title : '', cardType : ''});
		});
		it('Test 5 changing searchWhat  should call backend and searchWhat should be part of the query when bottomScroll', function () {
			spyOn(performService, 'getCycles').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve(cycleJson.getCycles());
                return deferred.promise;
            });
			scope.search('test');
            timeout.flush();
			expect(performService.getCycles).toHaveBeenCalled();

		});
	});
});