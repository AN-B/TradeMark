define([
	'unitTests/ui-mocks/okr.cycles.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(okrJson){
        describe('Goals cycles create controller spec', function() {
            var rootScope,
                goalsAdminSrvc,
                location,
                q,
                routeParams,
                backend,
                window,
                scope,
                ctrl;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalsAdminSrvc, TeamSrvc) {
                rootScope = $rootScope;
                goalsAdminSrvc = GoalsAdminSrvc;
                teamSrvc = TeamSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                window = $injector.get("$window");
                scope = $rootScope.$new();
                ctrl = $controller('OkrCyclesCreateCtrl', {$scope: scope});

                backend.whenGET('/svc/GoalCycle/GetCycleSummaries')
                    .respond(200, okrJson.getCycles());
            }));
            afterEach(function () {
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 goals cycle create controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 on cancel cycle create', function (){
                spyOn(location, 'path').andCallFake(function(){});
                scope.cancel();
                expect(location.path).toHaveBeenCalledWith('Admin/Goals/Cycles/All');
            });
            it('Test 3 setWeightFlag should toggle GoalWeighting and set isDirty flag to true', function (){
                var test = scope.setWeightFlag({});
                expect(test.isDirty).toBeTruthy();
                expect(test.GoalWeighting).toBeTruthy();
            });
    });
});