define([
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (userJson) {
    describe('Admin Survey Benchmark Results Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            routeParams,
            timeout;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, $routeParams) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            routeParams = $routeParams;
            httpBackend = $injector.get('$httpBackend');
            timeout = $injector.get('$timeout');
            ctrl = $controller('AdminSurveyBenchmarkResultsCtrl', {$scope: scope});
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());

            UserSrvc.clearUserCache();
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Admin Survey Benchmark Results controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

        it('Test 2: $scope.init should set $scope.model', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyResult?currentRoundId=zoo&recurrenceId=bar&surveyId=foo')
                .respond(200, {cohorts: [{}]});
            routeParams.surveyId = 'foo';
            routeParams.recurrenceId = 'bar';
            routeParams.currentRoundId = 'zoo';
            scope.init();
            httpBackend.flush();
            expect(scope.model).toEqual({
                cohorts: [{predicate: 'engagement', reverse: true}],
                summarySortModel:{predicate: 'engagement', reverse: true}
            });
        });
        it('Test 3: getSurveyComments should set driverLabel and showComments flag to true', function () {
            scope.getSurveyComments('testId', 'testName');
            expect(scope.commentsListModel.driverId).toEqual('testId');
            expect(scope.commentsListModel.label).toEqual('testName');
            expect(scope.flags.showComments).toBe(true);
        });
        it('Test 7: exportPDF should open new window with the pdf file', function () {
            spyOn(window, 'open').andCallFake(function () {});
            scope.exportPDF();
            expect(window.open).toHaveBeenCalled();
        })
    });
});
