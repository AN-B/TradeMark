define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/productItem.templates.json',
    'unitTests/ui-mocks/group.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, productItemsJson, groupJson){

    describe('Points Products Controller spec -> ', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            productItemService,
            userService,
            modalSeviceMock,
            confirmCallBack,
            returnModel = {
                result: {
                    then: function(test) {
                        confirmCallBack = test;
                    }
                }
            },
            q;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProductItemSrvc, UserSrvc, $modal) {
            modalSeviceMock = $modal;
            productItemService = ProductItemSrvc;
            userService = UserSrvc;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            q = $injector.get("$q");
            httpBackend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            ctrl = $controller('AdminPointsProductsCtrl', {$scope: scope});

            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/ProductItem/GetProductItemsForAdmin')
                .respond(200, productItemsJson.getAll());
            httpBackend.whenPOST('/svc/ProductItem/CreateProductItem')
                .respond(200, productItemsJson.getAll()[0]);
            httpBackend.whenPOST('/svc/ProductItem/DeleteProductItem')
                .respond(200, 'The product item has been deleted.');
            httpBackend.whenPOST('/svc/ProductItem/ApproveProductSuggestion')
                .respond(200, 'The product item has been Updated.');
            httpBackend.whenPOST('/svc/ProductItem/RejectProductSuggestion')
                .respond(200, 'The product item has been deleted.');
            httpBackend.whenGET("/svc/Group/GetCurrentGroupMembers?es=false&status=Active")
                .respond(200, groupJson.getCurrentGroupMembers());
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2: init() should call backend', function () {
            scope.init();
            httpBackend.flush();
            expect(scope.productItems.length).toBe(3);
        });

        it('Test 3: setIndex will set scope.selectedIndex', function () {
            scope.init();
            httpBackend.flush();
            scope.productItems = productItemsJson.getAll();
            expect(scope.selectedIndex).toBeUndefined();

            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);
            expect(scope.selectedIndex).toBe(0);
        });

        it('Test 4: addNew() should add new record to productItems array', function () {
            scope.init();
            httpBackend.flush();

            expect(scope.productItems.length).toBe(3);
            expect(scope.productItems[0].hgId).toBeDefined();

            scope.addNew();

            expect(scope.selectedIndex).toBe(0);
            expect(scope.productItems.length).toBe(4);
            expect(scope.productItems[0].hgId).not.toBeDefined();
        });

        it('Test 5: clear() should clear selectedIndex and new record', function () {
            scope.init();
            httpBackend.flush();
            scope.addNew();

            expect(scope.productItems.length).toBe(4);
            expect(scope.productItems[0].hgId).not.toBeDefined();
            expect(scope.selectedIndex).toBe(0);

            scope.clear();

            expect(scope.productItems.length).toBe(3);
            expect(scope.productItems[0].hgId).toBeDefined();
            expect(scope.selectedIndex).toBeFalsy();
        });

        it('Test 6: saveItem() should call createProductItem if hgId is undefined and product item is valid and product type is store', function () {
            scope.init();
            httpBackend.flush();
            scope.addNew();
            scope.productItems[0] = productItemsJson.getNew();

            spyOn(productItemService, 'createProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            httpBackend.flush();

            expect(productItemService.createProductItem).toHaveBeenCalled();
            expect(productItemService.clearCache).toHaveBeenCalled();
        });

        it('Test 7: saveItem() should not call createProductItem if hgId is undefined and product item is not valid and product type is store', function () {
            scope.init();
            httpBackend.flush();
            scope.addNew();
            scope.productItems[0] = productItemsJson.getNew();
            scope.productItems[0].Name = '';

            spyOn(productItemService, 'createProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            expect(productItemService.createProductItem).not.toHaveBeenCalled();
            expect(productItemService.clearCache).not.toHaveBeenCalled();
        });

        it('Test 8: saveItem() should call updateProductItem if hgId is defined and product type is store', function () {
            httpBackend.whenPOST('/svc/ProductItem/UpdateProductItem')
                .respond(200, productItemsJson.getAll()[0]);
            scope.init();
            httpBackend.flush();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);

            spyOn(productItemService, 'updateProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            httpBackend.flush();

            expect(productItemService.updateProductItem).toHaveBeenCalled();
            expect(productItemService.clearCache).toHaveBeenCalled();
        });

        it('Test 9: saveItem() should not call updateProductItem if hgId is defined and product item is not valid and product type is store', function () {
            scope.init();
            httpBackend.flush();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);
            scope.productItems[0].Name = '';

            spyOn(productItemService, 'updateProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            expect(productItemService.updateProductItem).not.toHaveBeenCalled();
            expect(productItemService.clearCache).not.toHaveBeenCalled();
        });

        it('Test 10: clear() should delete new product item', function () {
            scope.init();
            httpBackend.flush();
            scope.addNew();

            expect(scope.productItems[0].hgId).not.toBeDefined();
            expect(scope.productItems.length).toBe(4);

            scope.clear();

            expect(scope.productItems[0].hgId).toBeDefined();
            expect(scope.productItems.length).toBe(3);
        });

        it('Test 11: clear() should restore existing product item from cache', function () {
            scope.init();
            httpBackend.flush();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);

            spyOn(productItemService, 'getProductItemsForAdmin').andCallThrough();

            scope.clear();

            expect(productItemService.getProductItemsForAdmin).toHaveBeenCalled();
        });

        it('Test 11: deleteItem() should delete productItem from scope and call productItemService', function () {
            scope.init();
            httpBackend.flush();
            spyOn(productItemService, 'deleteProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            expect(scope.productItems[0].hgId).toBe('21f61c10-c403-11e3-a9c0-71c4281b4207');
            scope.deleteItem(scope.productItems[0].hgId, 0);
            httpBackend.flush();

            expect(productItemService.deleteProductItem).toHaveBeenCalledWith({hgId: '21f61c10-c403-11e3-a9c0-71c4281b4207'});
            expect(productItemService.clearCache).toHaveBeenCalled();
            expect(scope.productItems.length).toBe(2);
        });

        it('Test 12: deleteItem() should delete new item from scope and not call productItemService', function () {
            scope.init();
            httpBackend.flush();
            spyOn(productItemService, 'deleteProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.addNew();
            expect(scope.productItems[0].hgId).toBeFalsy();
            scope.deleteItem(scope.productItems[0].hgId, 0);

            expect(productItemService.deleteProductItem).not.toHaveBeenCalled();
            expect(productItemService.clearCache).not.toHaveBeenCalled();
            expect(scope.productItems.length).toBe(3);
        });

        it('Test 13: approveProductSuggestion() should update status Approve of suggested product item', function () {
            scope.init();
            httpBackend.flush();
            scope.setIndex('5f4dd850-c403-11e3-a9c0-71c4281b4208', 0);

            spyOn(productItemService, 'approveProductSuggestion').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.productItems[scope.selectedIndex].Status = 'Active';
            scope.approveProductSuggestion();
            httpBackend.flush();

            expect(productItemService.approveProductSuggestion).toHaveBeenCalled();
            expect(productItemService.clearCache).toHaveBeenCalled();

        });

        it('Test 14: approveProductSuggestion() should not call approveProductSuggestion if Status is ApprovalPending', function () {
            scope.init();
            httpBackend.flush();
            scope.setIndex('5f4dd850-c403-11e3-a9c0-71c4281b4208', 0);

            spyOn(productItemService, 'approveProductSuggestion').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.approveProductSuggestion();

            expect(productItemService.approveProductSuggestion).not.toHaveBeenCalled();
            expect(productItemService.clearCache).not.toHaveBeenCalled();

        });

        it('Test 15: rejectProductSuggestion() should delete productItem from scope and call productItemService', function () {
            scope.init();
            httpBackend.flush();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);
            expect(scope.productItems.length).toBe(3);

            spyOn(productItemService, 'rejectProductSuggestion').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();


            scope.rejectProductSuggestion();
            httpBackend.flush();

            expect(productItemService.rejectProductSuggestion).toHaveBeenCalled();
            expect(productItemService.clearCache).toHaveBeenCalled();
            expect(scope.productItems.length).toBe(2);

        });

        it('Test 16: saveItem() should call createProductItem if hgId is undefined and product item is valid and product type is campaign', function () {
            scope.init();
            httpBackend.flush();
            scope.addNew();
            scope.productItems[0] = productItemsJson.getCampaign();

            spyOn(productItemService, 'createProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            httpBackend.flush();

            expect(productItemService.createProductItem).toHaveBeenCalled();
            expect(productItemService.clearCache).toHaveBeenCalled();
        });

        it('Test 17: saveItem() should not call createProductItem if hgId is undefined and product item is not valid and product type is campaign', function () {
            scope.init();
            httpBackend.flush();
            scope.addNew();
            scope.productItems[0] = productItemsJson.getCampaign();
            scope.productItems[0].CampaignItem.FundingGoal = -1;

            spyOn(productItemService, 'createProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            expect(productItemService.createProductItem).not.toHaveBeenCalled();
            expect(productItemService.clearCache).not.toHaveBeenCalled();
        });

        it('Test 18: saveItem() should call updateProductItem if hgId is defined and product type is campaign', function () {
            httpBackend.whenPOST('/svc/ProductItem/UpdateProductItem')
             .respond(200, productItemsJson.getAllCampaignItems()[0]);

            scope.init();
            httpBackend.flush();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);

            spyOn(productItemService, 'updateProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            httpBackend.flush();

            expect(productItemService.updateProductItem).toHaveBeenCalled();
            expect(productItemService.clearCache).toHaveBeenCalled();
        });


        it('Test 19: saveItem() should not call updateProductItem if hgId is defined and product item is not valid and product type is campaign', function () {
            scope.init();
            httpBackend.flush();
            scope.productItems[0] = productItemsJson.getAllCampaignItems()[0];
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4208', 0);
            scope.productItems[0].CampaignItem.FundingGoal = -1;

            spyOn(productItemService, 'updateProductItem').andCallThrough();
            spyOn(productItemService, 'clearCache').andCallThrough();

            scope.saveItem();
            expect(productItemService.updateProductItem).not.toHaveBeenCalled();
            expect(productItemService.clearCache).not.toHaveBeenCalled();
        });

        it('Test 20: DisplaySpecificProduct() should display specific type of product', function () {
            scope.init();
            httpBackend.flush();

            scope.DisplaySpecificProduct('Campaign');
            expect(scope.searchProductType).toBe("Campaign");
        });

        it('Test 21: selectProductType() should select a specific type of product', function () {
            scope.init();
            httpBackend.flush();
            scope.selectedIndex = 2;

            scope.selectProductType('Campaign');
            expect(scope.productItems[scope.selectedIndex].ProductType).toBe("Campaign");
        });

        it('Test 22: on member it should return UserId and MemberId', function () {
            scope.selectedIndex = 0;
            scope.productItems = productItemsJson.suggestNew();
            var Owner = {
                AvatarId : '3cf80a90-9cd2-11e2-a3a4-25024474fe63',
                Id : '9852e220-8840-11e3-8afa-93a5651e7795'
            };
            scope.$broadcast('member', [Owner]);
            expect(scope.productItems[0].Owner.UserId).toBe(Owner.AvatarId);
        });

        it('Test 17: reset() should reset the search fields ', function () {
            scope.advSearch = {
                status : 'Active',
                productType : 'Campaign'
            };
            scope.searchWhat = 'ABC';

            scope.searchProductType = {
                status: 'Active',
                productType: 'Campaign'
            };
            scope.resetSearch();
            expect(scope.searchWhat).toBeFalsy();
            expect(scope.advSearch.status).toBeFalsy();
            expect(scope.advSearch.productType).toBeFalsy();
            expect(scope.searchProductType.status).toBeFalsy();
            expect(scope.searchProductType.productType).toBeFalsy();
        });

        it('Test 18: enableAdvancedSearch() should toggle the advance search feature if scope.advancedSearch is true', function () {
            scope.advancedSearch = true;
            scope.enableAdvancedSearch();
            expect(scope.advancedSearch).toBe(false);
        });

        it('Test 19: enableAdvancedSearch() should toggle the advance search feature if scope.advancedSearch is false', function () {
            scope.advancedSearch = false;
            scope.enableAdvancedSearch();
            expect(scope.advancedSearch).toBe(true);
        });

        it('Test 20: AdvSearch() should set the fields of Filter', function () {
            scope.advSearch.status = 'Active';
            scope.advSearch.productType = '';
            scope.AdvSearch();
            expect(scope.advSearch.status).toBe('Active');
            expect(scope.advSearch.productType).toBe('');
        });
        it('Test 21: toggleRestricted() when type is Department', function () {
            scope.init();
            httpBackend.flush();
            scope.productItems = productItemsJson.getAll();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);
            scope.selectedIndex = 0;
            scope.toggleRestricted('Department');
            expect(scope.productItems[scope.selectedIndex].Accessibility.Departments.length === 0).toBeTruthy();
        });
        it('Test 22: toggleRestricted() when type is location', function () {
            scope.init();
            httpBackend.flush();
            scope.productItems = productItemsJson.getAll();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);
            scope.selectedIndex = 0;
            scope.toggleRestricted('Location');
            expect(scope.productItems[scope.selectedIndex].Accessibility.Locations.length === 0).toBeTruthy();
        });
        it('Test 23: openImageDialog() ', function () {
            scope.productItems = productItemsJson.getAll();
            scope.selectedIndex = 0;
            spyOn(modalSeviceMock, "open").andReturn(returnModel);
            scope.openImageDialog();
            expect(modalSeviceMock.open).toHaveBeenCalled();
            confirmCallBack();
            expect(scope.productItems[scope.selectedIndex].notValidProductImage).toBeFalsy();
        });
        it('Test 24: openRejectDialog()', function () {
            scope.init();
            httpBackend.flush();
            scope.productItems = productItemsJson.getAll();
            scope.setIndex('21f61c10-c403-11e3-a9c0-71c4281b4207', 0);
            scope.selectedIndex = 0;
            spyOn(modalSeviceMock, "open").andReturn(returnModel);
            scope.openRejectDialog();
            expect(modalSeviceMock.open).toHaveBeenCalled();
        });
        it('Test 25: validate()', function () {
            scope.productItems = productItemsJson.getAll();
            scope.selectedIndex = 0;
            scope.validate();
            expect(scope.productItems[scope.selectedIndex].Name.length > 0).toBeTruthy();
        });
    });
});
