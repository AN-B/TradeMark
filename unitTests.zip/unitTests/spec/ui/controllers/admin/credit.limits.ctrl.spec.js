define([
    'unitTests/ui-mocks/group.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (groupJson) {
    describe('Issue Points Controller spec', function () {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            groupAdminSrvc,
            toastrSrvc;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, GroupAdminSrvc, ToastrSrvc) {
            groupAdminSrvc = GroupAdminSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            ctrl = $controller('AdminCreditsLimitsCtrl', {$scope: scope});
            toastrSrvc = ToastrSrvc;

            httpBackend.whenGET('/svc/Group/GetCurrentGroup')
                .respond(200, groupJson.getCurrentGroup());
            httpBackend.whenPOST('/svc/GroupAdmin/SaveCreditSetting')
                .respond(200, 'Credit limits have been updated.');
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it(' 1 controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it(' 2 init should return group info', function () {
            scope.init();
            httpBackend.flush();
            expect(scope.creditLimit.MaxTransfer).toBe(2000);
            expect(scope.creditLimit.MinTransfer).toBe(20);
        });
        it(' 3 submit should set the credit saving', function () {
            scope.init();
            httpBackend.flush();
            spyOn(groupAdminSrvc, 'saveCreditSetting').andCallThrough();
            spyOn(toastrSrvc, 'info').andCallThrough();
            spyOn(rootScope, '$broadcast').andCallThrough();
            scope.submit();
            httpBackend.flush();
            expect(toastrSrvc.info).toHaveBeenCalledWith('Credit limits have been updated.');
            expect(rootScope.$broadcast).toHaveBeenCalledWith('CreditLimitsUpdate');
        });
    });
});