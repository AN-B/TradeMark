define([
    'unitTests/ui-mocks/pointEconomy.templates.json',
    'static/source/hgapp/util/dateUtil',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/autocomplete.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (pointEconomyJson, dateUtil, userCache, autocompleteJson) {
    describe('Issue Points Controller spec', function () {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            pointService,
            userService,
            autoCompleteSrvc,
            pointsToIssueToMember,
            member;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, PointSrvc, UserSrvc, AutoCompleteSrvc) {
            pointService = PointSrvc;
            autoCompleteSrvc = AutoCompleteSrvc;
            userService = UserSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            ctrl = $controller('AdminIssuePointsCtrl', {$scope: scope});
            pointsToIssueToMember = {
                Points: 1,
                valid: true
            };
            member = {
                MemberId: userCache.getCu().hgId,
                IssuePoints: 1
            };

            httpBackend.whenGET('/svc/Point/GetCurrentSnapshot')
                .respond(200, pointEconomyJson.getCurrentSnapshot());
            httpBackend.whenGET('/svc/Point/GetEconomyTimeline?.*').respond(200, []);
            httpBackend.whenGET('/svc/Point/GetEconomyTimeline?.*').respond(200, []);
            httpBackend.whenGET('/svc/User/Login').respond(200, userCache.getCu());
            httpBackend.whenGET('/svc/Member/GetMembersByGroupIdCount')
                .respond(200, pointEconomyJson.getMemberPointsInit().totalCount);

            httpBackend.whenGET('/svc/Member/GetPointMasterMember')
                .respond(200, {hgId: userCache.getCu().hgId, FullName: userCache.getCu().FullName, UserId: userCache.getCu().UserId});

            httpBackend.whenPOST('/svc/Point/MintPoints')
                .respond(200, {});  //empty data for testing
            httpBackend.whenPOST('/svc/Point/Transfer')
                .respond(200, 'Points Issued');
            httpBackend.whenPOST('/svc/Point/IssueToGroup')
                .respond(200, 'Points Issued');
            httpBackend.whenPOST('/svc/AutoComplete/AutoComplete')
                .respond(200, autocompleteJson.getAutoCompleteDataForPointMember());

            UserSrvc.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it(' 1 controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it(' 2 init should set header points and group members', function () {
            var currentSnapshot = pointEconomyJson.getCurrentSnapshot();
            scope.init();
            httpBackend.flush();
            expect(scope.groupMembers.length).toEqual(pointEconomyJson.getMemberPointsInit().groupMembers.length);
            expect(scope.tableProps.totalCount).toBe(pointEconomyJson.getMemberPointsInit().totalCount);
        });

        it(' 3 getNext should get the next page from the table', function () {
            scope.init();
            httpBackend.flush();
            scope.getNext();
            httpBackend.flush();
            expect(scope.tableProps.skip).toBe(10);
        });

        it(' 4 getNext should not get the next page if on the last page', function () {
            scope.init();
            httpBackend.flush();
            spyOn(autoCompleteSrvc, 'autoComplete').andCallThrough();
            scope.tableProps.take = 40; //set to last page
            scope.tableProps.skip = 30; //set to last page
            scope.getNext();
            httpBackend.flush();
            expect(autoCompleteSrvc.autoComplete).toHaveBeenCalled();
            expect(scope.tableProps.skip).toBe(70);
        });

        it(' 5 getPrev should not get the previous page if on the first page', function () {
            scope.init();
            httpBackend.flush();
            spyOn(autoCompleteSrvc, 'autoComplete').andCallThrough();
            scope.getPrev();
            expect(autoCompleteSrvc.autoComplete).not.toHaveBeenCalled();
            expect(scope.tableProps.skip).toBe(0);
        });

        it(' 6 getPrev should get the previous page from the table', function () {
            spyOn(autoCompleteSrvc, 'autoComplete').andCallThrough();
            scope.init();
            httpBackend.flush();
            scope.tableProps.skip = 10; //set to second page
            scope.getPrev();
            httpBackend.flush();
            expect(autoCompleteSrvc.autoComplete).toHaveBeenCalled();
            expect(scope.tableProps.skip).toBe(0);
        });

        it(' 7 mintPoints should mint points and update header points', function () {
            httpBackend.whenGET('/svc/Point/GetEconomyTimeline?.*').respond(200, []);
            spyOn(pointService, 'mintPoints').andCallThrough();
            scope.init();
            httpBackend.flush();
            scope.pointsToMint.Points = 100;
            scope.mintPoints();
            httpBackend.flush();
            expect(pointService.mintPoints).toHaveBeenCalled();
            expect(scope.pointsToMint.Points).toBe(0);
        });

        it(' 8 issuePoints should not do anything if points are 0', function () {
            spyOn(pointService, 'issuePoints').andCallThrough();
            scope.init();
            httpBackend.flush();
            scope.issuePoints(scope.groupMembers[0]);
            expect(pointService.issuePoints).not.toHaveBeenCalled();
        });

        it(' 9 issuePoints should issue points and update table', function () {
            spyOn(pointService, 'issuePoints').andCallThrough();
            scope.init();
            httpBackend.flush();
            scope.groupMembers[0].IssuePoints = 42;
            scope.pointsToIssueToMember.Points = 42;
            scope.issuePoints(scope.groupMembers[0]);
            httpBackend.flush();
            expect(pointService.issuePoints).toHaveBeenCalled();
            expect(scope.groupMembers[0].PointTransfer).toBe(42);
            expect(scope.groupMembers[0].IssuePoints).toBe(0);
        });

        it(' 10 issuePointsToGroup should issue points and update table', function () {
            spyOn(pointService, 'issuePointsToGroup').andCallThrough();
            scope.init();
            httpBackend.flush();
            scope.pointsToIssueToGroup.Points = 42;
            scope.issuePointsToGroup();
            httpBackend.flush();
            expect(pointService.issuePointsToGroup).toHaveBeenCalled();
            expect(scope.pointsToIssueToGroup.Points).toBe(0);
        });
        it(' 11 issuePointsToGroup should fail validation if negative', function () {
            spyOn(pointService, 'issuePointsToGroup').andCallThrough();
            scope.pointsToIssueToGroup.Points = -42;
            scope.issuePointsToGroup();
            expect(pointService.issuePointsToGroup).not.toHaveBeenCalled();
            expect(scope.pointsToIssueToGroup.error).toBeTruthy();
            expect(scope.pointsToIssueToGroup.valid).toBeFalsy();
        });
        it(' 11 issuePointsToGroup should fail validation if negative', function () {
            spyOn(pointService, 'issuePointsToGroup').andCallThrough();
            scope.pointsToIssueToGroup.Points = 'test';
            scope.issuePointsToGroup();
            expect(pointService.issuePointsToGroup).not.toHaveBeenCalled();
        });
        it(' 12 searchMember should set the searched members list', function () {
            scope.init();
            httpBackend.flush();
            spyOn(autoCompleteSrvc, 'autoComplete').andCallThrough();
            scope.searchMember();
            httpBackend.flush();
            expect(scope.tableProps.totalCount).toBe(10);
        });
        it(' 13 validate should validate points', function () {
            scope.validate(pointsToIssueToMember);
            expect(scope.pointsToIssueToMember.valid).toBeTruthy();
        });
        it(' 14 validate should validate points and member', function () {
            scope.validate(pointsToIssueToMember, member);
            expect(scope.pointsToIssueToMember.valid).toBeTruthy();
        });
        it(' 15 changeSort() should sort the order of displayed data if earlier data sorted in ASCENDING ORDER', function () {
            scope.tableProps.sortCol = 'FullName';
            scope.tableProps.sortDir = 'ASC';
            scope.changeSort('FullName');
            httpBackend.flush();
            expect(scope.tableProps.sortDir).toBe('DSC');
            expect(scope.groupMembers.length).toBe(10);
        });
        it(' 16 changeSort() should sort the order of displayed data if earlier data sorted in DESCENDING ORDER', function () {
            scope.tableProps.sortCol = 'FullName';
            scope.tableProps.sortDir = 'DSC';
            scope.changeSort('FullName');
            httpBackend.flush();
            expect(scope.tableProps.sortDir).toBe('ASC');
            expect(scope.groupMembers.length).toBe(10);
        });
        it(' 17 changeSort() should sort the order of displayed data if different column for sorting is chosen, and it is DESCENDING in order', function () {
            scope.tableProps.sortCol = 'RolesInGroup';
            scope.tableProps.sortDir = 'DSC';
            scope.changeSort('FullName');
            httpBackend.flush();
            expect(scope.tableProps.sortCol).toBe('FullName');
            expect(scope.columns['FullName']).toBe('icon-chevron-down');
            expect(scope.groupMembers.length).toBe(10);
        });
        it(' 18 changeSort() should sort the order of displayed data if different column for sorting is chosen, and it is ASCENDING in order', function () {
            scope.tableProps.sortCol = 'RolesInGroup';
            scope.tableProps.sortDir = 'ASC';
            scope.changeSort('FullName');
            httpBackend.flush();
            expect(scope.tableProps.sortCol).toBe('FullName');
            expect(scope.columns['FullName']).toBe('icon-chevron-up');
            expect(scope.groupMembers.length).toBe(10);
        });

    });
});