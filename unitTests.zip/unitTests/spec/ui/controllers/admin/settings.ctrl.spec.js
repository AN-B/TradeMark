define([
    'unitTests/ui-mocks/settings.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(settings, user){

    describe('Admin Settings controller spec ->', function() {
        var scope,
            ctrl,
            timeout,
            backend,
            groupSrvc,
            rootScope,
            toastrSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, GroupSrvc, ToastrSrvc) {
            groupSrvc = GroupSrvc;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            toastrSrvc = ToastrSrvc;
            backend = $injector.get("$httpBackend");
            backend.whenGET('/svc/Group/EditCommentInterval?CommentEditInterval=5')
                .respond(200, 'business.gro.pro.com');
            backend.whenGET('/svc/User/Login')
                .respond(200, user.getCu());
            backend.whenGET('/svc/Group/GetCreditMasterMember')
                .respond(200, {hgId: 'test', FullName: 'test', UserId: 'test'});
            backend.whenGET('/svc/Group/GetTeamTabSettings')
                .respond(200, {});
            backend.whenGET('/svc/Group/GetRecapTimes')
                .respond(200, {});
            backend.whenPOST('/svc/Group/SetCreditMasterMember')
                .respond(200, {CurCreditMasterMember: {hgId: 'bar', FullName: 'foo', UserId: 'bar'}});
            backend.whenPOST('/svc/Group/SetPointMasterMember')
                .respond(200, '');
            backend.whenGET('/svc/Member/GetPointMasterMember')
                .respond(200, {hgId: 'bar', FullName: 'foo', UserId: 'bar'});

            backend.whenGET('/svc/Group/GetCommentIntervalSetting')
                .respond(200, {commentInterval: 300000});
            backend.whenGET('/svc/Group/GetPointMasterMember')
                .respond(200, {hgId: 'test', FullName: 'test', UserId: 'test'});
            scope = $rootScope.$new();
            ctrl = $controller('AdminSettingsCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            backend.verifyNoOutstandingExpectation();
            backend.verifyNoOutstandingRequest();
        });
        it('Test 1 admin settings controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 editCommentInterval() should edit the comment edit interval', function (){
            spyOn(groupSrvc, 'editCommentInterval').andCallThrough();
            spyOn(toastrSrvc, 'success').andCallThrough();
            scope.editCommentInterval(5);
            backend.flush();
            expect(groupSrvc.editCommentInterval).toHaveBeenCalled();
            expect(toastrSrvc.success).toHaveBeenCalledWith('business.gro.pro.com');
        });
        it('Test 3 init should make service request', function (){
            scope.init();
            backend.flush();
            expect(scope.pointsAdmin.autocomplete).toBeDefined();
            expect(scope.creditMaster.autocomplete).toBeDefined();
        });
        it('Test 4 creditMaster onSelect should call backend setCreditMasterMember', function (){
            spyOn(groupSrvc, 'setCreditMasterMember').andCallThrough();
            scope.init();
            backend.flush();
            scope.creditMaster.autocomplete.onSelect({Name: 'test', Id: 'test'});
            backend.flush();
            expect(scope.creditMaster.member.FullName).toBe('test');
            expect(groupSrvc.setCreditMasterMember).toHaveBeenCalled();
        });
        it('Test 5 pointAdmin onSelect should call backend setPointsAdmin', function (){
            spyOn(groupSrvc, 'setPointsAdmin').andCallThrough();
            scope.init();
            backend.flush();
            scope.pointsAdmin.autocomplete.onSelect({Name: 'test', Id: 'test'});
            backend.flush();
            expect(scope.pointsAdmin.member.FullName).toBe('foo');
            expect(groupSrvc.setPointsAdmin).toHaveBeenCalled();

        });
    });
});