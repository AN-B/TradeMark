define([
    'unitTests/ui-mocks/recognition.templates.json',
    'static/source/core/collectionCache',
    'unitTests/ui-mocks/teams.json',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/dto.service.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(templatesJson, cache, teams, userJson, dto){

    describe('Admin Recognitions Achievement controller spec - >', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            location,
            routeParams,
            service,
            recSrvc,
            badgeAdminSrvc,
            modal,
            confirmCallBack,
            returnModel = {
                result: {
                    then: function(test) {
                        confirmCallBack = test;
                    }
                }
            };

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionAdminSrvc, RecognitionSrvc, $modal, BadgeAdminSrvc) {
            modal = $modal;
            service = RecognitionAdminSrvc;
            recSrvc = RecognitionSrvc;
            badgeAdminSrvc = BadgeAdminSrvc;
            location = $injector.get("$location");
            timeout = $injector.get("$timeout");
            routeParams = $injector.get("$routeParams");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/UI/GetAchievementTemplates?Manage=true&skip=0&take=10')
                .respond(200, templatesJson.getAchievement());
            httpBackend.whenPOST('/svc/RecognitionAdmin/SaveTemplate')
                .respond(200, templatesJson.getAchievement()[0]);
            httpBackend.whenPOST('/svc/UI/ValidationTest')
                .respond(200, {valid: true});
            httpBackend.whenPOST('/svc/RecognitionAdmin/DeleteTemplate')
                .respond(200, {});
            httpBackend.whenGET('/svc/Team/GetDepartmentsDTOForAchievement')
                .respond(200, teams.getDepartments());
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/UI/GetMembersAndTeams')
                .respond(200, dto.getRecipients());
            httpBackend.whenGET('/svc/Member/GetMembersCanGiveAchievement')
                .respond(200, dto.getRecipients);
            httpBackend.whenGET('/svc/Recognition/GetTemplateByHgId?id=d0310380-3da8-11e3-8e3f-3b48bfc048fd')
                .respond(200, {});
            scope = $rootScope.$new();
            ctrl = $controller('AdminRecognitionsAchievementCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 Admin Recognitions Achievement controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 init function should call backend', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.templates.length).toBe(3);
        });
        it('Test 3 addLevel function will add empty level to the template[0]', function (){
            scope.init();
            httpBackend.flush();
            scope.selectedIndex = 0;
            expect(scope.templates[scope.selectedIndex].Levels.length).toBe(3);
            scope.addLevel();
            expect(scope.templates[scope.selectedIndex].Levels.length).toBe(4);
        });
        it('Test 4 removeLevel will remove level from the template[0]', function (){
            scope.init();
            httpBackend.flush();
            scope.selectedIndex = 0;
            expect(scope.templates[scope.selectedIndex].Levels.length).toBe(3);
            scope.removeLevel(0);
            expect(scope.templates[scope.selectedIndex].Levels.length).toBe(2);
        });
        it('Test 5 setIndex will set scope.selectedIndex to 0 when 0 is passed', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.selectedIndex).toBeUndefined();
            scope.setIndex(0);
            expect(scope.selectedIndex).toBe(0);
        });

        it('Test 6 should add new record to the templates object', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.templates.length).toBe(3);
            expect(scope.templates[0].hgId).toBeDefined();
            scope.addNew();
            expect(scope.templates.length).toBe(4);
            expect(scope.templates[0].hgId).not.toBeDefined();
        });
        it('Test 7 clear should clear selectedIndex and clear new item', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            expect(scope.templates.length).toBe(4);
            expect(scope.templates[0].hgId).not.toBeDefined();
            expect(scope.selectedIndex).toBe(0);
            scope.clear(0);
            expect(scope.templates.length).toBe(3);
            expect(scope.templates[0].hgId).toBeDefined();
            expect(scope.selectedIndex).toBeFalsy();
        });
        it('Test 8 toggleLevels should remove or add levels to template Levels object', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            expect(scope.templates[0].Levels.length).toBe(0);
            scope.toggleLevels();
            expect(scope.templates[0].Levels.length).toBe(1);
            scope.toggleLevels();
            expect(scope.templates[0].Levels.length).toBe(0);
        });
        it('Test 9 save should call saveTemplate if template is valid', function (){
            spyOn(service, 'saveTemplate').andCallThrough();
            scope.save(templatesJson.getAchievement()[0]);
            httpBackend.flush();
            expect(service.saveTemplate).toHaveBeenCalled();
        });
        it('Test 10 save should not call saveTemplate if template is invalid', function (){
            spyOn(service, 'saveTemplate').andCallThrough();
            spyOn(scope, 'clear').andCallThrough();
            scope.save({Levels: []});
            expect(service.saveTemplate).not.toHaveBeenCalled();
            expect(scope.clear).not.toHaveBeenCalled();
        });
        it('Test 11 validate should validate invalid selected template', function (){
            scope.init();
            httpBackend.flush();
            scope.selectedIndex = 0;
            scope.templates[scope.selectedIndex].Title = "";
            scope.validate();
            expect(scope.templates[scope.selectedIndex].notValid).toBeTruthy();
        });
        it('Test 12 validate should not actually validate new templates while being filled', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            scope.templates[scope.selectedIndex].Title = "blah";
            scope.validate();
            expect(scope.templates[scope.selectedIndex].notValid).toBeFalsy();
        });
        it('Test 13 validate should validate valid selected template', function (){
            scope.init();
            httpBackend.flush();
            scope.selectedIndex = 0;
            scope.validate();
            expect(scope.templates[scope.selectedIndex].notValid).toBeFalsy();
        });
        it('Test 14 clear should delete new template', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            expect(scope.templates[0].hgId).not.toBeDefined();
            scope.clear(0);
            expect(scope.templates[0].hgId).toBeDefined();
        });

        it('Test 15 clear should restore from cache existing template', function (){
            scope.init();
            httpBackend.flush();
            scope.selectedIndex = 0;
            spyOn(recSrvc, 'getTemplateByHgId').andCallThrough();
            scope.toggleLevels();
            expect(scope.templates[scope.selectedIndex].Levels.length).toBe(0);
            scope.clear(0);
            httpBackend.flush();
            expect(recSrvc.getTemplateByHgId).toHaveBeenCalled();
        });
        it('Test 16 deleteTemplate() should delete template from the scope templates and should call service', function (){
            scope.searchMeta = {meta: []};
            scope.init();
            httpBackend.flush();
            spyOn(service, 'deleteTemplate').andCallThrough();
            expect(scope.templates[0].hgId).toBe('d0310380-3da8-11e3-8e3f-3b48bfc048fd');
            scope.deleteTemplate(0);
            httpBackend.flush();
            expect(service.deleteTemplate).toHaveBeenCalledWith({TemplateId: 'd0310380-3da8-11e3-8e3f-3b48bfc048fd'});
            expect(scope.templates[0].hgId).not.toBe('d0310380-3da8-11e3-8e3f-3b48bfc048fd');
        });
        it('Test 17 deleteTemplate() should delete template from the scope templates and should not call service', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            spyOn(service, 'deleteTemplate').andCallThrough();
            spyOn(recSrvc, 'clearRecognitionTemplateCache').andCallThrough();
            expect(scope.templates[0].hgId).toBeFalsy();
            scope.deleteTemplate(0);
            expect(service.deleteTemplate).not.toHaveBeenCalled();
            expect(recSrvc.clearRecognitionTemplateCache).not.toHaveBeenCalled();
            expect(scope.templates[0].hgId).toBe('d0310380-3da8-11e3-8e3f-3b48bfc048fd');
        });
        it('Test 18 spec for openBackgroundImageDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openBackgroundImageDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
            confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
            expect(scope.templates[scope.selectedIndex].BackgroundBadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
        });
        it('Test 19 spec for openBadgeDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openBadgeDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
            confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
            expect(scope.templates[scope.selectedIndex].BadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
        });
        it('Test 20 setIndex should call setRestrictedUsers and setRestrictedDepartments', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.selectedIndex).toBeUndefined();
            scope.setIndex(0);
            expect(scope.selectedIndex).toBe(0);
            expect(scope.templates[scope.selectedIndex].restrictDepartments).toBeTruthy();
        });
		it('Test 21 setIndex should without RestrictUsers ', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.selectedIndex).toBeUndefined();
			scope.setIndex(1);
			expect(scope.selectedIndex).toBe(1);
			expect(scope.templates[scope.selectedIndex].restrictUser).toBeTruthy();
		});
        it('Test 22 spec for openSvgPartColorDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openSvgPartColorDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
        });
        it('Test 23 spec for openSvgPartColorDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openSvgPartColorDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
        });
        it('Test 24 toggleRestrictedUsers should not initialize search.memberSearch', function () {
            var template = scope.toggleRestrictedUsers({RestrictUsers: {}});
            expect(template.restrictRoles).toBeDefined();
            expect(scope.search.memberSearch).toBeDefined();
        });
        it('Test 25 toggleRestrictedUsers should initialize search.memberSearch', function () {
            var template = scope.toggleRestrictedUsers({restrictUser: true, RestrictUsers: {MemberIds: []}});
            expect(template.restrictRoles).toBeDefined();
            expect(scope.search.memberSearch).toBeDefined();
        });
        it('Test 26 toggleRestrictedDpt should not initialize search.departmentSearch', function () {
            var template = scope.toggleRestrictedDpt({});
            expect(scope.search.departmentSearch).toBeDefined();
        });
        it('Test 27 toggleRestrictedDpt should initialize search.departmentSearch', function () {
            var template = scope.toggleRestrictedDpt({restrictDepartments: true, RestrictDepartments: []});
            expect(scope.search.departmentSearch).toBeDefined();
        });
        it('Test 28 toggleRole should add selected role to restricted roles array ', function () {
            scope.templates[0] = {RestrictUsers: {Roles: []}};
            scope.selectedIndex = 0;
            scope.toggleRole({text:'test', selected: true});
            expect(scope.templates[0].RestrictUsers.Roles[0]).toBe('test');
        });
        it('Test 29 toggleRole should remove diselected role from restricted roles array ', function () {
            scope.templates[0] = {RestrictUsers: {Roles: ['test']}};
            scope.selectedIndex = 0;
            scope.toggleRole({text:'test'});
            expect(scope.templates[0].RestrictUsers.Roles.length).toBe(0);
        });
        it('Test 30 should select and deselect restricted user', function () {
            scope.init();
            httpBackend.flush();
            scope.templates[0].RestrictUsers.MemberIds = [];
            scope.setIndex(0);
            scope.search.memberSearch.onSelect({Id: 'test', Type: 'Member'});
            expect(scope.templates[0].RestrictUsers.MemberIds[0]).toBe('test');
            scope.search.memberSearch.deSelect({Id: 'test', Type: 'Member'});
            expect(scope.templates[0].RestrictUsers.MemberIds.length).toBe(0);
        });
        it('Test 31 should select and deselect restricted team', function () {
            scope.init();
            httpBackend.flush();
            scope.setIndex(0);
            scope.templates[0].RestrictUsers.TeamIds = [];
            scope.search.memberSearch.onSelect({Id: 'test'});
            expect(scope.templates[0].RestrictUsers.TeamIds[0]).toBe('test');
            scope.search.memberSearch.deSelect({Id: 'test'});
            expect(scope.templates[0].RestrictUsers.TeamIds.length).toBe(0);
        });
        it('Test 32 should select and deselect restricted department', function () {
            scope.init();
            httpBackend.flush();
            scope.setIndex(0);
            scope.templates[0].RestrictDepartments = [];
            scope.search.departmentSearch.onSelect({Id: 'test', Name: 'test'});
            expect(scope.templates[0].RestrictDepartments[0].Id).toBe('test');
            scope.search.departmentSearch.deSelect({Id: 'test'});
            expect(scope.templates[0].RestrictDepartments.length).toBe(0);
        });

    });
});
