define([
    'unitTests/ui-mocks/settings.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(settings, user){

    describe('Admin Settings Languages controller spec ->', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            groupSrvc,
            rootScope;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, GroupSrvc) {
            groupSrvc = GroupSrvc;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, user.getCu());
            scope = $rootScope.$new();
            ctrl = $controller('AdminSettingsLanguageCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 admin settings language controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 init() should initilize', function (){
            httpBackend.whenGET('/svc/Group/GetLanguageSetting')
                .respond(200, settings.getLanguages());
            spyOn(groupSrvc, 'getLanguageSettings').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(groupSrvc.getLanguageSettings).toHaveBeenCalled();
            expect(scope.languageSettings.SupportedLanguages).toBeDefined();
            expect(scope.languageSettings.DefaultLanguage).toBeDefined();
        });
        it('Test 3 saveLanguageSettings() should save', function (){
            httpBackend.whenPOST('/svc/Group/SaveLanguageSettings')
                .respond(200, []);
            spyOn(groupSrvc, 'saveLanguageSettings').andCallThrough();
            scope.languageSettings = settings.getLanguages();
            scope.saveLanguageSettings();
            httpBackend.flush();
            expect(groupSrvc.saveLanguageSettings).toHaveBeenCalled();
        });
    });
});