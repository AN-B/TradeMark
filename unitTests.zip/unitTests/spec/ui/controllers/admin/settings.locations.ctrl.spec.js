define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/locations.templates.json',
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/timezones.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, locationsJson, groupJson, timezonesJson){

    describe('Settings Locations Controller spec -> ', function() {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            userService,
            groupService,
            teamService;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, GroupSrvc, TeamSrvc) {

            userService = UserSrvc;
            groupService = GroupSrvc;
            teamService = TeamSrvc;
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            ctrl = $controller('AdminSettingsLocationsCtrl', {$scope: scope});

            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Team/GetLocationsForGroup?skip=0&take=10')
                .respond(200, locationsJson.getAll());
            httpBackend.whenGET('/svc/GroupAdmin/GetTimeZonesByCountry?country=United+States')
                .respond(200, timezonesJson.getAll());
            httpBackend.whenGET('/svc/Group/GetCurrentGroup')
                .respond(200, groupJson.getCurrentGroup());
            httpBackend.whenPOST('/svc/Team/DeleteLocation')
                .respond(200, '');
            httpBackend.whenPOST('/svc/Team/SaveLocation')
                .respond(200, '');

        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('init() should call backend', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                    callback(true);
                });
            scope.init();
            httpBackend.flush();
            expect(permissionSpy).toHaveBeenCalled();
            expect(scope.locations.length).toBe(3);
        });

        it('setSelected will set scope.model.selectedIndex', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            });
            scope.init();
            httpBackend.flush();
            scope.locations = locationsJson.getAll();
            expect(scope.model.selectedIndex).toBeUndefined();
            scope.setSelected(0);
            httpBackend.flush();
            expect(scope.model.selectedIndex).toBe(0);
        });

        it('addNew() should add new location to locations array', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            });
            scope.init();
            httpBackend.flush();
            expect(scope.locations.length).toBe(3);
            expect(scope.locations[0].Id).toBeDefined();
            scope.addNew();
            expect(scope.model.selectedIndex).toBe(0);
            expect(scope.locations.length).toBe(4);
            expect(scope.locations[0].Id).not.toBeDefined();
        });

        it('clear() should clear selectedIndex', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            });
            scope.init();
            httpBackend.flush();
            scope.addNew();
            expect(scope.locations.length).toBe(4);
            expect(scope.locations[0].Id).not.toBeDefined();
            expect(scope.model.selectedIndex).toBe(0);
            scope.clear();
            expect(scope.locations.length).toBe(3);
            expect(scope.locations[0].Id).toBeDefined();
            expect(scope.model.selectedIndex).toBeFalsy();
        });

        it('isUS() should set outsideUS bool false when country = United States and is the default when new location created', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            });
            scope.init();
            httpBackend.flush();
            scope.setSelected(1);
            httpBackend.flush();
            scope.isUS();
            expect(scope.locations[scope.model.selectedIndex].outsideUS).toBeFalsy(true);
            expect(scope.locations[scope.model.selectedIndex].Address.Country).toBe('United States');
            scope.addNew();
            scope.isUS();
            expect(scope.locations[scope.model.selectedIndex].outsideUS).toBeFalsy(true);
            expect(scope.locations[scope.model.selectedIndex].Address.Country).toBe('United States');
        });

        it('saveLocation() should call saveLocation if form is valid', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            });
            scope.init();
            httpBackend.flush();
            spyOn(teamService, 'saveLocation').andCallThrough();
            scope.model.selectedIndex = 0;
            scope.saveLocation();
            httpBackend.flush();
            expect(teamService.saveLocation).toHaveBeenCalled();
        });

        it('saveLocation() should NOT call saveLocation if form is invalid', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            });
            scope.init();
            httpBackend.flush();
            spyOn(teamService, 'saveLocation').andCallThrough();
            scope.addNew();
            scope.saveLocation();
            expect(teamService.saveLocation).not.toHaveBeenCalled();
        });

        it('getSearchResults() should call getLocations', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            }),
                search = 'Los Angeles';
            httpBackend.whenGET('/svc/Team/GetLocationsForGroup?search=Los+Angeles&skip=0&take=10')
                .respond(200, locationsJson.getAll().objectIndexOf(search, 'Name'));
            scope.init();
            spyOn(teamService, 'getLocations').andCallThrough();
            scope.getSearchResults('Los Angeles');
            httpBackend.flush();
            expect(scope.search.Name).toBe('Los Angeles');
            expect(teamService.getLocations).toHaveBeenCalledWith({search: search, skip: 0, take: 10});
        });

        it('deleteLocation should remove from locations list and call teamService', function () {
            var permissionSpy = spyOn(userService, 'hasPermission').andCallFake(function (tabGroupName, permissionName, callback) {
                callback(true);
            });
            scope.init();
            spyOn(teamService, 'deleteLocation').andCallThrough();
            scope.deleteLocation('ee1a2970-b166-11e4-9db4-71495aeb6a35', 2);
            httpBackend.flush();
            expect(teamService.deleteLocation).toHaveBeenCalled();
        });
    });
});
