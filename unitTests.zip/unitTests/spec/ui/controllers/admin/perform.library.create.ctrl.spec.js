define([
    'unitTests/ui-mocks/perform.card.edit.json',
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (cardJson, groupJson, userJson) {

    describe('Perform card library create controller spec', function () {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            rootScope,
            PerformAdminService,
            userService;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, PerformAdminSrvc, UserSrvc) {
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            PerformAdminService = PerformAdminSrvc;
            userService = UserSrvc;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET("/svc/Performance/GetCardByIdForBuilder?cardId=")
                .respond(200, cardJson.get());
            httpBackend.whenGET('/svc/Group/GetCurrentGroupMembers?status=Active&es=false')
                .respond(200, groupJson.getCurrentGroupMembers());
            scope = $rootScope.$new();
            ctrl = $controller('PerformLibraryCreateCtrl', {$scope: scope});

            httpBackend.whenPOST('/svc/Performance/SaveCard')
                .respond(200, {});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 Perform card library create controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 init() should call backend', function () {
            spyOn(userService, 'getUser').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
        });
        it('Test 3 perform card validation', function () {
            spyOn(PerformAdminService, 'saveCard').andCallThrough();
            scope.card = cardJson.validateCard();
            scope.saveCard();
            httpBackend.flush();
            expect(PerformAdminService.saveCard).toHaveBeenCalledWith(scope.card);
        });
    });
});
