define([
    'unitTests/ui-mocks/settings.json',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/profanity.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (settings, user, profanity) {

    describe('Admin Settings Profanity controller spec ->', function() {
        var scope,
            ctrl,
            httpBackend,
            groupSrvc,
            profanitySrvc,
            rootScope;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, GroupSrvc, ProfanitySrvc) {
            groupSrvc = GroupSrvc;
            profanitySrvc = ProfanitySrvc;
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, user.getCu());
            scope = $rootScope.$new();
            ctrl = $controller('AdminSettingsProfanityCtrl', {
                $scope: scope,
                mode: 'admin',
                ptabs: function () { return null; },
                pAdminService: ['ProfanitySrvc',
                    function (ProfanitySrvc){
                        return ProfanitySrvc;
                    }]
            });
            scope.PService = ProfanitySrvc;
            httpBackend.whenGET('/svc/Group/GetLanguageSetting')
                .respond(200, settings.getLanguages());
            httpBackend.whenGET('/svc/Profanity/GetGroupBannedWords?lang=en&skip=0&take=20')
                .respond(200, profanity.getBannedWords());
            httpBackend.whenGET('/svc/Profanity/GetGroupBannedWords?lang=en&searchTerm=crap&skip=0&take=20')
                .respond(200, profanity.getBannedWords())

            httpBackend.whenPOST('/svc/Profanity/ExcludeGroupBannedWord')
                .respond(200, '');
            httpBackend.whenPOST('/svc/Profanity/SaveGroupBannedWord')
                .respond(200, '');
            httpBackend.whenGET('/svc/Profanity/GetGroupBannedWords?lang=pt-br&skip=0&take=20')
                .respond(200, []);
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 admin settings profanity controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2 init() should initilize', function () {
            spyOn(groupSrvc, 'getLanguageSettings').andCallThrough();
            spyOn(profanitySrvc, 'getBannedWords').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(groupSrvc.getLanguageSettings).toHaveBeenCalled();
            expect(profanitySrvc.getBannedWords).toHaveBeenCalled();
            expect(scope.languages).toBeDefined();
        });
        it('Test 3 addNew() should add a new word entry', function () {
            scope.init();
            httpBackend.flush();
            expect(scope.words.length).toBe(4);
            expect(scope.words[0].hgId).toBeDefined();
            scope.addNew();
            expect(scope.model.selectedIndex).toBe(0);
            expect(scope.words.length).toBe(5);
            expect(scope.words[0].hgId).not.toBeDefined();
        });
        it('Test 4 setSelected() should set model.selectedIndex', function () {
            scope.init();
            httpBackend.flush();
            expect(scope.model.selectedIndex).toBeUndefined();
            scope.setSelected('87eb8f01-c862-11e5-ba42-df2774c46c91', 0);
            expect(scope.model.selectedIndex).toBe(0);
        });
        it('Test 5 clear() should clear selectedIndex', function () {
            scope.init();
            httpBackend.flush();
            scope.addNew();
            expect(scope.words.length).toBe(5);
            expect(scope.words[0].hgId).not.toBeDefined();
            expect(scope.model.selectedIndex).toBe(0);
            scope.clear();
            expect(scope.words.length).toBe(4);
            expect(scope.words[0].hgId).toBeDefined();
            expect(scope.model.selectedIndex).toBeFalsy();
        });
        it('Test 6 removeWord() should remove selected word', function () {
            spyOn(profanitySrvc, 'excludeBannedWord').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.words.length).toBe(4);
            scope.removeWord('87eb8f01-c862-11e5-ba42-df2774c46c91', 0);
            httpBackend.flush();
            expect(profanitySrvc.excludeBannedWord).toHaveBeenCalled();
            expect(scope.words.length).toBe(3);
        });
        it('Test 7 saveWord() should not call saveBannedWord', function () {
            scope.init();
            httpBackend.flush();
            spyOn(profanitySrvc, 'saveBannedWord').andCallThrough();
            scope.addNew();
            scope.saveWord();
            expect(profanitySrvc.saveBannedWord).not.toHaveBeenCalled();
        });
        it('Test 8 langChanged() should switch language and search', function () {
            scope.init();
            httpBackend.flush();
            spyOn(profanitySrvc, 'getBannedWords').andCallThrough();
            scope.model.lang = 'pt-br';
            scope.langChanged();
            httpBackend.flush();
            expect(scope.words.length).toBe(0);
            expect(profanitySrvc.getBannedWords).toHaveBeenCalled();
        });
        it('Test 9 Search for a word', function () {
            scope.init();
            httpBackend.flush();
            scope.model.searchTerm = 'crap';
            httpBackend.whenGET('/svc/Profanity/GetGroupBannedWords?lang=en&searchTerm=crap&skip=0&take=10')
                .respond(200, profanity.getBannedWords());
            spyOn(profanitySrvc, 'getBannedWords').andCallThrough();
            httpBackend.flush();
            expect(profanitySrvc.getBannedWords).toHaveBeenCalledWith({searchTerm : 'crap', lang : 'en', skip : 0});
        });
    });
});