define(['unitTests/ui-mocks/survey.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (surveyJson, userJson) {
    describe('Admin Survey Pulse Template Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            surveySrvc,
            userSrvc,
            compile,
            timeout;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, $compile, SurveySrvc, UserSrvc) {
            surveySrvc = SurveySrvc;
            userSrvc = UserSrvc;
            rootScope = $rootScope;
            compile = $compile;
            timeout = $injector.get('$timeout');
            httpBackend = $injector.get('$httpBackend');
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Survey/GetGroupPulseSurveyTemplate')
                .respond(200, surveyJson.getGroupPulseSurveyTemplate());
            httpBackend.whenPOST('/svc/Survey/SaveGroupPulseSurveyTemplate')
                .respond(200, {test: 'test'});
            UserSrvc.clearUserCache();
            scope = $rootScope.$new();
            ctrl = $controller('AdminSurveyPulseTemplateCtrl', {$scope: scope});
            scope.pulseSurvey = surveyJson.getGroupPulseSurveyTemplate();
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Admin Survey Pulse Template controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: should set scope.flags and scope.pulseSurvey', function (){
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.flags).toBeDefined();
            expect(scope.pulseSurvey).toBeDefined();
        });
        it('Test 3: should successfully save pulse survey', function () {
            spyOn(surveySrvc, 'saveGroupPulseSurveyTemplate').andCallThrough();
            scope.savePulseSurvey();
            httpBackend.flush();
            expect(surveySrvc.saveGroupPulseSurveyTemplate).toHaveBeenCalled();
        });
    });
});
