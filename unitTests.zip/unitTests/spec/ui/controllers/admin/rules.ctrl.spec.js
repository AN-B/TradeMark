define([
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson){

    describe('Rules Admin controller spec', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            rootScope,
            rulesEngineService,
            userSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, RulesEngineSrvc, UserSrvc) {
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            rulesEngineService = RulesEngineSrvc;
            userSrvc = UserSrvc;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/RulesEngine/GetRules').respond(200,{});
            httpBackend.whenPOST('/svc/RulesEngine/SaveRule').respond(200,{});
            httpBackend.whenPOST('/svc/RulesEngine/ArchiveRule').respond(200,{});
            httpBackend.whenGET('/svc/RulesEngine/GetAvailableSubjectTypes').respond(200, []);
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/RulesEngine/GetRulesEngineEventTypes').respond(200, []);
            scope = $rootScope.$new();
            UserSrvc.clearUserCache();
            ctrl = $controller('AdminRulesCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Rules Admin controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 1 should call init()', function (){
            spyOn(rulesEngineService, 'getRules').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(scope.rules).toBeDefined();
            expect(rulesEngineService.getRules).toHaveBeenCalled();
        });
        it('Test 2 should call addNew() ', function (){
            scope.search = {locationMeta: {}, departmentMeta: {}};
            scope.rules = [];
            scope.addNew();
            expect(scope.rules.length).toBe(1);
        });
        it('Test 3 should call save() ', function (){
            scope.rules = [{
                RuleName : 'test 123',
                Description : 'test 123',
                DeltaType : 'CountUp',
                DeltaValue : 'ActualValue',
                ResetInterval : 'None',
                AllowedInterval : 'None',
                StartDate : 123456,
                Status : 'Active',
                EventType : 'SalesRevenueMade',
                TriggerTiming : 'Immediate',
                SubjectType: 'type',
                TriggerConditions : [{
                    hgId : '',
                    Min : 0,
                    Max : 20,
                    RecognitionTemplateId : '123',
                    Level : 'Level'
                }]
            }];
            scope.selectedIndex = 0;
            spyOn(rulesEngineService, 'saveRule').andCallThrough();
            scope.save();
            httpBackend.flush();
            expect(rulesEngineService.saveRule).toHaveBeenCalled();
        });
        it('Test 4 should call deleteRule() ', function (){
            scope.rules = [{
                hgId: '123',
                RuleName : 'test 123',
                Description : 'test 123',
                DeltaType : 'CountUp',
                DeltaValue : 'ActualValue',
                ResetInterval : 'None',
                AllowedInterval : 'None',
                StartDate : 123456,
                Status : 'Active',
                EventType : 'SalesRevenueMade',
                TriggerTiming : 'Immediate',
                TriggerConditions : [{
                    hgId : '',
                    Min : 0,
                    Max : 20,
                    RecognitionTemplateId : '123',
                    Level : 'Level'
                }]
            }];
            spyOn(rulesEngineService, 'deleteRule').andCallThrough();
            scope.deleteRule(0);
            httpBackend.flush();
            expect(scope.rules.length).toBe(0);
        });
        it('Test 5 should call validate() ', function (){
            scope.rules = [{
                RuleName : 'test 123',
                Description : 'test 123',
                DeltaType : 'CountUp',
                DeltaValue : 'ActualValue',
                ResetInterval : 'None',
                AllowedInterval : 'None',
                StartDate : 123456,
                Status : 'Active',
                EventType : 'SalesRevenueMade',
                TriggerTiming : 'Immediate',
                SubjectType: 'type',
                TriggerConditions : [{
                    hgId : '',
                    Min : 0,
                    Max : 20,
                    RecognitionTemplateId : '123',
                    Level : 'Level'
                }]
            }];
            scope.selectedIndex = 0;
            scope.validate();
            expect(scope.rules[scope.selectedIndex].notValid).toBeFalsy();
        });
    });
});