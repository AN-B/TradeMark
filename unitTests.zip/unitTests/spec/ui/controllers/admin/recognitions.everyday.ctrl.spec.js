define([
	'unitTests/ui-mocks/user.json',
	'unitTests/ui-mocks/recognition.templates.json',
	'static/source/core/collectionCache',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(userJson, templatesJson, cache){

	describe('Admin Recognitions Everyday controller spec - >', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			location,
			routeParams,
			service,
            badgeAdminSrvc,
			recSrvc,
			modal,
			confirmCallBack,
			returnModel = {
				result: {
					then: function(test) {
						confirmCallBack = test;
					}
				}
			};

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionAdminSrvc, RecognitionSrvc, $modal, BadgeAdminSrvc) {
			service = RecognitionAdminSrvc;
			recSrvc = RecognitionSrvc;
            badgeAdminSrvc = BadgeAdminSrvc;
			modal = $modal;
			location = $injector.get("$location");
			timeout = $injector.get("$timeout");
			routeParams = $injector.get("$routeParams");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
			httpBackend.whenGET('/svc/Recognition/GetEverydayTemplates?skip=0&take=10')
				.respond(200, templatesJson.getEveryday());
			httpBackend.whenPOST('/svc/RecognitionAdmin/SaveTemplate')
				.respond(200, templatesJson.getEveryday()[0]);
			httpBackend.whenPOST('/svc/RecognitionAdmin/DeleteTemplate')
				.respond(200, {});
            httpBackend.whenGET('/svc/Recognition/GetTemplateByHgId?id=a96e6030-3da8-11e3-8e3f-3b48bfc048fd')
                .respond(200, {});
			scope = $rootScope.$new();
			ctrl = $controller('AdminRecognitionsEverydayCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 Admin Recognitions Achievement controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
		it('Test 2 init function should call backend', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.templates.length).toBe(2);
		});
		it('Test 3 setIndex will set scope.selectedIndex to 0 when 0 is passed', function (){
			expect(scope.selectedIndex).toBeUndefined();
			scope.templates = [{
				ForeGroundBadgeUrl: ''
			}];
			scope.setIndex(0);
			expect(scope.selectedIndex).toBe(0);
		});

		it('Test 4 should add new record to the templates object', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.templates.length).toBe(2);
			expect(scope.templates[0].hgId).toBeDefined();
			scope.addNew();
			expect(scope.templates.length).toBe(3);
			expect(scope.templates[0].hgId).not.toBeDefined();
		});
		it('Test 5 clear should clear selectedIndex and clear new item', function (){
			scope.init();
			httpBackend.flush();
			scope.addNew();
			expect(scope.templates.length).toBe(3);
			expect(scope.templates[0].hgId).not.toBeDefined();
			expect(scope.selectedIndex).toBe(0);
			scope.clear(0);
			expect(scope.templates.length).toBe(2);
			expect(scope.templates[0].hgId).toBeDefined();
			expect(scope.selectedIndex).toBeFalsy();
		});
		it('Test 6 save should call saveTemplate if template is valid', function (){
			scope.init();
			httpBackend.flush();
			scope.selectedIndex = 0;
			spyOn(service, 'saveTemplate').andCallThrough();
			scope.save();
			httpBackend.flush();
			expect(service.saveTemplate).toHaveBeenCalled();
		});
		it('Test 7 save should not call saveTemplate if template is invalid', function (){
			scope.init();
			httpBackend.flush();
			scope.addNew();
			spyOn(service, 'saveTemplate').andCallThrough();
			spyOn(scope, 'clear').andCallThrough();
			scope.save();
			expect(service.saveTemplate).not.toHaveBeenCalled();
			expect(scope.clear).not.toHaveBeenCalled();
		});
		it('Test 8 validate should validate invalid selected template', function (){
			scope.init();
			httpBackend.flush();
            scope.selectedIndex = 0;
            scope.templates[scope.selectedIndex].Title = "";
			scope.validate();
			expect(scope.templates[scope.selectedIndex].notValid).toBeTruthy();
		});
        it('Test 9 validate should not actually validate new templates while being filled', function (){
            scope.init();
            httpBackend.flush();
            scope.addNew();
            scope.templates[scope.selectedIndex].Title = "blah";
            scope.validate();
            expect(scope.templates[scope.selectedIndex].notValid).toBeFalsy();
        });
		it('Test 10 validate should validate valid selected template', function (){
			scope.init();
			httpBackend.flush();
			scope.selectedIndex = 0;
			scope.validate();
			expect(scope.templates[scope.selectedIndex].notValid).toBeFalsy();
		});
		it('Test 11 clear should delete new template', function (){
			scope.init();
			httpBackend.flush();
			scope.addNew();
			expect(scope.templates[0].hgId).not.toBeDefined();
			scope.clear(0);
			expect(scope.templates[0].hgId).toBeDefined();
		});
		it('Test 12 clear should restore from cache existing template', function (){
			scope.init();
            httpBackend.flush();
			spyOn(recSrvc, 'getTemplateByHgId').andCallThrough();
			scope.clear(0);
            httpBackend.flush();
			expect(recSrvc.getTemplateByHgId).toHaveBeenCalled();
		});
		it('Test 13 deleteTemplate() should delete template from the scope templates and should call service', function (){
			scope.init();
			httpBackend.flush();
			spyOn(service, 'deleteTemplate').andCallThrough();
			expect(scope.templates[0].hgId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc048fd');
			scope.deleteTemplate(0);
			httpBackend.flush();
			expect(service.deleteTemplate).toHaveBeenCalledWith({TemplateId: 'a96e6030-3da8-11e3-8e3f-3b48bfc048fd'});
			expect(scope.templates[0].hgId).not.toBe('a96e6030-3da8-11e3-8e3f-3b48bfc048fd');
		});
		it('Test 14 deleteTemplate() should delete template from the scope templates and should not call service', function (){
			scope.init();
			httpBackend.flush();
			scope.addNew();
			spyOn(service, 'deleteTemplate').andCallThrough();
			spyOn(recSrvc, 'clearRecognitionTemplateCache').andCallThrough();
			expect(scope.templates[0].hgId).toBeFalsy();
			scope.deleteTemplate(0);
			expect(service.deleteTemplate).not.toHaveBeenCalled();
			expect(recSrvc.clearRecognitionTemplateCache).not.toHaveBeenCalled();
			expect(scope.templates[0].hgId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc048fd');
		});
		it('Test 15 clear should get the templates', function (){
			scope.templates = [{
				hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc048fd'
			}];
			scope.selectedIndex = 0;
			spyOn(recSrvc, 'getTemplateByHgId').andCallThrough();
			scope.clear(0);
			httpBackend.flush();
			expect(recSrvc.getTemplateByHgId).toHaveBeenCalled();
		});
		it('Test 16 spec for openBadgeDialog', function () {
			scope.selectedIndex = 0;
			scope.init();
			spyOn(modal, 'open').andReturn(returnModel);
			scope.openBadgeDialog();
			httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
			confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
			expect(scope.templates[scope.selectedIndex].BadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
		});
		it('Test 17 spec for openBackgroundImageDialog', function () {
			scope.selectedIndex = 0;
			scope.init();
			spyOn(modal, 'open').andReturn(returnModel);
			scope.openBackgroundImageDialog();
			httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
			confirmCallBack({hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123', Filename: 'badgeFile'});
			expect(scope.templates[scope.selectedIndex].BackgroundBadgeId).toBe('a96e6030-3da8-11e3-8e3f-3b48bfc04123');
		});
		it('Test 18 broadcast cacheEveryday', function () {
			var data = {
				hgId : 'a96e6030-3da8-11e3-8e3f-3b48bfc04123'
			};
			scope.templates = [{
				hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc04123'
			}];
			scope.$broadcast('cacheEveryday', data);
			expect(data.hgId).toBe(scope.templates[0].hgId);
		});
        it('Test 19 spec for openSvgPartColorDialog', function () {
            scope.selectedIndex = 0;
            scope.init();
            spyOn(modal, 'open').andReturn(returnModel);
            scope.openSvgPartColorDialog();
            httpBackend.flush();
            expect(modal.open).toHaveBeenCalled();
        });
	});
});
