define([
    'unitTests/ui-mocks/pointEconomy.templates.json',
    'static/source/hgapp/util/dateUtil',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/autocomplete.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (pointEconomyJson, dateUtil, userCache, autocompleteJson) {
    describe('Points Economy Controller spec', function () {
        var scope,
            ctrl,
            rootScope,
            httpBackend,
            pointService,
            userService,
            autoCompleteSrvc,
            q;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, PointSrvc, UserSrvc, AutoCompleteSrvc) {
            pointService = PointSrvc;
            autoCompleteSrvc = AutoCompleteSrvc;
            userService = UserSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            q = $injector.get('$q');
            ctrl = $controller('AdminPointsEconomyCtrl', {$scope: scope});

            httpBackend.whenGET('/svc/Point/GetCurrentSnapshot')
                .respond(200, pointEconomyJson.getCurrentSnapshot());
            httpBackend.whenGET('/svc/User/Login').respond(200, userCache.getCu());
            httpBackend.whenGET('/svc/Member/GetMembersByGroupIdCount')
                .respond(200, pointEconomyJson.getMemberPointsInit().totalCount);
            httpBackend.whenGET('/svc/Member/GetPointMasterMember')
                .respond(200, []);
            httpBackend.whenGET('/svc/Point/GetPointDistributionByRole')
                .respond(200, []);
            httpBackend.whenPOST('/svc/Point/MintPoints')
                .respond(200, {});  //empty data for testing
            httpBackend.whenPOST('/svc/Point/Transfer')
                .respond(200, 'Points Issued');
            httpBackend.whenPOST('/svc/Point/IssueToGroup')
                .respond(200, 'Points Issued');
            httpBackend.whenPOST('/svc/AutoComplete/AutoComplete')
                .respond(200, autocompleteJson.getAutoCompleteDataForPointMember());
            spyOn(pointService, 'getEconomyTimeline').andCallFake(function () {
                var deferred = q.defer();
                deferred.resolve([]);
                return deferred.promise;
            });
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it(' 1 controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it(' 2 init should set header points and group members', function () {
            var currentSnapshot = pointEconomyJson.getCurrentSnapshot();
            scope.init();
            httpBackend.flush();

            expect(scope.spendTotal).toBe(currentSnapshot.SpendTotal);
            expect(scope.transferTotal).toBe(currentSnapshot.TransferTotal);
            expect(scope.itemCostTotal).toBe(currentSnapshot.ItemCostTotal);
        });
    });
});