define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/survey.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (userJson, surveyJson) {
    describe('Admin Survey Benchmark Driver Controller Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            routeParams,
            timeout,
            surveySrvc,
            location;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));

        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, $routeParams) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            routeParams = $routeParams;
            httpBackend = $injector.get('$httpBackend');
            surveySrvc = $injector.get('SurveySrvc');
            location = $injector.get('$location');
            timeout = $injector.get('$timeout');
            ctrl = $controller('AdminSurveyBenchmarkDriverCtrl', {$scope: scope});
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Survey/GetSurveyDrivers')
                .respond(200, surveyJson.getSurveyDrivers());
            httpBackend.whenGET('/svc/Survey/GetBenchmarkQuestionDetailByDriver?currentRoundId=test&driverId=test&recurrenceId=test&surveyId=test')
                 .respond(200, surveyJson.getBenchmarkQuestionDetailByDriver());
                routeParams.surveyId = 'test';
                routeParams.recurrenceId = 'test';
                routeParams.currentRoundId = 'test';
                routeParams.driverId = 'test';
            UserSrvc.clearUserCache();
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Admin Survey Benchmark Results controller should exist', function (){
            expect(ctrl).toBeDefined();
        });
        it('Test 2: init() should set model.drivers and model.selectedDriver', function () {
            spyOn(scope, '$broadcast').andCallThrough();
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.model.drivers.length).toBe(6);
            expect(scope.model.selectedDriver).toBeDefined();
            expect(scope.$broadcast).toHaveBeenCalledWith('selectedDriverChanged');
        });
        it('Test 3: init() should set model.driverData and model.questionsData', function () {
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.model.driverData).toBeDefined();
            expect(scope.model.questionsData).toBeDefined();
        });
        it('Test 4: should get Department data', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkEngagementScoreByDepartment?currentRoundId=test&driverId=test&recurrenceId=test&surveyId=test')
                .respond(200, surveyJson.getEngagementScoreByDepartment());
            routeParams.tabName = 'Department';
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.model.tabbedData).toBeDefined();
        });
        it('Test 5: should get Role data', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkEngagementScoreByRole?currentRoundId=test&driverId=test&recurrenceId=test&surveyId=test')
                .respond(200, surveyJson.getEngagementScoreByDepartment());
            routeParams.tabName = 'Role';
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.model.tabbedData).toBeDefined();
        });
        it('Test 6: should get Tenure data', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkEngagementScoreByTenure?currentRoundId=test&driverId=test&recurrenceId=test&surveyId=test')
                .respond(200, surveyJson.getEngagementScoreByDepartment());
            routeParams.tabName = 'Tenure';
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.model.tabbedData).toBeDefined();
        });
        it('Test 7: should get Location data', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkEngagementScoreByLocation?currentRoundId=test&driverId=test&recurrenceId=test&surveyId=test')
                .respond(200, surveyJson.getEngagementScoreByDepartment());
            httpBackend.whenGET('/svc/Survey/GetStateGeoJson')
                .respond(200, {test: 'test'});
            routeParams.tabName = 'Location';
            scope.init();
            httpBackend.flush();
            timeout.flush();
            expect(scope.model.tabbedData).toBeDefined();
        });
        it('Test 8: scope.setSelectedTab should change path', function () {
            spyOn(location, 'path').andCallFake(function () {});
            scope.setSelectedTab('Department');
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 9: scope.back should change path', function () {
            spyOn(location, 'path').andCallFake(function () {});
            scope.back();
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 10: scope.changeDriver should change path', function () {
            spyOn(location, 'path').andCallFake(function () {});
            scope.changeDriver({hgId: 'test'});
            expect(location.path).toHaveBeenCalled();
        });
    });
});
