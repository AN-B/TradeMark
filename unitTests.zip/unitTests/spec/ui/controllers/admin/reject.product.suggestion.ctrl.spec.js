define([
    'unitTests/ui-mocks/modal',
    'unitTests/ui-mocks/productItem.templates.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(modalMock, productItems){
    describe('Recipient delete list dialog controller spec -> ', function() {
        var scope,
            modal,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            productItemSrvc,
            rejectedProduct,
            productItem = productItems.getAll();

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams,  ProductItemSrvc) {
            modal = modalMock;
            productItemSrvc = ProductItemSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenPOST("/svc/ProductItem/RejectProductSuggestion").respond(200,{value: 'done'});
            scope = $rootScope.$new();
            ctrl = $controller('RejectProductSuggestionCtrl', {
                $rootScope: rootScope,
                $scope: scope,
                $modalInstance: modal,
                productItem:productItem,
                selectedIndex : 2
            });
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2: rejectProductSuggestion have to be called', function () {
            spyOn(productItemSrvc, 'rejectProductSuggestion').andCallThrough();
            rejectedProduct = productItem[2]
            scope.rejectProductSuggestion();
            httpBackend.flush();
            expect(productItemSrvc.rejectProductSuggestion).toHaveBeenCalledWith(rejectedProduct);
        });
    });
});