define([
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function (users) {
    describe('Settings Area Tabs Controller Spec', function () {
        var scope, ctrl, rootScope, httpBackend, userService;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc) {
            userService = UserSrvc;
            rootScope = $rootScope;
            scope = $rootScope.$new();
            httpBackend = $injector.get('$httpBackend');
            ctrl = $controller('SettingsAreaTabsCtrl', {$scope: scope});

            UserSrvc.clearUserCache();
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('init() should set flags.enableLocation', function () {
            httpBackend.whenGET('/svc/User/Login').respond(200, users.getCu());

            scope.init();
            httpBackend.flush();

            expect(scope.flags.enableLocation).toBeDefined();
            expect(scope.flags.enableLocation).toBeFalsy();
        });
    });
});