define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){

    describe('Perform card library question controller spec', function() {
        var scope,
            ctrl,
            timeout,
            rootScope;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;

            scope = $rootScope.$new();
            scope.card = {};
            ctrl = $controller('PerformCreateQuestCtrl', {$scope: scope});
        }));
        it('Perform card library question controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

    });
});