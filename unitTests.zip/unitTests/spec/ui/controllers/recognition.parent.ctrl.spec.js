define([
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(){

	describe('Recognition parent controller spec -> ', function() {
		var scope,
			ctrl;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope) {
			scope = $rootScope.$new();
			ctrl = $controller('RecognitionParentCtrl', {$scope: scope, profileType: 'company'});
		}));
		it('Recognition parent controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
	});
});

