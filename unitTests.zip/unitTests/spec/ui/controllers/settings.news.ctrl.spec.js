define([
	'unitTests/ui-mocks/news.json',
    'unitTests/ui-mocks/user.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(newsJson, userJson){

	describe('Admin news controller spec ->', function() {
		var scope,
			ctrl,
			timeout,
			httpBackend,
			newsService,
			rootScope;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, NewsSrvc) {
			newsService = NewsSrvc;
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenGET('/svc/News/GetMyGroupNews?Status=All')
				.respond(200, newsJson.getNews());
			httpBackend.whenPOST('/svc/News/DeleteGroupNews')
				.respond(200, 'deleted');
			httpBackend.whenPOST('/svc/News/UpdateGroupNews')
				.respond(200, 'updated');
			httpBackend.whenPOST('/svc/News/PostGroupNews')
				.respond(200, 'posted');
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());

			scope = $rootScope.$new();
			scope.groupNewsForm = {};
			ctrl = $controller('AdminSettingsNewsCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 admin news controller should exist', function (){
			expect(ctrl).toBeDefined();
			scope.init();
			httpBackend.flush();
			expect(scope.news).toBeDefined();
			expect(scope.tinyoptions).toBeDefined();
		});
		it('Test 2 init() should call backend and hydrate saved news object', function (){
			scope.init();
			httpBackend.flush();
			expect(scope.savedNews.length).toBe(6);
		});
		it('Test 3 deleteNews() should delete news by id', function (){
			scope.init();
			httpBackend.flush();
			scope.deleteNews('63805fd0-6029-11e3-88f9-770ebd99df41');
			httpBackend.flush();
			expect(scope.savedNews.length).toBe(5);
		});
		it('Test 4 displayNews() should hydrate news object with tentative news ', function (){
			scope.init();
			httpBackend.flush();
			scope.displayNews(0);
			expect(scope.news.hgId).toBe('63805fd0-6029-11e3-88f9-770ebd99df41');
		});
		it('Test 5 displayNews() should hydrate news object with final news ', function (){
			scope.init();
			httpBackend.flush();
			scope.displayNews(1);
			expect(scope.news.hgId).toBe('dfbf9580-6028-11e3-88f9-770ebd99df41');
		});
		it('Test 6 deleteNews() should delete news and clear selected news', function (){
			scope.init();
			httpBackend.flush();
			scope.displayNews(0);
			spyOn(scope, 'clear').andCallThrough();
			spyOn(newsService, 'deleteGroupNews').andCallThrough();
			expect(scope.news.hgId).toBe('63805fd0-6029-11e3-88f9-770ebd99df41');
			scope.deleteNews('63805fd0-6029-11e3-88f9-770ebd99df41');
			httpBackend.flush();
			expect(scope.news.hgId).toBe('');
			expect(scope.clear).toHaveBeenCalled();
			expect(newsService.deleteGroupNews).toHaveBeenCalled();
		});
		it('Test 7 deleteNews() should delete news', function (){
			scope.init();
			httpBackend.flush();
			spyOn(scope, 'clear').andCallThrough();
			spyOn(newsService, 'deleteGroupNews').andCallThrough();
			scope.deleteNews('63805fd0-6029-11e3-88f9-770ebd99df41');
			httpBackend.flush();
			expect(scope.news.hgId).toBe('');
			expect(scope.clear).not.toHaveBeenCalled();
			expect(newsService.deleteGroupNews).toHaveBeenCalled();
		});
		it('Test 8 submit() should call updateGroupNews if news contain hgId', function (){
			scope.init();
			httpBackend.flush();
			scope.displayNews(0);
			expect(scope.news.hgId).toBe('63805fd0-6029-11e3-88f9-770ebd99df41');
			spyOn(newsService, 'updateGroupNews').andCallThrough();
			//scope.groupNewsForm.$valid = true;
			scope.submit();
			httpBackend.flush();
			expect(newsService.updateGroupNews).toHaveBeenCalled();
		});
		it('Test 9 submit() should call updateNews if news does not contain hgId', function (){
			scope.init();
			httpBackend.flush();
			scope.displayNews(0);
			delete scope.news.hgId;
			spyOn(newsService, 'postGroupNews').andCallThrough();
			//scope.groupNewsForm.$valid = true;
			scope.submit();
			httpBackend.flush();
			expect(newsService.postGroupNews).toHaveBeenCalled();
		});
		it('Test 10 clear() should clear news object', function (){
			scope.init();
			httpBackend.flush();
			scope.displayNews(0);
			expect(scope.news.hgId).toBe('63805fd0-6029-11e3-88f9-770ebd99df41');
			scope.clear();
			expect(scope.news.hgId).toBe('');
		});
        it('Test 11 submit() after setting value of expiredays should update ExpireDate to be ahead of current date', function (){
            scope.init();
            scope.news.Sticky = true;
            scope.news.StickyDayNumber = 4;
            expect(scope.news.StickyDayNumber).toBe(4);
            //scope.groupNewsForm.$valid = true;
            scope.submit();
            httpBackend.flush();
        });
	});
});