define([
    'unitTests/ui-mocks/productItem.templates.json',
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(productItemsJson, groupJson, userJson){
    describe('Motivate Store Controller spec -> ', function() {
        var scope,
            ctrl,
            timeout,
            rootScope,
            httpBackend,
            service,
            groupService,
            userService,
            modal,
            fakeModal = {
                result: {
                    then: function(confirmCallback, cancelCallback) {
                        this.confirmCallBack = confirmCallback;
                        this.cancelCallback = cancelCallback;
                    }
                },
                close: function( item ) {
                    this.result.confirmCallBack( item );
                },
                dismiss: function( type ) {
                    this.result.cancelCallback( type );
                }
            };

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, ProductItemSrvc, GroupSrvc, UserSrvc, $modal) {
            service = ProductItemSrvc;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            groupService = GroupSrvc;
            userService = UserSrvc;
            ctrl = $controller('MotivateStoreCtrl', {$scope: scope});
            modal = $modal;

            httpBackend.whenGET('/svc/User/Login')
                    .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/ProductItem/GetProductItems')
                .respond(200, productItemsJson.getAll());
            httpBackend.whenGET('/svc/ProductItem/GetAllItemTags')
                .respond(200, productItemsJson.getAll());
            httpBackend.whenGET('/svc/Group/GetCurrentGroupMembers?es=false&status=Active')
                    .respond(200, groupJson.getCurrentGroupMembers());
            httpBackend.whenGET('/svc/ProductItem/GetCampaignProductItems')
                .respond(200, productItemsJson.getAllCampaignItems());
            userService.clearUserCache();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });


        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2: init() should call backend', function () {
            spyOn(userService, 'getUser').andCallThrough();
            spyOn(groupService, 'getCurrentGroupMembers').andCallThrough();
            scope.init();
            httpBackend.flush();
            expect(userService.getUser).toHaveBeenCalled();
            expect(groupService.getCurrentGroupMembers).toHaveBeenCalled();
            expect(scope.productItems.length).toBe(3);
            expect(scope.productItemsWithCampaign.length).toBe(1);
        });

        it('Test 3: toggleDisplayData will toggle the visibility of campaign records if type is flagCampaign and flag is true', function () {
            scope.init();
            httpBackend.flush();
            scope.toggleDisplayData('flagCampaign',true);
            expect(scope.flagCampaign).toBe(false);
        });

        it('Test 4: toggleDisplayData will toggle the visibility of campaign records if type is flagCampaign and flag is false', function () {
           scope.init();
           httpBackend.flush();
           scope.toggleDisplayData('flagCampaign',false);
           expect(scope.flagCampaign).toBe(true);
        });

        it('Test 5: suggestProduct() opens a modal', function () {
            spyOn(modal, 'open').andReturn(fakeModal);
            scope.init();
            httpBackend.flush();
            scope.suggestProduct();
            expect(modal.open).toHaveBeenCalled();
        });
    });
});
