define([
    'unitTests/ui-mocks/modal',
    'unitTests/ui-mocks/productItem.templates.json',
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/searchMeta.json',
    'unitTests/ui-mocks/productItem.templates.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(modalMock, productItems, groupJson, userJson, searchMetaJson, productItemsJson){
    describe('Suggest Product controller spec -> ', function() {
        var scope,
            modal,
            ctrl,
            rootScope,
            httpBackend,
            routeParams,
            productItemSrvc,
            productItem = productItems.suggestNew();

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, $routeParams, ProductItemSrvc) {
            modal = modalMock;
            productItemSrvc = ProductItemSrvc;
            rootScope = $rootScope;
            routeParams = $routeParams;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenPOST("/svc/ProductItem/SaveProductSuggestion").respond(200,{value: 'done'});
            httpBackend.whenGET("/svc/Group/GetCurrentGroupMembers?status=Active&es=false")
                .respond(200, groupJson.getCurrentGroupMembers());
            scope = $rootScope.$new();
            ctrl = $controller('SuggestProductCtrl', {
                $rootScope: rootScope,
                $scope: scope,
                $modalInstance: modal,
                searchMeta : groupJson.getCurrentGroupMembers(),
                currentUser : userJson.getCu()
            });
        }));

        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Controller should exist', function () {
            expect(ctrl).toBeDefined();
        });

        it('Test 2: saveProductSuggestion have to be called', function () {
            spyOn(productItemSrvc, 'saveProductSuggestion').andCallThrough();
            scope.productItem = productItem[0];
            scope.saveProductSuggestion();
            httpBackend.flush();
            expect(productItemSrvc.saveProductSuggestion).toHaveBeenCalledWith(productItem[0]);
        });

        it('Test 3: saveProductSuggestion should not be called', function () {
            spyOn(productItemSrvc, 'saveProductSuggestion').andCallThrough();
            productItem[0].Name = "";
            scope.productItem = productItem[0];
            scope.saveProductSuggestion();
            expect(productItemSrvc.saveProductSuggestion).not.toHaveBeenCalledWith(productItem[0]);
        });

        it('Test 4: getUserSelectModel should return user details', function () {
            var returnObj = {
                meta: searchMetaJson.getSearchMeta(),
                eventName: "Owner"
            };
            expect(JSON.stringify(scope.getUserSelectModel())).toBe(JSON.stringify(returnObj));
        });

        it('Test 5: on Owner it should return UserId and MemberId', function () {
            scope.productItems = productItemsJson.suggestNew();
            var Owner = {
                UserId : '3cf80a90-9cd2-11e2-a3a4-25024474fe63',
                MemberId : '9852e220-8840-11e3-8afa-93a5651e7795'
            };
            scope.$broadcast('Owner');
            expect(scope.productItems[0].Owner.UserId).toBe(Owner.UserId);
        });

        it('Test 6: selectProductType should select specific type of product', function () {
            scope.selectProductType("Campaign");
            expect(scope.productItem.ProductType).toBe("Campaign");
        });
    });
});