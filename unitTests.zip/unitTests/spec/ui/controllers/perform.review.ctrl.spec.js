define([
	'unitTests/ui-mocks/perform.review.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(json){

	describe('Perform review controller spec', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope) {
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			scope = $rootScope.$new();
			ctrl = $controller('PerformReviewCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Perform review controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
	});
});