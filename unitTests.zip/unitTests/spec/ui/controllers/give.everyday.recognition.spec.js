define([
	'unitTests/ui-mocks/autocomplete.json',
	'unitTests/ui-mocks/group.json',
	'unitTests/ui-mocks/teams.json',
	'unitTests/ui-mocks/recognition.templates.json',
	'unitTests/ui-mocks/recognition.request.object.json',
	'unitTests/ui-mocks/badge.json',
	'unitTests/ui-mocks/user.json',
	'unitTests/ui-mocks/dto.service.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(autocompleteJson, groupJson, teamsJson, templatesJson, recJson, badgeJson, userJson, dtoJson){

	describe('Give everyday recognition controller spec -> ', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			service,
			routeParams,
			autoCompleteSrvc,
			count = 0,
			testCount = function () {
				count += 1;
				return 'Test ' + count + ': ';
			};

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionSrvc, $routeParams, AutoCompleteSrvc, UserSrvc) {
			service = RecognitionSrvc;
			autoCompleteSrvc = AutoCompleteSrvc;
			routeParams = $routeParams;
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			UserSrvc.clearUserCache();
			httpBackend.whenGET('/svc/Recognition/GetUserEverydayTemplates')
				.respond(200, templatesJson.getEveryday());
			httpBackend.whenGET('/svc/User/Login')
				.respond(200, userJson.getCu());
			httpBackend.whenGET('/svc/UI/GetRecipientCandidates')
				.respond(200, dtoJson.getRecipients());

			httpBackend.whenPOST('/svc/Recognition/GiveEverydayRecognition')
				.respond(200, 'Everyday');
			httpBackend.whenPOST('/svc/Recognition/GiveValueRecognition')
				.respond(200, 'Value');
			httpBackend.whenPOST('/svc/Recognition/GiveCustomizedRecognition')
				.respond(200, 'Custom');
			httpBackend.whenPOST('/svc/Recognition/GiveAchievementRecognition')
				.respond(200, 'Achievement');
			httpBackend.whenPOST("/svc/AutoComplete/GetPreSelectedItems")
                .respond(200, autocompleteJson.getPreSelectedData());
			scope = $rootScope.$new();
			ctrl = $controller('GiveEverydayCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1: Recognition child controller should exist', function (){
			expect(ctrl).toBeDefined();
		});
		it('Test 2: global variable should be initialized', function (){
			expect(scope.hideRecognitions).toBeFalsy();
		});
		it('Test 3: should call initRec()', function (){
			scope.getTemplates();
			scope.initRec();
			httpBackend.flush();
			expect(scope.search.userMeta.type).toBe('MemberAndDepartmentandLocation');
			expect(scope.search.userMeta.selected.length).toBe(0);
			expect(scope.templates.length).toBe(2);
			expect(scope.isAchievement).toBeTruthy();
			expect(scope.isCustom).toBeTruthy();
		});
		it('Test 4: selectRec should select object from array of templates', function (){
			scope.getTemplates();
			scope.initRec();
			httpBackend.flush();
			expect(scope.request.Template.hgId.length).toBe(0);
			scope.selectRec(scope.templates[1]);
			expect(scope.request.Template.hgId).toBe(scope.templates[1].hgId);
			expect(scope.detail.show).toBeTruthy();
		});
		it('Test 5: should call service method giveEverydayRec if request category is Everyday', function (){
			scope.request = recJson.getEveryday();
            scope.request.Recipients.totalNumRecipients = 1;
            scope.giftStock = 100;
			spyOn(service, 'giveEverydayRec').andCallThrough();
			spyOn(scope, 'clear').andCallThrough();
			scope.giveRecognition();
			httpBackend.flush();
			expect(service.giveEverydayRec).toHaveBeenCalled();
			expect(scope.clear).toHaveBeenCalled();
		});
		it('Test 6: should not call service method giveValueRec if request is invalid', function (){
			scope.request = recJson.getValue();
			scope.request.Template.hgId = '';
			spyOn(service, 'giveValueRec').andCallThrough();
			spyOn(scope, 'clear').andCallThrough();
			scope.giveRecognition();
			expect(service.giveValueRec).not.toHaveBeenCalled();
			expect(scope.clear).not.toHaveBeenCalled();
		});
		it('Test 8: should resolve recipient if member id is passed', function (){
			routeParams.memberId = 'c15985d0-aea6-11e2-b79d-512ef31a350a';
			scope.initRec();
			httpBackend.flush();
			spyOn(autoCompleteSrvc, 'getPreSelectItems').andCallThrough();
			expect(scope.enableSearch).toBeTruthy();
			expect(scope.search.userMeta.preSelected.length).toBe(1);
			expect(scope.request.Recipients.length).toBe(1);
			expect(scope.request.Recipients[0].Name).toBe('Amie Chen');
		});
		it('Test 9: clear() should call cache.clear and broadcast to hide recognitions ', function (){
			spyOn(rootScope, '$broadcast').andCallThrough();
			scope.clear();
			expect(rootScope.$broadcast).toHaveBeenCalledWith('hideRecognitions');
		});
	});
});