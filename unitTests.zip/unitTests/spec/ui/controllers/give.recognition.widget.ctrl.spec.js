define([
	'static/source/core/collectionCache',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'], function(cache){

	describe('Recognition widget controller spec: ', function() {
		var scope,
			ctrl,
			timeout,
			rootScope,
			httpBackend,
			location,
			routeParams;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-controllers"));
		beforeEach(inject(function ($injector, $controller, $rootScope) {
			location = $injector.get("$location");
			timeout = $injector.get("$timeout");
			routeParams = $injector.get("$routeParams");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");

			scope = $rootScope.$new();
			ctrl = $controller('GiveRecWidgetCtrl', {$scope: scope});
		}));
		afterEach(function () {
			scope.$digest();
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
//		it('show recognitions to be false if there is no cache', function (){
//			scope.initWidget();
//			expect(scope.showRecognitions).toBeFalsy();
//		});
//		it('show recognitions to be true if cache is set to true', function (){
//			cache.set('showRecognitions', true);
//			scope.initWidget();
//			expect(scope.showRecognitions).toBeTruthy();
//		});
//		it('showRecognitions should be false when hideRecognitions broadcasted', function (){
//			scope.$broadcast('hideRecognitions');
//			expect(scope.showRecognitions).toBeFalsy();
//		});

	});
});