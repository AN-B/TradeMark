define([
    'unitTests/ui-mocks/user.json',
    'unitTests/ui-mocks/notification.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, notificationJson){

    describe('Important notification controller spec -> ', function () {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            userService,
            notificationSrvc,
            rootScope,
            routeParams;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc, NotificationSrvc, $routeParams) {
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            userService = UserSrvc;
            notificationSrvc = NotificationSrvc;
            routeParams = $routeParams;
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/Notification/GetAllImportantNotifications?recipientId=d2e0d320-a119-11e2-b177-7d64c8315189')
                .respond(200, notificationJson.getAllNotification());
            httpBackend.whenGET('/svc/Notification/GetImportantNotificationsByLimits?recipientId=d2e0d320-a119-11e2-b177-7d64c8315189&take=10')
                .respond(200, notificationJson.getTopTenNotification());
            httpBackend.whenPOST('/svc/Notification/Remove')
                .respond(200, []);
            userService.clearUserCache();
            scope = $rootScope.$new();
            ctrl = $controller('ImportantNotificationsCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 notification controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 it should show all notifications ', function () {
            spyOn(notificationSrvc, 'getAllImportantNotifications').andCallThrough();
            scope.initAll();
            httpBackend.flush();
            rootScope.$digest();
            expect(notificationSrvc.getAllImportantNotifications).toHaveBeenCalled();
            expect(scope.allNotifications.length > 0);
        });
        it('Test 3 removeFromAll should call backend removeNotification service', function () {
            spyOn(notificationSrvc, 'removeNotification').andCallThrough();
            scope.removeFromAll();
            httpBackend.flush();
            expect(notificationSrvc.removeNotification).toHaveBeenCalled();
            expect(scope.allNotifications.length > 0);
        });
        it('Test 4 on dropdownNotificationRemoved should remove 1 notifications', function () {
            spyOn(notificationSrvc, 'removeNotification').andCallThrough();
            scope.allNotifications = notificationJson.getAllNotification();
            rootScope.$broadcast('dropdownNotificationRemoved', {Id: 'a9605360-102a-11e3-bba0-8d9c8faa9d96'});
            expect(scope.allNotifications.length).toBe(9);
        });
        it('Test 5 on removeAll should call backend RemoveMemberNotificaitons service', function () {
            spyOn(notificationSrvc, 'removeMemberNotifications').andCallThrough();
            httpBackend.whenPOST('/svc/Notification/RemoveMemberNotificaitons')
                .respond(200, {});
            scope.removeAll();
            httpBackend.flush();
            expect(notificationSrvc.removeMemberNotifications).toHaveBeenCalled()

        });
    });
});