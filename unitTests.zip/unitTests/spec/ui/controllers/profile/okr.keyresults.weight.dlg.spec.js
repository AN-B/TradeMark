define([
    'unitTests/ui-mocks/modal',
    'unitTests/ui-mocks/okr.add.goal.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(modalMock, json){

    describe('Keyresults Weight Dlg dialog controller spec -> ', function() {
        var scope,
            modal,
            ctrl,
            timeout;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope) {
            modal = modalMock;
            timeout = $injector.get('$timeout');
            scope = $rootScope.$new();

            ctrl = $controller('KeyresultsWeightDlg', {
                $scope: scope,
                $modalInstance: modal,
                type: 'Equal',
                keyResults: json.getModel().KeyResults
            });
        }));
        afterEach(function () {
            scope.$digest();
        });
        
        it('Test 1: scope.model should be defined', function (){
            scope.initDlg(scope.model);
            expect(scope.model.type).toBe('Equal');
            expect(scope.model.keyResults.length).toBe(1);
            expect(scope.model.invalid).toBeFalsy();
            expect(scope.model.total).toBe(100);
        });
        it('Test 2: model should be custom and total should be calculated', function (){
            scope.toggleType(scope.model);
            expect(scope.model.type).toBe('Custom');
            expect(scope.model.keyResults[0].Weight).toBe(100);
            expect(scope.model.invalid).toBeFalsy();
            expect(scope.model.total).toBe(100);
        });
        it('Test 2: should toggle type', function (){
            scope.model.type = 'Custom';
            scope.toggleType(scope.model);
            expect(scope.model.type).toBe('Equal');
        });
        it('Test 3: it should return valid model if key results weight is valid and type is custom', function (){
            scope.model = scope.toggleType(scope.model);
            scope.addAndValidate(scope.model);
            expect(scope.model.invalid).toBeFalsy();
        });
        it('Test 4: it should return valid model type is equal and key results weight is valid', function (){
            scope.setEqual(scope.model);
            expect(scope.model.invalid).toBeFalsy();
            expect(scope.model.total).toBe(100);
        });
        it('Test 5: it should return invalid model type is custom and key results weight is invalid', function (){
            scope.model.type = 'Custom';
            scope.model.keyResults[0].Weight = 50;
            scope.addAndValidate(scope.model);
            expect(scope.model.total).toBe(50);
            expect(scope.model.invalid).toBeTruthy();
        });
        it('Test 6: it should call modal dismiss', function (){
            spyOn(modal, 'dismiss').andCallThrough();
            scope.dismiss();
            expect(modal.dismiss).toHaveBeenCalled();
        });
        it('Test 7: it should cleanup model and close dialog', function (){
            spyOn(modal, 'close').andCallThrough();
            scope.toggleType(scope.model);
            scope.model.type = 'Equal';
            scope.close(scope.model);
            timeout.flush();
            expect(modal.close).toHaveBeenCalled();
            expect(scope.model.keyResults[0].Weight).not.toBeDefined();
        });
        it('Test 8: it should dismiss dialog if model is invalid', function (){
            spyOn(modal, 'dismiss').andCallThrough();
            scope.toggleType(scope.model);
            scope.model.invalid = true;
            scope.close(scope.model);
            expect(modal.dismiss).toHaveBeenCalled();
        });
    });
});