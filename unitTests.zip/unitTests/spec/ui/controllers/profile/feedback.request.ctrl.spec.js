define([
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(){

        describe('feedback request controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                service,
                cycleService,
                location,
                toastr,
                routeParams;
            function getRequest() {
                return {note: 'test', memberIds:['test'], cycleId:'test'};
            }

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, feedbackSessionServiceSrvc, FeedbackCycleSrvc, ToastrSrvc) {
                toastr = ToastrSrvc;
                service = feedbackSessionServiceSrvc;
                cycleService = FeedbackCycleSrvc;
                location = $injector.get("$location");
                routeParams = $injector.get("$routeParams");
                q = $injector.get("$q");
                backend = $injector.get("$httpBackend");
                scope = $rootScope.$new();
                routeParams.cycleId = "test";
                ctrl = $controller('FeedbackRequestCtrl', {$scope: scope});
                spyOn(location, 'path').andCallFake(function(){});
            }));
            afterEach(function () {
                delete routeParams.cycleId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 init should call backend', function (){
                backend.whenGET('/svc/FeedbackCycle/GetCycleById?cycleId=test')
                    .respond(200, {Name: 'test'});
                spyOn(cycleService, 'getCycleById').andCallThrough();
                scope.init();
                backend.flush();
                expect(cycleService.getCycleById).toHaveBeenCalledWith('test');
                expect(scope.request.name).toBe('test');
            });
            it('Test 3 validate should return valid request', function (){
                var test = scope.validate(getRequest());
                expect(test.invalid).toBeFalsy();
            });
            it('Test 4 send should not call service if request is invalid', function (){
                var test = getRequest();
                delete test.note;
                spyOn(service, 'requestFeedback').andCallThrough();
                scope.send(test);
                expect(service.requestFeedback).not.toHaveBeenCalled();
            });
            it('Test 5 send should not call service if request is invalid', function (){
                var test = getRequest();
                backend.whenPOST('/svc/FeedbackSession/RequestFeedback')
                    .respond(200, {});
                spyOn(toastr, 'success').andCallFake(function(){});
                spyOn(service, 'requestFeedback').andCallThrough();
                scope.send(test);
                backend.flush();
                expect(service.requestFeedback).toHaveBeenCalled();
                expect(location.path).toHaveBeenCalled();
                expect(toastr.success).toHaveBeenCalled();
            });
        });
    });