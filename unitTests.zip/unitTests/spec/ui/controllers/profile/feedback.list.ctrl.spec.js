define(['unitTests/ui-mocks/feedback.list',
        'unitTests/ui-mocks/user.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(mock, userJson){

        describe('feedback list controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                service,
                cycleService,
                location,
                toastr,
                routeParams,
                metrics = {
                    Metrics: {
                        ToGive: 1,
                        ToReceive: 2,
                        Gave: 3,
                        Received: 4,
                        ArchivedGive: 5,
                        ArchivedReceive: 6
                    }
                },
                ctrlService;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, feedbackSessionServiceSrvc, FeedbackCycleSrvc, ToastrSrvc, FeedbackCtrlSrvc) {
                toastr = ToastrSrvc;
                service = feedbackSessionServiceSrvc;
                ctrlService = FeedbackCtrlSrvc;
                cycleService = FeedbackCycleSrvc;
                location = $injector.get("$location");
                routeParams = $injector.get("$routeParams");
                q = $injector.get("$q");
                backend = $injector.get("$httpBackend");
                backend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
                backend.whenGET('/svc/FeedbackSession/GetOverview?mId=d2e0d320-a119-11e2-b177-7d64c8315189')
                    .respond(200, metrics);
                backend.whenGET('/svc/FeedbackSession/GetSessionsToGive?mId=d2e0d320-a119-11e2-b177-7d64c8315189&skip=0&take=10')
                    .respond(200, mock.get());
                backend.whenGET('/svc/FeedbackSession/GetSessionsToGive?mId=d2e0d320-a119-11e2-b177-7d64c8315189&skip=0&st=abc&take=10')
                    .respond(200, mock.get());

                scope = $rootScope.$new();
                routeParams.cycleId = "test";
                ctrl = $controller('FeedbackList', {$scope: scope});
                spyOn(location, 'path').andCallFake(function(){});
            }));
            afterEach(function () {
                delete routeParams.cycleId;
                delete routeParams.tab;
                delete routeParams.memberId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            xit('Test 2', function (){
                spyOn(ctrlService, 'getRequest').andCallThrough();
                spyOn(service, 'getOverview').andCallThrough();
                spyOn(ctrlService, 'getMemberId').andCallThrough();
                routeParams.tab = 'Inbox';
                ctrl.init();
                backend.flush();
                expect(ctrl.model.subtabs[0].num).toBe(1);
                expect(ctrl.model.subtabs[1].num).toBe(2);
                expect(ctrlService.getRequest).toHaveBeenCalled();
                expect(service.getOverview).toHaveBeenCalled();
                expect(ctrlService.getMemberId).toHaveBeenCalled();
            });
            xit('Test 3', function (){
                spyOn(ctrlService, 'getRequest').andCallThrough();
                routeParams.tab = 'Completed';
                ctrl.init();
                backend.flush();
                expect(ctrl.model.subtabs[0].num).toBe(4);
                expect(ctrl.model.subtabs[1].num).toBe(3);
                expect(ctrlService.getRequest).toHaveBeenCalled();
            });
            xit('Test 4', function (){
                spyOn(ctrlService, 'getRequest').andCallThrough();
                routeParams.tab = 'Archived';
                ctrl.init();
                backend.flush();
                expect(ctrl.model.subtabs[0].num).toBe(6);
                expect(ctrl.model.subtabs[1].num).toBe(5);
                expect(ctrlService.getRequest).toHaveBeenCalled();
            });
            xit('Test 5', function (){
                spyOn(ctrlService, 'getRequest').andCallThrough();
                routeParams.tab = 'Inbox';
                ctrl.model.search = 'abc';
                ctrl.search('abc');
                backend.flush();
                expect(ctrl.feedbacks.length).toBe(2);
                expect(ctrlService.getRequest).toHaveBeenCalled();
            });
            it('Test 6', function (){
                spyOn(ctrlService, 'getRequest').andCallThrough();
                routeParams.tab = 'Inbox';
                ctrl.model.search = 'ac';
                ctrl.search('ac');
                expect(ctrl.feedbacks.length).toBe(0);
                expect(ctrlService.getRequest).not.toHaveBeenCalled();
            });
            xit('Test 7', function (){
                spyOn(ctrlService, 'getRequest').andCallThrough();
                routeParams.tab = 'Inbox';
                ctrl.more = true;
                scope.$broadcast('bottomScroll');
                backend.flush();
                expect(ctrl.feedbacks.length).toBe(2);
                expect(ctrlService.getRequest).toHaveBeenCalled();
            });
            it('Test 8', function (){
                spyOn(ctrlService, 'getRequest').andCallThrough();
                routeParams.tab = 'Inbox';
                scope.$broadcast('bottomScroll');
                expect(ctrl.feedbacks.length).toBe(0);
                expect(ctrlService.getRequest).not.toHaveBeenCalled();
            });


        });
    });