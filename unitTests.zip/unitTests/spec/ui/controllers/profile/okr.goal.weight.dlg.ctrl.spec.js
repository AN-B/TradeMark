define([
    'unitTests/ui-mocks/modal',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function (modalMock) {

    describe('goal dialog weight controller spec -> ', function () {
        var scope,
            modal,
            ctrl,
            timeout,
            service;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($rootScope, $injector, $controller, okrCycleViewSrvc, $timeout) {
            service = okrCycleViewSrvc;
            modal = modalMock;
            timeout = $timeout;
            scope = $rootScope.$new();
            ctrl = $controller('OkrGoalWeightDlg', {
                $scope: scope,
                $modalInstance: modal,
                type: 'Equal',
                note: '',
                goals: [],
                enableConfirm: true
            });
        }));
        afterEach(function () {
            scope.$digest();
        });
        it('Test 1: ', function () {
            expect(ctrl).toBeDefined();
            expect(scope.model).toBeDefined();
            expect(scope.addAndValidate).toBe(service.addAndValidate);
            expect(scope.dismiss).toBe(modal.dismiss);
        });

        it('Test 2: ', function () {
            spyOn(modal, 'close').andCallThrough();
            scope.close({goals: []});
            timeout.flush();
            expect(modal.close).toHaveBeenCalled();
        });

        it('Test 3: ', function () {
            spyOn(service, 'addAndValidate').andCallThrough();
            scope.reset({goals: []});
            expect(service.addAndValidate).toHaveBeenCalled();
        });

        it('Test 4: ', function () {
            spyOn(service, 'addAndValidate').andCallThrough();
            spyOn(service, 'setEqual').andCallThrough();
            scope.init({goals: []});
            expect(service.addAndValidate).toHaveBeenCalled();
            expect(service.setEqual).toHaveBeenCalled();
        });
    });
});