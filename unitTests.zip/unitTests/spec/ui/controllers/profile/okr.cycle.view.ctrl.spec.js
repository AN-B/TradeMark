define([
        'unitTests/ui-mocks/okr.cycle.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(okrJson){

        describe('Okr cycle view controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                rootScope,
                goalSrvc,
                location,
                routeParams,
                toastSrvc,
                q,
                memberSrvc;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalSrvc, ToastrSrvc, MemberSrvc) {
                rootScope = $rootScope;
                goalSrvc = GoalSrvc;
                memberSrvc = MemberSrvc;
                toastSrvc = ToastrSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                backend.whenGET('/svc/Goal/GetCycleOverviewByMemberId?memberId=test')
                   .respond(200, okrJson.getOverview());
                backend.whenGET('/svc/Goal/GetIndividualCyclesByMemberId?memberId=test')
                    .respond(200, okrJson.get());
                backend.whenGET('/svc/Goal/GetTeamCyclesByMemberId?memberId=test')
                    .respond(200, okrJson.get());
                backend.whenGET('/svc/Goal/GetCompanyCyclesByMemberId?memberId=test')
                    .respond(200, okrJson.get());
                backend.whenGET('/svc/Member/GetProfileMemberRecordById?MemberId=test')
                    .respond(200, {});

                routeParams.memberId = 'test';
                scope = $rootScope.$new();
                ctrl = $controller('OkrCycleViewCtrl', {$scope: scope});
            }));
            afterEach(function () {
                delete routeParams.memberId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 Okr cycle view controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 Okr goal service getIndividualCyclesByMemberId method should be called', function (){
                scope.path = '/Cycles/';
                spyOn(goalSrvc, 'getCycleOverviewByMemberId').andCallThrough();
                scope.init();
                backend.flush();
                expect(goalSrvc.getCycleOverviewByMemberId).toHaveBeenCalledWith('test');
            });
            it('Test 6 Okr length of nav links should be 3', function (){
                spyOn(goalSrvc, 'getCycleOverviewByMemberId').andCallFake(function(){
                    var apr = okrJson.getOverview(),
                        deferred = q.defer();
                    delete apr.IndividualCycleNumber;
                    deferred.resolve(apr);
                    return deferred.promise;
                });
                spyOn(goalSrvc, 'getCompanyCyclesByMemberId').andCallFake(function(){
                    var deferred = q.defer();
                    deferred.resolve(okrJson.get());
                    return deferred.promise;
                });
                spyOn(memberSrvc, 'getProfileMemberRecordById').andCallFake(function(){
                    var deferred = q.defer();
                    deferred.resolve({});
                    return deferred.promise;
                });
                scope.path = '/Cycle/';
                scope.init();
                scope.$digest();
                expect(scope.nav.links.length).toBe(3);
            });
            it('Test 7 addnew should location path', function (){
                spyOn(location, 'path').andCallFake(function(){});
                scope.addNew({ParticipantType: 'test', CycleId: 'test', ParticipantId: 'test'});
                expect(location.path).toHaveBeenCalledWith('Profile/GoalDetails/Create/test/test/test/test');
            });

            it('Test 10 should submit for approval', function (){
                backend.whenPOST('/svc/Goal/SetMyGoalsForCycle')
                    .respond(200, {Message: "done"});
                spyOn(toastSrvc, 'success').andCallThrough();
                spyOn(goalSrvc, 'setMyGoalsForCycle').andCallThrough();
                spyOn(goalSrvc, 'clearCache').andCallThrough();
                scope.cycle = {ParticipantType: 'test', ParticipantId: 'test', CycleId: 'test'};
                scope.submitForApproval(scope.cycle);

                backend.flush();
                expect(goalSrvc.setMyGoalsForCycle).toHaveBeenCalled();
                expect(goalSrvc.clearCache).toHaveBeenCalled();
                expect(toastSrvc.success).toHaveBeenCalledWith('done');
            });
            it('Test 11 should delete Goal from cycle', function (){
                backend.whenPOST('/svc/Goal/DeleteGoal')
                    .respond(200, 'done');
                spyOn(toastSrvc, 'success').andCallThrough();
                spyOn(goalSrvc, 'deleteGoal').andCallThrough();
                scope.cycle = {CycleId: 'test', Goals: [{hgId: '123'}, {hgId: '456'}]};
                scope.goalDelete(scope.cycle, '123');

                backend.flush();
                expect(goalSrvc.deleteGoal).toHaveBeenCalled();
                expect(scope.cycle.Goals.length).toBe(1);
                expect(toastSrvc.success).toHaveBeenCalledWith('profile.goals.ghbd');
            });
            it('Test 11 should call location with goal edit params', function (){
                spyOn(location, 'path').andCallFake(function(){});
                scope.goalEdit('test', 'test');
                expect(location.path).toHaveBeenCalledWith('Profile/GoalDetails/Edit/test/test/test');
            });
            it('Test 12 should submit for close', function (){
                backend.whenPOST('/svc/Goal/RequestCloseMyGoalsForCycle')
                    .respond(200, {Message: 'done'});
                spyOn(toastSrvc, 'success').andCallThrough();
                spyOn(goalSrvc, 'submitForClose').andCallThrough();
                spyOn(goalSrvc, 'clearCache').andCallThrough();
                scope.cycle = {ParticipantType: 'test', ParticipantId: 'test', CycleId: 'test'};
                scope.submitForClose(scope.cycle);

                backend.flush();
                expect(goalSrvc.submitForClose).toHaveBeenCalled();
                expect(goalSrvc.clearCache).toHaveBeenCalled();
                expect(toastSrvc.success).toHaveBeenCalledWith('done');
            });
            it('Test 13 on GoalServiceCacheCleared it should reload the UI', function (){
                spyOn(scope, 'init').andCallFake(function(){});
                spyOn(scope, 'getCycles').andCallFake(function(){});
                rootScope.$broadcast('GoalServiceCacheCleared');
                expect(scope.init).toHaveBeenCalled();
                expect(scope.getCycles).toHaveBeenCalledWith('getIndividualCyclesByMemberId', 'Member');
                expect(scope.getCycles).toHaveBeenCalledWith('getTeamCyclesByMemberId', 'Team');
                expect(scope.getCycles).toHaveBeenCalledWith('getCompanyCyclesByMemberId', 'Company');
            });
            it('Test 14 on GoalStatusUpdated it should reload the UI', function (){
                spyOn(scope, 'init').andCallFake(function(){});
                spyOn(scope, 'getCycles').andCallFake(function(){});
                rootScope.$broadcast('GoalStatusUpdated');
                expect(scope.init).toHaveBeenCalled();
                expect(scope.getCycles).toHaveBeenCalledWith('getIndividualCyclesByMemberId', 'Member');
                expect(scope.getCycles).toHaveBeenCalledWith('getTeamCyclesByMemberId', 'Team');
                expect(scope.getCycles).toHaveBeenCalledWith('getCompanyCyclesByMemberId', 'Company');
            });
            it('Test 15 on $destroy it should destroy listeners', function (){
                spyOn(scope, 'goalServiceCacheClearedListener').andCallThrough();
                spyOn(scope, 'goalStatusUpdatedListener').andCallThrough();
                rootScope.$broadcast('$destroy');
                expect(scope.goalServiceCacheClearedListener).toHaveBeenCalled();
                expect(scope.goalStatusUpdatedListener).toHaveBeenCalled();
            });
        });
    });
