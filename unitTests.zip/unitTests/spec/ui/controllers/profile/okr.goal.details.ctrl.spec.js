define([
        'unitTests/ui-mocks/okr.cycle.json',
        'unitTests/ui-mocks/okr.approve.json',
        'unitTests/ui-mocks/okr.goal.comments.json',
        'unitTests/ui-mocks/okr.add.goal.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(okrJson, approveJson, comments, okrAddGoalJson) {

        describe('Okr goal details controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                rootScope,
                goalSrvc,
                location,
                routeParams,
                window,
                toastrSrvc,
                timeout,
                commentSrvc,
                q,
                goalsAdminSrvc,
                modal;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalSrvc, $window, ToastrSrvc, GoalsAdminSrvc, CommentSrvc, $modal, $templateCache) {
                $templateCache.put('templates/Hgapp/User/user-list.html', '<span></span>');
                rootScope = $rootScope;
                goalSrvc = GoalSrvc;
                modal = $modal;
                commentSrvc = CommentSrvc;
                toastrSrvc = ToastrSrvc;
                timeout = $injector.get("$timeout");
                location = $injector.get("$location");
                window = $injector.get('$window');
                q = $injector.get("$q");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                routeParams.memberId = 'test';
                routeParams.goalId = 'test';
                scope = $rootScope.$new();
                ctrl = $controller('OkrGoalDetailsCtrl', {$scope: scope, $modalInstance: modal});
                goalsAdminSrvc = GoalsAdminSrvc;
                spyOn(location, 'path').andCallFake(function(){});
            }));
            afterEach(function () {
                delete routeParams.memberId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 Okr goal details controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 init should call backend getGoalById method', function (){
                spyOn(goalSrvc, 'getGoalById').andCallThrough();
                backend.whenGET('/svc/Goal/GetGoalById?gId=test')
                    .respond(200, approveJson.getDetails());
                backend.whenGET('/svc/Goal/GetCollaboratorsByGoalId?gId=test&skip=0&take=10')
                    .respond(200, okrAddGoalJson.getCollaboratorsByGoalId());
                backend.whenGET('/svc/Goal/GetGoalById?gId=dbc0bf70-0aec-11e5-ab2a-7d91bbc4935d')
                    .respond(200, approveJson.getDetails());
                scope.init();
                backend.flush();
                expect(goalSrvc.getGoalById).toHaveBeenCalledWith('test');
                expect(scope.goal).toBeDefined();
            });
            it('Test 3 comment should not call comment service if comment is invalid', function (){
                spyOn(goalSrvc, 'commentGoal').andCallThrough();
                var request = {goalId: 'test'};
                scope.comment(request);
                expect(goalSrvc.commentGoal).not.toHaveBeenCalled();
                expect(request.invalid).toBeTruthy();
            });
            it('Test 4 comment should not call comment service if comment is invalid', function (){
                spyOn(goalSrvc, 'commentGoal').andCallThrough();
                var request = {goalId: 'test', note: '  '};
                scope.comment(request);
                expect(goalSrvc.commentGoal).not.toHaveBeenCalled();
                expect(request.invalid).toBeTruthy();
            });
            it('Test 5 comment should call comment service if comment is valid', function (){
                backend.whenPOST('/svc/Goal/CommentGoal')
                    .respond(200, {});
                spyOn(goalSrvc, 'commentGoal').andCallThrough();
                var request = {goalId: 'test', note: 'done'};
                scope.comment(request);
                backend.flush();
                expect(goalSrvc.commentGoal).toHaveBeenCalled();
                expect(request.invalid).toBeFalsy();
            });
            it('Test 6 getComments should call backend and get comments', function (){
                backend.whenGET('/svc/Goal/GetCommentsByEntityId?entityId=test&skip=0')
                    .respond(200, comments.get());
                spyOn(goalSrvc, 'getComments').andCallThrough();
                scope.getComments();
                backend.flush();
                expect(goalSrvc.getComments).toHaveBeenCalledWith({goalId: 'test', skip: 0});
                expect(scope.comments.comments.length).toBeTruthy();
            });
            it('Test 7 on GoalCommentAdded event it should call get comments', function (){
                backend.whenGET('/svc/Goal/GetCommentById?id=test')
                    .respond(200, comments.get().comments[0]);
                spyOn(goalSrvc, 'GetCommentById').andCallThrough();
                scope.comments.comments = [];
                rootScope.$broadcast('GoalCommentAdded', {EntityId: 'test', hgId: 'test'});
                backend.flush();
                expect(goalSrvc.GetCommentById).toHaveBeenCalledWith('test');
            });
            it('Test 8 on GoalCommentCacheRemoved event it should not call get call get comment if id does not match' , function (){
                spyOn(goalSrvc, 'GetCommentById').andCallThrough();
                rootScope.$broadcast('GoalCommentAdded', 'blah');
                expect(goalSrvc.GetCommentById).not.toHaveBeenCalled();
            });
            it('Test 9 it should call backend and add collaborator', function (){
                backend.whenPOST('/svc/Goal/AddCollaborator')
                    .respond(200, {Collaborator: {}});
                spyOn(goalSrvc, 'addCollaborator').andCallThrough();
                scope.search.collaboratorMeta.onSelect({Id: 'test'});
                backend.flush();
                expect(scope.collaborators.length).toBe(1);
                expect(goalSrvc.addCollaborator).toHaveBeenCalled();
            });

            it('Test 10 it should call backend and remove collaborator', function (){
                backend.whenPOST('/svc/Goal/RemoveCollaborator')
                    .respond(200, {Collaborator: {}});
                scope.collaborators = [{MemberId: 'test'}];
                spyOn(goalSrvc, 'removeCollaborator').andCallThrough();
                scope.search.collaboratorMeta.deSelect({Id: 'test'});
                backend.flush();
                expect(scope.collaborators.length).toBe(0);
                expect(goalSrvc.removeCollaborator).toHaveBeenCalled();
            });
            it('Test 12 ', function (){
                var test = {Progress: 100};
                scope.completeKeyresult(test);
                expect(test.Progress).toBe(0);
            });
            it('Test 13 ', function (){
                var test = {Progress: 0};
                scope.completeKeyresult(test);
                expect(test.Progress).toBe(100);
            });

            it('Test 14 it should get call approveSet', function (){
                backend.whenPOST('/svc/Goal/ApproveSet')
                    .respond(200, {Status: 'alsdijfa'});
                spyOn(goalsAdminSrvc, 'approveSet').andCallThrough();
                scope.goal = approveJson.get();
                var id = scope.goal.GoalId;
                scope.approveSet(id);
                scope.$digest();
                backend.flush();
                expect(goalsAdminSrvc.approveSet).toHaveBeenCalledWith(id);
            });
            it('Test 15 it should not call service if request is invalid', function (){
                backend.whenPOST('/svc/Goal/RejectSet')
                    .respond(200, {Status: 'asldifjasdf'});
                spyOn(goalsAdminSrvc, 'rejectSet').andCallThrough();
                scope.goal = approveJson.get();
                var id = scope.goal.GoalId,
                    request = {};
                scope.rejectSet(request, id);
                expect(request.invalid).toBeTruthy();
            });
            it('Test 16 it should call service if request is valid', function (){
                backend.whenPOST('/svc/Goal/RejectSet')
                    .respond(200, {Status: 'asldifjasdf'});
                spyOn(goalsAdminSrvc, 'rejectSet').andCallThrough();
                scope.goal = approveJson.get();
                var id = scope.goal.GoalId,
                    request = {note: 'test', rejectNote: 'asldfija'};
                scope.rejectSet(request, id);
                backend.flush();
                expect(goalsAdminSrvc.rejectSet).toHaveBeenCalled();
            });
            it('Test 17 it should call backend approveClosure service', function (){
                backend.whenPOST('/svc/Goal/ApproveClose')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'approveClose').andCallThrough();
                scope.goal = approveJson.get();
                var id = scope.goal.GoalId;
                scope.approveClosure(id);
                backend.flush();
                expect(goalsAdminSrvc.approveClose).toHaveBeenCalledWith(id);
            });
            it('Test 18 it should call backend rejectClosure service', function (){
                backend.whenPOST('/svc/Goal/RejectClosure')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'rejectClose').andCallThrough();
                scope.goal = approveJson.get();
                var id = scope.goal.GoalId,
                    request = {note: 'test', rejectNote: 'alsdifjasdf'};
                scope.rejectClosure(request, id);
                backend.flush();
                expect(goalsAdminSrvc.rejectClose).toHaveBeenCalled();
            });
            it('Test 19 it should not call backend rejectClosure service if request is invalid', function (){
                backend.whenPOST('/svc/Goal/RejectClosure')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'rejectClose').andCallThrough();
                scope.goal = approveJson.get();
                var id = scope.goal.GoalId,
                    request = {};
                scope.rejectClosure(request, id);
                expect(request.invalid).toBeTruthy();
            });
            it('Test 20 it should call likeComment', function (){
                backend.whenPOST('/svc/Comment/Like')
                    .respond(200, {});
                spyOn(commentSrvc, 'likeComment').andCallThrough();
                scope.likeComment({ hgId: 'id', LikedMembers: [{MemberId: 'nothing'}]}, 'test');
                backend.flush();
                expect(commentSrvc.likeComment).toHaveBeenCalledWith('id');
            });
            it('Test 21 it should not call likeComment if member already liked comment', function (){
                backend.whenPOST('/svc/Comment/Like')
                    .respond(200, {});
                spyOn(commentSrvc, 'likeComment').andCallThrough();
                scope.likeComment({ hgId: 'id', LikedMembers: [{MemberId: 'test'}]}, 'test');
                expect(commentSrvc.likeComment).not.toHaveBeenCalled();
            });
            it('Test 22 on CommentLiked it should not update comments liked members if event object id is not found in comments array', function (){
                backend.whenPOST('/svc/Comment/Like')
                    .respond(200, {});
                scope.comments.comments = [];
                scope.goal = {IMemberId: 'test'};
                spyOn(goalSrvc, 'removeCommentCache').andCallThrough();
                scope.$broadcast('CommentLiked', {LikedMembers: {}});
                expect(goalSrvc.removeCommentCache).not.toHaveBeenCalled();
            });
            it('Test 23 on CommentLiked event it should update LikedMembers array', function (){
                scope.comments.comments = [{hgId:'test', LikedMembers: []}];
                scope.goal = {IMemberId: 'test'};
                scope.$broadcast('CommentLiked', {CommentId:'test', LikedMembers: [{test: 'test'}]});
                expect(scope.comments.comments[0].LikedMembers.length).toBe(1);
                expect(scope.comments.comments[0].iLike).toBeFalsy();
            });
            it('Test 24 on CommentLiked event it should set iLike to true', function (){
                scope.comments.comments = [{hgId:'test', LikedMembers: [{MemberId: 'test'}]}];
                scope.goal = {IMemberId: 'test'};
                scope.$broadcast('CommentLiked', {CommentId:'test', LikedMembers: [{MemberId: 'test'}]});
                expect(scope.comments.comments[0].LikedMembers.length).toBe(1);
                expect(scope.comments.comments[0].iLike).toBeTruthy();
            });
            it('Test 25 it should not call modal if member array is undefined', function (){
                spyOn(modal, 'open').andCallThrough();
                scope.viewLikeMembers();
                expect(modal.open).not.toHaveBeenCalled();
            });
            it('Test 26 it should call modal if member array is defined', function (){
                spyOn(modal, 'open').andCallThrough();
                scope.viewLikeMembers([{test: 'test'}]);
                expect(modal.open).toHaveBeenCalled();
            });
            it('Test 27 it should toggle history', function (){
                var test = {hLimit: 5, History: [{}, {}, {}, {}, {}, {}]};
                test = scope.toggleHistory(test);
                expect(test.hLimit).toBe(test.History.length);
            });
            it('Test 28 it should toggle history', function (){
                var test = {hLimit: 6, History: [{}, {}, {}, {}, {}, {}]};
                test = scope.toggleHistory(test);
                expect(test.hLimit).toBe(scope.model.hLimit);
            });
            it('Test 29 it should update key result isDirty flag', function (){
                var opt = {};
                var test = scope.getSliderOptions(opt);
                test.stop();
                expect(opt.isDirty).toBeTruthy();
            });
            it('Test 30 it should not call backend to update key results if there are no updates', function (){
                spyOn(goalSrvc, 'updateKeyResults').andCallThrough();
                var goal = approveJson.getDetails();
                scope.updateKeyResults(goal);
                expect(goalSrvc.updateKeyResults).not.toHaveBeenCalled();
                expect(goal.update).toBeFalsy();
            });
            it('Test 31 it should not call backend to update key results if there are no updates', function (){
                spyOn(goalSrvc, 'updateKeyResults').andCallThrough();
                backend.whenPOST('/svc/Goal/UpdateKeyResults')
                    .respond(200, {});
                var goal = approveJson.getDetails();
                goal.KeyResults[0].isDirty = true;
                scope.updateKeyResults(goal);
                backend.flush();
                expect(goalSrvc.updateKeyResults).toHaveBeenCalled();
                expect(goal.update).toBeTruthy();
            });
            it('Test 32 it should call backend UnfollowGoal method', function (){
                backend.whenPOST('/svc/Goal/UnfollowGoal')
                    .respond(200, {});
                spyOn(goalSrvc, 'unfollowGoal').andCallThrough();
                spyOn(scope, 'init').andCallFake(function(){});
                scope.unfollowGoal();
                backend.flush();
                expect(goalSrvc.unfollowGoal).toHaveBeenCalled();
                expect(scope.init).toHaveBeenCalled();
            });
            it('Test 33 it should call backend FollowGoal method', function (){
                backend.whenPOST('/svc/Goal/FollowGoal')
                    .respond(200, {});
                spyOn(goalSrvc, 'followGoal').andCallThrough();
                spyOn(scope, 'init').andCallFake(function(){});
                scope.followGoal();
                backend.flush();
                expect(goalSrvc.followGoal).toHaveBeenCalled();
                expect(scope.init).toHaveBeenCalled();
            });
            it('Test 34 it should navigate to edit route', function (){
                scope.switchToEditMode({CycleId: 'test', hgId: 'test', Owner:{MemberId: 'test'}});
                expect(location.path).toHaveBeenCalled();
            });
            it('Test 35  it should navigate back using location service', function (){
                rootScope.isHistory = false;
                scope.back();
                expect(location.path).toHaveBeenCalled();
            });
        });
    });
