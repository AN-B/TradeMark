define(['angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(){

        describe('feedback tip controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                service,
                cycleService,
                location,
                toastr,
                routeParams;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, feedbackSessionServiceSrvc, FeedbackCycleSrvc, ToastrSrvc) {
                toastr = ToastrSrvc;
                service = feedbackSessionServiceSrvc;
                cycleService = FeedbackCycleSrvc;
                location = $injector.get("$location");
                routeParams = $injector.get("$routeParams");
                q = $injector.get("$q");
                backend = $injector.get("$httpBackend");
                scope = $rootScope.$new();
                backend.whenGET('/svc/FeedbackSession/GetSessionByIdTip?sId=test')
                    .respond(200, {});
                backend.whenPOST('/svc/FeedbackSession/StartAnswer')
                    .respond(200, {});

                routeParams.sessionId = "test";
                ctrl = $controller('FeedbackTipCtrl', {$scope: scope});
                spyOn(location, 'path').andCallFake(function(){});
            }));
            afterEach(function () {
                delete routeParams.sessionId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2', function () {
                spyOn(service, 'getSessionByIdTip').andCallThrough();
                scope.init();
                backend.flush();
                expect(scope.feedback).toBeDefined();
                expect(service.getSessionByIdTip).toHaveBeenCalled();
            });
            it('Test 3', function () {
                spyOn(service, 'startAnswer').andCallThrough();
                scope.feedback = {
                    CycleId: '123'
                };
                scope.next();
                backend.flush();
                expect(service.startAnswer).toHaveBeenCalled();
                expect(location.path).toHaveBeenCalled();
            });
        });
    });