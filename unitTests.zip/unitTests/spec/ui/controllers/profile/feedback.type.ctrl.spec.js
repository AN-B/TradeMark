define([
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(){

        describe('feedback type controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                service,
                location,
                routeParams,
                timeout,
                q,
                window;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, feedbackSessionServiceSrvc) {

                service = feedbackSessionServiceSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                backend = $injector.get("$httpBackend");
                scope = $rootScope.$new();
                ctrl = $controller('FeedbackTypeCtrl', {$scope: scope});
                spyOn(location, 'path').andCallFake(function(){});
            }));
            afterEach(function () {
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 init should call backend', function (){
                backend.whenGET('/svc/FeedbackCycle/GetMyCycles')
                    .respond(200, []);
                scope.init();
                backend.flush();
                expect(scope.cycles).toBeDefined();
            });
            it('Test 3 next should redirect user', function (){
                scope.next('test');
                expect(location.path).toHaveBeenCalledWith('/Profile/FeedbackSession/Request/test');
            });
        });
    });