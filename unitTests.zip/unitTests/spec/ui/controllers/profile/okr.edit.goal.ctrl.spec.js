define([
        'unitTests/ui-mocks/okr.cycle.json',
        'unitTests/ui-mocks/okr.add.goal.json',
        'unitTests/ui-mocks/okr.approve.json',
        'unitTests/ui-mocks/user.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(okrJson, okrAddGoalJson, approveJson, userJson) {

        describe('Okr edit goal controller spec --> ', function () {
            var scope,
                ctrl,
                backend,
                rootScope,
                goalSrvc,
                location,
                routeParams,
                timeout,
                q,
                window;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalSrvc, $templateCache) {
                $templateCache.put('templates/Hgapp/Profile/okr/okr-keyresults-weight-dlg.html', '<span></span>');
                $templateCache.put('template/modal/backdrop.html', '<span></span>');
                rootScope = $rootScope;
                goalSrvc = GoalSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                timeout = $injector.get("$timeout");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                window = $injector.get("$window");
                routeParams.memberId = 'test';
                routeParams.cycleId = 'test';
                routeParams.goalId = 'test';
                scope = $rootScope.$new();
                ctrl = $controller('OkrEditGoalCtrl', {$scope: scope});
            }));
            afterEach(function () {
                delete routeParams.memberId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 Okr edit goal controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 on init it should add empty key result', function () {
                backend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
                backend.whenGET('/svc/Goal/GetGoalById?gId=test')
                    .respond(200, approveJson.getDetails());
                backend.whenGET('/svc/Goal/GetAlignGoalCandidates?cycleId=test&participantId=3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864&participantType=Member')
                    .respond(200, []);
                backend.whenGET('/svc/GoalCycle/GetCycleById?CycleId=test')
                    .respond(200, okrAddGoalJson.getCycleById());
                backend.whenGET('/svc/Goal/GetCollaboratorsByGoalId?gId=test&searchTerm=&skip=0&take=10')
                    .respond(200, okrAddGoalJson.getCollaboratorsByGoalId());

                spyOn(goalSrvc, 'getGoalById').andCallThrough();
                scope.init();
                backend.flush();
                expect(goalSrvc.getGoalById).toHaveBeenCalled();
                expect(scope.model.KeyResults).toBeDefined();
            });
            it('Test 3 it should add keyResult to model key result array', function () {
                var model = scope.addKeyResult(okrAddGoalJson.getModel().KeyResults);
                expect(model.length).toBe(2);
                expect(model[0].edit).toBeFalsy();
                expect(model[1].edit).toBeTruthy();
            });
            it('Test 4 it should remove first element in the array of key results', function (){
                var model = scope.removeKeyResult(okrAddGoalJson.getModel().KeyResults, 0);
                expect(model.length).toBe(0);
            });
            it('Test 5 it should set edit to false', function (){
                var model = okrAddGoalJson.getModel().KeyResults[0];
                expect(model.edit).toBeTruthy();
                model = scope.toggle(model);
                expect(model.edit).toBeFalsy();
            });
            it('Test 6 it should set edit to true', function (){
                var model = okrAddGoalJson.getModel().KeyResults[0];
                delete model.edit;
                model.Name = 'test';
                model = scope.toggle(model);
                expect(model.edit).toBeTruthy();
            });
            it('Test 7 it should call window.history.back', function (){
                spyOn(location, 'path').andCallFake(function(){});
                scope.goBack();
                expect(location.path).toHaveBeenCalled();
            });
            it('Test 8 it should not call backend service if model is invalid', function (){

                spyOn(goalSrvc, 'saveGoal').andCallThrough();
                var model = okrAddGoalJson.getModel();
                scope.save(model);
                expect(model.invalid).toBeTruthy();
                expect(model.invalidName).toBeTruthy();
                expect(goalSrvc.saveGoal).not.toHaveBeenCalled();
            });
            it('Test 9 it should not call save if request is invalid', function (){
                spyOn(goalSrvc, 'saveGoal').andCallThrough();
                var model = approveJson.getDetails();
                model.Name = '';
                scope.save(model);
                expect(model.invalid).toBeTruthy();
                expect(goalSrvc.saveGoal).not.toHaveBeenCalled();
            });
            it('Test 10 it should save goal if request is valid', function (){
                backend.whenPOST('/svc/Goal/SaveGoal')
                    .respond(200, {});
                spyOn(location, 'path').andCallFake(function(){});
                spyOn(goalSrvc, 'saveGoal').andCallThrough();
                spyOn(goalSrvc, 'clearCache').andCallThrough();
                var model = approveJson.getDetails();
                scope.save(model);
                backend.flush();
                timeout.flush();
                expect(goalSrvc.saveGoal).toHaveBeenCalled();
                expect(goalSrvc.clearCache).toHaveBeenCalled();
                expect(location.path).toHaveBeenCalled();
            });
            it('Test 11 it should toggle measure', function (){
                var model = okrAddGoalJson.getModel();
                model.KeyResults[0].Measure = 'Percentage';
                scope.toggleMeasure(model.KeyResults[0], 'Numeric');
                expect(model.KeyResults[0].Measure).toBe('Numeric');
            });
            it('Test 12 it should toggle measure', function (){
                var model = okrAddGoalJson.getModel();
                model.KeyResults[0].Measure = 'Numeric';
                scope.toggleMeasure(model.KeyResults[0], 'Percentage');
                expect(model.KeyResults[0].Measure).toBe('Percentage');
            });
            it('Test 13 it should not open dialog if model is invalid', function (){
                spyOn(goalSrvc, 'modalOpen').andCallThrough();
                var model = okrAddGoalJson.getModel();
                scope.editGoalWeight(model);
                expect(model.invalid).toBeTruthy();
                expect(model.KeyResults[0].invalid).toBeTruthy();
                expect(goalSrvc.modalOpen).not.toHaveBeenCalled();
            });
            it('Test 14 it should  open dialog if model is valid', function (){
                spyOn(goalSrvc, 'saveGoal').andCallThrough();
                spyOn(goalSrvc, 'modalOpen').andCallThrough();
                var model = okrAddGoalJson.getModel();
                model.Name = 'test';
                model.CycleId = 'test';
                model.KeyResults[0].Name = 'test';
                model.AlignedGoal = okrAddGoalJson.getAlignGoalCandidates()[0];
                scope.editGoalWeight(model);
                expect(goalSrvc.modalOpen).toHaveBeenCalled();
            });
           it('Test 15 it should not call save if request is invalid', function (){
                spyOn(goalSrvc, 'saveGoal').andCallThrough();
                var model = okrAddGoalJson.getModel();
                model.KeyResults[0].Measure = 'Numeric';
                delete model.KeyResults[0].Target;
                scope.save(model);
                expect(model.invalid).toBeTruthy();
                expect(model.KeyResults[0].invalidTarget).toBeTruthy();
                expect(goalSrvc.saveGoal).not.toHaveBeenCalled();
            });
            it('Test 16 it should call save if request is valid', function (){
                backend.whenPOST('/svc/Goal/SaveGoal')
                    .respond(200, {});
                spyOn(goalSrvc, 'saveGoal').andCallThrough();
                var model = approveJson.getDetails();
                model.KeyResults[0].Measure = 'Numeric';
                model.KeyResults[0].Target = 1;
                model.Name = 'test';
                model.KeyResults[0].Name = 'test';
                scope.save(model);
                backend.flush();
                expect(goalSrvc.saveGoal).toHaveBeenCalled();
            });
            it('Test 17 it should toggle and clear key results description', function (){
                var model = okrAddGoalJson.getModel();
                model.KeyResults[0].Description = 'This is a key result description.';
                scope.hideAndClearResultDescription(model.KeyResults[0]);
                expect(model.KeyResults[0].Description).toBeNull();
                expect(model.KeyResults[0].showResultDescription).not.toBe(true);
            });
            it('Test 18 it should toggle and clear key results due date', function (){
                var model = okrAddGoalJson.getModel();
                model.KeyResults[0].DueDate = '1454047200000';
                scope.hideAndClearDueDate(model.KeyResults[0]);
                expect(model.KeyResults[0].DueDate).toBeNull();
                expect(model.KeyResults[0].showKrDueDate).not.toBe(true);
            });
            it('Test 19 it should toggle and clear key results measure', function (){
                var model = okrAddGoalJson.getModel();
                model.KeyResults[0].Measure = 'Numeric';
                scope.hideAndClearMeasure(model.KeyResults[0]);
                expect(model.KeyResults[0].Measure).toBe('Binary');
                expect(model.KeyResults[0].isPercentage).not.toBe(true);
                expect(model.KeyResults[0].Target).toBeNull();
            });
        });
    });
