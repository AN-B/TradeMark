define(['unitTests/ui-mocks/okr.cycle.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(okrJson){

        describe('Okr approve list controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                rootScope,
                goalSrvc,
                location,
                routeParams,
                timeout,
                q,
                window;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalSrvc, $templateCache) {
                rootScope = $rootScope;
                goalSrvc = GoalSrvc;
                location = $injector.get("$location");
                timeout = $injector.get("$timeout");
                q = $injector.get("$q");
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                backend.whenGET('/svc/Goal/GetCycleOverviewByMemberId?memberId=test')
                    .respond(200, okrJson.getOverview());
                backend.whenGET('/svc/Goal/GetMyApprovalByPetitioner?skip=0&take=10')
                    .respond(200, []);
                backend.whenGET('/svc/Goal/GetMyApprovalByPetitioner?search=&skip=0&take=10')
                    .respond(200, []);
                backend.whenGET('/svc/Goal/GetMyApprovalByPetitioner?search=123&skip=0&take=10')
                    .respond(200, []);
                routeParams.approverId = 'test';
                scope = $rootScope.$new();
                ctrl = $controller('OkrApproveListCtrl', {$scope: scope});
            }));
            afterEach(function () {
                delete routeParams.memberId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 Okr approve list controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 Okr init should call getCycleOverviewByMemberId and getGoalsToApprove', function (){
                spyOn(goalSrvc, 'getGoalsToApprove').andCallThrough();
                spyOn(goalSrvc, 'getCycleOverviewByMemberId').andCallThrough();
                ctrl.init();
                backend.flush();
                expect(ctrl.nav.links).toBeDefined();
                expect(goalSrvc.getCycleOverviewByMemberId).toHaveBeenCalled();
                expect(goalSrvc.getGoalsToApprove).toHaveBeenCalled();
            });
            it('Test 3 Okr search should not call backend if search term length is 1 characters', function (){
                spyOn(goalSrvc, 'getGoalsToApprove').andCallThrough();
                ctrl.search('t');
                expect(goalSrvc.getGoalsToApprove).not.toHaveBeenCalled();
            });
            it('Test 4 Okr search should not call backend if search term length is 2 characters', function (){
                spyOn(goalSrvc, 'getGoalsToApprove').andCallThrough();
                ctrl.search('te');
                expect(goalSrvc.getGoalsToApprove).not.toHaveBeenCalled();
            });
            it('Test 5 Okr search should call backend if search term is empty', function (){
                spyOn(goalSrvc, 'getGoalsToApprove').andCallThrough();
                ctrl.search('');
                timeout.flush();
                backend.flush();
                expect(goalSrvc.getGoalsToApprove).toHaveBeenCalled();
            });
            it('Test 6 Okr search should call backend if search term length is greater than 2 characters', function (){
                spyOn(goalSrvc, 'getGoalsToApprove').andCallThrough();
                ctrl.search('123');
                timeout.flush();
                backend.flush();
                expect(goalSrvc.getGoalsToApprove).toHaveBeenCalled();
            });
            it('Test 7 on bottom scroll event it should call getGoalsToApprove', function (){
                spyOn(goalSrvc, 'getGoalsToApprove').andCallThrough();
                scope.$broadcast('bottomScroll');
                timeout.flush();
                backend.flush();
                expect(goalSrvc.getGoalsToApprove).toHaveBeenCalled();
            });
        });
    });
