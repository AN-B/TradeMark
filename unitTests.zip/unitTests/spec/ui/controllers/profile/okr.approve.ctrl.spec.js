define([
        'unitTests/ui-mocks/okr.cycle.json',
        'unitTests/ui-mocks/okr.approve.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(okrJson, approveJson){

        describe('Okr approve controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                rootScope,
                goalSrvc,
                location,
                routeParams,
                timeout,
                q,
                goalsAdminSrvc,
                uiservice;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, GoalSrvc, GoalsAdminSrvc, okrCycleViewSrvc) {
                rootScope = $rootScope;
                uiservice = okrCycleViewSrvc;
                goalSrvc = GoalSrvc;
                goalsAdminSrvc = GoalsAdminSrvc;
                location = $injector.get("$location");
                q = $injector.get("$q");
                timeout = $injector.get('$timeout');
                routeParams = $injector.get("$routeParams");
                backend = $injector.get("$httpBackend");
                backend.whenGET('/svc/Goal/GetCycleOverviewByMemberId?memberId=test')
                    .respond(200, okrJson.getOverview());
                backend.whenGET('/svc/Member/GetMemberByMemberId?MemberId=test')
                    .respond(200, {});

                backend.whenGET('/svc/Goal/GetMyApprovalFromPetitioner?mId=test')
                    .respond(200, approveJson.getMemberApproval());
                backend.whenGET('/svc/Goal/GetGoalByIdForApproval?gId=test')
                    .respond(200, approveJson.getDetails());
                backend.whenPOST('/svc/Goal/ApproveSet')
                    .respond(200, {});
                backend.whenPOST('/svc/Goal/RejectSet')
                    .respond(200, {});
                backend.whenGET('/svc/Goal/GetGoalWeightsByParticipant?pId=test')
                    .respond(200, {CycleId: 'test'});

                routeParams.approverId = 'test';
                routeParams.pId = 'test';
                scope = $rootScope.$new();
                ctrl = $controller('OkrApproveCtrl', {$scope: scope});
            }));
            afterEach(function () {
                delete routeParams.approverId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 Okr cycle view controller should exist', function (){
                expect(ctrl).toBeDefined();
                expect(ctrl.setEqual).toBe(uiservice.setEqual);
            });
            it('Test 2 Okr length of nav links should be 3', function (){
                spyOn(goalSrvc, 'getGoalsToApproveByMemberId').andCallThrough();
                spyOn(goalSrvc, 'getCycleOverviewByMemberId').andCallFake(function(){
                    var apr = okrJson.getOverview(),
                        deferred = q.defer();
                    delete apr.IndividualCycleNumber;
                    deferred.resolve(apr);
                    return deferred.promise;
                });
                scope.path = '/ApproveGoals/';
                ctrl.init();
                scope.$digest();
                backend.flush();
                expect(goalSrvc.getGoalsToApproveByMemberId).toHaveBeenCalledWith('test');
                expect(ctrl.nav.links.length).toBe(3);
            });
            it('Test 3 getGoalDetails should call getGoalByIdForApproval', function (){
                spyOn(goalSrvc, 'getGoalByIdForApproval').andCallThrough();
                ctrl.getGoalDetails({GoalId: 'test'});
                scope.$digest();
                backend.flush();
                expect(goalSrvc.getGoalByIdForApproval).toHaveBeenCalledWith('test');
                expect(ctrl.model.goalDetails.CycleId).toBe('9c5c50f0-f5bc-11e4-9874-fdfdf272338f');
            });

            it('Test 4 getWeightDetails should call getGoalsWeightToApprove', function (){
                spyOn(goalSrvc, 'getGoalsWeightToApprove').andCallThrough();
                ctrl.getWeightDetails({ParticipantHgId: 'test'});
                scope.$digest();
                backend.flush();
                expect(goalSrvc.getGoalsWeightToApprove).toHaveBeenCalledWith('test');
                expect(ctrl.model.wDetails.CycleId).toBe('test');
            });
            it('Test 5 it should get call approveSet', function (){
                spyOn(goalsAdminSrvc, 'approveSet').andCallThrough();
                ctrl.cycles = approveJson.getModel();
                ctrl.approveSet({hgId: 'test', CycleId: 'test'});
                scope.$digest();
                backend.flush();
                expect(goalsAdminSrvc.approveSet).toHaveBeenCalledWith('test');
            });

            it('Test 6 it should not call service if request is invalid', function (){
                spyOn(goalsAdminSrvc, 'rejectSet').andCallThrough();
                ctrl.cycles = approveJson.getModel();
                var request = {};
                ctrl.rejectSet(request, {hgId: 'test', CycleId: 'test'});
                expect(request.invalid).toBeTruthy();
            });

            it('Test 7 it should call service if request is valid', function (){
                spyOn(goalsAdminSrvc, 'rejectSet').andCallThrough();
                var request = {note: 'test'};
                ctrl.cycles = approveJson.getModel();
                ctrl.rejectSet(request, {hgId: 'test', CycleId: 'test'});
                backend.flush();
                expect(goalsAdminSrvc.rejectSet).toHaveBeenCalled();
            });

            it('Test 8 it should call backend approveClosure service', function (){
                backend.whenPOST('/svc/Goal/ApproveClose')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'approveClose').andCallThrough();
                ctrl.cycles = approveJson.getModel();

                ctrl.approveClosure({hgId: 'test', CycleId: 'test'});
                backend.flush();
                expect(goalsAdminSrvc.approveClose).toHaveBeenCalledWith('test');
            });

            it('Test 9 it should call backend rejectClosure service', function (){
                backend.whenPOST('/svc/Goal/RejectClosure')
                    .respond(200, {});
                spyOn(goalsAdminSrvc, 'rejectClose').andCallThrough();
                ctrl.cycles = approveJson.getModel();
                var request = {note: 'test'};
                ctrl.rejectClosure(request, {hgId: 'test', CycleId: 'test'});
                backend.flush();
                expect(goalsAdminSrvc.rejectClose).toHaveBeenCalled();
            });


            it('Test 10 rejectWeighting should call rejectWeighting', function (){
                backend.whenPOST('/svc/Goal/RejectWeighting')
                    .respond(200, {});
                spyOn(goalSrvc, 'rejectWeighting').andCallThrough();
                ctrl.cycles = approveJson.getModel();
                ctrl.rejectWeighting({note: 'test'}, {hgId: 'test', CycleId: 'test'});
                backend.flush();
                expect(goalSrvc.rejectWeighting).toHaveBeenCalled();
            });

            it('Test 11 rejectWeighting should not call rejectWeighting', function (){
                spyOn(goalSrvc, 'rejectWeighting').andCallThrough();
                ctrl.cycles = approveJson.getModel();
                ctrl.rejectWeighting({note: ''}, {hgId: 'test', CycleId: 'test'});
                expect(goalSrvc.rejectWeighting).not.toHaveBeenCalled();
            });

            it('Test 12 approveWeighting should call UI service approveWeighting', function (){
                backend.whenPOST('/svc/Goal/ApproveWeighting')
                    .respond(200, {});
                spyOn(goalSrvc, 'approveWeighting').andCallThrough();
                ctrl.cycles = approveJson.getModel();
                ctrl.approveWeighting({hgId: 'test', CycleId: 'test', goals: []});
                backend.flush();
                expect(goalSrvc.approveWeighting).toHaveBeenCalled();
            });

            it('Test 13 approveWeighting should not call UI service approveWeighting', function (){
                spyOn(goalSrvc, 'approveWeighting').andCallThrough();
                ctrl.cycles = approveJson.getModel();
                ctrl.approveWeighting({invalid: true});
                expect(goalSrvc.approveWeighting).not.toHaveBeenCalled();
            });

            it('Test 14 model.total should be 6', function (){
                var model = ctrl.getTotalWeight({goals: [{Weight: 1}, {Weight: 2}, {Weight: 3}]});
                expect(model.total).toBe(6);
            });

            it('Test 15 goalWeightChanged  should set isDirty true', function (){
                var model = ctrl.goalWeightChanged({goals: [{Weight: 1}, {Weight: 2}, {Weight: 3}]});
                expect(model.isDirty).toBeTruthy();
            });

            it('Test 16 toggleType should set type', function (){
                var model = ctrl.toggleType({goals: [{Weight: 1}, {Weight: 2}, {Weight: 3}]});
                expect(model.type).toBe('Custom');
            });

            it('Test 17 toggleType should set type', function (){
                var model = ctrl.toggleType({goals: [{Weight: 1}, {Weight: 2}], type: 'Custom'});
                expect(model.type).toBe('Equal');
                expect(model.goals[0].Weight).toBe(50);
            });

        });
    });
