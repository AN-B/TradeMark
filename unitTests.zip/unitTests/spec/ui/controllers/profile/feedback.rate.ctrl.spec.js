define(['angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(){

        describe('feedback rate controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                service,
                cycleService,
                location,
                toastr,
                routeParams;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, feedbackSessionServiceSrvc, FeedbackCycleSrvc, ToastrSrvc) {
                toastr = ToastrSrvc;
                service = feedbackSessionServiceSrvc;
                cycleService = FeedbackCycleSrvc;
                location = $injector.get("$location");
                routeParams = $injector.get("$routeParams");
                q = $injector.get("$q");
                backend = $injector.get("$httpBackend");
                scope = $rootScope.$new();
                routeParams.sessionId = "test";
                backend.whenGET('/svc/FeedbackSession/GetSessionById?sId=test')
                    .respond(200, {});
                backend.whenGET('/svc/FeedbackCycle/GetSessionTipMode')
                    .respond(200, {});

                backend.whenPOST('/svc/FeedbackSession/RateReceivedSession').respond(200, {});
                ctrl = $controller('FeedbackRateCtrl', {$scope: scope});
                spyOn(location, 'path').andCallFake(function(){});
            }));
            afterEach(function () {
                delete routeParams.sessionId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2', function (){
                spyOn(service, 'getSessionById').andCallThrough();
                scope.init();
                backend.flush();
                expect(scope.feedback).toBeDefined();
                expect(service.getSessionById).toHaveBeenCalled();
            });
            it('Test 2 submit valid request w/o rating and note', function (){
                spyOn(service, 'rateReceivedSession').andCallThrough();
                scope.rate({});
                backend.flush();
                expect(service.rateReceivedSession).toHaveBeenCalled();
            });
            it('Test 3 submit valid request', function (){
                spyOn(service, 'rateReceivedSession').andCallThrough();
                scope.rate({note: 'test', subjectRating: 'something'});
                backend.flush();
                expect(service.rateReceivedSession).toHaveBeenCalled();
            });

        });
    });