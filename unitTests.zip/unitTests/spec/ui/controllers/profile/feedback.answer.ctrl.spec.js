define(['unitTests/ui-mocks/feedback.item',
        'unitTests/ui-mocks/session.feedback.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function(mock, sectionMock){

        describe('feedback answer controller spec --> ', function() {
            var scope,
                ctrl,
                backend,
                service,
                cycleService,
                location,
                toastr,
                routeParams,
                request = {};
            function getRequest() {
                return {
                    Questions: [
                        {
                            Required: true,
                            Type: 'ShortAnswer',
                            Answer: {
                                Text:'',
                                SelectedValues: []
                            }
                        }, {
                            Required: true,
                            Type: 'Options',
                            Answer: {
                                Text:'',
                                SelectedValues: []
                            }
                        }
                    ]
                };
            }
            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, feedbackSessionServiceSrvc, FeedbackCycleSrvc, ToastrSrvc) {
                toastr = ToastrSrvc;
                service = feedbackSessionServiceSrvc;
                cycleService = FeedbackCycleSrvc;
                location = $injector.get("$location");
                routeParams = $injector.get("$routeParams");
                q = $injector.get("$q");
                backend = $injector.get("$httpBackend");
                scope = $rootScope.$new();
                backend.whenGET('/svc/FeedbackSession/GetSessionById?sId=test')
                    .respond(200, mock.get());
                backend.whenPOST('/svc/FeedbackSession/SubmitSession')
                    .respond(200, mock.get());
                backend.whenPOST('/svc/FeedbackSession/AnswerAndSave')
                    .respond(200, mock.get());
                routeParams.sessionId = "test";
                ctrl = $controller('FeedbackAnswerCtrl', {$scope: scope});
                scope.feedback = {CycleType: 'Request'};
                spyOn(location, 'path').andCallFake(function(){});
            }));
            afterEach(function () {
                delete routeParams.sessionId;
                scope.$digest();
                backend.verifyNoOutstandingExpectation();
                backend.verifyNoOutstandingRequest();
            });
            it('Test 1 controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 init should call get session by id', function (){
                spyOn(service, 'getSessionById').andCallThrough();
                scope.init();
                backend.flush();
                expect(scope.feedback.hgId).toBeDefined();
                expect(service.getSessionById).toHaveBeenCalledWith('test');
            });
            it('Test 3 should send valid request', function (){
                spyOn(service, 'submitSession').andCallThrough();
                var request = getRequest();
                request.Questions[0].Answer.Text = 'test';
                request.Questions[1].Answer.SelectedValues = [1, 2, 3];
                scope.send(request);
                backend.flush();
                expect(service.submitSession).toHaveBeenCalled();
                expect(location.path).toHaveBeenCalledWith('/Profile/FeedbackSession/Feedback/Inbox');
            });
            it('Test 4 should not send invalid request', function (){
                spyOn(service, 'submitSession').andCallThrough();
                var request = getRequest();
                scope.send(request);
                expect(service.submitSession).not.toHaveBeenCalled();
            });
            it('Test 5 it should call answerAndSave if request is valid ', function (){
                spyOn(service, 'answerAndSave').andCallThrough();
                var request = getRequest().Questions[0];
                request.Answer.Text = 'test';
                scope.reviewSession(request);
                backend.flush();
                expect(service.answerAndSave).toHaveBeenCalled();
                expect(location.path).toHaveBeenCalledWith('/Profile/Feedback/Review/test');
            });
            it('Test 6 it should not call answerAndSave if request is invalid ', function (){
                spyOn(service, 'answerAndSave').andCallThrough();
                var request = getRequest().Questions[0];
                scope.reviewSession(request);
                expect(service.answerAndSave).not.toHaveBeenCalled();
            });
            it('Test 7 it should redirect user if index is 0', function (){
                var model = {index: 0};
                model = scope.back(model);
                expect(location.path).toHaveBeenCalledWith('/Profile/FeedbackSession/Feedback/Inbox');
            });
            it('Test 8 it should decrement index', function (){
                var model = {index: 1};
                model = scope.back(model);
                expect(model.index).toBe(0);
            });
            it('Test 9 it should call answer and save ', function (){
                spyOn(service, 'answerAndSave').andCallThrough();
                var request = getRequest().Questions[0];
                request.Answer.Text = 'test';
                scope.next(request);
                backend.flush();
                expect(service.answerAndSave).toHaveBeenCalled();
                expect(scope.model.index).toBe(1);
            });
            it('Test 10 it should not call answer and save ', function (){
                spyOn(service, 'answerAndSave').andCallThrough();
                var request = getRequest().Questions[0];
                scope.next(request);
                expect(service.answerAndSave).not.toHaveBeenCalled();
                expect(scope.model.index).toBe(0);
            });

            it('Test 11 should send valid request', function (){
                spyOn(service, 'submitSession').andCallThrough();
                var request = sectionMock.getSectionFeedback().Card;
                request.Sections[0].Questions[0].Answer.Text = 'test';
                request.Sections[0].Questions[1].Answer.Text = 'test';
                request.Sections[1].Questions[0].Answer.Text = 'test';
                request.Sections[1].Questions[1].Answer.Text = 'test';
                scope.send(request);
                backend.flush();
                expect(service.submitSession).toHaveBeenCalled();
            });
            it('Test 12 should not send invalid request', function (){
                spyOn(service, 'submitSession').andCallThrough();
                var request = sectionMock.getSectionFeedback().Card;
                scope.send(request);
                expect(service.submitSession).not.toHaveBeenCalled();
                expect(request.invalid).toBeTruthy();
            });

            it('Test 13 it should not call answerAndSave if request is invalid ', function (){
                spyOn(service, 'answerAndSave').andCallThrough();
                var request = sectionMock.getSectionFeedback().Card;
                scope.saveAndExit(request);
                expect(service.answerAndSave).not.toHaveBeenCalled();
            });
            it('Test 14 it should not call answerAndSave if request is invalid ', function (){
                spyOn(service, 'answerAndSave').andCallThrough();
                var request = sectionMock.getSectionFeedback().Card;
                request.Sections[0].Questions[0].Answer.Text = 'test';
                request.Sections[0].Questions[1].Answer.Text = 'test';
                request.Sections[1].Questions[0].Answer.Text = 'test';
                request.Sections[1].Questions[1].Answer.Text = 'test';
                scope.saveAndExit(request);
                backend.flush();
                expect(service.answerAndSave).toHaveBeenCalled();
            });
        });
    });
