define(['unitTests/ui-mocks/group.json',
        'unitTests/ui-mocks/teams.json',
        'unitTests/ui-mocks/recognition.templates.json',
        'unitTests/ui-mocks/recognition.request.object.json',
        'unitTests/ui-mocks/badge.json',
        'unitTests/ui-mocks/user.json',
        'unitTests/ui-mocks/dto.service.json',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function (groupJson, teamsJson, templatesJson, recJson, badgeJson, userJson, dtoJson) {

        describe('Give value recognition controller spec -> ', function () {
            var scope,
                ctrl,
                timeout,
                rootScope,
                httpBackend,
                service,
                routeParams,
                count = 0,
                testCount = function () {
                    count += 1;
                    return 'Test ' + count + ': ';
                };

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-controllers"));
            beforeEach(inject(function ($injector, $controller, $rootScope, RecognitionSrvc, $routeParams, UserSrvc) {
                routeParams = $routeParams;
                service = RecognitionSrvc;
                timeout = $injector.get("$timeout");
                rootScope = $rootScope;
                httpBackend = $injector.get("$httpBackend");
                UserSrvc.clearUserCache();
                httpBackend.whenGET('/svc/Recognition/GetUserValueRecognitionTemplates')
                    .respond(200, templatesJson.getValue());
                httpBackend.whenGET('/svc/User/Login')
                    .respond(200, userJson.getCu());
                httpBackend.whenGET('/svc/UI/GetRecipientCandidates')
                    .respond(200, dtoJson.getRecipients());
                httpBackend.whenPOST('/svc/Recognition/GiveValueRecognition')
                    .respond(200, 'Value');
                scope = $rootScope.$new();
                ctrl = $controller('GiveValueCtrl', {$scope: scope});
                scope.imageStoreBadges = 'img';
                scope.flags = {FriendlyGroupId: 300};
                scope.imageVersion = 123;
            }));
            afterEach(function () {
                scope.$digest();
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });
            it('Test 1: Recognition  controller should exist', function () {
                expect(ctrl).toBeDefined();
            });
            it('Test 2: global variable should be initialized', function () {
                expect(scope.hideRecognitions).toBeFalsy();
            });
            it('Test 3: should call initRec()', function () {
                scope.getTemplates();
                scope.initRec();
                httpBackend.flush();
                expect(scope.templates.length).toBe(1);
                expect(scope.templatesSubValues.length).toBe(8);
                expect(scope.Levels.length).toBe(3);
                expect(scope.search.userMeta.type).toBe('MemberAndDepartmentandLocation');
                expect(scope.search.userMeta.selected.length).toBe(0);
                expect(scope.flags.FriendlyGroupId).toBe(500);
            });

            it('Test 4: should call service method giveValueRec if request is valid and gift stock >= number of recipients', function () {
                scope.initRec(recJson.getValue());
                scope.request.Recipients.totalNumRecipients = 1;
                scope.giftStock = 1;
                httpBackend.flush();
                spyOn(service, 'giveValueRec').andCallThrough();
                spyOn(scope, 'clear').andCallThrough();
                scope.giveRecognition();
                httpBackend.flush();
                expect(service.giveValueRec).toHaveBeenCalled();
                expect(scope.clear).toHaveBeenCalled();
            });
            it('Test 5: should not call service method giveValueRec if request is invalid or gift stock < number of recipients', function () {
                scope.request = recJson.getValue();
                scope.getTemplates();
                scope.initRec(scope.request);
                scope.request.Recipients.totalNumRecipients = 2;
                scope.giftStock = 1;
                httpBackend.flush();
                scope.request.Level = '';
                scope.flags.IsLevelOn = true;
                spyOn(service, 'giveValueRec').andCallThrough();
                spyOn(scope, 'clear').andCallThrough();
                scope.giveRecognition();
                expect(service.giveValueRec).not.toHaveBeenCalled();
                expect(scope.clear).not.toHaveBeenCalled();
            });
            it('Test 6: toggleRec should toggle recognition selection in request and meta', function () {
                scope.getTemplates();
                scope.initRec(recJson.getValue());
                httpBackend.flush();
                scope.toggleRec('c4c5brt0-3da8-11e3-8e3f-3b48bfc048fd');
                expect(scope.request.Template.hgId).toBe('c4c5brt0-3da8-11e3-8e3f-3b48bfc048fd');
                expect(scope.request.Template.Selected).toBeTruthy();
            });
            it('Test 7: toggleSubValue should toggle recognition selection in request and meta', function () {
                scope.getTemplates();
                scope.initRec(recJson.getValue());
                httpBackend.flush();
                scope.toggleSubValue('ba2b5950-3da8-11e3-8e3f-3b48bfc048fd', '5107ders-fbab-11e2-bad3-999e6df490a1');
                expect(scope.request.Template.hgId).toBe('ba2b5950-3da8-11e3-8e3f-3b48bfc048fd');
                expect(scope.request.Template.SubValue).toBeDefined();
                expect(scope.request.Template.SubValues.length).toBe(10);
            });
            it('Test 8: toggleLevels should toggle levels', function () {
                scope.getTemplates();
                scope.initRec();
                httpBackend.flush();
                scope.toggleLevels('Gold');
                expect(scope.request.Level).toBe('Gold');
                expect(scope.Levels[1].Selected).toBeTruthy();
                scope.toggleLevels('Silver');
                expect(scope.request.Level).toBe('Silver');
                expect(scope.Levels[0].Selected).toBeTruthy();
                expect(scope.Levels[1].Selected).toBeFalsy();
            });
            it('Test 9: should call service method giveValueRec if Levels and request.level are empty', function () {
                scope.initRec(recJson.getValue());
                scope.request.Recipients.totalNumRecipients = 1;
                scope.giftStock = 100;
                httpBackend.flush();
                scope.request.Level = '';
                scope.Levels = [];
                spyOn(service, 'giveValueRec').andCallThrough();
                spyOn(scope, 'clear').andCallThrough();
                scope.giveRecognition();
                httpBackend.flush();
                expect(service.giveValueRec).toHaveBeenCalled();
                expect(scope.clear).toHaveBeenCalled();
            });
            it('Test 11: clear() should call cache.clear, service.clearRecognitionTemplateCache and broadcast to hide recognitions ', function () {
                spyOn(service, 'clearRecognitionTemplateCache').andCallThrough();
                spyOn(rootScope, '$broadcast').andCallThrough();
                scope.clear();
                expect(service.clearRecognitionTemplateCache).toHaveBeenCalledWith('Values');
                expect(rootScope.$broadcast).toHaveBeenCalledWith('hideRecognitions');
            });
            it('Test 12: should resolve recipient if member id is passed', function () {
                routeParams.memberId = 'c15985d0-aea6-11e2-b79d-512ef31a350a';
                scope.initRec();
                httpBackend.flush();
                expect(scope.enableSearch).toBeTruthy();
                expect(scope.search.userMeta.preSelected.length).toBe(1);
            });
        });
    });