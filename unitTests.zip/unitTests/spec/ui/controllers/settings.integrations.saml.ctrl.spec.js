define([
    'unitTests/ui-mocks/group.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'hgapp-app'], function (groupJson, userJson) {

    describe('SAML controller spec ->', function () {
        var scope,
            ctrl,
            httpBackend,
            rootScope;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($injector, $controller, $rootScope, UserSrvc) {
            rootScope = $rootScope;
            httpBackend = $injector.get('$httpBackend');

            UserSrvc.clearUserCache();

            httpBackend.whenGET('/svc/SSO/GetGroupSAML')
                .respond(200, {
                    "entryPoint": "bar",
                    "uploaded_at": "1409765416490",
                    "issuer": "foo",
                    "type": "Custom"
                });
            httpBackend.whenGET('/svc/SSO/GetSAMLProviders')
                .respond(200, {});
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());

            scope = $rootScope.$new();
            ctrl = $controller('AdminSettingsIntegrationsSAMLCtrl', {$scope: scope});
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 admin SAML controller should exist', function () {
            expect(ctrl).toBeDefined();
        });
        it('Test 2 init() should get current group', function () {
            scope.init();
            httpBackend.flush();
            expect(scope.groupProps).toBeDefined();
            expect(scope.groupProps.groupId).toBe(userJson.getCu().UserContext.CurrentGroupId);
            expect(scope.groupProps.certUploadedAt).toBe("1409765416490");
            expect(scope.selectedProvider).toEqual({
                name: 'Custom',
                issuer: 'foo',
                entryPoint: 'bar'
            });
        });
    });
});