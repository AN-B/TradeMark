define([
    'unitTests/ui-mocks/settings.departments.json',
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(settingDepartmentJson, userJson){

    describe('Admin Settings Departments controller spec ->', function() {
        var scope,
            ctrl,
            timeout,
            httpBackend,
            teamService,
            rootScope,
            toastrSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, TeamSrvc, ToastrSrvc) {
            teamService = TeamSrvc;
            toastrSrvc = ToastrSrvc;
            timeout = $injector.get("$timeout");
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            ctrl = $controller('AdminSettingsDepartmentsCtrl', {$scope: scope});

            httpBackend.whenGET('/svc/Team/GetDepartments')
                .respond(200, settingDepartmentJson.getAll());
            httpBackend.whenGET('/svc/Team/DeleteDepartment?Id='+ settingDepartmentJson.getAll()[0].hgId)
                .respond(200, 'Department Deleted');
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());

        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 Admin Settings Departments controller should exist', function (){
            expect(ctrl).toBeDefined();
        });

        it('Test 2 init() should call backend', function (){
            scope.init();
            httpBackend.flush();
            expect(scope.model.departments.length).toBe(2);
        });

        it('Test 3 deleteDepartment() should delete the department if it has no department or members in it', function (){
            scope.model.departments = settingDepartmentJson.getAll();
            spyOn(teamService,'deleteDepartment').andCallThrough();
            spyOn(toastrSrvc, 'success').andCallThrough();
            scope.deleteDepartment(settingDepartmentJson.getAll()[0].hgId);
            httpBackend.flush();
            expect(teamService.deleteDepartment).toHaveBeenCalled();
            expect(toastrSrvc.success).toHaveBeenCalledWith('admin.set.dept.ded');
        });

        it('Test 4 selectDepartment() should show details of the department that is selected', function (){
            scope.search.userMeta = {preSelected: []};
            scope.model.departments = settingDepartmentJson.getAll();
            scope.selectDepartment(settingDepartmentJson.getAll()[0].hgId);
            expect(scope.model.showDeleteButtonFlag).toBe(true);
        });
    });
});
