define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'], function(){
    describe('Permission filter spec ->', function() {
        var permissionsFlt,
            arr1 = [{Name: "Bob"}, {Name: "Bill"}, {Name: "Dori"}, {Name: "Mary"}, {Name: "Berry"}, {Name: "Harry"}],
            arr2 = [{Name: "Dori"}],
            arr3 = [{Name: "Bill"}];

        beforeEach(module("provision-app"));
        beforeEach(module("provision-filters"));
        beforeEach(inject(function ($compile, $injector, $filter) {
            permissionsFlt = $filter('permissionsFlt');
        }));
        it('Test 1 filter should be defined', function() {
            expect(permissionsFlt).toBeDefined();
        });
        it('Test 2 filter', function() {
            var test = permissionsFlt(arr1, "Bo", arr2, arr3);
            expect(test[0]).toBeDefined();
            expect(test[0].Name).toBe("Bob");
        });
        it('Test 3 filter', function() {
            var test = permissionsFlt(arr1, "", arr2, arr3);
            expect(test.length).toBeFalsy();
        });

    });
});