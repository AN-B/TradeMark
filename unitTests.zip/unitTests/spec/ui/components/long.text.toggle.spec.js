define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){
    describe('text toggle component spec - > ', function() {
        var scope,
            cmp,
            cmpCtrl;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp.components"));
        beforeEach(inject(function ($templateCache, $rootScope, $componentController) {
            $templateCache.put('templates/shared/tag-content-editable.html',
                '<div class="title" ng-bind="textVal | ellipses: model.minLen">'
                + '</div><button type="button" ng-click="toggle(model)"'
                + 'translate="{{model.more? \'common.les\': \'common.mor\'}}"></button>');
            cmpCtrl = $componentController;
            scope = $rootScope.$new();
        }));

        it('Test 1 component should be initialized', function(){
            cmp = cmpCtrl('textToggle', {$scope: scope}, {minLen: 10, textVal: 'test'});
            expect(cmp.model.minLen).toBe(10);
        });
        it('Test 2 toggle should set less to true', function(){
            cmp = cmpCtrl('textToggle', {$scope: scope}, {minLen: 2, textVal: 'long text'});
            cmp.toggle(cmp.model);
            expect(cmp.model.less).toBeTruthy();
            expect(cmp.model.minLen).toBe(9);
        });
        it('Test 3 toggle should set less to false', function(){
            cmp = cmpCtrl('textToggle', {$scope: scope}, {minLen: 2, textVal: 'long text'});
            cmp.model.less = true;
            cmp.model.minLen = 9;
            cmp.toggle(cmp.model);
            expect(cmp.model.less).toBeFalsy();
            expect(cmp.model.minLen).toBe(2);
        });

    });
});
