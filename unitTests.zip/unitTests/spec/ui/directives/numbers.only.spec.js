define(['jquery',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(jquery, angular){

    describe('numbers only directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope) {
            rootScope = $rootScope;
            compile = $compile;
            scope = rootScope.$new();
        }));
        it('Test 1 ', function() {
            scope.number = 1;
            elm = angular.element('<input type="text" ng-model="number" numbers-only/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.triggerHandler({type: 'keydown', which: 8});
            scope.$digest();
            expect(elm.controller('ngModel').$viewValue).toBe(1);
        });
        it('Test 2 ', function() {
            scope.number = 1;
            elm = angular.element('<input type="text" ng-model="number" numbers-only/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            var test = elm.triggerHandler({type: 'keydown', which: 46});
            scope.$digest();
            expect(elm.controller('ngModel').$viewValue).toBe(1);
        });
        it('Test 3 ', function() {
            scope.number = 1;
            elm = angular.element('<input type="text" ng-model="number" numbers-only="decimal"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.triggerHandler({type: 'keydown', which: 190});
            scope.$digest();
            expect(elm.controller('ngModel').$viewValue).toBe(1);
        });
        it('Test 4 ', function() {
            scope.number = 1;
            elm = angular.element('<input type="text" ng-model="number" numbers-only="decimal"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.triggerHandler({type: 'keydown', which: 45});
            scope.$digest();
            expect(elm.controller('ngModel').$viewValue).toBe(1);
        });
        it('Test 5 ', function() {
            scope.number = 1;
            elm = angular.element('<input type="text" ng-model="number" numbers-only="decimal"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.triggerHandler({type: 'keydown', which: 59});
            scope.$digest();
            expect(elm.controller('ngModel').$viewValue).toBe(1);
        });
        it('Test 6 ', function() {
            scope.number = 1;
            elm = angular.element('<input type="text" ng-model="number" numbers-only/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.triggerHandler({type: 'keydown', which: 50});
            scope.$digest();
            expect(elm.controller('ngModel').$viewValue).toBe(1);
        });
    });
});