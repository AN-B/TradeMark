define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('Search select directive spec - > ', function() {
		var scope, elm, meta, timeout, ctrl;

		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-directives"));

		beforeEach(inject(function($compile, $rootScope, $templateCache, $injector) {
			timeout = $injector.get("$timeout");
			scope = $rootScope.$new();
			$templateCache.put('templates/shared/search-directive.html', '<div>template</div>');
			elm = angular.element('<div search-select="meta" ng-model="model" event-name="testEvent"/>');
			$compile(elm)(scope);
            scope.model = [];
			scope.$digest();

			ctrl = elm.scope();
		}));
		it('Test 1 elm should be defined', function() {
			expect(elm).toBeDefined();
		});
        xit('Test 2 search should be hidden when given esc keydown', function() {
            expect(elm).toBeDefined();
            var e = $.Event('keydown');
            e.which = 27;

            angular.element(elm).triggerHandler(e);

            expect(scope.hideSearch).toBeTruthy();
        })
	});
});

