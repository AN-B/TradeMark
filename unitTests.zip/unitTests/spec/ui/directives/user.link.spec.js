define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){
    describe('user link spec - > ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            location,
            timeout;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($compile, $rootScope, $injector) {
            rootScope = $rootScope;
            compile = $compile;
            scope = rootScope.$new();
            location = $injector.get('$location');
            timeout = $injector.get('$timeout');
            elm = angular.element('<div user-link="test"></div>');
            compile(elm)(scope);
            scope.$digest();
            ctrl = elm.scope();
            spyOn(location, 'path').andCallFake(angular.noop);
        }));

        it('Test 1 directive should be initialized', function(){
            expect(elm).toBeDefined();
        });

        it('Test 2 on click it should redirect to user profile feed', function(){
            elm.triggerHandler('click');
            timeout.flush();
            expect(location.path).toHaveBeenCalledWith('/Profile/Feed/test');
        });

    });
});

