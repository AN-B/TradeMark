define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(angular){

    describe('body event listener directive spec --> ', function() {
        var scope, elm, $compile, doc;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($injector, $document) {
            doc = $document;
            scope = $injector.get('$rootScope');
            $compile = $injector.get('$compile');
            scope.noop = angular.noop;
            spyOn(doc, 'on').andCallThrough();
            elm = angular.element('<input type="text" body-event="noop" />');
            $compile(elm)(scope);
            scope.$digest();
        }));
        it('Test: 1 elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('Test: 2 elm it should register listener', function() {
            expect(elm).toBeDefined();
            expect(doc.on).toHaveBeenCalled();
        });
        it('Test: 3 elm it should remove listener on scope destroy', function() {
            spyOn(doc, 'off').andCallThrough();
            scope.$broadcast('$destroy');
            expect(doc.off).toHaveBeenCalled();
        });
    });
});