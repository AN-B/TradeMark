define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('avatar-src directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test';
            elm = angular.element('<div avatar-src="{{test}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/user/test.jpg?123');
        });
        it('Test 2 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test';
            elm = angular.element('<div avatar-src="{{test}}" version="223"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/user/test.jpg?223');
        });
        it('Test 3 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test';
            elm = angular.element('<div avatar-src="{{test}}" team version="223"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/team/test.jpg?223');
        });
        it('Test 4 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test';
            scope.ver = '223';
            elm = angular.element('<div avatar-src="{{test}}" company version="{{ver}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/company/profile/test.jpg?223');
        });
    });
});