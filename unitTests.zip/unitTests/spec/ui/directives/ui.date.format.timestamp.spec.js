define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
    describe('Directive to format timestamps into Date objects for ui-date picker', function() {
        beforeEach(module("hgapp-directives"));

        it('Test1: $formatting: should format the date correctly from a timestamp', function () {
            inject(function($compile, $rootScope) {
                var aDate,
                    aTimestamp,
                    elm,
                    scope = $rootScope.$new();

                aDate = new Date();
                aTimestamp = aDate.getTime();
                scope.aTimestamp = aTimestamp;
                elm = angular.element('<input ui-date-format-timestamp ng-model="aTimestamp"/>');
                $compile(elm)(scope);
                scope.$digest();

                //check that model has not been altered
                expect(scope.aTimestamp).toEqual(aTimestamp);
                //check that view value has been formatted as date
                expect(elm.controller('ngModel').$viewValue).toEqual(aDate.toString());
            });
        });
    });

});