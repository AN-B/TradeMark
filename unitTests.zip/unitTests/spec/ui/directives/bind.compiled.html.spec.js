define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){
    describe('bind compiled html spec - > ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($compile, $rootScope) {
            rootScope = $rootScope;
            compile = $compile;
            scope = rootScope.$new();
            scope.test = '<div>test</div>';
            elm = angular.element('<div bind-compiled-html="test"></div>');
            compile(elm)(scope);
            scope.$digest();
            ctrl = elm.scope();
        }));

        it('Test 1 directive should be initialized', function(){
            expect(elm).toBeDefined();
        });

    });
});

