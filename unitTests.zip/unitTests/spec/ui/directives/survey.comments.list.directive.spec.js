define([
    'unitTests/ui-mocks/user.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app',
], function (userJson) {
    describe('Survey Comments List Directive Spec', function () {
        var scope,
            rootScope,
            ctrl,
            httpBackend,
            routeParams,
            timeout,
            compile,
            surveySrvc;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-controllers'));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/shared/driver-comments.html', '<div></div>');
        }));
        beforeEach(inject(function ($compile, $injector, $controller, $rootScope, UserSrvc, $routeParams) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            routeParams = $routeParams;
            httpBackend = $injector.get('$httpBackend');
            timeout = $injector.get('$timeout');
            compile = $compile;
            surveySrvc = $injector.get('SurveySrvc');
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyComments?currentRoundId=zoo&driverId=testId&recurrenceId=bar&skip=0&surveyId=foo&take=3')
                .respond(200, {comments: ['test1', 'test2', 'test3'], count:4});

            surveySrvc.clearSurveyCache();
        }));

        function create() {
	        var element, compiledElement;
	        scope = rootScope.$new();
            scope.commentsListModel = {
                surveyId: 'foo',
                recurrenceId: 'bar',
                currentRoundId: 'zoo',
                driverId: 'testId',
                label: 'test'
            };
	        element = angular.element("<div survey-comments-list ng-model='commentsListModel'></div>");
	        compiledElement = compile(element)(scope);
	        scope.$digest();
            httpBackend.flush();
	        return compiledElement;
	    }

        it('Test 1: element should be defined', function () {
            var element = create();
			expect(element).toBeDefined();
            expect(scope.commentsModel).toBeDefined();
        });
        it('Test 2: scope.$watch should set commentsModel properties', function () {
            var element = create();
            expect(scope.label).toBeDefined();
            expect(scope.commentsModel.page).toBe(0);
            expect(scope.commentsModel.keyword).toBe(null);
            expect(scope.commentsModel.comments.length).toEqual(3);
            expect(scope.commentsModel.numComments).toEqual(4);
            expect(scope.commentsModel.hasNextPage).toBe(true);
        });
        it('Test 3: nextPage should retrieve next pagination of comments', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyComments?currentRoundId=zoo&driverId=testId&recurrenceId=bar&skip=3&surveyId=foo&take=3')
                .respond(200, {comments: ['paginationTest'], count:4});
            var element = create();
            scope.nextPage();
            httpBackend.flush();
            expect(scope.commentsModel.comments).toEqual(['paginationTest']);
            expect(scope.commentsModel.hasNextPage).toBe(false);
            expect(scope.commentsModel.page).toEqual(1);
        });
        it('Test 4: previousPage should retrieve previous pagination of comments', function () {
            var element = create();
            scope.commentsModel.page = 1;
            scope.commentsModel.comments = ['test'];
            scope.commentsModel.hasNextPage = false;
            scope.previousPage();
            timeout.flush();
            expect(scope.commentsModel.comments.length).toBe(3);
            expect(scope.commentsModel.hasNextPage).toBe(true);
            expect(scope.commentsModel.page).toEqual(0);
        });
        it('Test 5: search should reset timeout and retrieve comments', function () {
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyComments?currentRoundId=zoo&driverId=testId&keyword=testSearch&recurrenceId=bar&skip=0&surveyId=foo&take=3')
                .respond(200, {comments: ['test'], count:1});
            var element = create();
            scope.commentsModel.page = 1;
            scope.search('testSearch');
            timeout.flush();
            httpBackend.flush();
            timeout.flush();
            expect(scope.commentsModel.comments).toEqual(['test']);
            expect(scope.commentsModel.numComments).toEqual(1);
            expect(scope.commentsModel.page).toEqual(0);
       });
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });


    });
});
