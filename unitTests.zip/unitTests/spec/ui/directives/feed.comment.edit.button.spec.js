define([
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('feed comment edit  button directive spec - > ', function() {

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/Hgapp/Profile/partials/feed-comment-edit-btn.html',
                '<div ng-if="model.isEdit"' +
                'class="delete-hover edit-hover pull-left"' +
                'ng-click="toggleEdit(comment)">' +
                '</div>');
        }));
        it('Test 1 comment should not be editable if user role in group is admin',
            inject(function ($compile, $rootScope, $templateCache, $injector, GroupSrvc) {
                var backend = $injector.get("$httpBackend"),
                    timeout = $injector.get("$timeout");
                backend.whenGET('/svc/Group/GetCommentIntervalSetting')
                    .respond(200, {CommentEditInterval: 60000});
                backend.whenGET('/svc/User/Login')
                    .respond(200, {
                        hgId: 'test',
                        UserContext: {
                            RolesInGroup: []
                        }
                    });
                var scope = $rootScope.$new();
                scope.comment = {
                    CreatedDate: Date.now(),
                    UserId: 'test'
                };
                var elm = angular.element('<div feed-comment-edit-btn ng-model="comment"/>');
                spyOn(GroupSrvc, 'getCommentIntervalSetting').andCallThrough();
                $compile(elm)(scope);

                scope.$digest();
                backend.flush();
                timeout.flush();
                var ctrl = elm.scope();
                expect(GroupSrvc.getCommentIntervalSetting).toHaveBeenCalled();
                expect(ctrl.comment.isEdit).toBeFalsy();
            }));
    });
});

