define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('odometer directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
            $templateCache.put('templates/shared/odometer.html',
                    '<div class="odometer-container pull-left">"' +
                    '<div ng-if="!odometer.IEOdometer" ng-repeat="number in odometer.numbers track by $index" ng-class="number.cls" class="digit-container">' +
                    '<div class="digit-new"></div>' +
                    '</div>' +
                    '<label ng-if="odometer.IEOdometer" class="credit-label thin IE-Odometer">' +
                    '<span ng-bind="odometer.value"></span>' +
                    '</label>' +
                    '</div>');
        }));
        it('Test 1 if flag IE 9 it should display IE odometer label', function() {
            rootScope.IEFlags = {isIE9: true};
            scope = rootScope.$new();
            scope.model = {number: 1};
            elm = angular.element('<div odometer ng-model="model.number"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            var element = elm.find('label');
            expect(element.length).toBe(1);
            scope.model = {number: 22};
            scope.$digest();
            var element = elm.find('label');
            expect(element.length).toBe(1);
        });
        it('Test 2 it should display IE odometer label then remove this label', function() {
            rootScope.IEFlags = {isIE9: false};
            scope = rootScope.$new();
            scope.model = {number: 1};
            elm = angular.element('<div odometer ng-model="model.number"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            var element = elm.find('label');
            expect(element.length).toBe(1);
            scope.model = {number: 22};
            scope.$digest();
            var element = elm.find('label');
            expect(element.length).toBe(0);
        });
    });
});