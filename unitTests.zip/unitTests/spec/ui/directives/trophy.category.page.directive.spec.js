define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){

    describe('trophy category page directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            $compile,
            rootScope,
            timeout;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($injector, $rootScope) {
            timeout = $injector.get('$timeout');
            backend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            rootScope = $rootScope;
            $compile = $injector.get('$compile');
            elm = angular.element('<div trophy-category-page count="30" category="achievement" action="getAchievement"></div>');
            $compile(elm)(scope);
        }));
        it('Test 1 elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('Test 2 should display category paging ', function() {
            backend.whenGET('templates/shared/trophy-category-page.html').respond(200, '<div></div>');
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('count')).toBe('30');
            expect(elm.attr('category')).toBe('achievement');
        });
        it('Test 3 should go to next page ', function() {
            backend.whenGET('templates/shared/trophy-category-page.html').respond(200, '<div></div>');
            ctrl = elm.scope();
            scope.$digest();
            ctrl.goNext();
            expect(elm.attr('action')).toBe('getAchievement');
        });
        it('Test 4 should go to prev page ', function() {
            backend.whenGET('templates/shared/trophy-category-page.html').respond(200, '<div></div>');
            ctrl = elm.scope();
            scope.$digest();
            ctrl.goPrev();
            expect(elm.attr('action')).toBe('getAchievement');
        });
    });
});