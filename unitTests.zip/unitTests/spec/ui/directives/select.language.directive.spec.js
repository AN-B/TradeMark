define(['angular',
    'unitTests/ui-mocks/recognition.templates.json',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular, templatesJson){

    describe('select-language directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/shared/select-language-directive.html',
                '<span></span>');
        }));
        beforeEach(inject(function($compile, $rootScope, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        function create() {
            var element, compiledElement;
            scope = rootScope.$new();
            scope.languageSettings = {
                languages : [
                    {key: 'en', value: 'English'},
                    {key: 'es', value: 'Spanish'}
                ],
                language: {key: 'en', value: 'English'}
            };
            scope.selectedTemplate = templatesJson.getEveryday()[0];
            element = angular.element('<div select-language ng-model="selectedTemplate"></div>');
            compiledElement = compile(element)(scope);
            scope.$digest();
            return compiledElement;    
        }
        it('Test 1 element should be enabled', function () {
            var element = create();
            expect(element).toBeDefined();
        });
        it('Test 2 should set TranslatedValues for selected template', function() {
            var element = create();
            expect(scope.selectedTemplate.TranslatedValues.length).toBe(2);
        });
        it('Test 3 should set oldValues and newValues', function() {
            var element = create();
            scope.selectedTemplate.Title = 'english';
            scope.languageSettings.language = {key: 'es', value: 'Spanish'};
            scope.$digest();
            expect(scope.selectedTemplate.TranslatedValues[0].values.Title).toBe('english');
            expect(scope.selectedTemplate.TranslatedValues[1].values.Title).toBe('');
        });
    });
});