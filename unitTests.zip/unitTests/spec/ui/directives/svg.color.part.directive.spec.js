define([
    'jquery',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function(jquery, angular){
    describe('svg color part directive spec - > ', function() {
        var scope,
            rootScope,
            elm,
            elHtml;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));

        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector) {
            rootScope = $rootScope;
            compile = $compile;
        }));

        it('Test 1 elm should be defined', function() {
            scope = rootScope.$new();
            elHtml = '<div class="pull-right" svg-color-part></div>';
            elm = angular.element(elHtml);
            compile(elm)(scope);
            scope.$digest();
            expect(elm).toBeDefined();
        });
    });
});
