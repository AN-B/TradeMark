/**
 * Created by philipplekhanov on 8/8/14.
 */
define([
    'jquery',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(jquery, angular){

    describe('textarea resize directive spec -> ', function() {
        var scope,
            elm,
            compiled,
            html = '<textarea autosize-textarea></textarea>';

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope) {
            scope = $rootScope.$new();
            elm = angular.element(html);

           /// elm.appendTo(document.body);
            //$compile(elm)(scope);
            //elm.autosize = function(){};

        }));
        it('Test 1 ', function() {
            //spyOn(jquery.fn, 'autosize');

            //scope.$digest();
        });
    });
});