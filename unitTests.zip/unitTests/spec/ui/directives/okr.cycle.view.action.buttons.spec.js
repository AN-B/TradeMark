define([
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('okr cycle view action button directive spec - > ', function() {
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/Hgapp/Profile/okr/okr-cycle-view-buttons.html',
                '<div ng-if="flags.addNew">' +
                '<button ng-click="addNew(item)"><span>+</span><span translate="profile.goals.ang"></span></button>' +
                '<button ng-click="addNew(item)" translate="profile.goals.sfa"></button>' +
                '</div>' +
                '<div ng-if="flags.newRequired">' +
                '<button ng-click="addNew(item)"><span>+</span><span translate="profile.goals.cgc"></span></button>' +
                '</div>');

        }));
        it('Test 1 addNew should be false if goals length > 0 and MyRole is owner',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{}, {}],
                    MyRole: "Owner",
                    ParticipantStatus: "NotStarted",
                    WeightingFlags: {CanSubmit: false, CanWeight: false}
                };
                var elm = angular.element('<div okr-view-action-buttons ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.newRequired).toBeFalsy();
            }));
        it('Test 2 addNew should be true if goals length > 0 and MyRole is owner and status is Setting',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{}, {}],
                    MyRole: "Owner",
                    ParticipantStatus: "Setting",
                    WeightingFlags: {CanSubmit: false, CanWeight: false}
                };
                var elm = angular.element('<div okr-view-action-buttons ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.newRequired).toBeFalsy();
            }));
        it('Test 3 should be false MyRole is not Owner',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{}, {}],
                    MyRole: "something",
                    ParticipantStatus: "Setting",
                    WeightingFlags: {CanSubmit: false, CanWeight: false}
                };
                var elm = angular.element('<div okr-view-action-buttons ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.newRequired).toBeFalsy();
            }));
        it('Test 4 should be false if ParticipantStatus is not Setting or NotStarted',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{}, {}],
                    MyRole: "Owner",
                    ParticipantStatus: "something",
                    WeightingFlags: {CanSubmit: false, CanWeight: false}
                };
                var elm = angular.element('<div okr-view-action-buttons ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.newRequired).toBeFalsy();
            }));
        it('Test 5 close should be false',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{}],
                    MyRole: "Owner",
                    ParticipantStatus: "InProgress",
                    WeightingFlags: {CanSubmit: false, CanWeight: false}
                };
                scope.goalId = 'test';

                var elm = angular.element('<div okr-view-action-buttons ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.close).toBeFalsy();
            }));

    });
});
