define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){

    describe('confirm note directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            $compile,
            rootScope,
            timeout;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($injector, $rootScope) {
            timeout = $injector.get('$timeout');
            backend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            rootScope = $rootScope;
            $compile = $injector.get('$compile');
            elm = angular.element('<button confirm-note="updateStatus(row, \'Cancel\')" ' +
                    'conftext="Cancel this order?"></button>');
            $compile(elm)(scope);
        }));
        it('Test 1 elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('Test 2 should display comment area ', function() {
            backend.whenGET('/templates/shared/confirm-note-directive.html').respond(200, '<div></div>');
            ctrl = elm.scope();
            scope.$digest();
            var confirmDiv = '<div></div>';
            elm.triggerHandler('click');
        });
        xit('Test 3 should submit comment area ', function() {
            backend.whenGET('/templates/shared/confirm-note-directive.html').respond(200, '<div></div>');
            ctrl = elm.scope();
            scope.$digest();
            elm.triggerHandler('click');
            var confirmDiv = '<div></div>';
            ctrl.submit();
        });
    });
});