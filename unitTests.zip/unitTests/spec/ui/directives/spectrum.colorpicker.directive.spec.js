define([
    'jquery',
    'angular',
    'angular-mocks',
    'angular-resource',
    'templates/shared/spectrum-colorpicker-directive.html',
    'unitTests/ui-mocks/spectrum.mock',
    'hgapp-app'
], function(jquery, angular){
    describe('Spectrum colorpicker directive spec - > ', function() {
        var scope,
            rootScope,
            elm,
            ctrl,
            cmp,
            elHtml;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(module('templates/shared/spectrum-colorpicker-directive.html'));

        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector) {
            rootScope = $rootScope;
            compile = $compile;
            // elHtml = '<spectrum-colorpicker ng-model="templates[selectedIndex].iconPickerColor" loaded-model="model.iconOverlayLoaded" chosen-model="iconColorChosen"></spectrum-colorpicker>';
            // elHtml = '<spectrum-colorpicker ng-model="templates[selectedIndex].bkgdPickerColor" loaded-model="model.bkgdOverlayLoaded" chosen-model="bkgdColorChosen"></spectrum-colorpicker>';
            // elHtml = '<spectrum-colorpicker ng-model="item.iconPickerColor" loaded-model="model.iconOverlayLoaded" chosen-model="iconColorChosen"></spectrum-colorpicker>';
        }));

        it('Test 1 elm should be defined', function() {
            scope = rootScope.$new();
            elHtml = '<spectrum-colorpicker ng-model="templates[selectedIndex].iconPickerColor" loaded-model="model.iconOverlayLoaded" chosen-model="iconColorChosen"></spectrum-colorpicker>';
            elm = angular.element(elHtml);
            compile(elm)(scope);
            scope.$digest();
            expect(elm).toBeDefined();
        });
    });
});
