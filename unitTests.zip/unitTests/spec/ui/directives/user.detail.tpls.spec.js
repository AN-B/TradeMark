define([
    'unitTests/ui-mocks/feed.json',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(feedJson){
    describe('User details tooltip directive spec - > ', function() {
        var scope,
            elm,
            timeout,
            ctrl,
            memberSrvc,
            backend;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, MemberSrvc) {
            memberSrvc = MemberSrvc;
            backend = $injector.get("$httpBackend");
            timeout = $injector.get("$timeout");
            scope = $rootScope.$new();
            scope.memId = 'tst';
            scope.name = 'Bob';
            $templateCache.put('/templates/Hgapp/User/user-name.html', '<span ng-bind="fullName"></span>');
            backend.whenGET('/templates/Hgapp/User/user-details.html')
                .respond(200, '<div></div>');
            backend.whenGET('/svc/Member/GetMemberExcerpt?MemberId=tst')
                .respond(200, feedJson.get().feeds[0].issuer);

            elm = angular.element('<div user-detail-tpls="{{memId}}" full-name="{{name}}"/>');
            $compile(elm)(scope);
            scope.model = [];
            scope.$digest();
            ctrl = elm.scope();
        }));
        it('Test 1 elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('Test 2 rendered', function() {
            spyOn(memberSrvc, 'getUserDetailsTmpl').andCallThrough();
            spyOn(memberSrvc, 'getMemberExcerpt').andCallThrough();
            elm.triggerHandler('mouseenter');
            scope.$digest();
            backend.flush();
            expect(memberSrvc.getUserDetailsTmpl).toHaveBeenCalled();
            expect(memberSrvc.getMemberExcerpt).toHaveBeenCalledWith('tst');
        });
    });
});


