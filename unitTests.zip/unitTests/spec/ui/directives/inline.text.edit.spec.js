define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('inline text edit directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));

        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/shared/directives/inline.text.edit.html',
                '<div></div>');
        }));
        beforeEach(inject(function($compile, $rootScope, $injector, _$document_) {
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
            scope = rootScope.$new();
            scope.test = 'hello!';
            scope.options = {cls: 'myclass'};
            scope.done = function(val){};
            scope.model = {};
            elm = angular.element('<div text-edit="options" ng-model="test" on-edit="done()"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
        }));
        it('Test 1 directive should be initialized', function() {
            expect(ctrl.model.value).toBe('hello!');
            expect(ctrl.model.options.cls).toBe('myclass');
        });
        it('Test 2 cancel should set model value to original value', function() {
            ctrl.model.isEdit = true;
            ctrl.model.value = 'test';
            ctrl.cancel();
            expect(ctrl.model.isEdit).toBeFalsy();
            expect(ctrl.model.value).toBe('hello!');
        });
        it('Test 3 should call parent scope function if valid', function() {
            spyOn(scope, 'done').andCallThrough();
            ctrl.submit('test');
            expect(scope.done).toHaveBeenCalled();
        });
        it('Test 4 should not call parent scope function if invalid', function() {
            spyOn(scope, 'done').andCallThrough();
            ctrl.submit('');
            expect(scope.done).not.toHaveBeenCalled();
        });
        it('Test 5 should flip isEdit switch', function() {
            ctrl.edit();
            expect(ctrl.model.isEdit).toBeTruthy();
        });
    });
});