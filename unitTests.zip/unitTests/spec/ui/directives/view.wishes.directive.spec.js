define([
    'unitTests/ui-mocks/member.json',
    'unitTests/ui-mocks/wish.json',
    'unitTests/ui-mocks/productItem.templates.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(memberJson, wishJson, productJson){
    describe('view wishes directive spec - > ', function() {
        var elm,
            scope,
            wishListService,
            memberService,
            httpBackend,
            ctrl;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));

        beforeEach(inject(function($compile, $injector, $templateCache, $rootScope, WishListSrvc, MemberSrvc) {
            wishListService = WishListSrvc;
            memberService = MemberSrvc;
            scope = $rootScope.$new();
            scope.product = productJson.getAll();
            scope.ownerId = memberJson.getProfileMemberRecordById().hgId;
            $templateCache.put('/templates/Hgapp/Motivate/dialogs/view-wishes.html', '<div>template</div>');
            elm = angular.element('<div view-wishes owner="{{ownerId}}" products="product"/>');
            $compile(elm)(scope);
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/WishList/GetWishListByMemberId?MemberId=f75b0252-a416-11e4-a111-57b4d90536cc&Skip=0&Take=10')
                .respond(200, wishJson.getWishList());
            httpBackend.whenGET('/svc/Member/GetMemberByMemberId?MemberId=f75b0252-a416-11e4-a111-57b4d90536cc')
                .respond(200, memberJson.getProfileMemberRecordById());

            ctrl = elm.scope();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('elm should be defined', function() {
            spyOn(wishListService, 'getWishListByMemberId').andCallThrough();
            spyOn(memberService, 'getMemberByMemberId').andCallThrough();
            scope.$digest();
            expect(elm).toBeDefined();
            expect(elm.attr('products')).toBeDefined();
            expect(elm.attr('owner')).toBe(scope.ownerId);
            httpBackend.flush();
            expect(scope.WishList).toBeDefined();
            expect(scope.readyToSort.products).toBe(true);
            expect(scope.readyToSort.wishlist).toBe(true);
            expect(wishListService.getWishListByMemberId).toHaveBeenCalled();
            expect(memberService.getMemberByMemberId).toHaveBeenCalled();
        });
    });
});

