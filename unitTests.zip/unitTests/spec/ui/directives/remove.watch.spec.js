define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('remove watch directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            timeout,
            win;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives", function($provide){
            $provide.value('$window', {
                addEventListener: function (a, b){
                    return true;
                },
                removeEventListener: function(){
                    return true;
                }
            });
        }));
        beforeEach(inject(function($compile, $rootScope, $injector, $window) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            timeout = $injector.get('$timeout');
            win = $window;

        }));
        function create(top) {
            var element, compiledElement;
            scope = rootScope.$new();
            scope.model = {obj:'test'};
            element = angular.element('<div remove-watch ng-model="model"><span ng-model="model.obj"></span></div>');

            spyOn(angular, 'element').andCallFake(function(){
                return {
                    scrollTop: function () {
                        return 0;
                    },
                    height: function () {
                        return 100;
                    },
                    offset: function(){
                        return {
                            top: top
                        };
                    }
                }
            });

            compiledElement = compile(element)(scope);
            scope.$digest();

            return compiledElement;
        }
        it('Test 1 elements watches should not be set if element is not in the view', function () {
            var elm = create(1050);
            timeout.flush();
            expect(elm.data().$scope.watchersBackup.length).toBe(2);
            expect(elm.data().$scope.$$watchers).toBeFalsy();
        });
        it('Test 2 element should have watchers set if element is in the view', function () {
            var elm = create(0);
            timeout.flush();
            expect(elm.data().$scope.watchersBackup).toBeFalsy();
            expect(elm.data().$scope.$$watchers.length).toBe(2);
        });
    });
});