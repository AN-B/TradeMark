define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('feedback-answer-text directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('/templates/Hgapp/Profile/feedbacksession/feedback-answer-text.html',
                '<div></div>');
        }));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should validate question', function() {
            scope = rootScope.$new();
            scope.test = {AnswerSelector: [], Answer:{SelectedValues:[]}};
            elm = angular.element('<div feedback-answer-text question="test"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            scope.test = elm.isolateScope().validate(scope.test);
            expect(scope.test.invalid).toBeFalsy();
        });
        it('Test 2 should validate question', function() {
            scope = rootScope.$new();
            scope.test = {Required: true, AnswerSelector: [], Answer:{SelectedValues:[]}};
            elm = angular.element('<div feedback-answer-text question="test"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            scope.test = elm.isolateScope().validate(scope.test);
            expect(scope.test.invalid).toBeTruthy();
        });
        it('Test 2 should validate question', function() {
            scope = rootScope.$new();
            scope.test = {Required: true, AnswerSelector: [], Answer:{SelectedValues:[], Text: "test"}};
            elm = angular.element('<div feedback-answer-text question="test"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            scope.test = elm.isolateScope().validate(scope.test);
            expect(scope.test.invalid).toBeFalsy();
        });

    });
});