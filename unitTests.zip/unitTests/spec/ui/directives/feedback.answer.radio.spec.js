define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('feedback-answer-radio directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('/templates/Hgapp/Profile/feedbacksession/feedback-answer-radio.html',
                '<div></div>');
        }));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should resolve selected', function() {
            scope = rootScope.$new();
            scope.test = {AnswerSelector: [{Value: 1}], Answer:{SelectedValues:[1]}};
            elm = angular.element('<div feedback-answer-radio question="test"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(scope.test.AnswerSelector[0].selected).toBeTruthy();
        });

        it('Test 2 should toggle selected', function() {
            scope = rootScope.$new();
            scope.test = {AnswerSelector: [{Value: 1}], Answer:{SelectedValues:[]}};
            elm = angular.element('<div feedback-answer-radio question="test"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.isolateScope().select(1);
            expect(scope.test.Answer.SelectedValues[0]).toBe(1);
        });
        it('Test 3 should toggle selected', function() {
            scope = rootScope.$new();
            scope.test = {AnswerSelector: [{Value: 1}]};
            elm = angular.element('<div feedback-answer-radio question="test"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.isolateScope().select(1);
            expect(scope.test.Answer.SelectedValues[0]).toBe(1);
        });
        it('Test 4 should toggle selected', function() {
            scope = rootScope.$new();
            scope.test = {AnswerSelector: [{Value: 1}], Answer: {}};
            elm = angular.element('<div feedback-answer-radio question="test"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.isolateScope().select(1);
            expect(scope.test.Answer.SelectedValues[0]).toBe(1);
        });
    });
});