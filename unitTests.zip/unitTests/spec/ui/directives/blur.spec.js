define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){

    describe('blur directive spec', function() {
        var scope, elm, $compile;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($injector, $sniffer) {
            scope = $injector.get('$rootScope');
            $compile = $injector.get('$compile');
            scope.blurFunction = function () {
                return true;
            };
            elm = angular.element('<input type="text" blur="someValue" action="blurFunction" />');
            $compile(elm)(scope);
        }));
        it('elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('should trigger outside function when element is blured ', function() {
            spyOn(scope, 'blurFunction');
            elm[0].blur();

            //expect(scope.blurFunction).toHaveBeenCalled();
        });
    });
});