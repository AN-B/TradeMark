define([
	'unitTests/ui-mocks/autocomplete.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app',
    'templates/shared/server-search-directive.html'
	], function(autocompleteJson) {
	describe('Server Search directive controller spec ->', function() {
		var scope,
			ctrl,
			timeout,
			search,
			rootScope,
			autoCompleteService,
			httpBackend,
			compile;
		search = {
			userMeta : {}
		};
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-directives"));
		beforeEach(module('templates/shared/server-search-directive.html'));
		beforeEach(inject(function ($compile, $rootScope, $injector, AutoCompleteSrvc) {
			timeout = $injector.get("$timeout");
			rootScope = $rootScope;
			httpBackend = $injector.get("$httpBackend");
			autoCompleteService = AutoCompleteSrvc;
			compile = $compile;
		}));
		afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
		function create() {
	        var element, compiledElement;
	        scope = rootScope.$new();
	        scope.search = search;
	        element = angular.element("<div server-search-select ng-model='search.userMeta' searchMode='multi'></div>");
	        compiledElement = compile(element)(scope);
	        scope.$digest();
	        return compiledElement;    
	    }
		it('Test 1 element should be enabled', function () {
			var element = create();
			expect(element).toBeDefined();
			expect(element.isolateScope().searchModel.take).toBe(50);
		});
		it('Test 2 preSelected items', function () {
			search.userMeta.preSelected = ['1'];
			httpBackend.whenPOST("/svc/AutoComplete/GetPreSelectedItems")
                .respond(200, search.userMeta.preSelected);
            spyOn(autoCompleteService, 'getPreSelectItems').andCallThrough();
			var element = create();
			httpBackend.flush();
			expect(element).toBeDefined();
			expect(element.isolateScope().searchModel.selected.length).toBe(1);
		});
		it('Test 3 prevent search', function () {
			search.userMeta.preSelected = [];
			var item, element = create();
			expect(element).toBeDefined();
			element.isolateScope().done = true;
			expect(element.isolateScope().preventSearch()).toBeTruthy();
		});
		it('Test 4 blur', function () {
			search.userMeta.preSelected = [];
			var item, element = create();
			element.isolateScope().searchTerm = 'Test Blur';
			element.isolateScope().blur({});
			element.isolateScope().$digest();
			expect(element).toBeDefined();
			expect(element.isolateScope().blurTimeout).toBeDefined();
		});
		it('Test 5 cancelTimeout', function () {
			search.userMeta.preSelected = [];
			var item, element = create();
			element.isolateScope().blur();
			element.isolateScope().cancelTimeout();
			expect(element).toBeDefined();
			expect(element.isolateScope().blurTimeout).toBe(undefined);
		});
		it('Test 6 getAutoCompleteData()', function () {
			search.userMeta.preSelected = [];
			search.userMeta.meta = [];
			httpBackend.whenPOST("/svc/AutoComplete/AutoComplete")
                .respond(200, autocompleteJson.getAutoCompleteData());
            spyOn(autoCompleteService, 'autoComplete').andCallThrough();
			var item, element = create();
			element.isolateScope().searchModel.searchTerm = 'Testing';
			element.isolateScope().getAutocompleteData();
			element.isolateScope().$digest();
			httpBackend.flush();
			expect(element).toBeDefined();
			expect(element.isolateScope().searchModel.meta.length).toBe(3);
		});
		it('Test 7 selectItem()', function () {
			search.userMeta.preSelected = [];
			search.userMeta.meta = [];
			httpBackend.whenPOST("/svc/AutoComplete/AutoComplete")
                .respond(200, autocompleteJson.getAutoCompleteData());
            spyOn(autoCompleteService, 'autoComplete').andCallThrough();
			var item, element = create();
			element.isolateScope().searchModel.searchTerm = 'Testing';
			element.isolateScope().getAutocompleteData();
			element.isolateScope().$digest();
			httpBackend.flush();
			item = element.isolateScope().searchModel.meta[0];
			element.isolateScope().selectItem(item);
			element.isolateScope().$digest();
			expect(element).toBeDefined();
			expect(element.isolateScope().searchModel.meta.length).toBe(0);
			expect(element.isolateScope().searchModel.selected.length).toBe(1);
			expect(element.isolateScope().searchModel.selected[0].Id).toBe(item.Id);
		});
		it('Test 8 selectAll()', function () {
			search.userMeta.preSelected = [];
			search.userMeta.meta = [];
			httpBackend.whenPOST("/svc/AutoComplete/AutoComplete")
                .respond(200, autocompleteJson.getAutoCompleteData());
            spyOn(autoCompleteService, 'autoComplete').andCallThrough();
			var item, element = create();
			element.isolateScope().searchModel.searchTerm = 'Testing';
			element.isolateScope().getAutocompleteData();
			element.isolateScope().$digest();
			httpBackend.flush();
			element.isolateScope().selectAll(item);
			element.isolateScope().$digest();
			expect(element).toBeDefined();
			expect(element.isolateScope().searchModel.meta.length).toBe(0);
			expect(element.isolateScope().searchModel.selected.length).toBe(3);
		});
		it('Test 9 deselectItem()', function () {
			search.userMeta.preSelected = [];
			search.userMeta.meta = [];
			httpBackend.whenPOST("/svc/AutoComplete/AutoComplete")
                .respond(200, autocompleteJson.getAutoCompleteData());
            spyOn(autoCompleteService, 'autoComplete').andCallThrough();
			var item, element = create();
			element.isolateScope().searchModel.searchTerm = 'Testing 3';
			element.isolateScope().getAutocompleteData();
			element.isolateScope().$digest();
			httpBackend.flush();
			item = element.isolateScope().searchModel.meta[0];
			element.isolateScope().selectItem(item);
			element.isolateScope().$digest();
			expect(element).toBeDefined();
			expect(element.isolateScope().searchModel.meta.length).toBe(0);
			expect(element.isolateScope().searchModel.selected.length).toBe(1);
			expect(element.isolateScope().searchModel.selected[0].Id).toBe(item.Id);
			element.isolateScope().deselectItem(item);
			element.isolateScope().$digest();
			expect(element.isolateScope().searchModel.selected.length).toBe(0);
		});
		it('Test 10 clearAll()', function () {
			search.userMeta.preSelected = [];
			search.userMeta.meta = [];
			httpBackend.whenPOST("/svc/AutoComplete/AutoComplete")
                .respond(200, autocompleteJson.getAutoCompleteData());
            spyOn(autoCompleteService, 'autoComplete').andCallThrough();
			var item, element = create();
			element.isolateScope().searchModel.searchTerm = 'Testing';
			element.isolateScope().getAutocompleteData();
			element.isolateScope().$digest();
			httpBackend.flush();
			element.isolateScope().selectAll(item);
			element.isolateScope().$digest();
			expect(element).toBeDefined();
			expect(element.isolateScope().searchModel.meta.length).toBe(0);
			expect(element.isolateScope().searchModel.selected.length).toBe(3);
			element.isolateScope().clearAll();
			element.isolateScope().$digest();
			expect(element.isolateScope().searchModel.selected.length).toBe(0);
		});
		it('Test 11 getAvatarUrl()', function () {
			search.userMeta.type = 'Team';
			search.userMeta.preSelected = [];
			search.userMeta.meta = [];
			var item = {
				AvatarId : 'abc'
			}, element = create();
			element.isolateScope().$digest();
			expect(element).toBeDefined();
			expect(element.isolateScope().getAvatarUrl(item), 'blah/team/abc.jpg?');
		});
	});
});