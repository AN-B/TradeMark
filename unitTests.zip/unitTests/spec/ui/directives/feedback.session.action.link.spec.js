define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('feedback-action-link directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should set href', function() {
            scope = rootScope.$new();
            scope.test = {NextStep: 'Start'};
            elm = angular.element('<a feedback-action-link="test"></a>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('href')).toBe('#/Profile/Feedback/Start/');
        });
    });
});