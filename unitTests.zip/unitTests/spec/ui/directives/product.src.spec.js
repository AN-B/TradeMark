define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('product-src directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test.jpg';
            scope.groupId = 123;
            elm = angular.element('<div product-src="{{test}}" group-id="{{groupId}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/product/123/test.jpg?123');
        });
        it('Test 2 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test.jpg';
            scope.groupId = 123;
            elm = angular.element('<div product-src="{{test}}" group-id="{{groupId}}" version="223"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/product/123/test.jpg?223');
        });
        it('Test 3 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test.jpg';
            scope.groupId = 123;
            elm = angular.element('<div product-src="{{test}}" group-id="{{groupId}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/product/123/test.jpg?123');
        });
        it('Test 4 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            scope.test = 'test.jpg';
            scope.ver = '223';
            scope.groupId = 123;
            elm = angular.element('<div product-src="{{test}}" group-id="{{groupId}}" version="{{ver}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe(rootScope.imageStore[0] + '/product/123/test.jpg?223');
        });
    });
});