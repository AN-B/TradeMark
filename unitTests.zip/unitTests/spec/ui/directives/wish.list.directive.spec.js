define([
    'unitTests/ui-mocks/member.json',
    'unitTests/ui-mocks/wish.json',
    'unitTests/ui-mocks/productItem.templates.json',
    'angular',
    'jquery',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(memberJson, wishJson, productJson){
    describe('wish list directive spec - > ', function() {
        var scope,
            elm,
            meta,
            ctrl,
            wishListSrvc,
            productItemSrvc,
            httpBackend,
            compile;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));

        beforeEach(inject(function($compile, $rootScope, $templateCache, $modal, $injector, WishListSrvc, ProductItemSrvc) {
            compile = $compile;
            wishListSrvc = WishListSrvc;
            productItemSrvc = ProductItemSrvc;
            scope = $rootScope.$new();
            scope.ownerId = memberJson.getProfileMemberRecordById().hgId;
            $templateCache.put('/templates/Hgapp/Motivate/dialogs/wish-list.html', '<div></div>');

            elm = angular.element('<div wish-list owner="{{ownerId}}"/>');
            compile(elm)(scope);
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/WishList/GetWishListByMemberId?MemberId=f75b0252-a416-11e4-a111-57b4d90536cc&Skip=0&Take=10')
                .respond(200, wishJson.getWishList());
            httpBackend.whenPOST('/svc/WishList/RemoveFromWishList')
                .respond(200, 'removed');
            httpBackend.whenPOST('/svc/WishList/UpdateWishList')
                .respond(200, 'updated');
            httpBackend.whenPOST('/svc/WishList/CreateWishList')
                .respond(200, {
                    Item: {Name: 'prodName', Id: '85c0afbe-563f-4092-8050-b93770b88e75'}
                });
            httpBackend.whenGET('/svc/ProductItem/GetProductItems')
                .respond(200, productJson.getAll());
            httpBackend.whenGET('/svc/ProductItem/GetProductById?Id=85c0afbe-563f-4092-8050-b93770b88e75')
                .respond(200, productJson.getNew());
            httpBackend.whenPOST('/svc/WishList/UpdateWishList')
                .respond(200, '');

            spyOn(wishListSrvc, 'getWishListByMemberId').andCallThrough();
            scope.$digest();
            httpBackend.flush();
            expect(wishListSrvc.getWishListByMemberId).toHaveBeenCalled();

            ctrl = elm.scope();
        }));
        afterEach(function () {
            scope.$digest();
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('elm should be defined', function() {
            expect(elm).toBeDefined();
            expect(scope.Products).toBeDefined();
        });
        it('removeItem should call removeFromWishList', function () {
            scope.WishList = wishJson.getWishList();
            scope.Products = productJson.getAll();
            spyOn(wishListSrvc, 'removeFromWishList').andCallThrough();
            expect(scope.WishList.length).toBe(3);
            scope.removeItem(0);
            httpBackend.flush();
            expect(wishListSrvc.removeFromWishList).toHaveBeenCalled();
            expect(scope.WishList.length).toBe(2);
        });
        it('addProduct should call getProductById and createWishList', function () {
            spyOn(productItemSrvc, 'getProductById').andCallThrough();
            spyOn(wishListSrvc, 'createWishList').andCallThrough();
            scope.addProduct('85c0afbe-563f-4092-8050-b93770b88e75');
            httpBackend.flush();
            expect(productItemSrvc.getProductById).toHaveBeenCalled();
            expect(wishListSrvc.createWishList).toHaveBeenCalled();
            expect(scope.WishList.length).toBe(4);
        });
        it('dragging the sortable list item should trigger start', function () {
            scope.WishList = wishJson.getWishList();
            var ids = [scope.WishList[0].Item.Id, scope.WishList[1].Item.Id],
                contents,
                element,
                li1,
                li2;
            li1 = angular.element('<li id="listitem1" data-id="' + ids[0] + '"></li>');
            li2 = angular.element('<li id="listitem2" data-id="' + ids[1] + '"></li>');
            compile(li1)(scope);
            element = angular.element('<ul ui-sortable="sortableOptions" ng-model="WishList"></ul>');
            element.append(li1);
            element.append(li2);
            compile(element)(scope);
            elm.append(element);
            compile(elm)(scope);
            ctrl = element.scope();
            contents = element.contents();
            httpBackend.flush();
            scope.$digest();

            spyOn(wishListSrvc, 'updateWishList').andCallThrough();
            spyOn(scope.sortableOptions, 'start').andCallThrough();

            //this is PhantomJS - there is an issue with create Events, see: https://github.com/ariya/phantomjs/issues/11289
            var evt = document.createEvent('MouseEvent');
            scope.sortableOptions.start(evt.initEvent('mousedown', true, false), {item: contents[0]});
            scope.sortableOptions.stop(evt.initEvent('mouseup', true, false), {item: contents[1]});

            httpBackend.flush();
            expect(scope.sortableOptions.start).toHaveBeenCalled();
            expect(wishListSrvc.updateWishList).toHaveBeenCalled();
            expect(angular.element(contents[0]).attr('data-id')).toEqual(ids[0]);
            expect(angular.element(contents[1]).attr('data-id')).toEqual(ids[1]);
        });
    });
});