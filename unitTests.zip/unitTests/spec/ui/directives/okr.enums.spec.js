/**
 * Created by philipplekhanov on 5/12/15.
 */
define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('okr-enums directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document,
            translate;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            translate = $injector.get('$translate');
            $document = _$document_;
        }));
        it('Test 1 should set elm html to Submitted For Set', function() {
            scope = rootScope.$new();
            spyOn(translate, 'instant').andCallThrough();
            scope.status = 'SubmittedForSet';
            elm = angular.element('<div okr-enums="{{status}}"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.html()).toBe('mob.goal.sts.sfs');
            expect(translate.instant).toHaveBeenCalledWith('mob.goal.sts.sfs');
        });
        it('Test 2 should set elm html to nothing', function() {
            scope = rootScope.$new();
            scope.status = '';
            elm = angular.element('<div okr-enums="{{status}}"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.html()).toBeFalsy();
        });
        it('Test 3 should set elm html to nothing', function() {
            scope = rootScope.$new();
            scope.status = 'test';
            elm = angular.element('<div okr-enums="{{status}}"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.html()).toBeFalsy();
        });
    });
});