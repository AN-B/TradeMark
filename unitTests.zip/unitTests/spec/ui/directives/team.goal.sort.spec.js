define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){

    describe('team goal sort directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            $compile,
            rootScope,
            timeout;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($injector, $rootScope) {
            timeout = $injector.get('$timeout');
            backend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            rootScope = $rootScope;
            $compile = $injector.get('$compile');
            elm = angular.element('<div team-sort column="Name" grid="goals" action="sortByColumn" current="Name"></div>');
            $compile(elm)(scope);
        }));
        it('Test 1 elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('Test 2 should display goal sort ', function() {
            backend.whenGET('templates/shared/team-goal-sort.html').respond(200, '<div></div>');
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('grid')).toBe('goals');
        });
    });
});