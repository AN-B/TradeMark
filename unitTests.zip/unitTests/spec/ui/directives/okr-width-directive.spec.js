/**
 * Created by jsunman on 12/15/15.
 */
define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('okr-width directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 value should not be undefined', function() {
            scope = rootScope.$new();
            elm = angular.element('<div class="result" okr-width=""></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('style')).not.toBeDefined();
        });
        it('Test 2 value should not be NaN', function() {
            scope = rootScope.$new();
            elm = angular.element('<div class="result" okr-width="{}"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('style')).not.toBeNaN();
        });
        it('Test 3 elm width should not be greater than 100%', function() {
            scope = rootScope.$new();
            elm = angular.element('<div class="result" okr-width="110"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('style')).toBe('width: 100%;');
        });
        it('Test 4 elm width should not be less than 0', function() {
            scope = rootScope.$new();
            elm = angular.element('<div class="result" okr-width="-57"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('style')).toBe('width: 0;');
        });
        it('Test 5 elm width should be 50%', function() {
            scope = rootScope.$new();
            elm = angular.element('<div class="result" okr-width="50"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('style')).toBe('width: 50%;');
        });
    });
});