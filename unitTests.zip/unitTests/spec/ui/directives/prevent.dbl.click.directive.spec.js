define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
    describe('Prevent dbl click directive spec - > ', function() {
        var scope,
            elm,
            timeout,
            ctrl,
            cmp;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));

        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector) {
            timeout = $injector.get("$timeout");
            cmp = $compile;
            scope = $rootScope.$new();
        }));
        it('Test 1 elm should be defined and timeout value should be 5000', function() {
            elm = angular.element('<button prevent-dbl-click="blah"/>');
            cmp(elm)(scope);
            scope.$digest();
            ctrl = elm.scope();
            expect(elm).toBeDefined();
            expect(scope.auszeit).toBe(5000);
        });
        it('Test 2 elm should be defined and timeout value should be 30', function() {
            elm = angular.element('<button prevent-dbl-click="30gsdhgscghcs"/>');
            cmp(elm)(scope);
            scope.$digest();
            ctrl = elm.scope();
            expect(elm).toBeDefined();
            expect(scope.auszeit).toBe(30);
        });
        it('Test 3 elm should be disabled after click and enabled after timeout', function() {
            elm = angular.element('<button prevent-dbl-click/>');
            cmp(elm)(scope);
            scope.$digest();
            ctrl = elm.scope();
            expect(elm.attr('disabled')).not.toBeDefined();
            elm.triggerHandler('click');
            timeout.flush();
            expect(elm.attr('disabled')).toBe('disabled');
            timeout.flush();
            expect(elm.attr('disabled')).not.toBeDefined();
        });
    });
});
