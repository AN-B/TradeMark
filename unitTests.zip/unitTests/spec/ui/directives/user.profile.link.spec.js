define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){
    describe('user profile link directive spec - > ', function() {
        var elm,
            scope,
            ctrl;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($compile, $rootScope, $templateCache, $injector) {

            $templateCache.put('templates/Hgapp/User/user-profile-link.html',
                '<span ng-bind-html="first"></span>'
                + '<a class="btn-new-link" ng-href="#/Profile/Feed/{{memberId}}" ng-bind="::fullName"></a>'
                + '<span ng-bind-html="second"></span>');

            scope = $rootScope.$new();
            scope.name = 'Larry';
            scope.id = 'test123';

            elm = angular.element('<small user-profile-link full-name="name" member-id="id" trans-key="profile.goals.bn" trans-prop="name"></small>');
            $compile(elm)(scope);
            scope.$digest();
            ctrl = elm.scope();
        }));
        it('Test 1 directive should be initialized', function(){
            expect(elm).toBeDefined();
            expect(elm.find('a').attr('href')).toBe('#/Profile/Feed/' + scope.id);
            expect(elm.find('a').html()).toBe(scope.name);
            expect(angular.element(elm.find('span')[0]).html()).toBe('profile.goals.bn');
        });
    });
});