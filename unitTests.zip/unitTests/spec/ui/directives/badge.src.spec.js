define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('badge-src directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            rootScope.imageStoreBadges = ['blah/'];
            scope.test = 'test';
            elm = angular.element('<div badge-src="{{test}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe('blah/test.svg?123');
        });
        it('Test 2 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            rootScope.imageStoreBadges = ['blah'];
            scope.test = 'test';
            elm = angular.element('<div badge-src="{{test}}" original/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe('blah/badges/original/test.svg?123');
        });
        it('Test 3 should set src', function() {
            scope = rootScope.$new();
            rootScope.imageVersion = '123';
            rootScope.imageStoreBadges = ['blah'];
            scope.test = 'test';
            scope.groupId = 'groupId';
            elm = angular.element('<div badge-src="{{test}}" group-id="{{groupId}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe('blah/badges/group/groupId/test.svg?123');
        });
        it('Badge src should be transparent gif if badge-src is empty', function() {
            scope = rootScope.$new();
            elm = angular.element('<div badge-src="" />');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('src')).toBe('data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
        });
    });
});