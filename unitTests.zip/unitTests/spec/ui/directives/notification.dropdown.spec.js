define(['angular',
    'unitTests/ui-mocks/user.json',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular, user){

    describe('Notification popup directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document,
            backend,
            modal,
            userSrvc,
            notificationSrvc;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            $templateCache.put('template/modal/backdrop.html', '<div></div>');
            userSrvc = $injector.get('UserSrvc');
            notificationSrvc = $injector.get('NotificationSrvc');
            backend = $injector.get('$httpBackend');
            modal = $injector.get('$modal');

            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
            backend.whenGET('/svc/User/Login').respond(200, user.getCu());
            backend.whenGET('/svc/Notification/GetImportantNotificationsByLimits?recipientId=d2e0d320-a119-11e2-b177-7d64c8315189&take=10')
                .respond(200, [{items: [{}]}, 1]);
            backend.whenPOST('/svc/Notification/Remove')
                .respond(200, {});
            userSrvc.clearUserCache();
            $templateCache.put('templates/Hgapp/User/dialogs/importantNotifications.html', '<div></div>');
            $templateCache.put('templates/Hgapp/survey/take-benchmark-survey-modal.html', '<div></div>');
            scope = rootScope.$new();
            elm = angular.element('<div notification-popup></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
        }));
        afterEach(function () {
            scope.$digest();
            backend.verifyNoOutstandingExpectation();
            backend.verifyNoOutstandingRequest();
        });
        it('Test 1 elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('Test 2 it click event listener should call backend and get user and notifications', function() {
            spyOn(userSrvc, 'getUser').andCallThrough();
            spyOn(notificationSrvc, 'getImportantNotificationsByLimits').andCallThrough();
            elm.triggerHandler('click');
            backend.flush();
            expect(userSrvc.getUser).toHaveBeenCalled();
            expect(notificationSrvc.getImportantNotificationsByLimits).toHaveBeenCalled();
        });
        it('Test 3 remove notifications should call backend removeNotification service', function() {
            spyOn(notificationSrvc, 'removeNotification').andCallThrough();
            var evt = document.createEvent('MouseEvent');
            scope.notifications = [];
            scope.remove('test', evt);
            backend.flush();
            expect(notificationSrvc.removeNotification).toHaveBeenCalled();
        });
        it('Test 4 takeSurvey should open survey modal', function() {
            spyOn(modal, 'open').andCallThrough();
            scope.takeSurvey();
            expect(modal.open).toHaveBeenCalled();
        });
        it('Test 5 on notificationRemoved event it should hide popup', function() {
            scope.showToggle = true;
            rootScope.$broadcast('notificationRemoved');
            expect(scope.showToggle).toBeFalsy();
        });
    });
});