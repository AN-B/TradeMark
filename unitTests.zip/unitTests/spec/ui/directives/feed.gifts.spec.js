define([
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('feed gift directive spec - > ', function() {
        var gifts = [
            {
                "ProductId":"d98fc5c0-3bac-11e5-88ce-cba677ba5049",
                "SenderId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "Type":"Group",
                "OrderIds":[
                    "25a01790-be2e-11e5-b90a-a76255aa76d3",
                    "25e277c0-be2e-11e5-b90a-a76255aa76d3"
                ]
            },
            {
                "ProductId":"d98fc5c0-3bac-11e5-88ce-cba677ba5049",
                "SenderId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "Type":"Individual",
                "OrderIds":[
                    "15f08b40-be38-11e5-b90a-a76255aa76d3"
                ]
            }
        ];
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/Hgapp/Profile/partials/feed-gifts.html', '<span></span>');
        }));
        it('Test 1 it should get both gift counts',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.feed = {gifts: gifts};
                var elm = angular.element('<div feed-gifts="feed.gifts"></div>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.giftType.groupCount).toBe(1);
                expect(ctrl.giftType.singleCount).toBe(1);
            }));
        it('Test 2 it should get single gift count',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.feed = {gifts: [gifts.pop()]};
                var elm = angular.element('<div feed-gifts="feed.gifts"></div>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.giftType.groupCount).toBe(0);
                expect(ctrl.giftType.singleCount).toBe(1);
            }));
        it('Test 3 it should get group gift count',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.feed = {gifts: [gifts.shift()]};
                var elm = angular.element('<div feed-gifts="feed.gifts"></div>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.giftType.groupCount).toBe(1);
                expect(ctrl.giftType.singleCount).toBe(0);
            }));
    });
});