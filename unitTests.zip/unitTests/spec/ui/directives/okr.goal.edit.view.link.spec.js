/**
 * Created by philipplekhanov on 6/17/15.
 */
define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('okr-goal-edit-view-link directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $injector) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
        }));
        it('Test 1 should set elm href to view link', function() {
            scope = rootScope.$new();
            scope.cycleTest = {CycleId: 'cycleId', MyRole: 'Owner', ParticipantId: 'memId', ParticipantStatus: 'nothing', Goals: [{hgId: 'goalId', Owner: {MemberId : "memId"}}]};
            scope.goalId = "goalId";
            elm = angular.element('<div okr-goal-edit-view-link cycle="cycleTest" goal-id="goalId"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('href')).toBe('#/Profile/GoalDetails/View/memId/goalId');
        });
        it('Test 3 should set elm href to view link', function() {
            scope = rootScope.$new();
            scope.cycleTest = {CycleId: 'cycleId', MyRole: 'None', ParticipantId: 'memId', ParticipantStatus: 'Setting', Goals: [{hgId: 'goalId', Owner: {MemberId : "memId"}}]};
            scope.goalId = "goalId";
            elm = angular.element('<div okr-goal-edit-view-link cycle="cycleTest" goal-id="goalId"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('href')).toBe('#/Profile/GoalDetails/View/memId/goalId');
        });
        it('Test 4 should set elm href to view link', function() {
            scope = rootScope.$new();
            scope.cycleTest = {CycleId: 'cycleId', MyRole: 'Owner', ParticipantId: 'memId', ParticipantStatus: 'noting', Goals: [{hgId: 'goalId', Owner: {MemberId : "memId"}}]};
            scope.goalId = "goalId";
            elm = angular.element('<div okr-goal-edit-view-link cycle="cycleTest" goal-id="goalId"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('href')).toBe('#/Profile/GoalDetails/View/memId/goalId');
        });
    });
});