define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('back button directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, $window) {
            location = $injector.get('$location');
            rootScope = $rootScope;
            compile = $compile;
        }));
        it('Test 1 should call window history back on click', function() {
            spyOn(location, 'path').andCallFake(function(){});
            scope = rootScope.$new();
            elm = angular.element('<div back-btn/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            elm.triggerHandler('click');
            expect(location.path).toHaveBeenCalled();
        });
    });
});