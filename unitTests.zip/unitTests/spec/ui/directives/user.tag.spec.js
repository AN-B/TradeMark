define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){
    describe('user tag spec - > ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            backend,
            service;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($templateCache, $compile, $rootScope, $injector, AutoCompleteSrvc) {
            $templateCache.put('templates/shared/tag-content-editable.html',
               '<div contentEditable="true" name="contentEditable"></div>' +
                '<ul ng-if="meta.length" class="dropdown-menu" ng-style="dropdown">' +
                '<li ng-repeat="item in meta | limitTo: 5" ng-click="setItem(item)">' +
                '<img class="avatar avatar-small pull-left" avatar-src="{{item.UserId}}"/>' +
                '<span ng-bind="item.Name"></span>' +
                '</li>' +
                '</ul>');
            service = AutoCompleteSrvc;
            backend = $injector.get('$httpBackend');
            rootScope = $rootScope;
            compile = $compile;
            scope = rootScope.$new();
            scope.comment = {html: 'test'};
            elm = angular.element('<div user-tag ng-model="comment"></div>');
            compile(elm)(scope);
            scope.$digest();
            ctrl = elm.scope();
        }));

        it('Test 1 directive should be initialized', function(){
            expect(elm).toBeDefined();
        });

    });
});
