define([
    'unitTests/ui-mocks/user.json',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson){
    describe('persist model directive spec - > ', function() {
        var scope,
            rootScope,
            compile,
            service,
            ctrl,
            elm,
            window,
            socket,
            timeout,
            backend;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(module("hgapp-services"));

        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, ioSrvc, UserSrvc) {
            service = ioSrvc;
            window = $injector.get('$window');
            timeout = $injector.get('$timeout');
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            rootScope.ioUrl = 'ws://test';
            compile = $compile;
            backend = $injector.get('$httpBackend');
            UserSrvc.clearUserCache();
            backend.whenGET('/svc/User/Login').respond(200, userJson.getCu());

        }));
        it('Test 1 should call web socket service get method', function() {
            spyOn(service,'get').andCallThrough();
            scope = rootScope.$new();
            scope.model = {test: 123};
            scope.id = 'test';
            elm = angular.element('<div persist="{{id}}" ng-model="model"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(service.get).toHaveBeenCalled();
        });
        it('Test 2 should call web socket service get method', function() {
            spyOn(service,'save').andCallThrough();
            scope = rootScope.$new();
            scope.model = {test: 123};
            scope.id = 'test';
            elm = angular.element('<div persist="{{id}}" ng-model="model"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            scope.model = {test: 224324};
            scope.$digest();
            timeout.flush();
            expect(service.save).not.toHaveBeenCalled();
        });
    });
});