/**
 * Created by philipplekhanov on 7/22/14.
 */
define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('ng-data directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should set data attribute if is IE9 flag is set to true', function() {
            rootScope.IEFlags = {isIE9: true};
            scope = rootScope.$new();
            scope.objectPdf = 'http://blahblahblah.com';
            elm = angular.element('<div ng-data="{{objectPdf}}"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('data')).toBeDefined();
        });
        it('Test 2 it should not set data if IE flags are not set', function() {
            rootScope.IEFlags = {isIE9: false};
            scope = rootScope.$new();
            scope.objectPdf = 'http://blahblahblah.com';
            elm = angular.element('<div ng-data="{{objectPdf}}"></div>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.attr('data')).not.toBeDefined();
        });
    });
});