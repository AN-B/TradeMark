define([
    'jquery',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function(){
    describe('SVG overlay directive spec - > ', function() {
        var scope,
            rootScope,
            elm,
            ctrl,
            cmp,
            elHtml;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));

        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector) {
            rootScope = $rootScope;
            scope = rootScope.$new();
            compile = $compile;
        }));

        it('Test 1 elm should be defined for icon svg-overlay', function() {
            elHtml = '<div svg-overlay svg-part="icon" default-picker-color="defIconPickerColor" elem-id=".colorPickerSvg" loaded-model="model.iconOverlayLoaded" ng-model="templates[selectedIndex].iconPickerColor"></div>';
            elm = compile(angular.element(elHtml))(scope);
            scope.$digest();
            expect(elm).toBeDefined();
        });

        it('Test 2 elm should be defined for icon background-overlay', function() {
            elHtml = '<div svg-overlay svg-part="bkgd" default-picker-color="defBkgdPickerColor" elem-id=".colorPickerBkgdSvg" loaded-model="model.bkgdOverlayLoaded" ng-model="templates[selectedIndex].bkgdPickerColor"></div>';
            elm = compile(angular.element(elHtml))(scope);
            scope.$digest();
            expect(elm).toBeDefined();
        });

        it('Test 3 elm should be defined', function() {
            elHtml = '<div svg-overlay svg-part="icon" svg-idx="{{$index}}" default-picker-color="defIconPickerColor" elem-id=".colorPickerSvg" loaded-model="model.iconOverlayLoaded" ng-model="item.iconPickerColor"></div>';
            elm = compile(angular.element(elHtml))(scope);
            scope.$digest();
            expect(elm).toBeDefined();
        });
    });
});
