define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('timeago directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document,
            timeout,
            interval,
            intervalSpy;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            timeout = $injector.get('$timeout');
            interval = $injector.get('$interval');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
            scope = rootScope.$new();
        }));
        it('Test 1 should exist and call updateTimeago', function() {
            rootScope.imageVersion = '123';
            scope.date = Date.now();
            elm = angular.element('<div timeago="{{date}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            spyOn(scope, 'updateTimeago').andCallThrough();
            scope.$digest();
            expect(scope.updateTimeago).not.toHaveBeenCalled();
        });
        it('Test 2 should call updateTimeago', function() {
            rootScope.imageVersion = '123';
            scope.date = Date.now();
            elm = angular.element('<div no-update timeago="{{date}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            spyOn(scope, 'updateTimeago').andCallThrough();
            scope.$digest();
            expect(scope.updateTimeago).not.toHaveBeenCalled();
        });
    });
});