define([
        'unitTests/ui-mocks/modal',
        'unitTests/ui-mocks/user.json',
        'unitTests/ui-mocks/tutorial.json',
        'static/source/core/collectionCache',
        'angular',
        'angular-mocks',
        'angular-resource',
        'hgapp-app'],
    function (modalMock, userJson, tutorialJson, cache) {

        describe('Tutorial service spec ->', function() {
            var tutorialService,
                userService,
                httpBackend,
                compile,
                modal,
                rootScope,
                scope,
                user,
                location,
                filteredTutorials,
                el;

            beforeEach(module("hgapp-app"));
            beforeEach(module("hgapp-services"));
            beforeEach(inject(function ($compile, $controller, $location, $injector, $rootScope, TutorialSrvc, UserSrvc) {
                user = {
                    CompletedTutorials : [],
                    RequiredTutorials: tutorialJson.getTutorials().RequiredTutorials,
                    UserContext: {
                        CurrentGroupName: 'Mercury Industries',
                        PermissionsInGroup: ['Tutorials']
                    }
                };
                modal = modalMock;
                compile = $compile;
                $rootScope.language = 'en';
                rootScope = $rootScope;
                filteredTutorials = [];
                httpBackend = $injector.get("$httpBackend");
                tutorialService =  TutorialSrvc;
                userService = UserSrvc;
                location = $location;
                el = '<div tutorial-modal></div>';

                location.path('/Recognize/Company/GiveEveryday');
                httpBackend.whenGET('templates/Tutorial/entemplate.html')
                    .respond(200);
                httpBackend.whenGET('/svc/User/Login').respond(200, user);
                httpBackend.whenPOST('/svc/Tutorial/CompleteMemberTutorials')
                    .respond(200, {
                        tutorialNumberCompleted: 1,
                        exitURL: '/Recognize/Company/GiveEveryday'
                    });
            }));
            afterEach(function () {
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });

            it('directive should call get user', function () {
                spyOn(userService, 'getUser').andCallThrough();
                scope = rootScope.$new();
                compile(el)(scope);
                scope.$digest();
                httpBackend.flush();
                expect(userService.getUser).toHaveBeenCalled();
            });

            xit('if give rec tutorials active, should open 5 tutorial modals', function () {
                spyOn(userService, 'getUser').andCallThrough();
                spyOn(tutorialService, 'bootstrapTutorial').andCallThrough();
                spyOn(tutorialService, 'openTutorialStepModal').andCallThrough();
                spyOn(rootScope, '$broadcast').andCallThrough();
                scope = rootScope.$new();
                compile(el)(scope);
                scope.$digest();
                expect(userService.getUser).toHaveBeenCalled();
                expect(tutorialService.openTutorialStepModal).toHaveBeenCalled();
                expect(rootScope.$broadcast).toHaveBeenCalledWith('modalIsOpen');

            });

        });
    });