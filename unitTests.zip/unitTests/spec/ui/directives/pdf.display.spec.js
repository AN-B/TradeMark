define(['angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(angular){

    describe('pdf-display directive spec -> ', function() {
        var scope,
            elm,
            ctrl,
            rootScope,
            compile,
            $document;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($compile, $rootScope, $templateCache, $injector, _$document_) {
            scope = $injector.get('$rootScope');
            rootScope = $rootScope;
            compile = $compile;
            $document = _$document_;
        }));
        it('Test 1 should set src of embed element for IE9', function() {
            scope = rootScope.$new();
            scope.test = '/test/test';
            elm = angular.element('<div pdf-display="{{test}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.find('embed').attr('src')).toBe('/test/test');

        });
        it('Test 2 should set src of iframe element for all other browsers', function() {
            scope = rootScope.$new();
            window.noIframe = true;
            scope.test = '/test/test';
            elm = angular.element('<div pdf-display="{{test}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.find('iframe').attr('src')).toBe('/test/test');
        });
        it('Test 3 element should not contain iframe or embed tag', function() {
            scope = rootScope.$new();
            window.noIframe = true;
            elm = angular.element('<div pdf-display="{{test}}"/>');
            compile(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(elm.find('iframe').attr('src')).not.toBeDefined();
            expect(elm.find('embed').attr('src')).not.toBeDefined();
        });
    });
});