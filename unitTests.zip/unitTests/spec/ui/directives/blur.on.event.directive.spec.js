define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){

    describe('blur on event directive spec -> ', function() {
        var scope, elm, $compile,
            rootScope,
            timeout;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function($injector, $rootScope) {
            timeout = $injector.get('$timeout');
            scope = $rootScope.$new();
            rootScope = $rootScope;
            $compile = $injector.get('$compile');
            elm = angular.element('<input type="text" blur-on-event="modalIsOpen" />');
            $compile(elm)(scope);
        }));
        it('Test 1 elm should be defined', function() {
            expect(elm).toBeDefined();
        });
        it('TEST 2 should blur when event broadcasted', function() {
            elm[0].focus();
            spyOn(elm[0], 'blur').andCallThrough();
            rootScope.$broadcast('modalIsOpen');
            timeout.flush();
            expect(elm[0].blur).toHaveBeenCalled();
            expect(scope.listener).toBeDefined();
            scope.$broadcast('$destroy');
        });
    });
});