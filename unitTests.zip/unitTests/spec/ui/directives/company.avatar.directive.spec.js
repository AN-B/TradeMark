define(['angular','angular-mocks','angular-resource','hgapp-app','templates/shared/company-avatar.html'], function(angular) {

    describe('company-avatar directive spec - > ', function() {
        var compile,
            scope,
            httpBackend,
            groupSrvc,
            rootScope;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(module('templates/shared/company-avatar.html'));
        beforeEach(inject(function ($compile, $rootScope, GroupSrvc, $injector) {
            httpBackend = $injector.get("$httpBackend");
            groupSrvc = GroupSrvc;
            rootScope =  $rootScope;
            compile = $compile;
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        function createElement(element) {
            var compiledElement;
            scope = rootScope.$new();
            scope.cmpAvt = {};
            compiledElement = compile(element)(scope);
            scope.$digest();
            return compiledElement;
        }
        it('Test element is defined', function () {
            var element =  createElement();
            expect(element).toBeDefined();
        });
        it('Verify Group Service is called ', function () {

			var element = angular.element("<div company-avatar></div>");
            httpBackend.whenGET('/svc/Group/GetCurrentGroup').respond(200, {
                hgId: '3cf21720-9cd2-11e2-a3a4-25024474fe63',
                GroupName: 'Test Company'});
            spyOn(groupSrvc, 'getCurrentGroup').andCallThrough();

			element = createElement(element);
			//
            httpBackend.flush();
            //   expect(element).toBeDefined();
             expect(scope.cmpAvt.company.hgId).toBe('3cf21720-9cd2-11e2-a3a4-25024474fe63');
             expect(groupSrvc.getCurrentGroup).toHaveBeenCalled();
             expect(scope.cmpAvt.company.GroupName).toBe('Test Company');
        });
    });
});
