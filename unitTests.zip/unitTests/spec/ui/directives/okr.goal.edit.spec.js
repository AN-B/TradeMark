define([
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){
    describe('okr goal edit delete button directive spec - > ', function() {
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));
        beforeEach(inject(function ($templateCache) {
            $templateCache.put('templates/Hgapp/Profile/okr/okr-goal-edit-delete.html',
                '<div ng-if="flags.edit">' +
                '<button ng-click="goalEdit(item, goal.hgId)" translate="common.edi"></button>' +
                '<button ng-click="deleteGoal(item, goal.hgId)" translate="common.dlt"></button>' +
                '</div>');

        }));
        it('Test 1 edit should be true MyRole is owner',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{
                        hgId: 'test',
                        Status: 'Editing',
                        Operations: {
                            Edit: true
                        }
                    }],
                    MyRole: "Owner",
                    ParticipantStatus: "NotStarted"
                };
                scope.goalId = 'test';

                var elm = angular.element('<div okr-goal-edit-delete="{{goalId}}" ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.edit).toBeTruthy();
            }));
        it('Test 2 edit should be false MyRole is not owner',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [],
                    MyRole: "something else",
                    ParticipantStatus: "NotStarted"
                };
                scope.goalId = 'test';

                var elm = angular.element('<div okr-goal-edit-delete="{{goalId}}" ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.edit).toBeFalsy();
            }));
        it('Test 3 edit should be true MyRole is owner and ParticipantStatus is Setting',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{
                        hgId: 'test',
                        Status: 'Editing',
                        Operations: {
                            Edit: true
                        }
                    }],
                    MyRole: "Owner",
                    ParticipantStatus: "Setting"
                };
                scope.goalId = 'test';

                var elm = angular.element('<div okr-goal-edit-delete="{{goalId}}" ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.edit).toBeTruthy();
            }));
        it('Test 4 edit should be false MyRole is owner and ParticipantStatus is not Setting or NotStarted',
            inject(function ($compile, $rootScope) {
                var scope = $rootScope.$new();
                scope.model = {
                    Goals: [{
                        hgId: 'test',
                        Status: 'Editing',
                        Operations: {
                            Edit: false
                        }
                    }],
                    MyRole: "Owner",
                    ParticipantStatus: "something"
                };
                scope.goalId = 'test';

                var elm = angular.element('<div okr-goal-edit-delete="{{goalId}}" ng-model="model"/>');
                $compile(elm)(scope);
                scope.$digest();
                var ctrl = elm.scope();
                expect(ctrl.flags.edit).toBeFalsy();
            }));
    });
});
