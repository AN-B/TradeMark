define(['unitTests/ui-mocks/user.json',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson){
    describe('Persist directive spec - > ', function() {
        var scope,
            elm,
            ctrl,
            q,
            cmp,
            timeout,
            service,
            userService,
            httpBackend;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-directives"));

        beforeEach(inject(function($compile, $rootScope, $injector, ioSrvc, $q, $timeout, UserSrvc) {
            userService = UserSrvc;
            service = ioSrvc;
            timeout = $timeout;
            cmp = $compile;
            q = $injector.get("$q");
            httpBackend = $injector.get("$httpBackend");
            scope = $rootScope.$new();
            userService.clearUserCache();
            httpBackend.whenGET('/svc/User/Login').respond(200, userJson.getCu());
        }));
        it('Test 1 on load directive should call io service.get and remove listener', function() {
            scope.model = {};
            spyOn(service, 'get').andCallFake(function(param){
                var deferred = q.defer();
                deferred.resolve({test: 'something'});
                return deferred.promise;
            });
            spyOn(service, 'removeListeners').andCallFake(function(){});
            elm = angular.element('<button persist="test" ng-model="something"/>');
            cmp(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            expect(service.get).toHaveBeenCalled();
            expect(service.removeListeners).toHaveBeenCalledWith('test');
        });
        it('Test 2 on model changes it should call io service save', function() {
            scope.model = {};
            spyOn(service, 'get').andCallFake(function(param, callback){
                var deferred = q.defer();
                deferred.resolve({test: 'something'});
                return deferred.promise;
            });
            spyOn(service, 'removeListeners').andCallFake(function(){});
            spyOn(service, 'save').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve();
                return deferred.promise;
            });
            elm = angular.element('<button persist="test" ng-model="something"/>');
            cmp(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            scope.model = {test: 'blah'};
            scope.model = {test: 'nothing'};
            timeout.flush();
            expect(service.save).toHaveBeenCalled();
        });
        it('Test 3 on click it should call io service clear event', function() {
            scope.model = {};
            spyOn(service, 'get').andCallFake(function(param){
                var deferred = q.defer();
                deferred.resolve({test: 'something'});
                return deferred.promise;
            });
            spyOn(service, 'removeListeners').andCallFake(function(){});
            spyOn(service, 'clear').andCallFake(function(){
                var deferred = q.defer();
                deferred.resolve();
                return deferred.promise;
            });
            elm = angular.element('<button type="button" persist="test" ng-model="something"/>');
            cmp(elm)(scope);
            ctrl = elm.scope();
            scope.$digest();
            scope.model = {test: 'blah'};
            elm.triggerHandler('click');
            expect(service.clear).toHaveBeenCalled();
        });
    });
});
