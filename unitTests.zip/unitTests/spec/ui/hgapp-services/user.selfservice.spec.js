define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('User Self Service service spec ->', function() {
		var service,
			httpBackend;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-services"));
		beforeEach(inject(function ($injector, UserSelfSrvc) {
			service = UserSelfSrvc;
			httpBackend = $injector.get("$httpBackend");
			httpBackend.whenPOST("/svc/UserSelf/SwitchCurrentGroup")
				.respond(200, 'SwitchCurrentGroup was called');
		}));
		afterEach(function () {
			httpBackend.verifyNoOutstandingExpectation();
			httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 user self service should be defined', function (){
			expect(service).toBeDefined();
		});
		it('Test 2 getByGroupId should call /svc/UserSelf/SwitchCurrentGroup', function (){
			var test;
			service.getByGroupId('nothing').then(function(data){
				return test = data;
			});
			httpBackend.flush();
			expect(test).toBe('SwitchCurrentGroup was called');
		});
	});
});