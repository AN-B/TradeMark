define([
    'unitTests/ui-mocks/group.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
    ], function(groupJson) {
    describe('group service spec ->', function() {
        var service,
            $httpBackend;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, GroupSrvc) {
            service = GroupSrvc;
            $httpBackend = $injector.get("$httpBackend");
        }));
        afterEach(function () {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 Group Service service should be defined', function (){
            expect(service).toBeDefined();
        });
        it('Test 2 GroupSrvc service should call /svc/Group/GetGroupDisplaySettings', function () {
            $httpBackend.whenGET("/svc/Group/GetGroupDisplaySettings")
                .respond(200, groupJson.getGroupDisplaySettings());
            var test,
                error;
            service.getGroupDisplaySettings({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
        });
        it('Test 3 GroupSrvc service should call /svc/Group/SaveDisplaySettings', function () {
            $httpBackend.whenPOST("/svc/Group/SaveDisplaySettings")
                .respond(200, groupJson.getGroupDisplaySettings());
            var test,
                error;
            service.saveDisplaySettings({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
        });
    });
});
