define([
    'unitTests/ui-mocks/perform.card.edit.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(cardJson){

    describe('Perform admin service spec', function() {
        var service,
            httpBackend;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, PerformAdminSrvc) {
            service = PerformAdminSrvc;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET("/svc/Performance/GetCardByIdForBuilder?cardId=cardId")
                .respond(200, cardJson.get());
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: Perform admin service should be defined', function (){
            expect(service).toBeDefined();
        });
        it('Test 2: getCardDtoById should call /svc/Performance/GetCardByIdForBuilder', function (){
            var response;
            service.getCardDtoById({CardId: 'cardId'}).then(function(data){
                return response = data;
            });
            httpBackend.flush();
            expect(response.hgId).toBe('72a3c130-101c-11e3-bba0-8d9c8faa9d96');
        });
        it('Test 3: setCycleCache should set cache and getCycleCache', function (){
            var obj = {test: []},
                test;
            service.setCycleCache('id', obj);
            test = service.getCycleCache('id');
            expect(test.test.length).toBe(0);
        });
    });
});