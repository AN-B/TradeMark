define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('Recognition service spec ->', function() {
		var service,
			$httpBackend;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-services"));
		beforeEach(inject(function ($injector, RecognitionSrvc) {
			service = RecognitionSrvc;
			$httpBackend = $injector.get("$httpBackend");
			$httpBackend.whenPOST("/svc/Recognition/GiveEverydayRecognition")
				.respond(200, 'GiveEverydayRecognition called');
			$httpBackend.whenPOST("/svc/Recognition/GiveValueRecognition")
				.respond(200, 'GiveValueRecognition called');
			$httpBackend.whenPOST("/svc/Recognition/GiveCustomizedRecognition")
				.respond(200, 'GiveCustomizedRecognition called');
			$httpBackend.whenPOST("/svc/Recognition/GiveAchievementRecognition")
				.respond(200, 'GiveAchievementRecognition called');
			$httpBackend.whenGET("/svc/UI/GetAchievementTemplates")
				.respond(200, 'GetAchievementTemplates called');
			$httpBackend.whenGET("/svc/Recognition/GetEverydayTemplates")
				.respond(200, 'GetEverydayTemplates called');
			$httpBackend.whenGET("/svc/UI/GetValueRecognitionTemplates")
				.respond(200, 'GetValuesTemplates called');

		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 badge admin service should be defined', function (){
			expect(service).toBeDefined();
		});
		it('Test 2 giveEverydayRec should call /svc/Recognition/GiveEverydayRecognition', function (){
			var value;
			service.giveEverydayRec('test').then(function(data){
				return value = data;
			});
			$httpBackend.flush();
			expect(value).toBe('GiveEverydayRecognition called');
		});
		it('Test 3 giveValueRec should call /svc/Recognition/GiveValueRecognition', function (){
			var value;
			service.giveValueRec('test').then(function(data){
				return value = data;
			});
			$httpBackend.flush();
			expect(value).toBe('GiveValueRecognition called');
		});
		it('Test 4 giveCustomizedRec should call /svc/Recognition/GiveCustomizedRecognition', function (){
			var value;
			service.giveCustomizedRec().then(function(data){
				return value = data;
			});
			$httpBackend.flush();
			expect(value).toBe('GiveCustomizedRecognition called');
		});
		it('Test 5 giveAchievementRec should call /svc/UI/GiveAchievementRecognition', function (){
			var value;
			service.giveAchievementRec().then(function(data){
				return value = data;
			});
			$httpBackend.flush();
			expect(value).toBe('GiveAchievementRecognition called');
		});
		it('Test 6 getAchievementTemplates should call /svc/Recognition/GetAchievementTemplates ', function (){
			var value;
			service.getAchievementTemplates().then(function(data){
				return value = data;
			});
			$httpBackend.flush();
			expect(value).toBe('GetAchievementTemplates called');
		});
		it('Test 7 getEverydayTemplates should call /svc/Recognition/GetEverydayTemplates', function (){
			var value;
			service.getEverydayTemplates().then(function(data){
				return value = data;
			});
			$httpBackend.flush();
			expect(value).toBe('GetEverydayTemplates called');
		});
		it('Test 8 getValuesTemplates should call /svc/Recognition/GetValuesTemplates', function (){
			var value;
			service.getValueTemplates().then(function(data){
				return value = data;
			});
			$httpBackend.flush();
			expect(value).toBe('GetValuesTemplates called');
		});
	});
});
