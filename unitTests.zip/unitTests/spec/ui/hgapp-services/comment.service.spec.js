define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
    describe('Comment service spec ->', function() {
        var service,
            $httpBackend;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, CommentSrvc) {
            service = CommentSrvc;
            $httpBackend = $injector.get("$httpBackend");
            $httpBackend.whenPOST("/svc/Comment/CommentBatch")
                .respond(200,{value: 'done'});
            $httpBackend.whenPOST("/svc/Comment/CommentRecognition")
                .respond(200,{value: 'done'});
            $httpBackend.whenGET("/svc/Comment/GetCommentByBatchId?BatchId=test")
                .respond(200,{value: 'done'});
        }));
        afterEach(function () {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 comment service should be defined', function (){
            expect(service).toBeDefined();
        });
        it('Test 2 commentBatch should call /svc/Comment/CommentBatch', function (){
            var value = '';
            service.commentBatch({}).then(function(data){
                return value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });
        it('Test 3 getCommentsByBatchId should call /svc/Comment/GetCommentsByBatchId', function (){
            var value = '';
            service.getCommentsByBatchId('test').then(function(data){
                return value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });
        it('Test 5 getCommentsEntityType should call "/svc/Comment/Get" with entity Id and type', function (){
            var entityId = 'blah',
                type = 'Milestone',
                value;
            $httpBackend.whenGET("/svc/Comment/Get?entityId=blah&entityType=Milestone")
                .respond(200,{value: 'done'});
            service.getCommentsEntityType(entityId, type).then(function(data){
                return value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });
        it('Test 6 getCommentsEntityType should call "/svc/Comment/Get" with entity Id and type recognition default', function (){
            var entityId = 'blah',
                value;
            $httpBackend.whenGET("/svc/Comment/Get?entityId=blah&entityType=Recognition")
                .respond(200,{value: 'done'});
            service.getCommentsEntityType(entityId).then(function(data){
                return value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });

    });
});