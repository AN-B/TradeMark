define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'
], function () {
    describe('spec', function () {
        var toastrSrvc,
            ngtoastr,
            httpBackend;

        beforeEach(module('hgapp-app'));
        beforeEach(module('hgapp-services'));
        beforeEach(module('pascalprecht.translate'));
        beforeEach(inject(function ($injector, ToastrSrvc, toastr) {
            toastrSrvc = ToastrSrvc;
            ngtoastr = toastr;
            httpBackend = $injector.get('$httpBackend');

        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1 ToastrSrvc should be defined', function () {
            expect(toastrSrvc).toBeDefined();
        });

        it('Test 2 ToastrSrvc.success should call toastr', function () {
            spyOn(ngtoastr, 'success').andCallThrough();
            toastrSrvc.success('test');
            expect(ngtoastr.success).toHaveBeenCalledWith('test', undefined);
        });

        it('Test 3 ToastrSrvc.info should call toastr', function () {
            spyOn(ngtoastr, 'info').andCallThrough();
            toastrSrvc.info('test');
            expect(ngtoastr.info).toHaveBeenCalledWith('test', undefined);
        });

        it('Test 4 ToastrSrvc.error should call toastr', function () {
            spyOn(ngtoastr, 'error').andCallThrough();
            toastrSrvc.error('test');
            expect(ngtoastr.error).toHaveBeenCalledWith('test', undefined);
        });

        it('Test 5 ToastrSrvc.warning should call toastr', function () {
            spyOn(ngtoastr, 'warning').andCallThrough();
            toastrSrvc.warning('test');
            expect(ngtoastr.warning).toHaveBeenCalledWith('test', undefined);
        });

        it('Test 6 ToastrSrvc.success should call with message and title', function () {
            spyOn(ngtoastr, 'success').andCallThrough();
            toastrSrvc.success('message', 'title');
            expect(ngtoastr.success).toHaveBeenCalledWith('message', 'title');
        });

        it('Test 7 ToastrSrvc.success should translate simple translation', function () {
            spyOn(ngtoastr, 'success').andCallThrough();
            toastrSrvc.success('common.suc', 'common.suc');
            expect(ngtoastr.success).toHaveBeenCalledWith('Success!', 'Success!');
        });

        it('Test 8 ToastrSrvc.success should translate complex JSON string', function () {
            var payload = JSON.stringify(['common.hel', {item: 'World!'}]);
            spyOn(ngtoastr, 'success').andCallThrough();
            toastrSrvc.success(payload, payload);
            expect(ngtoastr.success).toHaveBeenCalledWith('Hello World!', 'Hello World!');
        });

        it('Test 9 ToastrSrvc.success should translate complex translation object', function () {
            var payload = ['common.hel', {item: 'WORLD!'}];
            spyOn(ngtoastr, 'success').andCallThrough();
            toastrSrvc.success(payload, payload);
            expect(ngtoastr.success).toHaveBeenCalledWith('Hello WORLD!', 'Hello WORLD!');
        });
    });
});