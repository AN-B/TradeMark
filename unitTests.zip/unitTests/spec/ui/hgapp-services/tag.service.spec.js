define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('Tag service spec ->', function() {
		var service,
			$httpBackend,
			http;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-services"));
		beforeEach(inject(function ($injector, TagSrvc, $http) {
			service = TagSrvc;
			http = $http;
			$httpBackend = $injector.get("$httpBackend");
		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1: team service should be defined', function (){
			expect(service).toBeDefined();
		});
		it('Test 2: addTag should call /svc/Tag/AddTag', function (){
			var value = '';
			$httpBackend.whenPOST("/svc/Tag/AddTag")
				.respond(200, {value: 'added'});
			service.addTag({}).then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('added');
		});

		it('Test 3: addTag should call fail', function (){
			var value = '';
			$httpBackend.whenPOST("/svc/Tag/AddTag")
				.respond(500, 'error');
			service.addTag({}).then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});
		it('Test 4: removeTag should call /svc/Tag/RemoveEntityTag', function (){
			var value = '';
			$httpBackend.whenPOST("/svc/Tag/RemoveEntityTag")
				.respond(200, {value: 'removed'});
			service.removeTag({}).then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('removed');
		});

		it('Test 5: removeTag should fail', function (){
			var value = '';
			$httpBackend.whenPOST("/svc/Tag/RemoveEntityTag")
				.respond(500, 'error');
			service.removeTag({}).then(function () {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});
		it('Test 6: getMemberTags should call /svc/Tag/GetMemberTags', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Tag/GetMemberTags")
				.respond(200, ['mytag']);
			service.getMemberTags().then(function(res){
				value = res;
			});
			$httpBackend.flush();
			expect(value.length).toBe(1);
		});
		it('Test 7: getMemberTags should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Tag/GetMemberTags")
				.respond(500, 'error');
			service.getMemberTags().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});
	});
});
