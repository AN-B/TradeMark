define(['unitTests/ui-mocks/user.json', 'static/source/core/collectionCache', 'angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(userJson, cache){

    describe('User service spec ->', function() {
        var userService,
            httpBackend,
            location;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(module("ngRoute"));
        beforeEach(inject(function ($injector, UserSrvc) {
            httpBackend = $injector.get("$httpBackend");
            location = $injector.get("$location");
            userService =  UserSrvc;
            cache.clear('user');

            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenPOST('/svc/User/Login')
                .respond(200, userJson.getCu());
            httpBackend.whenGET('/svc/User/Logout')
                .respond(200, 'logged out');
            httpBackend.whenPOST('/svc/User/RegisterNewUser')
                .respond(200, 'register was called');
            httpBackend.whenPOST('/svc/User/RequestResetPassword')
                .respond(200, 'reset was called');
            httpBackend.whenGET('/pulse')
                .respond(200, 'pulse was called');
            spyOn(location, 'path').andReturn('test/test');
            //spyOn(location, 'path').andCallFake(function(){
            //	callbackCalled = true;
            //});

        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 user service should be defined', function(){

            expect(userService).toBeDefined();
        });
        it('Test 2 getUser should call /svc/User/Login', function (){
            var response = {};
            userService.getUser().then(function(data){
                return response = data;
            });
            httpBackend.flush();
            expect(response.hgId).toBe('d2c0ef10-a119-11e2-b177-7d64c8315189');
        });
        it('Test 3 logout() should call /svc/User/Logout', function (){
            var response = {};
            userService.logout().then(function(data){
                return response = data;
            });
            httpBackend.flush();
            expect(response).toBe('logged out');
        });
        it('Test 4 reset() should call /svc/User/RequestResetPassword', function (){
            var response = {};
            userService.reset('test').then(function(data){
                return response = data;
            });
            httpBackend.flush();
            expect(response).toBe('reset was called');
        });
        it('Test 5 getPulse() should call /pulse', function (){
            var response = {};
            userService.getPulse().then(function(data){
                return response = data;
            });
            httpBackend.flush();
            expect(response).toBe('pulse was called');
        });
        it('Test 6 login should call /svc/User/Login', function (){
            var response = {};
            userService.login({test: 'test'}).then(function(data){
                return response = data;
            });
            httpBackend.flush();
            expect(response.hgId).toBe('d2c0ef10-a119-11e2-b177-7d64c8315189');
        });
        it('Test 7 isDisableFeature should check location path', function (){
          var callbackCalled;
            userService.isDisableFeature('trackTabs','summary',function (){
                callbackCalled = true;
            });
            httpBackend.flush();
            expect(callbackCalled).toBeTruthy();
        });
        it('Test 8 isDisableFeature should change location path', function (){
            var callbackCalled;

            userService.isDisableFeature('trackTabs','mock',function (){
                callbackCalled = false;
            });
            httpBackend.flush();
            expect(location.path).toHaveBeenCalled();
        });
        it('Test 9 should set the cache', function (){
            var test;
            userService.getUser().then(function (data){
                test = data;
            });
            httpBackend.flush();
            expect(test._id).toBeDefined();
            userService.setUserCache({});
            userService.getUser().then(function (data){
                test = data;
                expect(test._id).not.toBeDefined();
            });
        });

        it('Test 10 should get user permissions', function (){
            var test;
            userService.getPermissionsMap().then(function(data) {
                test = data;
            });
            httpBackend.flush();
            expect(test.PermissionsInGroup).toBeDefined();
            expect(test.AggregatedSecuredTabs).toBeDefined();
        });

    });
});