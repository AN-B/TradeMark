define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
    describe('feedback session service spec ->', function() {
        var service;

        function getRequest() {
            return [
                {
                    Required: true,
                    Type: 'ShortAnswer',
                    Answer: {
                        Text:'',
                        SelectedValues: []
                    }
                }, {
                    Required: true,
                    Type: 'Options',
                    Answer: {
                        Text:'',
                        SelectedValues: []
                    }
                } , {
                    Required: true,
                    Type: 'Options',
                    Answer: {
                        Text: '',
                        SelectedValues: []
                    }
                }
            ];
        }

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp.ctrl.services"));
        beforeEach(inject(function ($injector, FeedbackCtrlSrvc) {
            service = FeedbackCtrlSrvc;
        }));

        it('Test 1 feedback session service should be defined', function (){
            expect(service).toBeDefined();
        });
        it('Test 2 ', function (){
            expect(service.getIndex(getRequest())).toBe(0);
        });
        it('Test 3 ', function (){
            var test = getRequest();
            test[0].Answer.Text = '123';
            expect(service.getIndex(test)).toBe(0);
        });
        it('Test 4 ', function (){
            var test = getRequest();
            test[0].Answer.Text = '123';
            test[1].Answer.SelectedValues = ['123'];
            expect(service.getIndex(test)).toBe(1);
        });
        it('Test 4 ', function (){
            var test = getRequest();
            test[0].Answer.Text = '123';
            test[1].Answer.SelectedValues = ['123'];
            test[2].Answer.SelectedValues = ['123'];
            expect(service.getIndex(test)).toBe(2);
        });

    });
});