define([
    'static/source/core/utility/cookies',
    'unitTests/ui-mocks/socket.io.mock',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(cookies, io){

    describe('io service spec -->', function() {
        var service,
            socket;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, ioSrvc) {
            service = ioSrvc;
            socket = io();
        }));
        it('Test 1 io service should be defined', function (){
            expect(service).toBeDefined();
        });
        xit('Test 2 io service should be defined', function (){
            cookies.userToken = 'test';
            service.init('test');
            socket.emit('connect');
        });
    });
});