define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
    describe('Manager Alert service spec ->', function() {
        var service,
            $httpBackend;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, ManagerAlertSrvc) {
            service = ManagerAlertSrvc;
            $httpBackend = $injector.get("$httpBackend");
        }));
        afterEach(function () {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1: manager alert service should be defined', function (){
            expect(service).toBeDefined();
        });
        it('Test 2: getMyTeamAlerts should call /svc/ManagerAlert/GetMyTeamAlerts', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetMyTeamAlerts?memberId=123&skip=0&take=9")
                .respond(200, {alerts: [1, 2, 3], weights: [1, 2, 3]});
            service.getMyTeamAlerts({memberId:123,skip:0,take:9}).then(function(res){
                value = res.alerts;
            });
            $httpBackend.flush();
            expect(value.length).toBe(3);
        });
        it('Test 3: getMyTeamAlerts should fail', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetMyTeamAlerts?memberId=123&skip=0&take=9")
                .respond(500, 'error');
            service.getMyTeamAlerts({memberId:123,skip:0,take:9}).then(function() {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });
        it('Test 4: getRecogntizeTeamStats should call /svc/ManagerAlert/GetRecognizeTeamStats', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetRecognizeTeamStats?memberId=123&skip=0&take=9")
                .respond(200, {value: [1, 2, 3]});
            service.getRecognizeTeamStats({memberId:123,skip:0,take:9}).then(function(res){
                value = res.value;
            });
            $httpBackend.flush();
            expect(value.length).toBe(3);
        });
        it('Test 5: getRecogntizeTeamStats should fail', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetRecognizeTeamStats?memberId=123&skip=0&take=9")
                .respond(500, 'error');
            service.getRecognizeTeamStats({memberId:123,skip:0,take:9}).then(function() {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });
        it('Test 6: getCoachingTeamStats should call /svc/ManagerAlert/GetCoachingTeamStats', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetCoachingTeamStats?memberId=123&skip=0&take=9")
                .respond(200, {value: [1, 2, 3]});
            service.getCoachingTeamStats({memberId:123,skip:0,take:9}).then(function(res){
                value = res.value;
            });
            $httpBackend.flush();
            expect(value.length).toBe(3);
        });
        it('Test 7: getCoachingTeamStats should fail', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetCoachingTeamStats?memberId=123&skip=0&take=9")
                .respond(500, 'error');
            service.getCoachingTeamStats({memberId:123,skip:0,take:9}).then(function() {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });
        it('Test 8: getPerformTeamStats should call /svc/ManagerAlert/GetPerformTeamStats', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetPerformTeamStats?memberId=123&skip=0&take=9")
                .respond(200, {value: [1, 2, 3]});
            service.getPerformTeamStats({memberId:123,skip:0,take:9}).then(function(res){
                value = res.value;
            });
            $httpBackend.flush();
            expect(value.length).toBe(3);
        });
        it('Test 9: getPerformTeamStats should fail', function (){
            var value = '';
            $httpBackend.whenGET("/svc/ManagerAlert/GetPerformTeamStats?memberId=123&skip=0&take=9")
                .respond(500, 'error');
            service.getPerformTeamStats({memberId:123,skip:0,take:9}).then(function() {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });
    });
});