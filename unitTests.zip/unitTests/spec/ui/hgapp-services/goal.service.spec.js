define([
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(){

    describe('Goal service spec -->', function() {
        var service,
            backend,
            rootScope;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, GoalSrvc, $rootScope) {
            service = GoalSrvc;
            rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/Performance/GetQuestionLibrary')
                .respond(200, []);
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 goal service should be defined', function (){
            expect(service).toBeDefined();
        });
        it('Test 2: on GoalCommentAdded event service should broadcast GoalCommentsUpdated', function (){
            spyOn(rootScope, '$broadcast').andCallThrough();
            rootScope.$broadcast('GoalCommentAdded', 'test');
            expect(rootScope.$broadcast).toHaveBeenCalledWith('GoalCommentAdded', 'test');
        });
    });
});
