define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){

    describe('Notification service spec', function() {
        var service,
            httpBackend;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector) {
            httpBackend = $injector.get("$httpBackend");
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('notification service should be defined', inject(function (_NotificationSrvc_){
            service = _NotificationSrvc_;
            expect(service).toBeDefined();
        }));
        it('getUnViewedRecognition should call /svc/Notification/GetUnViewedRecognition', inject(function (_NotificationSrvc_) {
            service = _NotificationSrvc_;
            var value = [];
            httpBackend.whenGET("/svc/Notification/GetUnViewedRecognition")
                .respond(200, {value: [1, 2, 3]});
            spyOn(service, 'getUnViewedRecognition').andCallThrough();
            service.getUnViewedRecognition().then(function(data) {
                return value = data.value;
            });
            httpBackend.flush();
            expect(value.length).toBe(3);
        }));
    });
});