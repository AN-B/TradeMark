define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function() {
    describe('Survey Service Spec -> ', function() {
        var service,
            httpBackend,
            timeout;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, $timeout, SurveySrvc) {
            service = SurveySrvc;
            timeout = $timeout;
            httpBackend = $injector.get("$httpBackend");
        }));

        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Test 1: Survey Service should be defined', function() {
            expect(service).toBeDefined();
        });

        it('Test 2: getGroupBenchmarkSurveyTemplate should call /svc/Survey/GetGroupBenchmarkSurveyTemplate', function() {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetGroupBenchmarkSurveyTemplate')
                .respond(200,{value: 'done'});
            service.getGroupBenchmarkSurveyTemplate({}).then(function (data) {
                return value = data.value;
            });
            httpBackend.flush();
            timeout.flush();
            expect(value).toBe('done');
        });

        it('Test 3: getGroupBenchmarkSurveyTemplate should fail', function (){
            var result = '';
            httpBackend.whenGET('/svc/Survey/GetGroupBenchmarkSurveyTemplate')
                .respond(500, 'error');
            service.getGroupBenchmarkSurveyTemplate({}).then(function () {},
                function () {
                    result = 'error';
                });
            httpBackend.flush();
            timeout.flush();
            expect(result).toEqual('error');
        });

        it('Test 4: saveBenchmarkSurveyTemplate should call /svc/Survey/SaveBenchmarkSurveyTemplate', function() {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/SaveGroupBenchmarkSurveyTemplate')
                .respond(200,{value: 'done'});
            service.saveGroupBenchmarkSurveyTemplate({}).then(function (data) {
                return value = data.value;
            });
            httpBackend.flush();
            timeout.flush();
            expect(value).toBe('done');
        });

        it('Test 5: saveBenchmarkSurveyTemplate should fail', function() {
            var result = '';
            httpBackend.whenPOST('/svc/Survey/SaveGroupBenchmarkSurveyTemplate')
                .respond(500, 'error');
            service.saveGroupBenchmarkSurveyTemplate({}).then(function () {},
                function () {
                    result = 'error';
                });
            httpBackend.flush();
            timeout.flush();
            expect(result).toBe('error');
        });

        it('Test 6: scheduleBenchmarkSurvey should call /svc/Survey/ScheduleBenchmarkSurvey', function() {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/ScheduleBenchmarkSurvey')
                .respond(200,{value: 'done'});
            service.scheduleBenchmarkSurvey({}).then(function (data) {
                return value = data.value;
            });
            httpBackend.flush();
            timeout.flush();
            expect(value).toBe('done');
        });

        it('Test 7: scheduleBenchmarkSurvey should fail', function() {
            var result = '';
            httpBackend.whenPOST('/svc/Survey/ScheduleBenchmarkSurvey')
                .respond(500, 'error');
            service.scheduleBenchmarkSurvey({}).then(function () {},
                function () {
                    result = 'error';
                });
            httpBackend.flush();
            timeout.flush();
            expect(result).toBe('error');
        });

        it('Test 8: cancelBenchmarkSurvey should call /svc/Survey/CancelBenchmarkSurvey', function() {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/CancelBenchmarkSurvey')
                .respond(200,{value: 'done'});
            service.cancelBenchmarkSurvey({}).then(function (data) {
                return value = data.value;
            });
            httpBackend.flush();
            timeout.flush();
            expect(value).toBe('done');
        });

        it('Test 9: cancelBenchmarkSurvey should fail', function() {
            var result = '';
            httpBackend.whenPOST('/svc/Survey/CancelBenchmarkSurvey')
                .respond(500, 'error');
            service.cancelBenchmarkSurvey({}).then(function () {},
                function () {
                    result = 'error';
                });
            httpBackend.flush();
            timeout.flush();
            expect(result).toBe('error');
        });

        it('Test 10: disableBenchmarkSurvey should call /svc/Survey/DisableBenchmarkSurvey', function() {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/DisableBenchmarkSurvey')
                .respond(200,{value: 'done'});
            service.disableBenchmarkSurvey({}).then(function (data) {
                return value = data.value;
            });
            httpBackend.flush();
            timeout.flush();
            expect(value).toBe('done');
        });

        it('Test 11: disableBenchmarkSurvey should fail', function() {
            var result = '';
            httpBackend.whenPOST('/svc/Survey/DisableBenchmarkSurvey')
                .respond(500, 'error');
            service.disableBenchmarkSurvey({}).then(function () {},
                function () {
                    result = 'error';
                });
            httpBackend.flush();
            timeout.flush();
            expect(result).toBe('error');
        });

        it('Test 12: getAllMyBenchmarkSurveyQuestions should call /svc/Survey/GetAllMyBenchmarkSurveyQuestions', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions').respond(200, {value: 'done'});
            service.getAllMyBenchmarkSurveyQuestions().then(function (data) {
                value = data.value;
            });
            httpBackend.flush();
            expect(value).toBe('done');
        });


        it('Test 14: getAllMyBenchmarkSurveyQuestions should fail', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetAllMyBenchmarkSurveyQuestions').respond(500, 'error');
            service.getAllMyBenchmarkSurveyQuestions().then(function () {},
                function (response) {
                    value = response.data;
                });
            httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 15: submitBenchmarkAnswer should call /svc/Survey/AnswerBenchmarkSurvey', function () {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/AnswerBenchmarkSurvey').respond(200, {value: 'done'});
            service.answerBenchmarkSurveyQuestion().then(function (data) {
                value = data.value;
            });
            httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 16: answerBenchmarkSurveyQuestion should fail', function () {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/AnswerBenchmarkSurvey').respond(500, 'error');
            service.answerBenchmarkSurveyQuestion().then(function () {},
                function (response) {
                    value = response.data;
                });
            httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 17: HasPendingBenchmarkSurvey should call /svc/Survey/HasPendingBenchmarkSurvey', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/HasPendingBenchmarkSurvey').respond(200, {value : true});
            service.hasPendingBenchmarkSurvey().then(function (data) {
                value = data.value;
            });
            httpBackend.flush();
            expect(value).toBe(true);
        });

        it('Test 18: HasPendingBenchmarkSurvey should fail', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/HasPendingBenchmarkSurvey').respond(500, 'error');
            service.hasPendingBenchmarkSurvey().then(function () {},
                function (response) {
                    value = response.data;
                });
            httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 19: startBenchmarkSurvey should call /svc/Survey/StartBenchmarkSurvey', function () {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/StartBenchmarkSurvey').respond(200, {value: 'done'});
            service.startBenchmarkSurvey().then(function (data) {
                value = data.value;
            });
            httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 20: startBenchmarkSurvey should fail', function () {
            var value = '';
            httpBackend.whenPOST('/svc/Survey/StartBenchmarkSurvey').respond(500, 'error');
            service.startBenchmarkSurvey().then(function () {},
                function (response) {
                    value = response.data;
                });
            httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 21: getSurveyResult should call /svc/Survey/GetBenchmarkSurveyResult', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyResult?currentRoundId=test&recurrenceId=test&surveyId=test').respond(200, {value : 'done'});
            service.getSurveyResult({
                surveyId: 'test',
                recurrenceId: 'test',
                currentRoundId: 'test'
            }).then(function (data) {
                value = data.value;
            });
            httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 23: getSurveyComments should call /svc/Survey/GetBenchmarkSurveyComments', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyComments?currentRoundId=zoo&driverId=baz&keyword=test&recurrenceId=bar&skip=0&surveyId=foo&take=10').respond(200, {value : 'done'});
            service.getSurveyComments({
                surveyId: 'foo',
                recurrenceId: 'bar',
                driverId: 'baz',
                currentRoundId: 'zoo',
                skip: 0,
                take: 10,
                keyword: 'test'
            }).then(function (data) {
                value = data.value;
            });
            httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 24: getSurveyComments should fail', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyComments?currentRoundId=zoo&driverId=baz&recurrenceId=bar&skip=0&surveyId=foo&take=10').respond(500, 'error');
            service.getSurveyComments({
                surveyId: 'foo',
                recurrenceId: 'bar',
                currentRoundId: 'zoo',
                driverId: 'baz',
                skip: 0,
                take: 10
            }).then(function () {},
                function (response) {
                    value = response.data;
                });
            httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 25: getResultList should call /svc/Survey/GetBenchmarkSurveyResultList', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyResultList?skip=0&take=10').respond(200, {value : 'done'});
            service.getResultList({
                skip: 0,
                take: 10
            }).then(function (data) {
                value = data.value;
            });
            httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 26: getResultList should fail', function () {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetBenchmarkSurveyResultList?skip=0&take=10').respond(500, 'error');
            service.getResultList({
                skip: 0,
                take: 10
            }).then(function () {},
                function (response) {
                    value = response.data;
                });
            httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 27: GetGroupBenchmarkSurveyTemplatePreview should call /svc/Survey/GetGroupBenchmarkSurveyTemplatePreview', function() {
            var value = '';
            httpBackend.whenGET('/svc/Survey/GetGroupBenchmarkSurveyTemplatePreview')
                .respond(200,{value: 'done'});
            service.getGroupBenchmarkSurveyTemplatePreview({}).then(function (data) {
                return value = data.value;
            });
            httpBackend.flush();
            timeout.flush();
            expect(value).toBe('done');
        });
    });
});
