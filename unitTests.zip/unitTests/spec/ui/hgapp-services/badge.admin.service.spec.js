define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('Badge admin service spec ->', function() {
		var service,
			$httpBackend;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-services"));
		beforeEach(inject(function ($injector, BadgeAdminSrvc) {
			service = BadgeAdminSrvc;
			$httpBackend = $injector.get("$httpBackend");
			$httpBackend.whenGET("/svc/Badge/GetBadgesForCustomizedRecognition")
				.respond(200, {value: [1, 2, 3]});
			$httpBackend.whenGET("/svc/Badge/GetBadgesForValueBorder")
				.respond(200, {value: [1, 2, 3]});
		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 badge admin service should be defined', function (){
			expect(service).toBeDefined();
		});
		it('Test 2 getCustomBadges should call svc/Badge/GetBadgesForCustomizedRecognition', function (){
			var value = [];
			service.getCustomBadges().then(function(data){
				return value = data.value;
			});
			$httpBackend.flush();
			expect(value.length).toBe(3);
		});
		it('Test 3 getBadgesForValueBorder should call /svc/Badge/GetBadgesForValueBorder', function (){
			var value = [];
			service.getBadgesForValueBorder().then(function(data){
				return value = data.value;
			});
			$httpBackend.flush();
			expect(value.length).toBe(3);
		});
	});
});