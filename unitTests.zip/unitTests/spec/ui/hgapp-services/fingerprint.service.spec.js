define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){

    describe('Notification service spec', function() {
        var service,
            $httpBackend,
            http;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, FingerprintSrvc) {
            service = FingerprintSrvc;
            $httpBackend = $injector.get("$httpBackend");
        }));
        it('Test 1', function (){

           // expect(value).toBe('added');
        });
    });
});