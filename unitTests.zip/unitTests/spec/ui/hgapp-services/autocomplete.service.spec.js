define([
	'unitTests/ui-mocks/autocomplete.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'hgapp-app'
	], function(autocompleteJson) {
	describe('autocomplete service spec ->', function() {
		var service,
			$httpBackend;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-services"));
		beforeEach(inject(function ($injector, AutoCompleteSrvc) {
			service = AutoCompleteSrvc;
			$httpBackend = $injector.get("$httpBackend");
		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 AutoComplete service should be defined', function (){
			expect(service).toBeDefined();
		});
		it('Test 2 autoComplete service should call /svc/AutoComplete/AutoComplete', function (){
			$httpBackend.whenPOST("/svc/AutoComplete/AutoComplete")
                .respond(200, autocompleteJson.getAutoCompleteData());
            var test,
                error;
            service.autoComplete({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
		});
		it('Test 3 autoComplete service should call /svc/AutoComplete/GetPreSelectedItems', function (){
			$httpBackend.whenPOST("/svc/AutoComplete/GetPreSelectedItems")
                .respond(200, autocompleteJson.getPreSelectedData());
            var test,
                error;

            service.getPreSelectItems({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
		});
	});
});
