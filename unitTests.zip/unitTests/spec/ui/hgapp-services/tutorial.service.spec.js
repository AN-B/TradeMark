define([
	'unitTests/ui-mocks/modal',
	'unitTests/ui-mocks/tutorial.json',  
	'static/source/core/collectionCache',
	'static/source/core/prototypes', 
	'angular', 
	'angular-mocks', 
	'angular-resource', 
	'hgapp-app'], 
	function (modalMock, tutorialJson, cache) {

    describe('Tutorial service spec ->', function() {
        var tutorialService,
            httpBackend,
            location,
            modal,
            modalStack,
            rootScope,
            user,
            filteredTutorials;

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, TutorialSrvc, $rootScope, $modal, $modalStack, $location) {
        	modal = $modal;
            modalStack = $modalStack;
            user = {
                CompletedTutorials : []
            };
            filteredTutorials = [];
        	rootScope = $rootScope;
            httpBackend = $injector.get("$httpBackend");
            location = $location;
			tutorialService =  TutorialSrvc;
            httpBackend.whenGET('template.html')
                .respond(200, 'template retrieved');
            httpBackend.whenGET('intro.html')
                .respond(200, 'template retrieved');
            httpBackend.whenPOST('/svc/Tutorial/CompleteMemberTutorials')
                .respond(200, {
                	tutorialNumberCompleted: 1,
                	exitURL: '/Recognize/Company/GiveEveryday'
                });
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });

        it('Tutorial service should be defined', function(){
            expect(tutorialService).toBeDefined();
        });

//        it('bootstrapTutorial() should return a filtered array with 5 elements for the given path', function(){
//            location.path('/Recognize/Company/GiveEveryday');
//            filteredTutorials = tutorialService.bootstrapTutorial(tutorialJson.getTutorials().RequiredTutorials, user.CompletedTutorials);
//            expect(filteredTutorials.length).toEqual(5);
//        });
//
//        it('bootstrapTutorial() should return a filtered array with 0 elements for the given path', function(){
//            location.path('/Nonsense/Path');
//            filteredTutorials = tutorialService.bootstrapTutorial(tutorialJson.getTutorials().RequiredTutorials, user.CompletedTutorials);
//            expect(filteredTutorials.length).toEqual(0);
//        });
//
//        it('bootstrapTutorial() should return a filtered array with 0 elements for the given path and completed tutorial number', function(){
//            location.path('/Recognize/Company/GiveEveryday');
//            user.CompletedTutorials.push(1);
//            filteredTutorials = tutorialService.bootstrapTutorial(tutorialJson.getTutorials().RequiredTutorials, user.CompletedTutorials);
//            expect(filteredTutorials.length).toEqual(0);
//        });
//
//        it('bootstrapTutorial() should return a filtered array with 5 elements for the given path and completed tutorial number', function(){
//            location.path('/Recognize/Company/GiveEveryday');
//        	user.CompletedTutorials.push(2);
//            filteredTutorials = tutorialService.bootstrapTutorial(tutorialJson.getTutorials().RequiredTutorials, user.CompletedTutorials);
//            expect(filteredTutorials.length).toEqual(5);
//        });

//        it('openTutorialStepModal() should open a modal for a given tutorial step with the template given', function(){
//            spyOn(modal, 'open').andCallThrough();
//            httpBackend.whenGET('templates/Tutorial/enintro.html')
//                .respond(200);
//        	tutorialService.openTutorialStepModal({
//                currentTutorialStep: tutorialJson.getTutorialModel(),
//                totalSteps: tutorialJson.getTutorialModel().totalSteps,
//                tutorialGroupName: 'Mercury Industries'
//            }, 1, function () {});
//            httpBackend.flush();
//        	expect(modal.open).toHaveBeenCalled();
//        });

        it('completeTutorial() should return expected response data via promise when http complete tutorial request returned successfully', function(){
        	tutorialService.completeTutorialRemote(tutorialJson.getTutorialModel())
        	.then(function (response) {
        		expect(response.tutorialNumberCompleted).toEqual(1);
        		expect(response.exitURL).toEqual('/Recognize/Company/GiveEveryday');
        	});
        	httpBackend.flush();
        });

        it('completeTutorial() should reject response data via promise when http complete tutorial request returned with error', function(){
        	httpBackend.whenPOST('/svc/Tutorial/CompleteMemberTutorials')
	            .respond(500);
        	tutorialService.completeTutorialRemote(tutorialJson.getTutorialModel())
        	.then(null, function (err) {
        		expect(err).toBeTruthy;
        	});
        	httpBackend.flush();
        });
    });
});