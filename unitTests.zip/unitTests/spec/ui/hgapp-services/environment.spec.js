define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
    describe('Environment service spec ->', function() {
        var service,
            location;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, EnvironmentSrvc) {
            service = EnvironmentSrvc;
            location = $injector.get("$location");
            spyOn(location, 'path').andCallFake(function(){});
        }));
        it('Test 1 addHistory should not add url on exclusion list', function (){
            service.addHistory('/Profile/Feedback/Tip/871287218h');
            service.navigateBack();
            expect(location.path).toHaveBeenCalledWith('/');
        });
        it('Test 2 addHistory should add url not in exclusion list', function (){
            service.addHistory('/Profile/Feedback/Answer/871287218h');
            service.navigateBack();
            expect(location.path).toHaveBeenCalledWith('/Profile/Feedback/Answer/871287218h');
        });
        it('Test 3 addHistory should not add url on exclusion list', function (){
            service.addHistory('/Profile/Feedback/Start/871287218h');
            service.navigateBack();
            expect(location.path).toHaveBeenCalledWith('/');
        });
    });
});