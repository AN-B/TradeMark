define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('Feed service spec ->', function() {
		var service,$httpBackend;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, FeedSrvc) {
            service = FeedSrvc;
            $httpBackend = $injector.get("$httpBackend");
        }));

		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});

        it('Test 1 Feed service should be defined', function (){
            expect(service).toBeDefined();
        });

        it('Test 2: GetCompanyFeed should call /svc/Feed/GetCompanyFeed', function (){
            var value = '';
            $httpBackend.whenGET("/svc/Feed/GetCompanyFeed")
                .respond(200,{value: 'done'});
            service.getCompanyFeed({}).then(function(data){
                value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 3: GetCompanyFeed should fail', function (){
            var value = '';
            $httpBackend.whenGET("/svc/Feed/GetCompanyFeed")
                .respond(500, 'error');
            service.getCompanyFeed({}).then(function () {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 4: GetFeedByMemberId should call /svc/Feed/GetFeedByMemberId', function (){
            var value = '';
            $httpBackend.whenPOST("/svc/Feed/GetFeedByMemberId")
                .respond(200,{value: 'done'});
            service.getFeedByMemberId({memberId: 'blah'}).then(function(data){
                value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 5: GetFeedByMemberId should fail', function (){
            var value = '';
            $httpBackend.whenPOST("/svc/Feed/GetFeedByMemberId")
                .respond(500, 'error');
            service.getFeedByMemberId({memberId: 'blah'}).then(function() {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 6: getDefaultFeedSearch should call /svc/Feed/GetMemberDefaultFeedSearch', function (){
            var value = '';
            $httpBackend.whenGET("/svc/Feed/GetMemberDefaultFeedSearch")
                .respond(200,{value: 'done'});
            service.getDefaultFeedSearch({}).then(function(data){
                value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 7: getDefaultFeedSearch should fail', function (){
            var value = '';
            $httpBackend.whenGET("/svc/Feed/GetMemberDefaultFeedSearch")
                .respond(500, 'error');
            service.getDefaultFeedSearch({}).then(function() {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });

        it('Test 8: saveFeedSearch should call /svc/Feed/SaveMemberFeedSearch', function (){
            var value = '';
            $httpBackend.whenPOST("/svc/Feed/SaveMemberFeedSearch")
                .respond(200,{value: 'done'});
            service.saveFeedSearch({}).then(function(data){
                value = data.value;
            });
            $httpBackend.flush();
            expect(value).toBe('done');
        });

        it('Test 9: saveFeedSearch should fail', function (){
            var value = '';
            $httpBackend.whenPOST("/svc/Feed/SaveMemberFeedSearch")
                .respond(500, 'error');
            service.saveFeedSearch({}).then(function() {}, function(err){
                value = err.data;
            });
            $httpBackend.flush();
            expect(value).toBe('error');
        });
	});
});