define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('Team service spec ->', function() {
		var service,
			$httpBackend;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-services"));
		beforeEach(inject(function ($injector, TeamSrvc) {
			service = TeamSrvc;
			$httpBackend = $injector.get("$httpBackend");
		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1: team service should be defined', function (){

			expect(service).toBeDefined();
		});
		it('Test 2: getDepartments should call svc/Team/GetDepartments', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetDepartments")
				.respond(200, {value: [1, 2, 3]});
			service.getDepartments().then(function(res){
				value = res.value;
			});
			$httpBackend.flush();
			expect(value.length).toBe(3);
		});

		it('Test 3: getDepartments should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetDepartments")
				.respond(500, 'error');
			service.getDepartments().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 4: getMemberDepartment should call /svc/Team/GetMemberDepartment?MemberId=test', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetMemberDepartment?MemberId=test")
				.respond(200, {value: 'done'});
			service.getMemberDepartment('test').then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 5: getMemberDepartment should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetMemberDepartment?MemberId=test")
				.respond(500, 'error');
			service.getMemberDepartment('test').then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 6: getPublicTeamsDTO should call /svc/Team/GetPublicTeamsDTO', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetPublicTeamsDTO")
				.respond(200, {value: 'done'});
			service.getPublicTeamsDTO().then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 7: getPublicTeamsDTO should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetPublicTeamsDTO")
				.respond(500, 'error');
			service.getPublicTeamsDTO().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 8: getMyTeams should call /svc/Team/GetMyTeams', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetMyTeams")
				.respond(200, {value: 'done'});
			service.getMyTeams().then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 9: getMyTeams should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetMyTeams")
				.respond(500, 'error');
			service.getMyTeams().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 10: getTeamsIOwn should call /svc/Team/GetTeamsIOwn', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetTeamsIOwn")
				.respond(200, {value: 'done'});
			service.getTeamsIOwn().then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 11: getTeamsIOwn should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetTeamsIOwn")
				.respond(500, 'error');
			service.getTeamsIOwn().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 12: getTeamsIOwnOrBelong should call /svc/Team/GetTeamsOwnOrBelong', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetTeamsOwnOrBelong")
				.respond(200, {value: 'done'});
			service.getTeamsIOwnOrBelong().then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 13: getTeamsIOwnOrBelong should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetTeamsOwnOrBelong")
				.respond(500, 'error');
			service.getTeamsIOwnOrBelong().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 14: getTeamsIBelong should call /svc/Team/GetTeamsIBelong', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetTeamsIBelong")
				.respond(200, {value: 'done'});
			service.getTeamsIBelong().then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 15: getTeamsIBelong should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetTeamsIBelong")
				.respond(500, 'error');
			service.getTeamsIBelong().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 16: getPublicTeams should call /svc/Team/GetPublicTeams', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetPublicTeams")
				.respond(200, {value: 'done'});
			service.getPublicTeams().then(function(data){
				value = data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 17: getPublicTeams should fail', function (){
			var value = '';
			$httpBackend.whenGET("/svc/Team/GetPublicTeams")
				.respond(500, 'error');
			service.getPublicTeams().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});

		it('Test 18: saveTeam should call /svc/Team/SaveTeam', function (){
			var value = '';
			$httpBackend.whenPOST("/svc/Team/SaveTeam")
				.respond(200, {value: 'done'});
			service.saveTeam().then(function(res){
				value = res.data.value;
			});
			$httpBackend.flush();
			expect(value).toBe('done');
		});

		it('Test 19: saveTeam should fail', function (){
			var value = '';
			$httpBackend.whenPOST("/svc/Team/SaveTeam")
				.respond(500, 'error');
			service.saveTeam().then(function() {}, function(err){
				value = err.data;
			});
			$httpBackend.flush();
			expect(value).toBe('error');
		});
	});
});