define(['unitTests/ui-mocks/user.json',
    'static/source/core/collectionCache',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(userJson, cache){
    describe('pusher service spec ->', function() {
        var pusherSrvc,
            httpBackend,
            user;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, PusherSrvc) {
            pusherSrvc = PusherSrvc;
            httpBackend = $injector.get("$httpBackend");
            httpBackend.whenGET('/svc/User/Login')
                .respond(200, userJson.getCu());
            user = userJson.getCu();
            cache.clear('user');
        }));
        afterEach(function () {
            httpBackend.verifyNoOutstandingExpectation();
            httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 pusher service should be defined', function (){
            expect(pusherSrvc).toBeDefined();
        });
        it('Test 2 pusher instances should be defined', function (){
            pusherSrvc.subscribe();
            httpBackend.flush();
            var stub = window.Pusher.instances[0];
            expect(stub).toBeDefined();
        });
        it('Test 3 pusher should fire bunch of events', function (){
            var stub = window.Pusher.instances[0];
            expect(stub).toBeDefined();

        });

    });
});
