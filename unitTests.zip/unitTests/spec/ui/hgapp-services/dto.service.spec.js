define(['angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(){
	describe('Dto service spec ->', function() {
		var service,
			$httpBackend;
		beforeEach(module("hgapp-app"));
		beforeEach(module("hgapp-services"));
		beforeEach(inject(function ($injector, DtoSrvc) {
			service = DtoSrvc;
			$httpBackend = $injector.get("$httpBackend");
			$httpBackend.whenGET("/svc/UI/GetRecipientCandidates")
				.respond(200, {value: [1, 2, 3]});
		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 badge admin service should be defined', function (){

			expect(service).toBeDefined();
		});
		it('Test 2 getCustomBadges should call svc/Badge/GetBadgesForCustomizedRecognition', function (){
			var value = [];
			service.getRecipients().then(function(data){
				return value = data.value;
			});
			$httpBackend.flush();
			expect(value.length).toBe(3);
		});
	});
});