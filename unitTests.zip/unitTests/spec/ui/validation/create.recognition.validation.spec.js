define(['static/source/hgapp/validation/create-recognition-validation',
	'unitTests/ui-mocks/recognition.templates.json'], function(validation, recJson){
	var request;
	describe("Create recognition request validation spec -> ", function(){
		it("Test 1 should return valid achievement request", function(){
			request = recJson.getAchievement();
			request = validation.validateAchievement(request[0]);
			expect(request.notValid).toBeFalsy();
		});
		it("Test 2 should return invalid achievement request title is missing", function(){
			request = recJson.getAchievement()[0];
			request.Title = '';
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeTruthy();
			expect(request.notValidTitle).toBeTruthy();
		});
		it("Test 3 should return valid achievement request if levels are empty array", function(){
			request = recJson.getAchievement()[0];
			request.Levels = [];
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeFalsy();
		});
		it("Test 4 should return invalid achievement request level name is missing", function(){
			request = recJson.getAchievement()[0];
			request.Levels[0].Name = '';
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeTruthy();
			expect(request.Levels[0].notValidName).toBeTruthy();
		});
		it("Test 5 should return invalid achievement request level Credit Value is missing", function(){
			request = recJson.getAchievement()[0];
			request.Levels[0].CreditValue = 'hg';
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeTruthy();
			expect(request.Levels[0].notValidCreditValue).toBeTruthy();
		});
		it("Test 6 should return invalid achievement request level Credit Value is negative", function(){
			request = recJson.getAchievement()[0];
			request.Levels[0].CreditValue = -1;
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeTruthy();
			expect(request.Levels[0].notValidCreditValue).toBeTruthy();
		});
		it("Test 7 should return valid achievement request level Point Value is missing", function(){
			request = recJson.getAchievement()[0];
			request.Levels[0].PointValue = '';
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeFalsy();
			expect(request.Levels[0].notValidPointValue).toBeFalsy();
		});
		it("Test 8 should return valid achievement request level Point Value is negative", function(){
			request = recJson.getAchievement()[0];
			request.Levels[0].PointValue = -1;
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeFalsy();
			expect(request.Levels[0].notValidPointValue).toBeFalsy();
		});
		it("Test 9 should return valid achievement request level Point Value has decimal", function(){
			request = recJson.getAchievement()[0];
			request.Levels[0].PointValue = 1.234;
			request = validation.validateAchievement(request);
			expect(request.notValid).toBeFalsy();
			expect(request.Levels[0].notValidPointValue).toBeFalsy();
		});
		it("Test 10 should return valid value request", function(){
			request = recJson.getValue().Templates[0];
			request = validation.validateValue(request);
			expect(request.notValid).toBeFalsy();
		});
		it("Test 11 should return valid value request if no hgId and badge id", function(){
			request = recJson.getValue().Templates[0];
			request.hgId = '';
			request.BadgeId = 'something';
			request = validation.validateValue(request);
			expect(request.notValid).toBeFalsy();
		});
		it("Test 12 should return valid value request if hgId and badge id", function(){
			request = recJson.getValue().Templates[0];
			request.BadgeId = 'something';
			request = validation.validateValue(request);
			expect(request.notValid).toBeFalsy();
		});
		it("Test 13 should return valid value request if sub values empty", function(){
			request = recJson.getValue().Templates[0];
			request.SubValues = [];
			request = validation.validateValue(request);
			expect(request.notValid).toBeFalsy();
		});
		it("Test 14 should return invalid value request if sub values[0] no ImageId and no Badge Id", function(){
			request = recJson.getValue().Templates[0];
			request.SubValues[0].ImageId = '';
			request = validation.validateValue(request);
			expect(request.notValid).toBeTruthy();
			expect(request.SubValues[0].notValidImageId).toBeTruthy();
		});
		it("Test 15 should return valid value request if sub values[0] no ImageId and Badge Id", function(){
			request = recJson.getValue().Templates[0];
			request.SubValues[0].ImageId = '';
			request.SubValues[0].BadgeId = 'jsdhjsdh';
			request = validation.validateValue(request);
			expect(request.notValid).toBeFalsy();
			expect(request.SubValues[0].notValidImageId).toBeFalsy();
		});
		it("Test 16 should return invalid value request if sub values[0] no Name", function(){
			request = recJson.getValue().Templates[0];
			request.SubValues[0].Name = '';
			request = validation.validateValue(request);
			expect(request.notValid).toBeTruthy();
			expect(request.SubValues[0].notValidName).toBeTruthy();
		});
	});
});
