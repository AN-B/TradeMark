define(['static/source/hgapp/validation/points-create-product-validation',
        'unitTests/ui-mocks/productItem.templates.json'], function(validation, productItems) {
    var request;
    describe("Create product item validation spec", function() {
        beforeEach(function() {
            request = productItems.getAll()[0];
        });

        it("should return valid", function () {
            request = validation.validate(request);
            expect(request.notValid).toBeFalsy();
        });

        it("should return invalid if no name", function () {
            request.Name = '';
            request = validation.validate(request);
            expect(request.notValid).toBeTruthy();
            expect(request.notValidName).toBeTruthy();
        });

        it("should return invalid if name > 65 char", function () {
            request.Name = new Array(70).join('a');
            request = validation.validate(request);
            expect(request.notValid).toBeTruthy();
            expect(request.notValidName).toBeTruthy();
        });

        it("should return invalid if point cost < 0", function () {
            request.PointCost = -5;
            request = validation.validate(request);
            expect(request.notValid).toBeTruthy();
            expect(request.notValidPointCost).toBeTruthy();
        });

        it("should return invalid if available num < 0", function () {
            request.AvailableNumber = -5;
            request = validation.validate(request);
            expect(request.notValid).toBeTruthy();
            expect(request.notValidAvailableNumber).toBeTruthy();
        });

        it("should return invalid if status is unset", function () {
            request.Status = '';
            request = validation.validate(request);
            expect(request.notValid).toBeTruthy();
            expect(request.notValidStatus).toBeTruthy();
        });

        it("should return invalid if productImageFile is unset", function () {
            request.ProductImageFile = '';
            request = validation.validate(request);
            expect(request.notValid).toBeTruthy();
            expect(request.notValidProductImage).toBeTruthy();
        });
    });
});