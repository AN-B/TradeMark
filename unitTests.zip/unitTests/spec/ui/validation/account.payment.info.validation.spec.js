define(['static/source/hgapp/validation/account.payment.info.validation'],
    function(validation) {
        describe("Account payment info validation spec ->", function () {
            var request;
            beforeEach(function () {

            });
            it("Test 1 zip should be invalid", function () {
                var paymentInfo = validation.validateZip({Zip: ''});
                expect(paymentInfo.errorZip).toBe('users.ac.pi.te.zp');
            });
            it("Test 2 zip should be invalid", function () {
                var paymentInfo = validation.validateZip({Zip: 'bdcjhdfhgdfghdf'});
                expect(paymentInfo.errorZip).toBe('users.ac.pi.te.zf');
            });
            it("Test 3 zip should be valid", function () {
                var paymentInfo = validation.validateZip({Zip: '67788'});
                expect(paymentInfo.errorZip).toBeFalsy();
            });
            it("Test 4 first name should be invalid", function () {
                var paymentInfo = validation.validateZip({Zip: 'j23323'});
                expect(paymentInfo.errorZip).toBe('users.ac.pi.te.zf');
            });
            it("Test 5 zip should be invalid", function () {
                var paymentInfo = validation.validateZip({Zip: 'bdcjhdfhgdfghdf'});
                expect(paymentInfo.errorZip).toBe('users.ac.pi.te.zf');
            });
            it("Test 6 FirstName should be invalid", function () {
                var paymentInfo = validation.validate({FirstName: ''}, 'FirstName');
                expect(paymentInfo.errorFirstName).toBe('common.fn');
            });
            it("Test 7 FirstName should be valid", function () {
                var paymentInfo = validation.validate({FirstName: 'test'}, 'FirstName');
                expect(paymentInfo.errorFirstName).toBeFalsy();
            });
            it("Test 8 LastName should be valid", function () {
                var paymentInfo = validation.validate({LastName: 'test'}, 'LastName');
                expect(paymentInfo.errorLastName).toBeFalsy();
            });
            it("Test 9 LastName should be invalid", function () {
                var paymentInfo = validation.validate({LastName: ''}, 'LastName');
                expect(paymentInfo.errorLastName).toBe('common.ln');
            });
            it("Test 10 Address should be invalid", function () {
                var paymentInfo = validation.validate({Address: ''}, 'Address');
                expect(paymentInfo.errorAddress).toBe('users.ac.pi.te.ad');
            });
            it("Test 11 Address should be valid", function () {
                var paymentInfo = validation.validate({Address: 'test 123'}, 'Address');
                expect(paymentInfo.errorAddress).toBeFalsy();
            });
            it("Test 12 City should be valid", function () {
                var paymentInfo = validation.validate({City: 'test 123'}, 'City');
                expect(paymentInfo.errorCity).toBeFalsy();
            });
            it("Test 13 City should be invalid", function () {
                var paymentInfo = validation.validate({City: ''}, 'City');
                expect(paymentInfo.errorCity).toBe('users.ac.pi.te.ct');
            });
            it("Test 14 State should be valid", function () {
                var paymentInfo = validation.validate({State: 'IL'}, 'State');
                expect(paymentInfo.errorCity).toBeFalsy();
            });
            it("Test 15 State should be invalid", function () {
                var paymentInfo = validation.validate({State: ''}, 'State');
                expect(paymentInfo.errorState).toBe('users.ac.pi.te.st');
            });
            it("Test 16 FriendlyName should be valid", function () {
                var paymentInfo = validation.validate({FriendlyName: 'amex'}, 'FriendlyName');
                expect(paymentInfo.errorFriendlyName).toBeFalsy();
            });
            it("Test 17 FriendlyName should be invalid", function () {
                var paymentInfo = validation.validate({FriendlyName: ''}, 'FriendlyName');
                expect(paymentInfo.errorFriendlyName).toBe('users.ac.pi.te.na');
            });

            it("Test 18 CardNumber should be invalid", function () {
                var paymentInfo = validation.validateCreditcard({CardNumber: ''});
                expect(paymentInfo.errorCardNumber).toBe('users.ac.pi.pg');
            });
            it("Test 19 CardNumber should be valid", function () {
                var paymentInfo = validation.validateCreditcard({CardNumber: '378282246310005'});
                expect(paymentInfo.errorCardNumber).toBeFalsy('');
            });
            it("Test 20 CardNumber should be valid", function () {
                var paymentInfo = validation.validateCreditcard({CardNumber: '4111111111111111'});
                expect(paymentInfo.errorCardNumber).toBeFalsy('');
            });
            it("Test 21 SecurityCode should be invalid", function () {
                var paymentInfo = validation.validateCvv({CardNumber: '378282246310005', SecurityCode: ''});
                expect(paymentInfo.errorSecurityCode).toBe('users.ac.pi.pg');
            });
            it("Test 22 SecurityCode should be invalid", function () {
                var paymentInfo = validation.validateCvv({CardNumber: '4111111111111111', SecurityCode: ''});
                expect(paymentInfo.errorSecurityCode).toBe('users.ac.pi.pg');
            });
            it("Test 23 SecurityCode should be invalid", function () {
                var paymentInfo = validation.validateCvv({CardNumber: '378282246310005', SecurityCode: '22'});
                expect(paymentInfo.errorSecurityCode).toBe('users.ac.pi.pg');
            });
            it("Test 24 SecurityCode should be invalid", function () {
                var paymentInfo = validation.validateCvv({CardNumber: '4111111111111111', SecurityCode: '21'});
                expect(paymentInfo.errorSecurityCode).toBe('users.ac.pi.pg');
            });
            it("Test 25 SecurityCode should be valid", function () {
                var paymentInfo = validation.validateCvv({CardNumber: '378282246310005', SecurityCode: '2243'});
                expect(paymentInfo.errorSecurityCode).toBeFalsy();
            });
            it("Test 26 SecurityCode should be valid", function () {
                var paymentInfo = validation.validateCvv({CardNumber: '4111111111111111', SecurityCode: '214'});
                expect(paymentInfo.errorSecurityCode).toBeFalsy();
            });
            it("Test 27 month should be valid", function () {
                var paymentInfo = validation.validate({month: '01'}, 'month');
                expect(paymentInfo.errormonth).toBeFalsy();
            });
            it("Test 28 month should be invalid", function () {
                var paymentInfo = validation.validate({month: ''}, 'month');
                expect(paymentInfo.errormonth).toBe('users.ac.pi.te.em');
            });
            it("Test 29 month should be valid", function () {
                var paymentInfo = validation.validate({year: '01'}, 'year');
                expect(paymentInfo.erroryear).toBeFalsy();
            });
            it("Test 30 month should be invalid", function () {
                var paymentInfo = validation.validate({year: ''}, 'year');
                expect(paymentInfo.erroryear).toBe('users.ac.pi.te.ey');
            });

            it("Test 31 ", function () {
                var paymentInfo = validation.getCardTypeName({CardNumber: '378282246310005'});
                expect(paymentInfo.CardType).toBe('American Express');
            });
            it("Test 32 ", function () {
                var paymentInfo = validation.getCardTypeName({CardNumber: '4111111111111111'});
                expect(paymentInfo.CardType).toBe('Visa');
            });
        });
    });