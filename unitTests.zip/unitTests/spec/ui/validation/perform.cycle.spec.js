define(['unitTests/ui-mocks/cycle.post.json',
    'angular', 'angular-mocks', 'angular-resource', 'hgapp-app'], function(json){
	var Cycle;
	describe("Perform cycle validation spec ->", function(){
        var service;
        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-services"));
        beforeEach(inject(function ($injector, PerformAssignCycleValidation) {
            service =  PerformAssignCycleValidation;
            Cycle = json.get().Cycle;
        }));
		it("Test 1 should return cycle", function(){
            service.validate(Cycle, function(val){
				expect(val.hgId).toBe('test 123');
			});
		});
		it("Test 2 should return title valid false and title error message should be 'Cycle Title required'", function(){
			Cycle.Title = '';
            service.validate(Cycle, function(val){
				expect(val.valid).toBeFalsy();
				expect(val.titleValid).toBeFalsy();
			});
		});
		it("Test 3 should return title valid true and title error message should be blank", function(){
            service.validate(Cycle, function(val){
				expect(val.invalidTitle).toBeFalsy();
				expect(val.titleError).toBeFalsy();
			});
		});
		it("Test 4 should fail if start date is empty", function(){
			Cycle.ReviewPeriodStart = '';
            service.validate(Cycle, function(val){
				expect(val.valid).toBeFalsy();
				expect(val.startDateValid).toBeFalsy();
			});
		});
		it("Test 4 should fail if end date is empty", function(){
			Cycle.ReviewPeriodEnd = '';
            service.validate(Cycle, function(val){
				expect(val.valid).toBeFalsy();
				expect(val.endDateValid).toBeFalsy();

			});
		});
		it("Test 6 should pass if due date is greater than end date", function(){
			var date = new Date(Cycle.ReviewPeriodStart),
				date = date.setDate(date.getDate() + 1);
			Cycle.PeopleDates[0].DlvTrgPplType = 'Date';
			Cycle.PeopleDates[0].DueDate = date;
            service.validate(Cycle, function(val){
				expect(val.PeopleDates[0].dueDateValid).toBeTruthy();
			});
		});
		it("Test 7 should pass if due date is greater than end date", function(){
			var date = new Date(Cycle.PeopleDates[0].DeliveryDate),
				date = date.setDate(date.getDate() - 1);
			Cycle.PeopleDates[0].DlvTrgPplType = 'Date';
			Cycle.PeopleDates[0].DeliveryDate = date;
            service.validate(Cycle, function(val){
				expect(val.PeopleDates[0].dueDateValid).toBeTruthy();
			});
		});
	});
});
