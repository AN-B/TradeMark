define(['static/source/hgapp/validation/recognition-request-validation',
	'unitTests/ui-mocks/recognition.request.object.json',
	'unitTests/ui-mocks/recognition.templates.json',
    'unitTests/ui-mocks/productItem.templates.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'hgapp-app'], function(validation, recJson, recTemplates, prodTemplates){
	var request,
        httpBackend,
        prodSrvc;
	describe("Recognition request validation spec", function(){

        beforeEach(module("hgapp-app"));
        beforeEach(module("hgapp-controllers"));
        beforeEach(inject(function ($injector, $controller, $rootScope, ProductItemSrvc, RecognitionSrvc, UserSrvc, $routeParams) {
            prodSrvc = ProductItemSrvc;
            httpBackend = $injector.get("$httpBackend");

            httpBackend.whenGET('/svc/ProductItem/GetProductById?Id=5f4dd850-c403-11e3-a9c0-71c4281b4207')
                .respond(200, prodTemplates.getNew());

        }));

		it("Test 1 should return valid everyday request", function(){
			request = recJson.getEveryday();
			request = validation.validate(request);
			expect(request.invalid).toBeFalsy();
		});
		it("Test 2 should return invalid everyday request", function(){
			request = recJson.getEveryday();
			request.Template.hgId = '';
			request.Message = '';
			request.Recipients = [];
			request = validation.validate(request);
			expect(request.invalid).toBeTruthy();
			expect(request.Template.invalidHgId).toBeTruthy();
			expect(request.Template.invalidHgId).toBeTruthy();
			expect(request.Template.invalidImageId).toBeFalsy();
			expect(request.invalidMsg).toBeTruthy();
			expect(request.invalidRecipients).toBeTruthy();
		});
		it("Test 3 should return valid achievement request", function(){
			request = recJson.getAchievement();
			request = validation.validateAchievement(request, 1);
			expect(request.invalid).toBeFalsy();
		});
		it("Test 4 should return invalid  achievement request", function(){
			request = recJson.getAchievement();
			request.Template.hgId = '';
			request.Message = '';
			request.Recipients = [];
			request = validation.validateAchievement(request, 1);
			expect(request.invalid).toBeTruthy();
			expect(request.Template.invalidHgId).toBeTruthy();
			expect(request.Template.invalidHgId).toBeTruthy();
			expect(request.Template.invalidImageId).toBeFalsy();
			expect(request.invalidMsg).toBeTruthy();
			expect(request.invalidRecipients).toBeTruthy();
		});
		it("Test 5 should return valid value request", function(){
			request = recJson.getValue();
			request = validation.validateValue(request, recTemplates.getLevels(), true);
			expect(request.invalid).toBeFalsy();
		});
		it("Test 6 should return invalid  value request", function(){
			request = recJson.getValue();
			request.Template.hgId = '';
			request.Message = '';
			request.Recipients = [];
			request = validation.validate(request);
			expect(request.invalid).toBeTruthy();
			expect(request.Template.invalidHgId).toBeTruthy();
			expect(request.Template.invalidImageId).toBeFalsy();
			expect(request.invalidMsg).toBeTruthy();
			expect(request.invalidRecipients).toBeTruthy();
		});
		it("Test 7 should return valid custom request", function(){
			request = recJson.getCustom();
			request = validation.validate(request);
			expect(request.invalid).toBeFalsy();
		});
		it("Test 8 should return invalid custom request", function(){
			request = recJson.getCustom();
			request.Template.hgId = '';
			request.Message = '';
			request.Recipients = [];
			request.Template.ImageId = '';
			request = validation.validateCustom(request);
			expect(request.invalid).toBeTruthy();
			expect(request.Template.invalidHgId).toBeFalsy();
			expect(request.Template.invalidImageId).toBeTruthy();
			expect(request.invalidMsg).toBeTruthy();
			expect(request.invalidRecipients).toBeTruthy();
		});
		it("Test 9 should return invalid everyday request where points and credits NaN", function(){
			request = recJson.getEveryday();
			request.MoreOptions.pointValue = 'blah';
			request.MoreOptions.creditValue = 'blah';
			request = validation.validate(request);
			expect(request.MoreOptions.creditValueError).toBe('Credit value should be a number');
			expect(request.MoreOptions.pointValueError).toBe('Point value should be a number');
		});
		it("Test 10 should return invalid everyday request where points and credits less than 0", function(){
			request = recJson.getEveryday();
			request.MoreOptions.pointValue = -1;
			request.MoreOptions.creditValue = -1;
			request = validation.validate(request);
			expect(request.MoreOptions.creditValueError).toBe('Credit value should be greater than 0');
			expect(request.MoreOptions.pointValueError).toBe('Point value should be be greater than 0');
		});
		it("Test 11 should return invalid value request if level is not selected", function(){
			request = recJson.getValue();
			request.Level = '';
			request = validation.validateValue(request, [1, 2], true);
			expect(request.invalidLevel).toBeTruthy();
		});
		it("Test 12 should return invalid value request if template  is not selected", function(){
			request = recJson.getValue();
			request.Template.hgId = '';
			request = validation.validateValue(request, recTemplates.getLevels(), 0);
			expect(request.Template.invalidHgId).toBeTruthy();
		});
		it("Test 13 should return invalid custom request if badge id is not selected", function(){
			request = recJson.getCustom();
			request.Template.ImageId = '';
			request = validation.validateCustom(request);
			expect(request.Template.invalidImageId).toBeTruthy();
		});
		it("Test 14 should return valid custom request if template id is not selected", function(){
			request = recJson.getCustom();
			request.Template.hgId = '';
			request = validation.validate(request);
			expect(request.Template.invalidHgId).toBeFalsy();
		});
		it("Test 15 should return invalid value request if levels are greater than zero and level is not selected", function(){
			request = recJson.getValue();
			request.Level = '';
			request = validation.validateValue(request, recTemplates.getLevels(), 1, true);
			expect(request.invalidLevel).toBeTruthy();
		});
		it("Test 16 should return valid value request if levels equal zero and level is not selected", function(){
			request = recJson.getValue();
			request.Level = '';
			request = validation.validateValue(request, [], 0);
			expect(request.invalidLevel).toBeFalsy();
		});
		it("Test 17 should return invalid achievement request if level is not selected", function(){
			request = recJson.getAchievement();
			delete request.Level;
			request = validation.validateAchievement(request, 2);
			expect(request.invalid).toBeTruthy();
			expect(request.invalidLevel).toBeTruthy();
		});
		it("Test 18 should return valid achievement request if level is not selected and there are no levels", function(){
			request = recJson.getAchievement();
			delete request.Level;
			request = validation.validateAchievement(request, 0);
			expect(request.invalid).toBeFalsy();
			expect(request.invalidLevel).toBeFalsy();
		});
		it("Test 19 should return valid value request if level is not selected and there are no levels and no sub values", function(){
			request = recJson.getValue();
			delete request.Level;
			delete request.Template.SubValues;
			delete request.Template.SubValue;
			request = validation.validateValue(request, [], 0);
			expect(request.invalid).toBeFalsy();
			expect(request.invalidLevel).toBeFalsy();
			expect(request.Template.invalidImageId).toBeFalsy();
		});
		it("Test 20 should return invalid value request if level is not selected and there are levels and sub values", function(){
			request = recJson.getValue();
			request.Level = '';
			request.Template.SubValue = null;
			request = validation.validateValue(request, recTemplates.getLevels(), true);
			expect(request.invalid).toBeTruthy();
			expect(request.invalidLevel).toBeTruthy();
			expect(request.Template.invalidImageId).toBeTruthy();
		});
		it("Test 21 should return invalid request if point and credit values isNaN", function(){
			request = recJson.getEveryday();
			request.MoreOptions.creditValue = '12mjj';
			request.MoreOptions.pointValue = '12mjj';
			request = validation.validate(request);
			expect(request.invalid).toBeTruthy();
			expect(request.MoreOptions.creditValueError).toBe('Credit value should be a number');
			expect(request.MoreOptions.pointValueError).toBe('Point value should be a number');
		});
		it("Test 22 should return invalid request if point and credit values less than 0", function(){
			request = recJson.getEveryday();
			request.MoreOptions.creditValue = -1;
			request.MoreOptions.pointValue = -1;
			request = validation.validate(request);
			expect(request.invalid).toBeTruthy();
			expect(request.MoreOptions.creditValueError).toBe('Credit value should be greater than 0');
			expect(request.MoreOptions.pointValueError).toBe('Point value should be be greater than 0');
		});
		it("Test 23 should return invalid request levels RemainingToMe is 0", function(){
			request = recJson.getValue();
			request.Level = 'Silver';
			var levels = recTemplates.getLevels();
			levels[0].RemainingToMe = 0;
			request = validation.validateValue(request, levels, 2, true);
			expect(request.invalid).toBeTruthy();
			expect(request.invalidLevel).toBeTruthy();
		});
		it("Test 24 should return invalid request levels RemainingToMe is 2 and recipients is 3", function(){
			request = recJson.getValue();
			request.Level = 'Silver';
			request.Recipients.push(request.Recipients[0]);
			request.Recipients.push(request.Recipients[0]);
			var levels = recTemplates.getLevels();
			request = validation.validateValue(request, levels, 2, true);
			expect(request.Recipients.length).toBe(3);
			expect(request.invalid).toBeTruthy();
			expect(request.invalidLevel).toBeTruthy();
		});
		it("Test 25 should return invalid request if remainingToMe is 0", function(){
			request = recJson.getValue();
			request.Level = 'Silver';
			var levels = recTemplates.getLevels();
			levels[0].RemainingToMe = 0;
			request = validation.validateValue(request, levels, 2, true);
			expect(request.Recipients.length).toBe(1);
			expect(request.invalid).toBeTruthy();
			expect(request.invalidLevel).toBeTruthy();
		});
        if("Test 26 should return invalid request if product AvailableNumber is 1 and recipients is 2", function () {
            request = recJson.getValue();
            request.MoreOptions.gift = {
                AvailableNumber: 0
            };
            scope.request.MoreOptions.giftId = '5f4dd850-c403-11e3-a9c0-71c4281b4207';
            request.Recipients.push(request.Recipients[0]);
            request = validation.validate(request);
            expect(request.Recipients.length).toBe(2);
            expect(request.MoreOptions.invalidGift).toBeTruthy();
            expect(request.invalid).toBeTruthy();
        });
        if("Test 27 should return invalid request if product cost * recipients is greater than user points", function () {
            request = recJson.getValue();
            request.MoreOptions.gift = {
                AvailableNumber: 0,
                PointCost: 10
            };
            request.MoreOptions.pointsAvailable = 10;
            request.MoreOptions.giftId = '5f4dd850-c403-11e3-a9c0-71c4281b4207';
            request.Recipients.push(request.Recipients[0]);

            request = validation.validate(request);
            expect(request.Recipients.length).toBe(2);
            expect(request.MoreOptions.invalidGift).toBeTruthy();
            expect(request.invalid).toBeTruthy();
        });
        if("Test 28 should return invalid request if gift status is not active", function () {
            request = recJson.getValue();
            request.MoreOptions.gift = {
                Status: 'Draft'
            };
            request.MoreOptions.giftId = '5f4dd850-c403-11e3-a9c0-71c4281b4207';
            request.Recipients.push(request.Recipients[0]);

            request = validation.validate(request);
            expect(request.MoreOptions.invalidGift).toBeTruthy();
            expect(request.invalid).toBeTruthy();
        });

	});
});