define(['static/source/provision/validation/templates-survey-validation',
    'unitTests/ui-mocks/template.json'], function(validation, templateMock) {
    describe("Templates Survey validation spec ->", function () {
        var request;
        beforeEach(function () {
            request = templateMock.getBenchmarkSurveyTemplate();
        });
        xit("Test 1 Validation Success", function () {
            validation.validateTransfer(request);
            expect(request.notValid).toBeFalsy();
        });
        // it("Test 2 Validation Failure if no GroupId exists", function () {
        //     delete request.GroupId;
        //     validation.validateTransfer(request);
        //     expect(request.notValid).toBeTruthy();
        //     expect(request.notValidGroupId).toBeTruthy();
        // });
        // it("Test 3 Valiation Failure if no FromAccountMember exists", function () {
        //     delete request.FromAccountMember;
        //     validation.validateTransfer(request);
        //     expect(request.notValid).toBeTruthy();
        //     expect(request.notValidFromAccount).toBeTruthy();
        // });
        // it("Test 4 Valiation Failure if SameUser is set to False and no ToAccountMember exists", function () {
        //     delete request.ToAccountMember;
        //     validation.validateTransfer(request);
        //     expect(request.notValid).toBeTruthy();
        //     expect(request.notValidToAccount).toBeTruthy();
        // });
        // it("Test 5 Valiation Success if SameUser is set to True and no ToAccountMember exists", function () {
        //     delete request.ToAccountMember;
        //     request.SameUser = true;
        //     validation.validateTransfer(request);
        //     expect(request.notValid).toBeFalsy();
        //     expect(request.notValidToAccount).toBeFalsy();
        // });
        // it("Test 6 Valiation Failure if no TransferAmount exists", function () {
        //     delete request.TransferAmount;
        //     validation.validateTransfer(request);
        //     expect(request.notValid).toBeTruthy();
        //     expect(request.notValidAmount).toBeTruthy();
        // });
        // it("Test 7 Valiation Failure if TransferAmount > FromAccountMember.SPND", function () {
        //     request.TransferAmount = request.FromAccountMember.SPND + 100;
        //     validation.validateTransfer(request);
        //     expect(request.notValid).toBeTruthy();
        //     expect(request.notValidAmount).toBeTruthy();
        // });
    });
});