define(['static/source/hgapp/validation/badge.defaults.validation'],
    function(validation) {
        describe("Badge defaults validation spec ->", function () {
            var request;
            beforeEach(function () {
                request = [
                    {
                        "Type":"Birthday",
                        "Id":"9f664420-d2b1-11e2-abde-65c08851db36",
                        "FriendlyGroupId":500,
                        "Title":"ererrere",
                        "Message":"",
                        "BadgeFileName":"packagebadge.svg",
                        "ForegroundBadgeId":"",
                        "ForegroundFilename":"packagebadge.svg",
                        "ForegroundUrl":"/img/badges/original/packagebadge.svg?1409238549577",
                        "BackgroundBadgeId":"",
                        "BackgroundFilename":"",
                        "titleRequired":true,
                        "messageRequired":false
                }];
            });
            it("Test 1 request should be valid", function () {
                var valid = validation.validate(request).valid;
                expect(valid).toBeTruthy();
            });
            it("Test 2 request should be invalid if title is required and empty", function () {
                delete request[0].Title;
                var valid = validation.validate(request).valid;
                expect(valid).toBeFalsy();
            });
            it("Test 3 request should be invalid if message is required and empty", function () {
                request[0].messageRequired = true;
                var valid = validation.validate(request).valid;
                expect(valid).toBeFalsy();
            });
            it("Test 4 request should be valid if message is required and length greater than zero", function () {
                request[0].messageRequired = true;
                request[0].Message = 'djfhjdfh';
                var valid = validation.validate(request).valid;
                expect(valid).toBeTruthy();
            });
        });
});