define([
    'unitTests/ui-mocks/provisioning.company.json',
    'angular',
    'angular-mocks',
    'angular-resource',
    'provision-app'
    ], function(companyJson) {
    describe('ProvisioningCompanySrvc service spec ->', function() {
        var service,
            $httpBackend;
        beforeEach(module("provision-app"));
        beforeEach(module("provision-services"));
        beforeEach(inject(function ($injector, ProvisioningCompanySrvc) {
            service = ProvisioningCompanySrvc;
            $httpBackend = $injector.get("$httpBackend");
        }));
        afterEach(function () {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });
        it('Test 1 ProvisioningCompanySrvc service should be defined', function (){
            expect(service).toBeDefined();
        });
        it('Test 2 ProvisioningCompanySrvc service should call /svc/Provision/GetFileConfirmationDetails', function (){
            $httpBackend.whenGET('/svc/Provision/GetFileConfirmationDetails?Id=1111')
                .respond(200, companyJson.getFileConfirmationDetails());
            var test,
                error;
            service.getFileConfirmationDetails('1111').then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
        });
        it('Test 3 ProvisioningCompanySrvc service should call /svc/Provision/CancelValidatedFile', function (){
            $httpBackend.whenPOST('/svc/Provision/CancelValidatedFile')
                .respond(200, {value: 'saved'});
            var test,
                error;
            service.cancelValidatedFile({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
        });
        it('Test 3 ProvisioningCompanySrvc service should call /svc/Provision/ProcessValidatedFile', function (){
            $httpBackend.whenPOST('/svc/Provision/ProcessValidatedFile')
                .respond(200, {value: 'saved'});
            var test,
                error;
            service.processValidatedFile({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
        });
    });
});
