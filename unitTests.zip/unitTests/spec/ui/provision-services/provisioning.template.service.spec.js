define([
	'unitTests/ui-mocks/template.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'provision-app'
	], function(surveyDriverJson) {
	describe('ProvisioningTemplate service spec ->', function() {
		var service,
			$httpBackend;
		beforeEach(module("provision-app"));
		beforeEach(module("provision-services"));
		beforeEach(inject(function ($injector, ProvisioningTemplateSrvc) {
			service = ProvisioningTemplateSrvc;
			$httpBackend = $injector.get("$httpBackend");
		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 ProvisioningTemplate service should be defined', function (){
			expect(service).toBeDefined();
		});
		it('Test 2 ProvisioningSurvey service should call /svc/Template/GetBenchmarkSurveyTemplate', function (){
			$httpBackend.whenGET("/svc/Template/GetBenchmarkSurveyTemplate")
                .respond(200, surveyDriverJson.getBenchmarkSurveyTemplate());
            var test,
                error;
            service.getBenchmarkSurveyTemplate({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
		});
		it('Test 3 ProvisioningSurvey service should call /svc/Template/SaveBenchmarkSurveyTemplate', function (){
			$httpBackend.whenPOST("/svc/Template/SaveBenchmarkSurveyTemplate")
                .respond(200, {value: 'saved'});
            var test,
                error;
            service.saveBenchmarkSurveyTemplate({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
		});
	});
});
