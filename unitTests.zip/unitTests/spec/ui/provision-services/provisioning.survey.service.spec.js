define([
	'unitTests/ui-mocks/survey.drivers.json',
	'angular',
	'angular-mocks',
	'angular-resource',
	'provision-app'
	], function(surveyDriverJson) {
	describe('ProvisioningSurvey service spec ->', function() {
		var service,
			$httpBackend;
		beforeEach(module("provision-app"));
		beforeEach(module("provision-services"));
		beforeEach(inject(function ($injector, ProvisioningSurveySrvc) {
			service = ProvisioningSurveySrvc;
			$httpBackend = $injector.get("$httpBackend");
		}));
		afterEach(function () {
			$httpBackend.verifyNoOutstandingExpectation();
			$httpBackend.verifyNoOutstandingRequest();
		});
		it('Test 1 ProvisioningSurvey service should be defined', function (){
			expect(service).toBeDefined();
		});
		it('Test 2 ProvisioningSurvey service should call /svc/Survey/GetGlobalSurveyDrivers', function (){
			$httpBackend.whenGET("/svc/Survey/GetGlobalSurveyDrivers")
                .respond(200, surveyDriverJson.getSurveyDrivers());
            var test,
                error;
            service.getSurveyDrivers({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
		});
		it('Test 3 ProvisioningSurvey service should call /svc/Survey/SaveSurveyDriver', function (){
			$httpBackend.whenPOST("/svc/Survey/SaveSurveyDriver")
                .respond(200, {value: 'saved'});
            var test,
                error;
            service.saveSurveyDriver({}).then(function (data) {
                test = data;
            }, function (err) {
                error = err;
            });
            $httpBackend.flush();
            expect(test).toBeDefined();
		});
	});
});
