define([
        'angular',
        'angular-mocks',
        'angular-resource',
        'display-app'],
    function () {
        describe('Display Recognition controller spec ->', function() {
            var displaySrvc,
                httpBackend,
                scope,
                rootScope,
                ctrl;

            beforeEach(module("display-app"));
            beforeEach(module("display-services"));
            beforeEach(inject(function ($controller, $rootScope, $location, $injector, DisplaySrvc) {
                httpBackend = $injector.get("$httpBackend");
                displaySrvc = DisplaySrvc;
                rootScope = $rootScope;
                scope = rootScope.$new();
                ctrl = $controller('RecognitionCtrl', {
                    $scope: scope
                });
            }));
            afterEach(function () {
                httpBackend.verifyNoOutstandingExpectation();
                httpBackend.verifyNoOutstandingRequest();
            });
            it('Test 1 Display Recognition controller should exist', function (){
                expect(ctrl).toBeDefined();
            });
            it('Test 2 should have called the services after init', function () {
                httpBackend.whenPOST('/svc/Display/GetDisplaySettings')
                    .respond(200, {Id : '111'});
                httpBackend.whenPOST('/svc/Display/GetRecognitions')
                    .respond(200, {Id : '111'});
                spyOn(displaySrvc, 'getDisplaySettings').andCallThrough();
                spyOn(displaySrvc, 'getRecognitions').andCallThrough();
                scope.init();
                // $httpBackend.flush();
                // expect(displaySrvc.getDisplaySettings).notoHaveBeenCalled();
                // expect(displaySrvc.getRecognitions).toHaveBeenCalled();
            });
        });
    });