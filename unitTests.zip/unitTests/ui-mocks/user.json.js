define(function(){
    function  getCu(){
        return {
            "__v": 0,
            "_id": "5238769534ce278a13000028",
            "ModifiedDate": 1365514305673,
            "ModifiedBy": "",
            "CreatedDate": 1365514305673,
            "CreatedBy": "",
            "hgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
            "AvatarVersion": 1373324183444,
            "Flags": {
            "CompanyNewsPending": false,
                "HGNewsPending": false,
                "TutorialPending": false,
                "WelcomeBadgePending": false
        },
            "LastLoginTime": 1379432085022,
            "UserFinance": {
            "PaymentProfiles": [
                {
                    "_id": "517052fdb982630000000014",
                    "OnlyForGroupId": "",
                    "AuthorizeNetPaymentProfileId": 16744952,
                    "FriendlyName": "Cu CC",
                    "Type": "CreditCard",
                    "HgId": "1ec8605b-44e9-4b1c-895b-e6c1daf03dfd"
                },
                {
                    "_id": "517052fdb9826300000000qw",
                    "OnlyForGroupId": "",
                    "AuthorizeNetPaymentProfileId": 16744952,
                    "FriendlyName": "My card",
                    "Type": "CreditCard",
                    "HgId": "1ec86023d-44e9-4b1c-895b-e6c1daf03dfd"
                }
            ],
                "DefaultPaymentProfileId": "1ec8605b-44e9-4b1c-895b-e6c1daf03dfd",
                "AuthorizeNetCustomerProfileId": 17750345,
                "TransferAccountBalanceInGroup": 66005,
                "SpendingAccountBalance": 5000,
                "PointSpendingBalance": 20
        },
            "MyMemberships": [
            {
                "_id": "5238769534ce278a13000026",
                "ExperiencePoint": 5280,
                "MyManagers": [],
                "MembershipStatus": "Active",
                "FriendlyId": "",
                "RolesInGroup": [
                    "HGAdmin"
                ],
                "MemberTitleInGroup": "Director Software Engineering",
                "MemberIdInGroup": "d2e0d320-a119-11e2-b177-7d64c8315189",
                "BannerUrl": "",
                "GroupTermStatus": "NoPermission",
                "GroupDepartmentName": "Development",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864"
            }
        ],
            "UserContext": {
            "AggregatedSecuredTabs": {
                "dashboardTabs": [
                    "home"
                ],
                "teamTabs": [
                    "recognize",
                    "coaching",
                    "perform"
                ],
                    "recognizeTabs": [
                    "giveRecognition",
					"recognition2",
                    "badges",
                    "skills",
                    "trophyRoom",
                    "deleteFeedEntry",
                    "sendCredits",
					"everydayRecognition",
					"customizedRecognition",
					"valuesRecognition",
					"achievementRecognition"
                ],
                    "trackTabs": [
                    "summary",
                    "goalTracks",
                    "manageTracks",
                    "moreOptions",
                    "deleteTracks"
                ],
                    "motivateTabs": [
                    "store",
                    "disabled",
                    "group",
                    "giftCards",
                    "pointStore",
                    "charitiesButton"
                ],
                    "profileTabs": [
                    "myCards",
                    "cardLibrary",
                    "cycleSubTab",
                    "perform",
                    "coaching"
                ],
                    "userTabs": [
                    "paymentInfo",
                    "account",
                    "notifications",
                    "credits",
                    "purchaseCredits",
                    "teams",
                    "preferences",
                    "disabled",
                    "userPulseSurvey"
                ],
                    "adminTabs": [
                    "disabled",
                    "settings",
                    "credits",
                    "members",
                    "editProfile",
                    "provisioning",
                    "teamTabManagement",
                    "metrics",
                    "reports",
                    "points",
                    "rules",
                    "recognitions",
                    "transferPoints"
                ],
                    "teamTabs": [
                        "recognize",
                        "coaching",
                        "perform"
                ]
            },
            "ExperiencePoint": 5280,
            "MyManagers": [],
            "MembershipStatus": "Active",
            "FriendlyId": "",
            "PermissionsInGroup": [
                "BasicPermission",
                "SelectRecapTime",
                "TeamTabManagement",
				"AchievementRecognition",
                "CreateTrackTemplate",
                "TransferCredit",
                "CompleteMileStone",
				"CustomizedRecognition",
                "CreateRecognitionTemplate",
                "ManageMember",
                "ManageAdmin",
                "ManageGroup",
                "PulseSurvey"
            ],
                "RolesInGroup": [
                "HGAdmin"
            ],
                "MemberTitleInGroup": "Director Software Engineering",
                "MemberIdInGroup": "d2e0d320-a119-11e2-b177-7d64c8315189",
                "CurrentGroupTermStatus": "Bypass",
                "CurrentGroupBannerUrl": "",
                "CurrentGroupName": "Mercury",
                "CurrentGroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864"
        },
            "UserToken": "d3e72345-b22a-4328-ace1-9cb12c73de49",
            "Preference": {
            "SuppressBirthday": false,
                "DefaultChannel": "",
                "WorkZip": "60654",
                "HomeZip": "60609",
                "DefaultChannelId": "",
                "Channels": "",
                "Photo": "",
                "NickName": "Tuan",
                "DefaultGroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864"
        },
            "UserPersonal": {
            "Startdate": 1379432085020,
                "Birthdate": 1214629200000,
                "PrimaryEmail": null,
                "Address": "",
                "FullName": "Cu Barnes",
                "LastName": "Pham-Barnes",
                "FirstName": "Tuan"
        },
            "LowercaseUserName": "cu@highground.com",
            "UserName": "cu@highground.com"
        }
    }
	function  getBasicPermission(){
		return {
			"__v": 0,
			"_id": "5238769534ce278a13000028",
			"ModifiedDate": 1365514305673,
			"ModifiedBy": "",
			"CreatedDate": 1365514305673,
			"CreatedBy": "",
			"hgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
			"AvatarVersion": 1373324183444,
			"Flags": {
				"CompanyNewsPending": false,
				"HGNewsPending": false,
				"TutorialPending": false,
				"WelcomeBadgePending": false
			},
			"LastLoginTime": 1379432085022,
			"UserFinance": {
				"PaymentProfiles": [
					{
						"_id": "517052fdb982630000000014",
						"OnlyForGroupId": "",
						"AuthorizeNetPaymentProfileId": 16744952,
						"FriendlyName": "Cu CC",
						"Type": "CreditCard",
						"HgId": "1ec8605b-44e9-4b1c-895b-e6c1daf03dfd"
					}
				],
				"DefaultPaymentProfileId": "1ec8605b-44e9-4b1c-895b-e6c1daf03dfd",
				"AuthorizeNetCustomerProfileId": 17750345,
				"TransferAccountBalanceInGroup": 66005,
				"SpendingAccountBalance": 5000
			},
			"MyMemberships": [
				{
					"_id": "5238769534ce278a13000026",
					"ExperiencePoint": 5280,
					"MyManagers": [],
					"MembershipStatus": "Active",
					"FriendlyId": "",
					"RolesInGroup": [
						"HGAdmin"
					],
					"MemberTitleInGroup": "Director Software Engineering",
					"MemberIdInGroup": "d2e0d320-a119-11e2-b177-7d64c8315189",
					"BannerUrl": "",
					"GroupTermStatus": "NoPermission",
					"GroupDepartmentName": "Development",
					"GroupName": "Mercury",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864"
				}
			],
			"UserContext": {
				"AggregatedSecuredTabs": {
					"dashboardTabs": [
						"home"
					],
					"recognizeTabs": [
						"giveRecognition",
						"badges",
						"skills",
						"trophyRoom",
						"deleteFeedEntry",
						"sendCredits"
					],
					"trackTabs": [
						"summary",
						"goalTracks",
						"manageTracks",
						"moreOptions",
						"deleteTracks"
					],
					"motivateTabs": [
						"store",
						"disabled",
						"group",
						"giftCards",
						"pointStore",
						"charitiesButton"
					],
					"profileTabs": [
						"myCards",
						"cardLibrary",
						"cycleSubTab",
                        "perform",
                        "coaching"
					],
					"userTabs": [
						"account",
						"notifications",
						"credits",
						"purchaseCredits",
						"teams",
						"preferences",
						"disabled"
					],
					"adminTabs": [
                        "disabled",
                        "settings",
                        "credits",
                        "members",
                        "editProfile",
                        "provisioning",
                        "metrics",
                        "reports",
                        "recognitions"
					]
				},
				"ExperiencePoint": 5280,
				"MyManagers": [],
				"MembershipStatus": "Active",
				"FriendlyId": "",
				"PermissionsInGroup": [
					"BasicPermission"
				],
				"RolesInGroup": [
					"HGAdmin"
				],
				"MemberTitleInGroup": "Director Software Engineering",
				"MemberIdInGroup": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"CurrentGroupTermStatus": "Bypass",
				"CurrentGroupBannerUrl": "",
				"CurrentGroupName": "Mercury",
				"CurrentGroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864"
			},
			"UserToken": "d3e72345-b22a-4328-ace1-9cb12c73de49",
			"Preference": {
				"SuppressBirthday": false,
				"DefaultChannel": "",
				"WorkZip": "60654",
				"HomeZip": "60609",
				"DefaultChannelId": "",
				"Channels": "",
				"Photo": "",
				"NickName": "Tuan",
				"DefaultGroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864"
			},
			"UserPersonal": {
				"Startdate": 1379432085020,
				"Birthdate": 1214629200000,
				"PrimaryEmail": null,
				"Address": "",
				"FullName": "Cu Barnes",
				"LastName": "Pham-Barnes",
				"FirstName": "Tuan"
			},
			"LowercaseUserName": "cu@highground.com",
			"UserName": "cu@highground.com"
		}
	}
    return {
        getCu: getCu,
		getBasicPermission: getBasicPermission
    }

});
