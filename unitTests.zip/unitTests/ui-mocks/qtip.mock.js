(function(jQuery){
    jQuery.fn.qtip = function(){
        return this;
    };
}(jQuery));