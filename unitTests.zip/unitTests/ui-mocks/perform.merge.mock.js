define(function(){

    function cache() {
        return [
            {
                "hgId": "560a9f90-92b9-11e5-bbfb-c394923559a7",
                "Title": "",
                "Description": "",
                "SortOrder": 1,
                "Questions": [
                    {
                        "hgId": "28122131-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 1,
                        "QuestionText": "short text",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "ShortText",
                        "QuestionHelp": "text",
                        "AnswerSelectors": [

                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "test cache",
                                "SelectedValues": [

                                ],
                                "TrackId": "",
                                "$$hashKey": "0BM",
                                "isDirty": true
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A",
                        "$$hashKey": "0B6"
                    },
                    {
                        "hgId": "28122132-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 2,
                        "QuestionText": "long answer",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "Paragraph",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d77",
                                "Text": "",
                                "Value": 1
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [

                                ],
                                "TrackId": "",
                                "$$hashKey": "0BT",
                                "isDirty": true
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A",
                        "$$hashKey": "0B7"
                    },
                    {
                        "hgId": "28122133-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 3,
                        "QuestionText": "rating scale",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "ScaleRating",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d75",
                                "Text": "test 1",
                                "Value": 1,
                                "$$hashKey": "0CA"
                            },
                            {
                                "_id": "5654769ced012011b9976d74",
                                "Text": "test 2",
                                "Value": 2,
                                "$$hashKey": "0C9"
                            },
                            {
                                "_id": "5654769ced012011b9976d73",
                                "Text": "test 3",
                                "Value": 3,
                                "$$hashKey": "0C8"
                            },
                            {
                                "_id": "5654769ced012011b9976d72",
                                "Text": "test 4",
                                "Value": 4,
                                "$$hashKey": "0C7"
                            },
                            {
                                "_id": "5654769ced012011b9976d71",
                                "Text": "test 5",
                                "Value": 5,
                                "$$hashKey": "0C6"
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "test cache",
                                "SelectedValues": [
                                    1
                                ],
                                "TrackId": "",
                                "$$hashKey": "0C0",
                                "isDirty": true
                            }
                        ],
                        "AllowComments": true,
                        "Confidential": false,
                        "NAEnable": true,
                        "NAText": "N\/A",
                        "$$hashKey": "0B8"
                    },
                    {
                        "hgId": "28122134-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 4,
                        "QuestionText": "Multiple choice",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "RadioButton",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d6f",
                                "Text": "test 1",
                                "Value": 1,
                                "$$hashKey": "0CN"
                            },
                            {
                                "_id": "5654769ced012011b9976d6e",
                                "Text": "test 2",
                                "Value": 2,
                                "$$hashKey": "0CO"
                            },
                            {
                                "_id": "5654769ced012011b9976d6d",
                                "Text": "test 3",
                                "Value": 3,
                                "$$hashKey": "0CP"
                            },
                            {
                                "_id": "5654769ced012011b9976d6c",
                                "Text": "test 4",
                                "Value": 4,
                                "$$hashKey": "0CQ"
                            },
                            {
                                "_id": "5654769ced012011b9976d6b",
                                "Text": "test 5",
                                "Value": 5,
                                "$$hashKey": "0CR"
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [
                                ],
                                "TrackId": "",
                                "$$hashKey": "0CH",
                                "isDirty": true
                            }
                        ],
                        "AllowComments": true,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A",
                        "$$hashKey": "0B9"
                    },
                    {
                        "hgId": "28122135-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 5,
                        "QuestionText": "Checkbox",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "CheckBox",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d69",
                                "Text": "test 1",
                                "Value": 1,
                                "$$hashKey": "0D3"
                            },
                            {
                                "_id": "5654769ced012011b9976d68",
                                "Text": "test 2",
                                "Value": 2,
                                "$$hashKey": "0D4"
                            },
                            {
                                "_id": "5654769ced012011b9976d67",
                                "Text": "test 3",
                                "Value": 3,
                                "$$hashKey": "0D5"
                            },
                            {
                                "_id": "5654769ced012011b9976d66",
                                "Text": "test 4",
                                "Value": 4,
                                "$$hashKey": "0D6"
                            },
                            {
                                "_id": "5654769ced012011b9976d65",
                                "Text": "test 5",
                                "Value": 5,
                                "$$hashKey": "0D7"
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "test cache",
                                "SelectedValues": [
                                    1
                                ],
                                "TrackId": "",
                                "$$hashKey": "0CX",
                                "isDirty": true
                            }
                        ],
                        "AllowComments": true,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A",
                        "$$hashKey": "0BA"
                    },
                    {
                        "hgId": "28122136-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 6,
                        "QuestionText": "Track discussion",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "Templated",
                        "CanSelectTrack": true,
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d63",
                                "Text": "",
                                "Value": 1
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "test cache",
                                "SelectedValues": [

                                ],
                                "TrackId": "",
                                "$$hashKey": "0DD",
                                "isDirty": true
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A",
                        "$$hashKey": "0BB",
                        "isDirty": true,
                        "TrackId": "test track id",
                        "track": {
                            "hgId": "test track id",
                            "percent": 100,
                            "groupId": 1,
                            "goalId": "1c36d580-be46-11e2-be06-f3983bff19cc",
                            "status": "Completed",
                            "title": "Hands-On  IT Training course",
                            "milestones": [
                                {
                                    "percent": 100,
                                    "groupId": 1,
                                    "mlsId": "1c3723a0-be46-11e2-be06-f3983bff19cc",
                                    "title": "Course 1",
                                    "status": "Completed",
                                    "$$hashKey": "0MU"
                                },
                                {
                                    "percent": 100,
                                    "groupId": 1,
                                    "mlsId": "1c374ab0-be46-11e2-be06-f3983bff19cc",
                                    "title": "Course 2",
                                    "status": "Completed",
                                    "$$hashKey": "0MV"
                                },
                                {
                                    "percent": 100,
                                    "groupId": 1,
                                    "mlsId": "1c3771c0-be46-11e2-be06-f3983bff19cc",
                                    "title": "Course 3",
                                    "status": "Completed",
                                    "$$hashKey": "0MW"
                                },
                                {
                                    "percent": 100,
                                    "groupId": 1,
                                    "mlsId": "1c3798d0-be46-11e2-be06-f3983bff19cc",
                                    "title": "Course 4",
                                    "status": "Completed",
                                    "$$hashKey": "0MX"
                                },
                                {
                                    "percent": 100,
                                    "groupId": 1,
                                    "mlsId": "1c37bfe0-be46-11e2-be06-f3983bff19cc",
                                    "title": "Course 5",
                                    "status": "Completed",
                                    "$$hashKey": "0MY"
                                }
                            ],
                            "page": 0
                        }
                    },
                    {
                        "hgId": "28122137-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 7,
                        "QuestionText": "choose from the list",
                        "ToBeAnsweredBy": [
                            "Manager"
                        ],
                        "AnswerType": "Option",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d61",
                                "Text": "test 1",
                                "Value": 1
                            },
                            {
                                "_id": "5654769ced012011b9976d60",
                                "Text": "test 2",
                                "Value": 2
                            },
                            {
                                "_id": "5654769ced012011b9976d5f",
                                "Text": "test 3",
                                "Value": 3
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [
                                    1
                                ],
                                "TrackId": "",
                                "$$hashKey": "0DM",
                                "isDirty": true
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A",
                        "$$hashKey": "0BC"
                    }
                ],
                "sectionValid": true
            }
        ];
    }
    function server() {
        return  [
            {
                "hgId": "560a9f90-92b9-11e5-bbfb-c394923559a7",
                "Title": "",
                "Description": "",
                "SortOrder": 1,
                "Questions": [
                    {
                        "hgId": "28122131-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 1,
                        "QuestionText": "short text",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "ShortText",
                        "QuestionHelp": "text",
                        "AnswerSelectors": [

                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [

                                ],
                                "TrackId": ""
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A"
                    },
                    {
                        "hgId": "28122132-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 2,
                        "QuestionText": "long answer",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "Paragraph",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d77",
                                "Text": "",
                                "Value": 1
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "test server",
                                "SelectedValues": [

                                ],
                                "TrackId": ""
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A"
                    },
                    {
                        "hgId": "28122133-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 3,
                        "QuestionText": "rating scale",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "ScaleRating",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d75",
                                "Text": "test 1",
                                "Value": 1
                            },
                            {
                                "_id": "5654769ced012011b9976d74",
                                "Text": "test 2",
                                "Value": 2
                            },
                            {
                                "_id": "5654769ced012011b9976d73",
                                "Text": "test 3",
                                "Value": 3
                            },
                            {
                                "_id": "5654769ced012011b9976d72",
                                "Text": "test 4",
                                "Value": 4
                            },
                            {
                                "_id": "5654769ced012011b9976d71",
                                "Text": "test 5",
                                "Value": 5
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [

                                ],
                                "TrackId": ""
                            }
                        ],
                        "AllowComments": true,
                        "Confidential": false,
                        "NAEnable": true,
                        "NAText": "N\/A"
                    },
                    {
                        "hgId": "28122134-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 4,
                        "QuestionText": "Multiple choice",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "RadioButton",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d6f",
                                "Text": "test 1",
                                "Value": 1
                            },
                            {
                                "_id": "5654769ced012011b9976d6e",
                                "Text": "test 2",
                                "Value": 2
                            },
                            {
                                "_id": "5654769ced012011b9976d6d",
                                "Text": "test 3",
                                "Value": 3
                            },
                            {
                                "_id": "5654769ced012011b9976d6c",
                                "Text": "test 4",
                                "Value": 4
                            },
                            {
                                "_id": "5654769ced012011b9976d6b",
                                "Text": "test 5",
                                "Value": 5
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [
                                    1
                                ],
                                "TrackId": ""
                            }
                        ],
                        "AllowComments": true,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A"
                    },
                    {
                        "hgId": "28122135-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 5,
                        "QuestionText": "Checkbox",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "CheckBox",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d69",
                                "Text": "test 1",
                                "Value": 1
                            },
                            {
                                "_id": "5654769ced012011b9976d68",
                                "Text": "test 2",
                                "Value": 2
                            },
                            {
                                "_id": "5654769ced012011b9976d67",
                                "Text": "test 3",
                                "Value": 3
                            },
                            {
                                "_id": "5654769ced012011b9976d66",
                                "Text": "test 4",
                                "Value": 4
                            },
                            {
                                "_id": "5654769ced012011b9976d65",
                                "Text": "test 5",
                                "Value": 5
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [
                                    1
                                ],
                                "TrackId": ""
                            }
                        ],
                        "AllowComments": true,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A"
                    },
                    {
                        "hgId": "28122136-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 6,
                        "QuestionText": "Track discussion",
                        "ToBeAnsweredBy": [
                            "Manager",
                            "Subject",
                            "Subordinate"
                        ],
                        "AnswerType": "Templated",
                        "CanSelectTrack": true,
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d63",
                                "Text": "",
                                "Value": 1
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [

                                ],
                                "TrackId": ""
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A"
                    },
                    {
                        "hgId": "28122137-92b9-11e5-bbfb-c394923559a7",
                        "SortOrder": 7,
                        "QuestionText": "choose from the list",
                        "ToBeAnsweredBy": [
                            "Manager"
                        ],
                        "AnswerType": "Option",
                        "QuestionHelp": "",
                        "AnswerSelectors": [
                            {
                                "_id": "5654769ced012011b9976d61",
                                "Text": "test 1",
                                "Value": 1
                            },
                            {
                                "_id": "5654769ced012011b9976d60",
                                "Text": "test 2",
                                "Value": 2
                            },
                            {
                                "_id": "5654769ced012011b9976d5f",
                                "Text": "test 3",
                                "Value": 3
                            }
                        ],
                        "Answers": [
                            {
                                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                                "Text": "",
                                "SelectedValues": [

                                ],
                                "TrackId": ""
                            }
                        ],
                        "AllowComments": false,
                        "Confidential": false,
                        "NAEnable": false,
                        "NAText": "N\/A"
                    }
                ],
                "sectionValid": true
            }
        ];
    }
    return {
        cache: cache,
        server: server
    }

});