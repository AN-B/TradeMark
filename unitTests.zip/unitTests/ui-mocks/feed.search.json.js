
define(function(){
	function getDefaultFeedSearch(){
		return {
			"SearchTerm":"",
			"RecognitionSource":"External",
			"hgId":"4250a9f0-5ac4-11e4-abd1-5b73b1a439a3",
			"Name":"Default",
			"MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
			"DefaultSearch":true,
			"ManagerIds":["2331f5a0-9cd5-11e2-a3a4-25024474fe63"],
			"DepartmentIds":[],
			"TeamIds":[],
			"UserIds":[]
		}
	}
	function getEmptyFeedSearch(){
		return {
			"SearchTerm":"",
			"RecognitionSource":"External",
			"hgId":"4250a9f0-5ac4-11e4-abd1-5b73b1a439a3",
			"Name":"Default",
			"MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
			"DefaultSearch":true,
			"ManagerIds":[],
			"DepartmentIds":[],
			"TeamIds":[],
			"UserIds":[]
		}
	}
	return {
		getDefaultFeedSearch: getDefaultFeedSearch,
		getEmptyFeedSearch : getEmptyFeedSearch
	};
});