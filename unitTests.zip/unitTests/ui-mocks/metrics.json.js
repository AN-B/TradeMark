define(function(){
    function  getMyMetrics(){
        return {
            "RecognitionReceived":148,
            "AdviceReceived":1,
            "ReviewsCompleted":0,
            "GoalsInProgress":0
        };
    }
    return {
        getMyMetrics: getMyMetrics
    }
});