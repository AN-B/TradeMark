define(function() {
    function getBannedWords() {
        return[{
            "Lang": "en",
            "hgId": "87eb8f01-c862-11e5-ba42-df2774c46c91",
            "Level": 2,
            "Word": "crap"
        }, {
            "Lang": "en",
            "hgId": "87eb8f02-c862-11e5-ba42-df2774c46c91",
            "Level": 1,
            "Word": "crapped"
        }, {
            "Lang": "en",
            "hgId": "87eb8f03-c862-11e5-ba42-df2774c46c91",
            "Level": 1,
            "Word": "crappie"
        }, {
            "Lang": "en",
            "hgId": "87ebdce4-c862-11e5-ba42-df2774c46c91",
            "Level": 1,
            "Word": "crappy"
        }];
    }
    return {
        getBannedWords: getBannedWords
    };
});