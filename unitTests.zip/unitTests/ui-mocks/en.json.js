/**
 * Created by philipplekhanov on 8/21/14.
 */
define(function () {
    function get() {
        return {
            "common": {
                "hel": "Hello {{item}}",
                "req": "required",
                "opt": "optional",
                "yes": "Yes",
                "no": "No",
                "Can": "Cancel",
                "all": "All",
                "com": "Completed",
                "clo": "Closed",
                "nts": "Notes",
                "add": "Add",
                "hid": "Hide",
                "mor": "More",
                "ydl": "Yes, Delete",
                "nmd": "Nevermind",
                "don": "Done",
                "rmv": "Remove",
                "rmvq": "Remove?",
                "dlt": "Delete",
                "ok": "OK",
                "smr": "Show more",
                "sls": "Show less",
                "dsc": "Description",
                "can": "Cancel",
                "con": "Continue",
                "clos": "Close",
                "sav": "Save",
                "on": "On",
                "off": "Off",
                "fst": "First Name",
                "lst": "Last Name",
                "fnm": "FullName",
                "unm": "UserName",
                "eml": "Email",
                "edt": "End Date",
                "sdt": "Start Date",
                "phg": "Powered by HighGround",
                "yca": "Your Company Admin has been notified.<br><br>Thanks!<br>HG Team",
                "ati": "Visit HighGround web site.",
                "snd": "Send",
                "tum": "Tell Us More",
                "rec": "Recognize",
                "recw": "Recognize Whom?",
                "chob": "Choose a Badge",
                "eve": "Everyday",
                "val": "Values",
                "ach": "Achievements",
                "des": "Describe why the recipient(s) deserves a recognition...",
                "ple": "Please select at least one recipient",
                "pde": "Please describe why the recipient(s) deserves a recognition",
                "wri": "Write a Message",
                "bac": "Back",
                "requ": "(required)",
                "choa": "Choose an achievement:",
                "cre": " credits",
                "crd": "Credits",
                "not": "N/A",
                "rpt": "Reports",
                "trn": "Transactions",
                "noy": "Not Yet",
                "prb": "Project Based",
                "gen": "General",
                "unc": "Untitled card",
                "tfm": "Transfer Manager",
                "snh": "Search Name Here",
                "nte": "Notification Email",
                "rol": "Role",
                "dpt": "Department",
                "mgr": "Manager",
                "svc": "Save changes",
                "ept": "Export",
                "fil": "Filter",
                "pwd": "Password",
                "sel": "Select manager",
                "drp": "Direct Reports",
                "per": "Perform",
                "pon": "Points",
                "eex": "Export to Excel",
                "recg": "Recognition",
                "coh": "Coaching",
                "gls": "Goals",
                "cmt": "Comments",
                "amt": "Amount",
                "hgr": "HighGround",
                "phgc": "Purchase HG Visa Card",
                "ctc": "Choose This Card",
                "spc": "Spend your credits to purchase a prepaid Visa card that can be used anywhere that Visa is accepted.",
                "edi": "Edit",
                "cts": "comments",
                "nms": "Neverminds",
                "pre": "Preview",
                "bcg": "Background",
                "act": "Actions",
                "tir": "Title is required",
                "cho": "Choose a background",
                "ico": "Icon",
                "sta": "Status",
                "odn": "OK, Done",
                "vpr": "View previous",
                "vnx": "View next",
                "arc": "Archived",
                "wtk": "Which Track",
                "sal": "Select All",
                "ftr": "Find Track...",
                "tyn": "Type your notes...",
                "inv": "Invalid Email",
                "uir": "Username is required",
                "eir": "Email is required",
                "sam": "Select a Member",
                "cra": "Credits Administrator",
                "suc": "Success!"
            },
            "actions": {
                "ca": "Cancel",
                "sc": "Save Changes",
                "by": "Buy",
                "ny": "Not Yet"
            },
            "day": {
                "mon": "Monday",
                "tue": "Tuesday",
                "wed": "Wednesday",
                "thu": "Thursday",
                "fri": "Friday",
                "sat": "Saturday",
                "sun": "Sunday"
            },
            "helpTips": {
                "re": {
                    "gv": {
                        "tw": "Who's awesome? Select one or more individuals to recognize. You can search by name or functional area (e.g. 'sales'). If you select more than one person they will be recognized as a team.",
                        "wr": "Choose a badge to describe their accomplishment. Click into the search field to display the badges. You can select from the list or search for any term which describes the badge (e.g. 'congrats', 'number', or 'red'). Use the 'Filter Recognition' drop-down below to only show badges of a certain category.",
                        "tt": "Some badges have credits associated with them. Choosing one of these badges will give some of your credits to the person you are recognizing. The credits will come from your 'credits to give' and go to their 'credits to spend.' Look for green text on the bottom of the badge to see how many credits are associated with it. If there aren't any it will appear blank. The number to the right shows the total amount of credits you will spend when you give the recognition you selected."
                    },
                    "fd": {
                        "ei": "Click to email this person."
                    }
                },
                "tr": {
                    "as": {
                        "wt": "Select which saved track(s) you want to assign from the list below. You can also search by name for any track in the Track Library.",
                        "tw": "Select one or more recipients below. You may use the search field to find people by name or department. Whomever you choose will be assigned the track(s) you selected."
                    },
                    "cr": {
                        "wc": "Choose who in your organization can see this track if it is saved as a template.<br><br>If <span style=font-weight:bold>'Only Me'</span> is chosen only you will be able assign it.<br><br>If <span style=font-weight:bold>'Everyone'</span> is chosen anyone in your organization will be able to assign it.<br><br>If <span style=font-weight:bold>'Teams'</span> is selected only a particular team will be able to assign it.",
                        "rl": "Select this option if milestones must be completed in sequential order. In the list below, the milestone on top must be completed first and the milestone on the bottom must be completed last. Objectives may only be completed after the last milestone.",
                        "cv": "Assign credits to this objective. When the assignee completes this objective the amount of credits assigned will be transferred from your 'credits to give' account into their 'credits to spend' account. If you do not have enough credits to give you will not be able to approve this objective.",
                        "xp": "Assign Experience Points (XP) to this objective. When the assignee completes the objective they will earn the amount of Experience Points you specify.",
                        "ra": "Check this box if you are assigning this track to someone and want to confirm they completed this milestone. You will be notified once the assignee has marked the milestone complete.",
                        "cm": "Assign credits to this milestone. When the assignee completes this milestone the amount of credits assigned will be transferred from your 'credits to give' account into their 'credits to spend' account. If you do not have enough credits to give you will not be able to approve this milestone.",
                        "mx": "Assign Experience Points (XP) to this objective. When the assignee completes the milestone they will earn the amount of Experience Points you specify."
                    },
                    "ed": {
                        "wt": "Select a saved track from the list below to edit it. You can also search for any track in the Track Library by name."
                    },
                    "vw": {
                        "ft": "Click on a folder below to filter tracks by folder name. Selection of multiple folders is allowed."
                    }
                },
                "ad": {
                    "se": {
                        "en": "By clicking this checkbox, your news will be sent as a email to all members in addition to showing on members dashboard."
                    }
                },
                "ac": {
                    "pr": {
                        "cf": "Click to choose a file from your hard drive to upload. You can crop the image after it has been uploaded.",
                        "gr": "Click to associate your Gravatar image to your profile. Your Gravatar is an image that follows you from site to site appearing beside your name when you do things like comment or post. You can manage all of your avatar images using Gravatar and your email address. If you want to learn more or want to set up/manage your Gravatar, click on the 'What's Gravatar' link.",
                        "gu": "You are currently using your Gravatar image. Click to Change which Gravatar is used or to discontinue using Gravatar.",
                        "ge": "This email address has to match one of the registered email addresses that you've set up on Gravatar. This will initially default to your HighGround Username.",
                        "ci": "Place this button in your email signature to make it easy for others to give you recognition. Highlight the button below as you would with text to copy. Then, copy and paste into your email signature using keyboard shortcuts (PC: CTRL+C to copy and CTRL+V to paste, Mac: Command+C to copy and Command+V to paste).",
                        "cu": "Use this URL as a quick way for anyone to recognize you. Put it in your email signature or anywhere else people will see your name. If someone in your organization clicks it they will be taken to the Give Recognition page with you selected. If someone outside the organization clicks it they will be taken to the public recognition page."
                    }
                }
            },
            "mon": {
                "jan": "January",
                "feb": "February",
                "mar": "March",
                "apr": "April",
                "may": "May",
                "jun": "June",
                "jul": "July",
                "aug": "August",
                "sep": "September",
                "oct": "October",
                "nov": "November",
                "dec": "December"
            },
            "sideNav": {
                "co": "Company",
                "po": "Profile",
                "tr": "Tracks",
                "st": "Store",
                "pf": "Perform",
                "ad": "Admin",
                "pr": "Provision"
            },
            "tabs": {
                "re": {
                    "fe": {
                        "fe": "Feeds"
                    },
                    "gr": {
                        "gr": "Give Recognition"
                    },
                    "co": {
                        "co": "Coaching"
                    }
                },
                "tr": {
                    "mt": {
                        "mt": "My Tracks"
                    },
                    "ct": {
                        "ct": "Create Track"
                    },
                    "tl": {
                        "tl": "Track Library"
                    },
                    "at": {
                        "at": "Assign Tracks"
                    }
                },
                "mo": {
                    "gc": {
                        "gc": "Gift Cards"
                    },
                    "cg": {
                        "cg": "Canadian Gift Cards"
                    },
                    "ch": {
                        "ch": "Charities"
                    },
                    "gd": {
                        "gd": "Group Deals"
                    },
                    "re": {
                        "re": "Rewards"
                    }
                },
                "pf": {
                    "mc": {
                        "mc": "My Cards"
                    },
                    "cl": {
                        "cl": "Card Library"
                    },
                    "fb": {
                        "fb": "Feedback"
                    },
                    "co": {
                        "co": "Coaching"
                    }
                },
                "us": {
                    "ac": {
                        "ac": "Account",
                        "pr": "Profile",
                        "pi": "Payment Info"
                    },
                    "no": {
                        "no": "Notifications",
                        "al": "All",
                        "ge": "General",
                        "ev": "Events",
                        "ov": "Overdue Alerts",
                        "tr": "Transactions"
                    },
                    "cr": {
                        "cr": "Credits",
                        "tc": "Transfer Credits",
                        "pc": "Purchase Credit Packs",
                        "tr": "Transactions"
                    },
                    "pt": {
                        "pt": "Points",
                        "tr": "Transactions"
                    },
                    "tm": {
                        "tm": "Teams",
                        "mt": "Manage Teams",
                        "ct": "Create Team",
                        "ed": "Edit Team"
                    },
                    "pr": {
                        "pr": "Preferences",
                        "ge": "General"
                    }
                },
                "ad": {
                    "se": {
                        "se": "Settings"
                    },
                    "re": {
                        "re": "Recognitions"
                    },
                    "cr": {
                        "cr": "Credits"
                    },
                    "me": {
                        "me": "Members"
                    },
                    "mt": {
                        "mt": "Metrics"
                    },
                    "rp": {
                        "rp": "Reports"
                    },
                    "pe": {
                        "pe": "Perform"
                    }
                }
            },
            "top": {
                "tos": "To Spend:",
                "tog": "To Give:",
                "cre": "Credits",
                "tra": "Transactions",
                "gre": "Give Recognition",
                "trc": "Transfer Credits",
                "acc": "Account",
                "adm": "Admin",
                "not": "Notifications",
                "hel": "Help",
                "sti": "Stop Impersonation",
                "lgo": "Log Out",
                "tou": "Terms of Use",
                "poi": "Points",
                "pts": "Points to Spend",
                "ptg": "Points to Give",
                "cts": "Credits to Spend",
                "ctg": "Credits to Give"
            },
            "users": {
                "ac": {
                    "pr": {
                        "pi": "Personal Information",
                        "ua": "Upload a different avatar",
                        "cf": "Choose File",
                        "ug": "Use Gravatar",
                        "wg": "What's Gravatar",
                        "cg": "Change or Remove Gravatar",
                        "ea": "Email Address to Use",
                        "ue": "Use Gravatar Email",
                        "rg": "Remove Gravatar Email",
                        "nv": "Nevermind",
                        "un": "Username",
                        "ne": "Notification Email",
                        "fn": "First Name",
                        "ln": "Last Name",
                        "fu": "Full Name",
                        "bm": "Birthday - Month",
                        "bd": "Birthday - Day",
                        "sb": "Supress Birthday Announcements",
                        "hz": "Home Zip Code",
                        "wz": "Work Zip Code",
                        "pt": "Position/Title",
                        "mm": "My Manager (Who reviews me)",
                        "sm": "Select Manager",
                        "my": "My Manager",
                        "rm": "Recognize Me Links",
                        "cr": "Copy 'Recognize Me' URL Only",
                        "ci": "Copy 'Recognize Me' Image Button",
                        "ho": "How am I doing? Recognize Me.",
                        "cp": "Change Password",
                        "np": "New Password",
                        "vp": "Verify New Password",
                        "tb": "Teams I Belong To or Own",
                        "um": "Updated manager to : ",
                        "au": "Account has been updated.",
                        "re": "You are restricted from changing your notification email at this time. Please contact your system administrator.",
                        "gs": "Gravatar has been set.",
                        "gr": "Gravatar has been removed.",
                        "rq": {
                            "fn": "First Name required",
                            "ln": "Last Name required",
                            "fr": "Full Name required",
                            "bm": "Birth Month required",
                            "bd": "Birth Date is required",
                            "hz": "Home Zip Code in wrong format",
                            "wz": "Work Zip Code in wrong format",
                            "pw": "Password should be at least 6 characters long",
                            "dm": "Your passwords don't match"
                        },
                        "ph": {
                            "np": "At least 6 characters long"
                        }
                    },
                    "pi": {
                        "ba": "Billing Address",
                        "fn": "First Name",
                        "ln": "Last Name",
                        "ad": "Address",
                        "ct": "City",
                        "st": "State",
                        "zp": "Zip",
                        "pm": "Payment Method",
                        "pt": "Payment Type",
                        "cc": "Credit Card",
                        "ac": "ACH",
                        "na": "Friendly Name For this card",
                        "fp": "Someone's Chase Credit Card",
                        "cn": "Credit Card Number",
                        "em": "Exp. Month",
                        "ey": "Exp. Year",
                        "sc": "Security Code",
                        "ns": "ACH is currently not supported. Please use Credit Card.",
                        "fa": "Friendly Name For this account",
                        "ap": "Someone's Bank",
                        "bn": "Bank Name",
                        "at": "Account Type",
                        "ck": "Checking",
                        "sv": "Savings",
                        "nm": "Name on Account",
                        "rn": "Bank Routing Number",
                        "an": "Bank Account Number",
                        "te": {
                            "fn": "First Name is required",
                            "ln": "Last Name required",
                            "ad": "Address is required",
                            "ct": "City is required",
                            "st": "State is required",
                            "zp": "Zip Code is required",
                            "zf": "Zip Code in wrong format",
                            "zl": "Maximum number of characters is 10",
                            "mc": "Maximum number of characters is 30",
                            "pt": "Payment Type is required",
                            "cn": "Friendly Name for Card is required",
                            "cc": "Credit Card Number is required",
                            "em": "Expiration month required",
                            "ey": "Expiration year required",
                            "na": "Friendly Name for Account is required",
                            "bn": "Bank Name is required",
                            "nm": "Name on Account is required",
                            "at": "Account Type is required",
                            "rn": "Routing Number is required",
                            "an": "Account Number is required"
                        },
                        "cp": "Create Payment Profile",
                        "dp": "default payment",
                        "pa": "No Payment Profile",
                        "pb": "My Payment Profile",
                        "pc": "My Payment Profiles",
                        "pd": "Expiration Date is required",
                        "pe": "Expiration Date in wrong format",
                        "pf": "Credit Card is required",
                        "pg": "Credit Card in wrong format",
                        "ph": "Security Code is required",
                        "pi": "Security Code in wrong format",
                        "pj": "Make this my default payment type",
                        "pk": "Delete this payment type",
                        "pl": "Profile information changed.",
                        "id": "Default Profile information deleted.",
                        "pn": "Profile information saved."
                    },
                    "cp": {
                        "rq": "Your current password is required to make this change",
                        "cp": "Enter Your Current Password",
                        "ok": "OK",
                        "te": {
                            "cp": "Current password required"
                        }
                    }
                },
                "cr": {
                    "tc": {
                        "hm": "How Many Credits?",
                        "no": "Notes",
                        "re": "Reason for transferring credits...",
                        "to": "To Whom?",
                        "fi": "Find recipients...",
                        "ca": "Credit Category?",
                        "ed": "Expiration Date?",
                        "ex": "Exp. Date",
                        "al": "All",
                        "pv": "Preview",
                        "am": "Amount",
                        "tt": "Total you will transfer",
                        "ze": "No recipients selected",
                        "on": "{} recipient selected",
                        "ot": "{} recipients selected",
                        "ok": "OK! Transfer",
                        "te": {
                            "ra": "Credit amount should be in the range of",
                            "no": "Notes is required"
                        }
                    },
                    "pc": {
                        "cp": "Credit Pack Quantity",
                        "co": "Cost",
                        "cr": "credits",
                        "pv": "Preview",
                        "wa": "Which Account?",
                        "sp": "Credits to Spend",
                        "gi": "Credits to Give",
                        "pm": "Payment Method",
                        "pp": "Add Payment Profile",
                        "to": "Total you will spend",
                        "su": "Are you sure you want to purchase credits for your transfer account?",
                        "st": "Transfer credits are strictly used to give out recognitions and can not be used to purchase goods/services.",
                        "no": "No",
                        "yo": "Confirm Your Order",
                        "ii": "Item Info",
                        "cd": "Credits",
                        "hg": "HighGround Credit Pack",
                        "ok": "OK, Continue Purchase",
                        "or": "Change Order",
                        "ta": "Thanks for your Credit Pack purchase :)",
                        "em": "You should receive an email receipt shortly.",
                        "mo": "Purchase more Credit Packs",
                        "tr": "Transfer credits",
                        "te": "Bill Me Later is available only for Transfer Account"
                    },
                    "tr": {
                        "sd": "Start Date",
                        "ed": "End Date",
                        "st": "Search Term",
                        "fr": "Filter Results",
                        "ep": "Export",
                        "da": "Date",
                        "co": "Company",
                        "ty": "Type",
                        "fn": "FirstName",
                        "ln": "LastName",
                        "ei": "EmpId",
                        "cr": "Credits",
                        "pt": "Points",
                        "no": "Notes",
                        "re": "References",
                        "ss": "Status"
                    },
                    "cm": {
                        "bt": "Bucket Type",
                        "id": "Issued Date",
                        "ai": "Amount Issued",
                        "ar": "Amount Remaining",
                        "ed": "Expire Date",
                        "ac": "Action",
                        "rt": "Return",
                        "rq": "Request"
                    }
                },
                "tm": {
                    "mt": {
                        "st": "Search Team",
                        "sp": "Search Team Name...",
                        "ow": "Teams I Own",
                        "be": "Teams I Belong To",
                        "pt": "Public Teams",
                        "pv": "Preview",
                        "no": "No team selected",
                        "on": "Owner:",
                        "me": "Me",
                        "vi": "Visibility:",
                        "pr": "Private",
                        "pu": "Public",
                        "mb": "Team Members",
                        "it": "Included Teams",
                        "ac": "Actions",
                        "de": "Delete",
                        "du": "Duplicate",
                        "to": "Transfer Ownership",
                        "et": "Edit Team",
                        "tt": "Ownership has been transferred to ",
                        "td": "The team has been deleted"
                    },
                    "et": {
                        "sm": "Select Member(s)",
                        "sn": "Search Name...",
                        "at": "Add Team(s)",
                        "tn": "Search Team Name...",
                        "vm": "View Members",
                        "pv": "Preview",
                        "un": "Give this team a unique name...",
                        "dp": "Description",
                        "td": "Add a team description...",
                        "mb": "Members",
                        "in": "Include myself on the team",
                        "tm": "Teams",
                        "vi": "Visibility",
                        "pu": "Public",
                        "pr": "Private",
                        "up": "Upload Team Avatar (optional)",
                        "uu": "Use URL",
                        "fc": "From Computer",
                        "ad": "Member(s) have been added",
                        "ta": "A team and its members have been added",
                        "tr": "A team and its members were removed from the team",
                        "mr": "A member has been removed",
                        "ic": "included",
                        "nc": "not included",
                        "tt": " in the team",
                        "cr": "Created",
                        "ud": "Updated",
                        "tb": "Team has been ",
                        "te": {
                            "tr": "Title required",
                            "mr": "Members required",
                            "vi": "Visibility required"
                        }
                    }
                },
                "pr": {
                    "gp": {
                        "en": "Email Notifications",
                        "rc": "Send me a Recap email",
                        "dy": "Daily",
                        "wk": "Weekly",
                        "in": "Include weekends in the Daily Recap (Saturday & Sunday emails)",
                        "sa": "Preferences have been saved."
                    },
                    "no": {
                        "gn": "General",
                        "rg": "Recognize",
                        "mo": "Motivate",
                        "pf": "Perform",
                        "ti": "Title",
                        "em": "Email",
                        "in": "HG Internal",
                        "sm": "SMS",
                        "av": "Available credits updated",
                        "pa": "Path assigned",
                        "pc": "Permission changes",
                        "tc": "Tranfer credits changed"
                    }
                },
                "no": {
                    "ra": "Remove All",
                    "no": "You have no notifications.",
                    "fr": "from",
                    "by": "by",
                    "hb": "Happy Birthday",
                    "ha": "Happy Anniversary",
                    "at": "Looks as though your milestones could use your attention!",
                    "td": "Today",
                    "is": "is",
                    "bd": "birthday!",
                    "an": "anniversary!"
                },
                "av": {
                    "ua": "Upload Avatar",
                    "if": "Supported image format",
                    "fs": "File size",
                    "cr": "Crop image by click and dragging over the avatar.",
                    "in": "User avatar updated"
                },
                "di": {
                    "cm": "Choose a Member",
                    "sp": "Search People",
                    "fr": "Find recipients...",
                    "al": "All",
                    "fu": "Filter Users",
                    "dt": "Are you sure you want to delete the team",
                    "de": "Delete",
                    "tm": "Team Members",
                    "do": "Done"
                }
            },
            "public": {
                "inv": {
                    "acp": {
                        "wth": "Welcome back to HighGround!",
                        "hwm": "Oh, how we've missed you. <em>Let's get motivated!</em>",
                        "yca": "Your Company Admin has been notified.<br><br>Thanks!<br>HG Team",
                        "ttl": {
                            "ati": "Visit HighGround web site."
                        },
                        "pbh": "Powered by HighGround"
                    },
                    "ivl": {
                        "dym": "Darn, you missed out!",
                        "yie": "Your invitation has expired. ",
                        "pcy": "Please contact the your Company Admin."
                    },
                    "rej": {
                        "bth": "Bummed to hear you're not ready to come back now.",
                        "lft": "But, looking forward to having you back in the near future!"
                    }
                },
                "man": {
                    "err": {
                        "mis": {
                            "sim": "Sorry,<br>I may have eaten that page.<br>-Gus",
                            "ems": "Email Support"
                        }
                    },
                    "vod": {
                        "ivp": "Invalid Page"
                    }
                },
                "pwd": {
                    "fpe": {
                        "pre": "A password reset email was sent to <em>__persistEmail__</em>. Click on the link in the email to reset your password."
                    },
                    "fpw": {
                        "unm": "Username",
                        "eyu": "Enter your username and click Send to receive a Password Reset email. Your username is typically in the format of an email address. A message will be sent to your registered notification email address.",
                        "snd": "Send",
                        "can": "Cancel",
                        "plh": {
                            "pun": "Your username..."
                        },
                        "tlt": {
                            "tet": "Username is required"
                        }
                    },
                    "rsp": {
                        "enp": "Enter a new password and verify it by entering it again.",
                        "npw": "New Password",
                        "vnp": "Verify New Password",
                        "plh": {
                            "enp": "Enter new password...",
                            "tnp": "Type new password again..."
                        },
                        "tlt": {
                            "psb": "Password should be at least 6 characters long",
                            "dnm": "Does not match with New Password"
                        }
                    }
                },
                "rcg": {
                    "prz": {
                        "tps": "Thanks! Please show us some love. ",
                        "yfn": "Your Full Name",
                        "ycn": "Your Company Name",
                        "yem": "Your Email",
                        "cam": "Choose a Message",
                        "por": "<span>1</span> = poor",
                        "fir": "<span>5</span> = fair",
                        "exc": "<span>10</span> = excellent",
                        "sar": "Select a recognition",
                        "okg": "OK, Give",
                        "can": "Cancel",
                        "ens": "Endorsed Skills",
                        "rcr": "Received Recognitions",
                        "plh": {
                            "fnm": "Full Name...",
                            "cmn": "Company Name...",
                            "eml": "Email Address..."
                        },
                        "tlt": {
                            "fnr": "Your full name required",
                            "yfn": "Your full name is limited to 65 characters",
                            "cnr": "Your company name required",
                            "ycn": "Your company name is limited to 65 characters",
                            "cei": "Your company email is invalid"
                        },
                        "rue": "Rate your experience with __userInfo.PublicDisplayName__"
                    },
                    "rct": {
                        "tfr": "Thanks for recognizing me!"
                    }
                }
            },
            "main": {
                "tut": {
                    "lok": "Looks like you are new here. Would you like me to show you around?",
                    "yes": "Yes, please!",
                    "ski": "Skip it"
                }
            },
            "motivate": {
                "dlg": {
                    "efd": "Email Us for Details",
                    "chd": "Choose Deal",
                    "can": "Cancel"
                },
                "cnf": {
                    "ord": "Order Summary",
                    "pvo": "Please take a moment to verify the information below before placing your order.",
                    "itm": "Item",
                    "tot": "Total",
                    "des": "Description:",
                    "gft": "Gift for:",
                    "pik": "Pick-up instructions:",
                    "con": "Confirm",
                    "can": "Cancel",
                    "exp": "Expires on"
                },
                "mcg": {
                    "pgc": "Purchase a Gift Card<label class='muted'><em>The HighGround credit rate for the Canadian Gift Card values is based on the vendor's exchange rate.<br>Please review your check-out information before submitting your order.</em></label>"
                },
                "mtc": {
                    "prg": "We applaud your charitable efforts, but we want to make sure you spend your credits treating yourself! Please see our offerings under the <strong>'Gift Cards'</strong> tab.",
                    "dtc": "Donate to a Charity<label class='muted'><em>For reference, $10 = 100 credits.</em></label>"
                },
                "mot": {
                    "cyo": "Confirm Your Order",
                    "crd": "Card",
                    "iav": "Item Info and Availability",
                    "val": "Value",
                    "cre": "Credit",
                    "tcs": "Total credits you will spend",
                    "ocp": "OK, Continue Purchase",
                    "whg": "Welcome to the HighGround Store",
                    "grd": "Group Deals",
                    "gfc": "Gift Cards",
                    "chr": "Charities",
                    "cms": "coming soon",
                    "edu": "Education"
                },
                "mgt": {
                    "typ": "Thanks for your purchase :)",
                    "yre": "You should receive an email with further instructions regarding your purchase."
                },
                "mgf": {
                    "pgc": "Purchase a Gift Card<label class='muted'><em>For reference, $10 = 100 credits.</em></label>",
                    "frc": "For reference, $10 = 100 credits."
                },
                "mco": {
                    "cyg": "Confirm Your Group Order for:",
                    "grc": "<h5>Great choice! </h5>We're almost ready to book your event. Just let us know when you would like to attend and how many people are coming.",
                    "1ch": "1st choice",
                    "2ch": "2nd choice",
                    "gst": "Guests: # of Attendees",
                    "img": "Image",
                    "inf": "Deal Info",
                    "cst": "Cost",
                    "gpd": "Group Deal",
                    "stx": "Sales Tax",
                    "grq": "Gratuity (required)",
                    "tcs": "Total credits you will spend<br>(Group Deal + Sales Tax + Gratuity)",
                    "cts": "Credits To Spend",
                    "ctg": "Credits To Give",
                    "fac": "From Which Account?",
                    "cng": "Change",
                    "dat": "Date",
                    "tim": "Time"
                },
                "mgm": {
                    "mpg": "Manage Purchased Group Deals",
                    "sfl": "Search Fields",
                    "com": "Company",
                    "dat": "Date",
                    "hds": "Hold Description",
                    "crd": "Credits",
                    "stu": "Status",
                    "act": "Action",
                    "can": "Cancel",
                    "tkw": "Type keyword..."
                },
                "mtb": {
                    "pur": "Purchase",
                    "mng": "Manage"
                },
                "mtk": {
                    "typ": "Thanks for your purchase :)",
                    "dts": "Dates and Times selected:",
                    "itm": "Item Thumbnail",
                    "inf": "Item Info",
                    "tot": "Total",
                    "onm": "Order Number",
                    "pmg": "Purchase more group events",
                    "bts": "Back to Store"
                },
                "mog": {
                    "fdb": "Filter Deals By: ",
                    "efp": "Email Us for Price",
                    "cdl": "Choose Deal",
                    "vdt": "View Detail",
                    "plc": "Enter keywords, i.e. 'sushi', 'baseball'..."
                },
                "mpt": {
                    "typ": "Thanks for your purchase :)",
                    "cni": "You should receive a confirmation email soon about your purchase.",
                    "bgc": "Back to Gift Cards"
                },
                "mpd": {
                    "gca": "Gift Card Amount",
                    "crd": "Credits",
                    "usc": "Use All Spending Credits",
                    "pfe": "Processing Fee",
                    "tvl": "Total Value",
                    "noc": "Name on the Card",
                    "fnm": "Full Name",
                    "sad": "Shipping Address",
                    "st1": "Street 1",
                    "st2": "Street 2",
                    "cty": "City",
                    "sta": "State",
                    "zip": "Zip",
                    "tcs": "Total credits you will spend",
                    "pur": "Purchase",
                    "bts": "← Back to Store",
                    "des": "Description:",
                    "iwl": "This item will no longer be available on ",
                    "exp": "Expires on"
                },
                "str": {
                    "frb": "Filter Rewards By:",
                    "plc": "Enter keywords, i.e. 'sushi', 'baseball'...",
                    "exi": " Expires:"
                }
            },
            "profile": {
                "coa": {
                    "noc": "There are no coaching notes yet.",
                    "nov": "You cannot view this person's coaching notes."
                },
                "com": {
                    "fee": {
                        "rec": "Recognize",
                        "coa": "Coaching",
                        "ple": "Enter name..."
                    }
                },
                "ans": {
                    "sea": "Search",
                    "ans": "Answer Library",
                    "fil": "Filter by Competency",
                    "all": "--All--",
                    "fis": "Filter by Sentiment",
                    "sel": "Select answer by clicking on a box below. Multiple selections are allowed.",
                    "noa": "There are no answers.",
                    "sek": "Search keywords in Answer library"
                },
                "tra": {
                    "sel": {
                        "sea": "Search tracks...",
                        "noc": "No Track Description"
                    }
                },
                "iso": {
                    "fee": {
                        "via": "View All Recognitions"
                    }
                },
                "partials": {
                    "boo": {
                        "use": {
                            "opp": "Other people's profile"
                        }
                    },
                    "fee": {
                        "coa": {
                            "loa": "load earlier notes",
                            "add": "Add a note",
                            "hid": "Hide this private note",
                            "sho": "Show this private note",
                            "del": "Delete this comment",
                            "load": "load earlier comments",
                            "giv": "Give some constructive coaching here ...",
                            "dec": "Delete this coaching note"
                        }
                    },
                    "mem": {
                        "coa": {
                            "coa": "Coach Whom?",
                            "wri": "Write a Message",
                            "ent": "Enter your coaching notes here...",
                            "ple": "Please select at least one recipient"
                        }
                    },
                    "giv": {
                        "coa": {
                            "lin": " Link to Goal",
                            "coa": "Coaching Note",
                            "pri": "Private (for my eyes only)",
                            "con": "Coaching Note is required",
                            "giv": "Give some constructive coaching here ...",
                            "dra": "Draft (for my eyes only)",
                            "nod": "Not Draft"
                        }
                    },
                    "rec": {
                        "fee": {
                            "rem": "Remove from Feed",
                            "dis": "Dismiss for All",
                            "nos": "No search results found.",
                            "you": "You",
                            "der": "Delete Recognition",
                            "hid": "Hide Recognition",
                            "den": "Delete News",
                            "sho": "Show",
                            "sha": "Share",
                            "cer": "Certificate",
                            "cli": "Click for more actions",
                            "rec": "received this badge from",
                            "lik": " Like",
                            "d": "d",
                            "oth": "other",
                            "s": "s"
                        }
                    },
                    "rev": {
                        "tra": {
                            "viw": "View previous",
                            "vin": "View next"
                        }
                    }
                },
                "per": {
                    "rev": {
                        "rew": "Reviewee:",
                        "man": "Manager:",
                        "vio": "View other reviewer's responses",
                        "vie": "View Employee version",
                        "noe": "No recognitions were received within this review period.",
                        "ach": "Achievement",
                        "ext": "External",
                        "rec": "Received from",
                        "ret": "Remove this track",
                        "pit": "Pick another track",
                        "set": "Select Your Track",
                        "sey": "Select a track",
                        "cmt": "Comments:",
                        "sel": "--Select--",
                        "rej": "Reject Review",
                        "pre": "Prev",
                        "nex": "Next",
                        "sub": "Submit Review",
                        "red": "Upon submitting, you will only be able to make changes by submitting a request through the 'Request Edit' button for this review. Only when that request has been approved will you be able to modify this review. Continue?",
                        "yes": "Yes, Submit Review",
                        "ok": "OK, Done",
                        "ner": "Nevermind, Don't Reject",
                        "ren": "Rejection note:",
                        "by": "By:",
                        "des": "Description:",
                        "dat": "Date:",
                        "you": "You are about to reject a review for the following person(s). Please enter your reason for rejecting this review and select the persons:",
                        "log": "Long answer",
                        "ans": "Answer required",
                        "anr": "Answer is required",
                        "san": "Short answer",
                        "anl": "Answer Library",
                        "rar": "Rating is required",
                        "cmr": "Comment is required",
                        "moa": "Select one or more answer",
                        "seo": "Select one answer"
                    }
                },
                "perf": {
                    "rev": {
                        "sea": "Search Reviews",
                        "rev": "Reviewee:",
                        "yor": "Your Role:",
                        "sub": "Submit Review",
                        "sho": "SHOW MORE ",
                        "com": "Completed Reviews",
                        "nor": "No completed reviews found.",
                        "tes": "test description",
                        "son": "Submitted On:",
                        "yoc": "You cannot view this person's reviews.",
                        "fin": "Find review...",
                        "sel": "Select a folder",
                        "req": "Request Edit",
                        "typ": "Type an explanation of why you are requesting to edit this review.",
                        "okr": "OK, Request",
                        "pen": "Pending Reviews",
                        "nop": "No pending reviews found."
                    }
                },
                "use": {
                    "fee": {
                        "rec": "Recognize Me",
                        "pin": "Pin Me",
                        "fee": "Feed",
                        "per": "Perform",
                        "coa": "Coaching"
                    }
                }
            },
            "recognize": {
                "dia": {
                    "ach": {
                        "sel": {
                            "chot": "Choose a template",
                            "nov": "No Value Description",
                            "ple": "Please Select a Level"
                        }
                    },
                    "bad": {
                        "met": {
                            "las": "Last Given:",
                            "dat": "12/10/13",
                            "bad": "Badge Recipients",
                            "thr": "3",
                            "don": "Done"
                        },
                        "sel": {
                            "cho": "Choose a Quick Recognition Badge",
                            "whi": "Which Recognition?",
                            "fin": "Find Recognition Badge...",
                            "all": "All",
                            "tha": "Thanks",
                            "lik": "Like",
                            "qui": "Quick",
                            "nor": "No Recognition Badges have been found",
                            "can": "Cancel"
                        }
                    },
                    "pre": {
                        "cer": {
                            "gena": "Generate a Certificate",
                            "sel": "Select a style",
                            "inc": "Include Message",
                            "genc": "Generate Certificate",
                            "dow": "Download PDF",
                            "rep": "Repeat entire message on additional page(s)"
                        }
                    },
                    "rec": {
                        "lis": {
                            "recl": "Recipients List",
                            "recm": "Recognize Me"
                        }
                    },
                    "sel": {
                        "tea": {
                            "cho": "Choose a Team",
                            "sea": "Search Team",
                            "seat": "Search Team..."
                        }
                    },
                    "use": {
                        "sel": {
                            "cho": "Choose a Member",
                            "sea": "Search Name",
                            "fin": "Find recipients...",
                            "fil": "Filter Users"
                        }
                    }
                },
                "fee": {
                    "man": {
                        "use": {
                            "dlg": {
                                "add": "Add Members to Follow",
                                "sea": "Search People",
                                "seap": "Search people...",
                                "sel": "Selected Member(s)",
                                "ok": "OK",
                                "can": "Cancel"
                            }
                        }
                    }
                },
                "lin": {
                    "suc": "Successfully posted your recognition to your LinkedIn profile.",
                    "the": "There was an issue posting to your LinkeIn profile. You are required to allow HighGround to post under your behalf.",
                    "ret": "Return to Feeds"
                },
                "par": {
                    "giv": {
                        "ach": {
                            "plel": "Please Select a Level",
                            "all": "All Departments",
                            "nov": "No Value Description"
                        },
                        "cus": {
                            "bac": "Back to Default Badges",
                            "tit": "Title",
                            "giv": "Give your badge a name ...",
                            "pleb": "Please enter a name for your customized badge",
                            "choc": "Choose a Category",
                            "plec": "Please select one of the categories above",
                            "the": "There is no recognition badge in this category"
                        },
                        "eve": {
                            "chor": "Choose an everyday recognition",
                            "cre": "Create a Custom Badge"
                        },
                        "non": {
                            "you": " You do not have access to give recognitions."
                        },
                        "rec": {
                            "opt": {
                                "addc": "Add Credits",
                                "addp": "Add Points",
                                "trs": "This recognition will be shown in the Feed.",
                                "trns": "This recognition will not be shown in the Feed.",
                                "sho": "Show in Feed",
                                "dsho": "Do not show in Feed",
                                "cre": "__request.MoreOptions.creditValue__  Credits",
                                "poi": "__request.MoreOptions.pointValue__ Points"
                            }
                        },
                        "val": {
                            "chov": "Choose a value recognition",
                            "cho": "Choose badge:",
                            "bad": "Badge Preview",
                            "poi": " points",
                            "rem": " remaining"
                        }
                    }
                },
                "pop": {
                    "giv": {
                        "rec": {
                            "giv": "Give Recognition"
                        }
                    },
                    "vie": {
                        "use": {
                            "who": "Who's Recognized?"
                        },
                        "com": {
                            "who": "Who liked this comment:"
                        },
                        "con": {
                            "who": "Who liked this:"
                        }
                    }
                }
            },
            "track": {
                "dlg": {
                    "cod": {
                        "sme": "Search Members",
                        "slm": "Selected Member(s)",
                        "wtr": "Writer",
                        "mna": "Manager/Approver",
                        "phl": {
                            "smb": "Search members..."
                        }
                    },
                    "dsd": {
                        "ndm": "Type a note and select a delegation member",
                        "ant": "Add Notes (optional)",
                        "fur": "Filter Users",
                        "phl": {
                            "fdm": "Find delegation member..."
                        }
                    },
                    "ltd": {
                        "stk": "Search Tracks",
                        "ok": "OK",
                        "cnl": "Cancel",
                        "phl": {
                            "str": "Search tracks..."
                        }
                    },
                    "uld": {
                        "eul": "Enter Url",
                        "atl": "Add This Link",
                        "csc": "Code School Ruby Course",
                        "wgc": "www.google.com",
                        "caj": "Code Academy Javascript Course",
                        "wrc": "ww.reddit.com",
                        "ok": "OK",
                        "cnl": "Cancel",
                        "phl": {
                            "ewu": "Enter the website url you want to add..."
                        }
                    }
                },
                "ptl": {
                    "gtk": {
                        "fol": "Folders:",
                        "exp": "Expand",
                        "col": "Collapse",
                        "acn": "Actions",
                        "amb": "Add Member",
                        "rmb": "Remove Member",
                        "etk": "Edit Track",
                        "dtk": "Delete Track",
                        "pot": "Pop Out",
                        "rst": "Restore",
                        "crd": "Click on a member below, then 'remove' to separate their track from<br />the group or 'delete' to delete the their track altogether.",
                        "dag": "This will delete all tracks assigned and delete this group track.",
                        "ydl": "Yes, Delete!",
                        "rtt": "Restore this track?",
                        "yrs": "Yes, Restore",
                        "asg": "Assigner",
                        "asd": "Assigned"
                    },
                    "stk": {
                        "arq": "Approval Required.",
                        "vta": "View To Approve",
                        "fld": "Folders:",
                        "onr": "Owner",
                        "asn": "Assigner",
                        "col": "Collaborator",
                        "etk": "Edit Track",
                        "dtk": "Delete Track",
                        "dlg": "Delegate",
                        "rst": "Restore",
                        "dtt": "Delete this track?",
                        "rtt": "Restore this track?",
                        "yrs": "Yes, Restore",
                        "cos": "Collaborators"
                    },
                    "tpr": {
                        "mos": "No milestone or objective selected",
                        "swm": "Show More",
                        "ncm": " Note on completing this milestone",
                        "tgt": "Target",
                        "pgr": "Progress",
                        "pco": "Percentage Complete",
                        "asg": "Assignment",
                        "fdr": "Folders",
                        "coa": "Collaborators/Approver",
                        "lnk": "Links",
                        "hgi": "HighGround, Inc.",
                        "alg": "Alignment",
                        "stf": "Send track completion as a recognition into the feed",
                        "cmt": "COMMENTS",
                        "coh": "COACHING",
                        "ntm": "Notify track members via email",
                        "cmm": "Comment",
                        "ips": "Include in Performance Summary",
                        "ant": "Add Note",
                        "dwm": "I am done with this milestone",
                        "opt": "Options",
                        "phl": {
                            "ent": "Enter notes..."
                        },
                        "tip": {
                            "nrd": "Notes are required if declining objective or milestone."
                        },
                        "dtd": "__DetailsType__ Detail",
                        "cpd": "completed"
                    }
                },
                "asn": {
                    "twm": "To Whom",
                    "cnt": "+ Create New Track",
                    "pas": "Preview Assignment",
                    "nrs": "No Recipient selected",
                    "rsl": "Recipient(s) Selected",
                    "tsl": "Team(s) Selected",
                    "phl": {
                        "frt": "Find Recipients..."
                    },
                    "ttl": {
                        "nar": "Notes are required"
                    },
                    "tdc": "__team.Description__",
                    "vum": "View __userMode__"
                },
                "esy": {
                    "obj": "Objective",
                    "chn": "(change)",
                    "tte": "Track Title",
                    "wst": "Who Can See This?",
                    "slv": "-- Select Level --",
                    "cvl": "Credit value",
                    "rcp": "Requires completion in linear progression",
                    "pvl": "Point value",
                    "rac": "Requires approval after completion",
                    "dml": "Delete the milestone?",
                    "mit": "Milestone Title",
                    "idd": "Is there a Due Date?",
                    "mnt": "Does this Milestone have a numeric target?",
                    "ams": "+ Add Milestone",
                    "prv": "Preview",
                    "tca": "Track currently assigned to :",
                    "nrs": "No recipient selected",
                    "imt": "Include this manager on this track",
                    "mns": "Your manager has not yet been selected",
                    "rug": "Remind assignee to update goals:",
                    "nvr": "Never",
                    "wkl": "Weekly",
                    "mtl": "Monthly",
                    "qtl": "Quarterly",
                    "att": "Assign Track To",
                    "msf": "Myself",
                    "mem": "Members",
                    "tem": "Teams",
                    "wms": "Weight Milestones",
                    "eql": "Equally",
                    "ctm": "Custom",
                    "twe": "Total weight must equal 100%",
                    "atk": "Assign Track",
                    "ctk": "Create Track",
                    "stl": "Save to Library",
                    "phl": {
                        "otl": "Objective's title...",
                        "tde": "Type description...",
                        "mtl": "Milestone's title...",
                        "sdd": "Set a due date...",
                        "evl": "Enter value..",
                        "ewp": "Enter Weighted Percentage"
                    },
                    "tip": {
                        "ttr": "Track Title is required.",
                        "str": "Who Can See This is required.",
                        "mtr": "Milestone title is required.",
                        "nmt": "Please enter a number as Milestone Target.",
                        "awr": "An assigned weight is required."
                    },
                    "ttl": {
                        "trt": "Team is required when Access Level is 'Team'",
                        "nrq": "Notes required"
                    },
                    "trk": "Track",
                    "dsc": "Description",
                    "mst": "Milestone",
                    "opt": "Options",
                    "utl": "Untitled",
                    "rsl": "recipient(s) selected",
                    "tsl": "team(s) selected",
                    "csl": "Collaborator(s) Selected",
                    "smg": "Select manager",
                    "sem": "Save __editMode__",
                    "col": "Collaborators",
                    "cst": "- Choose Team -"
                },
                "edt": {
                    "dtt": "Delete this track template?"
                },
                "mat": {
                    "etk": "Edit Tracks",
                    "atk": "Assign Tracks"
                },
                "trk": {
                    "wtr": "Which of __totalTrackCount__ Track(s)?",
                    "gtr": "Go to My Tracks",
                    "fbf": "Filter by Folder",
                    "ion": "I Own",
                    "ias": "I Assigned",
                    "ico": "I Collaborate",
                    "emb": "Edit Members",
                    "gtk": "Group Tracks",
                    "ftr": "Filter Track",
                    "grp": "Group",
                    "bfl": "By Folder",
                    "ftk": "Follow Tracks",
                    "phl": {
                        "stb": "Search for a track or person by name..."
                    }
                }
            },
            "admin": {
                "org": "Organization",
                "inv": "Individual",
                "9bx": "9 Box",
                "rab": "Rating Bias",
                "led": "Leaderboard",
                "ulb": "User Leaderboard",
                "dpl": "Department Leaderboard",
                "crl": "Credit Limits",
                "trl": "Transfer Limits",
                "mia": "Minimum Transfer Amount",
                "maa": "Maximum Transfer Amount",
                "dta": "Default Transfer Amount",
                "rcm": "Recognition Limits",
                "mca": "Minimum Credit Amount",
                "mxa": "Maximum Credit Amount",
                "spl": "Spending Limits",
                "msa": "Minimum Spend Amount",
                "msx": "Maximum Spend Amount",
                "scl": "Save Credit Limits",
                "tol": {
                    "mca": "The number should be between 10 and 50,000, not exceeding Maximum Credit Amount",
                    "mia": "The number should be between 10 and 50,000, not exceeding Maximum Transfer Amount",
                    "maa": "The number should be between 10 and 50,000",
                    "dta": "The number should be between Minimum Transfer Amount and Maximum Transfer Amount",
                    "msa": "The number should be between 10 and 50,000, not exceeding Maximum Spend Amount",
                    "msx": "Please type in only numbers"
                },
                "plc": {
                    "mia": "Greater than or equal to 10 credits",
                    "maa": "Less than or equal to 50,000 credits",
                    "dta": "must be between the min and max transfer amounts entered above",
                    "msa": "Greater than or equal to 100 credits",
                    "msx": "Leave blank for unlimited"
                },
                "dsb": "Admin Dashboard",
                "dia": {
                    "car": {
                        "sel": {
                            "sela": "Select A Card",
                            "sel": "Select a card",
                            "fin": "Find your card...",
                            "noc": "No Card Description"
                        }
                    },
                    "for": {
                        "bef": {
                            "rem": {
                                "not": "Notes",
                                "rem": "Remind with Notes",
                                "remw": "Remind without Notes"
                            },
                            "uns": {
                                "ple": "Please explain why this review is being unsubmitted...",
                                "not": "Notes to __params.name__",
                                "unw": "Unsubmit with Notes",
                                "unwn": "Unsubmit without Notes"
                            }
                        }
                    },
                    "que": {
                        "sel": {
                            "que": "Question Library",
                            "sea": "Search",
                            "seak": "Search keywords in Question library",
                            "the": "There are no questions for this answer type.",
                            "sel": "Select category",
                            "for": "for"
                        }
                    }
                },
                "onb": "On-Board",
                "ofb": "Off-Board",
                "emb": "Edit Member",
                "exm": "Export Members",
                "emi": "Edit Member Info",
                "cga": "Change Avatar",
                "avt": "Avatar",
                "rwe": "Re-send Welcome Email",
                "cne": "Change Notification Email",
                "ptn": "Position",
                "sdt": "Starting Date",
                "epi": "Employee Id",
                "plh": {
                    "1st": "First Name...",
                    "lst": "Last Name...",
                    "ful": "Full Name...",
                    "unm": "UserName...",
                    "ptn": "Position...",
                    "dpt": "Department Name...",
                    "epi": "Employee Id...",
                    "eml": "Email Address..."
                },
                "tlh": {
                    "1st": "First Name is required",
                    "max": "Maximum number of characters is 30",
                    "lst": "Last Name is required",
                    "ful": "Full Name is required",
                    "m65": "Maximum number of characters is 65",
                    "u6l": "Username should be at least 6 characters long",
                    "alw": "Username only allows alphanumeric characters, @ and . symbols for email, spaces between characters are not allowed.",
                    "crl": "Changes require log-out. Continue?",
                    "scy": "Save changes. Yes?"
                },
                "iof": "Include Off-Boarded Members",
                "prv": "Preview",
                "ofd": "Off Board Date",
                "obt": "Off-Board Type",
                "vol": "Voluntary",
                "ivo": "In-Voluntary",
                "cra": "Credits Administrator",
                "cof": "This Credits Administrator will receive all Transfer credits from the selected off-boarded member.",
                "obr": "Are you sure you want to off board this member?",
                "bom": "Off-Board Member",
                "pco": {
                    "tnm": "Enter a name..."
                },
                "tte": {
                    "otr": "Offboard Type is required"
                },
                "pif": "Personal Information",
                "lem": "Last Employee Id:",
                "eyi": "Employee Id (do not use SSN)",
                "bir": {
                    "mon": "Birthday - Month",
                    "day": "Birthday - Day"
                },
                "zip": {
                    "hom": "Home Zip Code",
                    "wrk": "Work Zip Code",
                    "dep": "Team/Department",
                    "tit": "Position/Title",
                    "npw": "Verify New Password",
                    "seo": "Send Welcome Email After Onboarding",
                    "swd": "Send Welcome Email Date",
                    "som": "Save and Onboard This Member",
                    "onm": "Are you sure you want to onboard this member?",
                    "rhg": "Re-instate a HighGround User",
                    "map": "Members Pending Admin Approval",
                    "apr": "Approve",
                    "rbm": "Recently On-boarded Members"
                },
                "pch": {
                    "sdt": "Start Date...",
                    "tdp": "Team/Department...",
                    "tit": "Position/Title...",
                    "eps": "Enter password...",
                    "rpw": "Repeat password...",
                    "lei": "Last Employee Id:__template.LastEmployeeId__"
                },
                "tet": {
                    "sdr": "Start Date is required",
                    "bmr": "Birth Month required",
                    "bdr": "Birth Date is required",
                    "hzc": "Home Zip Code",
                    "hzw": "Home Zip Code in wrong format",
                    "wzc": "Work Zip Code in wrong format",
                    "tit": "Position/Title is required",
                    "psr": "Password is required",
                    "pw6": "Password should be at least 6 characters long",
                    "ypm": "Your passwords don't match",
                    "wed": "Send Welcome Email Date is required"
                },
                "olm": "Old Manager",
                "mtm": {
                    "ofb": "Off-Board Manager",
                    "nwm": "New Manager",
                    "trc": "Tracks",
                    "pon": "Points",
                    "sur": "Are you sure you want to transfer Manager?",
                    "plc": "Type in old Manager name here",
                    "tnm": "Type in new Manager name here",
                    "itt": "Items To Transfer to __request.NewManager.FullName__"
                },
                "qtt": {
                    "mcg": "New manager gets the old manager's credits to give",
                    "mrt": "New manager replaces old manager as approver on any open tracks",
                    "mmm": "New manager takes the place of old manager in the 'manager' role of open reviews",
                    "nog": "New manager gets the old manager's points to give",
                    "ndr": "New manager becomes the manager of the old manager's direct reports"
                },
                "mdb": {
                    "mbr": "You need a modern browser to view this page. Please use Chrome, Safari, Firefox, or IE 9 and above. Thank you!",
                    "tpm": "Please select a Time Period to view the metrics for the duration.",
                    "tpr": "Time Period:",
                    "l07": "Last 7",
                    "l30": "Last 30",
                    "l90": "Last 90",
                    "grp": "Group:",
                    "sgr": "Select Groups",
                    "slp": "Since Last Period",
                    "aur": "Active Users:",
                    "rec": "Recognitions:",
                    "lks": "Likes:",
                    "com": "Comments:",
                    "dat": "Department Activity TreeMap",
                    "rdc": "Rectangles are sized based on the number of users in the Department. Color shows department activity or inactivity for the selected duration.",
                    "fip": "15%",
                    "thp": "30%",
                    "ffp": "45%",
                    "sxp": "60%",
                    "sfp": "75%",
                    "rct": "Recognition Category",
                    "erc": " Everyday Recognitions",
                    "vrc": " Value Recognitions",
                    "arc": "Achievement Recognitions"
                },
                "mdt": {
                    "dmt": "Department Metrics",
                    "sfc": "Search for a Company",
                    "tur": "Total Users",
                    "tgn": "Total Given",
                    "gpu": "Given Per User",
                    "cre": "Created",
                    "opn": "Open",
                    "arc": "Archived",
                    "gpe": "Given Per Employee",
                    "pco": "Percent Coached",
                    "pur": "% Users Reviewed",
                    "rus": "Reviews/User"
                },
                "pla": {
                    "tcn": "Type in Company Name"
                },
                "mmg": {
                    "mmt": "Manager Metrics",
                    "sfc": "Search for a Company",
                    "sdt": "Start Date",
                    "edt": "End date",
                    "exe": "Export to Excel",
                    "rec": "Recognition",
                    "gol": "Goals",
                    "coc": "Coaching",
                    "per": "Perform",
                    "mnm": "Manager Name",
                    "dir": "Direct Reports",
                    "tog": "Total Given",
                    "gpu": "Given Per User",
                    "crd": "Created",
                    "opn": "Open",
                    "arc": "Archived",
                    "tgi": "Total Given",
                    "gpe": "Given Per Employee",
                    "pec": "Percent Coached",
                    "usr": "% Users Reviewed",
                    "rev": "Reviews/User"
                },
                "mts": {
                    "enm": "Employee Name",
                    "mnm": "Manager Name",
                    "gnm": "Goal Name",
                    "lud": "Last Updated",
                    "ufr": "Update Frequency",
                    "cur": "Current",
                    "pcm": "Percent Completed"
                },
                "mup": {
                    "cyn": "Cycle Name:",
                    "ctl": "Card Title:",
                    "dsb": "Date Submitted:",
                    "cls": "Close"
                },
                "meu": {
                    "usm": "Users Metrics",
                    "wcm": "Which Company?",
                    "mng": "Managers",
                    "men": "Member Name",
                    "dsl": "Days Since Last Login",
                    "tog": "Total Given",
                    "trc": "Total Received",
                    "asg": "Assigned To",
                    "ipr": "In Progress",
                    "arc": "Archived",
                    "trd": "Total Recv'd",
                    "tir": "Times Reviewed",
                    "rsb": "Reviews Submitted",
                    "pro": "In Progress",
                    "dsr": "Days Since Last Review",
                    "plc": {
                        "tdn": "Type Department Name",
                        "tmn": "Type Manager Name"
                    }
                },
                "ofs": {
                    "smr": "Select Member to Re-Instate",
                    "grp": "Groups",
                    "egp": "External-Groups",
                    "spl": "Search People (use email)",
                    "fnd": "Find",
                    "nmf": "No Member Found",
                    "sin": "Send Invitation:",
                    "rim": "Re-Instate Member",
                    "frc": "Find recipients..."
                },
                "par": {
                    "cre": {
                        "for": {
                            "ques": "Question",
                            "whoa": "Who answers this question? ",
                            "hel": "Help Text",
                            "ans": "Answer Type",
                            "typ": "Type number or alphabet in the fields below.",
                            "inc": "Include Not Applicable Answer Option",
                            "adda": "Add Another",
                            "all": "Allow comments",
                            "req": "Required",
                            "opt": "Optional",
                            "hid": "Hide question and answer from reviewee",
                            "unt": "Untitled Question ...",
                            "help": "Helper Text Here ...",
                            "quel": "Question Library",
                            "queti": "Question title required",
                            "cho": "Choose from the types of recognition below to display. Only recognitions earned by the reviewee during the review cycle's performance period will be displayed. Performance periods are determined when delivering a review cycle.",
                            "atl": "At least one recognition category is required",
                            "quety": "Question type required",
                            "ent": "Enter text to describe this value...",
                            "entc": "Enter a custom role here",
                            "ple": "Please select at least one person type",
                            "the": "The 5-point scale forces a sharper focus than is possible with the popular 1-to-10 scale. Depending on what is being rated, take the time to assign appropriate words to each number or letter. <br /><br />For example:<br /><strong>1</strong> = Poor, <strong>2</strong> = Fair, <strong>3</strong> = Good, <strong>4</strong> = Very Good, <strong>5</strong> = Excellent",
                            "opts": "Option __selector.Value__ ."
                        },
                        "que": {
                            "too": {
                                "dra": "Drag to Reorder",
                                "dup": "Duplicate",
                                "edi": "Edit"
                            }
                        }
                    },
                    "per": {
                        "car": {
                            "are": {
                                "tab": {
                                    "lib": "Library",
                                    "cyc": "Cycles"
                                }
                            }
                        }
                    },
                    "que": {
                        "pre": {
                            "typ": "Type in your question...",
                            "que": "Question Title",
                            "lon": "Long answer",
                            "sho": "Short answer",
                            "rat": "Rating scale",
                            "tra": "Track container",
                            "rec": "Recognitions",
                            "selo": "Select one answer",
                            "selm": "Select one or more answer",
                            "seld": "Select one answer from a dropdown",
                            "who": "Who answers this question?",
                            "sel": "--Select--",
                            "rst": "Reviewee selects track here",
                            "revr": "Reviewee sees recognitions here",
                            "rad": "&nbsp;&nbsp;Radio button",
                            "che": "&nbsp;&nbsp;Check box",
                            "rpt": "Reviewee will place track here",
                            "rsr": "Reviewee will see recognitions here",
                            "rech": "Reviewee will enter a comment here",
                            "one": "1",
                            "two": "2",
                            "thr": "3",
                            "fou": "4",
                            "fiv": "5",
                            "unt": "Untitled Question  ..."
                        }
                    },
                    "sec": {
                        "hea": {
                            "inp": {
                                "sect": "Section Title",
                                "secd": "Section Description",
                                "unt": "Untitled Section",
                                "des": "Description of the section..."
                            },
                            "pre": {
                                "unt": "Untitled Section"
                            }
                        }
                    }
                },
                "pca": {
                    "crc": "Create A Review Cycle",
                    "1cn": "1. Cycle Name",
                    "2pe": "2. Period Under Evaluation",
                    "edt": "Enter Date",
                    "tmg": "3. Timing",
                    "dfq": "Delivery Frequency",
                    "otm": "One Time",
                    "oey": "Once every ",
                    "vor": "Can view other's responses",
                    "dmd": "Delivery Method",
                    "dat": "Date",
                    "ddt": "Delivery date",
                    "dud": "Due date",
                    "ddu": "Days due",
                    "rej": "Rejection",
                    "crj": "Can reject",
                    "rdt": "Release date",
                    "rev": "4. Reviews ",
                    "acr": "Add Card",
                    "rvw": "Review",
                    "rwe": "Reviewee",
                    "ann": "Anonymous",
                    "amr": "Add More Reviews",
                    "rcp": "Review Cards/Confirmation Page",
                    "fbd": "Filter By Department",
                    "rws": "Reviewee(s)",
                    "man": "Manager <em class='muted'>Click on a manager's name to modify. Changes only apply to this review.</em>",
                    "sam": "Select a Manager",
                    "not": "Notes <em class='muted'>(optional)</em>",
                    "dcr": "Deliver Cards"
                },
                "phr": {
                    "gct": "Give this cycle a title ...",
                    "dlv": "Delivery Date",
                    "ddt": "Due Date",
                    "did": "Due In Days",
                    "tak": "Type any keyword, i.e. 'Billy', 'Bobby', 'Mary', 'Ahmet', etc.",
                    "war": "Warning: The Delivery Date is before the Period Under Evaluation end date",
                    "wsd": "Warning: The Delivery Date is before the Period Under Evaluation start date",
                    "wud": "Warning: The Due Date is before the Period Under Review end date"
                },
                "fsr": "Fully submitted reviews will be available to view by the reviewee and reviewee's manager once the release date has passed.",
                "sar": "Select a reviewee",
                "per": {
                    "car": {
                        "cre": {
                            "cre": "Create Card Type:&nbsp;&nbsp;",
                            "pre": "Preview Only",
                            "car": "Card Description",
                            "sho": "Short Answer",
                            "par": "Paragraph Answer",
                            "rat": "Rating Scale",
                            "mul": "Multiple Choice",
                            "che": "Checkbox",
                            "rec": "Recognition Discussion",
                            "tra": "Track Discussion",
                            "cho": "Choose from List",
                            "sav": "Save Card As a Draft",
                            "sac": "Save Card To Library",
                            "ads": "Add Section",
                            "adq": "Add Question",
                            "cat": "Card Title ",
                            "ctr": "Card title required",
                            "des": "Description of the card..."
                        }
                    },
                    "dra": "Drafts",
                    "ser": "Search Card",
                    "new": "+ New Card",
                    "tem": "Template",
                    "del": "Deliver This Card",
                    "ege": "e.g. Employee Performance Review",
                    "cli": "Click to edit this card.",
                    "nod": "No Card Description",
                    "cyc": {
                        "add": {
                            "rev": {
                                "cyc": "Cycle: __Cycle.Title__",
                                "eva": "Evaluation Period:",
                                "rew": "Review(s) will be delivered today",
                                "del": "Delivery Method:",
                                "ded": "Delivery date:",
                                "dud": "Due date:",
                                "dad": "Days due:",
                                "review": "Reviewee",
                                "ano": "Anonymous",
                                "add": "Add More Reviews",
                                "ple": "Please add at least one reviewee",
                                "adr": "Add Reviewee",
                                "rec": "Review Cards/Confirmation Page",
                                "fil": "Filter By Department",
                                "reviewee": "Reviewee(s)",
                                "cli": " Click on a manager's name to modify. Changes only apply to this review.",
                                "sel": "Select a Manager",
                                "delc": "Deliver Cards",
                                "reviews": "Reviews",
                                "tim": "Timing",
                                "ser": "Select a reviewee",
                                "nod": "No Card Description",
                                "typ": "Type any keyword, i.e. 'Billy', 'Bobby', 'Mary', etc.",
                                "rev": "Review",
                                "adtr": "Add/Delete Reviewer(s)",
                                "upc": "Update Cycle"
                            }
                        }
                    },
                    "myc": {
                        "cyc": {
                            "del": {
                                "del": "DELIVERED PLACEHOLDER"
                            },
                            "det": {
                                "nor": "No reviews in this cycle",
                                "cyc": "Cycle:",
                                "eva": "Evaluation Period ",
                                "del": "Delivery Date",
                                "rew": "(Reviewee): ",
                                "nex": "Next Delivery Date: ",
                                "rec": "Recurrence: ",
                                "cat": "Categorize this cycle:",
                                "rel": "Release Date:",
                                "not": "Not Started",
                                "inp": "In Progress",
                                "sub": "Submitted",
                                "ove": "Overall Completion",
                                "rev": "Reviewee:",
                                "due": "Due Date",
                                "man": "Manager",
                                "mee": "Meeting Date",
                                "rem": "Reminded",
                                "uns": "Unsubmit",
                                "remi": "Remind",
                                "bac": " &larr; Back to Cycles",
                                "add": "Add Reviewee",
                                "remin": "Remind All",
                                "dup": "Duplicate",
                                "dela": "Delete All",
                                "clo": "Close All",
                                "exp": "Export Cycle Content",
                                "sto": "Stop Recurrence",
                                "sus": "Suspend Next Round",
                                "subj": "Subject of review",
                                "revw": "Reviewer(s)",
                                "remind": "Reminded",
                                "mana": "(Manager)",
                                "dea": "Delete all reviews in this cycle",
                                "cla": "Close all reviews in this cycle",
                                "adr": "Add Reviewee",
                                "day": " day(s) after ",
                                "sum": " submits",
                                "reww": "Reviewee",
                                "red": "Release Date",
                                "vie": "View this review",
                                "clr": "close this review",
                                "der": "delete this review",
                                "ret": "__review.totalReviewers__ Reviewer(s)",
                                "nos": " Not Started, ",
                                "com": " Completed)",
                                "ano": "Anonymous",
                                "key": "<strong>(__review.customNotStarted__</strong> Not Started, <strong>__review.customInProgress__</strong> In Progress, <strong>__review.customCompleted__</strong> Complete",
                                "moa": "More Actions",
                                "aodr": "Add/Delete Reviewer"
                            },
                            "sea": "Search for a Cycle",
                            "the": "There are no cycles.",
                            "per": "Period Under Evaluation:",
                            "car": "Card(s):",
                            "fin": "Enter a cycle name",
                            "sel": "Select folder",
                            "pen": "Pending",
                            "inp": "In Progress",
                            "com": "Completed",
                            "nos": "__Summary.PendingCycles__  Not Started",
                            "inr": "__Summary.InProgressReviews__ In Progress",
                            "cop": "__Summary.CompletedReviews__ Completed",
                            "fil": "Filter By",
                            "tim": "Date Created",
                            "ent": "Enter Date Range",
                            "sad": "Start Date",
                            "end": "End date",
                            "ses": "Select Status",
                            "cad": "Card Type",
                            "sec": "Select Card Type",
                            "key": "Keyword",
                            "fik": "Filter by Keyword",
                            "thr": " through ",
                            "col": "% completed"
                        }
                    }
                },
                "poi": {
                    "are": {
                        "tab": {
                            "eco": "Economy",
                            "pro": "Products",
                            "ord": "Orders",
                            "tra": "Transactions"
                        }
                    },
                    "eco": {
                        "poi": "Points To Give",
                        "poin": "Points In Inventory",
                        "pos": "Points To Spend",
                        "min": "Mint Points",
                        "use": "User",
                        "rol": "Role",
                        "iss": "Issue Points",
                        "issu": "Issue __member.valid__",
                        "pre": " Prev",
                        "nex": "Next "
                    },
                    "ord": {
                        "whi": "Which Order",
                        "fil": "Filter By Status",
                        "sea": "Search orders..."
                    },
                    "pro": {
                        "whi": "Which Product",
                        "add": "+ Add a Product",
                        "ins": "in stock",
                        "edi": "Edit Product Item",
                        "prn": "Product Name (Limit to 65 characters)",
                        "des": "Description (optional)",
                        "cli": "Click to Upload",
                        "ple": "Please upload a product image.",
                        "pri": "Price (in points)",
                        "qua": "Quantity Available",
                        "exp": "Expires (optional)",
                        "red": "Redemption Instructions (optional)",
                        "act": "Active",
                        "dra": "Draft",
                        "ima": "Image",
                        "sea": "Search for a product...",
                        "pro": "Product Name is required",
                        "prc": "Price is required",
                        "qut": "Quantity is required"
                    }
                },
                "pop": {
                    "rem": {
                        "rem": "Remind",
                        "remd": "Reminded"
                    }
                },
                "rec": {
                    "ach": {
                        "new": "+ New Achievement",
                        "lev": "levels",
                        "ach": "Achievement Title (Limit to 65 characters)",
                        "des": "Description (optional)",
                        "sel": "Select an icon and a border",
                        "len": "Level Name",
                        "add": "Add more",
                        "cho": "Choose an icon",
                        "lnr": "Level name required",
                        "lvl": "Levels"
                    },
                    "are": {
                        "tab": {
                            "eve": "Everyday",
                            "val": "Value",
                            "ach": "Achievement"
                        }
                    },
                    "eve": {
                        "new": "+ New Everyday",
                        "rec": "Recognition Title (Limit to 65 characters)",
                        "des": "Description (optional)",
                        "sel": "Select an icon and a border",
                        "ree": "Recognition Exposed to",
                        "int": "Internal",
                        "ext": "External",
                        "bot": "Both",
                        "chi": "Choose an icon"
                    },
                    "val": {
                        "new": "+ New Value",
                        "set": "Settings",
                        "rec": "Recognition Title (Limit to 65 characters)",
                        "des": "Description (optional)",
                        "sub": "Sub Values",
                        "sel": "Select an icon that represent the value",
                        "val": "Sub-Value",
                        "til": "Sub Value Title",
                        "add": "+ Add Sub Value",
                        "giv": "Give the recognition a title",
                        "cho": "Choose a badge image",
                        "unt": "Untitled"
                    }
                },
                "rep": {
                    "are": {
                        "tab": {
                            "rep": "Report",
                            "dep": "Department",
                            "man": "Manager",
                            "use": "User",
                            "cur": "Current Goals"
                        }
                    },
                    "eng": "Engagement Report",
                    "rep": "Reports",
                    "cho": "Choose Report",
                    "dat": "Date Range",
                    "fro": "From Date",
                    "tod": "To Date",
                    "gen": "Generate Report",
                    "ana": "Analytics",
                    "gene": "Generate Reports"
                },
                "rul": {
                    "new": "+ New Rule",
                    "rul": "Rule name (Limit to 65 characters)",
                    "des": "Description (optional)",
                    "sel": "Select the event type",
                    "sele": "-- Select event type --",
                    "set": "Select Timing Type",
                    "imm": "Immediate",
                    "bef": "Before Reset",
                    "add": "+ Add",
                    "min": "Minimum",
                    "max": "Maximum",
                    "ach": "Select an achievement template to give",
                    "del": "Delta type",
                    "sed": "-- Select Delta type --",
                    "dev": "Delta value",
                    "devl": "-- Select Delta value --",
                    "res": "Reset interval",
                    "sei": "-- Select interval --",
                    "all": "Allowed interval",
                    "std": "Start Date",
                    "cho": "Choose an achievement template"
                },
                "set": {
                    "are": {
                        "tab": {
                            "gen": "General",
                            "bad": "Badge Defaults",
                            "new": "News"
                        }
                    },
                    "bad": {
                        "def": {
                            "tra": "Track Default Badges",
                            "obj": "Objective",
                            "mil": "Milestone",
                            "sys": "System Default Badges",
                            "sav": "Save Settings",
                            "sel": "Select an icon and/or a background for each system default badge type. To save your changes, click on <strong>Save Settings</strong> button above.",
                            "sei": "Select Icon and Background",
                            "til": "Title",
                            "mes": "Message",
                            "meg": "Message here...",
                            "cli": "Click to change objective badge",
                            "clm": "Click to change milestone badge",
                            "clb": "Click to change badge icon",
                            "chb": "Click to change badge icon background"
                        }
                    },
                    "new": {
                        "cre": "Create New",
                        "new": "News Editor ",
                        "net": "News Title",
                        "ned": "News Description",
                        "sav": "Save for now",
                        "pub": "Publish",
                        "sen": "Send news as emailed newsletter to all active members",
                        "send": "Send the news to the News Feed",
                        "pin": "Pin news to top of feed",
                        "rec": "Recently Saved News",
                        "req": "News Title Required",
                        "typ": "Type your description...",
                        "nwb": "News Body Required"
                    },
                    "cre": "Credits Administrator",
                    "the": "The Credits Administrator account will receive all transfer credits from an off-boarded member and is able to revoke/reissue credits. ",
                    "cli": "Click on the avatar to update.",
                    "poi": "Points Administrator",
                    "poa": "The Points Administrator will handle all points economy functions as well as order fulfillment. ",
                    "yai": "Yammer Integration",
                    "use": "User: ",
                    "ema": "Email: ",
                    "net": "Network: ",
                    "yam": "This user is not a Yammer verified admin. Yammer integration will not work.",
                    "ple": "Please log out of Yammer and try authenticating again with a verified admin account.",
                    "int": "Integrate Your Yammer Network",
                    "cly": "Click the button to authorize HighGround to post to Yammer on your behalf. This must be done with a Yammer account with admin privileges."
                },
                "val": {
                    "rec": {
                        "lev": {
                            "ena": "Enable Levels",
                            "bac": "Back to Value",
                            "poi": "Points to give",
                            "cre": "Credits to give",
                            "lim": "Limit to give per",
                            "limi": "Limit number to give",
                            "cho": "Choose a Level image"
                        }
                    }
                }
            },
            "dialogs": {
                "bad": {
                    "ima": {
                        "sel": {
                            "typ": "Type any keyword, i.e. 'wellness', 'red', 'good job', etc.",
                            "fil": "Filter by Category"
                        }
                    },
                    "sel": {
                        "sea": "abc Search Keyword",
                        "typ": "Type any keyword, i.e. 'wellness', 'red', 'good job', etc.",
                        "fil": "Filter by Category",
                        "ok": "OK",
                        "can": "Cancel"
                    }
                },
                "rec": {
                    "rec": {
                        "you": "You have received a recognition from",
                        "cli": "Click anywhere to dismiss."
                    }
                },
                "use": {
                    "sel": {
                        "sea": "Search Name or Keyword",
                        "typ": "Type any keyword, i.e. 'Billy', 'Bobby', 'Mary', etc.",
                        "fil": "Filter by Department"
                    }
                }
            },
            "user": {
                "acb": {
                    "bpc": "Backpack page content here."
                },
                "api": {
                    "fnf": "Friendly Name For this account",
                    "bnm": "Bank Name",
                    "noa": "Name on Account",
                    "brn": "Bank Routing Number",
                    "ban": "Bank Account Number",
                    "plh": {
                        "sob": "Someone's Bank"
                    },
                    "dyn": {
                        "ap1": "__card.FriendlyName__",
                        "ap2": "__card.actionCaption__"
                    }
                },
                "aup": {
                    "uav": "Upload User Avatar",
                    "pim": "Upload Product Image",
                    "tav": "Upload Team Avatar",
                    "sif": "Supported image format",
                    "jjp": "jpg, jpeg, png, bmp",
                    "fsz": "File size",
                    "3mb": "&#8804; 3MB",
                    "cic": "Crop image by click and dragging over the avatar."
                },
                "crp": {
                    "dyn": {
                        "btn": "__actionButtonCaption__"
                    }
                },
                "dlg": {
                    "ato": {
                        "dyn": {
                            "itm": "__item__"
                        }
                    },
                    "dtm": {
                        "dyn": {
                            "tmn": "Are you sure you want to delete the team '__teamName__'?"
                        }
                    }
                },
                "ntf": {
                    "dyn": {
                        "ifn": "__item.issuerFillName__",
                        "eti": "__item.entityTitle__",
                        "iae": "__item.issuerFillName__ &#150; __item.entityTitle__",
                        "isn": "__item.issuerFillName__! &#150; __item.notes__",
                        "bdy": " __item.issuerFillName__'s birthday!",
                        "ani": "is __item.issuerFillName__'s anniversary!"
                    }
                },
                "pra": {
                    "apc": "Activities Preferences content here."
                },
                "prf": {
                    "fpc": "Food Preferences content here.",
                    "fcb": "Facebook"
                },
                "ted": {
                    "dyn": {
                        "unm": "__user.GroupDepartmentName__",
                        "tnm": "__team.Name__"
                    },
                    "tit": "Title"
                },
                "tms": {
                    "dyn": {
                        "nam": "__team.Name__",
                        "des": "__team.Description__",
                        "snm": "__selectedTeam.Name__",
                        "dsc": "__selectedTeam.Description__",
                        "tnm": "__t.TeamName__"
                    }
                }
            },
            "shared": {
                "cfp": {
                    "cmg": "CONFMSG"
                },
                "lgn": {
                    "hit": "Hi there,",
                    "ehg": "Welcome back to HighGround.",
                    "rmp": "Reset my password",
                    "bex": "For a better experience install<br>Google Chrome Frame",
                    "usr": "Username/Email",
                    "fpw": "Forgot Password?",
                    "orr": "or"
                },
                "phd": {
                    "ppt": "Provisioning Portal"
                },
                "pbf": {
                    "hge": "&copy 2013 HighGround Enterprise Solutions, Inc."
                },
                "pub": {
                    "top": {
                        "hea": {
                            "con": "Contact Us"
                        }
                    }
                },
                "rev": {
                    "pdf": {
                        "dow": "Download PDF"
                    }
                },
                "sea": {
                    "dir": {
                        "sel": "Select All",
                        "cle": "Clear All",
                        "ent": "Enter a name or a department name..."
                    }
                }
            }
        }
    }
    return {
        get: get
    };
});