define(function() {
    function getFileConfirmationDetails () {
        return [
            {
                "Id":"559d941f10e1e37afa6cf81c",
                "Type":"OffBoard",
                "Company":"Mercury Industries",
                "GroupId":"3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "Notes":[
                    "1 User(s) will be offboarded.",
                    "Sarah Wallace, sarah@highground.com: Voluntary",
                    "Users Status will be changed from Active to Off-Boarded. They will also be removed from their current respective Teams and Departments."
                    ]
                }
        ]
    }

    return {
        getFileConfirmationDetails: getFileConfirmationDetails
    };
});