define(function(){

    function getCreditMasterMember(){
        return [
            {
                AbbrvName: "Tuan P.",
                ApprovedOrDeniedBy: "5e42c56e-5b17-4070-817f-d924a5cd7462",
                CreatedBy: "",
                CreatedDate: 1365045000698,
                DefaultPaymentProfileId: "",
                EmployeeId: "HG002",
                ExperiencePoint: 5053,
                FirstName: "Tuan",
                FriendlyId: "",
                FullName: "Cu Barnes",
                GravatarEmail: "cu@highground.com",
                GroupDepartmentName: "",
                GroupId: "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                GroupName: "Mercury Industries",
                GroupRoleId: "GroupRegularMemeber",
                InvitedBy: "5e42c56e-5b17-4070-817f-d924a5cd7462",
                LastDailyRecapSentDate: 1421064076029,
                LastName: "Pham-Barnes",
                LastRole: "",
                MembershipStatus: "Active",
                ModifiedBy: "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                ModifiedDate: 1418195935022,
                OffBoardType: "NotApplicable",
                Position: "Director Software Engineering",
                ProgramName: "",
                StartingDate: 729018000000,
                UserId: "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                __v: 1,
                _id: "515cef085965ca02000000a0",
                hgId: "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                id: null
            }
        ];
    }
    function getLanguages() {
        return {
            SupportedLanguages:["en","pt-br"],
            DefaultLanguage:"pt-br",
            AvailableLanguages:[
                {"key":"en","value":"English","Enable":true},
                {"key":"pt-br","value":"Portuguese - Brazil","Enable":true}
            ],
            DisplaySupportedLanguages:[
                {"key":"en","value":"English","Enable":true},
                {"key":"pt-br","value":"Portuguese - Brazil","Enable":true}
            ]
        };
    }
    return {
        getCreditMasterMember: getCreditMasterMember,
        getLanguages: getLanguages
    };
});