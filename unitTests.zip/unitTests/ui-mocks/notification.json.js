define(function(){
    function getSingleNotification() {
        return [
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
                }
        ];
    }
    function getAllNotification() {
        return [
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            },
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[{
                    "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                    "eventName":"GroupAnniversary",
                    "issuerFillName":"Ross Wallace",
                    "subject":"Today is ${name}'s anniversary!"}]
            }
        ];
    }
    function getTopTenNotification() {
        return [
            {
                "createDate":"2014-10-01T05:00:00.000Z",
                "ActionUrl": "#/Track/Iso/cc30d820-0b4c-11e3-84c5-c5accc7da0b6",
                "items":[
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"},
                    {
                        "hgId":"a9605360-102a-11e3-bba0-8d9c8faa9d96",
                        "eventName":"GroupAnniversary",
                        "issuerFillName":"Ross Wallace",
                        "subject":"Today is ${name}'s anniversary!"}
                ]
            }
            ,
           20
        ];
    }
    return {
        getSingleNotification: getSingleNotification,
        getAllNotification : getAllNotification,
        getTopTenNotification : getTopTenNotification
    }
});
