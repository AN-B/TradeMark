define(function(){
  function getCycleSummaryCount() {
      return { "Summary" : {
        PendingCycles : 1,
        InProgressReviews : 5,
        CompletedReviews  : 10
         }
       };
  }
	function getCycles() {
		return {
			"Cycles": [
				{
					"hgId": "51838940-797b-11e3-9619-c579e9bc5bff",
					"Title": "test 1223",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1388556000000,
					"ReviewPeriodEnd": 1388642400000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 1
				},
				{
					"hgId": "489749d0-132c-11e3-bc94-552338a0b1b7",
					"Title": "Test review 4 sections",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1377959911461,
					"ReviewPeriodEnd": 1380344400000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 1
				},
				{
					"hgId": "d6c23730-6415-11e3-91a0-75859541cdd1",
					"Title": "test track",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1385877600000,
					"ReviewPeriodEnd": 1386050400000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 5
				},
				{
					"hgId": "24934950-6415-11e3-91a0-75859541cdd1",
					"Title": "test tracks",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1386914400000,
					"ReviewPeriodEnd": 1387173600000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 8
				},
				{
					"hgId": "7659cf40-3506-11e3-b887-1d1e5cc7b3f5",
					"Title": "jsekjsdikj",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1381771272860,
					"ReviewPeriodEnd": 1381771272860,
					"PercentCompletion": 0,
					"TotalReviewNumber": 1
				},
				{
					"hgId": "b0955ff0-6380-11e3-b1e7-3170d2b42df4",
					"Title": "asassa",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1386828000000,
					"ReviewPeriodEnd": 1386914400000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 8
				},
				{
					"hgId": "f49beaa0-3696-11e3-996a-b15daba7fd71",
					"Title": "assasa",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1381899600000,
					"ReviewPeriodEnd": 1382677200000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 1
				},
				{
					"hgId": "bb6c2ac0-3997-11e3-a30a-8f7c935a2c1e",
					"Title": "test 1223",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1382245200000,
					"ReviewPeriodEnd": 1382331600000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 1
				},
				{
					"hgId": "c5a644f0-56be-11e3-8bf7-5528fc0465ae",
					"Title": "sdsdsdsds",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1385445600000,
					"ReviewPeriodEnd": 1385618400000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 1
				},
				{
					"hgId": "444b1fa0-4d60-11e3-ad17-d904db88d068",
					"Title": "test 1233",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"GroupName": "Mercury",
					"ReviewPeriodStart": 1384408800000,
					"ReviewPeriodEnd": 1384581600000,
					"PercentCompletion": 0,
					"TotalReviewNumber": 1
				}
			],
			"CycleTags": [
				"test1",
				"my tag"
			]
		};
	}
  function getCycleDetail() {
    return {

        "__v": 0,
        "ModifiedDate": 1385152985119,
        "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
        "CreatedDate": 1385152985119,
        "CreatedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
        "hgId": "10660990-53b7-11e3-9946-775ceaf8ea2d",
        "ReviewSummaries": [
          {
            "_id": "52a8bcee8959e79c9900011c",
            "CardId": "2d0e5fc0-32ab-11e3-8fe9-7fbcf85d265e",
            "CardTitle": "Review with PEER",
            "Peoples": [
              {
                "_id": "528fc27b3da14b3e89000053",
                "PeopleType": "Subject",
                "ModifiedDate": 1385153147076,
                "ModifiedBy": "",
                "CreatedDate": 1385153147076,
                "CreatedBy": "",
                "hgId": "",
                "ContainQuestionForMe": false,
                "Anonymous": false,
                "PercentAchieved": 0,
                "StatusInCurrentReview": "NA",
                "SubmitDate": 1385153147076,
                "DueDate": null,
                "DeliveryDate": null,
                "MemberFullname": "Demetri Maltsiniotis",
                "EmployeeId": "HG010",
                "UserId": "3cf54b70-9cd2-11e2-a3a4-25024474fe63",
                "MemberId": "2331a780-9cd5-11e2-a3a4-25024474fe63"
              },
              {
                "_id": "528fc27b3da14b3e89000054",
                "PeopleType": "Peer",
                "ModifiedDate": 1385153147075,
                "ModifiedBy": "",
                "CreatedDate": 1385153147075,
                "CreatedBy": "",
                "hgId": "",
                "ContainQuestionForMe": true,
                "Anonymous": false,
                "PercentAchieved": 0,
                "StatusInCurrentReview": "Overdue",
                "SubmitDate": 1385153147075,
                "DueDate": 1385066918,
                "DeliveryDate": 1385100000000,
                "MemberFullname": "Erin Guenther",
                "EmployeeId": "HG011",
                "UserId": "3cf48820-9cd2-11e2-a3a4-25024474fe63",
                "MemberId": "23315961-9cd5-11e2-a3a4-25024474fe63"
              },
              {
                "_id": "528fc27b3da14b3e89000055",
                "PeopleType": "Peer",
                "ModifiedDate": 1385153147075,
                "ModifiedBy": "",
                "CreatedDate": 1385153147075,
                "CreatedBy": "",
                "hgId": "",
                "ContainQuestionForMe": true,
                "Anonymous": false,
                "PercentAchieved": 0,
                "StatusInCurrentReview": "Overdue",
                "SubmitDate": 1385153147075,
                "DueDate": 1385066918,
                "DeliveryDate": 1385100000000,
                "MemberFullname": "Elaine Benes",
                "EmployeeId": "HG015",
                "UserId": "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160",
                "MemberId": "2de5a650-a0c6-11e2-a665-cf2c2ef6e160"
              },
              {
                "_id": "528fc27b3da14b3e89000056",
                "PeopleType": "Peer",
                "ModifiedDate": 1385153147074,
                "ModifiedBy": "",
                "CreatedDate": 1385153147074,
                "CreatedBy": "",
                "hgId": "",
                "ContainQuestionForMe": true,
                "Anonymous": false,
                "PercentAchieved": 0,
                "StatusInCurrentReview": "NotStarted",
                "SubmitDate": 1385153147074,
                "DueDate": 1385186400000,
                "DeliveryDate": 1385100000000,
                "MemberFullname": "Jerry Seinfeld",
                "EmployeeId": "HG014",
                "UserId": "2d82ece0-a0c6-11e2-a665-cf2c2ef6e160",
                "MemberId": "2de5f470-a0c6-11e2-a665-cf2c2ef6e160"
              },
              {
                "_id": "528fc27b3da14b3e89000057",
                "PeopleType": "Manager",
                "ModifiedDate": 1385153147074,
                "ModifiedBy": "",
                "CreatedDate": 1385153147074,
                "CreatedBy": "",
                "hgId": "",
                "ContainQuestionForMe": true,
                "Anonymous": false,
                "PercentAchieved": 0,
                "StatusInCurrentReview": "NotStarted",
                "SubmitDate": 1385153147074,
                "DueDate": 1385186400000,
                "DeliveryDate": 1385100000000,
                "MemberFullname": "Ganesh Kamble",
                "EmployeeId": "HG019",
                "UserId": "8a418dc0-ee81-11e2-8706-c3b972347dee",
                "MemberId": "8a51ba60-ee81-11e2-8706-c3b972347dee"
              }
            ],
            "StatusByAdminView": "NotStarted",
            "DetectableRolesOnly": false,
            "ReviewId": "106a7660-53b7-11e3-9946-775ceaf8ea2d"
          }
        ],
        "PercentCompletion": 0,
        "SubmittedReviewNumber": 0,
        "InProgressReviewNumber": 0,
        "NotStartedReviewNumber": 1,
        "TotalReviewNumber": 1,
        "PeopleDates": [
          {
            "_id": "528fc27b3da14b3e8900004b",
            "DeliveryDate": 1385100000000,
            "DueDate": 1385186400000,
            "PeopleType": "Manager"
          },
          {
            "_id": "528fc27b3da14b3e8900004a",
            "DeliveryDate": 1385100000000,
            "DueDate": 1385186400000,
            "PeopleType": "Peer"
          }
        ],
        "ReviewPeriodEnd": 1385100000000,
        "ReviewPeriodStart": 1385013600000,
        "GroupName": "Mercury Industries",
        "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
        "Title": "Overdue test",
	  "Tags": ['cycle tag']
    };
  }
  function getClosedReview() {
      return {
          "ReviewId": "106a7660-53b7-11e3-9946-775ceaf8ea2d",
          "Peoples": [
            {
              "_id": "528fc27b3da14b3e89000053",
              "PeopleType": "Subject",
              "ModifiedDate": 1386790194858,
              "ModifiedBy": "",
              "CreatedDate": 1385153147076,
              "CreatedBy": "",
              "hgId": "",
              "ContainQuestionForMe": false,
              "Anonymous": false,
              "PercentAchieved": 0,
              "StatusInCurrentReview": "NA",
              "SubmitDate": 1385153147076,
              "DueDate": null,
              "DeliveryDate": null,
              "MemberFullname": "Demetri Maltsiniotis",
              "EmployeeId": "HG010",
              "UserId": "3cf54b70-9cd2-11e2-a3a4-25024474fe63",
              "MemberId": "2331a780-9cd5-11e2-a3a4-25024474fe63"
            },
            {
              "_id": "528fc27b3da14b3e89000054",
              "PeopleType": "Peer",
              "ModifiedDate": 1386790194859,
              "ModifiedBy": "",
              "CreatedDate": 1385153147075,
              "CreatedBy": "",
              "hgId": "",
              "ContainQuestionForMe": true,
              "Anonymous": false,
              "PercentAchieved": 0,
              "StatusInCurrentReview": "Closed",
              "SubmitDate": 1385153147075,
              "DueDate": 1385066918,
              "DeliveryDate": 1385100000000,
              "MemberFullname": "Erin Guenther",
              "EmployeeId": "HG011",
              "UserId": "3cf48820-9cd2-11e2-a3a4-25024474fe63",
              "MemberId": "23315961-9cd5-11e2-a3a4-25024474fe63"
            },
            {
              "_id": "528fc27b3da14b3e89000055",
              "PeopleType": "Peer",
              "ModifiedDate": 1386790194859,
              "ModifiedBy": "",
              "CreatedDate": 1385153147075,
              "CreatedBy": "",
              "hgId": "",
              "ContainQuestionForMe": true,
              "Anonymous": false,
              "PercentAchieved": 0,
              "StatusInCurrentReview": "Closed",
              "SubmitDate": 1385153147075,
              "DueDate": 1385066918,
              "DeliveryDate": 1385100000000,
              "MemberFullname": "Elaine Benes",
              "EmployeeId": "HG015",
              "UserId": "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160",
              "MemberId": "2de5a650-a0c6-11e2-a665-cf2c2ef6e160"
            },
            {
              "_id": "528fc27b3da14b3e89000056",
              "PeopleType": "Peer",
              "ModifiedDate": 1386790194859,
              "ModifiedBy": "",
              "CreatedDate": 1385153147074,
              "CreatedBy": "",
              "hgId": "",
              "ContainQuestionForMe": true,
              "Anonymous": false,
              "PercentAchieved": 0,
              "StatusInCurrentReview": "Closed",
              "SubmitDate": 1385153147074,
              "DueDate": 1385186400000,
              "DeliveryDate": 1385100000000,
              "MemberFullname": "Jerry Seinfeld",
              "EmployeeId": "HG014",
              "UserId": "2d82ece0-a0c6-11e2-a665-cf2c2ef6e160",
              "MemberId": "2de5f470-a0c6-11e2-a665-cf2c2ef6e160"
            },
            {
              "_id": "528fc27b3da14b3e89000057",
              "PeopleType": "Manager",
              "ModifiedDate": 1386790194859,
              "ModifiedBy": "",
              "CreatedDate": 1385153147074,
              "CreatedBy": "",
              "hgId": "",
              "ContainQuestionForMe": true,
              "Anonymous": false,
              "PercentAchieved": 0,
              "StatusInCurrentReview": "Closed",
              "SubmitDate": 1385153147074,
              "DueDate": 1385186400000,
              "DeliveryDate": 1385100000000,
              "MemberFullname": "Ganesh Kamble",
              "EmployeeId": "HG019",
              "UserId": "8a418dc0-ee81-11e2-8706-c3b972347dee",
              "MemberId": "8a51ba60-ee81-11e2-8706-c3b972347dee"
            }
          ],
          "StatusByAdminView": "Closed",
          "DetectableRolesOnly": false,
          "CardTitle": "Review with PEER",
          "CardId": "2d0e5fc0-32ab-11e3-8fe9-7fbcf85d265e",
		"Tags": []
      };
  }
    function getCycle() {
        return {
            "CurrentDeliveryId": "290ade50-5481-11e4-8ee0-5f231c0ddbea",
            "__v": 12,
            "_id": "543e94b4296d687c2988e794",
            "ModifiedDate": 1413571294137,
            "ModifiedBy": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
            "CreatedDate": 1413387444384,
            "CreatedBy": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
            "hgId": "29075be0-5481-11e4-8ee0-5f231c0ddbea",
            "Timing": "OneTime",
            "DeliveryHistory": [{
                "Date": 1413387444405,
                "Id": "290ade50-5481-11e4-8ee0-5f231c0ddbea",
                "_id": "543e94b4296d687c2988e795"
            }
            ],
            "PercentCompletion": 0,
            "Cards": [{
                "_id": "543e94b4296d687c2988e792",
                "Assignments": [{
                    "CustomAnonymous": {
                        "Peer": false
                    },
                    "_id": "544162de08efdd6501b9dff8",
                    "Participants": [{
                        "Department": "Development",
                        "AvatarId": "3cf94310-9cd2-11e2-a3a4-25024474fe63",
                        "Anonymous": false,
                        "EntityName": "Amie Chen",
                        "EntityId": "23310b40-9cd5-11e2-a3a4-25024474fe63",
                        "EntityType": "Member",
                        "PeopleType": "Subject"
                    }, {
                        "Department": "",
                        "AvatarId": "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160",
                        "Anonymous": false,
                        "EntityName": "Elaine Benes",
                        "EntityId": "2de5a650-a0c6-11e2-a665-cf2c2ef6e160",
                        "EntityType": "Member",
                        "PeopleType": "Manager"
                    }, {
                        "Department": "Development",
                        "AvatarId": "b6eff990-d39e-11e2-949a-bba0bbb422e0",
                        "Anonymous": false,
                        "EntityName": "Miriam Diversiev",
                        "EntityId": "b76fff00-d39e-11e2-949a-bba0bbb422e0",
                        "EntityType": "Member",
                        "PeopleType": "Peer"
                    }
                    ],
                    "hgId": ""
                }, {
                    "CustomAnonymous": {
                        "Peer": false
                    },
                    "_id": "544162de08efdd6501b9dff7",
                    "Participants": [{
                        "Department": "Development",
                        "AvatarId": "b6eff990-d39e-11e2-949a-bba0bbb422e0",
                        "Anonymous": false,
                        "EntityName": "Miriam Diversiev",
                        "EntityId": "b76fff00-d39e-11e2-949a-bba0bbb422e0",
                        "EntityType": "Member",
                        "PeopleType": "Subject"
                    }, {
                        "Department": "",
                        "AvatarId": "00db8060-d434-11e3-938d-991324c83af7",
                        "Anonymous": false,
                        "EntityName": "Akash kale",
                        "EntityId": "00db8062-d434-11e3-938d-991324c83af7",
                        "EntityType": "Member",
                        "PeopleType": "Manager"
                    }, {
                        "Department": "Development",
                        "AvatarId": "3cf94310-9cd2-11e2-a3a4-25024474fe63",
                        "Anonymous": false,
                        "EntityName": "Amie Chen",
                        "EntityId": "23310b40-9cd5-11e2-a3a4-25024474fe63",
                        "EntityType": "Member",
                        "PeopleType": "Peer"
                    }
                    ],
                    "hgId": ""
                }
                ],
                "PeopleTypes": [{
                    "_id": "542ee0d3b4fe8b37ae883107",
                    "Hierarchy": 0,
                    "Required": false,
                    "ContainQuestionForMe": true,
                    "PeopleTypeName": "Manager"
                }, {
                    "_id": "542ee0d3b4fe8b37ae883106",
                    "Hierarchy": 0,
                    "Required": false,
                    "ContainQuestionForMe": true,
                    "PeopleTypeName": "Subject"
                }, {
                    "_id": "542ee0d3b4fe8b37ae883105",
                    "Hierarchy": 0,
                    "Required": false,
                    "ContainQuestionForMe": true,
                    "PeopleTypeName": "Peer"
                }
                ],
                "ContainQuestion": ["Manager", "Subject", "Peer"],
                "CustomList": [{
                    "hierarchy": 0,
                    "typeName": "Peer"
                }
                ],
                "DetectableRolesOnly": false,
                "Description": "",
                "Title": "Subject, manager, peer",
                "hgId": "202eab00-4b25-11e4-9a85-775eb7762d56"
            }
            ],
            "PeopleDates": [{
                "DlvTrgPplType": "Date",
                "DueInDays": 0,
                "CanReject": false,
                "SignsOff": false,
                "CanSeeResponse": false,
                "DeliveryTrigger": "Date",
                "DeliveryDate": 1413349200000,
                "DueDate": 1414731600000,
                "PeopleType": "Subject"
            }, {
                "DlvTrgPplType": "Subject",
                "DueInDays": 8,
                "CanReject": false,
                "SignsOff": false,
                "CanSeeResponse": false,
                "DeliveryTrigger": "Submission",
                "DeliveryDate": null,
                "DueDate": null,
                "PeopleType": "Manager"
            }, {
                "DlvTrgPplType": "Subject",
                "DueInDays": 8,
                "CanReject": false,
                "SignsOff": false,
                "CanSeeResponse": false,
                "DeliveryTrigger": "Submission",
                "DeliveryDate": null,
                "DueDate": null,
                "PeopleType": "Peer"
            }
            ],
            "CreatorReceivesNotificationOnCompletion": false,
            "SignOffInitiator": "",
            "ReleaseMethod": "ReleaseDate",
            "ReleaseDate": null,
            "ReviewPeriodEnd": 1414731600000,
            "ReviewPeriodStart": 1413349200000,
            "GroupName": "Mercury Industries",
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Title": "Subject manager and peer"
        };
    }

    function getPojo() {
        return {
            "ModifiedDate": 1413821446462,
            "ModifiedBy": "",
            "CreatedDate": 1413821446462,
            "CreatedBy": "",
            "hgId": "",
            "Timing": "OneTime",
            "DeliveryHistory": [],
            "PercentCompletion": 0,
            "Cards": [],
            "PeopleDates": [],
            "CreatorReceivesNotificationOnCompletion": false,
            "SignOffInitiator": "",
            "ReleaseMethod": "ReleaseDate",
            "ReleaseDate": null,
            "ReviewPeriodEnd": 1413815789317,
            "ReviewPeriodStart": 1413815789317,
            "GroupName": "",
            "GroupId": "",
            "Title": ""
        };
    }

    function getCycleCard() {
        return {
            "hgId": "d4632960-4ef5-11e4-850b-136c767d1f91",
            "Title": "Subject manager only",
            "Description": "",
            "DetectableRolesOnly": true,
            "ContainQuestion": ["Manager", "Subject"],
            "CustomList": [],
            "PeopleTypes": [{
                "_id": "5435477614a7f10000cb906a",
                "Level": 0,
                "AllowMultiple": false,
                "Hierarchy": 0,
                "Required": false,
                "ContainQuestionForMe": true,
                "PeopleTypeName": "Manager"
            }, {
                "_id": "5435477614a7f10000cb9069",
                "Level": 0,
                "AllowMultiple": false,
                "Hierarchy": 0,
                "Required": false,
                "ContainQuestionForMe": true,
                "PeopleTypeName": "Subject"
            }, {
                "_id": "5435477614a7f10000cb9068",
                "Level": 0,
                "AllowMultiple": false,
                "Hierarchy": 0,
                "Required": false,
                "ContainQuestionForMe": false,
                "PeopleTypeName": "Peer"
            }
            ],
            "Assignments": [{
                "RevieweeIds": [],
                "CustomIds": [],
                "CustomAnonymous": [],
                "Participants": [],
                "CustomValid": []
            }
            ]
        };
    }

    function getDistinctDepartmentsByCycle() {
        return [
            'Development'
        ];
    }

    return {
        getCycleDetail: getCycleDetail,
        getClosedReview: getClosedReview,
		getCycles: getCycles,
        getCycleSummaryCount : getCycleSummaryCount,
        getCycle: getCycle,
        getPojo: getPojo,
        getCycleCard: getCycleCard,
        getDistinctDepartmentsByCycle: getDistinctDepartmentsByCycle
    };
});