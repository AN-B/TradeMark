define(function(){
    function getCommentsForFeeds(){
        return [
            {
                "hgId": "6fbd4b80-9a73-11e3-a710-595fa25447be",
                "EntityId": "4d7e26a1-9985-11e3-a57e-ef0c5cd920f3",
                "CommenterUserhgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                "CommenterFirstName": "Tuan",
                "CommenterLastName": "Pham-Barnes",
                "CreatedDate": "Pham-Barnes",
                "Comment": "test 2323"
            },
            {
                "hgId": "71d507f0-9a73-11e3-a710-595fa25447be",
                "EntityId": "4d7e26a1-9985-11e3-a57e-ef0c5cd920f3",
                "CommenterUserhgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                "CommenterFirstName": "Tuan",
                "CommenterLastName": "Pham-Barnes",
                "CreatedDate": "Pham-Barnes",
                "Comment": "mama"
            },
            {
                "hgId": "733eaa10-9a73-11e3-a710-595fa25447be",
                "EntityId": "4d7e26a1-9985-11e3-a57e-ef0c5cd920f3",
                "CommenterUserhgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                "CommenterFirstName": "Tuan",
                "CommenterLastName": "Pham-Barnes",
                "CreatedDate": "Pham-Barnes",
                "Comment": "mia"
            },
            {
                "hgId": "75c44380-9a73-11e3-a710-595fa25447be",
                "EntityId": "c94c23f0-9984-11e3-a57e-ef0c5cd920f3",
                "CommenterUserhgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                "CommenterFirstName": "Tuan",
                "CommenterLastName": "Pham-Barnes",
                "CreatedDate": "Pham-Barnes",
                "Comment": "test 12jb"
            },
            {
                "hgId": "76b421c0-9a73-11e3-a710-595fa25447be",
                "EntityId": "c94c23f0-9984-11e3-a57e-ef0c5cd920f3",
                "CommenterUserhgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                "CommenterFirstName": "Tuan",
                "CommenterLastName": "Pham-Barnes",
                "CreatedDate": "Pham-Barnes",
                "Comment": "jhzsxjhsda"
            },
            {
                "hgId": "c94c23f0-9984-11e3-a57e-ef0c5cd920f3",
                "EntityId": "c94c23f0-9984-11e3-a57e-ef0c5cd920f3",
                "CommenterUserhgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                "CommenterFirstName": "Tuan",
                "CommenterLastName": "Pham-Barnes",
                "CreatedDate": "Pham-Barnes",
                "Comment": "Hello World",
                "showEditDiv": false
            }
        ];
    }
    return {
        getCommentsForFeeds: getCommentsForFeeds
    }
});