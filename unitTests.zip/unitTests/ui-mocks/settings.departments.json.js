define(function() {
    function getAll() {
        return [
            {
                "ChildTeams" : [],
                "CreatedBy" : "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate" : 1418031905091,
                "Description" : "dept 1 desc",
                "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "GroupName" : "Mercury Industries",
                "IsPublic" : true,
                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                "ModifiedDate" : 1418031961655,
                "Name" : "Dept 1",
                "OwnerFullName" : "Cu Barnes",
                "OwnerId" : "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "Status" : "Active",
                "TeamMembers" : [],
                "Type" : "Department",
                "__v" : 0,
                "hgId" : "e3559400-7ebe-11e4-babf-a99abd4c4c6a"
            },
            {
                "ChildTeams" : [
                    {
                        "TeamName" : "Dept 1",
                        "TeamId" : "e3559400-7ebe-11e4-babf-a99abd4c4c6a"
                    }
                ],
                "CreatedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate" : 1418032829369,
                "Description" : "Dept 2 desc",
                "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "GroupName" : "Mercury Industries",
                "IsPublic" : true,
                "ModifiedBy" : "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                "ModifiedDate" : 1418032838938,
                "Name" : "Dept 2",
                "OwnerFullName" : "Marcie Carlos",
                "OwnerId" : "2331f5a1-9cd5-11e2-a3a4-25024474fe63",
                "Status" : "Active",
                "TeamMembers" : [],
                "Type" : "Department",
                "__v" : 1,
                "hgId" : "0a3f5c70-7ec1-11e4-babf-a99abd4c4c6a"
            }
        ]
    }

    return {
        getAll: getAll
    };
});