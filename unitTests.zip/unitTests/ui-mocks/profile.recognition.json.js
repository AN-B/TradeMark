/**
 * Created by philipplekhanov on 9/26/14.
 */
define(function () {
    function getCompany () {
        return [{
            "Message":"test",
            "BatchId":"b0b3c3d0-dd2f-11e4-b2d6-b5513c694ce6",
            "CreatedDate":1428415762581,
            "hgId":"b0b3eae0-dd2f-11e4-b2d6-b5513c694ce6",
            "CongratsCount":0,
            "BadgeUrl":"/badges/group/1/207be770-dd2f-11e4-b2d6-b5513c694ce6",
            "IsPublic":false,
            "CommentCount":0,
            "Title":"Ristrication issue",
            "Description":"Ristrication issue",
            "Levels":[],
            "LevelAchieved":0,
            "From":"Cu Barnes"
        },{
            "Message":"test",
            "BatchId":"3e9597b0-dd2f-11e4-b2d6-b5513c694ce6",
            "CreatedDate":1428415571118,
            "hgId":"3e9597b1-dd2f-11e4-b2d6-b5513c694ce6",
            "CongratsCount":0,
            "BadgeUrl":"/badges/group/1/207be770-dd2f-11e4-b2d6-b5513c694ce6",
            "IsPublic":false,
            "CommentCount":3,
            "Title":"Ristrication issue",
            "Description":"Ristrication issue",
            "Levels":[],
            "LevelAchieved":0,
            "From":"Cu Barnes"
        },{
            "Message":"test",
            "BatchId":"2d4697c0-dd2f-11e4-b2d6-b5513c694ce6",
            "CreatedDate":1428415542094,
            "hgId":"2d46bed0-dd2f-11e4-b2d6-b5513c694ce6",
            "CongratsCount":0,
            "BadgeUrl":"/badges/group/1/207be770-dd2f-11e4-b2d6-b5513c694ce6",
            "IsPublic":false,
            "CommentCount":0,
            "Title":"Ristrication issue",
            "Description":"Ristrication issue",
            "Levels":[],
            "LevelAchieved":0,
            "From":"Cu Barnes"
        }];
    }
    function getValue() {
        return [{
            "BatchId":"d606ae30-2269-11e4-b6ce-cd4f824663e4",
            "Message":"test",
            "CreatedDate":1407879868591,
            "hgId":"d607e6b0-2269-11e4-b6ce-cd4f824663e4",
            "CongratsCount":0,
            "BadgeUrl":"/badges/group/1/fddb7f40-2231-11e4-93fd-5f6f2c76988a_Gold",
            "IsPublic":false,
            "CommentCount":0,
            "Title":"Transport A firefighter (historically and still sometimes also kn",
            "Description":"Transport",
            "Levels":[],
            "LevelAchieved":0,
            "From":"Jalpa Khatri"
        },{
            "BatchId":"b87fc8e0-0c40-11e4-8d26-734ba54d5f0f",
            "Message":"1",
            "CreatedDate":1405443284115,
            "hgId":"b87feff0-0c40-11e4-8d26-734ba54d5f0f",
            "CongratsCount":1,
            "BadgeUrl":"/badges/group/1/929eb3d0-061d-11e4-8cd7-0b32aec4952f_Silver",
            "IsPublic":false,
            "CommentCount":0,
            "Title":"test1",
            "Description":"testing",
            "Levels":[],
            "LevelAchieved":0,
            "From":"Amie Chen"
        },{
            "BatchId":"7ac245f0-0c40-11e4-929c-117bb6b53286",
            "Message":"test1",
            "CreatedDate":1405443180521,
            "hgId":"7ac26d00-0c40-11e4-929c-117bb6b53286",
            "CongratsCount":0,
            "BadgeUrl":"/badges/group/1/929eb3d0-061d-11e4-8cd7-0b32aec4952f_Silver",
            "IsPublic":false,
            "CommentCount":0,
            "Title":"test1",
            "Description":"testing",
            "Levels":[],
            "LevelAchieved":0,
            "From":"Amie Chen"
        }];
    }
    function getExternal() {
        return [{
            "Message":"Gang sefCAEFVAERFV.",
            "BatchId":"250dedc0-3486-11e5-b2a8-d3a1c1ae2a23",
            "CreatedDate":1438018645660,
            "hgId":"250e14d0-3486-11e5-b2a8-d3a1c1ae2a23",
            "CongratsCount":0,
            "BadgeUrl":"/badges/group/1/26378510-8854-11e3-a59c-6f04438d3e64",
            "IsPublic":true,
            "CommentCount":0,
            "Title":"If you Ain't First, You're Last",
            "Description":"Awards can be given by any person or institution, although the prestige of an award usually depends on the status of the awarder. Usually, awards are given by an organization of some sort, or by the office of an official within an organization or government.",
            "Levels":[],
            "LevelAchieved":0,
            "From":"cu (cu)"
        },{
            "Message":"Gang sfvardjgfarejkgfjre.",
            "BatchId":"a0552ee0-3485-11e5-a0b7-afc6d4e2a703",
            "CreatedDate":1438018422991,
            "hgId":"a05555f0-3485-11e5-a0b7-afc6d4e2a703",
            "CongratsCount":0,
            "Title":"C2",
            "Description":"",
            "BadgeUrl":"/badges/group/1/f26a3040-d792-11e4-83b1-8b669af5a4cc",
            "IsPublic":true,
            "CommentCount":0,
            "Levels":[],
            "LevelAchieved":0,
            "From":"gary123 (gary123)"
        },{
            "Message":"Gang sfCSEVFDASRVA.",
            "BatchId":"e98e6960-3484-11e5-948d-a129a700586d",
            "CreatedDate":1438018116342,
            "hgId":"e98e9070-3484-11e5-948d-a129a700586d",
            "CongratsCount":0,
            "BadgeUrl":"/badges/group//",
            "IsPublic":true,
            "CommentCount":0,
            "LevelAchieved":0,
            "From":"no badge (no badge)"
        }];
    }
    function getEveryday() {
      return [{
        "Message":"Gang sefCAEFVAERFV.",
        "BatchId":"250dedc0-3486-11e5-b2a8-d3a1c1ae2a23",
        "CreatedDate":1438018645660,
        "hgId":"250e14d0-3486-11e5-b2a8-d3a1c1ae2a23",
        "CongratsCount":0,
        "BadgeUrl":"/badges/group/1/26378510-8854-11e3-a59c-6f04438d3e64",
        "IsPublic":true,
        "CommentCount":0,
        "Title":"If you Ain't First, You're Last",
        "Description":"Awards can be given by any person or institution, although the prestige of an award usually depends on the status of the awarder. Usually, awards are given by an organization of some sort, or by the office of an official within an organization or government.",
        "Levels":[],
        "LevelAchieved":0,
        "From":"cu (cu)"
    },{
        "Message":"Gang sfvardjgfarejkgfjre.",
        "BatchId":"a0552ee0-3485-11e5-a0b7-afc6d4e2a703",
        "CreatedDate":1438018422991,
        "hgId":"a05555f0-3485-11e5-a0b7-afc6d4e2a703",
        "CongratsCount":0,
        "Title":"C2",
        "Description":"",
        "BadgeUrl":"/badges/group/1/f26a3040-d792-11e4-83b1-8b669af5a4cc",
        "IsPublic":true,
        "CommentCount":0,
        "Levels":[],
        "LevelAchieved":0,
        "From":"gary123 (gary123)"
    },{
        "Message":"Gang sfCSEVFDASRVA.",
        "BatchId":"e98e6960-3484-11e5-948d-a129a700586d",
        "CreatedDate":1438018116342,
        "hgId":"e98e9070-3484-11e5-948d-a129a700586d",
        "CongratsCount":0,
        "BadgeUrl":"/badges/group//",
        "IsPublic":true,
        "CommentCount":0,
        "LevelAchieved":0,
        "From":"no badge (no badge)"
        }];
    }
    function getSystem() {
        return [{
                "BatchId":"e9f74dd1-aec0-11e4-aa51-6d38e7c6cdd4",
                "Message":"Happy Anniversary -from HighGround!\nWepoiru oisdufoi wueoifu osdiufoiwueoifu osiduf \nspeiruwpo eiufpoisdup ofiuwopeiu fposiduf poiwue ifusdiu fpowieup ofiuspdoifu opwieufo isudoifu owiueo fisuodiuf oiwueoif usodiuf oiwueo fiusdf\nWelcome to HighGorund!",
                "CreatedDate":1423310431025,
                "hgId":"e9f74dd0-aec0-11e4-aa51-6d38e7c6cdd4",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/b1269f70-d3a1-11e2-949a-bba0bbb422e0",
                "IsPublic":false,
                "CommentCount":0,
                "Title":"Anniversary Badge",
                "Description":"Anniversary Badge",
                "Levels":[],
                "LevelAchieved":0,
                "From":"Testing Mercury Program Name"
            }];
    }
    function getInitRecognitions() {
        return {
            "external":
            [{
                "Message":"Gang good feedback.\r\n Gang's Rating: 10",
                "BatchId":"074d1890-355a-11e5-9206-492d499f77c0",
                "CreatedDate":1438109649050,
                "hgId":"074d3fa0-355a-11e5-9206-492d499f77c0",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/bbff86e0-f3d7-11e2-a386-1b415e60a691",
                "IsPublic":true,
                "CommentCount":0,
                "Title":"Don't Take No for an Answer",
                "Description":"Company",
                "Levels":[],
                "LevelAchieved":0,
                "From":"test777 (test777)"
            }, {
                "Message":"Gang eJQWDHewkfhewkagfekwjGUFJEWGFJUEQ.\r\n Gang's Rating: 10",
                "BatchId":"90758bb0-34ac-11e5-b6c0-e1d8190c2684",
                "CreatedDate":1438035146732,
                "hgId":"9075b2c0-34ac-11e5-b6c0-e1d8190c2684",
                "CongratsCount":1,
                "BadgeUrl":"/badges/group/1/3b1af400-48ff-11e4-9708-692135abd5f5",
                "IsPublic":true,
                "CommentCount":0,
                "Title":"The Uncomplicator",
                "Description":"1",
                "Levels":[],
                "LevelAchieved":0,
                "From":"positive (positive)"
            },{
                "Message":"Gang eDFHkefhkwuEGFEuw.\r\n Gang's Rating: 10",
                "BatchId":"c5055070-3486-11e5-ae56-21db888abcfa",
                "CreatedDate":1438018914040,
                "hgId":"c5057780-3486-11e5-ae56-21db888abcfa",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/bbff86e0-f3d7-11e2-a386-1b415e60a691",
                "IsPublic":true,
                "CommentCount":0,
                "Title":"Don't Take No for an Answer",
                "Description":"Company",
                "Levels":[],
                "LevelAchieved":0,
                "From":"recog (recog)"
            }],
            "everyday":
            [{
                "Message":"Gang good feedback.\r\n Gang's Rating: 10",
                "BatchId":"074d1890-355a-11e5-9206-492d499f77c0",
                "CreatedDate":1438109649050,
                "hgId":"074d3fa0-355a-11e5-9206-492d499f77c0",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/bbff86e0-f3d7-11e2-a386-1b415e60a691",
                "IsPublic":true,
                "CommentCount":0,
                "Title":"Don't Take No for an Answer",
                "Description":"Company",
                "Levels":[],
                "LevelAchieved":0,
                "From":"test777 (test777)"
            },{
                "Message":"Gang eJQWDHewkfhewkagfekwjGUFJEWGFJUEQ.\r\n Gang's Rating: 10",
                "BatchId":"90758bb0-34ac-11e5-b6c0-e1d8190c2684",
                "CreatedDate":1438035146732,
                "hgId":"9075b2c0-34ac-11e5-b6c0-e1d8190c2684",
                "CongratsCount":1,
                "BadgeUrl":"/badges/group/1/3b1af400-48ff-11e4-9708-692135abd5f5",
                "IsPublic":true,
                "CommentCount":0,
                "Title":"The Uncomplicator",
                "Description":"1",
                "Levels":[],
                "LevelAchieved":0,
                "From":"positive (positive)"
            },{
                "Message":"Gang eDFHkefhkwuEGFEuw.\r\n Gang's Rating: 10",
                "BatchId":"c5055070-3486-11e5-ae56-21db888abcfa",
                "CreatedDate":1438018914040,
                "hgId":"c5057780-3486-11e5-ae56-21db888abcfa",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/bbff86e0-f3d7-11e2-a386-1b415e60a691",
                "IsPublic":true,
                "CommentCount":0,
                "Title":"Don't Take No for an Answer",
                "Description":"Company",
                "Levels":[],
                "LevelAchieved":0,
                "From":"recog (recog)"
            }],
            "company":
            [{
                "Message":"test",
                "BatchId":"8632c380-dd30-11e4-b2d6-b5513c694ce6",
                "CreatedDate":1428416120765,
                "hgId":"8632ea90-dd30-11e4-b2d6-b5513c694ce6",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/207be770-dd2f-11e4-b2d6-b5513c694ce6",
                "IsPublic":false,
                "CommentCount":1,
                "Title":"Ristrication issue",
                "Description":"Ristrication issue",
                "Levels":[
                {"PointValue":10,"CreditValue":10,"_id":"5523e5f02888f40b00fc7f78","Name":"1"},
                {"PointValue":10,"CreditValue":10,"_id":"5523e5f02888f40b00fc7f77","Name":"2"}
                ],
                "LevelAchieved":1,
                "From":"Cu Barnes"
            },{
                "Message":"test",
                "BatchId":"4f062910-dd30-11e4-bf0f-73a1dd3e784b",
                "CreatedDate":1428416028197,
                "hgId":"4f065020-dd30-11e4-bf0f-73a1dd3e784b",
                "CongratsCount":1,
                "BadgeUrl":"/badges/group/1/207be770-dd2f-11e4-b2d6-b5513c694ce6",
                "IsPublic":false,
                "CommentCount":4,
                "Title":"Ristrication issue",
                "Description":"Ristrication issue",
                "Levels":[
                {"PointValue":10,"CreditValue":10,"_id":"5523e5f02888f40b00fc7f78","Name":"1"},
                {"PointValue":10,"CreditValue":10,"_id":"5523e5f02888f40b00fc7f77","Name":"2"}
                ],
                "LevelAchieved":1,
                "From":"Cu Barnes"
            },{
                "Message":"test",
                "BatchId":"3ebc3d10-dd30-11e4-b912-91cee5f77e0d",
                "CreatedDate":1428416000873,
                "hgId":"3ebc3d11-dd30-11e4-b912-91cee5f77e0d",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/207be770-dd2f-11e4-b2d6-b5513c694ce6",
                "IsPublic":false,
                "CommentCount":1,
                "Title":"Ristrication issue",
                "Description":"Ristrication issue",
                "Levels":[
                {"PointValue":10,"CreditValue":10,"_id":"5523e5f02888f40b00fc7f78","Name":"1"},
                {"PointValue":10,"CreditValue":10,"_id":"5523e5f02888f40b00fc7f77","Name":"2"}
                ],
                "LevelAchieved":1,
                "From":"Cu Barnes"
            }],
            "value":
            [{
                "BatchId":"881f1dc0-382a-11e4-a5c6-83f8b65466cd",
                "Message":"test",
                "CreatedDate":1410271605149,
                "hgId":"881f1dc1-382a-11e4-a5c6-83f8b65466cd",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/751d6e20-3811-11e4-99eb-4b805b5c74df_Silver",
                "IsPublic":false,
                "CommentCount":5,
                "Title":"t 1",
                "Description":"t 1",
                "Levels":[],
                "LevelAchieved":0,
                "From":"Areena Jose"
            },{
                "BatchId":"48e34a60-32a7-11e4-8077-cbccd452209c",
                "Message":"1",
                "CreatedDate":1409665479209,
                "hgId":"48e39882-32a7-11e4-8077-cbccd452209c",
                "CongratsCount":1,
                "BadgeUrl":"/badges/group/1/fddb7f40-2231-11e4-93fd-5f6f2c76988a_Silver",
                "IsPublic":false,
                "CommentCount":4,
                "Title":"Transport A firefighter (historically and still sometimes also kn",
                "Description":"Transport",
                "Levels":[],
                "LevelAchieved":0,
                "From":"Mahendra Khichi"
            },{
                "BatchId":"d2fb25c0-2d47-11e4-b086-5b5bfa9e8f7d",
                "Message":"test 1",
                "CreatedDate":1409074723370,
                "hgId":"d2fb4cd0-2d47-11e4-b086-5b5bfa9e8f7d",
                "CongratsCount":0,
                "BadgeUrl":"/badges/group/1/3af89cf0-26e7-11e4-9b99-5362469969ab_Silver",
                "IsPublic":false,
                "CommentCount":0,
                "Title":"testing_2",
                "Description":"Bacon ipsum dolor sit amet pig rump pancetta, jowl flank corned beef andouille shankle. Spare ribs leberkas pork chop tongue pork, ham short ribs biltong hamburger tenderloin flank rump kielbasa. Pork spare ribs capicola cow. Bacon andouille venison tri-tip chicken filet mignon.",
                "Levels":[],
                "LevelAchieved":0,
                "From":"Elaine Benes"
            }],
            "counts":{
                "CompanyCount":24,
                "ExternalCount":37,
                "ValuesCount":12,
                "EverydayCount":385}
        };
    }
    return {
        getInitRecognitions: getInitRecognitions,
        getCompany: getCompany,
        getValue: getValue,
        getEveryday: getEveryday,
        getExternal: getExternal,
        getSystem: getSystem

    };
});