define(function(){
    function get(){
        return [
            {
                "CycleTitle":"2015 HighGround Company OKR",
                "CycleId":"813b7c70-eeb8-11e4-b7aa-61d7457d1175",
                "GoalId":"0a962700-ef67-11e4-99b4-6b63ccdbea5b",
                "Name":"goal 3",
                "Status":"SubmittedForSet",
                "Owner":{
                    "MemberId":"3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "UserId":"3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "FullName":"Gang Wei"
                }
            },
            {
                "CycleTitle":"2015 HighGround Company OKR",
                "CycleId":"813b7c70-eeb8-11e4-b7aa-61d7457d1175",
                "GoalId":"2fd3e590-ef47-11e4-ac59-1d9ce62f7688",
                "Name":"aa",
                "Status":"SubmittedForSet",
                "Owner":{
                    "MemberId":"3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "UserId":"3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "FullName":"Gang Wei"
                }
            },
            {
                "CycleTitle":"2015 HighGround Company OKR",
                "CycleId":"813b7c70-eeb8-11e4-b7aa-61d7457d1175",
                "GoalId":"3bd6d910-ef47-11e4-ac59-1d9ce62f7688",
                "Name":"ad",
                "Status":"SubmittedForSet",
                "Owner":{
                    "MemberId":"3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "UserId":"3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "FullName":"Gang Wei"
                }
            },
            {
                "CycleTitle":"2015 HighGround Company OKR",
                "CycleId":"813b7c70-eeb8-11e4-b7aa-61d7457d1175",
                "GoalId":"67b02b80-ef48-11e4-b0ed-9d0131b99e3d",
                "Name":"af",
                "Status":"SubmittedForSet",
                "Owner":{
                    "MemberId":"3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "UserId":"3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "FullName":"Gang Wei"
                }
            },
            {
                "CycleTitle":"2015 HighGround Company OKR",
                "CycleId":"813b7c70-eeb8-11e4-b7aa-61d7457d1175",
                "GoalId":"a76527f0-ef64-11e4-9c40-e9c23a2a664a",
                "Name":"Goal 2",
                "Status":"SubmittedForSet",
                "Owner":{
                    "MemberId":"3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "UserId":"3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "FullName":"Gang Wei"
                }
            }
        ];
    }
    function getDetails() {
        return {
            "CycleId": "9c5c50f0-f5bc-11e4-9874-fdfdf272338f",
            "Name": "Gary Development Goal of Q4",
            "hgId": "c9b61e50-f5bc-11e4-9cab-2755ac17dd00",
            "KeyResults": [
                {
                    "_id": "554d15b73119f6bbaae18ea6",
                    "Name": "KR 1: Finish up ORK backend",
                    "Target": 100,
                    "ModifiedDate": 1431115191478,
                    "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate": 1431115191478,
                    "CreatedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "hgId": "c9b226b0-f5bc-11e4-9cab-2755ac17dd00",
                    "Progress": 0,
                    "Measure": "Percentage"
                },
                {
                    "_id": "554d15b73119f6bbaae18ea7",
                    "Name": "KR 2: help with Perform",
                    "Target": 100,
                    "ModifiedDate": 1431115191478,
                    "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate": 1431115191478,
                    "CreatedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "hgId": "c9b226b1-f5bc-11e4-9cab-2755ac17dd00",
                    "Progress": 0,
                    "Measure": "Percentage"
                },
                {
                    "_id": "554d15b73119f6bbaae18ea8",
                    "Name": "KR 3: Fix 80 defects",
                    "Target": 80,
                    "ModifiedDate": 1431115191478,
                    "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate": 1431115191478,
                    "CreatedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "hgId": "c9b226b2-f5bc-11e4-9cab-2755ac17dd00",
                    "Progress": 0,
                    "Measure": "Numeric"
                },
                {
                    "_id": "554d15b73119f6bbaae18ea9",
                    "Name": "KR 4: refactor 5 services during shark week",
                    "Target": 5,
                    "ModifiedDate": 1431115191478,
                    "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate": 1431115191478,
                    "CreatedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "hgId": "c9b226b3-f5bc-11e4-9cab-2755ac17dd00",
                    "Progress": 0,
                    "Measure": "Numeric"
                }
            ],
            AlignedGoal: {
                "GoalId": "dbc0bf70-0aec-11e5-ab2a-7d91bbc4935d",
                "Name": "Drink More Beer",
                "ParticipantType": "Company"
            },
            "PercentCompletion": 0,
            "Collaborators": [],
            "Approver": {
                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "FullName": "Cu Barnes"
            },
            "Owner": {
                "MemberId": "23318070-9cd5-11e2-a3a4-25024474fe63",
                "UserId": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                "FullName": "Gary Wei"
            },
            "Participant": {
                "ParticipantType": "Member",
                "ParticipantId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
            },
            "KeyResultWeightType": "Equal",
            "IsPublic": true,
            "Status": "SubmittedForSet",
            "ProgressStatus": "OnTrack"
        };
    }
    function getMemberApproval() {
        return [
            {
                "CycleId": "8e51c110-354b-11e5-8018-052cb3f37b70",
                "CycleTitle": "test12 21",
                "WeightingPetitions": [

                ],
                "GoalPetitions": [
                    {
                        "GoalId": "4cb0e160-70ff-11e5-87eb-395618fb3637",
                        "GoalName": "test 223",
                        "Status": "SubmittedForSet",
                        "Name": "Katrina Manoshin",
                        "AvatarId": "3cf412f0-9cd2-11e2-a3a4-25024474fe63",
                        "ParticipantId": "23315960-9cd5-11e2-a3a4-25024474fe63"
                    }
                ]
            },
            {
                "CycleId": "6348e270-fcd6-11e5-a051-4d7959bbea1b",
                "CycleTitle": "test",
                "WeightingPetitions": [

                ],
                "GoalPetitions": [
                    {
                        "GoalId": "a599a920-fcd6-11e5-a051-4d7959bbea1b",
                        "GoalName": "test",
                        "Status": "SubmittedForSet",
                        "Name": "Katrina Manoshin",
                        "AvatarId": "3cf412f0-9cd2-11e2-a3a4-25024474fe63",
                        "ParticipantId": "23315960-9cd5-11e2-a3a4-25024474fe63"
                    },
                    {
                        "GoalId": "ae6406e0-fcd6-11e5-a051-4d7959bbea1b",
                        "GoalName": "test",
                        "Status": "SubmittedForSet",
                        "Name": "Katrina Manoshin",
                        "AvatarId": "3cf412f0-9cd2-11e2-a3a4-25024474fe63",
                        "ParticipantId": "23315960-9cd5-11e2-a3a4-25024474fe63"
                    }
                ]
            },
            {
                "CycleId": "ad-hoc-cycle-dummy-id",
                "CycleTitle": "Ad-hoc goals",
                "WeightingPetitions": [

                ],
                "GoalPetitions": [

                ]
            }
        ];
    }
    function getModel() {
        return [{
            CycleId: 'test',
            GoalPetitions: [{GoalId: 'test'}],
            WeightingPetitions: [{ParticipantHgId: 'test'}]

        }];
    }
    return {
        get: get,
        getDetails: getDetails,
        getMemberApproval: getMemberApproval,
        getModel: getModel
    };
});