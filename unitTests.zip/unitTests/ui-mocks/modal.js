define(function(){
    return {
        close: function(){

        },
        dismiss: function(){

        },
        open: function(){

        }
    };
});
