define(function() {
    function getRequest() {
        return {
            "hgId": "9820fee0-7256-11e3-9aa0-cfdc9304f88e",
            "valid": false,
            "FriendlyGroupId": '1337',
            "Certs": [
                "Acq_Cert1.svg",
                "Acq_Cert2.svg",
                "Acq_Cert3.svg"
            ]
        }
    };
    function getMessages() {
        return  [
                "Uploading Cert zip...",
                "Uploaed Cert Successfully...",
                "Begin Uploaded Zip Validation",
                "Extracting badges zip file..."
            ]
    }
    return {
        getMessages: getMessages,
        getRequest: getRequest
    }
})
