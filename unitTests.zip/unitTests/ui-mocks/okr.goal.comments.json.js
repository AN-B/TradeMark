define(function(){
    function get(){
        return {
            comments:[
                {
                    "hgId":"1b046d70-056c-11e5-b977-4ba3046a4f8f",
                    "Comment":"test",
                    "UserhgId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate":1432839757256,
                    "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "Name":"Tuan Pham-Barnes"
                },
                {
                    "hgId":"a17779c0-055c-11e5-a4fd-bf739487cc16",
                    "Comment":"nshdsdhhsd",
                    "UserhgId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate":1432833110877,
                    "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "Name":"Tuan Pham-Barnes"
                },
                {
                    "hgId":"a035d200-055c-11e5-a4fd-bf739487cc16",
                    "Comment":"sjhdbdshg",
                    "UserhgId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate":1432833108768,
                    "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "Name":"Tuan Pham-Barnes"
                },
                {
                    "hgId":"9e4a0790-055c-11e5-a4fd-bf739487cc16",
                    "Comment":"tetet",
                    "UserhgId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate":1432833105545,
                    "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "Name":"Tuan Pham-Barnes"
                },
                {
                    "hgId":"6b946bc0-055b-11e5-a4fd-bf739487cc16",
                    "Comment":"comment",
                    "UserhgId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate":1432832590972,
                    "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "Name":"Tuan Pham-Barnes"
                }
            ],
            count: 5
        };
    }
    return {
        get: get
    };
});