define(function(){

    function getSectionFeedback() {
        return {
            "hgId": "fd9738e0-3c82-11e6-ba54-9b7fc7019def",
            "CycleId": "aa6e9ae0-3c7e-11e6-80c1-b33abf5e18f0",
            "CycleTitle": "test sections",
            "CycleDescription": "",
            "ExpirationDate": 1468253997934,
            "Card": {
                "hgId": "aa691ca6-3c7e-11e6-80c1-b33abf5e18f0",
                "Title": "test sections",
                "Sections": [
                    {
                        "Title": "section 1",
                        "Description": "",
                        "hgId": "aa691ca0-3c7e-11e6-80c1-b33abf5e18f0",
                        "Questions": [
                            {
                                "hgId": "aa691ca1-3c7e-11e6-80c1-b33abf5e18f0",
                                "Question": "test question 1",
                                "QuestionHelp": "",
                                "Type": "ShortAnswer",
                                "Required": true,
                                "OptionalComment": false,
                                "Answer": {},
                                "AnswerSelector": [],
                                "SortOrder": 0
                            },
                            {
                                "hgId": "aa691ca2-3c7e-11e6-80c1-b33abf5e18f0",
                                "Question": "test question 2",
                                "QuestionHelp": "",
                                "Type": "ShortAnswer",
                                "Required": true,
                                "OptionalComment": false,
                                "Answer": {},
                                "AnswerSelector": [],
                                "SortOrder": 1
                            }
                        ]
                    },
                    {
                        "Title": "Section 2",
                        "Description": "",
                        "hgId": "aa691ca3-3c7e-11e6-80c1-b33abf5e18f0",
                        "Questions": [
                            {
                                "hgId": "aa691ca4-3c7e-11e6-80c1-b33abf5e18f0",
                                "Question": "test question 1",
                                "QuestionHelp": "",
                                "Type": "ShortAnswer",
                                "Required": true,
                                "OptionalComment": false,
                                "Answer": {},
                                "AnswerSelector": [],
                                "SortOrder": 0
                            },
                            {
                                "hgId": "aa691ca5-3c7e-11e6-80c1-b33abf5e18f0",
                                "Question": "test question 2",
                                "QuestionHelp": "",
                                "Type": "ShortAnswer",
                                "Required": true,
                                "OptionalComment": false,
                                "Answer": {},
                                "AnswerSelector": [],
                                "SortOrder": 1
                            }
                        ]
                    }
                ],
                "Questions": [],
                "SinglePageQuestion": true,
                "UseSections": true
            },
            "Participants": [
                {
                    "ParticipantType": "Subject",
                    "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "FullName": "Cu Barnes",
                    "Role": "HGAdmin",
                    "DepartmentName": "Zomm1",
                    "DepartmentId": "fe45b8f0-f40a-11e4-99fc-6bc86d3fba1d",
                    "LocationName": "River North",
                    "LocationId": "51756460-b23b-11e4-9219-db713d08c4ee",
                    "Status": "Requesting"
                },
                {
                    "ParticipantType": "Reviewer",
                    "MemberId": "23318070-9cd5-11e2-a3a4-25024474fe63",
                    "UserId": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "FullName": "Gary Wei",
                    "Role": "HGAdmin",
                    "DepartmentName": "IT Department",
                    "DepartmentId": "eedeee60-b81c-11e4-a5dc-6dbf45f327cc",
                    "LocationName": "West Loop",
                    "LocationId": "824edfa0-b25c-11e4-a057-6739eadd4561",
                    "Status": "Accepted"
                }
            ],
            "RequestNote": "test sections",
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Status": "InProgress",
            "AccessMode": "Reviewer",
            "TipUrl": "/files/ReceivingInput_AK_0607_1.pdf?"
        };
    }
    return {
      getSectionFeedback: getSectionFeedback
    };

});