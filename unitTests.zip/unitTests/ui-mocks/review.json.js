define(function(){

	function getMyReviews() {
		return {
			"Reviews": [
				{
					"youAre": "manager",
					"userId": "d2c052d0-a119-11e2-b177-7d64c8315189",
					"reviewee": "Demetri Maltsiniotis",
					"MyDueDate": 1385186400000,
					"CycleName": "sdsdsdsd",
					"hgId": "5754ac90-4d7b-11e3-906e-1bfdf8a272bd",
					"MySubmitDate": 1384467789271,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test questions for manager"
				},
				{
					"youAre": "manager",
					"userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
					"reviewee": "Katrina Manoshin",
					"MyDueDate": 1384581600000,
					"CycleName": "test 123",
					"hgId": "858c4080-4d5f-11e3-ad17-d904db88d068",
					"MySubmitDate": 1384455840901,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "assasa Copy 8"
				},
				{
					"youAre": "manager",
					"userId": "",
					"reviewee": "Gary Wei",
					"MyDueDate": 1382158800000,
					"CycleName": "test 123",
					"hgId": "10d4a8f0-3823-11e3-a5c8-a975498df066",
					"MySubmitDate": 1382120900862,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test manager subject pear"
				},
				{
					"youAre": "manager",
					"userId": "b1283100-b911-11e2-9ce1-b17fe9feb8ae",
					"reviewee": "Gary Wei",
					"MyDueDate": 1384927200000,
					"CycleName": "test 123",
					"hgId": "bd33e1e0-4d60-11e3-ad17-d904db88d068",
					"MySubmitDate": 1384456363773,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test review 4 sections"
				},
				{
					"youAre": "manager",
					"userId": "b1283100-b911-11e2-9ce1-b17fe9feb8ae",
					"reviewee": "Gary Wei",
					"MyDueDate": 1384840800000,
					"CycleName": "test 233223",
					"hgId": "bfb8e9a0-4d61-11e3-ad17-d904db88d068",
					"MySubmitDate": 1384456797496,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test review 4 sections"
				},
				{
					"youAre": "manager",
					"userId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"reviewee": "Gary Wei",
					"MyDueDate": 1384581600000,
					"CycleName": "test 1",
					"hgId": "5beb9bd0-4d65-11e3-ad17-d904db88d068",
					"MySubmitDate": 1384458348044,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test 1"
				},
				{
					"youAre": "manager",
					"userId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"reviewee": "Gary Wei",
					"MyDueDate": 1384754400000,
					"CycleName": "test 2",
					"hgId": "a518abe0-4d65-11e3-ad17-d904db88d068",
					"MySubmitDate": 1384458470814,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test 1"
				},
				{
					"youAre": "manager",
					"userId": "d2c24ea0-a119-11e2-b177-7d64c8315189",
					"reviewee": "Marcie Carlos",
					"MyDueDate": 1384668000000,
					"CycleName": "test 121212",
					"hgId": "e3ada110-4d7b-11e3-91c2-9f17509a3f12",
					"MySubmitDate": 1384468024734,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test submit"
				},
				{
					"youAre": "manager",
					"userId": "",
					"reviewee": "Miriam Diversiev",
					"MyDueDate": 1382158800000,
					"CycleName": "test 123",
					"hgId": "10d54530-3823-11e3-a5c8-a975498df066",
					"MySubmitDate": 1382120900867,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test manager subject pear"
				},
				{
					"youAre": "manager",
					"userId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"reviewee": "Gary Wei",
					"MyDueDate": 1384754400000,
					"CycleName": "test 1233",
					"hgId": "444c3110-4d60-11e3-ad17-d904db88d068",
					"MySubmitDate": 1384456160928,
					"MyPercentAchieved": 0,
					"Anonymous": false,
					"CardTitle": "test review 4 sections"
				}
			],
			"CycleTags": [
				"DEV Tags",
				"test"
			]
		};
	}
	function getMyEmpReviews() {
		return {
			"MyEmployees": [
			{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "214ff9b0-4d62-11e3-ad17-d904db88d068",
					"CycleId": "214f3660-4d62-11e3-ad17-d904db88d068",
					"CycleName": "test 1233",
					"CardTitle": "test review 4 sections",
					"DueDate": 1384668000000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "214ff9b0-4d62-11e3-ad17-d904db88d068",
					"CycleId": "214f3660-4d62-11e3-ad17-d904db88d068",
					"CycleName": "test 1233",
					"CardTitle": "test review 4 sections",
					"DueDate": 1384668000000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				},
				{
					"RevieweeName": "Gary Wei",
					"PercentAchieved": 100,
					"UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
					"hgId": "d70065d0-4d65-11e3-ad17-d904db88d068",
					"CycleId": "d6ff5460-4d65-11e3-ad17-d904db88d068",
					"CycleName": "test 3",
					"CardTitle": "test 1",
					"DueDate": 1384581600000,
					"Status": "Completed"
				}
		],
			"CycleTags": ['my Tags', 'your Tags']
		}
	}
    function getCyclesForPending () {
        return {
            "Reviews": [
                {
                    "youAre": "reviewee",
                    "userId": "",
                    "reviewee": "Cu Barnes",
                    "MyDueDate": 1382331600000,
                    "CycleName": "test 1223",
                    "hgId": "bb6e74b0-3997-11e3-a30a-8f7c935a2c1e",
                    "MySubmitDate": 1382280959867,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test review 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 3,
                    "AnsweredRequiredQuestions": 3
                },
                {
                    "youAre": "manager",
                    "userId": "b1283100-b911-11e2-9ce1-b17fe9feb8ae",
                    "reviewee": "Gary Wei",
                    "MyDueDate": 1384840800000,
                    "CycleName": "test 233223",
                    "hgId": "bfb8e9a0-4d61-11e3-ad17-d904db88d068",
                    "MySubmitDate": 1384456797496,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test review 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 1,
                    "AnsweredRequiredQuestions": 1
                },
                {
                    "youAre": "manager",
                    "userId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "reviewee": "Gary Wei",
                    "MyDueDate": 1384754400000,
                    "CycleName": "test 2",
                    "hgId": "a518abe0-4d65-11e3-ad17-d904db88d068",
                    "MySubmitDate": 1384458470814,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test 1",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 1,
                    "AnsweredRequiredQuestions": 1
                },
                {
                    "youAre": "manager",
                    "userId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "reviewee": "Gary Wei",
                    "MyDueDate": 1384754400000,
                    "CycleName": "test 1233",
                    "hgId": "444c3110-4d60-11e3-ad17-d904db88d068",
                    "MySubmitDate": 1384456160928,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test review 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 1,
                    "AnsweredRequiredQuestions": 1
                },
                {
                    "youAre": "manager",
                    "userId": "",
                    "reviewee": "Cezary Wojtkowski",
                    "MyDueDate": 1382072400000,
                    "CycleName": "errererweawefcds",
                    "hgId": "e9ec5b70-3741-11e3-8b94-6b9c04aa84d4",
                    "MySubmitDate": 1382024198823,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 5,
                    "AnsweredRequiredQuestions": 5
                },
                {
                    "youAre": "manager",
                    "userId": "",
                    "reviewee": "Gary Wei",
                    "MyDueDate": 1382072400000,
                    "CycleName": "errererweawefcds",
                    "hgId": "e9ec3460-3741-11e3-8b94-6b9c04aa84d4",
                    "MySubmitDate": 1382024198821,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 5,
                    "AnsweredRequiredQuestions": 5
                },
                {
                    "youAre": "manager",
                    "userId": "",
                    "reviewee": "Demetri Maltsiniotis",
                    "MyDueDate": 1382072400000,
                    "CycleName": "errererweawefcds",
                    "hgId": "e9ecf7b0-3741-11e3-8b94-6b9c04aa84d4",
                    "MySubmitDate": 1382024198826,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 5,
                    "AnsweredRequiredQuestions": 5
                },
                {
                    "youAre": "manager",
                    "userId": "",
                    "reviewee": "Amie Chen",
                    "MyDueDate": 1382072400000,
                    "CycleName": "errererweawefcds",
                    "hgId": "e9eca990-3741-11e3-8b94-6b9c04aa84d4",
                    "MySubmitDate": 1382024198824,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 5,
                    "AnsweredRequiredQuestions": 5
                },
                {
                    "youAre": "manager",
                    "userId": "",
                    "reviewee": "Erin Guenther",
                    "MyDueDate": 1382072400000,
                    "CycleName": "errererweawefcds",
                    "hgId": "e9ed1ec0-3741-11e3-8b94-6b9c04aa84d4",
                    "MySubmitDate": 1382024198827,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 5,
                    "AnsweredRequiredQuestions": 5
                },
                {
                    "youAre": "manager",
                    "userId": "b1283100-b911-11e2-9ce1-b17fe9feb8ae",
                    "reviewee": "Gary Wei",
                    "MyDueDate": 1384927200000,
                    "CycleName": "test 123",
                    "hgId": "bd33e1e0-4d60-11e3-ad17-d904db88d068",
                    "MySubmitDate": 1384456363773,
                    "MyPercentAchieved": 0,
                    "Anonymous": false,
                    "CardTitle": "test review 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 1,
                    "AnsweredRequiredQuestions": 0
                }
            ],
            "CycleTags": ['my Tags', 'your Tags']
        }
    }
    function getJsonForUtil() {
        return {
            "Reviews": [
                {
                    "youAre": "manager",
                    "userId": "",
                    "reviewee": "Erin Guenther",
                    "MyDueDate": 1382072400000,
                    "CycleName": "errererweawefcds",
                    "hgId": "e9ed1ec0-3741-11e3-8b94-6b9c04aa84d4",
                    "MySubmitDate": 1382024198827,
                    "MyPercentAchieved": 100,
                    "Anonymous": false,
                    "CardTitle": "test 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 5,
                    "AnsweredRequiredQuestions": 5
                },
                {
                    "youAre": "manager",
                    "userId": "b1283100-b911-11e2-9ce1-b17fe9feb8ae",
                    "reviewee": "Gary Wei",
                    "MyDueDate": 1384927200000,
                    "CycleName": "test 123",
                    "hgId": "bd33e1e0-4d60-11e3-ad17-d904db88d068",
                    "MySubmitDate": 1384456363773,
                    "MyPercentAchieved": 0,
                    "Anonymous": false,
                    "CardTitle": "test review 4 sections",
                    "TotalOptionalQuestions": 0,
                    "TotalRequiredQuestions": 1,
                    "AnsweredRequiredQuestions": 0
                }
            ],
            "CycleTags": ['my Tags', 'your Tags']
        }
    }
    function recognitionSummaryByCategory() {
    	return {
			"RecognitionsByTemplates": [
				{
					"hgId": "a243c090-8eb9-11e3-bc1e-0b93b1cd394d",
					"Count": 2,
					"Title": "004 Test Value default badge",
					"BadgeFilename": "a243e7a0-8eb9-11e3-bc1e-0b93b1cd394d_Platinum",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "566fbb20-8eb3-11e3-bc1e-0b93b1cd394d",
					"Count": 2,
					"Title": "002 Value with Sub",
					"BadgeFilename": "71204fc0-8eb3-11e3-bc1e-0b93b1cd394d_Gold",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "cbb5a890-8ebd-11e3-b1d0-7d8fa21b49ee",
					"Count": 2,
					"Title": "009 no sub",
					"BadgeFilename": "cbb5a890-8ebd-11e3-b1d0-7d8fa21b49ee_Platinum",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "64f2f740-8ebb-11e3-826a-83b79e9b53de",
					"Count": 2,
					"Title": "008 no sub",
					"BadgeFilename": "64f2f740-8ebb-11e3-826a-83b79e9b53de_Gold",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "fbaa9a90-8eba-11e3-826a-83b79e9b53de",
					"Count": 1,
					"Title": "007",
					"BadgeFilename": "4152f0b0-8ebb-11e3-826a-83b79e9b53de_Gold",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "4da29a10-8eba-11e3-b2ec-bb3cbe4faed2",
					"Count": 1,
					"Title": "005",
					"BadgeFilename": "4da29a11-8eba-11e3-b2ec-bb3cbe4faed2_Platinum",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "061ad590-8eba-11e3-b2ec-bb3cbe4faed2",
					"Count": 1,
					"Title": "005",
					"BadgeFilename": "061afca0-8eba-11e3-b2ec-bb3cbe4faed2_Gold",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "9dfb5030-8eb3-11e3-bc1e-0b93b1cd394d",
					"Count": 1,
					"Title": "002 Value with Sub",
					"BadgeFilename": "9dfb5031-8eb3-11e3-bc1e-0b93b1cd394d_Gold",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "43ef4010-8eb3-11e3-bc1e-0b93b1cd394d",
					"Count": 1,
					"Title": "001 Value",
					"BadgeFilename": "43ef4010-8eb3-11e3-bc1e-0b93b1cd394d_Gold",
					"FriendlyGroupId": 1
				},
				{
					"hgId": "2b023bc0-7fbd-11e3-92b1-4fece5207fe2",
					"Count": 1,
					"Title": "Value with Sub values",
					"BadgeFilename": "2b0262d1-7fbd-11e3-92b1-4fece5207fe2_Gold",
					"FriendlyGroupId": 1
				}
			],
			"TotalCount": 10,
			"BatchCount": 10
		};
    }
    function recognitionsByTemplate() {
    	return [
			{
				"hgId": "15dc18c0-9f51-11e3-856e-3fb942e04173",
				"CreatedDate": 1393465635916,
				"PublicCreatorInfo": {
					"Email": "",
					"CompanyName": "",
					"FullName": ""
				},
				"RecipientMember": {
					"FullName": "Amie Chen",
					"UserId": "3cf94310-9cd2-11e2-a3a4-25024474fe63",
					"hgId": "23310b40-9cd5-11e2-a3a4-25024474fe63"
				},
				"CreatorMember": {
					"FullName": "Marcie Carlos",
					"UserId": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
					"hgId": "2331f5a1-9cd5-11e2-a3a4-25024474fe63"
				},
				"Template": {
					"Category": "Values",
					"FriendlyGroupId": 1,
					"Title": "008 no sub",
					"hgId": "64f2f740-8ebb-11e3-826a-83b79e9b53de"
				},
				"LevelName": "Gold",
				"Message": "val - 106 from marcie",
				"BadgeFilename": "64f2f740-8ebb-11e3-826a-83b79e9b53de_Gold"
			},
			{
				"hgId": "8f858860-9f50-11e3-856e-3fb942e04173",
				"CreatedDate": 1393465410534,
				"PublicCreatorInfo": {
					"Email": "",
					"CompanyName": "",
					"FullName": ""
				},
				"RecipientMember": {
					"FullName": "Amie Chen",
					"UserId": "3cf94310-9cd2-11e2-a3a4-25024474fe63",
					"hgId": "23310b40-9cd5-11e2-a3a4-25024474fe63"
				},
				"CreatorMember": {
					"FullName": "Shihoko Ui",
					"UserId": "3cfaf0c0-9cd2-11e2-a3a4-25024474fe63",
					"hgId": "23313250-9cd5-11e2-a3a4-25024474fe63"
				},
				"Template": {
					"Category": "Values",
					"FriendlyGroupId": 1,
					"Title": "008 no sub",
					"hgId": "64f2f740-8ebb-11e3-826a-83b79e9b53de"
				},
				"LevelName": "Platinum",
				"Message": "Value - 101 from shihoko",
				"BadgeFilename": "64f2f740-8ebb-11e3-826a-83b79e9b53de_Platinum"
			}
		];
    } 
    function recognitionSummary () {
    	return {"EverydayExternal":1,"EverydayInternal":18,"Values":14,"Achievement":9};
    }   
	return {
		getMyReviews: getMyReviews,
		getMyEmpReviews: getMyEmpReviews,
        getCyclesForPending: getCyclesForPending,
        getJsonForUtil: getJsonForUtil,
        recognitionSummary: recognitionSummary,
        recognitionSummaryByCategory: recognitionSummaryByCategory,
        recognitionsByTemplate: recognitionsByTemplate
	};

});