define(function () {
    'use strict';
    function getLikers() {
        return {
            "congratMemberNames": "Cu Barnes",
            "recognitionId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
            "congratsCount": 1
        };
    }
    return {
        getLikers: getLikers
    };
});