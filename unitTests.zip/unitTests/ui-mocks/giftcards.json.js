define(function () {
	function getAvailableCodeGiftcardsByIssuer () {
		return [
		  {
		    "ModifiedDate": 1389637328210,
		    "ModifiedBy": "",
		    "CreatedDate": 1389637328210,
		    "CreatedBy": "",
		    "hgId": "",
		    "AvailableDenominations": [
		      {
		        "_id": "52d42ed03d0d72d0bd000077",
		        "AvailableNumber": 3,
		        "Denomination": 200,
		        "MaxAmount": 0,
		        "MinAmount": 0,
		        "TangoSKU": ""
		      },
		      {
		        "_id": "52d42ed03d0d72d0bd000078",
		        "AvailableNumber": 13,
		        "Denomination": 100,
		        "MaxAmount": 0,
		        "MinAmount": 0,
		        "TangoSKU": ""
		      },
		      {
		        "_id": "52d42ed03d0d72d0bd00007b",
		        "AvailableNumber": 18,
		        "Denomination": 50,
		        "MaxAmount": 0,
		        "MinAmount": 0,
		        "TangoSKU": ""
		      }
		    ],
		    "ImageFilename": "amazon.png",
		    "ImageUrl": "",
		    "CardType": "HighGround",
		    "Category": "Code",
		    "Issuer": {
		      "IssuerId": "e8d19b1d-8236-482d-9abb-5104c900b8a0",
		      "IssuerName": "Amazon"
		    }
		  },
		  {
		    "ModifiedDate": 1389637328213,
		    "ModifiedBy": "",
		    "CreatedDate": 1389637328213,
		    "CreatedBy": "",
		    "hgId": "",
		    "AvailableDenominations": [
		      {
		        "_id": "52d42ed03d0d72d0bd000079",
		        "AvailableNumber": 2,
		        "Denomination": 200,
		        "MaxAmount": 0,
		        "MinAmount": 0,
		        "TangoSKU": ""
		      },
		      {
		        "_id": "52d42ed03d0d72d0bd00007a",
		        "AvailableNumber": 1,
		        "Denomination": 25,
		        "MaxAmount": 0,
		        "MinAmount": 0,
		        "TangoSKU": ""
		      },
		      {
		        "_id": "52d42ed03d0d72d0bd00007c",
		        "AvailableNumber": 1,
		        "Denomination": 100,
		        "MaxAmount": 0,
		        "MinAmount": 0,
		        "TangoSKU": ""
		      },
		      {
		        "_id": "52d42ed03d0d72d0bd00007d",
		        "AvailableNumber": 5,
		        "Denomination": 50,
		        "MaxAmount": 0,
		        "MinAmount": 0,
		        "TangoSKU": ""
		      }
		    ],
		    "ImageFilename": "groupon.png",
		    "ImageUrl": "",
		    "CardType": "HighGround",
		    "Category": "Code",
		    "Issuer": {
		      "IssuerId": "20ac7ed8-7730-4da7-965e-25f42a3da65c",
		      "IssuerName": "Groupon"
		    }
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Amazon.com",
		      "IssuerName": "Amazon.com"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/amazon-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "AMZN-E-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "America Scores",
		      "IssuerName": "America Scores"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/america-scores-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "AMRS-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Apple iTunes",
		      "IssuerName": "Apple iTunes"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/itunes-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "APPL-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "APPL-E-1500-STD",
		        "Denomination": 15,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "APPL-E-2000-STD",
		        "Denomination": 20,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "APPL-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "APPL-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Best Buy",
		      "IssuerName": "Best Buy"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/best-buy-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "BSTB-E-500-STD",
		        "Denomination": 5,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "BSTB-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "BSTB-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "BSTB-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "BSTB-E-10000-STD",
		        "Denomination": 100,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Fandango",
		      "IssuerName": "Fandango"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/fandango-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "FAND-E-500-STD",
		        "Denomination": 5,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "FAND-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "FAND-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Gap",
		      "IssuerName": "Gap"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/gap-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "GAPP-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "GAPP-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "GAPP-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "GAPP-E-10000-STD",
		        "Denomination": 100,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Grameen",
		      "IssuerName": "Grameen"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/grameen-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "GRAM-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "GroupOn",
		      "IssuerName": "GroupOn"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/groupon-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "GRPN-E-1500-STD",
		        "Denomination": 15,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "GRPN-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "GRPN-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "GRPN-E-10000-STD",
		        "Denomination": 100,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Habitat for Humanity",
		      "IssuerName": "Habitat for Humanity"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/habitat-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "HABT-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "John Hopkins",
		      "IssuerName": "John Hopkins"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/johns-hopkins-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "JHNH-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Long Live the Kings",
		      "IssuerName": "Long Live the Kings"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/long-live-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "LLTK-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "National Parks Foundation",
		      "IssuerName": "National Parks Foundation"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/national-park-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "NTPF-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "REI",
		      "IssuerName": "REI"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/rei-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "REII-E-500-STD",
		        "Denomination": 5,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "REII-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "REII-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "REII-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "REII-E-10000-STD",
		        "Denomination": 100,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "REII-E-20000-STD",
		        "Denomination": 200,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Starbucks",
		      "IssuerName": "Starbucks"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/starbucks-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "SBUX-E-500-STD",
		        "Denomination": 5,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "SBUX-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "SBUX-E-1500-STD",
		        "Denomination": 15,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "SBUX-E-2000-STD",
		        "Denomination": 20,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "SBUX-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "SBUX-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Summer Search",
		      "IssuerName": "Summer Search"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/summer-search-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "SMRS-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Tango Card",
		      "IssuerName": "Tango Card"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/tango-card-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "TNGO-E-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 500000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Target",
		      "IssuerName": "Target"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/target-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "TRGT-E-500-BULS",
		        "Denomination": 5,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "TRGT-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "TRGT-E-1500-STD",
		        "Denomination": 15,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "TRGT-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "TRGT-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "TRGT-E-10000-STD",
		        "Denomination": 100,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Walmart",
		      "IssuerName": "Walmart"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/walmart-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "WALM-E-500-STD",
		        "Denomination": 5,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "WALM-E-1000-STD",
		        "Denomination": 10,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "WALM-E-1500-STD",
		        "Denomination": 15,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "WALM-E-2000-STD",
		        "Denomination": 20,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "WALM-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "WALM-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "WALM-E-10000-STD",
		        "Denomination": 100,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "World of Children",
		      "IssuerName": "World of Children"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/world-of-children-donation-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "WRLD-D-V-STD",
		        "Denomination": -1,
		        "MinAmount": 1,
		        "MaxAmount": 100000,
		        "AvailableNumber": 1
		      }
		    ]
		  },
		  {
		    "Issuer": {
		      "IssuerId": "Zappos",
		      "IssuerName": "Zappos"
		    },
		    "ImageUrl": "https://d30s7yzk2az89n.cloudfront.net/graphics/item-images/zappos-gift-card.png",
		    "Category": "Card",
		    "CardType": "Tango",
		    "AvailableDenominations": [
		      {
		        "TangoSKU": "ZAPO-E-1500-STD",
		        "Denomination": 15,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "ZAPO-E-2500-STD",
		        "Denomination": 25,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "ZAPO-E-5000-STD",
		        "Denomination": 50,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      },
		      {
		        "TangoSKU": "ZAPO-E-10000-STD",
		        "Denomination": 100,
		        "MinAmount": 0,
		        "MaxAmount": 0,
		        "AvailableNumber": 1
		      }
		    ]
		  }
		];
	}

	return {
		getAvailableCodeGiftcardsByIssuer: getAvailableCodeGiftcardsByIssuer
	}
});