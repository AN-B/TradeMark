define(function() {

    function getCycles() {
        return [{
            AvgGoalCompletePercentage: 72,
            ClosedPercentage: 44,
            OnTimePercentage: 43,
            ParticipantTypes: ["Company", "Team", "Member"],
            PendingClosure: false,
            PendingPercentage: 55,
            SetAndBeyondPercentage: 22,
            Status: "InProgress",
            Title: "Test",
            hgId: "852cfea0-03c4-11e5-838f-b1897568bb7a",
        }];
    }
    function getCycleDepartments() {
        return [{
            hgId: '1'
        }, {
            hgId: '2'
        }];
    }
    function getDeliveryMethods() {
        return [{
            ParticipantType: 'Company',
            CheckInFrequency: 'Daily',
            DeliveryDate: 1431199582358,
            SetDueDate: 1431199582358,
            SetDueInDays: 2,
            DeliveryTrigger: 'ByDate'
        }];
    }
    return {
        getCycles: getCycles,
        getCycleDepartments: getCycleDepartments,
        getDeliveryMethods: getDeliveryMethods
    };
});