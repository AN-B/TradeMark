!function() {
    var d3 = {
        version: "3.4.1"
    };
    d3.scale = {
        linear: function() {
            return {
                domain: function () {
                    return {
                        range: function () {
                            return {};
                        }
                    }
                }
            }
        }
    };
    d3.layout = {
        treemap: function () {
            return {
                size: function () {
                    return {
                        nodes: function () {
                            return {
                                sort: function () {
                                    return true;
                                }
                            }
                        }
                    };
                }
            };
        }
    };
    d3.select = function() {
        return {
            selectAll: function() {
                return true;
            },
            empty: function () {
                return true;
            },
            append: function () {
                return {
                    attr: function () {
                        return {
                            attr: function () {
                                return {
                                    style: function () {
                                        return {
                                            style: function () {
                                                return true;
                                            }
                                        };
                                    }
                                }
                            }
                        };
                    }
                }
            }
        }
    };

    d3.sum = function(arg) {
        return true;
    }

    d3.lab = function() {
        return true;
    };

    d3.functor = function(){
        return true;
    };
    d3.xhr = function(){
        return true;
    };

    d3.text = function () {
        return true;
    };
    d3.json = function(url, callback) {
        return callback();
    };
    function d3_json(request) {
        return true;
    }
    d3.html = function(url, callback) {
        return callback();
    };
    d3.xml = function () {
        return true;
    };
    if (typeof define === "function" && define.amd) {
        define(d3);
    } else if (typeof module === "object" && module.exports) {
        module.exports = d3;
    } else {
        this.d3 = d3;
    }
}();