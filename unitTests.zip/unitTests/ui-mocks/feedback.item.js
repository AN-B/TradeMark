define(function(){

    function get() {
        return {
            "hgId": "c6dbc1e0-0e42-11e6-a9bf-35811b11ff47",
            "CycleId": "617bca50-0e3f-11e6-a9bf-35811b11ff47",
            "CycleTitle": "test all options",
            "CycleDescription": "test all options",
            "ExpirationDate": 1463168664830,
            "Card": {
                "_id": "5723b3e6fb18e09775580406",
                "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "GroupName": "UAT Mercury Industries",
                "__v": 0,
                "SinglePageQuestion": false,
                "Description": "test all options",
                "Title": "test all options",
                "ModifiedDate": 1461957606221,
                "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": 1461957606219,
                "CreatedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "hgId": "617561b4-0e3f-11e6-a9bf-35811b11ff47",
                "Type": "General",
                "Questions": [
                    {
                        "QuestionHelp": "test 123",
                        "Question": "test 1",
                        "_id": "5723b3e6dd27bbc892575fc6",
                        "ModifiedDate": 1461957606219,
                        "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "CreatedDate": 1461957606219,
                        "CreatedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "hgId": "617561b0-0e3f-11e6-a9bf-35811b11ff47",
                        "SortOrder": 0,
                        "AnswerSelector": [

                        ],
                        "Answer": {
                            "SelectedValues": [

                            ]
                        },
                        "OptionalComment": false,
                        "Required": true,
                        "Type": "ShortAnswer"
                    },
                    {
                        "QuestionHelp": "",
                        "Question": "test 2",
                        "_id": "5723b3e6dd27bbc892575fc5",
                        "ModifiedDate": 1461957606219,
                        "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "CreatedDate": 1461957606219,
                        "CreatedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "hgId": "617561b1-0e3f-11e6-a9bf-35811b11ff47",
                        "SortOrder": 1,
                        "AnswerSelector": [
                            {
                                "Order": 0,
                                "Value": 0,
                                "Text": "Option 1"
                            },
                            {
                                "Order": 1,
                                "Value": 1,
                                "Text": "Option 2"
                            },
                            {
                                "Order": 2,
                                "Value": 2,
                                "Text": "Option 3"
                            },
                            {
                                "Order": 3,
                                "Value": 3,
                                "Text": "Option 4"
                            },
                            {
                                "Order": 4,
                                "Value": 4,
                                "Text": "Option 5"
                            },
                            {
                                "Order": 5,
                                "Value": 5,
                                "Text": "Option 6"
                            },
                            {
                                "Order": 6,
                                "Value": 6,
                                "Text": "Option 7"
                            }
                        ],
                        "Answer": {
                            "SelectedValues": [

                            ]
                        },
                        "OptionalComment": false,
                        "Required": true,
                        "Type": "RadioButton"
                    },
                    {
                        "NotApplicableOption": false,
                        "QuestionHelp": "",
                        "Question": "test 3",
                        "_id": "5723b3e6dd27bbc892575fc4",
                        "ModifiedDate": 1461957606219,
                        "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "CreatedDate": 1461957606219,
                        "CreatedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "hgId": "617561b2-0e3f-11e6-a9bf-35811b11ff47",
                        "SortOrder": 2,
                        "AnswerSelector": [
                            {
                                "Order": 0,
                                "Value": 0,
                                "Text": "Option 1"
                            },
                            {
                                "Order": 1,
                                "Value": 1,
                                "Text": "Option 2"
                            },
                            {
                                "Order": 2,
                                "Value": 2,
                                "Text": "Option 3"
                            },
                            {
                                "Order": 3,
                                "Value": 3,
                                "Text": "Option 4"
                            }
                        ],
                        "Answer": {
                            "SelectedValues": [

                            ]
                        },
                        "OptionalComment": true,
                        "Required": true,
                        "Type": "RatingScale"
                    },
                    {
                        "QuestionHelp": "",
                        "Question": "test 4",
                        "_id": "5723b3e6dd27bbc892575fc3",
                        "ModifiedDate": 1461957606219,
                        "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "CreatedDate": 1461957606219,
                        "CreatedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                        "hgId": "617561b3-0e3f-11e6-a9bf-35811b11ff47",
                        "SortOrder": 3,
                        "AnswerSelector": [
                            {
                                "Order": 0,
                                "Value": 0,
                                "Text": "Option 1"
                            },
                            {
                                "Order": 1,
                                "Value": 1,
                                "Text": "Option 2"
                            },
                            {
                                "Order": 2,
                                "Value": 2,
                                "Text": "Option 3"
                            },
                            {
                                "Order": 3,
                                "Value": 3,
                                "Text": "Option 4"
                            },
                            {
                                "Order": 4,
                                "Value": 4,
                                "Text": "Option 5"
                            }
                        ],
                        "Answer": {
                            "SelectedValues": [

                            ]
                        },
                        "OptionalComment": false,
                        "Required": true,
                        "Type": "CheckBox"
                    }
                ],
                "Status": "Active"
            },
            "Participants": [
                {
                    "ParticipantType": "Subject",
                    "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "FullName": "Cu Barnes",
                    "Role": "HGAdmin",
                    "DepartmentName": "Zomm1",
                    "DepartmentId": "fe45b8f0-f40a-11e4-99fc-6bc86d3fba1d",
                    "LocationName": "River North",
                    "LocationId": "51756460-b23b-11e4-9219-db713d08c4ee",
                    "Status": "Requesting"
                },
                {
                    "ParticipantType": "Reviewer",
                    "MemberId": "23318070-9cd5-11e2-a3a4-25024474fe63",
                    "UserId": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "FullName": "Gary Wei",
                    "Role": "HGAdmin",
                    "DepartmentName": "IT Department",
                    "DepartmentId": "eedeee60-b81c-11e4-a5dc-6dbf45f327cc",
                    "LocationName": "West Loop",
                    "LocationId": "824edfa0-b25c-11e4-a057-6739eadd4561",
                    "Status": "Requesting"
                }
            ],
            "RequestNote": "test 123",
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Status": "InProgress",
            "AccessMode": "Reviewer"
        };
    }

    return {
        get: get
    }

});