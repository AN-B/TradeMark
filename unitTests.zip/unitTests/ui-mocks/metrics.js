define(function(){
    function get() {
       return  {
            "Category": [
            "Jan.16",
            "Feb.16"
        ],
            "Recognitions": [
            0,
            0
        ],
            "TotalRecognitions": 0,
            "CommentRecognitions": [
            49,
            128
        ],
            "TotalComments": 177,
            "Likes": [
            1,
            0
        ],
            "TotalLikes": 1,
            "RecognitionCategories": [
            0
        ],
            "RecognitionCategory": [
            "Everyday"
        ],
            "CongratCategories": [
            1
        ],
            "CongratCategory": [
            "Gift"
        ],
            "RecognitionSource": {
            "Internal": 0
        },
            "DepartmentActivity": [
            {
                "name": "123",
                "value": 1,
                "active": 0
            },
            {
                "name": "213",
                "value": 4,
                "active": 0
            },
            {
                "name": "3 Members",
                "value": 4,
                "active": 0
            },
            {
                "name": "Application Department",
                "value": 24,
                "active": 0
            },
            {
                "name": "Automation Testing Department",
                "value": 5,
                "active": 0
            },
            {
                "name": "BACKEND DEPARTMENT",
                "value": 19,
                "active": 0
            },
            {
                "name": "Book1",
                "value": 12,
                "active": 0
            },
            {
                "name": "Copy of G-5",
                "value": 19,
                "active": 0
            },
            {
                "name": "Copy of GYd-001",
                "value": 10,
                "active": 0
            },
            {
                "name": "Finance Department Finance Department Finance Department",
                "value": 7,
                "active": 0
            },
            {
                "name": "G1",
                "value": 1,
                "active": 0
            },
            {
                "name": "GURU99!",
                "value": 28,
                "active": 0
            },
            {
                "name": "HGTeams_001",
                "value": 4,
                "active": 0
            },
            {
                "name": "HTP",
                "value": 4,
                "active": 0
            },
            {
                "name": "HighGround Enterprise Solutions, Inc.",
                "value": 4,
                "active": 0
            },
            {
                "name": "IT",
                "value": 10,
                "active": 0
            },
            {
                "name": "IT Department",
                "value": 52,
                "active": 0
            },
            {
                "name": "MH14",
                "value": 2,
                "active": 0
            },
            {
                "name": "Management Department",
                "value": 17,
                "active": 0
            },
            {
                "name": "Marcie's Department",
                "value": 2,
                "active": 0
            },
            {
                "name": "New department",
                "value": 29,
                "active": 0
            },
            {
                "name": "Product Department 2",
                "value": 6,
                "active": 0
            },
            {
                "name": "Product Engineering",
                "value": 24,
                "active": 0
            },
            {
                "name": "QA Test",
                "value": 17,
                "active": 0
            },
            {
                "name": "Regression Testing department",
                "value": 3,
                "active": 0
            },
            {
                "name": "Sale Deoartment",
                "value": 18,
                "active": 0
            },
            {
                "name": "Sale Team",
                "value": 5,
                "active": 0
            },
            {
                "name": "Sentiment Test",
                "value": 5,
                "active": 0
            },
            {
                "name": "Standing ovations",
                "value": 3,
                "active": 0
            },
            {
                "name": "T2",
                "value": 5,
                "active": 0
            },
            {
                "name": "Testing and Automation",
                "value": 2,
                "active": 0
            },
            {
                "name": "Testing_0022",
                "value": 2,
                "active": 0
            },
            {
                "name": "UI Department",
                "value": 10,
                "active": 0
            },
            {
                "name": "Zomm1",
                "value": 3,
                "active": 0
            }
        ],
            "Shares": [
            0,
            0
        ],
            "TotalShares": 0
        };
    }
    return {
        get: get
    }
});