(function(jQuery){
    jQuery.fn.spectrum = function(){
        return this;
    };
}(jQuery));