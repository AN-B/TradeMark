define(function () {
    function getAuditLogs() {
        return [{
            "_id": "56cc84a0ba6afed815bf13f5",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720dd",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf13f5"
        }, {
            "_id": "56cc8421ba6afed815bf13ef",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720dd",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf13ef"
        }, {
            "_id": "56cc83cbe342e5d015cac5da",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720dd",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac5da"
        }, {
            "_id": "56cc838be342e5d015cac5d5",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720dd",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac5d5"
        }, {
            "_id": "56cc7e5a25e8468715776d07",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720dd",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776d07"
        }, {
            "_id": "56cc84a0ba6afed815bf13ab",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720ab",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf13ab"
        }, {
            "_id": "56cc8421ba6afed815bf13cd",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720cd",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf13cd"
        }, {
            "_id": "56cc83cbe342e5d015cac5ef",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720ef",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac5ef"
        }, {
            "_id": "56cc838be342e5d015cac5gh",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720gh",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac5gh"
        }, {
            "_id": "56cc7e5a25e8468715776dij",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720ij",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776dij"
        }, {
            "_id": "56cc84a0ba6afed815bf13kl",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720kl",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf13kl"
        }, {
            "_id": "56cc8421ba6afed815bf13mn",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720mn",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf13mn"
        }, {
            "_id": "56cc83cbe342e5d015cac5op",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720op",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac5op"
        }, {
            "_id": "56cc838be342e5d015cac5qr",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720qr",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac5qr"
        }, {
            "_id": "56cc7e5a25e8468715776dst",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720st",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776dst"
        }, {
            "_id": "56cc84a0ba6afed815bf13uv",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720uv",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf13uv"
        }, {
            "_id": "56cc8421ba6afed815bf13wx",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720wx",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf13wx"
        }, {
            "_id": "56cc83cbe342e5d015cac5yz",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720yz",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac5yz"
        }, {
            "_id": "56cc838be342e5d015cac511",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672011",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac511"
        }, {
            "_id": "56cc7e5a25e8468715776d22",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672022",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776d22"
        }, {
            "_id": "56cc84a0ba6afed815bf1333",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672033",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf1333"
        }, {
            "_id": "56cc8421ba6afed815bf1344",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672044",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf1344"
        }, {
            "_id": "56cc83cbe342e5d015cac555",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672055",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac555"
        }, {
            "_id": "56cc838be342e5d015cac566",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672066",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac566"
        }, {
            "_id": "56cc7e5a25e8468715776d07",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672077",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776d77"
        }, {
            "_id": "56cc84a0ba6afed815bf1388",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672088",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf1388"
        }, {
            "_id": "56cc8421ba6afed815bf1399",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672099",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf1399"
        }, {
            "_id": "56cc83cbe342e5d015cac512",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672012",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac512"
        }, {
            "_id": "56cc838be342e5d015cac534",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672034",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac534"
        }, {
            "_id": "56cc7e5a25e8468715776d56",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672056",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776d56"
        }, {
            "_id": "56cc84a0ba6afed815bf1378",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672078",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf1378"
        }, {
            "_id": "56cc8421ba6afed815bf1390",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc64672090",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf1390"
        }, {
            "_id": "56cc83cbe342e5d015cac51a",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467201a",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac51a"
        }, {
            "_id": "56cc838be342e5d015cac52b",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467202b",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac52b"
        }, {
            "_id": "56cc7e5a25e8468715776d3c",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467203c",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776d3c"
        }, {
            "_id": "56cc84a0ba6afed815bf134d",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467204d",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf134d"
        }, {
            "_id": "56cc8421ba6afed815bf135e",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467205e",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf135e"
        }, {
            "_id": "56cc83cbe342e5d015cac56f",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467206f",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac56f"
        }, {
            "_id": "56cc838be342e5d015cac57h",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467207h",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac57h"
        }, {
            "_id": "56cc7e5a25e8468715776d8i",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467208i",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776d8i"
        }, {
            "_id": "56cc84a0ba6afed815bf139j",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467209j",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf139j"
        }, {
            "_id": "56cc8421ba6afed815bf130k",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc6467200k",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf130k"
        }, {
            "_id": "56cc83cbe342e5d015cac5a1",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720a1",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac5a1"
        }, {
            "_id": "56cc838be342e5d015cac5b2",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720b2",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac5b2"
        }, {
            "_id": "56cc7e5a25e8468715776dc3",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720c3",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776dc3"
        }, {
            "_id": "56cc84a0ba6afed815bf13d4",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720d4",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Manager"]
            },
            "CreatedDate": 1456243872892,
            "id": "56cc84a0ba6afed815bf13d4"
        }, {
            "_id": "56cc8421ba6afed815bf13e5",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720e5",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243745652,
            "id": "56cc8421ba6afed815bf13e5"
        }, {
            "_id": "56cc83cbe342e5d015cac5f6",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720f6",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            },
            "CreatedDate": 1456243659021,
            "id": "56cc83cbe342e5d015cac5f6"
        }, {
            "_id": "56cc838be342e5d015cac5g7",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720g7",
            "FullName": "API Update",
            "Activity": {
                "OldRole": ["Executive"],
                "NewRole": ["Admin"]
            },
            "CreatedDate": 1456243595098,
            "id": "56cc838be342e5d015cac5g7"
        }, {
            "_id": "56cc7e5a25e8468715776dh8",
            "EntityId": "42b85af2-a8c5-11e5-82c9-49bc646720h8",
            "FullName": "Marcie Carlos",
            "Activity": {
                "OldRole": ["Admin"],
                "NewRole": ["Executive"]
            }, "CreatedDate": 1456242266258,
            "id": "56cc7e5a25e8468715776dh8"
        }];
    }

    function getMemberRoles() {
        return ['OffBoarded', 'Employee', 'Manager', 'Director',
            'Executive', 'Admin', 'Owner', 'ResellerAdmin'];
    }

    return {
        getAuditLogs: getAuditLogs,
        getMemberRoles: getMemberRoles
    }
});