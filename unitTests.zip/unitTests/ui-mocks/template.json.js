define(function(){

    function getBenchmarkSurveyTemplate() {
		return {
			"UberQuestion":{
				"Status":"Active",
				"Type":"System",
				"Question":{
					"Translation":[],
					"Text":"I am committed to working at HighGround."
				},
				"MinLabelAnswer":{
					"Translation":[],
					"Text":"Strongly Disagree"
				},
				"MaxLabelAnswer":{
					"Translation":[],
					"Text":"Strongly Agree"
				},
				"hgId":"8ea31d21-e772-11e4-8b9c-21afbdb7637b",
				"CreatedBy":"",
				"CreatedDate":1429543993330,
				"ModifiedBy":"",
				"ModifiedDate":1429543993330,
				"Driver":{
					"hgId":"8ea31d22-e772-11e4-8b9c-21afbdb7637b",
					"Name":"Engagement",
					"Description":"Engagement Description ...."
				},
				"BenchmarkQuestionType":"Uber"
			},
			"__v":0,
			"ModifiedDate":1429543993332,
			"ModifiedBy":"",
			"CreatedDate":1429543993332,
			"CreatedBy":"",
			"hgId":"8ea31d20-e772-11e4-8b9c-21afbdb7637b",
			"DriverQuestions":[
			{
				"hgId":"8ea34430-e772-11e4-8b9c-21afbdb7637b",
				"MinLabelAnswer":{
					"Text":"Strongly Disagree"
				},
				"MaxLabelAnswer":{
					"Text":"Strongly Agree"
				},
				"BenchmarkQuestionType":"Driver",
				"Status":"Active",
				"Type":"System",
				"Driver":{
					"hgId":"8ea36b40-e772-11e4-8b9c-21afbdb7637b",
					"Name":"Goal Clarity",
					"Description":"Goal Clarity Description ...."
				}
			}],
			"Description":{
				"Translation":[]
			},
			"Title":{
				"Text":"HighGround Benchmark Survery",
				"Translation":[]
			},
			"Status":"Active",
			"Type":"Benchmark"
		};
	}
	return {
		getBenchmarkSurveyTemplate: getBenchmarkSurveyTemplate
	}
});