define(function(){

    function getSurveyDrivers(){
        return [
            {
                "hgId":"a2bf5070-e449-11e4-a184-87fb91927d2e",
                "Name":"Test 1 Compensation",
                "Description":"Compensation Descripton ......"
            },
            {
                "hgId":"4dd48f30-e539-11e4-ae84-fdfce471a362",
                "Name":"Test 2 Custom Driver",
                "Description":"Custom to b used by Admins"
            },
            {
                "hgId":"a2bf5076-e449-11e4-a184-87fb91927d2e",
                "Description":"Goal Clarity Descripton ......",
                "Name":"Test 3 Goal Clarity"
            },
            {
                "hgId":"a2bf5071-e449-11e4-a184-87fb91927d2e",
                "Description":"Growth and Development Descripton ......",
                "Name":"Test 5 Growth and Development"
            }
        ];
    }
    return {
        getSurveyDrivers: getSurveyDrivers
    };
});