define(function () {
    function getAvailableServices() {
        return {
            "1.0": ["default", "Recognition", "EventBus"]
        }
    }

    function getClientAPIKeys() {
        return [
            {
                "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "APIKeyVersion": "1.0",
                "APIKey": "35fc1940-74c9-11e4-91d7-2bcdb6c76b20",
                "AvailableServices": ["EventBus", "Recognition"],
                "APIKeyLastAccessedAt": 1416898498776,
                "APIKeyStatus": "Active"
            }
        ]
    }

    function getNewAPIKey() {
        return {
            "APIKeyVersion":"1.0",
            "APIKey":"6d6ff941-74f2-11e4-97aa-1d8c3509da9a",
            "GroupId":"3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "AvailableServices":["Recognition"],
            "APIKeyLastAccessedAt":1416954529492,
            "APIKeyStatus":"Active"
        }
    }

    return {
        getAvailableServices: getAvailableServices,
        getClientAPIKeys: getClientAPIKeys,
        getNewAPIKey: getNewAPIKey
    };
});