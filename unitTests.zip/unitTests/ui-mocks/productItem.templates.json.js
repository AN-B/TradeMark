define(function() {
    function getAll() {
        return [
            {
                "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "FriendlyGroupId": 1,
                "AvailableNumber": 10,
                "PointCost": 2000,
                "Name": "Non Expiring Product Item",
                "hgId": "21f61c10-c403-11e3-a9c0-71c4281b4207",
                "ProductImageFile": "goat.jpg",
                "Status": 'Active',
                "ProductType" : 'Store',
                "Accessibility" : {
                    "RestrictByDept": true,
                    "RestrictByLocation": true,
                    Departments: ['abc'],
                    Locations: ['abc']
                },
                "restrictDepartment": true,
                "restrictLocation": true
            },
            {
                "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "FriendlyGroupId": 1,
                "AvailableNumber": 10,
                "PointCost": 2000,
                "Description": "Product Item with no expire date",
                "Name": "Non Expiring Product Item",
                "hgId": "5f4dd850-c403-11e3-a9c0-71c4281b4207",
                "Accessibility" : {
                    "RestrictByDept": false,
                    "RestrictByLocation": false,
                    Departments: [],
                    Locations: []
                }
            },
            {
                "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "FriendlyGroupId": 1,
                "AvailableNumber": 10,
                "PointCost": 2000,
                "Description": "Product Item with no expire date",
                "Name": "Suggested product item",
                "hgId": "5f4dd850-c403-11e3-a9c0-71c4281b4208",
                "ProductImageFile": "goat.jpg",
                "Status": 'ApprovalPending',
                "ProductType" : 'Store',
                "Accessibility" : {
                    "RestrictByDept": false,
                    "RestrictByLocation": false,
                    Departments: [],
                    Locations: []
                }
            }
        ]
    }

    function getAllCampaignItems() {
        return [
            {
                "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "FriendlyGroupId": 1,
                "AvailableNumber": 1,
                "Description": "Product Item with no expire date 1",
                "Name": "Non Expiring Product Item 1",
                "hgId": "21f61c10-c403-11e3-a9c0-71c4281b4208",
                "ProductImageFile": "goat.jpg",
                "ExpireDate": 1425061800000.000000,
                "PledgedPoint": 10,
                "Status": 'Active',
                "ProductType" : 'Campaign',
                "CampaignItem": {
                    PledgedPrice: 10,
                    FundingGoal: 100,
                    Backers : [
                        {
                            "PledgePoint" : 2,
                            "LastName" : "Kumar Dewangan",
                            "FirstName" : "Pankaj",
                            "FullName" : "Pankaj Kumar Dewangan",
                            "UserId" : "a47799b0-3e43-11e4-928f-9facd4e65c8b",
                            "MemberId" : "a47799b2-3e43-11e4-928f-9facd4e65c8b"
                        }
                    ]
                },
                "Owner" : {
                    UserId : '3cf80a90-9cd2-11e2-a3a4-25024474fe63',
                    MemberId : '9852e220-8840-11e3-8afa-93a5651e7795'
                },
                "Accessibility" : {
                    "RestrictByDept": false,
                    "RestrictByLocation": false,
                    Departments: [],
                    Locations: []
                }
            }
        ]
    }


    function getCampaign() {
        return {
            "Description": "New Campaign Item Description",
            "Name": "New Campaign Item",
            "Status": 'Active',
            "ProductType" : 'Campaign',
            "ProductImageFile": "goat.jpg",
            "ExpireDate": "1416249000000.000000",
            "CampaignItem": {
                PledgedPrice: 10,
                FundingGoal: 100
            },
            "Owner" : {
                UserId : '3cf80a90-9cd2-11e2-a3a4-25024474fe63',
                MemberId : '9852e220-8840-11e3-8afa-93a5651e7795'
            },
            "Accessibility" : {
                "RestrictByDept": false,
                "RestrictByLocation": false,
                Departments: [],
                Locations: []
            }
        }
    }
    function getNew() {
        return {
            "AvailableNumber": 10,
            "PointCost": 2000,
            "Description": "New Product Item",
            "Name": "Non Expiring Product Item",
            "Status": 'Active',
            "ProductType" : 'Store',
            "ProductImageFile": "goat.jpg",
            "Accessibility" : {
                "RestrictByDept": false,
                "RestrictByLocation": false,
                Departments: [],
                Locations: []
            }
        }
    }
    function suggestNew() {
        return [{
            "AvailableNumber": 10,
            "PointCost": 2000,
            "Description": "New Product Item",
            "Name": "Non Expiring Product Item",
            "ProductImageFile": "goat.jpg",
            "Owner" : {
                UserId : '3cf80a90-9cd2-11e2-a3a4-25024474fe63',
                MemberId : '9852e220-8840-11e3-8afa-93a5651e7795'
            }
        }];
    }
    return {
        getAll: getAll,
        getAllCampaignItems: getAllCampaignItems,
        getCampaign: getCampaign,
        getNew: getNew,
        suggestNew : suggestNew
    };
});