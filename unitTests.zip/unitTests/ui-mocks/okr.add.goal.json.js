define(function () {
    function getModel() {
        return {
            KeyResults: [{
                Measure: 'Percentage',
                Target: 0,
                edit: true
            }]
        };
    }

    function getAlignGoalCandidates() {
        return [
            {
                "GoalId": "dbc0bf70-0aec-11e5-ab2a-7d91bbc4935d",
                "Name": "Drink More Beer",
                "ParticipantType": "Company"
            }
        ];
    }

    function getCycleById() {
        return {
        };
    }

    function getCollaboratorsByGoalId() {
        return {
            TotalNumber: 0,
            Collaborators: []
        };
    }

    return {
        getModel: getModel,
        getAlignGoalCandidates: getAlignGoalCandidates,
        getCycleById: getCycleById,
        getCollaboratorsByGoalId: getCollaboratorsByGoalId
    };
});