define(function(){
	function getTemplates() {
		return [{
		    "_id": "5189234c8751480200000033",
		    "ApprovalLevel": "",
		    "ApproverMemberSummary": "",
		    "ExperienceValue": 10,
		    "IsPublic": true,
		    "Publicity": "Public",
		    "Tags": "Public Recognition",
		    "TeamId": "",
		    "__v": 0,
		    "ModifiedDate": 1367971685264,
		    "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
		    "CreatedDate": 1367941873949,
		    "CreatedBy": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
		    "hgId": "2859ab40-b72e-11e2-a789-3de6b536f51c",
		    "RestrictUsers": {
		        "MemberIds": [],
		        "TeamIds": []
		    },
		    "Levels": [],
		    "AchievementLevelEnabled": false,
		    "SubValues": [],
		    "DefaultGivenToNewMembers": false,
		    "ApproverMemberId": -1,
		    "AccessLevel": "WithinGroup",
		    "Type": "Recognition",
		    "SubCategory": "Default",
		    "Category": "Everyday",
		    "GroupName": "Mercury Industries",
		    "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
		    "FriendlyGroupId": 1,
		    "PointValue": 0,
		    "CreditValue": 0,
		    "Description": "Public Recognition",
		    "DepartmentName": "",
		    "Title": "Problem Solver"
		}, {
		    "_id": "518923768751480200000034",
		    "ApprovalLevel": "",
		    "ApproverMemberSummary": "",
		    "ExperienceValue": 10,
		    "IsPublic": true,
		    "Publicity": "Public",
		    "Tags": "public",
		    "TeamId": "",
		    "__v": 0,
		    "ModifiedDate": 1367979244214,
		    "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
		    "CreatedDate": 1367941873949,
		    "CreatedBy": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
		    "hgId": "41126780-b72e-11e2-a789-3de6b536f51c",
		    "RestrictUsers": {
		        "MemberIds": [],
		        "TeamIds": []
		    },
		    "Levels": [],
		    "AchievementLevelEnabled": false,
		    "SubValues": [],
		    "DefaultGivenToNewMembers": false,
		    "ApproverMemberId": -1,
		    "AccessLevel": "WithinGroup",
		    "Type": "Recognition",
		    "SubCategory": "Default",
		    "Category": "Everyday",
		    "GroupName": "Mercury Industries",
		    "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
		    "FriendlyGroupId": 1,
		    "PointValue": 0,
		    "CreditValue": 0,
		    "Description": "Customer Service",
		    "DepartmentName": "",
		    "Title": "Speedy Service"
		}, {
		    "_id": "51913cbd5cc7c40200000037",
		    "ApprovalLevel": "",
		    "ApproverMemberSummary": "",
		    "ExperienceValue": 0,
		    "IsPublic": true,
		    "Publicity": "Public",
		    "Tags": "Public Recognition",
		    "TeamId": "",
		    "__v": 0,
		    "ModifiedDate": 1368472599035,
		    "ModifiedBy": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
		    "CreatedDate": 1368472599035,
		    "CreatedBy": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
		    "hgId": "062a5410-bc02-11e2-a8a4-1d8f4152a782",
		    "RestrictUsers": {
		        "MemberIds": [],
		        "TeamIds": []
		    },
		    "Levels": [],
		    "AchievementLevelEnabled": false,
		    "SubValues": [],
		    "DefaultGivenToNewMembers": false,
		    "ApproverMemberId": -1,
		    "AccessLevel": "WithinGroup",
		    "Type": "Recognition",
		    "SubCategory": "Default",
		    "Category": "Everyday",
		    "GroupName": "Mercury Industries",
		    "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
		    "FriendlyGroupId": 1,
		    "PointValue": 0,
		    "CreditValue": 0,
		    "Description": "Public Recognition",
		    "DepartmentName": "",
		    "Title": "Professional Service"
		}];
	}
	function GetPublicUserInfoByMemberId() {
		return {
		    "FullName": "Marcie Carlos",
		    "PublicDisplayName": "HighGround Enterprise Solutions, Inc.",
		    "FirstName": "Marcie",
		    "UserId": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
		    "GroupDepartmentName": "QA",
		    "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
		    "hgId": "2331f5a1-9cd5-11e2-a3a4-25024474fe63",
		    "ShowPublicRecognitions": false
		};
	}
	function messages() {
		return [{
		    "cat": "General",
		    "msg": "Has a very hot rapport"
		}, {
		    "cat": "General",
		    "msg": "Identifies practical solutions"
		}, {
		    "cat": "General",
		    "msg": "Has become the \"go to person\" for advice to solve problems"
		}, {
		    "cat": "General",
		    "msg": "Addresses problem issues head on in a proactive fashion"
		}, {
		    "cat": "General",
		    "msg": "Shows patience in dealing with complex and time consuming issues"
		}];
	}
	return {
		GetPublicUserInfoByMemberId: GetPublicUserInfoByMemberId,
		getTemplates: getTemplates,
		messages: messages
	}
});

