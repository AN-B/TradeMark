define(function(){


	function get() {
		return {
            "feeds": [
                {
                    "hgId": [
                        "4d7e26a1-9985-11e3-a57e-ef0c5cd920f3"
                    ],
                    "batchId": "4d7e26a0-9985-11e3-a57e-ef0c5cd920f3",
                    "badgeUrl": "/badges/group/500/b120f920-8ac7-11e3-bb56-f5fcef8ffb98",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 0,
                    "message": "test",
                    "congratMemberIds": [],
                    "isCongrats": false,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "rtffg",
                    "createdDate": 1392828356106,
                    "modifiedDate": 1392828356106,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "c94c23f0-9984-11e3-a57e-ef0c5cd920f3"
                    ],
                    "batchId": "c94bfce0-9984-11e3-a57e-ef0c5cd920f3",
                    "badgeUrl": "/badges/group/500/b120f920-8ac7-11e3-bb56-f5fcef8ffb98",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 0,
                    "message": "test",
                    "congratMemberIds": [],
                    "isCongrats": false,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "rtffg",
                    "createdDate": 1392828134319,
                    "modifiedDate": 1392828134319,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "e7426320-9983-11e3-a57e-ef0c5cd920f3"
                    ],
                    "batchId": "e7423c10-9983-11e3-a57e-ef0c5cd920f3",
                    "badgeUrl": "/badges/group/500/37f5fdc0-8ac7-11e3-bb56-f5fcef8ffb98",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 0,
                    "message": "Test",
                    "congratMemberIds": [],
                    "isCongrats": false,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "dffddf",
                    "createdDate": 1392827755090,
                    "modifiedDate": 1392827755090,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "d6b68c21-9983-11e3-a57e-ef0c5cd920f3"
                    ],
                    "batchId": "d6b68c20-9983-11e3-a57e-ef0c5cd920f3",
                    "badgeUrl": "/badges/group/500/b120f920-8ac7-11e3-bb56-f5fcef8ffb98",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 0,
                    "message": "Test",
                    "congratMemberIds": [],
                    "isCongrats": false,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "rtffg",
                    "createdDate": 1392827727330,
                    "modifiedDate": 1392827727330,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "79300401-926c-11e3-9042-e5ad2148604b"
                    ],
                    "batchId": "79300400-926c-11e3-9042-e5ad2148604b",
                    "badgeUrl": "/badges/group/500/37f5fdc0-8ac7-11e3-bb56-f5fcef8ffb98",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 0,
                    "message": "dssdds",
                    "congratMemberIds": [],
                    "isCongrats": false,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "dffddf",
                    "createdDate": 1392048033856,
                    "modifiedDate": 1392048033856,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "d6f5dab0-8abf-11e3-b1ac-871b113ebb36"
                    ],
                    "batchId": "d6f5b3a0-8abf-11e3-b1ac-871b113ebb36",
                    "badgeUrl": "/badges/group/500/69f99da0-78bf-11e3-a70e-bbadf182d203_Platinum",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "c15b0c70-aea6-11e2-b79d-512ef31a350a",
                            "userId": "c13cfd20-aea6-11e2-b79d-512ef31a350a",
                            "fullName": "Miriam Diversiev"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 1,
                    "message": "dfdfdf",
                    "congratMemberIds": [
                        "d2e0d320-a119-11e2-b177-7d64c8315189"
                    ],
                    "isCongrats": true,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "test 1",
                    "createdDate": 1391204230107,
                    "modifiedDate": 1391204230107,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "bf668040-886f-11e3-bb52-99c17e85e396"
                    ],
                    "batchId": "bf665930-886f-11e3-bb52-99c17e85e396",
                    "badgeUrl": "/badges/group/500/81b06890-6bed-11e3-9f06-63cc7d70bea1",
                    "teamRecognition": false,
                    "isPublic": true,
                    "recipients": [
                        {
                            "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                            "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                            "fullName": "Cu Barnes"
                        }
                    ],
                    "issuer": {
                        "hgId": "",
                        "userId": "",
                        "fullName": "Larry Flint",
                        "companyName": "Flint company",
                        "email": "larry@highground.com"
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 2,
                    "message": "Tuan regularly asks for immediate feedback to ensure understanding.",
                    "congratMemberIds": [
                        "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "d2defe60-a119-11e2-b177-7d64c8315189"
                    ],
                    "isCongrats": true,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "The Right Sector issued a statement saying that the new anti-prot",
                    "createdDate": 1390949928515,
                    "modifiedDate": 1390949928515,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "ca250001-8776-11e3-b226-49b0016170ec"
                    ],
                    "batchId": "ca250000-8776-11e3-b226-49b0016170ec",
                    "badgeUrl": "/badges/group/500/ca20ba40-8776-11e3-b226-49b0016170ec",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 1,
                    "message": "sddssd",
                    "congratMemberIds": [
                        "d2e0d320-a119-11e2-b177-7d64c8315189"
                    ],
                    "isCongrats": true,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "sdsd",
                    "createdDate": 1390843001856,
                    "modifiedDate": 1390843001856,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "f2720950-8775-11e3-b226-49b0016170ec"
                    ],
                    "batchId": "f271e240-8775-11e3-b226-49b0016170ec",
                    "badgeUrl": "/badges/group/500/81b06890-6bed-11e3-9f06-63cc7d70bea1",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 1,
                    "message": "sddssd",
                    "congratMemberIds": [
                        "d2e0d320-a119-11e2-b177-7d64c8315189"
                    ],
                    "isCongrats": true,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "The Right Sector issued a statement saying that the new anti-prot",
                    "createdDate": 1390842639973,
                    "modifiedDate": 1390842639973,
                    "suppressInFeed": false
                },
                {
                    "hgId": [
                        "b0eb5820-876f-11e3-8493-457d8d3c5ef5",
                        "b0e9d180-876f-11e3-8493-457d8d3c5ef5"
                    ],
                    "batchId": "b0e9aa70-876f-11e3-8493-457d8d3c5ef5",
                    "badgeUrl": "/badges/group/500/81b06890-6bed-11e3-9f06-63cc7d70bea1",
                    "teamRecognition": true,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2de3b11-a119-11e2-b177-7d64c8315189",
                            "userId": "d2c44a70-a119-11e2-b177-7d64c8315189",
                            "fullName": "Liliana Zektser"
                        },
                        {
                            "hgId": "d2de3b10-a119-11e2-b177-7d64c8315189",
                            "userId": "d2c38720-a119-11e2-b177-7d64c8315189",
                            "fullName": "Philip Plekhanov"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [],
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 2,
                    "message": "sssdsds",
                    "congratMemberIds": [
                        "d2e0d320-a119-11e2-b177-7d64c8315189"
                    ],
                    "isCongrats": true,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "The Right Sector issued a statement saying that the new anti-prot",
                    "createdDate": 1390839953058,
                    "modifiedDate": 1390839953058,
                    "suppressInFeed": false,
                    "shareCount": null
                },
                {
                    "hgId": [
                        "c94c23f0-9984-11e3-a57e-ef0c5cd920f3"
                    ],
                    "batchId": "76b421c0-9a73-11e3-a710-595fa25447be",
                    "badgeUrl": "/badges/group/500/b120f920-8ac7-11e3-bb56-f5fcef8ffb98",
                    "teamRecognition": false,
                    "isPublic": false,
                    "recipients": [
                        {
                            "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                            "userId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                            "fullName": "Katrina Manoshin"
                        }
                    ],
                    "issuer": {
                        "hgId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                        "userId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "fullName": "Cu Barnes",
                        "companyName": "Mercury",
                        "email": ""
                    },
                    "comments": [{
                        "hgId": "c94c23f0-9984-11e3-a57e-ef0c5cd920f3",
                        "EntityId": "c94c23f0-9984-11e3-a57e-ef0c5cd920f3",
                        "CommenterUserhgId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                        "CommenterFirstName": "Tuan",
                        "CommenterLastName": "Pham-Barnes",
                        "CreatedDate": "Pham-Barnes",
                        "Comment": "old comment",
                        "TaggedUser": [
                            {
                                "_id": "5671c3e5880731a76cbbe1f7",
                                "__v": 0,
                                "ModifiedDate": 1450296293406,
                                "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                                "CreatedDate": 1450296293406,
                                "CreatedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                                "hgId": "45612cd0-a430-11e5-b762-bf8a6acf7a53",
                                "Tags": [
                                    {
                                        "UserId": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                                        "_id": "5671c3e523ec24a76c5e7692"
                                    },
                                    {
                                        "UserId": "3cf412f0-9cd2-11e2-a3a4-25024474fe63",
                                        "_id": "5671c3e523ec24a76c5e7691"
                                    }
                                ]
                            }
                        ],
                        "newComment": {"comment": {"html": "its a new comment"}},
                        "ModifiedDate": 1423216592090.000000,
                        "UserId": "d2c0ef10-a119-11e2-b177-7d64c8315189"
                    }],
                    "newComment": {"comment": {"html": "its a new comment"}},
                    "ShareCount": 0,
                    "commentCount": 0,
                    "congratsCount": 0,
                    "message": "test",
                    "congratMemberIds": [],
                    "isCongrats": false,
                    "creditValue": 0,
                    "actualCreditValue": 0,
                    "actualPointValue": 0,
                    "type": "Recognition",
                    "title": "rtffg",
                    "createdDate": 1392828356106,
                    "modifiedDate": 1392828356106,
                    "suppressInFeed": false
                }
            ]
        }
	}
    function commentJson() {
        return {
            "_id": "567821ade95f030c826afb9c",
                "Comment": "Hello <div user-link=\"19e886d2-082c-11e4-889a-4b6365100230\" style=\"display:inline-block;\" contenteditable=\"false\" readonly=\"\">Adi khanna<\/div>&nbsp;and me",
                "EntityId": "1b9910e0-9d0d-11e5-bb02-81786bc333fd",
                "ReasonCode": "",
                "__v": 0,
                "ModifiedDate": 1450713517335,
                "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate": 1450713517335,
                "CreatedBy": "e46a1cf6-832b-11e5-96ce-8d46d7a442a3",
                "TaggedUser": [
                "567821ade95f030c826afb9b"
            ],
                "Source": "Web",
                "LikedCount": 0,
                "LikedMembers": [

            ],
                "MilestoneFriendlyGroupId": -1,
                "Attachments": {
                "Description": "",
                    "Title": "",
                    "ImgSrc": "",
                    "Url": "",
                    "OrderId": ""
            },
            "HasAttachment": false,
                "Type": "Comment",
                "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "Recipients": [

            ],
                "ReadBy": [

            ],
                "MemberId": "e46a1cf8-832b-11e5-96ce-8d46d7a442a3",
                "CommenterUserhgId": "e46a1cf6-832b-11e5-96ce-8d46d7a442a3",
                "CommenterLastName": "test",
                "CommenterFirstName": "manager-store",
                "EntityType": "Recognition",
                "Status": "Active",
                "IncludePerformance": false,
                "IsPublic": true,
                "hgId": "b2389270-a7fb-11e5-913b-b14905ebfc95"
        };
    }
	return {
		get: get,
        commentJson: commentJson
	}

});
