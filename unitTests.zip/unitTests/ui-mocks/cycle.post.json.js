define(function(){
	function get() {
		return {
			"Cycle":{
				"ModifiedDate":1381848477328,
				"ModifiedBy":"",
				"CreatedDate":1381848477327,
				"CreatedBy":"",
				"hgId":"test 123",
				"PercentCompletion":0,
				"Assignments":[
					{
						"DetectableRolesOnly":true,
						"CardId":"6a055300-131d-11e3-bc94-552338a0b1b7",
						"CardTitle":"test 4 sections",
						"Participants":[
							{
								"PeopleType":"Subject",
								"EntityType":"Member",
								"EntityId":"c15ba8b0-aea6-11e2-b79d-512ef31a350a",
								"EntityName":"Cezary Wojtkowski"
							},
							{
								"PeopleType":"Manager",
								"EntityType":"Member",
								"EntityId":"d2defe60-a119-11e2-b177-7d64c8315189",
								"EntityName":"Katrina Manoshin"
							}
						],
						"Selected":true
					},
					{
						"DetectableRolesOnly":true,
						"CardId":"6a055300-131d-11e3-bc94-552338a0b1b7",
						"CardTitle":"test 4 sections",
						"Participants":[
							{
								"PeopleType":"Subject",
								"EntityType":"Member",
								"EntityId":"d2e08500-a119-11e2-b177-7d64c8315189",
								"EntityName":"Demetri Maltsiniotis"
							},
							{
								"PeopleType":"Manager",
								"EntityType":"Member",
								"EntityId":"d2de3b11-a119-11e2-b177-7d64c8315189",
								"EntityName":"Liliana Zektser"
							}
						],
						"Selected":true
					}
				],
				"PeopleDates":[
					{
						"PeopleType":"Manager",
						"DueDate":1381899600000,
						"DeliveryDate":1381848477195,
						"CardId":["6a055300-131d-11e3-bc94-552338a0b1b7"]
					},
					{
						"PeopleType":"Subject",
						"DueDate":1381899600000,
						"DeliveryDate":1381848477195,
						"CardId":["6a055300-131d-11e3-bc94-552338a0b1b7"]
					}],
				"ReviewPeriodEnd":1381847759610,
				"ReviewPeriodStart":1381847759610,
				"ManagerCanSeeResponse":false,
				"GroupName":"",
				"GroupId":"",
				"Title": "dedsdffd"
			}
		};

	}
	return {
		get: get
	};
});
