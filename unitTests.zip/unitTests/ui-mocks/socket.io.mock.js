
define(function(){
	var listiners = [];
	return function() {
		return {
			on: function(event, callback) {
				listiners.push({event: event, callback: callback});
			},
			emit: function(event, params){
				listiners.forEach(function(item){
					if (item.event === event) {
						item.callback(params);
					}
				});
			},
			clear: function(){
				listiners = [];
			}
		};
	};
});