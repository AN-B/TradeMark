define(function () {
    function getSurveyQuestions() {
        return {
            "Questions": [{
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "3ee07a50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionText": "How strong is the urge to vomit when you read the word \"SYNERGY\"?"
            }, {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "17c51000-ecf9-11e4-acb5-457aab1acccb",
                "QuestionText": "How synergized do you feel?"
            }],
            LastViewedIndex: 0,
            "AnsweredQuestionCount": 0,
            "Survey": {"Title": "Test Template", "Description": "first test template"},
            "TotalQuestions": 2
        }
    }

    function getHalfCompletedSurvey() {
        return {
            "Questions": [{
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "3ee07a50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionText": "How strong is the urge to vomit when you read the word \"SYNERGY\"?"
            }, {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "17c51000-ecf9-11e4-acb5-457aab1acccb",
                "QuestionText": "How synergized do you feel?"
            },
            {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "3ee07a50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionText": "How strong is the urge to vomit when you read the word \"SYNERGY\"?"
            }, {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "17c51000-ecf9-11e4-acb5-457aab1acccb",
                "QuestionText": "How synergized do you feel?"
            }],
            "AnsweredQuestionCount": 2,
            "Survey": {"Title": "Test Template", "Description": "first test template"},
            "TotalQuestions": 4}
    }

    function getFiveQuestions() {
        return {
            "Questions": [{
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "3ee07a50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionText": "How strong is the urge to vomit when you read the word \"SYNERGY\"?"
            }, {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "17c51000-ecf9-11e4-acb5-457aab1acccb",
                "QuestionText": "How synergized do you feel?"
            }, {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "17c51000-ecf9-11e4-acb5-457aab1acccb",
                "QuestionText": "How synergized do you feel?"
            }, {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "17c51000-ecf9-11e4-acb5-457aab1acccb",
                "QuestionText": "How synergized do you feel?"
            }, {
                "SurveyId": "3ee07a51-ecfc-11e4-95fd-8be4288c1093",
                "RecurrenceId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "CurrentRoundId": "3ee55c50-ecfc-11e4-95fd-8be4288c1093",
                "QuestionId": "17c51000-ecf9-11e4-acb5-457aab1acccb",
                "QuestionText": "How synergized do you feel?"
            }],
            "AnsweredQuestionCount": 5,
            "Survey": {"Title": "Test Template", "Description": "first test template"},
            "TotalQuestions": 7
        }
    }

    return {
        getSurveyQuestions: getSurveyQuestions,
        getHalfCompletedSurvey: getHalfCompletedSurvey,
        getFiveQuestions: getFiveQuestions
    };
});