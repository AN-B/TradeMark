define(function(){

	function getNews(){
		return {
			"ContainUnreadNews": false,
			"NewsCollection": [
				{
					"_id": "52a4a43f61472844c1000040",
					"__v": 0,
					"ModifiedDate": 1386521663053,
					"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"CreatedDate": 1386521663052,
					"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"hgId": "63805fd0-6029-11e3-88f9-770ebd99df41",
					"ExpireDate": 1386521663245,
					"GroupName": "Mercury",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"Status": "Tentative",
					"Type": "Group",
					"Body": "<p>weewwewe</p>",
					"Title": "rerwew"
				},
				{
					"__v": 0,
					"_id": "52a4a36261472844c1000037",
					"ModifiedDate": 1386521456173,
					"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"CreatedDate": 1386521442007,
					"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"hgId": "dfbf9580-6028-11e3-88f9-770ebd99df41",
					"ExpireDate": 1386521663246,
					"GroupName": "Mercury",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"Status": "Final",
					"Type": "Group",
					"Body": "<p>test 1</p>",
					"Title": "test 1"
				},
				{
					"__v": 0,
					"_id": "52a4a06dc2cb7fbdbd00003c",
					"ModifiedDate": 1386520705432,
					"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"CreatedDate": 1386520685008,
					"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"hgId": "1c8a8d00-6027-11e3-9877-11b42a78442f",
					"ExpireDate": 1386521663246,
					"GroupName": "Mercury",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"Status": "Tentative",
					"Type": "Group",
					"Body": "<p>errerere</p>",
					"Title": "erere"
				},
				{
					"__v": 0,
					"_id": "52a49f06c2cb7fbdbd000031",
					"ModifiedDate": 1386520334331,
					"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"CreatedDate": 1386520326382,
					"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"hgId": "46c8b7f0-6026-11e3-9877-11b42a78442f",
					"ExpireDate": 1386521663247,
					"GroupName": "Mercury",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"Status": "Tentative",
					"Type": "Group",
					"Body": "<p>dsdsdsdsdsdsds</p>",
					"Title": "sddsdsds"
				},
				{
					"__v": 0,
					"_id": "52a49dea4cc4af80bc000046",
					"ModifiedDate": 1386520295833,
					"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"CreatedDate": 1386520042627,
					"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"hgId": "9da72440-6025-11e3-be42-71706abf9fd0",
					"ExpireDate": 1386521663247,
					"GroupName": "Mercury",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"Status": "Final",
					"Type": "Group",
					"Body": "<p>asasas</p>",
					"Title": "test 1"
				},
				{
					"__v": 0,
					"_id": "52a49dea4cc4af80bc000046",
					"ModifiedDate": 1386520295833,
					"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"CreatedDate": 1386520042627,
					"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"hgId": "9da72440-6025-11e3-be42-71706abf9fd0",
					"ExpireDate": 1386521663247,
					"GroupName": "Mercury",
					"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
					"Status": "Deleted",
					"Type": "Group",
					"Body": "<p>asasas</p>",
					"Title": "test 1"
				}]
		};
	}
	return {
		getNews: getNews
	};

});