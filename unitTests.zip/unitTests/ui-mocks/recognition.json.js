define(function () {
    function getRecognitionModalParams() {
        return {
            RecognitionId: "295d2c30-f259-11e3-851e-e1dd1a3833aa",
            NotificationId: "2974abd0-f259-11e3-851e-e1dd1a3833aa"
        };
    }
    function getRecognition() {
        return {
            ShareCount: 0,
            actualCreditValue: 10,
            actualPointValue: 10,
            badgeUrl: "/badges/group/1/302f7a60-b517-11e3-9685-61b7d0e98452_Silver",
            batchId: "b51ee9c0-f259-11e3-851e-e1dd1a3833aa",
            commentCount: 0,
            comments: [],
            congratMemberIds: [],
            congratsCount: 0,
            createdDate: 1402595285602,
            creditValue: 0,
            description: "",
            hgId: ['b51f10d0-f259-11e3-851e-e1dd1a3833aa'],
            isCongrats: false,
            isPublic: false,
            issuer: {
                companyName: "Mercury Industries",
                email: "",
                fullName: "Ross Hettel",
                hgId: "8532a592-bc3e-11e3-8b6f-b1f22651f9e3",
                userId: "8532a590-bc3e-11e3-8b6f-b1f22651f9e3"
            },
            message: "test",
            modifiedDate: 1402595285602,
            pointValue: 0,
            recipients: [
                {
                    fullName: "Hunter Lane",
                    hgId: "962f0220-d9b4-11e2-9d80-8b35d1bed369",
                    userId: "95ec05b0-d9b4-11e2-9d80-8b35d1bed369"
                }
            ],
            suppressInFeed: false,
            teamRecognition: false,
            title: "002 with sub",
            type: "Recognition"
        }
    }
    function getPublicRecognition() {
        return {
            ShareCount: 0,
            actualCreditValue: 10,
            actualPointValue: 0,
            badgeUrl: "/badges/group/1/302f7a60-b517-11e3-9685-61b7d0e98452_Silver",
            batchId: "b51ee9c0-f259-11e3-851e-e1dd1a3833aa",
            commentCount: 0,
            comments: [],
            congratMemberIds: [],
            congratsCount: 0,
            createdDate: 1402595285602,
            creditValue: 0,
            description: "",
            hgId: ['b51f10d0-f259-11e3-851e-e1dd1a3833aa'],
            isCongrats: false,
            isPublic: true,
            issuer: {
                companyName: "Mercury Industries",
                email: "",
                fullName: "Ross Hettel",
                hgId: "8532a592-bc3e-11e3-8b6f-b1f22651f9e3",
                userId: "8532a590-bc3e-11e3-8b6f-b1f22651f9e3"
            },
            message: "test",
            modifiedDate: 1402595285602,
            pointValue: 0,
            recipients: [
                {
                    fullName: "Hunter Lane",
                    hgId: "962f0220-d9b4-11e2-9d80-8b35d1bed369",
                    userId: "95ec05b0-d9b4-11e2-9d80-8b35d1bed369"
                }
            ],
            suppressInFeed: false,
            teamRecognition: false,
            title: "002 with sub",
            type: "Recognition"
        }
    }
    return {
        getRecognitionModalParams: getRecognitionModalParams,
        getRecognition: getRecognition,
        getPublicRecognition: getPublicRecognition
    }
});