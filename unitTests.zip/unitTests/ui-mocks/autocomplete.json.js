define(function () {
    function getAutoCompleteData() {
        return [
            {
                "UserId":"3cf94310-9cd2-11e2-a3a4-25024474fe63",
                "Id":"23310b40-9cd5-11e2-a3a4-25024474fe63",
                "Name":"Amie Chen",
                "AvatarId":"3cf94310-9cd2-11e2-a3a4-25024474fe63",
                "Department":"UAT Department"
            },
            {
                "UserId":"50ada1c0-aaf6-11e3-a970-81f78528efa6",
                "Id":"50ada1c1-aaf6-11e3-a970-81f78528efa6",
                "Name":"Mark Hamilton",
                "AvatarId":"50ada1c0-aaf6-11e3-a970-81f78528efa6",
                "Department":"Marcie's Department"
            },
            {
                "UserId":"bb05a850-bb1e-11e3-8dcb-3bb84f772d43",
                "Id":"bb05a852-bb1e-11e3-8dcb-3bb84f772d43",
                "Name":"Mosami Chatargi",
                "AvatarId":"bb05a850-bb1e-11e3-8dcb-3bb84f772d43",
                "Department":"Tech Support"
            }
        ]
    }

    function getPreSelectedData() {
        return [
            {
                "UserId":"3cf94310-9cd2-11e2-a3a4-25024474fe63",
                "Id":"23310b40-9cd5-11e2-a3a4-25024474fe63",
                "Name":"Amie Chen",
                "AvatarId":"3cf94310-9cd2-11e2-a3a4-25024474fe63",
                "Department":"UAT Department"
            },
            {
                "UserId":"50ada1c0-aaf6-11e3-a970-81f78528efa6",
                "Id":"50ada1c1-aaf6-11e3-a970-81f78528efa6",
                "Name":"Mark Hamilton",
                "AvatarId":"50ada1c0-aaf6-11e3-a970-81f78528efa6",
                "Department":"Marcie's Department"
            },
            {
                "UserId":"bb05a850-bb1e-11e3-8dcb-3bb84f772d43",
                "Id":"bb05a852-bb1e-11e3-8dcb-3bb84f772d43",
                "Name":"Mosami Chatargi",
                "AvatarId":"bb05a850-bb1e-11e3-8dcb-3bb84f772d43",
                "Department":"Tech Support"
            }
        ]
    }

    function getAutoCompleteDataForPointMember() {
        return {
            groupMembers: [
                {
                    FullName: "Amie Chen",
                    IssuePoints: 0,
                    MemberId: "23310b40-9cd5-11e2-a3a4-25024474fe63",
                    PointSpend: 0,
                    PointTransfer: 0,
                    Role: "Manager",
                    UserId: "3cf94310-9cd2-11e2-a3a4-25024474fe63"
                },
                {
                    FullName: "Areena Jose",
                    IssuePoints: 0,
                    MemberId: "a0132a00-5808-11e3-94c7-a7d327c74878",
                    PointSpend: 0,
                    PointTransfer: 4,
                    Role: "Admin",
                    UserId: "a00ce870-5808-11e3-94c7-a7d327c74878"
                },
                {
                    FullName: "Brendan Farrell",
                    IssuePoints: 0,
                    MemberId: "986744a0-14a9-11e3-8340-83c7e7202af3",
                    PointSpend: 100,
                    PointTransfer: 3,
                    Role: "Employee",
                    UserId: "98077160-14a9-11e3-8340-83c7e7202af3"
                },
                {
                    FullName: "Cezary Wojtkowski",
                    IssuePoints: 0,
                    MemberId: "2a74c710-ea47-11e2-b3b5-db0fb9a0b763",
                    PointSpend: 0,
                    PointTransfer: 3,
                    Role: "Manager",
                    UserId: "2a6c1480-ea47-11e2-b3b5-db0fb9a0b763"
                }, {
                    FullName: "Charlie Greubel",
                    IssuePoints: 0,
                    MemberId: "d76696a0-e336-11e2-97f1-bd30c7a0e0f3",
                    PointSpend: 0,
                    PointTransfer: 3,
                    Role: "Manager",
                    UserId: "d7524b50-e336-11e2-97f1-bd30c7a0e0f3"
                },{
                    FullName: "Cosmo Kramer",
                    IssuePoints: 0,
                    MemberId: "2de4bbf0-a0c6-11e2-a665-cf2c2ef6e160",
                    PointSpend: 18,
                    PointTransfer: 522,
                    Role: "Employee",
                    UserId: "2d84e8b0-a0c6-11e2-a665-cf2c2ef6e160"
                }, {
                    FullName: "Cu Barnes",
                    IssuePoints: 0,
                    MemberId: "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    PointSpend: 3,
                    PointTransfer: 0,
                    Role: "HGAdmin",
                    UserId: "3cf80a90-9cd2-11e2-a3a4-25024474fe63"
                }, {
                    FullName: "David Puddy",
                    IssuePoints: 0,
                    MemberId: "ede16340-c87b-11e2-aa05-198054fd4117",
                    PointSpend: 0,
                    PointTransfer: 53,
                    Role: "Employee",
                    UserId: "edcffe20-c87b-11e2-aa05-198054fd4117"
                }, {
                    FullName: "Demetri Maltsiniotis",
                    IssuePoints: 0,
                    MemberId: "2331a780-9cd5-11e2-a3a4-25024474fe63",
                    PointSpend: 0,
                    PointTransfer: 3,
                    Role: "Employee",
                    UserId: "3cf54b70-9cd2-11e2-a3a4-25024474fe63"
                }, {
                    FullName: "Devon Miles",
                    IssuePoints: 0,
                    MemberId: "af8abe00-1a53-11e3-943e-8f3acebdde8a",
                    PointSpend: 400,
                    PointTransfer: 3,
                    Role: "Employee",
                    UserId: "af8280a0-1a53-11e3-943e-8f3acebdde8a"
                }],
            totalCount: 10
        }
    }

    return {
        getAutoCompleteData: getAutoCompleteData,
        getPreSelectedData: getPreSelectedData,
        getAutoCompleteDataForPointMember: getAutoCompleteDataForPointMember
    };
});