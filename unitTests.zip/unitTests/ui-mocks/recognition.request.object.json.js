define(function(){
	function getEveryday() {
		return {
			Message: 'test 123',
			MoreOptions: {
				suppressFeed: false,
				creditValue: 0,
				pointValue: 0
			},
			Recipients: [{Id: '9c0cd910-cc94-11e2-863c-278252e8a19f', Type: 'Member'}],
			Template: {
				Title: '',
				hgId: 'a96e6030-3da8-11e3-8e3f-3b48bfc048fd',
				Category: 'Everyday',
				BadgeCategory: '',
				ImageId: ''
			}
		};
	}
	function getAchievement(){
		return {
			Message: 'test 123',
			Level: 'Silver',
			MoreOptions: {
				suppressFeed: false,
				creditValue: 0,
				pointValue: 0
			},
			Recipients: [{Id: '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864', Type: 'Member'}],
			Template: {
				Title: '',
				hgId: 'd0310380-3da8-11e3-8e3f-3b48bfc048fd',
				Category: 'Achievement',
				BadgeCategory: '',
				ImageId: ''
			}
		};
	}
	function getValue(){
		return {
			Message: 'test 123',
			MoreOptions: {
				suppressFeed: false,
				creditValue: 0,
				pointValue: 0
			},
			Recipients: [{Id: '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864', Type: 'Member'}],
			Level: 'Gold',
			Template: {
				Title: '',
				hgId: 'd9fe5250-3da8-11e3-8e3f-3b48bfc048fd',
				Category: 'Value',
				BadgeCategory: '',
				ImageId: 'blaf',
				SubValue :{
							ImageId : '5107a0d0-fbab-11e2-bad3-999e6df490a1',
							Name : 'Twenty Years A'
						},
				SubValues: [{
						ImageId : '5107a0d0-fbab-11e2-bad3-999e6df490a1',
						Name : 'Twenty Years A'
					},
					{
						ImageId : '4f0a7530-a1ee-11e2-b9ee-293826524e46',
						Name : 'Twenty Years B'
					}]
			}
		};
	}
	function getCustom(){
		return {
			Message: 'test 123',
			MoreOptions: {
				suppressFeed: false,
				creditValue: 0,
				pointValue: 0
			},
			Recipients: [{Id: '9c0cd910-cc94-11e2-863c-278252e8a19f', Type: 'Member'}],
			Template: {
				Title: 'Test 123',
				hgId: '',
				Category: 'Custom',
				BadgeCategory: 'Account Finance',
				ImageId: '4ef67800-a1ee-11e2-b9ee-293826524e46'
			}
		};
	}
	return {
		getEveryday: getEveryday,
		getAchievement: getAchievement,
		getValue: getValue,
		getCustom: getCustom
	}
});