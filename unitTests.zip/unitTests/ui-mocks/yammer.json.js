define(function () {
    function getYammerAuthStatus() {
        return {
            "created_at":1410190120000,
            "verified_admin":true,
            "user_name":"Cu Barnes",
            "user_email":"cu@highground.com",
            "network_name":"highground.com"
        }
    }

    function getYammerAuthUrl() {
        return "https://www.yammer.com/dialog/oauth?client_id=SehGkS3SyPUaVtnKhZXaTw";
    }

    return {
        getYammerAuthStatus: getYammerAuthStatus,
        getYammerAuthUrl: getYammerAuthUrl
    };
});