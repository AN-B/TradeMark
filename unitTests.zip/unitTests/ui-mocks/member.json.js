define(function(){
    function getProfileMemberRecordById() {
    	return {
    		"hgId":"f75b0252-a416-11e4-a111-57b4d90536cc",
    		"UserId":"f75b0250-a416-11e4-a111-57b4d90536cc",
    		"FullName":"Sam2 Hill",
    		"Position":"QA",
    		"PrimaryEmail":"sam2@highground.com",
    		"GroupDepartmentName":"Application Development",
    		"MyManagers":[{
    			"_id":"54e2bb579525f00000d70e13",
    			"FullName":"Tuan Barnes",
    			"MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63"
    		}],
    		"MembershipStatus":"Active"
    	};
    }
	return {
        getProfileMemberRecordById : getProfileMemberRecordById
	};
});