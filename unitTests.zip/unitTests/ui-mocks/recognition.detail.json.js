/**
 * Created by philipplekhanov on 9/27/14.
 * Updated by katrina on 4/28/2016. 
 */
define(function () {
    function getComments() {
        return [{
                "hgId":"cb3d0110-4b5e-11e5-8ae9-e11c3f526263",
                "Name":"Tuan Pham-Barnes",
                "Comment":"has attached 1000 points!",
                "UserId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate":1440530621345,
                "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "TaggedUser":{},
                "LikedMembers":[{
                    "FullName":"Gary Wei",
                    "UserId":"3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "MemberId":"23318070-9cd5-11e2-a3a4-25024474fe63",
                    "_id":"5717fa308c1be95d9da177a9"
                }],
                "LikedCount":1,
                "HasAttachment":false,
                "Attachments":{
                    "Description":"",
                    "Title":"",
                    "ImgSrc":"",
                    "Url":"",
                    "OrderId":""},
                "ModifiedDate":1461189168741,
                "MeLiked":true
            },{
                "hgId":"eb95c580-4b56-11e5-a4e4-339991900561",
                "Name":"Tuan Pham-Barnes",
                "Comment":"test 2",
                "UserId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate":1440527239640,
                "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "TaggedUser":{},
                "LikedMembers":[],
                "LikedCount":0,
                "HasAttachment":false,
                "Attachments":{
                    "Description":"",
                    "Title":"",
                    "ImgSrc":"",
                    "Url":"",
                    "OrderId":""},
                "ModifiedDate":1440527239640,
                "MeLiked":false
            },{
                "hgId":"ea304210-4b56-11e5-a4e4-339991900561",
                "Name":"Tuan Pham-Barnes",
                "Comment":"test 1",
                "UserId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate":1440527237297,
                "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "TaggedUser":{},
                "LikedMembers":[],
                "LikedCount":0,
                "HasAttachment":false,
                "Attachments":{
                    "Description":"",
                    "Title":"",
                    "ImgSrc":"",
                    "Url":"",
                    "OrderId":""},
                "ModifiedDate":1440527237297,
                "MeLiked":false}];
    };
    function get() {
        return {"_id":
            {
                "BatchId":"53df11c0-3179-11e5-8fd0-45a15aa81c75"
            },
            "hgId":["53df38d0-3179-11e5-8fd0-45a15aa81c75"],
            "batchId":"456",
            "CreatorMemberStatus":"Active",
            "TemplateId":"45837390-8d11-11e3-9f72-1d077c315508",
            "recipients":[{
                "hgId":"23318070-9cd5-11e2-a3a4-25024474fe63",
                "userId":"3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                "fullName":"Gary Wei",
                "dpt":"Points_001",
                "status":"Active",
                "managerId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63"
            }],
            "createdDate":1437683287261,
            "modifiedDate":1440530621355,
            "suppressInFeed":false,
            "message":"Gang has a very warm rapport.",
            "description":"Everyday",
            "title":"Beast mode",
            "type":"Recognition",
            "dismissMemberIds":[],
            "ShareCount":0,
            "shareCount":0,
            "commentCount":5,
            "congratsCount":2,
            "actualPointValue":1013,
            "actualCreditValue":0,
            "category":"Everyday",
            "levels":[],
            "SubValue":null,
            "subValues":[],
            "sticky":false,
            "levelName":null,
            "gifts":[],
            "visibilityMemberIds":null,
            "visibilityLocations":null,
            "krUpdates":null,
            "teamRecognition":false,
            "comments":[{
                "hgId":"cb3d0110-4b5e-11e5-8ae9-e11c3f526263",
                "Name":"Tuan Pham-Barnes",
                "Comment":"has attached 1000 points!",
                "UserId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate":1440530621345,
                "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "TaggedUser":{},
                "LikedMembers":[{
                    "FullName":"Gary Wei",
                    "UserId":"3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "MemberId":"23318070-9cd5-11e2-a3a4-25024474fe63",
                    "_id":"5717fa308c1be95d9da177a9"
                }],
                "LikedCount":1,
                "HasAttachment":false,
                "Attachments":{
                    "Description":"",
                    "Title":"",
                    "ImgSrc":"",
                    "Url":"",
                    "OrderId":""},
                "ModifiedDate":1461189168741,
                "MeLiked":true
            },{
                "hgId":"eb95c580-4b56-11e5-a4e4-339991900561",
                "Name":"Tuan Pham-Barnes",
                "Comment":"test 2",
                "UserId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate":1440527239640,
                "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "TaggedUser":{},
                "LikedMembers":[],
                "LikedCount":0,
                "HasAttachment":false,
                "Attachments":{
                    "Description":"",
                    "Title":"",
                    "ImgSrc":"",
                    "Url":"",
                    "OrderId":""},
                "ModifiedDate":1440527239640,
                "MeLiked":false
            },{
                "hgId":"ea304210-4b56-11e5-a4e4-339991900561",
                "Name":"Tuan Pham-Barnes",
                "Comment":"test 1",
                "UserId":"3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate":1440527237297,
                "MemberId":"2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "TaggedUser":{},
                "LikedMembers":[],
                "LikedCount":0,
                "HasAttachment":false,
                "Attachments":{
                    "Description":"",
                    "Title":"",
                    "ImgSrc":"",
                    "Url":"",
                    "OrderId":""},
                "ModifiedDate":1440527237297,
                "MeLiked":false}],
            "issuer":{
                "hgId":"",
                "userId":"",
                "fullName":"katya",
                "companyName":"Sss",
                "email":"yyy@yyy.com"},
            "isCongrats":false,
            "isPublic":5,
            "creditValue":0,
            "pointValue":0,
            "onTop":false,
            "levelAchieved":-1,
            "badgeUrl":"/badges/group/1/45837390-8d11-11e3-9f72-1d077c315508",
            "MeCongrated":false,
            "MeDismissed":false,
            "unfollow":false
        };
    }
    return {
        get: get,
        getComments: getComments
    };
});