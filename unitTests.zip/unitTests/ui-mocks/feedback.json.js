/**
 * Created by philipplekhanov on 10/16/14.
 */
define(function () {
    function getByUserId() {
        return [
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            },
            {
                "BatchId": "ff433990-549a-11e4-a17d-c3ac9eeb2492",
                "ModifiedDate": 1413398541228,
                "DisplayMembers": [
                    {
                        "MemberId": "d2defe60-a119-11e2-b177-7d64c8315189",
                        "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                        "FullName": "Katrina Manoshin",
                        "RecipientId": "d2defe60-a119-11e2-b177-7d64c8315189"
                    }
                ],
                "Subject": "testing 123",
                "Status": "Active"
            }

        ];
    }
    function getDetail() {
        return {
                "hgId": "315b7651-5580-11e4-963d-19a226615b28",
                "BatchId": "315b7650-5580-11e4-963d-19a226615b28",
                "Recipient": {
                "MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "FullName": "Gary Wei"
            },
                "Creator": {
                "MemberId": "d2e0d320-a119-11e2-b177-7d64c8315189",
                    "UserId": "d2c0ef10-a119-11e2-b177-7d64c8315189",
                    "FullName": "Cu Barnes"
            },
                "Subject": "test",
                "Status": "Active",
                "ModifiedDate": 1413496980022,
                "Comments": [
                {
                    "hgId": "56a18bc0-5580-11e4-963d-19a226615b28",
                    "Comment": "hey!",
                    "EntityId": "315b7651-5580-11e4-963d-19a226615b28",
                    "FullName": "Gang Wei",
                    "UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "CreatedDate": 1413497042556
                },
                {
                    "hgId": "4e9797d0-5580-11e4-963d-19a226615b28",
                    "Comment": "hey!",
                    "EntityId": "315b7651-5580-11e4-963d-19a226615b28",
                    "FullName": "Gang Wei",
                    "UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                    "MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "CreatedDate": 1413497029069
                }
            ]
        };
    }
    return {
        getByUserId: getByUserId,
        getDetail: getDetail
    };
});