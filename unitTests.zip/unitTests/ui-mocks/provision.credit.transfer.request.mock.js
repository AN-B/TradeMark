define(function() {
    function getMockup () {
        return {
            "SameUser": false,
            "DiffUser": false,
            "Refund": false,
            "notValidGroupId": false,
            "notValidFromAccount": false,
            "notValidToAccount": false,
            "notValidAmount": false,
            "notValid": false,
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "FromAccountMember": {
                "hgId": "232d61c0-9cd5-11e2-a3a4-25024474fe63",
                "FullName": "Vip Sandhir",
                "AvatarId": "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                "UserId": "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                "Type": "Member",
                "AbbrvName": "Vipon S.",
                "GroupDepartmentName": "Executive",
                "Role": "Executive",
                "SPND": 15800,
                "TRFR": 13955
            },
            "ToAccountMember": {
                "hgId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "FullName": "Cu Barnes",
                "AvatarId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "Type": "Member",
                "AbbrvName": "Tuan P.",
                "GroupDepartmentName": "Development",
                "Role": "HGAdmin",
                "SPND": 2180,
                "TRFR": 21628
            },
            "TransferAmount": 100
        }
    };
    return {
        getMockup: getMockup
    };
});