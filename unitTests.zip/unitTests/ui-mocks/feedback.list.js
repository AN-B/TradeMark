define(function(){
    function get() {
        return [
            {
                "hgId": "beb63b30-0bc7-11e6-ad65-c958adf62ca2",
                "CycleId": "21511c20-0bc7-11e6-ad65-c958adf62ca2",
                "CycleTitle": "test new feedback",
                "CycleDescription": "my description is not very long, its only for testing.....",
                "ExpirationDate": 1462895920739,
                "Participant": {
                    "ParticipantType": "Subject",
                    "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "FullName": "Cu Barnes",
                    "Status": "Requesting"
                },
                "Status": "InProgress",
                "NextStep": "Answer"
            },
            {
                "hgId": "c6dbc1e0-0e42-11e6-a9bf-35811b11ff47",
                "CycleId": "617bca50-0e3f-11e6-a9bf-35811b11ff47",
                "CycleTitle": "test all options",
                "CycleDescription": "test all options",
                "ExpirationDate": 1463168664830,
                "Participant": {
                    "ParticipantType": "Subject",
                    "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                    "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                    "FullName": "Cu Barnes",
                    "Role": "HGAdmin",
                    "DepartmentName": "Zomm1",
                    "DepartmentId": "fe45b8f0-f40a-11e4-99fc-6bc86d3fba1d",
                    "LocationName": "River North",
                    "LocationId": "51756460-b23b-11e4-9219-db713d08c4ee",
                    "Status": "Requesting"
                },
                "Status": "InProgress",
                "NextStep": "Answer"
            }
        ];
    }
    return {
        get: get
    }

});