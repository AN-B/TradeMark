define(function () {

    var GroupBenchmarkSurveyTemplate = {
        _id: '553e80319d9ac92326a98ea7',
        StartDate: '1430370000000',
        GroupId: '3cf21720-9cd2-11e2-a3a4-25024474fe63',
        __v: 0,
        ModifiedDate: '1430228011759',
        ModifiedBy: '3cf80a90-9cd2-11e2-a3a4-25024474fe63',
        CreatedDate: '1430159409150',
        CreatedBy: '3cf80a90-9cd2-11e2-a3a4-25024474fe63',
        hgId: '6f0ccad2-ed0b-11e4-8ced-470926a270e2',
        Status: 'Active',
        Reminder: true,
        DaysToLive: 7,
        PeriodType: 'Semi-Annual',
        Template: {
            "UberQuestion" : {
                "Driver" : {
                    "hgId" : "5a6c5b80-e861-11e4-bab0-2705c6098ea2",
                    "Name" : "Driver A"
                },
                "hgId" : "7ab12920-e861-11e4-bab0-2705c6098ea2",
                "MaxLabelAnswer" : "Agree",
                "MinLabelAnswer" : "Disagree",
                "Question" : "Question",
                "Status" : "Active"
            },
            "hgId" : "7ab10210-e861-11e4-bab0-2705c6098ea2",
            "DriverQuestions" : [
                {
                    "BenchmarkQuestionType" : "Driver",
                    "Driver" : {
                        "hgId" : "5e4046e0-e861-11e4-bab0-2705c6098ea2",
                        "Name" : "Driver B"
                    },
                    "hgId" : "7ab15030-e861-11e4-bab0-2705c6098ea2",
                    "MaxLabelAnswer" : "Agree",
                    "MinLabelAnswer" : "Disagree",
                    "Question" : "Question",
                    "Type" : "System",
                    "Status" : "Active"
                },
                {
                    "BenchmarkQuestionType" : "Driver",
                    "Driver" : {
                        "hgId" : "61cbdea0-e861-11e4-bab0-2705c6098ea2",
                        "Name" : "Driver C"
                    },
                    "hgId" : "7ab15031-e861-11e4-bab0-2705c6098ea2",
                    "MaxLabelAnswer" : "Agree",
                    "MinLabelAnswer" : "Disagree",
                    "Question" : "Question",
                    "Type" : "System",
                    "Status" : "Active"
                }
            ],
            "Description" : 'Testing',
            "PeriodType": 'Semi-Annual',
            "Frequency": 1,
            "Title" : 'Unit Test Template',
            "Type" : "Benchmark",
            "Status" : "Active"
        }
    },
    GroupPulseSurveyTemplate = {
        "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
        "hgId" : "8b1b39a0-1119-11e5-854d-d9810696c6ac",
        "Status" : "Active",
        "Points" : 10,
        "DaysToLive" : 14,
        "PeriodType" : "Weekly",
        "Template" : {
            "_id" : "556f27093bbfda0000b498be",
            "hgId" : "19ac2be0-0a0b-11e5-bda7-1b1222ed296b",
            "PulseQuestions" : [
                {
                    "hgId" : "19ac52f0-0a0b-11e5-bda7-1b1222ed296b",
                    "Status" : "Active",
                    "Type" : "System",
                    "AnswerType" : "Mood",
                    "Order" : 0,
                    "Question" : "How do you feel about work today?",
                    "AnswerSelectors" : [
                        {
                            "Value" : 0,
                            "Text" : "Horrible",
                            "Order" : 1
                        },
                        {
                            "Value" : 1,
                            "Text" : "Poor",
                            "Order" : 1
                        },
                        {
                            "Value" : 2,
                            "Text" : "Fair",
                            "Order" : 1
                        },
                        {
                            "Value" : 3,
                            "Text" : "Good",
                            "Order" : 1
                        },
                        {
                            "Value" : 4,
                            "Text" : "Excellent",
                            "Order" : 1
                        }
                    ]
                }
            ],
            "Description" : "Pulse Survey Template Description",
            "Title" : "Pulse Survey Template",
            "Status" : "Active",
            "Type" : "Pulse"
        },
        "__v" : 0
    },
    AggregatedPulseSurveyMetrics = {
        "Departments": [{
            "TeamName":"Development",
            "MemberNumber":10,
            "Max":null,
            "Min":null,
            "Average":0,
            "Date":1434402994309,
            "TotalNumber":0,
            "AnsweredNumber":0
        },
        {
            "TeamName":"Sales",
            "MemberNumber":8,
            "Max":null,
            "Min":null,
            "Average":0,
            "Date":1434402994309,
            "TotalNumber":0,
            "AnsweredNumber":0
        }],
        "Locations":[{
            "TeamName":"Chicago",
            "MemberNumber":5,
            "Max":null,
            "Min":null,
            "Average":0,
            "Date":1434402994352,
            "TotalNumber":0,
            "AnsweredNumber":0
        },
        {
            "TeamName":"Salem",
            "MemberNumber":4,
            "Max":null,
            "Min":null,
            "Average":0,
            "Date":1434402994352,
            "TotalNumber":0,
            "AnsweredNumber":0
        }],
        "Roles":[{
            "TeamName":"Employee",
            "MemberNumber":39,
            "Max":null,
            "Min":null,
            "Average":0,
            "Date":1434402994397,
            "TotalNumber":0,
            "AnsweredNumber":0
        },
        {
            "TeamName":"Admin",
            "MemberNumber":12,
            "Max":null,
            "Min":null,
            "Average":0,
            "Date":1434402994397,
            "TotalNumber":0,
            "AnsweredNumber":0
        }]
    },
    GetBenchmarkQuestionDetailByDriver = {
        "driver":{
            "engagement":90,
            "favorable":93,
            "neutral":7,
            "participation":17,
            "unfavorable":0
        },
        "questions":[
            {
                "text":"One",
                "engagement":80,
                "favorable":80,
                "neutral":20,
                "unfavorable":0
            },
            {
                "text":"Test quetsion",
                "engagement":95,
                "favorable":100,
                "neutral":0,
                "unfavorable":0
            },
            {
                "text":"Four",
                "engagement":95,
                "favorable":100,
                "neutral":0,
                "unfavorable":0
            }
        ]
    },
    GetSurveyDrivers = [
        {
            "hgId":"test",
            "GroupId":"3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Description":"Test",
            "Name":"Test"
        },
        {
            "hgId":"3ad65820-03c3-11e5-929c-635a6c46fdff",
            "Name":"Custom",
            "Description":"Custom question"
        },
        {
            "hgId":"6f8184a0-1908-11e5-9955-0bc85c7521b3",
            "Description":"Employee Satisfaction",
            "Name":"Employee Satisfaction"
        },
        {
            "hgId":"ca3b5390-f990-11e4-8260-df94da262fa6",
            "Description":"Opportunity",
            "Name":"Opportunity"
        },
        {
            "hgId":"48560000-f990-11e4-8260-df94da262fa6",
            "Description":"Work Environment",
            "Name":"Positive Work Environment"
        },
        {
            "hgId":"d2f44c30-f990-11e4-8260-df94da262fa6",
            "Description":"Relationships with coworkers",
            "Name":"Relationships"
        }
    ],
    GetEngagementScoreByDepartment = [
        {
            "name":"Sales",
            "value":13,
            "average":87.5,
            "responses":2
        },
        {
            "name":"Development",
            "value":16,
            "average":87.5,
            "responses":3
        }
    ],
    GetBenchmarkQuestionDetailByDepartment = {
        "cohort":{
            "_id":{
                "Id":"4995fd70-c674-11e4-a67a-0d774ac33ccb",
                "Name":"Sales"
            },
            "Comment":0,
            "ResponseScore":1225,
            "Participant":14,
            "Total":13,
            "neutral":0,
            "unfavorable":0,
            "favorable":100,
            "participation":15.384615384615385,
            "engagement":87.5
        },"questions":[
            {
                "_id":{
                    "DN":"Relationships",
                    "QT":"One"
                },
                "engagement":87.5,
                "unfavorable":0,
                "favorable":100,
                "neutral":0
            },
            {
                "_id":{
                    "DN":"Opportunity",
                    "QT":"Two"
                },
                "engagement":87.5,
                "unfavorable":0,
                "favorable":100,
                "neutral":0
            },
            {
                "_id":{
                    "DN":"Custom",
                    "QT":"Three"
                },
                "engagement":75,
                "unfavorable":0,
                "favorable":100,
                "neutral":0
            }
        ],
        "drivers":[
            {
                "name":"Relationships",
                "engagement":91.66666666666667
            },
            {
                "name":"Opportunity",
                "engagement":87.5
            },
            {
                "name":"Custom",
                "engagement":75
            }
        ],
        "company":[
            {
                "name":"Relationships",
                "engagement":90
            },
            {
                "name":"Opportunity",
                "engagement":88
            },
            {
                "name":"Custom",
                "engagement":75
            }
        ]
    };

    function getGroupPulseSurveyTemplate() {
        return GroupPulseSurveyTemplate;
    }

    function getGroupBenchmarkSurveyTemplate() {
        return GroupBenchmarkSurveyTemplate;
    }

    function setTemplate() {
        return GroupBenchmarkSurveyTemplate.Template;
    }

    function inProgressSurvey() {
        var survey = GroupBenchmarkSurveyTemplate;
        survey.Status = 'InProgress';
        return survey;
    }
    function getAggregatedPulseSurveyMetrics() {
        return AggregatedPulseSurveyMetrics;
    }
    function getBenchmarkQuestionDetailByDriver() {
        return GetBenchmarkQuestionDetailByDriver;
    }
    function getSurveyDrivers() {
        return GetSurveyDrivers;
    }
    function getEngagementScoreByDepartment () {
        return GetEngagementScoreByDepartment;
    }
    function getBenchmarkQuestionDetailByDepartment () {
        return GetBenchmarkQuestionDetailByDepartment;
    }
    return {
        getGroupPulseSurveyTemplate: getGroupPulseSurveyTemplate,
        getGroupBenchmarkSurveyTemplate: getGroupBenchmarkSurveyTemplate,
        setTemplate: setTemplate,
        inProgressSurvey: inProgressSurvey,
        getAggregatedPulseSurveyMetrics: getAggregatedPulseSurveyMetrics,
        getBenchmarkQuestionDetailByDriver: getBenchmarkQuestionDetailByDriver,
        getSurveyDrivers: getSurveyDrivers,
        getEngagementScoreByDepartment: getEngagementScoreByDepartment,
        getBenchmarkQuestionDetailByDepartment: getBenchmarkQuestionDetailByDepartment
    };
});
