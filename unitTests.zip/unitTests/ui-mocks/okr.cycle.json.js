define(function() {

    function get() {
        return [
            {
                "GoalNumber": 0,
                "CycleTitle": "2015 HighGround Company OKR",
                "ParticipantId": "232d61c0-9cd5-11e2-a3a4-25024474fe63",
                "ParticipantType": "Member",
                "ParticipantStatus": "NotStarted",
                "SetDueDate": 1431199582358,
                "CycleId": "c762b660-f425-11e4-80df-87f216b53a7b",
                "MyRole": "Owner"
            },{
                "GoalNumber": 0,
                "CycleTitle": "2015 HighGround Company OKR",
                "ParticipantId": "232d61c0-9cd5-11e2-a3a4-25024474fe63",
                "ParticipantType": "Member",
                "ParticipantStatus": "NotStarted",
                "SetDueDate": 1431199582358,
                "CycleId": "c762b660-f425-11e4-80df-87f216b53a7b",
                "MyRole": "Owner"
            }
        ];
    }
    function getOverview() {
        return {
            "IndividualCycleNumber": 1,
            "TeamCycleNumber": 1,
            "CompanyCycleNumber": 1,
            "ApprovalNumber": 1
        };
    }
    function getGoals() {
        return [{
                Status: 'blah',
                GoalName: 'Increase Recurring Revenue',
                Aligned: true,
                LastUpdated: 1431638631,
                UpdateFrequency: 'Weekly',
                Current: true,
                Completion: 35
            },{
                Status: 'blah',
                GoalName: 'Increase Recurring Revenue',
                Aligned: true,
                LastUpdated: 1431638631,
                UpdateFrequency: 'Monthly',
                Current: true,
                Completion: 35
            }];
    }
    function addDays(days){
        var today = new Date(),
            ret = new Date(today);
        ret.setDate(today.getDate() + days);
        return ret.getTime();
    }
    function getEditCycle() {
        return { 
            "Cycle": {
                "CompanyGoalOwner": {
                    "Title":"Sales Manager",
                    "FullName":"David Puddy",
                    "UserId":"edcffe20-c87b-11e2-aa05-198054fd4117",
                    "MemberId":"ede16340-c87b-11e2-aa05-198054fd4117"
                },
                "hgId":"123",
                "Title": "New Cycle Draft",
                "Timing":"OneTime",
                "Status":"Pending",
                "PeriodType":"Daily",
                "DeliveryMethods":[{
                    "includeInCycle":true,
                    "SetDueDate": addDays(10),
                    "ParticipantType":"Company",
                    "DeliveryTrigger":"ByDate",
                    "DeliveryDate": addDays(2),
                    "CheckInFrequency":"Daily",
                    "ApprovalFlags":{
                        "Set":true,
                        "Update":false,
                        "Closure":true}
                    },{
                        "includeInCycle":true,
                        "SetDueDate":addDays(10),
                        "ParticipantType":"Member",
                        "DeliveryTrigger":"ByDate",
                        "DeliveryDate": addDays(2),
                        "CheckInFrequency":"Daily",
                        "ApprovalFlags":{
                            "Set":true,
                            "Update":false,
                            "Closure":true}
                        }],
                        "ClosePeriod":6,
                        "CloseDate":addDays(15)
                    },
                    "TotalMemberNumber":136,
                    "Members":[{
                        "MemberId":"937ae1f2-74c9-11e4-b0f4-df09deb0dc49",
                        "UserId":"937ae1f0-74c9-11e4-b0f4-df09deb0dc49",
                        "FullName":"Aamir khan test",
                        "Role":"Admin",
                        "Department":"Cosmo",
                        "IsInCycle":false
                    },{
                        "MemberId":"6db96742-d431-11e3-86a4-9711b6b34e5a",
                        "UserId":"6db96740-d431-11e3-86a4-9711b6b34e5a",
                        "FullName":"Abha singh test",
                        "Role":"Manager",
                        "Department":"Finance test",
                        "IsInCycle":true
                    },{
                        "MemberId":"28b1e652-e64b-11e3-bda7-1dd5c425b06f",
                        "UserId":"28b1e650-e64b-11e3-bda7-1dd5c425b06f",
                        "FullName":"Abhijit Malkar",
                        "Role":"Executive",
                        "Department":"Dept A",
                        "IsInCycle":true
                    },{
                        "MemberId":"311be6b0-d76f-11e2-bfde-692f778bcc11",
                        "UserId":"31111140-d76f-11e2-bfde-692f778bcc11",
                        "FullName":"Adam Lippman",
                        "Role":"Manager",
                        "Department":"Finance test",
                        "IsInCycle":true
                    },{
                        "MemberId":"bc2c6632-d2fe-11e4-ab10-f7a4633a68da",
                        "UserId":"bc2c6630-d2fe-11e4-ab10-f7a4633a68da",
                        "FullName":"Ajay rathod",
                        "Role":"Employee",
                        "Department":"Sale department",
                        "IsInCycle":true
                    },{
                        "MemberId":"23310b40-9cd5-11e2-a3a4-25024474fe63",
                        "UserId":"3cf94310-9cd2-11e2-a3a4-25024474fe63",
                        "FullName":"Amie Chen",
                        "Role":"Employee",
                        "Department":"DEPT A",
                        "IsInCycle":true
                    },{
                        "MemberId":"6908c0a2-74c8-11e4-a99f-53b54ed8242f",
                        "UserId":"6908c0a0-74c8-11e4-a99f-53b54ed8242f",
                        "FullName":"Anu singh",
                        "Role":"Admin",
                        "Department":"Cosmo",
                        "IsInCycle":true
                    },{
                        "MemberId":"a0132a00-5808-11e3-94c7-a7d327c74878",
                        "UserId":"a00ce870-5808-11e3-94c7-a7d327c74878",
                        "FullName":"Areena Jose",
                        "Role":"Admin",
                        "Department":"DEPT A",
                        "IsInCycle":true
                    },{
                        "MemberId":"2899f522-d788-11e4-83b1-8b669af5a4cc",
                        "UserId":"2899f520-d788-11e4-83b1-8b669af5a4cc",
                        "FullName":"Ashish thakur",
                        "Role":"Employee",
                        "Department":"Dept A",
                        "IsInCycle":true
                    },{
                        "MemberId":"d1a766a1-b6f1-11e4-a420-2dada8c07e91",
                        "UserId":"d1a73f90-b6f1-11e4-a420-2dada8c07e91",
                        "FullName":"Automation_Employee Testing",
                        "Role":"Employee",
                        "Department":"Dept A",
                        "IsInCycle":true
                    }],
                    "Teams":[{
                        "hgId":"23d2a9d0-dcfe-11e4-aec8-296fa10182ff",
                        "Name":"Cosmo",
                        "IsInCycle":true
                    },{
                        "hgId":"9503ab60-e2d3-11e4-aca8-1fa854139662",
                        "Name":"DEPT A",
                        "IsInCycle":false
                    },{
                        "hgId":"44c72520-c715-11e4-b9e6-9f54224db729",
                        "Name":"Dept  B",
                        "IsInCycle":false
                    },{
                        "hgId":"2b74c0f0-c715-11e4-b9e6-9f54224db729",
                        "Name":"Dept A",
                        "IsInCycle":true
                    },{
                        "hgId":"376f3520-d2eb-11e4-af5b-731a727704ec",
                        "Name":"Finance test",
                        "IsInCycle":false
                    },{
                        "hgId":"d1012030-d78d-11e4-83b1-8b669af5a4cc",
                        "Name":"Financier Department",
                        "IsInCycle":true
                    },{
                        "hgId":"5b80aa70-dd18-11e4-b1b5-3b90501ff431",
                        "Name":"HHTA",
                        "IsInCycle":true
                    },{
                        "hgId":"c46d6150-dd12-11e4-b912-91cee5f77e0d",
                        "Name":"HR_Department",
                        "IsInCycle":false
                    },{
                        "hgId":"f2322580-dd12-11e4-bf0f-73a1dd3e784b",
                        "Name":"Points_001",
                        "IsInCycle":true
                    },{
                        "hgId":"8dd24f70-d204-11e4-b20b-1b4d12f70b26",
                        "Name":"Sale department",
                        "IsInCycle":true
                    }]
                };
    }
    function getTeamsForViewing() {
        return [
           {
              "hgId":"36e9558e-6691-11e4-bee2-812188965580",
              "TeamName":"SurgeryFlow",
              "OwnerName":"Jacob Rohde",
              "OwnerUserId":"36f8e600-6691-11e4-bee2-812188965580",
              "OwnerMemberId":"36f8e601-6691-11e4-bee2-812188965580",
              "GoalCount":0
           },
           {
              "hgId":"36e95579-6691-11e4-bee2-812188965580",
              "TeamName":"Transworld",
              "OwnerName":"Rob Fishman",
              "OwnerUserId":"36f8bf11-6691-11e4-bee2-812188965580",
              "OwnerMemberId":"36f8bf12-6691-11e4-bee2-812188965580",
              "GoalCount":0
           },
           {
              "hgId":"36e95570-6691-11e4-bee2-812188965580",
              "TeamName":"WEX",
              "OwnerName":"Severin Delabar",
              "OwnerUserId":"36f8befc-6691-11e4-bee2-812188965580",
              "OwnerMemberId":"36f8befd-6691-11e4-bee2-812188965580",
              "GoalCount":0
           },
           {
              "hgId":"36e9558a-6691-11e4-bee2-812188965580",
              "TeamName":"bswift",
              "OwnerName":"Jeffrey Marks",
              "OwnerUserId":"36f8bf47-6691-11e4-bee2-812188965580",
              "OwnerMemberId":"36f8bf48-6691-11e4-bee2-812188965580",
              "GoalCount":0
           },
           {
              "hgId":"36e95589-6691-11e4-bee2-812188965580",
              "TeamName":"iContact",
              "OwnerName":"Kevin Newman",
              "OwnerUserId":"36f8e5ee-6691-11e4-bee2-812188965580",
              "OwnerMemberId":"36f8e5ef-6691-11e4-bee2-812188965580",
              "GoalCount":0
           }
        ];
    }
    function getTeams() {
        return [{
                "hgId":"23d2a9d0-dcfe-11e4-aec8-296fa10182ff",
                "Name":"Cosmo",
                "IsInCycle":true
            },{
                "hgId":"9503ab60-e2d3-11e4-aca8-1fa854139662",
                "Name":"DEPT A",
                "IsInCycle":false
            },{
                "hgId":"44c72520-c715-11e4-b9e6-9f54224db729",
                "Name":"Dept  B",
                "IsInCycle":false
            },{
                "hgId":"2b74c0f0-c715-11e4-b9e6-9f54224db729",
                "Name":"Dept A",
                "IsInCycle":true
            },{
                "hgId":"376f3520-d2eb-11e4-af5b-731a727704ec",
                "Name":"Finance test",
                "IsInCycle":false
            },{
                "hgId":"d1012030-d78d-11e4-83b1-8b669af5a4cc",
                "Name":"Financier Department",
                "IsInCycle":true
            },{
                "hgId":"5b80aa70-dd18-11e4-b1b5-3b90501ff431",
                "Name":"HHTA",
                "IsInCycle":true
            },{
                "hgId":"c46d6150-dd12-11e4-b912-91cee5f77e0d",
                "Name":"HR_Department",
                "IsInCycle":false
            },{
                "hgId":"f2322580-dd12-11e4-bf0f-73a1dd3e784b",
                "Name":"Points_001",
                "IsInCycle":true
            },{
                "hgId":"8dd24f70-d204-11e4-b20b-1b4d12f70b26",
                "Name":"Sale department",
                "IsInCycle":true
            }];
    }
    function getMembers() {
        return {
            Total: 10,
            Members: [{
                "MemberId":"937ae1f2-74c9-11e4-b0f4-df09deb0dc49",
                "UserId":"937ae1f0-74c9-11e4-b0f4-df09deb0dc49",
                "FullName":"Aamir khan test",
                "Role":"Admin",
                "Department":"Cosmo",
                "IsInCycle":false
            },{
                "MemberId":"6db96742-d431-11e3-86a4-9711b6b34e5a",
                "UserId":"6db96740-d431-11e3-86a4-9711b6b34e5a",
                "FullName":"Abha singh test",
                "Role":"Manager",
                "Department":"Finance test",
                "IsInCycle":false
            },{
                "MemberId":"28b1e652-e64b-11e3-bda7-1dd5c425b06f",
                "UserId":"28b1e650-e64b-11e3-bda7-1dd5c425b06f",
                "FullName":"Abhijit Malkar",
                "Role":"Executive",
                "Department":"Dept A",
                "IsInCycle":true
            },{
                "MemberId":"311be6b0-d76f-11e2-bfde-692f778bcc11",
                "UserId":"31111140-d76f-11e2-bfde-692f778bcc11",
                "FullName":"Adam Lippman",
                "Role":"Manager",
                "Department":"Finance test",
                "IsInCycle":true
            },{
                "MemberId":"bc2c6632-d2fe-11e4-ab10-f7a4633a68da",
                "UserId":"bc2c6630-d2fe-11e4-ab10-f7a4633a68da",
                "FullName":"Ajay rathod",
                "Role":"Employee",
                "Department":"Sale department",
                "IsInCycle":true
            },{
                "MemberId":"23310b40-9cd5-11e2-a3a4-25024474fe63",
                "UserId":"3cf94310-9cd2-11e2-a3a4-25024474fe63",
                "FullName":"Amie Chen",
                "Role":"Employee",
                "Department":"DEPT A",
                "IsInCycle":true
            },{
                "MemberId":"6908c0a2-74c8-11e4-a99f-53b54ed8242f",
                "UserId":"6908c0a0-74c8-11e4-a99f-53b54ed8242f",
                "FullName":"Anu singh",
                "Role":"Admin",
                "Department":"Cosmo",
                "IsInCycle":true
            },{
                "MemberId":"a0132a00-5808-11e3-94c7-a7d327c74878",
                "UserId":"a00ce870-5808-11e3-94c7-a7d327c74878",
                "FullName":"Areena Jose",
                "Role":"Admin",
                "Department":"DEPT A",
                "IsInCycle":true
            },{
                "MemberId":"2899f522-d788-11e4-83b1-8b669af5a4cc",
                "UserId":"2899f520-d788-11e4-83b1-8b669af5a4cc",
                "FullName":"Ashish thakur",
                "Role":"Employee",
                "Department":"Dept A",
                "IsInCycle":true
            },{
                "MemberId":"d1a766a1-b6f1-11e4-a420-2dada8c07e91",
                "UserId":"d1a73f90-b6f1-11e4-a420-2dada8c07e91",
                "FullName":"Automation_Employee Testing",
                "Role":"Employee",
                "Department":"Dept A",
                "IsInCycle":true
            }]
        };
    }
    function getDetails() {
        return {
                hgId: '123',
                Status: 'InProgress',
                IndividualGoalsTotal: 4,
                Overall: {
                    GoalSet: 93,
                    GoalCurrent: 73,
                    AvgCompletion: 23,
                    ClosedDate: 1431638631
                },
                Company: {
                    OwnerName: 'John Smith',
                    OwnerUserId: '9318f6f0-9e08-11e2-bd88-3fc07fd541f7', 
                    OwnerMemberId: '123',
                    Title: 'CEO',
                    Goals: [{
                        Status: 'blah',
                        GoalName: 'Increase Recurring Revenue',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: true,
                        Completion: 18
                    },{
                        Status: 'blah',
                        GoalName: 'Improve Employee Engagement',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: true,
                        Completion: 10
                    },{
                        Status: 'blah',
                        GoalName: 'Build a Solid Financial Foundation',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: true,
                        Completion: 0
                    }]
                },
                Teams: [{
                    hgId:'123',
                    TeamName: 'Sales',
                    OwnerName: 'Bob Builder',
                    OwnerUserId: '931a2f70-9e08-11e2-bd88-3fc07fd541f7',
                    OwnerMemberId: '123',
                    Title: 'VP of Sales',
                    Goals: []
                },{
                    hgId:'123',
                    TeamName: 'Product',
                    OwnerName: 'Kat Smith',
                    OwnerUserId: '55cd9780-a3d7-11e3-a983-ffeb5d7109a3',
                    OwnerMemberId: '123',
                    Title: 'Principal of Sales',
                    Goals: []
                }],
                Individuals: [
                    {
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerMemberId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },{
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },{
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },{
                        Status: 'pending',
                        OwnerName: 'test',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },
                    {
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerMemberId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },{
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },{
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },{
                        Status: 'pending',
                        OwnerName: 'test',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },
                    {
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerMemberId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    },{
                        Status: 'pending',
                        OwnerName: 'Charlie Grubel',
                        OwnerMemberId: '123',
                        ManagerName: 'Moose Farnham',
                        ManagerId: '123',
                        GoalName: 'Grow the sales team',
                        LastUpdated: 1431638631,
                        UpdateFrequency: 'Weekly',
                        Current: false,
                        Completion: 18
                    }
                ]
            };
    }
    return {
        get: get,
        getOverview: getOverview,
        getDetails: getDetails,
        getGoals: getGoals,
        getEditCycle: getEditCycle,
        getMembers: getMembers,
        getTeams: getTeams,
        getTeamsForViewing: getTeamsForViewing
    };
});