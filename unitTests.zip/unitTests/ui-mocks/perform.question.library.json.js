define(function(){
    function get(){
        return [
            {
                "__v": 0,
                "_id": "5244aba8e10d1f6524000037",
                "ModifiedDate": 1380232103965,
                "ModifiedBy": "",
                "CreatedDate": 1380232103965,
                "CreatedBy": "",
                "hgId": "5e262cd1-26f5-11e3-895a-4b3c71e041ac",
                "Archived": false,
                "AnswerType": "ScaleRating",
                "Category": "Advocating Causes",
                "QuestionText": "Ensures others grasp the purpose and benefits of the program or cause. Tailors messages to specific audiences to develop interest and endorsement."
            },
            {
                "__v": 0,
                "_id": "5244aba8e10d1f6524000038",
                "ModifiedDate": 1380232103968,
                "ModifiedBy": "",
                "CreatedDate": 1380232103968,
                "CreatedBy": "",
                "hgId": "5e26a200-26f5-11e3-895a-4b3c71e041ac",
                "Archived": false,
                "AnswerType": "ScaleRating",
                "Category": "Analysis/Reasoning",
                "QuestionText": "Goes beyond analyzing factual information to develop a conceptual understanding of the meaning of a range of information. Integrates diverse themes and lines of reasoning to create new insights or levels of understanding for the issue at hand. Thinks in terms of generalized models rather than concrete details."
            },
            {
                "__v": 0,
                "_id": "5244aba8e10d1f6524000039",
                "ModifiedDate": 1380232103970,
                "ModifiedBy": "",
                "CreatedDate": 1380232103970,
                "CreatedBy": "",
                "hgId": "5e26f020-26f5-11e3-895a-4b3c71e041ac",
                "Archived": false,
                "AnswerType": "ScaleRating",
                "Category": "Business Alignment",
                "QuestionText": "Seeks to understand other programs in the department, including their services, deliverables, and measures."
            },
            {
                "__v": 0,
                "_id": "5244abb3e10d1f6524000118",
                "ModifiedDate": 1380232115511,
                "ModifiedBy": "",
                "CreatedDate": 1380232115511,
                "CreatedBy": "",
                "hgId": "6507f472-26f5-11e3-895a-4b3c71e041ac",
                "Archived": false,
                "AnswerType": "ScaleRating",
                "Category": "Writing",
                "QuestionText": "Organizes information so that facts or ideas build upon one another to lead the reader to a specific conclusion."
            },
            {
                "__v": 0,
                "_id": "5244abb3e10d1f6524000118",
                "ModifiedDate": 1380232115511,
                "ModifiedBy": "",
                "CreatedDate": 1380232115511,
                "CreatedBy": "",
                "hgId": "6507f472-26f5-11e3-895a-4b3c71e041ac",
                "Archived": false,
                "AnswerType": "SomethingElse",
                "Category": "Writing",
                "QuestionText": "Organizes information so that facts or ideas build upon one another to lead the reader to a specific conclusion."
            },
            {
                "__v": 0,
                "_id": "5244abb3e10d1f6524000118",
                "ModifiedDate": 1380232115511,
                "ModifiedBy": "",
                "CreatedDate": 1380232115511,
                "CreatedBy": "",
                "hgId": "6507f472-26f5-11e3-895a-4b3c71e041ac",
                "Archived": false,
                "AnswerType": "SomethingElse",
                "Category": "Thinking",
                "QuestionText": "Organizes information so that facts or ideas build upon one another to lead the reader to a specific conclusion."
            }];
    }
    return {
        get: get
    }
});