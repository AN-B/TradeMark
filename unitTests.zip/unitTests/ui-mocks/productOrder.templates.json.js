define(function() {
    function getAll() {
        return [
            {
                "AccountType" : "PointTransfer",
                "CreatedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate" : 1403521571429,
                "FriendlyId" : 1,
                "FulfillNote" : "",
                "ModifiedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                "ModifiedDate" : 1403521629525,
                "ProductItem" : {
                    "ExpireDate" : 1403634600000,
                    "ModifiedDate" : 1403521426729,
                    "ModifiedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate" : 1403521426729,
                    "CreatedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                    "hgId" : "0c40aa80-fac6-11e3-83ea-631642c0314c",
                    "ProductImageFile" : "d41368f0-fac5-11e3-9900-d95465c5e0ea.jpg",
                    "Instruction" : "",
                    "Status" : "Active",
                    "TeamName" : "",
                    "TeamId" : "",
                    "GroupName" : "Mercury Industries",
                    "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                    "FriendlyGroupId" : 1,
                    "AccessLevel" : "WithinGroup",
                    "AvailableNumber" : 2,
                    "Limit" : -1,
                    "PointCost" : 10,
                    "RedeemInstruction" : "1.2010 Model",
                    "Description" : "Sale Bike",
                    "Name" : "Sale Bike X2"
                },
                "Quantity" : 1,
                "Recipient" : {
                    "MemberId" : "2de5a650-a0c6-11e2-a665-cf2c2ef6e160",
                    "UserId" : "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160",
                    "FullName" : "Elaine Benes"
                },
                "Requester" : {
                    "MemberId" : "23318070-9cd5-11e2-a3a4-25024474fe63",
                    "UserId" : "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "FullName" : "Gary Wei"
                },
                "Status" : "Cancelled",
                "hgId" : '3cf4d640-9cd2-11e2-a3a4-25024474fe63'
            },
            {
                "AccountType" : "PointTransfer",
                "CreatedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                "CreatedDate" : 1403521571429,
                "FriendlyId" : 1,
                "FulfillNote" : "",
                "ModifiedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                "ModifiedDate" : 1403521629525,
                "ProductItem" : {
                    "ExpireDate" : 1403634600000,
                    "ModifiedDate" : 1403521426729,
                    "ModifiedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                    "CreatedDate" : 1403521426729,
                    "CreatedBy" : "3cf59990-9cd2-11e2-a3a4-25024474fe63",
                    "hgId" : "0c40aa80-fac6-11e3-83ea-631642c0314c",
                    "ProductImageFile" : "d41368f0-fac5-11e3-9900-d95465c5e0ea.jpg",
                    "Instruction" : "",
                    "Status" : "Active",
                    "TeamName" : "",
                    "TeamId" : "",
                    "GroupName" : "Mercury Industries",
                    "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                    "FriendlyGroupId" : 1,
                    "AccessLevel" : "WithinGroup",
                    "AvailableNumber" : 2,
                    "Limit" : -1,
                    "PointCost" : 10,
                    "RedeemInstruction" : "1.2010 Model",
                    "Description" : "Sale Bike",
                    "Name" : "Sale Bike X2"
                },
                "Quantity" : 1,
                "Recipient" : {
                    "MemberId" : "2de5a650-a0c6-11e2-a665-cf2c2ef6e160",
                    "UserId" : "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160",
                    "FullName" : "Elaine Benes"
                },
                "Requester" : {
                    "MemberId" : "23318070-9cd5-11e2-a3a4-25024474fe63",
                    "UserId" : "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                    "FullName" : "Gary Wei"
                },
                "Status" : "Fulfilled",
                "hgId" : '3cf4d640-9cd2-11e2-a3a4-25024474fe63'
            }
        ]
    }

    return {
        getAll: getAll
    };
});