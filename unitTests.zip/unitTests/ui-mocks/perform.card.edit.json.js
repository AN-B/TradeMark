define(function () {
    function get() {
        return {
            "hgId": "72a3c130-101c-11e3-bba0-8d9c8faa9d96",
            "Title": "test 3 sections",
            "Description": "test 3 sections",
            "IsTemplate": false,
            "OriginalId": "",
            "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
            "GroupName": "Mercury",
            "Status": "ReadyToAssign",
            "Type": "General",
            "PeopleTypes": [
                {
                    "_id": "521e56cbbb2af40000000035",
                    "AllowMultiple": false,
                    "Required": false,
                    "ContainQuestionForMe": false,
                    "PeopleTypeName": "Manager"
                },
                {
                    "_id": "521e56cbbb2af40000000034",
                    "AllowMultiple": false,
                    "Required": false,
                    "ContainQuestionForMe": true,
                    "PeopleTypeName": "Subject"
                },
                {
                    "_id": "521e56cbbb2af40000000033",
                    "AllowMultiple": false,
                    "Required": false,
                    "ContainQuestionForMe": false,
                    "PeopleTypeName": "Peer"
                }
            ],
            "DetectableRolesOnly": true,
            "ExpireDate": 1409256011971,
            "QnSs": [
                {
                    "hgId": "72a3c131-101c-11e3-bba0-8d9c8faa9d96",
                    "Type": "Section",
                    "Title": "Sections 1",
                    "Description": "Test sections uno"
                },
                {
                    "hgId": "72a3c132-101c-11e3-bba0-8d9c8faa9d96",
                    "Type": "Question",
                    "QuestionText": "Test textbox",
                    "QuestionHelp": "",
                    "Confidential": false,
                    "ToBeAnsweredBy": [
                        "Subject"
                    ],
                    "AllowComments": false,
                    "AnswerType": "ShortText",
                    "AnswerSelectors": [],
                    "SectionId": "72a3c131-101c-11e3-bba0-8d9c8faa9d96"
                },
                {
                    "hgId": "72a3c133-101c-11e3-bba0-8d9c8faa9d96",
                    "Type": "Question",
                    "QuestionText": "test rating",
                    "QuestionHelp": "",
                    "Confidential": false,
                    "ToBeAnsweredBy": [
                        "Subject"
                    ],
                    "AllowComments": false,
                    "AnswerType": "ScaleRating",
                    "AnswerSelectors": [
                        {
                            "_id": "521e56cbbb2af4000000003a",
                            "Text": "bad",
                            "Value": 1
                        },
                        {
                            "_id": "521e56cbbb2af40000000039",
                            "Text": "not so bad",
                            "Value": 2
                        },
                        {
                            "_id": "521e56cbbb2af40000000038",
                            "Text": "OK I guess",
                            "Value": 3
                        },
                        {
                            "_id": "521e56cbbb2af40000000037",
                            "Text": "good",
                            "Value": 4
                        },
                        {
                            "_id": "521e56cbbb2af40000000036",
                            "Text": "very good",
                            "Value": 5
                        }
                    ],
                    "SectionId": "72a3c131-101c-11e3-bba0-8d9c8faa9d96"
                },
                {
                    "hgId": "cb343860-101d-11e3-bba0-8d9c8faa9d96",
                    "Type": "Section",
                    "Title": "Section 2",
                    "Description": "test section 2"
                },
                {
                    "hgId": "cb343861-101d-11e3-bba0-8d9c8faa9d96",
                    "Type": "Question",
                    "QuestionText": "test question 1",
                    "QuestionHelp": "",
                    "Confidential": false,
                    "ToBeAnsweredBy": [
                        "Subject"
                    ],
                    "AllowComments": false,
                    "AnswerType": "ShortText",
                    "AnswerSelectors": [],
                    "SectionId": "cb343860-101d-11e3-bba0-8d9c8faa9d96"
                },
                {
                    "hgId": "cb343862-101d-11e3-bba0-8d9c8faa9d96",
                    "Type": "Question",
                    "QuestionText": "Test 12221",
                    "QuestionHelp": "",
                    "Confidential": false,
                    "ToBeAnsweredBy": [
                        "Subject"
                    ],
                    "AllowComments": false,
                    "AnswerType": "RadioButton",
                    "AnswerSelectors": [
                        {
                            "_id": "521e590ebb2af4000000004a",
                            "Text": "option 1",
                            "Value": 1
                        },
                        {
                            "_id": "521e590ebb2af40000000049",
                            "Text": "option 2",
                            "Value": 2
                        },
                        {
                            "_id": "521e590ebb2af40000000048",
                            "Text": "option 3",
                            "Value": 3
                        }
                    ],
                    "SectionId": "cb343860-101d-11e3-bba0-8d9c8faa9d96"
                },
                {
                    "hgId": "cb343863-101d-11e3-bba0-8d9c8faa9d96",
                    "Type": "Section",
                    "Title": "Section 3",
                    "Description": "test section 3"
                },
                {
                    "hgId": "cb343864-101d-11e3-bba0-8d9c8faa9d96",
                    "Type": "Question",
                    "QuestionText": "question 1",
                    "QuestionHelp": "",
                    "Confidential": false,
                    "ToBeAnsweredBy": [
                        "Subject"
                    ],
                    "AllowComments": false,
                    "AnswerType": "Option",
                    "AnswerSelectors": [
                        {
                            "_id": "521e590ebb2af40000000047",
                            "Text": "option 2",
                            "Value": 1
                        },
                        {
                            "_id": "521e590ebb2af40000000046",
                            "Text": "option 2",
                            "Value": 2
                        },
                        {
                            "_id": "521e590ebb2af40000000045",
                            "Text": "option 3",
                            "Value": 3
                        }
                    ],
                    "SectionId": "cb343863-101d-11e3-bba0-8d9c8faa9d96"
                },
                {
                    "hgId": "cb343865-101d-11e3-bba0-8d9c8faa9d96",
                    "Type": "Question",
                    "QuestionText": "checkbox question",
                    "QuestionHelp": "",
                    "Confidential": false,
                    "ToBeAnsweredBy": [
                        "Subject"
                    ],
                    "AllowComments": false,
                    "AnswerType": "CheckBox",
                    "AnswerSelectors": [
                        {
                            "_id": "521e590ebb2af40000000044",
                            "Text": "checkbox 1",
                            "Value": 1
                        },
                        {
                            "_id": "521e590ebb2af40000000043",
                            "Text": "checkbox 2",
                            "Value": 2
                        },
                        {
                            "_id": "521e590ebb2af40000000042",
                            "Text": "checkbox 3",
                            "Value": 3
                        }
                    ],
                    "SectionId": "cb343863-101d-11e3-bba0-8d9c8faa9d96"
                }
            ]
        };
    }
    function validateCard() {
        return {
            Description: '',
            PeopleTypes: [{
                $$hashKey: '03H',
                PeopleTypeName: 'Manager'
            }],
            Status: 'ReadyToAssign',
            Title: 'Test',
            Type: 'General',
            cardValid: true,
            hgId: 'e269ed30-4894-11e4-bd9f-590e2c8c5821',
            titleValid: true,
            QnSs: [{
                $$hashKey: "0CU",
                AllowComments: false,
                AnswerSelectors: [],
                AnswerType: 'Paragraph',
                Answers: [],
                Confidential: false,
                Description: '',
                NAEnable: false,
                NAText: 'N/A',
                OptionalTo: [],
                QuestionHelp: '',
                QuestionId: '',
                QuestionText: 'Test',
                RecognitionFilter: [],
                SectionId: '',
                Title: '',
                ToBeAnsweredBy: [
                    'Manager'
                ],
                Type: 'Question',
                answerTypeValid: true,
                descValid: true,
                focus: true,
                hgId: '',
                questAnsweredByValid: true,
                questHelpValid: true,
                questTextValid: true,
                questValid: true,
                recognitionAnswerTypeValid: true,
                selected: true,
                titleValid: true
            }]
        };
    }

    return {
        get: get,
        validateCard: validateCard
    };
});

