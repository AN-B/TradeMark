define(function () {
    function getMemberPermission() {
        return [
             "OffBoarded",
            "Basic",
            "GiveRecognition",
            "SendCreditsInRecognition",
            "SendPointsInRecognition",
            "CreateTrack",
            "DeleteRecognition"
        ];
    }
    function getRolesPermissionsTabs() {
        return {"Roles": [
            {Description: "A OffBoarded Employee", Role: "OffBoarded", selected: false},
            {Description: "A regular Employee", Role: "Employee", selected: false},
            {Description: "Manager", Role: "Manager", selected: false},
            {Description: "Executive", Role: "Executive", selected: false},
            {Description: "Admin of the group, generally HR staff", Role: "Admin", selected: false}
        ]
        }
    }

    function getFilteredRolePermissions () {
        return [
            "OffBoarded",
            "Basic",
            "GiveRecognition",
            "SendCreditsInRecognition",
            "SendPointsInRecognition",
            "CreateTrack",
            "DeleteRecognition"
        ];
    }

    function getPermissions() {
        var arrPermissions = [], allPermission = getMemberPermission();
        allPermission.forEach(function(permission) {
            arrPermissions.push(permission.MemberPermission);
        });
        return arrPermissions;
    }

    return {
        getMemberPermission : getMemberPermission,
        getPermissions: getPermissions,
        getRolesPermissionsTabs: getRolesPermissionsTabs,
        getFilteredRolePermissions : getFilteredRolePermissions
    }
});