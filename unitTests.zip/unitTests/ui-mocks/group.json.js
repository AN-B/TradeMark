define(function () {
    function getCurrentGroupMembers() {
        return [
            {
                "GroupRoleId": "GroupRegularMemeber",
                "__v": 0,
                "_id": "515c822abe7d7778b7000042",
                "ModifiedDate": 1365017130663,
                "ModifiedBy": "",
                "CreatedDate": 1365017130663,
                "CreatedBy": "",
                "hgId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                "GravatarEmail": "",
                "ExperiencePoint": 1870,
                "FollowedTrackMemberIds": [
                    "6c85b89b-860b-454f-b6a5-9d6839477972",
                    "a79dfa57-9740-4158-bc3c-fa8613e302c6",
                    "1fef59de-d1fd-491b-82cf-590b1f69c337",
                    "d2e0ac10-a119-11e2-b177-7d64c8315189"
                ],
                "FollowedMemberIds": [
                    "6c85b89b-860b-454f-b6a5-9d6839477972",
                    "a79dfa57-9740-4158-bc3c-fa8613e302c6",
                    "1fef59de-d1fd-491b-82cf-590b1f69c337"
                ],
                "EmployeeId": "HG003",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600292,
                "EndingDate": 1365016736818,
                "StartingDate": 1341244800000,
                "Position": "Server Architect Engineer",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "HGAdmin"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Gary Wei",
                "LastName": "Wei",
                "FirstName": "Gang",
                "UserId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
                "AbbrvName": "Gang W.",
                "id": null
            },
            {
                "_id": "517ad428d380da1a57000086",
                "__v": 0,
                "ModifiedDate": 1367004200622,
                "ModifiedBy": "",
                "CreatedDate": 1367004200622,
                "CreatedBy": "",
                "hgId": "c15985d0-aea6-11e2-b79d-512ef31a350a",
                "GravatarEmail": "",
                "ExperiencePoint": 710,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG014",
                "FriendlyId": "",
                "GroupDepartmentName": "Operations",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600584,
                "EndingDate": 1367003362692,
                "StartingDate": 1365483600000,
                "Position": "Product Manager",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Hunter Lane",
                "LastName": "Lane",
                "FirstName": "Hunter",
                "UserId": "c139a1c0-aea6-11e2-b79d-512ef31a350a",
                "AbbrvName": "Hunter L.",
                "id": null
            },
            {
                "_id": "517ad428d380da1a57000087",
                "__v": 0,
                "ModifiedDate": 1367004200625,
                "ModifiedBy": "",
                "CreatedDate": 1367004200625,
                "CreatedBy": "",
                "hgId": "c159fb00-aea6-11e2-b79d-512ef31a350a",
                "GravatarEmail": "",
                "ExperiencePoint": 710,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG008",
                "FriendlyId": "",
                "GroupDepartmentName": "Operations",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600622,
                "EndingDate": 1367003362692,
                "StartingDate": 1354687200000,
                "Position": "Operations Manager",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "OffBoarded"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Matthew Bryant",
                "LastName": "Bryant",
                "FirstName": "Matthew",
                "UserId": "c13a6510-aea6-11e2-b79d-512ef31a350a",
                "AbbrvName": "Matthew B.",
                "id": null
            },
            {
                "_id": "517ad428d380da1a57000088",
                "__v": 0,
                "ModifiedDate": 1367004200631,
                "ModifiedBy": "",
                "CreatedDate": 1367004200631,
                "CreatedBy": "",
                "hgId": "c15b0c70-aea6-11e2-b79d-512ef31a350a",
                "GravatarEmail": "",
                "ExperiencePoint": 710,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG017",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600635,
                "EndingDate": 1367003362692,
                "StartingDate": 1366866000000,
                "Position": "Web Developer",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Miriam Diversiev",
                "LastName": "Diversiev",
                "FirstName": "Miriam",
                "UserId": "c13cfd20-aea6-11e2-b79d-512ef31a350a",
                "AbbrvName": "Miriam D.",
                "id": null
            },
            {
                "_id": "517ad428d380da1a57000089",
                "__v": 0,
                "ModifiedDate": 1367004200635,
                "ModifiedBy": "",
                "CreatedDate": 1367004200635,
                "CreatedBy": "",
                "hgId": "c15ba8b0-aea6-11e2-b79d-512ef31a350a",
                "GravatarEmail": "",
                "ExperiencePoint": 850,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG016",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600653,
                "EndingDate": 1367003362692,
                "StartingDate": 1366779600000,
                "Position": "Software Engineer",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Cezary Wojtkowski",
                "LastName": "Wojtkowski",
                "FirstName": "Cezary",
                "UserId": "c13f2000-aea6-11e2-b79d-512ef31a350a",
                "AbbrvName": "Cezary W.",
                "id": null
            },
            {
                "_id": "519cd29afed525000000006a",
                "__v": 0,
                "ModifiedDate": 1369232026115,
                "ModifiedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "CreatedDate": 1369232026115,
                "CreatedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "hgId": "d0d22e20-c2e9-11e2-a633-35224a3a67f7",
                "GravatarEmail": "",
                "ExperiencePoint": 750,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG003",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600728,
                "EndingDate": 1369191447376,
                "StartingDate": 1234571130000000,
                "Position": "Server Architect Engineer",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Staff"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Gary Wei",
                "LastName": "Wei",
                "FirstName": "Gang",
                "UserId": "b1283100-b911-11e2-9ce1-b17fe9feb8ae",
                "AbbrvName": "Gang W.",
                "id": null
            },
            {
                "__v": 0,
                "_id": "51641841c35eb3cede000053",
                "ModifiedDate": 1365514305856,
                "ModifiedBy": "",
                "CreatedDate": 1365514305856,
                "CreatedBy": "",
                "hgId": "d2ddecf0-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 1293,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [
                    "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
                ],
                "EmployeeId": "HG001",
                "FriendlyId": "",
                "GroupDepartmentName": "Executive",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600796,
                "EndingDate": 1365474004858,
                "StartingDate": 1335888000000,
                "Position": "CEO",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Executive"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Vip Sandhir",
                "LastName": "Sandhir",
                "FirstName": "Vipon",
                "UserId": "d2c311f0-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Vipon S.",
                "id": null
            },
            {
                "__v": 0,
                "_id": "51641841c35eb3cede000054",
                "ModifiedDate": 1365514305857,
                "ModifiedBy": "",
                "CreatedDate": 1365514305857,
                "CreatedBy": "",
                "hgId": "d2de3b10-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 1520,
                "FollowedTrackMemberIds": [
                    "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
                    "d2defe60-a119-11e2-b177-7d64c8315189",
                    "d2e0d320-a119-11e2-b177-7d64c8315189",
                    "d2de3b11-a119-11e2-b177-7d64c8315189"
                ],
                "FollowedMemberIds": [],
                "EmployeeId": "HG007",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600815,
                "EndingDate": 1365474004858,
                "StartingDate": 1349107200000,
                "Position": "Lead UI Engineer",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Philip Plekhanov",
                "LastName": "Plekhanov",
                "FirstName": "Philip",
                "UserId": "d2c38720-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Philip P.",
                "id": null
            },
            {
                "_id": "51641841c35eb3cede000055",
                "__v": 0,
                "ModifiedDate": 1365514305857,
                "ModifiedBy": "",
                "CreatedDate": 1365514305857,
                "CreatedBy": "",
                "hgId": "d2de3b11-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 710,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG013",
                "FriendlyId": "",
                "GroupDepartmentName": "QA",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600128,
                "EndingDate": 1365474004858,
                "StartingDate": 1333900800000,
                "Position": "QA Tester",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Liliana Zektser",
                "LastName": "Zektser",
                "FirstName": "Liliana",
                "UserId": "d2c44a70-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Liliana Z.",
                "id": null
            },
            {
                "_id": "51641841c35eb3cede000056",
                "__v": 0,
                "ModifiedDate": 1365514305859,
                "ModifiedBy": "",
                "CreatedDate": 1365514305859,
                "CreatedBy": "",
                "hgId": "d2de8930-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 870,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG006",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600177,
                "EndingDate": 1365474004858,
                "StartingDate": 1345478400000,
                "Position": "UX/Creative Lead",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Amie Chen",
                "LastName": "Chen",
                "FirstName": "Amie",
                "UserId": "d2c4e6b0-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Amie C.",
                "id": null
            },
            {
                "__v": 0,
                "_id": "51641841c35eb3cede000057",
                "ModifiedDate": 1365514305860,
                "ModifiedBy": "",
                "CreatedDate": 1365514305860,
                "CreatedBy": "",
                "hgId": "d2de8931-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 710,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG012",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600194,
                "EndingDate": 1365474004858,
                "StartingDate": 1359392400000,
                "Position": "Senior UI Engineer",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Shihoko Ui",
                "LastName": "Ui",
                "FirstName": "Shihoko",
                "UserId": "d2c534d0-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Shihoko U.",
                "id": null
            },
            {
                "_id": "51641841c35eb3cede000059",
                "__v": 0,
                "ModifiedDate": 1365514305863,
                "ModifiedBy": "",
                "CreatedDate": 1365514305863,
                "CreatedBy": "",
                "hgId": "d2defe60-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 4397,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG004",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600212,
                "EndingDate": 1365474004858,
                "StartingDate": 1343059200000,
                "Position": "Lead Software Engineer",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Katrina Manoshin",
                "LastName": "Manoshin",
                "FirstName": "Katrina",
                "UserId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Katrina M.",
                "id": null
            },
            {
                "__v": 0,
                "_id": "51641841c35eb3cede00005a",
                "ModifiedDate": 1365514305863,
                "ModifiedBy": "",
                "CreatedDate": 1365514305863,
                "CreatedBy": "",
                "hgId": "d2df2570-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 1860,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG011",
                "FriendlyId": "",
                "GroupDepartmentName": "Operations",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600830,
                "EndingDate": 1365474004858,
                "StartingDate": 1359046800000,
                "Position": "Director of Implementation",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "HGAdmin"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Erin Guenther",
                "LastName": "Guenther",
                "FirstName": "Erin",
                "UserId": "d2bf8f80-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Erin G.",
                "id": null
            },
            {
                "_id": "51641841c35eb3cede00005c",
                "__v": 0,
                "ModifiedDate": 1365514305872,
                "ModifiedBy": "",
                "CreatedDate": 1365514305872,
                "CreatedBy": "",
                "hgId": "d2e08500-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 710,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG010",
                "FriendlyId": "",
                "GroupDepartmentName": "Development",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600257,
                "EndingDate": 1365474004858,
                "StartingDate": 1358182800000,
                "Position": "SVP Architecture",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "Employee"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Demetri Maltsiniotis",
                "LastName": "Maltsiniotis",
                "FirstName": "Demetri",
                "UserId": "d2c052d0-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Demetri M.",
                "id": null
            },
            {
                "_id": "51641841c35eb3cede00005f",
                "__v": 0,
                "ModifiedDate": 1365514305875,
                "ModifiedBy": "",
                "CreatedDate": 1365514305875,
                "CreatedBy": "",
                "hgId": "d2e0d321-a119-11e2-b177-7d64c8315189",
                "GravatarEmail": "",
                "ExperiencePoint": 710,
                "FollowedTrackMemberIds": [],
                "FollowedMemberIds": [],
                "EmployeeId": "HG009",
                "FriendlyId": "",
                "GroupDepartmentName": "QA",
                "DefaultPaymentProfileId": "",
                "InvitedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "ApprovedOrDeniedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
                "Preference": {
                    "WeekendDailyRecap": false
                },
                "MyManagers": [],
                "MembershipStatus": "Active",
                "LastDailyRecapSentDate": 1372179600275,
                "EndingDate": 1365474004858,
                "StartingDate": 1355158800000,
                "Position": "Quality Assurance Lead",
                "RemovedPermissions": [],
                "AddedPermissions": [],
                "RolesInGroup": [
                    "HGAdmin"
                ],
                "PublicDisplayName": "",
                "GroupName": "Mercury",
                "GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
                "FullName": "Marcie Carlos",
                "LastName": "Carlos",
                "FirstName": "Marcie",
                "UserId": "d2c24ea0-a119-11e2-b177-7d64c8315189",
                "AbbrvName": "Marcie C.",
                "id": null
            }
        ];
    }

    function getMyBookmarkedTeams() {
        return [
            {
                "hgId": "732fc900-32ad-11e4-b35f-6f91c6460e4d",
                "Name": "merry team",
                "AvatarId": "732fc900-32ad-11e4-b35f-6f91c6460e4d",
                "Type": "Team"
            },
            {
                "hgId": "a1a36d70-d794-11e2-aedc-3d0929110705",
                "Name": "Operations",
                "AvatarId": "a1a36d70-d794-11e2-aedc-3d0929110705",
                "Type": "Team"
            }
        ];
    }

    function getMembersAndDepartments() {
        return [
            {
                "Id": "0a48fd80-d921-11e2-9b34-057edb55ccee",
                "Name": "Dustin Lasky",
                "AvatarId": "0a463e60-d921-11e2-9b34-057edb55ccee",
                "Type": "Member",
                "Department": ""
            },
            {
                "Id": "10a555d0-e9a6-11e2-b673-edd279fc6025",
                "Name": "Eric, Blair",
                "AvatarId": "10a1fa70-e9a6-11e2-b673-edd279fc6025",
                "Type": "Member",
                "Department": "Development"
            }
        ]
    };
    function getCurrentMembersDto() {
        return [
            {
                "hgId": "2de4bbf0-a0c6-11e2-a665-cf2c2ef6e160",
                "FullName": "Cosmo Kramer",
                "AvatarId": "2d84e8b0-a0c6-11e2-a665-cf2c2ef6e160",
                "UserId": "2d84e8b0-a0c6-11e2-a665-cf2c2ef6e160",
                "Type": "Member",
                "AbbrvName": "Cosmo K.",
                "GroupDepartmentName": "Sales",
                "Role": "Employee",
                "SPND": 30,
                "TRFR": 100
            },
            {
                "hgId": "2de57f40-a0c6-11e2-a665-cf2c2ef6e160",
                "FullName": "George Costanza",
                "AvatarId": "2d80a2f0-a0c6-11e2-a665-cf2c2ef6e160",
                "UserId": "2d80a2f0-a0c6-11e2-a665-cf2c2ef6e160",
                "Type": "Member",
                "AbbrvName": "George C.",
                "GroupDepartmentName": "Sales",
                "Role": "Employee",
                "SPND": 5490,
                "TRFR": 8580
            },
            {
                "hgId": "2de5a650-a0c6-11e2-a665-cf2c2ef6e160",
                "FullName": "Elaine Benes",
                "AvatarId": "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160",
                "UserId": "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160",
                "Type": "Member",
                "AbbrvName": "Elaine B.",
                "GroupDepartmentName": "Operations",
                "Role": "Admin",
                "SPND": 630,
                "TRFR": 7580
            },
            {
                "hgId": "2de5f470-a0c6-11e2-a665-cf2c2ef6e160",
                "FullName": "Jerry Seinfeld",
                "AvatarId": "2d82ece0-a0c6-11e2-a665-cf2c2ef6e160",
                "UserId": "2d82ece0-a0c6-11e2-a665-cf2c2ef6e160",
                "Type": "Member",
                "AbbrvName": "Jerry S.",
                "GroupDepartmentName": "Executive",
                "Role": "Executive",
                "SPND": 6490,
                "TRFR": 1645
            },
            {
                "hgId": "7bb09420-c868-11e2-aa05-198054fd4117",
                "FullName": "James Peterman",
                "AvatarId": "7b9bfab0-c868-11e2-aa05-198054fd4117",
                "UserId": "7b9bfab0-c868-11e2-aa05-198054fd4117",
                "Type": "Member",
                "AbbrvName": "James P.",
                "GroupDepartmentName": "Sales",
                "Role": "Employee",
                "SPND": 90,
                "TRFR": 0
            },
            {
                "hgId": "ede16340-c87b-11e2-aa05-198054fd4117",
                "FullName": "David Puddy",
                "AvatarId": "edcffe20-c87b-11e2-aa05-198054fd4117",
                "UserId": "edcffe20-c87b-11e2-aa05-198054fd4117",
                "Type": "Member",
                "AbbrvName": "Dave P.",
                "GroupDepartmentName": "",
                "Role": "Employee",
                "SPND": 120,
                "TRFR": 500
            }
        ];
    }

    function getCu() {
        return {
            "hgId": "ede16340-c87b-11e2-aa05-198054fd4117",
            "FullName": "David Puddy",
            "AvatarId": "edcffe20-c87b-11e2-aa05-198054fd4117",
            "UserId": "edcffe20-c87b-11e2-aa05-198054fd4117",
            "Type": "Member",
            "AbbrvName": "Dave P.",
            "GroupDepartmentName": "",
            "Role": "Employee",
            "SPND": 120,
            "TRFR": 500
        };
    }

    function getMemberOffboardInfo() {
        return {
            "directReports":[],
            "email": "cu@highground.com",
            "checkList":[{"Name":"CompanyGoalCycleOwner","Count":1},{"Name":"CompanyGoalOwner","Count":1}]
        }
    }

    function getCurrentGroup() {
        return {
            "BadgeDefaults": [
                {
                    "Id": "1e38a930-a21c-11e2-be0d-0d0214757a1f",
                    "Type": "Goal"
                },
                {
                    "Id": "fd22ae50-b763-11e2-915e-e74bcdc5cb17",
                    "Type": "Objective"
                },
                {
                    "Id": "11674da0-cec8-11e2-9e7e-b5cf618e3622",
                    "Type": "Milestone"
                },
                {
                    "Id": "d3ec86b0-ad62-11e2-882a-81d4fa38f1ec",
                    "Type": "Welcome"
                },
                {
                    "Id": "750ace70-b72d-11e2-a789-3de6b536f51c",
                    "Type": "Birthday"
                },
                {
                    "Id": "2d4bed30-cd4e-11e2-9ad8-9b6c4e20c79e",
                    "Type": "Anniversary"
                },
                {
                    "Id": "1ac083d0-ef07-11e2-b942-c17f4ea8d805",
                    "Type": "News"
                }
            ],
            "BannerBackgroundColor": "",
            "BannerBackgroundImage": "",
            "BannerLink1Text": "Element",
            "BannerLink1Url": "http://en.wikipedia.org/wiki/Mercury_(element)",
            "BannerLink2Text": "Planet",
            "BannerLink2Url": "http://en.wikipedia.org/wiki/Mercury_(planet)",
            "BannerLink3Text": "Mythology",
            "BannerLink3Url": "http://en.wikipedia.org/wiki/Mercury_(mythology)",
            "BannerText": "Mercury Industries",
            "BannerTextColor": "",
            "BannerUrl": "./static/templates/banner/acme.html",
            "BillMeAllowed": true,
            "BillingAddress": {
                "Address1": "600 W. Chicago Ave.1396583597307",
                "Address2": "Suite 775",
                "City": "Chicago",
                "State": "IL",
                "Zip": "60654"
            },
            "BillingEmail": "erin@highground.com",
            "BillingPhone": "555.555.5555",
            "BillingRep": "Erin Guenther",
            "CorporateEmailDomain": false,
            "CreatedBy": "5e42c56e-5b17-4070-817f-d924a5cd7462",
            "CreatedDate": 1365043755412,
            "CreditLimit": 110000,
            "CreditMasterMemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
            "CreditSetting": {
                "DefaultTransferAmount": 100,
                "MaxRecognition": 500,
                "MaxSpendAmount": 2000,
                "MaxTransfer": 2000,
                "MinRecognition": 40,
                "MinSpendAmount": 200,
                "MinTransfer": 20
            },
            "PointSetting": {},
            "FriendlyGroupId": 1,
            "GroupName": "Mercury Industries",
            "HGAccountId": "HG201300001",
            "IsPrivateGroup": false,
            "MainAddress": {
                "Address1": "600 W. Chicago Ave.",
                "Address2": "Suite 775",
                "City": "Chicago",
                "State": "IL",
                "Zip": "60654"
            },
            "MainFax": "855-694-4669",
            "MainPhone": "855-694-4669",
            "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
            "ModifiedDate": 1396583600049,
            "Preference": {
                "AnniversaryEmailEnabled": false,
                "BirthdayEmailEnabled": false,
                "DailyRecapEnabled": false,
                "FeatureFlags": [
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [],
                        "FeatureName": "EnablePerform"
                    },
                    {
                        "FeatureEnabled": false,
                        "FeatureMeta": [
                            {
                                "Value": "true",
                                "Name": "LinkedIn"
                            },
                            {
                                "Value": "false",
                                "Name": "Facebook"
                            }
                        ],
                        "FeatureName": "ShareLink"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [],
                        "FeatureName": "IsFoundingCompany"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [
                            {
                                "Value": "Alz_Cert1.svg,Alz_Cert2.svg,Alz_Cert3.svg",
                                "Name": "CertificateNames"
                            }
                        ],
                        "FeatureName": "CertificateTemplates"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [
                            {
                                "Value": "http://www.google.com",
                                "Name": "TutorialA"
                            }
                        ],
                        "FeatureName": "TutorialUrl"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [],
                        "FeatureName": "Recognition2"
                    },
                    {
                        "FeatureEnabled": false,
                        "FeatureMeta": [],
                        "FeatureName": "ForSalesDemo"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [],
                        "FeatureName": "DisableRecognition"
                    },
                    {
                        "FeatureEnabled": false,
                        "FeatureMeta": [],
                        "FeatureName": "DisableTracks"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [],
                        "FeatureName": "DisableMotivate"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [
                            {
                                "Value": "wayne-email-banner.png",
                                "Name": "Filename"
                            }
                        ],
                        "FeatureName": "BrandedEmail"
                    },
                    {
                        "FeatureEnabled": false,
                        "FeatureMeta": [],
                        "FeatureName": "EnableCoaching"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [
                            {
                                "Value": "OffBoarded",
                                "Name": "Roles"
                            },
                            {
                                "Value": "dashboardTabs.giftCards",
                                "Name": "Permissions"
                            }
                        ],
                        "FeatureName": "DisableFeatureByRole"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [
                            {
                                "Value": "OffBoarded",
                                "Name": "Roles"
                            },
                            {
                                "Value": "dashboardTabs.home, dashboardTabs.trophyRoom",
                                "Name": "Permissions"
                            }
                        ],
                        "FeatureName": "DisableFeatureByRole"
                    },
                    {
                        "FeatureEnabled": true,
                        "FeatureMeta": [
                            {
                                "Value": "OffBoarded",
                                "Name": "Roles"
                            },
                            {
                                "Value": "dashboardTabs.giftCards",
                                "Name": "Permissions"
                            }
                        ],
                        "FeatureName": "DisableFeatureByRole"
                    }
                ],
                "TimeZone": "CDT",
                "WeeklyRecapDay": "Wednesday",
                "WeeklyRecapEnabled": false
            },
            "PublicDisplayName": "HighGround Enterprise Solutions, Inc.",
            "RatePerPerson": 2,
            "StartBillingDate": 1368421200000,
            "TermsOfUse": {
                "Accepted": true,
                "AcceptMemberId": "2de5a650-a0c6-11e2-a665-cf2c2ef6e160",
                "AcceptMemberName": "Elaine Benes",
                "AcceptDate": 1380139485747
            },
            "TotalFloatCredit": 108500,
            "ValueLevelSetting": {
                "Enabled": false,
                "Levels": [
                    {
                        "Name": "Default",
                        "LimitPeriod": "NoLimit",
                        "ImageId": "bed2d940-b505-11e3-bd41-575b0b40ced4",
                        "LimitNumber": 0,
                        "RemainingToMe": 0,
                        "AvailabilityToRoles": [],
                        "CreditValue": 0,
                        "PointValue": 10
                    },
                    {
                        "Name": "Silver",
                        "LimitPeriod": "Month",
                        "ImageId": "valueRedstarLevel1",
                        "LimitNumber": 10,
                        "RemainingToMe": 0,
                        "AvailabilityToRoles": [
                            {
                                "RoleName": "Employee",
                                "LimitNumber": 10,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Manager",
                                "LimitNumber": 10,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Executive",
                                "LimitNumber": 10,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Admin",
                                "LimitNumber": 10,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Owner",
                                "LimitNumber": 10,
                                "Allowed": true
                            },
                            {
                                "RoleName": "HGAdmin",
                                "LimitNumber": 10,
                                "Allowed": true
                            }
                        ],
                        "CreditValue": 0,
                        "PointValue": 50
                    },
                    {
                        "Name": "Gold",
                        "LimitPeriod": "Month",
                        "ImageId": "valueRedstarLevel2",
                        "LimitNumber": 3,
                        "RemainingToMe": 0,
                        "AvailabilityToRoles": [
                            {
                                "RoleName": "Employee",
                                "LimitNumber": 3,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Manager",
                                "LimitNumber": 3,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Executive",
                                "LimitNumber": 3,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Admin",
                                "LimitNumber": 3,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Owner",
                                "LimitNumber": 3,
                                "Allowed": true
                            },
                            {
                                "RoleName": "HGAdmin",
                                "LimitNumber": 3,
                                "Allowed": true
                            }
                        ],
                        "CreditValue": 0,
                        "PointValue": 150
                    },
                    {
                        "Name": "Platinum",
                        "LimitPeriod": "Month",
                        "ImageId": "valueRedstarLevel3",
                        "LimitNumber": 1,
                        "RemainingToMe": 0,
                        "AvailabilityToRoles": [
                            {
                                "RoleName": "Employee",
                                "LimitNumber": 1,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Manager",
                                "LimitNumber": 1,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Executive",
                                "LimitNumber": 1,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Admin",
                                "LimitNumber": 1,
                                "Allowed": true
                            },
                            {
                                "RoleName": "Owner",
                                "LimitNumber": 1,
                                "Allowed": true
                            },
                            {
                                "RoleName": "HGAdmin",
                                "LimitNumber": 1,
                                "Allowed": true
                            }
                        ],
                        "CreditValue": 0,
                        "PointValue": 500
                    }
                ],
                "DefaultLevel": {}
            },
            "PointMasterMemberId": "2331f5a1-9cd5-11e2-a3a4-25024474fe63",
            "SSO": {
                "SAML": {
                    "cert": "foobar",
                    "uploaded_at": "1409765416490",
                    "type": "Custom",
                    "issuer": "foo",
                    "entryPoint": "bar"
                }
            },
            "__v": 43,
            "hgId": "3cf21720-9cd2-11e2-a3a4-25024474fe63"
        };
    }

    function getGroupManagers() {
        return [
            {
                "FullName": "Amie Chen",
                "UserId": "3cf94310-9cd2-11e2-a3a4-25024474fe63",
                "MemberId": "23310b40-9cd5-11e2-a3a4-25024474fe63",
                "hgId": "23310b40-9cd5-11e2-a3a4-25024474fe63",
                "DirectReports": 4
            },
            {
                "FullName": "Cu Barnes",
                "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "hgId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "DirectReports": 4
            },
            {
                "FullName": "Devon Miles",
                "UserId": "1b256150-1631-11e3-a738-6310b1217eba",
                "MemberId": "1b3d7d30-1631-11e3-a738-6310b1217eba",
                "hgId": "1b3d7d30-1631-11e3-a738-6310b1217eba",
                "DirectReports": 1
            }
        ];
    }

    function getGroupDisplaySettings() {
        return {
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "ModifiedDate": 1423090512291,
            "ModifiedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
            "CreatedDate": 1423090512291,
            "CreatedBy": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
            "hgId": "e0300820-acc0-11e4-86b9-b91fd8c4b905",
            "IPRange": [{
                "Start": "24.21.21.20",
                "End": "24.21.21.23",
            }],
            "GroupRecognitionAvatarInterval": 30,
            "RecognitionInterval": 60
        }
    }

    return {
        getCurrentGroupMembers: getCurrentGroupMembers,
        getCurrentMembersDto: getCurrentMembersDto,
        getCurrentGroup: getCurrentGroup,
        getCu: getCu,
        getMyBookmarkedTeams: getMyBookmarkedTeams,
        getMembersAndDepartments: getMembersAndDepartments,
        getGroupManagers: getGroupManagers,
        getGroupDisplaySettings: getGroupDisplaySettings,
        getMemberOffboardInfo: getMemberOffboardInfo
    };
});