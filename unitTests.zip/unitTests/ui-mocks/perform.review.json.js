define(function(){

	function getSubject() {
		return {
			"MyTypeInReview": "Subject",
			"__v": 51,
			"_id": "522379da3a6d8efad6000086",
			"ModifiedDate": 1387463104641,
			"ModifiedBy": "1378056666877",
			"CreatedDate": 1378056666877,
			"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
			"hgId": "4899bad0-132c-11e3-bc94-552338a0b1b7",
			"MyAnonymous": false,
			"ManagerCanSeeResponse": true,
			"MySubmitDate": 1387463104640,
			"MyDueDate": 1380344400000,
			"MyPercentAchieved": 50,
			"MyStatusInCurrentReview": "InProgress",
			"StatusByAdminView": "InProgress",
			"Peoples": [
				{
					"PeopleType": "Subject",
					"ModifiedDate": 1387463104640,
					"ModifiedBy": "",
					"CreatedDate": 1378056666876,
					"CreatedBy": "",
					"hgId": "",
					"ContainQuestionForMe": false,
					"Anonymous": false,
					"PercentAchieved": 50,
					"StatusInCurrentReview": "InProgress",
					"SubmitDate": 1387463104640,
					"DueDate": 1380344400000,
					"DeliveryDate": 1378056627027,
					"MemberFullname": "Katrina Manoshin",
					"EmployeeId": "",
					"UserId": "",
					"MemberId": "d2defe60-a119-11e2-b177-7d64c8315189"
				},
				{
					"PeopleType": "Manager",
					"ModifiedDate": 1387463104640,
					"ModifiedBy": "",
					"CreatedDate": 1378056666875,
					"CreatedBy": "",
					"hgId": "",
					"ContainQuestionForMe": false,
					"Anonymous": false,
					"PercentAchieved": 100,
					"StatusInCurrentReview": "Submitted",
					"SubmitDate": 1387463104639,
					"DueDate": 1380344400000,
					"DeliveryDate": 1378056627027,
					"MemberFullname": "Erin Guenther",
					"EmployeeId": "",
					"UserId": "",
					"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
				}
			],
			"Card": {
				"__v": 1,
				"_id": "522360e83a6d8efad6000072",
				"ModifiedDate": 1378056586238,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1378050280441,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "6a055300-131d-11e3-bc94-552338a0b1b7",
				"ExpireDate": 1409586280497,
				"DetectableRolesOnly": true,
				"PeopleTypes": [
					{
						"_id": "522360e83a6d8efad600005d",
						"AllowMultiple": false,
						"Required": false,
						"ContainQuestionForMe": true,
						"PeopleTypeName": "Manager"
					},
					{
						"_id": "522360e83a6d8efad600005c",
						"AllowMultiple": false,
						"Required": false,
						"ContainQuestionForMe": true,
						"PeopleTypeName": "Subject"
					},
					{
						"_id": "522360e83a6d8efad600005b",
						"AllowMultiple": false,
						"Required": false,
						"ContainQuestionForMe": false,
						"PeopleTypeName": "Peer"
					}
				],
				"Type": "General",
				"Status": "ReadyToAssign",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Sections": [
					{
						"ModifiedDate": 1378056586190,
						"ModifiedBy": "",
						"CreatedDate": 1378056586190,
						"CreatedBy": "",
						"hgId": "6a063d60-131d-11e3-bc94-552338a0b1b7",
						"Questions": [
							{
								"ModifiedDate": 1378056586193,
								"ModifiedBy": "",
								"CreatedDate": 1378056586192,
								"CreatedBy": "",
								"hgId": "6a063d61-131d-11e3-bc94-552338a0b1b7",
								"Answers": [],
								"AnswerSelectors": [],
								"AnswerType": "Paragraph",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Subject"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 1,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "question 1 section 1 subject"
							},
							{
								"ModifiedDate": 1378056586191,
								"ModifiedBy": "",
								"CreatedDate": 1378056586191,
								"CreatedBy": "",
								"hgId": "6a063d62-131d-11e3-bc94-552338a0b1b7",
								"Answers": [
									{
										"Selections": [],
										"TrackId": "",
										"Text": "sdsdsd",
										"PeopleType": "Manager",
										"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
									}
								],
								"AnswerSelectors": [],
								"AnswerType": "Paragraph",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Manager"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 2,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "question 2 section 1 manager"
							}
						],
						"SortOrder": 1,
						"Description": "Test Section 1",
						"Title": "Test Section 1"
					},
					{
						"ModifiedDate": 1378056586174,
						"ModifiedBy": "",
						"CreatedDate": 1378056586174,
						"CreatedBy": "",
						"hgId": "6a063d63-131d-11e3-bc94-552338a0b1b7",
						"Questions": [
							{
								"ICanSelectTrack": true,
								"ModifiedDate": 1378056586187,
								"ModifiedBy": "",
								"CreatedDate": 1378056586187,
								"CreatedBy": "",
								"hgId": "6a066470-131d-11e3-bc94-552338a0b1b7",
								"Answers": [
									{
										"Selections": [],
										"TrackId": "",
										"Text": "drere",
										"PeopleType": "Subject",
										"MemberId": "d2defe60-a119-11e2-b177-7d64c8315189"
									}
								],
								"AnswerSelectors": [],
								"AnswerType": "Templated",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Subject"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 1,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "Question 1 Section 2 subject"
							},
							{
								"ModifiedDate": 1378056586178,
								"ModifiedBy": "",
								"CreatedDate": 1378056586178,
								"CreatedBy": "",
								"hgId": "6a066471-131d-11e3-bc94-552338a0b1b7",
								"Answers": [
									{
										"Selections": [
											{
												"Text": "2",
												"Value": 2
											}
										],
										"SelectedValues": [
											2
										],
										"Text": "",
										"PeopleType": "Subject",
										"MemberId": "d2defe60-a119-11e2-b177-7d64c8315189"
									}
								],
								"AnswerSelectors": [
									{
										"_id": "522360e83a6d8efad6000071",
										"Text": "2",
										"Value": 1
									},
									{
										"_id": "522360e83a6d8efad6000070",
										"Text": "2",
										"Value": 2
									},
									{
										"_id": "522360e83a6d8efad600006f",
										"Text": "2",
										"Value": 3
									},
									{
										"_id": "522360e83a6d8efad600006e",
										"Text": "e",
										"Value": 4
									},
									{
										"_id": "522360e83a6d8efad600006d",
										"Text": "3",
										"Value": 5
									},
									{
										"_id": "522360e83a6d8efad600006c",
										"Text": "2",
										"Value": 6
									},
									{
										"_id": "522360e83a6d8efad600006b",
										"Text": "2",
										"Value": 7
									},
									{
										"_id": "522360e83a6d8efad600006a",
										"Text": "2",
										"Value": 8
									}
								],
								"AnswerType": "ScaleRating",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Subject"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 2,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "Question 2 Section 2 subject"
							},
							{
								"ModifiedDate": 1378056586175,
								"ModifiedBy": "",
								"CreatedDate": 1378056586175,
								"CreatedBy": "",
								"hgId": "6a066472-131d-11e3-bc94-552338a0b1b7",
								"Answers": [
									{
										"Selections": [
											{
												"Text": "Option 1",
												"Value": 1
											}
										],
										"SelectedValues": [
											1
										],
										"Text": "",
										"PeopleType": "Subject",
										"MemberId": "d2defe60-a119-11e2-b177-7d64c8315189"
									}
								],
								"AnswerSelectors": [
									{
										"_id": "522360e83a6d8efad6000069",
										"Text": "Option 1",
										"Value": 1
									},
									{
										"_id": "522360e83a6d8efad6000068",
										"Text": "Option 2",
										"Value": 2
									}
								],
								"AnswerType": "RadioButton",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Subject"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 3,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "Question 1 Section 2 Subject"
							}
						],
						"SortOrder": 2,
						"Description": "Test Section 2",
						"Title": "Test Section 2"
					},
					{
						"ModifiedDate": 1378056586121,
						"ModifiedBy": "",
						"CreatedDate": 1378056586121,
						"CreatedBy": "",
						"hgId": "6a066473-131d-11e3-bc94-552338a0b1b7",
						"Questions": [
							{
								"ICanSelectTrack": true,
								"ModifiedDate": 1378056586150,
								"ModifiedBy": "",
								"CreatedDate": 1378056586150,
								"CreatedBy": "",
								"hgId": "6a066474-131d-11e3-bc94-552338a0b1b7",
								"Answers": [
									{
										"Selections": [],
										"TrackId": "048b1970-fde1-11e2-a661-5b93d44b4bce",
										"Text": "jkkjkjkjkj",
										"PeopleType": "Manager",
										"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
									}
								],
								"AnswerSelectors": [],
								"AnswerType": "Templated",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Manager"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 1,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "Question 1 Section 3 Manager"
							},
							{
								"ModifiedDate": 1378056586126,
								"ModifiedBy": "",
								"CreatedDate": 1378056586126,
								"CreatedBy": "",
								"hgId": "6a066475-131d-11e3-bc94-552338a0b1b7",
								"Answers": [
									{
										"Selections": [
											{
												"Text": "2",
												"Value": 1
											}
										],
										"SelectedValues": [
											1
										],
										"Text": "",
										"PeopleType": "Manager",
										"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
									}
								],
								"AnswerSelectors": [
									{
										"_id": "522360e83a6d8efad6000067",
										"Text": "2",
										"Value": 1
									},
									{
										"_id": "522360e83a6d8efad6000066",
										"Text": "2",
										"Value": 2
									},
									{
										"_id": "522360e83a6d8efad6000065",
										"Text": "2",
										"Value": 3
									},
									{
										"_id": "522360e83a6d8efad6000064",
										"Text": "e",
										"Value": 4
									},
									{
										"_id": "522360e83a6d8efad6000063",
										"Text": "3",
										"Value": 5
									},
									{
										"_id": "522360e83a6d8efad6000062",
										"Text": "2",
										"Value": 6
									},
									{
										"_id": "522360e83a6d8efad6000061",
										"Text": "2",
										"Value": 7
									},
									{
										"_id": "522360e83a6d8efad6000060",
										"Text": "2",
										"Value": 8
									}
								],
								"AnswerType": "ScaleRating",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Subject",
									"Manager"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 2,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "Question 2 Section 3 subject manager"
							},
							{
								"ModifiedDate": 1378056586121,
								"ModifiedBy": "",
								"CreatedDate": 1378056586121,
								"CreatedBy": "",
								"hgId": "6a068b80-131d-11e3-bc94-552338a0b1b7",
								"Answers": [],
								"AnswerSelectors": [
									{
										"_id": "522360e83a6d8efad600005f",
										"Text": "Option 1",
										"Value": 1
									},
									{
										"_id": "522360e83a6d8efad600005e",
										"Text": "Option 2",
										"Value": 2
									}
								],
								"AnswerType": "RadioButton",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Subject"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 3,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "Question 3 Section 3 subject"
							}
						],
						"SortOrder": 3,
						"Description": "Test Section 3",
						"Title": "Test Section 3"
					},
					{
						"ModifiedDate": 1378056586117,
						"ModifiedBy": "",
						"CreatedDate": 1378056586117,
						"CreatedBy": "",
						"hgId": "6a068b81-131d-11e3-bc94-552338a0b1b7",
						"Questions": [
							{
								"ModifiedDate": 1378056586118,
								"ModifiedBy": "",
								"CreatedDate": 1378056586118,
								"CreatedBy": "",
								"hgId": "6a068b82-131d-11e3-bc94-552338a0b1b7",
								"Answers": [
									{
										"Selections": [],
										"TrackId": "",
										"Text": "wweewew",
										"PeopleType": "Manager",
										"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
									}
								],
								"AnswerSelectors": [],
								"AnswerType": "ShortText",
								"AllowComments": false,
								"ToBeAnsweredBy": [
									"Manager"
								],
								"VisibleTo": [],
								"Confidential": false,
								"SortOrder": 1,
								"Category": "",
								"QuestionHelp": "",
								"QuestionText": "question 1 Section 4 Manager"
							}
						],
						"SortOrder": 4,
						"Description": "Test Section 4",
						"Title": "Test Section 4"
					}
				],
				"OriginalId": "",
				"IsTemplate": false,
				"Description": "test 4 sections",
				"Title": "test 4 sections"
			},
			"CycleName": "Test review 4 sections",
			"CycleId": "489749d0-132c-11e3-bc94-552338a0b1b7"
		};
	}
	return {
		getSubject: getSubject
	};
});