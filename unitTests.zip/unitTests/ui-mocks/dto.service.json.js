define(function(){

	function getRecipients() {
		return [
			{
				"Id": "9c0cd910-cc94-11e2-863c-278252e8a19f",
				"Name": "Gary Test Team 8",
				"AvatarId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
				"Type": "Team"
			},
			{
				"Id": "be97cac0-302c-11e3-91d2-dd5c4c401983",
				"Name": "ww",
				"AvatarId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
				"Type": "Team"
			},
			{
				"Id": "b0989210-302c-11e3-91d2-dd5c4c401983",
				"Name": "wwwas",
				"AvatarId": "b0989210-302c-11e3-91d2-dd5c4c401983",
				"Type": "Team"
			},
			{
				"Id": "9fa84960-302b-11e3-91d2-dd5c4c401983",
				"Name": "wwwwqw",
				"AvatarId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
				"Type": "Team"
			},
			{
				"Id": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "Gary Wei",
				"AvatarId": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"Type": "Member"
			},
			{
				"Id": "c15985d0-aea6-11e2-b79d-512ef31a350a",
				"Name": "Hunter Lane",
				"AvatarId": "c139a1c0-aea6-11e2-b79d-512ef31a350a",
				"Type": "Member"
			},
			{
				"Id": "c159fb00-aea6-11e2-b79d-512ef31a350a",
				"Name": "Matthew Bryant",
				"AvatarId": "c13a6510-aea6-11e2-b79d-512ef31a350a",
				"Type": "Member"
			},
			{
				"Id": "c15b0c70-aea6-11e2-b79d-512ef31a350a",
				"Name": "Miriam Diversiev",
				"AvatarId": "c13cfd20-aea6-11e2-b79d-512ef31a350a",
				"Type": "Member"
			},
			{
				"Id": "c15ba8b0-aea6-11e2-b79d-512ef31a350a",
				"Name": "Cezary Wojtkowski",
				"AvatarId": "c13f2000-aea6-11e2-b79d-512ef31a350a",
				"Type": "Member"
			},
			{
				"Id": "d0d22e20-c2e9-11e2-a633-35224a3a67f7",
				"Name": "Gary Wei",
				"AvatarId": "b1283100-b911-11e2-9ce1-b17fe9feb8ae",
				"Type": "Member"
			},
			{
				"Id": "d2ddecf0-a119-11e2-b177-7d64c8315189",
				"Name": "Vip Sandhir",
				"AvatarId": "d2c311f0-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2de3b10-a119-11e2-b177-7d64c8315189",
				"Name": "Philip Plekhanov",
				"AvatarId": "d2c38720-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2de3b11-a119-11e2-b177-7d64c8315189",
				"Name": "Liliana Zektser",
				"AvatarId": "d2c44a70-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2de8930-a119-11e2-b177-7d64c8315189",
				"Name": "Amie Chen",
				"AvatarId": "d2c4e6b0-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2de8931-a119-11e2-b177-7d64c8315189",
				"Name": "Shihoko Ui",
				"AvatarId": "d2c534d0-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2defe60-a119-11e2-b177-7d64c8315189",
				"Name": "Katrina Manoshin",
				"AvatarId": "d2bf1a50-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2df2570-a119-11e2-b177-7d64c8315189",
				"Name": "Erin Guenther",
				"AvatarId": "d2bf8f80-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2e08500-a119-11e2-b177-7d64c8315189",
				"Name": "Demetri Maltsiniotis",
				"AvatarId": "d2c052d0-a119-11e2-b177-7d64c8315189",
				"Type": "Member"
			},
			{
				"Id": "d2e0d321-a119-11e2-b177-7d64c8315189",
				"Name": "Marcie Carlos",
				"AvatarId": "d2c24ea0-a119-11e2-b177-7d64c8315189",
				"Type": "Member",
				"numMembers": 1
			}
		];
	}
    function getUserMeta() {
        return [
            {
                "AvatarId": "3cf4d640-9cd2-11e2-a3a4-25024474fe63",
                "Id": "23318070-9cd5-11e2-a3a4-25024474fe63",
                "Name": "Gary Wei",
                "Selected": false,
                "Type": "Member"

            },
            {
                "AvatarId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63",
                "Id": "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "Name": "Cu Barnes",
                "Selected": false,
                "Type": "Member"
            },
            {
                "AvatarId": "3cf858b0-9cd2-11e2-a3a4-25024474fe63",
                "Id": "2331f5a1-9cd5-11e2-a3a4-25024474fe63",
                "Name": "Marcie Carlos",
                "Selected": false,
                "Type": "Member"
            }
        ]
    }
    function getDepartmentMeta() {
        return [
            {
                "AvatarId": "d72bd150-8ce5-11e4-8bdd-57e59346de68",
                "Id": "d72bd150-8ce5-11e4-8bdd-57e59346de68",
                "Name": "Marketing",
                "Selected": false,
                "Type": "Department"
            },
            {
                "AvatarId": "c91bf6d0-8ce5-11e4-8bdd-57e59346de68",
                "Id": "c91bf6d0-8ce5-11e4-8bdd-57e59346de68",
                "Name": "Sales",
                "Selected": false,
                "Type": "Department"
            }
        ]
    }
	return {
		getRecipients: getRecipients,
        getUserMeta: getUserMeta,
        getDepartmentMeta: getDepartmentMeta
	}
});
