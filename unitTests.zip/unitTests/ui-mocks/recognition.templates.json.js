define(function(){
	function getTemplates() {
		return [
			{
				"_id": "516419ccc35eb3cede000071",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1365514685584,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1365514685584,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "be0b7620-a11a-11e2-b177-7d64c8315189",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "1 Million",
				"Tags": "1 Million",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 1,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"RestrictUsers": {},
				"Description": "1 Million",
				"DepartmentName": "",
				"Title": "1 Million",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "51641b9ac35eb3cede000072",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1365515145575,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1365515145575,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "d1701a30-a11b-11e2-b177-7d64c8315189",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "1 million",
				"Tags": "1 million",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 1,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "1 million",
				"DepartmentName": "",
				"Title": "1 million",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "516818699aea300000000014",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1365776459846,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1365776459846,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "44a0fe90-a37c-11e2-84e1-ff1c846166f8",
				"IsPublic": true,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "public",
				"RestrictUsers": {
					"MemberIds" : ["2331f5a1-9cd5-11e2-a3a4-25024474fe63"],
					"TeamIds": ["29722060-6657-11e3-a6ba-816f8a7dcb5c"],
					"Roles": ["Manager"]
				},
				"Tags": "public",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": -1,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "2m",
				"DepartmentName": "",
				"Title": "2m",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "516c69d09a20810000000018",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1366059454652,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1366059454652,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "237b2750-a60f-11e2-bd86-5f24472861d7",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "5 Million!",
				"Tags": "5 Million!",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": -1,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "5 Million!",
				"DepartmentName": "",
				"Title": "5 Million!",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "5176f238fe2c4f9d3f00001a",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1366749717747,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1366749717747,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "527bdbb0-ac56-11e2-9766-a967f5796cbe",
				"IsPublic": true,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "abacus",
				"Tags": "abacus",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": -1,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "abacus",
				"DepartmentName": "",
				"Title": "abacus",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "51782468bee08b0000000014",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1366828053018,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1366828053018,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "d31d6cf0-ad0c-11e2-806f-456dc21a79d2",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "Test",
				"Tags": "Test",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": -1,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Test",
				"DepartmentName": "",
				"Title": "Test 10",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "517824a7bee08b0000000015",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1366828188020,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1366828188020,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "f8afcda0-ad0c-11e2-806f-456dc21a79d2",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "123",
				"Tags": "123",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": -1,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "123",
				"DepartmentName": "",
				"Title": "10",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "5179635c6fda465b95000014",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1366909766704,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1366909766704,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "ef275eb0-adca-11e2-b839-f369d0b7ba06",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "experience",
				"Tags": "experience",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": -1,
				"ExperienceValue": 10,
				"CreditValue": 0,
				"Description": "experience",
				"DepartmentName": "",
				"Title": "experience 10",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "517bfab07ef1be37b6000014",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1367079442038,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1367079442038,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "4f6c6bd0-af56-11e2-967e-6ffdd13b3856",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "test",
				"Tags": "test",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": -1,
				"ExperienceValue": 100,
				"CreditValue": 15,
				"Description": "test",
				"DepartmentName": "",
				"Title": "Credit test",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"_id": "51a4f1581a48950000000017",
				"ApproverMemberSummary": "",
				"__v": 0,
				"ModifiedDate": 1369764112595,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1369764112595,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "d8329ca0-c7c0-11e2-874d-fb8f8ddd0ce6",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "Everyone",
				"Tags": "Everyone",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Everyone",
				"DepartmentName": "",
				"Title": "Everyone",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"ApproverMemberSummary": "",
				"__v": 0,
				"_id": "51ae671394e4feb359000023",
				"ModifiedDate": 1370384115579,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1370384115579,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "4e9cf8b0-cd64-11e2-8d00-cf00ed9f9078",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "Individual",
				"Type": "Recognition",
				"Category": "Happy Birthday!",
				"Tags": "Happy Birthday!",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Happy Birthday!",
				"DepartmentName": "",
				"Title": "Happy Birthday!",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"ApproverMemberSummary": "",
				"__v": 0,
				"_id": "51ae675d94e4feb359000024",
				"ModifiedDate": 1370384115579,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1370384115579,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "7ac57200-cd64-11e2-8d00-cf00ed9f9078",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "Individual",
				"Type": "Recognition",
				"Category": "Happy Anniversary!",
				"Tags": "Happy Anniversary!",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Happy Anniversary!",
				"DepartmentName": "",
				"Title": "Happy Anniversary!",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"ApproverMemberSummary": "",
				"__v": 0,
				"_id": "51b74c4524d2c1744100001c",
				"ModifiedDate": 1370967006291,
				"ModifiedBy": "d2c311f0-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1370967006291,
				"CreatedBy": "d2c311f0-a119-11e2-b177-7d64c8315189",
				"hgId": "9f664420-d2b1-11e2-abde-65c08851db36",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "stuff",
				"Tags": "stuff",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "stuff",
				"DepartmentName": "",
				"Title": "stuff",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"ApproverMemberSummary": "",
				"__v": 0,
				"_id": "51defe2b62136f645400001c",
				"ModifiedDate": 1373568526428,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1373568526428,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "95f73aa0-ea5a-11e2-afbe-8746cddce64a",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "d6a46ed0-d914-11e2-b815-35b9b8d4d164",
				"AccessLevel": "Individual",
				"Type": "Recognition",
				"Category": "weewew",
				"Tags": "weewew",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "weewew",
				"DepartmentName": "",
				"Title": "wewe",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"ApproverMemberSummary": "",
				"__v": 0,
				"_id": "51df05fc62136f645400001d",
				"ModifiedDate": 1373568526428,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1373568526428,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "3e5fe1c0-ea5f-11e2-afbe-8746cddce64a",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "ae3c0ac0-d914-11e2-b815-35b9b8d4d164",
				"AccessLevel": "Individual",
				"Type": "Recognition",
				"Category": "test qwqwwqqw",
				"Tags": "test qwqwwqqw",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "test qwqwwqqw",
				"DepartmentName": "",
				"Title": "test 2112122121",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"ApproverMemberSummary": "",
				"__v": 0,
				"_id": "5244637fe10d1f6524000033",
				"ModifiedDate": 1380213593727,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1380213593727,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "5b6a9dd0-26ca-11e3-895a-4b3c71e041ac",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "Everyday",
				"Tags": "Everyday",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Everyday",
				"DepartmentName": "",
				"Title": "very long one masnmnsmssasas",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"ApproverMemberSummary": "",
				"__v": 0,
				"_id": "524463b9e10d1f6524000034",
				"ModifiedDate": 1380213593727,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1380213593727,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "7e4b9a20-26ca-11e3-895a-4b3c71e041ac",
				"IsPublic": false,
				"DefaultGivenToNewMembers": false,
				"ApproverMemberId": -1,
				"ApprovalLevel": "",
				"TeamId": "",
				"AccessLevel": "WithinGroup",
				"Type": "Recognition",
				"Category": "Everyday",
				"Tags": "Everyday",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Everyday",
				"DepartmentName": "",
				"Title": "qwwqwq232323hghg23hgh23gh2g3 hghagshasgahsg  21232hghg  23ghghghg  hghghg hghghg23 hghghg",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			}
		];
	}

	function getEveryday () {
		return [
			{
				"IsPublic": false,
				"hgId": "a96e6030-3da8-11e3-8e3f-3b48bfc048fd",
				"Levels": [],
				"SubValues": [],
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Everyday",
				"Publicity" : "Private",
				"Title": "Test 1",
				"ForegroundFilename": "pig",
				"BackgroundFilename": "goldborder",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"IsPublic": false,
				"hgId": "addb7e50-3da8-11e3-8e3f-3b48bfc048fd",
				"Levels": [],
				"SubValues": [],
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Everyday",
				"Publicity" : "Private",
				"Title": "Test 2",
				"ForegroundFilename": "beehive",
				"BackgroundFilename": "thin",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			}
		];
	}
	function getValue() {

		return {
			"Templates": [
			{
				"Publicity": "Private",
				"hgId": "ba2b5950-3da8-11e3-8e3f-3b48bfc048fd",
				"SubValues": [
					{
						ImageId : '5107ders-fbab-11e2-bad3-999e6df490a1',
						Name : 'Twenty Years A'
					},
					{
						ImageId : '4f0awedw-a1ee-11e2-b9ee-293826524e46',
						Name : 'Twenty Years B'
					},
					{
						ImageId : '5107ders-fetb-11e2-bad3-999e6df490a1',
						Name : 'Twenty Years A'
					},
					{
						ImageId : '4f0awedw-a1w2-11e2-b9ee-293826524e46',
						Name : 'Twenty Years B'
					},
					{
						ImageId : '5107rtrs-fetb-11e2-bad3-999e6df490a1',
						Name : 'Twenty Years A'
					},
					{
						ImageId : '4f0axfdw-a1w2-11e2-b9ee-293826524e46',
						Name : 'Twenty Years B'
					},
					{
						ImageId : '5107r2cs-fetb-11e2-bad3-999e6df490a1',
						Name : 'Twenty Years A'
					},
					{
						ImageId : '4f0axkuw-a1w2-11e2-b9ee-293826524e46',
						Name : 'Twenty Years B'
					},
					{
						ImageId : '5107232s-fetb-11e2-bad3-999e6df490a1',
						Name : 'Twenty Years A'
					},
					{
						ImageId : '4f0jdkdw-a1w2-11e2-b9ee-293826524e46',
						Name : 'Twenty Years B'
					}
				],
				"Type": "Recognition",
				"Category": "Values",
				"Tags": "Values",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Values",
				"Title": "Test 3 Value",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
			},
			{
				"Publicity": "Private",
				"hgId": "c4c5bc20-3da8-11e3-8e3f-3b48bfc048fd",
				"SubValues": [
					{
						ImageId : '5107a0d0-fbab-11e2-bad3-999e6df490a1',
						Name : 'Twenty Years A'
					},
					{
						ImageId : '4f0a7530-a1ee-11e2-b9ee-293826524e46',
						Name : 'Twenty Years B'
					}
				],
				"Type": "Recognition",
				"Category": "Values",
				"Tags": "Values",
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Values",
				"Title": "Test 3 Value",
				"BackgroundBadgeId": "123",
				"BadgeId": "456"
				},
				{
					"Publicity": "Private",
					"hgId": "c4c5bc2w-3da8-11e3-8e3f-3b48bfc048fd",
					"SubValues": [
						{
							ImageId : '5107afd0-fbab-11e2-bad3-999e6df490a1',
							Name : 'Twenty Years A'
						},
						{
							ImageId : '4f0a75e0-a1ee-11e2-b9ee-293826524e46',
							Name : 'Twenty Years B'
						}
					],
					"Type": "Recognition",
					"Category": "Values",
					"Tags": "Values",
					"FriendlyGroupId": 500,
					"ExperienceValue": 0,
					"CreditValue": 0,
					"Description": "Values",
					"Title": "Test 3 Value",
					"BackgroundBadgeId": "123",
					"BadgeId": "456"
				},
				{
					"Publicity": "Private",
					"hgId": "c4c5bcf0-3da8-11e3-8e3f-3b48bfc048fd",
					"SubValues": [
						{
							ImageId : '510ra0d0-fbab-11e2-bad3-999e6df490a1',
							Name : 'Twenty Years A'
						},
						{
							ImageId : '4r0a7530-a1ee-11e2-b9ee-293826524e46',
							Name : 'Twenty Years B'
						}
					],
					"Type": "Recognition",
					"Category": "Values",
					"Tags": "Values",
					"FriendlyGroupId": 500,
					"ExperienceValue": 0,
					"CreditValue": 0,
					"Description": "Values",
					"Title": "Test 3 Value",
					"BackgroundBadgeId": "123",
					"BadgeId": "456"
				},
				{
					"Publicity": "Private",
					"hgId": "c4c5wc20-3da8-11e3-8e3f-3b48bfc048fd",
					"SubValues": [
						{
							ImageId : '5107ard0-fbab-11e2-bad3-999e6df490a1',
							Name : 'Twenty Years A'
						},
						{
							ImageId : '4fea7530-a1ee-11e2-b9ee-293826524e46',
							Name : 'Twenty Years B'
						}
					],
					"Type": "Recognition",
					"Category": "Values",
					"Tags": "Values",
					"FriendlyGroupId": 500,
					"ExperienceValue": 0,
					"CreditValue": 0,
					"Description": "Values",
					"Title": "Test 3 Value",
					"BackgroundBadgeId": "123",
					"BadgeId": "456"
				},
				{
					"Publicity": "Private",
					"hgId": "c4c5fbe20-3da8-11e3-8e3f-3b48bfc048fd",
					"SubValues": [
						{
							ImageId : '5107wrd0-fbab-11e2-bad3-999e6df490a1',
							Name : 'Twenty Years A'
						},
						{
							ImageId : '4fwe7530-a1ee-11e2-b9ee-293826524e46',
							Name : 'Twenty Years B'
						}
					],
					"Type": "Recognition",
					"Category": "Values",
					"Tags": "Values",
					"FriendlyGroupId": 500,
					"ExperienceValue": 0,
					"CreditValue": 0,
					"Description": "Values",
					"Title": "Test 3 Value",
					"BackgroundBadgeId": "123",
					"BadgeId": "456"
				},
				{
					"Publicity": "Private",
					"hgId": "c4c5wc20-3da8-11e3-8e3f-3b48bfc048fd",
					"SubValues": [
						{
							ImageId : '51r7a0d0-fbab-11e2-bad3-999e6df490a1',
							Name : 'Twenty Years A'
						},
						{
							ImageId : '4f0awe30-a1ee-11e2-b9ee-293826524e46',
							Name : 'Twenty Years B'
						}
					],
					"Type": "Recognition",
					"Category": "Values",
					"Tags": "Values",
					"FriendlyGroupId": 500,
					"ExperienceValue": 0,
					"CreditValue": 0,
					"Description": "Values",
					"Title": "Test 4 Value",
					"BackgroundBadgeId": "123",
					"BadgeId": "456"
				},
				{
					"Publicity": "Private",
					"__v": 0,
					"_id": "526ac1916a81d80000000032",
					"ModifiedDate": 1382728024542,
					"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"CreatedDate": 1382728024542,
					"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
					"hgId": "c4c5bc20-3da8-11e3-8e3f-3b48bfc048fd",
					"AchievementLevelEnabled": false,
					"SubValues": [
						{
							ImageId : '5107a0d0-fbab-11e2-bad3-999e6df490a1',
							Name : 'Twenty Years A'
						},
						{
							ImageId : '4f0a7530-a1ee-11e2-b9ee-293826524e46',
							Name : 'Twenty Years B'
						}
					],
					"Type": "Recognition",
					"Category": "Values",
					"Tags": "Values",
					"FriendlyGroupId": 500,
					"ExperienceValue": 0,
					"CreditValue": 0,
					"Description": "Values",
					"Title": "Test 3 Value",
					"BackgroundBadgeId": "123",
					"BadgeId": "456"
				},
				{
					"Publicity": "Private",
					"hgId": "c4c5brt0-3da8-11e3-8e3f-3b48bfc048fd",
					"SubValues": [],
					// [
					// 	{
					// 		ImageId : '5wc7a0d0-fbab-11e2-bad3-999e6df490a1',
					// 		Name : 'Twenty Years A'
					// 	},
					// 	{
					// 		ImageId : '4f0nh530-a1ee-11e2-b9ee-293826524e46',
					// 		Name : 'Twenty Years B'
					// 	}
					// ],
					"Type": "Recognition",
					"Category": "Values",
					"Tags": "Values",
					"FriendlyGroupId": 500,
					"ExperienceValue": 0,
					"CreditValue": 0,
					"Description": "Values",
					"Title": "Test 5 Value",
					"BackgroundBadgeId": "123",
					"BadgeId": "456"

				}
		],
			"Levels": [
			{
				"Name": "Silver",
				"PointValue": 50,
				"CreditValue": 0,
				"RemainingToMe": 2
			},
			{
				"Name": "Gold",
				"PointValue": 150,
				"CreditValue": 0,
				"RemainingToMe": 2
			},
			{
				"Name": "Platinum",
				"PointValue": 500,
				"CreditValue": 0,
				"RemainingToMe": 2
			}
		],
		FriendlyGroupId: 500
		}
	}
	function getAchievement() {
		return [
			{
				"hgId": "d0310380-3da8-11e3-8e3f-3b48bfc048fd",
				"Publicity": "Private",
				"Levels": [{
						"Name": "Silver",
						"PointValue": 50,
						"CreditValue": 0,
						"RemainingToMe": 2
					},
					{
						"Name": "Gold",
						"PointValue": 150,
						"CreditValue": 0,
						"RemainingToMe": 2
					},
					{
						"Name": "Platinum",
						"PointValue": 500,
						"CreditValue": 0,
						"RemainingToMe": 2
					}],
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Achievement",
				"DepartmentName": "",
				"Title": "Test 4 Achivement",
				"BackgroundBadgeId": "123",
				"BadgeId": "456",
                "RestrictUsers": {
                    "MemberIds" : ["2331f5a1-9cd5-11e2-a3a4-25024474fe63"],
                    "TeamIds": ["29722060-6657-11e3-a6ba-816f8a7dcb5c"],
					"Roles": ["Manager"]
                },
                "RestrictDepartments": [{
					"AvatarId": "d72bd150-8ce5-11e4-8bdd-57e59346de68",
					"Id": "d72bd150-8ce5-11e4-8bdd-57e59346de68",
					"Name": "Marketing",
					"Selected": false,
					"Type": "Department"
				}]
			},
			{
				"hgId": "d9fe5250-3da8-11e3-8e3f-3b48bfc048fd",
				"Publicity": "Private",
				"Levels": [{
						"Name": "Silver",
						"PointValue": 50,
						"CreditValue": 0,
						"RemainingToMe": 2
					},
					{
						"Name": "Gold",
						"PointValue": 150,
						"CreditValue": 0,
						"RemainingToMe": 2
					},
					{
						"Name": "Platinum",
						"PointValue": 500,
						"CreditValue": 0,
						"RemainingToMe": 2
					}],
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Achievement",
				"DepartmentName": "",
				"Title": "Test 6 Achivement",
				"BackgroundBadgeId": "123",
				"BadgeId": "456",
				"RestrictDepartments":[],
                "RestrictUsers": {
                    "MemberIds": [],
                    "TeamIds": [],
					"Roles": ["Manager"]
                }
			},
			{
				"hgId": "c3da7bf0-4241-11e3-8ccb-9fe43c10c1be",
				"Publicity": "Private",
				"Levels": [],
				"FriendlyGroupId": 500,
				"ExperienceValue": 0,
				"CreditValue": 0,
				"Description": "Achievement",
				"DepartmentName": "",
				"Title": "test",
				"BackgroundBadgeId": "123",
				"BadgeId": "456",
				"RestrictUsers": {
					"MemberIds": ["2331f5a1-9cd5-11e2-a3a4-25024474fe63"],
					"TeamIds": ["29722060-6657-11e3-a6ba-816f8a7dcb5c"],
					"Roles": ["Manager"]
				},
				"RestrictDepartments": []
			}
		];
	}
	function getLevels() {
		return [
			{
				"Name": "Silver",
				"PointValue": 50,
				"CreditValue": 0,
				"RemainingToMe": 2
			},
			{
				"Name": "Gold",
				"PointValue": 150,
				"CreditValue": 0,
				"RemainingToMe": 2
			},
			{
				"Name": "Platinum",
				"PointValue": 500,
				"CreditValue": 0,
				"RemainingToMe": 2
			}
		];
	}
	function getLevelAvailabilities() {
		return ["Silver", "Gold", "Platinum"];
	}
	function getSystem() {
		return [
			{
				"hgId":"eb367f20-2983-11e5-ad8a-65cef6744bfc",
				"Title":"service award 2",
				"Message": "123",
				"Description":"",
				"Levels":[],
				"Category":"System",
				"FriendlyGroupId":1,
				"PointValue":2,
				"CreditValue":0,
				"SubValues":[],
				"ForegroundFilename":"IconATV.svg",
				"BackgroundFilename":"BorderCardSpade.svg",
				"BadgeId":"7793d0e0-883f-11e3-8aee-2f0e4f4dbcac",
				"BackgroundBadgeId":"c84798f0-8d12-11e3-8e02-b9ba59330e1a",
				"DepartmentName":"",
				"RestrictUsers":
					{
						"TeamIds":[],
						"MemberIds":[],
						"Roles":[]
					},
				"RestrictDepartments":[],
				"YearsNumber":2
			},
			{
				"hgId":"09450bd0-2984-11e5-ad8a-65cef6744bfc",
				"Title":"service award 3",
				"Message": "123",
				"Description":"",
				"Levels":[],
				"Category":"System",
				"FriendlyGroupId":1,
				"PointValue":3,
				"CreditValue":0,
				"SubValues":[],
				"ForegroundFilename":"IconBankingBuster.svg",
				"BackgroundFilename":"BorderSolidBlue.svg",
				"BadgeId":"779668f1-883f-11e3-8aee-2f0e4f4dbcac",
				"BackgroundBadgeId":"c848f881-8d12-11e3-8e02-b9ba59330e1a",
				"DepartmentName":"",
				"RestrictUsers":
					{
						"TeamIds":[],
						"MemberIds":[],
						"Roles":[]
					},
				"RestrictDepartments":[],
				"YearsNumber":3
			}
		];
	}
	return {
		getTemplates: getTemplates,
		getEveryday: getEveryday,
		getValue: getValue,
		getAchievement: getAchievement,
		getLevels: getLevels,
		getLevelAvailabilities: getLevelAvailabilities,
		getSystem: getSystem
	}
});