define(function(){

	function getTeamsIOwn(){
		return [
			{
				"__v": 0,
				"_id": "52542208d1592b00000005f3",
				"ModifiedDate": 1381245448556,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381245448556,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "52542208d1592b00000005f2",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Demetri Maltsiniotis",
						"MemberId": "d2e08500-a119-11e2-b177-7d64c8315189"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "ww"
			},
			{
				"__v": 0,
				"_id": "525421f1d1592b00000005ef",
				"ModifiedDate": 1381245425073,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381245425073,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "b0989210-302c-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "525421f1d1592b00000005ee",
						"TeamId": "b0989210-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Cezary Wojtkowski",
						"MemberId": "c15ba8b0-aea6-11e2-b79d-512ef31a350a"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "Development",
				"Type": "Department"
			},
			{
				"__v": 0,
				"_id": "52542027d1592b00000005e7",
				"ModifiedDate": 1381358996797,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381244967157,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "52542027d1592b00000005e6",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Gary Wei",
						"MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "wwwwqw"
			}
		];
	}
	function getAvailableChildTeams(){
		return [
			{
				"_id": "51ad0a9d868dce726e000018",
				"__v": 4,
				"ModifiedDate": 1370294941984,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1370294941984,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
				"TeamMembers": [
					{
						"_id": "51ad0a9d868dce726e000016",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Philip Plekhanov",
						"MemberId": "d2de3b10-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "51ad0a9d868dce726e000017",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Gary Wei",
				"OwnerId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
				"IsPublic": true,
				"Description": "Gary Test Team Description",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "Gary Test Team 8"
			},
			{
				"__v": 0,
				"_id": "52542027d1592b00000005e7",
				"ModifiedDate": 1381358996797,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381244967157,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "52542027d1592b00000005e6",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Gary Wei",
						"MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "wwwwqw"
			},
			{
				"__v": 0,
				"_id": "525421f1d1592b00000005ef",
				"ModifiedDate": 1381245425073,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381245425073,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "b0989210-302c-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "525421f1d1592b00000005ee",
						"TeamId": "b0989210-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Cezary Wojtkowski",
						"MemberId": "c15ba8b0-aea6-11e2-b79d-512ef31a350a"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "wwwas"
			},
			{
				"__v": 0,
				"_id": "52542208d1592b00000005f3",
				"ModifiedDate": 1381245448556,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381245448556,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "52542208d1592b00000005f2",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Demetri Maltsiniotis",
						"MemberId": "d2e08500-a119-11e2-b177-7d64c8315189"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "ww"
			}
		];
	}
	function getTeamById() {
		return {
			"__v": 0,
			"_id": "52542027d1592b00000005e7",
			"ModifiedDate": 1381358996797,
			"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
			"CreatedDate": 1381244967157,
			"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
			"hgId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
			"TeamMembers": [
				{
					"_id": "52542027d1592b00000005e6",
					"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
					"MemberFullName": "Gary Wei",
					"MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
				}
			],
			"ChildTeams": [],
			"Status": "",
			"OwnerFullName": "Cu Barnes",
			"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
			"IsPublic": true,
			"Description": "",
			"GroupName": "Mercury",
			"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
			"Name": "wwwwqw"
		};
	}
	function getPublic() {
		return [
			{
				"_id": "51ad0a9d868dce726e000018",
				"__v": 14,
				"ModifiedDate": 1370294941984,
				"ModifiedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"CreatedDate": 1370294941984,
				"CreatedBy": "3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864",
				"hgId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
				"TeamMembers": [
					{
						"_id": "51ad0a9d868dce726e000016",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Philip Plekhanov",
						"MemberId": "d2de3b10-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "51ad0a9d868dce726e000017",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Gary Wei",
				"OwnerId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864",
				"IsPublic": true,
				"Description": "Gary Test Team Description",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "Gary Test Team 8"
			},
			{
				"__v": 226,
				"_id": "52542208d1592b00000005f3",
				"ModifiedDate": 1382463698486,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381245448556,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "525d86fb1dfc4c0000000518",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Erin Guenther",
						"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a0000000030",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Demetri Maltsiniotis",
						"MemberId": "d2e08500-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a0000000034",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a0000000035",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Shihoko Ui",
						"MemberId": "d2de8931-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a0000000036",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Miriam Diversiev",
						"MemberId": "c15b0c70-aea6-11e2-b79d-512ef31a350a"
					},
					{
						"_id": "5266b8cc76b00a0000000037",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Katrina Manoshin",
						"MemberId": "d2defe60-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a0000000038",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Gary Wei",
						"MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
					},
					{
						"_id": "5266b8cc76b00a0000000039",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Marcie Carlos",
						"MemberId": "d2e0d321-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a000000003a",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Marcie Carlos",
						"MemberId": "d2e0d321-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a000000003b",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Vip Sandhir",
						"MemberId": "d2ddecf0-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a000000003c",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Gary Wei",
						"MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
					},
					{
						"_id": "5266b8cc76b00a000000003d",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Erin Guenther",
						"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a000000003e",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a000000003f",
						"TeamId": "b0989210-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Cezary Wojtkowski",
						"MemberId": "c15ba8b0-aea6-11e2-b79d-512ef31a350a"
					},
					{
						"_id": "5266b8cc76b00a0000000040",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Philip Plekhanov",
						"MemberId": "d2de3b10-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8cc76b00a0000000041",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					}
				],
				"ChildTeams": [
					{
						"_id": "5266b8cc76b00a000000002a",
						"TeamName": "wwwwqw",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983"
					}
				],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "ww"
			},
			{
				"__v": 10,
				"_id": "525421f1d1592b00000005ef",
				"ModifiedDate": 1381245425073,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381245425073,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "b0989210-302c-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "525421f1d1592b00000005ee",
						"TeamId": "b0989210-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Cezary Wojtkowski",
						"MemberId": "c15ba8b0-aea6-11e2-b79d-512ef31a350a"
					}
				],
				"ChildTeams": [],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "wwwas"
			},
			{
				"__v": 138,
				"_id": "52542027d1592b00000005e7",
				"ModifiedDate": 1381754940334,
				"ModifiedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"CreatedDate": 1381244967157,
				"CreatedBy": "d2c0ef10-a119-11e2-b177-7d64c8315189",
				"hgId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
				"TeamMembers": [
					{
						"_id": "525acbc8c139960d9b00032f",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Marcie Carlos",
						"MemberId": "d2e0d321-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "525accaac139960d9b000334",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Vip Sandhir",
						"MemberId": "d2ddecf0-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "525b2a0cc139960d9b00034e",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Gary Wei",
						"MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
					},
					{
						"_id": "525b2a0ec139960d9b000354",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Erin Guenther",
						"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "525b2a0fc139960d9b00035b",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a0000000042",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Demetri Maltsiniotis",
						"MemberId": "d2e08500-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a0000000043",
						"TeamId": "b0989210-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Cezary Wojtkowski",
						"MemberId": "c15ba8b0-aea6-11e2-b79d-512ef31a350a"
					},
					{
						"_id": "5266b8d276b00a0000000044",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Philip Plekhanov",
						"MemberId": "d2de3b10-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a0000000045",
						"TeamId": "9c0cd910-cc94-11e2-863c-278252e8a19f",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a0000000046",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Erin Guenther",
						"MemberId": "d2df2570-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a0000000047",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Liliana Zektser",
						"MemberId": "d2de3b11-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a0000000048",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Shihoko Ui",
						"MemberId": "d2de8931-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a0000000049",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Miriam Diversiev",
						"MemberId": "c15b0c70-aea6-11e2-b79d-512ef31a350a"
					},
					{
						"_id": "5266b8d276b00a000000004a",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Katrina Manoshin",
						"MemberId": "d2defe60-a119-11e2-b177-7d64c8315189"
					},
					{
						"_id": "5266b8d276b00a000000004b",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Gary Wei",
						"MemberId": "3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864"
					},
					{
						"_id": "5266b8d276b00a000000004c",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983",
						"MemberFullName": "Marcie Carlos",
						"MemberId": "d2e0d321-a119-11e2-b177-7d64c8315189"
					}
				],
				"ChildTeams": [
					{
						"_id": "525b2a16c139960d9b000363",
						"TeamName": "wwwwqw",
						"TeamId": "9fa84960-302b-11e3-91d2-dd5c4c401983"
					},
					{
						"_id": "525b2a18c139960d9b000369",
						"TeamName": "ww",
						"TeamId": "be97cac0-302c-11e3-91d2-dd5c4c401983"
					},
					{
						"_id": "525be786c139960d9b000370",
						"TeamName": "wwwas",
						"TeamId": "b0989210-302c-11e3-91d2-dd5c4c401983"
					}
				],
				"Status": "",
				"OwnerFullName": "Cu Barnes",
				"OwnerId": "d2e0d320-a119-11e2-b177-7d64c8315189",
				"IsPublic": true,
				"Description": "",
				"GroupName": "Mercury",
				"GroupId": "3f39c660-9c94-11e2-a2b3-67b5e3eaf864",
				"Name": "wwwwqw"
			}
		];
	}
	function getDepartments() {
		return [
			{
				"hgId": "ca872f20-c424-11e2-b067-df7f084210c8",
				"Name": "Gary Test Team",
                "Type" : "Department"
			},
			{
				"hgId": "2fe40080-cbca-11e2-9373-0765abcea76d",
				"Name": "Gary Test Team 5",
                "Type" : "Department"
			},
			{
				"hgId": "b8abcd00-cc90-11e2-a949-1f9bef60c441",
				"Name": "Gary Test Team 7",
                "Type" : "Department"
			}
		]
	}
    function getTeamsForFeeds() {
        return [
            {
                "Name": "ww",
                "hgId": "be97cac0-302c-11e3-91d2-dd5c4c401983"
            },
            {
                "Name": "wwwas",
                "hgId": "b0989210-302c-11e3-91d2-dd5c4c401983"
            },
            {
                "Name": "wwwwqw",
                "hgId": "9fa84960-302b-11e3-91d2-dd5c4c401983"
            }
        ];
    }
	return {
		getTeamsIOwn: getTeamsIOwn,
		getAvailableChildTeams: getAvailableChildTeams,
		getTeamById: getTeamById,
		getPublic: getPublic,
		getDepartments: getDepartments,
        getTeamsForFeeds: getTeamsForFeeds
	};
});