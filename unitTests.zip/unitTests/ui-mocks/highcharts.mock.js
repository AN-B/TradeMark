window.Highcharts = {
    Chart : function () {
        return {test: 'test'};
    }
};