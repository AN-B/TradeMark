define(function(){
	function getSearchMeta(){
		return [{
            Id: '3f5c1b70-9c94-11e2-a2b3-67b5e3eaf864',
            Name: 'Gary Wei',
            AvatarId: '3f3cd3a0-9c94-11e2-a2b3-67b5e3eaf864',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'c15985d0-aea6-11e2-b79d-512ef31a350a',
            Name: 'Hunter Lane',
            AvatarId: 'c139a1c0-aea6-11e2-b79d-512ef31a350a',
            Type: 'Member',
            Selected: false,
            Department: 'Operations'
        }, {
            Id: 'c159fb00-aea6-11e2-b79d-512ef31a350a',
            Name: 'Matthew Bryant',
            AvatarId: 'c13a6510-aea6-11e2-b79d-512ef31a350a',
            Type: 'Member',
            Selected: false,
            Department: 'Operations'
        }, {
            Id: 'c15b0c70-aea6-11e2-b79d-512ef31a350a',
            Name: 'Miriam Diversiev',
            AvatarId: 'c13cfd20-aea6-11e2-b79d-512ef31a350a',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'c15ba8b0-aea6-11e2-b79d-512ef31a350a',
            Name: 'Cezary Wojtkowski',
            AvatarId: 'c13f2000-aea6-11e2-b79d-512ef31a350a',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'd0d22e20-c2e9-11e2-a633-35224a3a67f7',
            Name: 'Gary Wei',
            AvatarId: 'b1283100-b911-11e2-9ce1-b17fe9feb8ae',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'd2ddecf0-a119-11e2-b177-7d64c8315189',
            Name: 'Vip Sandhir',
            AvatarId: 'd2c311f0-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'Executive'
        }, {
            Id: 'd2de3b10-a119-11e2-b177-7d64c8315189',
            Name: 'Philip Plekhanov',
            AvatarId: 'd2c38720-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'd2de3b11-a119-11e2-b177-7d64c8315189',
            Name: 'Liliana Zektser',
            AvatarId: 'd2c44a70-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'QA'
        }, {
            Id: 'd2de8930-a119-11e2-b177-7d64c8315189',
            Name: 'Amie Chen',
            AvatarId: 'd2c4e6b0-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'd2de8931-a119-11e2-b177-7d64c8315189',
            Name: 'Shihoko Ui',
            AvatarId: 'd2c534d0-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'd2defe60-a119-11e2-b177-7d64c8315189',
            Name: 'Katrina Manoshin',
            AvatarId: 'd2bf1a50-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'd2df2570-a119-11e2-b177-7d64c8315189',
            Name: 'Erin Guenther',
            AvatarId: 'd2bf8f80-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'Operations'
        }, {
            Id: 'd2e08500-a119-11e2-b177-7d64c8315189',
            Name: 'Demetri Maltsiniotis',
            AvatarId: 'd2c052d0-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'Development'
        }, {
            Id: 'd2e0d321-a119-11e2-b177-7d64c8315189',
            Name: 'Marcie Carlos',
            AvatarId: 'd2c24ea0-a119-11e2-b177-7d64c8315189',
            Type: 'Member',
            Selected: false,
            Department: 'QA'
        }] ;
	}

	return {
        getSearchMeta: getSearchMeta
	};
});