define(function () {
    function getMyPolls () {
        return [
            {
                "ParticipantsCount":21,
                "OutstandingVotes":19,
                "PollId":"ce7bb2a1-7100-11e5-b54a-a17009f8745a",
                "PollQuestionId":"ba042280-7100-11e5-b54a-a17009f8745a",
                "Question":"Another Poll",
                "Description":"",
                "Status":"InProgress",
                "StartDate":1444668397507,
                // "EndDate":1444711620000,
                "AnswerResults":[
                    {
                        "Text":"Jupiter",
                        "Vote":1,
                        "_id":"561c2d589362d9000051075b"
                    },
                    {
                        "Text":"Saturn",
                        "Vote":1,
                        "_id":"561c2d589362d9000051075a"
                    }
                ],
                "AnswerOptions":[
                    {
                        "Text":"Jupiter",
                        "Value":0
                    },
                    {
                        "Text":"Saturn",
                        "Value":1
                    }
                ]
            }
        ];
    }
    return {
        getMyPolls: getMyPolls
    }
});
