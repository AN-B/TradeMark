define(function() {
    function getAll() {
        return [
            {
                "Address" : {
                    "Address1" : "600 W. Chicago Ave.",
                    "Address2" : "Suite 700",
                    "City" : "Chicago",
                    "State" : "IL",
                    "Zip" : "60654",
                    "Country" : "United States"
                },
                "Id" : "d555a600-b169-11e4-b70d-99915588ce04",
                "TeamMembers" : [],
                "Type" : "Location",
                "Status" : "Active",
                "IsPublic" : true,
                "GroupName" : "Mercury Industries",
                "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "Name" : "Chicago",
            },
            {
                "Address" : {
                    "Zip" : "11111",
                    "State" : "CA",
                    "City" : "Los Angeles",
                    "Address1" : "123 Main St.",
                    "Country" : "United States"
                },
                "LocationCode" : "HG-LA",
                "Id" : "231c1bb0-b167-11e4-9db4-71495aeb6a35",
                "TeamMembers" : [],
                "Type" : "Location",
                "Status" : "Active",
                "IsPublic" : true,
                "GroupName" : "Mercury Industries",
                "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "Name" : "Los Angeles"
            },
            {
                "Address" : {
                    "Zip" : "30290",
                    "State" : "FL",
                    "City" : "Miami",
                    "Address1" : "1000 Beach Blvd.",
                    "Country" : "United States"
                },
                "LocationCode" : "HG-PRTY",
                "Id" : "ee1a2970-b166-11e4-9db4-71495aeb6a35",
                "TeamMembers" : [],
                "Type" : "Location",
                "Status" : "Active",
                "IsPublic" : true,
                "GroupName" : "Mercury Industries",
                "GroupId" : "3cf21720-9cd2-11e2-a3a4-25024474fe63",
                "Name" : "Miami"
            }
        ]
    }
    return {
        getAll: getAll
    };
});