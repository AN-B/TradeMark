define(function () {
    function getCurrentSnapshot() {
        return {
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "GroupName": "Mercury Industries",
            "SpendTotal": 2172,
            "TransferTotal": 42712,
            "ItemCostTotal": 88000
        }
    }

    function getPointSpendGiveAndProduct() {
        return {
            ProductSpend:[4, 17, 7, 14, 18, 12, 3, 16, 10, 4, 4, 11],
            ProductGive:[],
            ProductItem:[10,100,300,500]
        }
    }

    function PointDistribution() {
        return [
            {
                Name: 'Employee',
                PointSpend: [],
                PointTransfer: [],
                PeopleNumber: 0
            },
            {
                Name: 'Manager',
                PointSpend: [],
                PointTransfer: [],
                PeopleNumber: 0
            },
            {
                Name: 'Executive',
                PointSpend: [],
                PointTransfer: [],
                PeopleNumber: 0
            },
        ]
    }

    function getMemberPointsInit() {
        return {"groupMembers": [
            {"MemberId": "311be6b0-d76f-11e2-bfde-692f778bcc11", "UserId": "31111140-d76f-11e2-bfde-692f778bcc11", "FullName": "Adam Lippman", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "23310b40-9cd5-11e2-a3a4-25024474fe63", "UserId": "3cf94310-9cd2-11e2-a3a4-25024474fe63", "FullName": "Amie Chen", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "a0132a00-5808-11e3-94c7-a7d327c74878", "UserId": "a00ce870-5808-11e3-94c7-a7d327c74878", "FullName": "Areena Jose", "Role": "Admin", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "88452ad0-50d4-11e3-864a-eba6380c47b6", "UserId": "883c2a20-50d4-11e3-864a-eba6380c47b6", "FullName": "Bobby Brady", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "cd3eafe0-8193-11e3-85fd-95865f9015f2", "UserId": "cd2163e0-8193-11e3-85fd-95865f9015f2", "FullName": "Brenda Walsh", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "986744a0-14a9-11e3-8340-83c7e7202af3", "UserId": "98077160-14a9-11e3-8340-83c7e7202af3", "FullName": "Brendan Farrell", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "2a74c710-ea47-11e2-b3b5-db0fb9a0b763", "UserId": "2a6c1480-ea47-11e2-b3b5-db0fb9a0b763", "FullName": "Cezary Wojtkowski", "Role": "Manager", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "d76696a0-e336-11e2-97f1-bd30c7a0e0f3", "UserId": "d7524b50-e336-11e2-97f1-bd30c7a0e0f3", "FullName": "Charlie Greubel", "Role": "Manager", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "2de4bbf0-a0c6-11e2-a665-cf2c2ef6e160", "UserId": "2d84e8b0-a0c6-11e2-a665-cf2c2ef6e160", "FullName": "Cosmo Kramer", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "1f0f5bb0-090a-11e3-975d-bda64f5fff03", "UserId": "1f091a20-090a-11e3-975d-bda64f5fff03", "FullName": "Courtney Privitera", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0}
        ], "totalCount": 10}
    }

    function getMemberPointsNextPage() {
        return {"groupMembers": [
            {"MemberId": "2331f5a0-9cd5-11e2-a3a4-25024474fe63", "UserId": "3cf80a90-9cd2-11e2-a3a4-25024474fe63", "FullName": "Cu Barnes", "Role": "HGAdmin", "PointSpend": 30, "PointTransfer": 502, "IssuePoints": 0},
            {"MemberId": "ede16340-c87b-11e2-aa05-198054fd4117", "UserId": "edcffe20-c87b-11e2-aa05-198054fd4117", "FullName": "David Puddy", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "2331a780-9cd5-11e2-a3a4-25024474fe63", "UserId": "3cf54b70-9cd2-11e2-a3a4-25024474fe63", "FullName": "Demetri Maltsiniotis", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "af8abe00-1a53-11e3-943e-8f3acebdde8a", "UserId": "af8280a0-1a53-11e3-943e-8f3acebdde8a", "FullName": "Devon Miles", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "4a766010-901d-11e3-884e-d5532dd2ec50", "UserId": "4a54ce50-901d-11e3-884e-d5532dd2ec50", "FullName": "Dnynesh K", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "d7d7f580-77b4-11e3-951d-87e893b9bd5e", "UserId": "d65a7d40-77b4-11e3-951d-87e893b9bd5e", "FullName": "Donna Martin", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "2de5a650-a0c6-11e2-a665-cf2c2ef6e160", "UserId": "2d8250a0-a0c6-11e2-a665-cf2c2ef6e160", "FullName": "Elaine Benes", "Role": "Admin", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "23315961-9cd5-11e2-a3a4-25024474fe63", "UserId": "3cf48820-9cd2-11e2-a3a4-25024474fe63", "FullName": "Erin Guenther", "Role": "Manager", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "8a51ba60-ee81-11e2-8706-c3b972347dee", "UserId": "8a418dc0-ee81-11e2-8706-c3b972347dee", "FullName": "Ganesh Kamble", "Role": "Employee", "PointSpend": 0, "PointTransfer": 0, "IssuePoints": 0},
            {"MemberId": "23318070-9cd5-11e2-a3a4-25024474fe63", "UserId": "3cf4d640-9cd2-11e2-a3a4-25024474fe63", "FullName": "Gary Wei", "Role": "HGAdmin", "PointSpend": 0, "PointTransfer": 100, "IssuePoints": 0}
        ], "totalCount": 10}
    }

    return {
        getCurrentSnapshot: getCurrentSnapshot,
        getMemberPointsInit: getMemberPointsInit,
        getMemberPointsNextPage: getMemberPointsNextPage,
        getPointSpendGiveAndProduct: getPointSpendGiveAndProduct,
        PointDistribution: PointDistribution
    }
});