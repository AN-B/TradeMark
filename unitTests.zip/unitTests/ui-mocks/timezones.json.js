define(function() {
    function getAll() {
        return [
            {"key":"America/New_York","value":"Eastern Time"},
            {"key":"America/Detroit","value":"Eastern Time - Michigan - most locations"},
            {"key":"America/Kentucky/Louisville","value":"Eastern Time - Kentucky - Louisville area"},
            {"key":"America/Kentucky/Monticello","value":"Eastern Time - Kentucky - Wayne County"},
            {"key":"America/Indiana/Indianapolis","value":"Eastern Time - Indiana - most locations"},
            {"key":"America/Indiana/Vincennes","value":"Eastern Time - Indiana - Daviess, Dubois, Knox & Martin Counties"},
            {"key":"America/Indiana/Winamac","value":"Eastern Time - Indiana - Pulaski County"},
            {"key":"America/Indiana/Marengo","value":"Eastern Time - Indiana - Crawford County"},
            {"key":"America/Indiana/Petersburg","value":"Eastern Time - Indiana - Pike County"},
            {"key":"America/Indiana/Vevay","value":"Eastern Time - Indiana - Switzerland County"},
            {"key":"America/Chicago","value":"Central Time"},
            {"key":"America/Indiana/Tell_City","value":"Central Time - Indiana - Perry County"},
            {"key":"America/Indiana/Knox","value":"Central Time - Indiana - Starke County"},
            {"key":"America/Menominee","value":"Central Time - Michigan - Dickinson, Gogebic, Iron & Menominee Counties"},
            {"key":"America/North_Dakota/Center","value":"Central Time - North Dakota - Oliver County"},
            {"key":"America/North_Dakota/New_Salem","value":"Central Time - North Dakota - Morton County (except Mandan area)"},
            {"key":"America/North_Dakota/Beulah","value":"Central Time - North Dakota - Mercer County"},
            {"key":"America/Denver","value":"Mountain Time"},
            {"key":"America/Boise","value":"Mountain Time - south Idaho & east Oregon"},
            {"key":"America/Phoenix","value":"Mountain Standard Time - Arizona (except Navajo)"},
            {"key":"America/Los_Angeles","value":"Pacific Time"},
            {"key":"America/Metlakatla","value":"Pacific Standard Time - Annette Island, Alaska"},
            {"key":"America/Anchorage","value":"Alaska Time"},
            {"key":"America/Juneau","value":"Alaska Time - Alaska panhandle"},
            {"key":"America/Sitka","value":"Alaska Time - southeast Alaska panhandle"},
            {"key":"America/Yakutat","value":"Alaska Time - Alaska panhandle neck"},
            {"key":"America/Nome","value":"Alaska Time - west Alaska"},
            {"key":"America/Adak","value":"Aleutian Islands"},
            {"key":"Pacific/Honolulu","value":"Hawaii time"}
        ];
    }
    return {
        getAll: getAll
    };
});