define(function() {
    function getRecipients() {
        return [
            {
                "fullName" : "Cu Barnes",
                "hgId" : "2331f5a0-9cd5-11e2-a3a4-25024474fe63",
                "userId" : "3cf80a90-9cd2-11e2-a3a4-25024474fe63"
            }
        ]
    }
    return {
        getRecipients: getRecipients
    };
});