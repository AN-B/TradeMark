define(function(){
    function getWishList() {
        return [{
            "hgId": "85c0afbe-563f-4092-8050-b93770b88e75",
            "MemberId": "f75b0252-a416-11e4-a111-57b4d90536cc",
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Rank": 0,
            "Type": "ProductItem",
            "Item": {
                "Id": "21f61c10-c403-11e3-a9c0-71c4281b4207",
                "Name": "Non Expiring Product Item"
            },
            "Status": "Active",
            "FulfillmentMemberId": ""
        },{
            "hgId": "0239bac5-d18d-4633-b59d-90258023c121",
            "MemberId": "f75b0252-a416-11e4-a111-57b4d90536cc",
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Rank": 1,
            "Type": "ProductItem",
            "Item": {
                "Id": "5f4dd850-c403-11e3-a9c0-71c4281b4207",
                "Name": "Non Expiring Product Item 2.0"
            },
            "Status": "Active",
            "FulfillmentMemberId": ""
        },{
            "hgId": "dda10a0c-0832-4e56-a359-82a961313e4c",
            "MemberId": "f75b0252-a416-11e4-a111-57b4d90536cc",
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Rank": 2,
            "Type": "ProductItem",
            "Item": {
                "Id": "5f4dd850-c403-11e3-a9c0-71c4281b4208",
                "Name": "Suggested product item"
            },
            "Status": "Active",
            "FulfillmentMemberId": ""
        }];
    }
    function getSingleWish() {
        return {
            "hgId": "10b834ac-431a-41ff-a5d0-da471f6c2a66",
            "MemberId": "f75b0252-a416-11e4-a111-57b4d90536cc",
            "GroupId": "3cf21720-9cd2-11e2-a3a4-25024474fe63",
            "Rank": 2,
            "Type": "ProductItem",
            "Item": {
                "Id": "5f4dd850-c403-11e3-a9c0-71c4281b4208",
                "Name": "Suggested product item"
            },
            "Status": "Active",
            "FulfillmentMemberId": ""
        };
    }
    return {
        getWishList: getWishList,
        getSingleWish: getSingleWish
    };
});