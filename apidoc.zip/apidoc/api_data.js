define({ "api": [
  {
    "type": "get",
    "url": "/1.0/Departments/",
    "title": "Get Departments",
    "version": "1.0.0",
    "name": "GetDepartments",
    "group": "Departments",
    "description": "<p>Returns an array of Departments</p>",
    "parameter": {
      "fields": {
        "Query String Params": [
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "skip",
            "description": "<p>The number of records to skip</p>"
          },
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "take",
            "description": "<p>The number of records to return (max 25)</p>"
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Departments.js",
    "groupTitle": "Departments",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidTakeValue",
            "description": "<p>Take value has to be positive number and less than or equal to 25</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidSkipValue",
            "description": "<p>Skip value has to be positive number</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Departments</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.DepartmentId",
            "description": "<p>The Department's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Name",
            "description": "<p>The Department's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Description",
            "description": "<p>The Department's description</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar header = {\n    host: 'api.highground.com',\n    port: 443,\n    clientkey: '[Your API Key]',\n    path: '/1.0/Departments/',\n    method: 'GET'\n};\n\nvar reqGet = https.request(header, function(response) {\n    var buffer = \"\", data;\n    \n    response.on('data', function (chunk) {\n        buffer += chunk;\n    });\n\n    response.on('end', function (err) {\n        data = JSON.parse(buffer);\n        console.log('statusCode: ', response.statusCode);\n        console.log('data:', data);\n    });\n});\n\nreqGet.on('error', function(e) {\n  console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\n\ndef get_departments\n    uri = URI.parse(\"https://api.highground.com/1.0/Departments/\")\n    request = Net::HTTP::Get.new(uri)\n    request['clientkey'] = \"Your API key\"\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef get_department_info():\n    headers = {\n        'Accept' : 'application/json',\n        'clientkey' : API_ACCESS_KEY\n    }\n    r = requests.get(\n                    'https://api.highground.com/1.0/Departments/',\n                    headers=headers\n    )\n    print (r.status_code)\n    print (r.text)\n    \nget_department_info()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Departments/';\n$curl = curl_init($service_url);\n\n$headers = array (\n    \"Accept: application/json\",\n    \"clientkey:[Your API Key]\"\n);\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n    $info = curl_getinfo($curl);\n    curl_close($curl);\n    die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n    die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string EndPoint = \"https://api.highground.com/1.0/Departments/\";\n        \n        public static void Main(string[] args)\n        {\n            var request = (HttpWebRequest)WebRequest.Create(EndPoint);\n            request.Method = \"GET\";\n            request.ContentLength = 0;\n            request.ContentType = \"application/json\";\n            request.Headers.Add(\"clientkey\", \"[Your API Key]\");\n            using (var response = (HttpWebResponse)request.GetResponse())\n            {\n              var responseValue = string.Empty;\n              if (response.StatusCode != HttpStatusCode.OK)\n              {\n                var message = String.Format(\"Request failed. Received HTTP {0}\", response.StatusCode);\n                throw new ApplicationException(message);\n              }\n              using (var responseStream = response.GetResponseStream())\n              {\n                if (responseStream != null)\n                  using (var reader = new StreamReader(responseStream))\n                  {\n                    responseValue = reader.ReadToEnd();\n                  }\n              }\n              Console.Write(responseValue);\n            }\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\n\nclass Rextester\n{  \n    public static void main(String args[])\n    {\n        try \n        {\n            URL url = new URL(\"https://api.highground.com/1.0/Departments/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"GET\");\n            conn.setRequestProperty(\"Accept\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X GET \"https://api.highground.com/1.0/Departments/\"",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "get",
    "url": "/1.0/Locations/",
    "title": "Get Locations",
    "version": "1.0.0",
    "name": "GetLocations",
    "group": "Locations",
    "description": "<p>Return an array of Locations</p>",
    "parameter": {
      "fields": {
        "Query String Params": [
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "skip",
            "description": "<p>The number of records to skip</p>"
          },
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "take",
            "description": "<p>The number of records to return (max 25)</p>"
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Locations.js",
    "groupTitle": "Locations",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidTakeValue",
            "description": "<p>Take value has to be positive number and less than or equal to 25</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidSkipValue",
            "description": "<p>Skip value has to be positive number</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Locations</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.LocationId",
            "description": "<p>The Location's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Name",
            "description": "<p>The Location's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.LocationCode",
            "description": "<p>The Location's code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.Description",
            "description": "<p>The Location's description</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "body.Address",
            "description": "<p>The Location's address information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Address1",
            "description": "<p>The address's line 1</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Address2",
            "description": "<p>The address's line 2</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.City",
            "description": "<p>The address's city</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.State",
            "description": "<p>The address's state</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Zip",
            "description": "<p>The address's zip</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Country",
            "description": "<p>The address's country</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.TimeZone",
            "description": "<p>The Location's timezone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.Phone",
            "description": "<p>The Location's contact phone number</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.Language",
            "description": "<p>The Location's Language</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar header = {\n    host: 'api.highground.com',\n    port: 443,\n    clientkey: '[Your API Key]',\n    path: '/1.0/Locations/',\n    method: 'GET'\n};\n\nvar reqGet = https.request(header, function(response) {\n    var buffer = \"\", data;\n    \n    response.on('data', function (chunk) {\n        buffer += chunk;\n    });\n\n    response.on('end', function (err) {\n        data = JSON.parse(buffer);\n        console.log('statusCode: ', response.statusCode);\n        console.log('data:', data);\n    });\n});\n\nreqGet.on('error', function(e) {\n  console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\n\ndef get_locations\n    uri = URI.parse(\"https://api.highground.com/1.0/Locations/\")\n    request = Net::HTTP::Get.new(uri)\n    request['clientkey'] = \"Your API key\"\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef get_locations_info():\n    headers = {\n        'Accept' : 'application/json',\n        'clientkey' : API_ACCESS_KEY\n    }\n    r = requests.get(\n                    'https://api.highground.com/1.0/Locations/',\n                    headers=headers\n    )\n    print (r.status_code)\n    print (r.text)\n    \nget_locations_info()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Locations';\n$curl = curl_init($service_url);\n\n$headers = array (\n    \"Accept: application/json\",\n    \"clientkey:[Your API Key]\"\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n    $info = curl_getinfo($curl);\n    curl_close($curl);\n    die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n    die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string EndPoint = \"https://api.highground.com/1.0/Locations/\";\n        \n        public static void Main(string[] args)\n        {\n            var request = (HttpWebRequest)WebRequest.Create(EndPoint);\n            request.Method = \"GET\";\n            request.ContentLength = 0;\n            request.ContentType = \"application/json\";\n            request.Headers.Add(\"clientkey\", \"[Your API Key]\");\n            using (var response = (HttpWebResponse)request.GetResponse())\n            {\n              var responseValue = string.Empty;\n              if (response.StatusCode != HttpStatusCode.OK)\n              {\n                var message = String.Format(\"Request failed. Received HTTP {0}\", response.StatusCode);\n                throw new ApplicationException(message);\n              }\n              using (var responseStream = response.GetResponseStream())\n              {\n                if (responseStream != null)\n                  using (var reader = new StreamReader(responseStream))\n                  {\n                    responseValue = reader.ReadToEnd();\n                  }\n              }\n              Console.Write(responseValue);\n            }\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\n\nclass Rextester\n{  \n    public static void main(String args[])\n    {\n        try \n        {\n            URL url = new URL(\"https://api.highground.com/1.0/Locations/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"GET\");\n            conn.setRequestProperty(\"Accept\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X GET \"https://api.highground.com/1.0/Locations/\"",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "post",
    "url": "/1.0/Locations",
    "title": "Add or Update Locations",
    "version": "1.0.0",
    "name": "UpdateLocations",
    "group": "Locations",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Message confirming Locations has been imported successfully</p>"
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Locations</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.LocationId",
            "description": "<p>The Location's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Name",
            "description": "<p>The Location's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.LocationCode",
            "description": "<p>The Location's code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.Description",
            "description": "<p>The Location's description</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "body.Address",
            "description": "<p>The Location's address information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Address1",
            "description": "<p>The address's line 1</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Address2",
            "description": "<p>The address's line 2</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.City",
            "description": "<p>The address's city</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.State",
            "description": "<p>The address's state</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Zip",
            "description": "<p>The address's zip</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Address.Country",
            "description": "<p>The address's country</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.TimeZone",
            "description": "<p>The Location's timezone</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.Phone",
            "description": "<p>The Location's contact phone number</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": true,
            "field": "body.Language",
            "description": "<p>The Location's Language</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Example Successful Response:",
          "content": "{\n    \"message\": \"Locations has been imported successfully.\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "hgnode/api/1.0/Locations.js",
    "groupTitle": "Locations",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MissingRequiredLocationInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidTimeZone",
            "description": "<p>An Invalid TimeZone was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "CountryNotFound",
            "description": "<p>Country is not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "Duplicate",
            "description": "<p>Location name or code. More information will be in the 'details' property</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar updateLocations = [\n     {\n        Name: 'New Location Name',\n        LocationCode: 'NewLocationCode',\n        Description: 'New Location Description',\n        Language: 'en',\n        TimeZone' : 'Central Time',\n        Address: {\n            Address1: '363 W Erie St.',\n            Address2: 'Suite 500',\n            City: 'Chicago',\n            State: 'IL',\n            Zip: '60654',\n            Country: 'United States'\n        },\n        Phone: '1234567890'\n     },\n     {\n        LocationId: '3f187010-fc9d-11e6-91d3-bf98e3690106',\n        Name: 'Updated Location Name',\n        LocationCode: 'LocationCode',\n        Description: 'Updated Location Description',\n        Language: 'en',\n        TimeZone: 'central time',\n        Address: {\n            Address1: '123 Main Street.',\n            Address2: 'Suite 500',\n            City: 'Chicago',\n            State: 'IL',\n            Zip: '60654',\n            Country: 'United States'\n        }\n     }];\nvar dataString = JSON.stringify(updateLocations);\nvar postheaders = {\n        'Accept' : 'application/json',  \n        'Content-Type' : 'application/json',\n        'clientkey' : '[Your API Key]',\n        'Content-Length' : dataString.length\n    };\n\nvar options = {\n    host: 'api.highground.com',\n    port: 443,\n    path: '/1.0/Locations/',\n    method: 'POST',\n    headers: postheaders,\n    body: dataString\n};\n\nvar reqGet = https.request(options, function(response) {\n  var buffer = \"\", data;\n  response.on('data', function (chunk) {\n    buffer += chunk;\n  });\n  response.on('end', function (err) {\n    data = JSON.parse(buffer);\n    console.log('statusCode: ', response.statusCode);\n    console.log('data:', data);\n  });\n});\n\nreqGet.on('error', function(e) {\n    console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\nrequire \"json/ext\"\n\ndef update_locations\n    uri = URI.parse(\"https://api.highground.com/1.0/Locations/\")\n    request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})\n    request['clientkey'] = \"Your API key\"\n    request.body = [\n     {\n        Name: 'New Location Name',\n        LocationCode: 'NewLocationCode',\n        Description: 'New Location Description',\n        Language: 'en',\n        TimeZone' : 'Central Time',\n        Address: {\n            Address1: '363 W Erie St.',\n            Address2: 'Suite 500',\n            City: 'Chicago',\n            State: 'IL',\n            Zip: '60654',\n            Country: 'United States'\n        },\n        Phone: '1234567890'\n     },\n     {\n        LocationId: '3f187010-fc9d-11e6-91d3-bf98e3690106',\n        Name: 'Updated Location Name',\n        LocationCode: 'LocationCode',\n        Description: 'Updated Location Description',\n        Language: 'en',\n        TimeZone: 'central time',\n        Address: {\n            Address1: '123 Main Street.',\n            Address2: 'Suite 500',\n            City: 'Chicago',\n            State: 'IL',\n            Zip: '60654',\n            Country: 'United States'\n        }\n     }].to_json\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res.body}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import json\nimport requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef update_locations():\n  headers = {\n      'Accept' : 'application/json',\n      'Content-type': 'application/json',\n      'clientkey' : API_ACCESS_KEY\n  }\n  payload = json.dumps([\n     {\n        \"Name\": \"New Location Name\",\n        \"LocationCode\": \"NewLocationCode\",\n        \"Description\": \"New Location Description\",\n        \"Language\": \"en\",\n        \"TimeZone\" : \"Central Time\",\n        \"Address\": {\n            \"Address1\": \"363 W Erie St.\",\n            \"Address2\": \"Suite 500\",\n            \"City\": \"Chicago\",\n            \"State\": \"IL\",\n            \"Zip\": \"60654\",\n            \"Country\": \"United States\"\n        },\n        \"Phone\": \"1234567890\"\n     },\n     {\n        \"LocationId\": \"3f187010-fc9d-11e6-91d3-bf98e3690106\",\n        \"Name\": \"Updated Location Name\",\n        \"LocationCode\": \"LocationCode\",\n        \"Description\": \"Updated Location Description\",\n        \"Language\": \"en\",\n        \"TimeZone\": \"central time\",\n        \"Address\": {\n            \"Address1\": \"123 Main Street.\",\n            \"Address2\": \"Suite 500\",\n            \"City\": \"Chicago\",\n            \"State\": \"IL\",\n            \"Zip\": \"60654\",\n            \"Country\": \"United States\"\n     }])\n\n  r = requests.post(\n                  'https://api.highground.com/1.0/Locations/',\n                  headers=headers,\n                  data=payload,\n  )\n  print (r.status_code)\n  print (r.text)\n  \nupdate_locations()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Locations/';\n$curl = curl_init($service_url);\n\n$headers = array (\n   \"Accept: application/json\",\n   \"Content-Type:application/json\",\n   \"clientkey:[Your API Key]\"\n);\n\n$newLocation = array(\n   'Name' => 'New Location Name',\n   'LocationCode' => 'NewLocationCode',\n   'Description' => 'New Location Description',\n   'Language' => 'en',\n   'TimeZone' => 'Central Time',\n   'Address' =>  array(\n       'Address1' =>  '363 W Erie St.',\n       'Address2' =>  'Suite 500',\n       'City' =>  'Chicago',\n       'State' =>  'IL',\n       'Zip' =>  '60654',\n       'Country' =>  'United States'\n    ),\n   'Phone' => '1234567890'\n);\n\n$updateLocation = array(\n   'LocationId' => '3f187010-fc9d-11e6-91d3-bf98e3690106',\n   'Name' => 'Updated Location Name',\n   'LocationCode' => 'LocationCode',\n   'Description' => 'Updated Location Description',\n   'Language' => 'en',\n   'TimeZone' => 'central time',\n   'Address' =>  array(\n       'Address1' =>  '123 Main Street.',\n       'Address2' =>  'Suite 500',\n       'City' =>  'Chicago',\n       'State' =>  'IL',\n       'Zip' =>  '60654',\n       'Country' =>  'United States'\n    ),\n   'Phone' => '1234567890'\n);\n$curl_post_data = array($newLocation, $updateLocation);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_POST, true);\ncurl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Collections.Generic;\nusing System.Collections;\nusing System.Net;\nusing System.Text;\nusing System.serviceModel;\nusing System.Runtime.Serialization;\nusing System.ServiceModel.Web;\nusing System.Web.Script.Serialization;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string uri = \"https://api.highground.com/1.0/Locations/\";\n        public class Location\n        {\n            public String LocationId;\n            public String Name;\n            public String LocationCode;\n            public String Description;\n            public String Language;\n            public String TimeZone;\n            public String Phone;\n            public Address Address;\n        }\n        public class Address\n        {\n            public String Address1;\n            public String Address2;\n            public String City;\n            public String State;\n            public String Zip;\n            public String Country;\n        }\n\n        public static void Main(string[] args)\n        {\n            var locations = new List<Location>();\n            var newLocation = new Location();\n            newLocation.Name = \"New Location Name\";\n            newLocation.LocationCode = \"NewLocationCode\";\n            newLocation.Description = \"New Location Description\";\n            newLocation.Language = \"en\";\n            newLocation.TimeZone = \"Central Time\";\n            newLocation.Phone = \"1234567890\";\n            newLocation.Address = new Address {\n                Address1 = \"363 W Erie St.\",\n                Address2 = \"Suite 500\",\n                City = \"Chicago\",\n                State = \"IL\",\n                Zip = \"60654\",\n                Country = \"United States\"\n            };\n            locations.Add(newLocation);\n            \n            var updatedLocation = new Location();\n            updatedLocation.LocationId = \"3f187010-fc9d-11e6-91d3-bf98e3690127\";\n            updatedLocation.Name = \"Updated Location Name\";\n            updatedLocation.LocationCode = \"LocationCode\";\n            updatedLocation.Description = \"Updated Location Description\";\n            updatedLocation.Language = \"en\";\n            updatedLocation.TimeZone = \"central time\";\n            updatedLocation.Address = new Address {\n                Address1 = \"123 Main Street.\",\n                Address2 = \"Suite 500\",\n                City = \"Chicago\",\n                State = \"IL\",\n                Zip = \"60654\",\n                Country = \"United States\"\n            };\n            locations.Add(updatedLocation);\n            \n            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);\n            request.Method = \"POST\";\n            request.ContentType = \"application/json;charset=utf-8\";\n            var json = new JavaScriptSerializer().Serialize(locations);\n            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();\n            byte[] bytes = encoding.GetBytes(json);\n            request.ContentLength = bytes.Length;\n            using (Stream requestStream = request.GetRequestStream())\n            {\n                requestStream.Write(bytes, 0, bytes.Length);\n            }\n            request.BeginGetResponse((x) =>\n            {\n                using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))\n                {\n                    if (callback != null)\n                    {\n                        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));\n                        callback(ser.ReadObject(response.GetResponseStream()) as Response);\n                    }\n                }\n            }, null);\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.io.OutputStream;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\nimport java.util.HashMap;\nimport java.util.Map;\nimport com.google.gson.Gson;\n\nclass Rextester\n{\n    public static void main(String args[])\n    {\n        try \n        {\n            URL url = new URL(\"https://api.highground.com/1.0/Locations/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"POST\");\n            conn.setRequestProperty(\"Content-Type\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            HashMap<String, Object> locations = new HashMap<String, Object>();\n            HashMap<String, Object> newLocation = new HashMap<String, Object>();\n            newLocation.put(\"Name\", \"New Location Name\");\n            newLocation.put(\"LocationCode\", \"NewLocationCode\");\n            newLocation.put(\"Description\", \"New Location Description);\n            newLocation.put(\"Language\", \"en\");\n            newLocation.put(\"TimeZone\", \"Central Time'\");\n            newLocation.put(\"Phone\", \"1234567890\");\n            HashMap<String, Object> newlocationAddress = new HashMap<String, Object>();\n            newlocationAddress.put(\"Address1\", \"363 W Erie St.\");\n            newlocationAddress.put(\"Address2\", \"Suite 500\");\n            newlocationAddress.put(\"City\", \"Chicago\");\n            newlocationAddress.put(\"State\", \"IL\");\n            newlocationAddress.put(\"Zip\", \"60654);\n            newlocationAddress.put(\"Country\", \"United States\");\n            newLocation.put(\"Address\", newlocationAddress);\n            locations.put(\"location\", newLocation);\n\n            HashMap<String, Object> updateLocation = new HashMap<String, Object>();\n            updateLocation.put(\"LocationId\", \"3f187010-fc9d-11e6-91d3-bf98e3690106\");\n            updateLocation.put(\"Name\", \"New Location Name\");\n            updateLocation.put(\"LocationCode\", \"NewLocationCode\");\n            updateLocation.put(\"Description\", \"New Location Description);\n            updateLocation.put(\"Language\", \"en\");\n            updateLocation.put(\"TimeZone\", \"Central Time'\");\n            HashMap<String, Object> updatelocationAddress = new HashMap<String, Object>();\n            updatelocationAddress.put(\"Address1\", \"123 Main Street.\");\n            updatelocationAddress.put(\"Address2\", \"Suite 500\");\n            updatelocationAddress.put(\"City\", \"Chicago\");\n            updatelocationAddress.put(\"State\", \"IL\");\n            updatelocationAddress.put(\"Zip\", \"60654);\n            updatelocationAddress.put(\"Country\", \"United States\");\n            updateLocation.put(\"Address\", updatelocationAddress);\n            locations.put(\"location\", updateLocation);\n            \n            Gson gson = new Gson();\n            String json = gson.toJson(locations);\n            OutputStream os = conn.getOutputStream();\n            os.write(json.getBytes());\n            os.flush();\n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X POST \"https://api.highground.com/1.0/Locations/\" \\\n--data '[{\"Name\": \"New Location Name\",\"LocationCode\": \"NewLocationCode\",\"Description\": \"New Location Description\",\"Language\": \"en\",\"TimeZone\" : \"Central Time\",\"Address\": {\"Address1\": \"363 W Erie St.\",\"Address2\": \"Suite 500\",\"City\": \"Chicago\",\"State\": \"IL\",\"Zip\": \"60654\",\"Country\": \"United States\"},\"Phone\": \"1234567890\"},{\"LocationId\": \"3f187010-fc9d-11e6-91d3-bf98e3690106\",\"Name\": \"Updated Location Name\",\"LocationCode\": \"LocationCode\",\"Description\": \"Updated Location Description\",\"Language\": \"en\",\"TimeZone\": \"central time\",\"Address\": {\"Address1\": \"123 Main Street.\",\"Address2\": \"Suite 500\",\"City\": \"Chicago\",\"State\": \"IL\",\"Zip\": \"60654\",\"Country\": \"United States\"}]'",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "post",
    "url": "/1.0/Manager/TransferManager/",
    "title": "Transfer Manager",
    "version": "1.0.0",
    "name": "TransferManager",
    "group": "Manager",
    "description": "<p>Transfer members from one manager to other manager</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Message confirming the Transfer Manager was completed</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Example Successful Response:",
          "content": "{\n    \"message\": \"Transfer manager has been completed successfully.\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "hgnode/api/1.0/Manager.js",
    "groupTitle": "Manager",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "OldManagerMemberId",
            "description": "<p>The old manager member's identifier</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "NewManagerMemberId",
            "description": "<p>The new manager member's identifier</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MemberIds",
            "description": "<p>The list of member's identifier who reports to old manager</p>"
          },
          {
            "group": "body",
            "type": "Object",
            "optional": false,
            "field": "TransferItems",
            "description": "<p>The list of items that needs to be transfer under new manager</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "TransferItems.TransferCredit",
            "description": "<p>Is credit should be transfer to new manager? (Yes/No)</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "TransferItems.TransferPerform",
            "description": "<p>Is performance review should be transfer to new manager? (Yes/No)</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "TransferItems.TransferProfile",
            "description": "<p>Is direct report(s) should be transfer to new manager? (Yes/No)</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "TransferItems.TransferTracks",
            "description": "<p>Is tracks should be transfer to new manager? (Yes/No)</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "TransferItems.TransferPoints",
            "description": "<p>Is points should be transfer to new manager? (Yes/No)</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidTransferManagerInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OldManagerNotFound",
            "description": "<p>Old Manager was not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "NewManagerNotFound",
            "description": "<p>New Manager was not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ManagerWithoutDirectReports",
            "description": "<p>No direct reports found for the selected manager.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "NewManagerInvalidStatus",
            "description": "<p>New Manager status is not Active in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OldManagerInvalidStatus",
            "description": "<p>Old Manager status is not Active in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "SameOldAndNewManagerId",
            "description": "<p>OldManagerId and NewManagerId values are same.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "The",
            "description": "<p>member Id's passed in don't match the old manager's direct reports.</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar transferManager = {\n  OldManagerMemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n  NewManagerMemberId: '1139cf30-7103-11e5-a9bd-29f2977b44c4',\n  MemberIds: [],\n  TransferItems: {\n      TransferCredit: 'Yes',\n      TransferPerform: 'Yes',\n      TransferProfile: 'Yes',\n      TransferTracks: 'Yes',\n      TransferPoints: 'Yes'\n   }\n };\n\nvar dataString = JSON.stringify(transferManager);\nvar postheaders = {\n      'Accept' : 'application/json',  \n      'Content-Type' : 'application/json',\n      'clientkey' : '[Your API Key]',\n      'Content-Length' : dataString.length\n };\n\nvar options = {\n  host: 'api.highground.com',\n  port: 443,\n  path: '/1.0/Manager/TransferManager',\n  method: 'POST',\n  headers: postheaders,\n  body: dataString\n};\n\nvar reqGet = https.request(options, function(response) {\nvar buffer = \"\", data;\nresponse.on('data', function (chunk) {\n    buffer += chunk;\n});\nresponse.on('end', function (err) {\n    data = JSON.parse(buffer);\n    console.log('statusCode: ', response.statusCode);\n    console.log('data:', data);\n});\n});\n\nreqGet.on('error', function(e) {\n  console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\nrequire \"json/ext\"\n\ndef transfer_manager\n  uri = URI.parse(\"https://api.highground.com/1.0/Manager/TransferManager/\")\n  request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})\n  request['clientkey'] = \"Your API key\"\n  request.body = {\n      OldManagerMemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n      NewManagerMemberId: '1139cf30-7103-11e5-a9bd-29f2977b44c4',\n      MemberIds: [],\n      TransferItems: {\n         TransferCredit: 'Yes',\n         TransferPerform: 'Yes',\n         TransferProfile: 'Yes',\n         TransferTracks: 'Yes',\n         TransferPoints: 'Yes'\n   }\n  }.to_json\n  res = Net::HTTP.start(uri.host, uri.port,\n    :use_ssl => uri.scheme == 'https') {|http|\n    http.request(request)\n  }\n  puts \"response #{res}\"\n  rescue => e\n      puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": " import json\n import requests\n \n API_ACCESS_KEY='[Your API Key]'\n \n def transfer_manager():\n   headers = {\n       'Accept' : 'application/json',\n       'Content-type': 'application/json',\n       'clientkey' : API_ACCESS_KEY\n  }\n  payload = json.dumps({\n       \"OldManagerMemberId\": 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n       \"NewManagerMemberId\": '1139cf30-7103-11e5-a9bd-29f2977b44c4',\n       \"MemberIds\": [],\n       \"TransferItems\": {\n           \"TransferCredit\": 'Yes',\n           \"TransferPerform\": 'Yes',\n           \"TransferProfile\": 'Yes',\n           \"TransferTracks\": 'Yes',\n           \"TransferPoints\": 'Yes'\n       }\n  })\n  r = requests.post(\n       'https://api.highground.com/1.0/Manager/TransferManager/',\n       headers=headers,\n       data=payload,\n  )\n  print (r.status_code)\n  print (r.text)\n \ntransfer_manager()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Manager/TransferManager/';\n$curl = curl_init($service_url);\n\n$headers = array (\n  \"Accept: application/json\",\n  \"Content-Type:application/json\",\n  \"clientkey:[Your API Key]\"\n);\n\n$curl_post_data = array(\n  'OldManagerMemberId' => 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n  'NewManagerMemberId' => 'UserName',\n  'MemberIds' => array(\n       'MemberId' =>  '1a7484e0-519c-11e5-8bbd-a385a1c75a10',\n  ),\n  'TransferItems' => array(\n       'TransferCredit' => 'Yes',\n       'TransferPerform' => 'Yes',\n       'TransferProfile' => 'Yes',\n       'TransferTracks' => 'Yes',\n       'TransferPoints' => 'Yes',\n    )\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_POST, true);\ncurl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\nusing System.ServiceModel;\nusing System.Runtime.Serialization;\nusing System.ServiceModel.Web;\nusing System.Web.Script.Serialization;\n\nnamespace Rextester\n{\n  public class Program\n  {\n      public const string uri = \"https://api.highground.com/1.0/Manager/TransferManager\";\n      public class TransferManager\n      {\n          public String OldManagerMemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n          public String NewManagerMemberId = \"1139cf30-7103-11e5-a9bd-29f2977b44c4\";\n          public List<String> MemberIds = new List<String>();\n          public TransferItems TransferItems;\n      }\n      public class TransferItems\n      {\n          public String TransferCredit = \"Yes\";\n          public String TransferPerform = \"Yes\";\n          public String TransferProfile = \"Yes\";\n          public String TransferTracks = \"Yes\";\n          public String TransferPoints = \"Yes\";\n      }\n      public static void Main(string[] args)\n      {\n          var transferManager = new TransferManager();\n          HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);\n          request.Method = \"POST\";\n          request.ContentType = \"application/json;charset=utf-8\";\n          var json = new JavaScriptSerializer().Serialize(transferManager);\n          System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();\n          byte[] bytes = encoding.GetBytes(json);\n          request.ContentLength = bytes.Length;\n          using (Stream requestStream = request.GetRequestStream())\n          {\n              requestStream.Write(bytes, 0, bytes.Length);\n          }\n          request.BeginGetResponse((x) =>\n          {\n              using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))\n              {\n                  if (callback != null)\n                  {\n                      DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));\n                      callback(ser.ReadObject(response.GetResponseStream()) as Response);\n                  }\n              }\n          }, null);\n      }\n  }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.io.OutputStream;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\nimport java.util.HashMap;\nimport java.util.Map;\nimport com.google.gson.Gson;\n\n\nclass Rextester\n{\n  public static void main(String args[])\n  {\n      try \n      {\n          URL url = new URL(\"https://api.highground.com/1.0/Manager/TransferManager/\");\n          HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n          conn.setRequestMethod(\"POST\");\n          conn.setRequestProperty(\"Content-Type\", \"application/json\");\n          conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n          \n          HashMap<String, Object> transferManager = new HashMap<String, Object>();\n          transferManager.put(\"OldManagerMemberId\", \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\");\n          transferManager.put(\"NewManagerMemberId\", \"1139cf30-7103-11e5-a9bd-29f2977b44c4\");\n\n          HashMap<String, Object> transferItems = new HashMap<String, Object>();\n          transferItems.put(\"TransferCredit\", \"Yes\");\n          transferItems.put(\"TransferPerform\", \"Yes\");\n          transferItems.put(\"TransferProfile\", \"Yes\");\n          transferItems.put(\"TransferTracks\", \"Yes\");\n          transferItems.put(\"TransferPoints\", \"Yes\");\n          transferManager.put(\"TransferItems\", transferItems);\n\n          Gson gson = new Gson();\n          String json = gson.toJson(transferManager);\n          \n          OutputStream os = conn.getOutputStream();\n          os.write(json.getBytes());\n          os.flush();\n          \n          if (conn.getResponseCode() != 200) {\n              throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n          }\n          BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n          String output;\n          while ((output = br.readLine()) != null) {\n              System.out.println(output);\n          }\n          conn.disconnect();\n     } \n      catch (MalformedURLException e) { e.printStackTrace(); }\n      catch (IOException e) { e.printStackTrace(); }\n  }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X POST \"https://api.highground.com/1.0/Manager/TransferManager/\" \\\n--data '{\"OldManagerMemberId\":\"d9d14d00-41ca-11e5-95f3-29dbd151f43c\", \\\n           \"NewManagerMemberId\":\"1139cf30-7103-11e5-a9bd-29f2977b44c4\",\"MemberIds\": [], \\\n           \"TransferItems\":{\"TransferCredit\":\"Yes\",\"TransferPerform\":\"Yes\",\"TransferProfile\":\"Yes\",\"TransferTracks\":\"Yes\",\"TransferPoints\":\"Yes\"}}'",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "get",
    "url": "/1.0/Member/:id",
    "title": "Get Member",
    "version": "1.0.0",
    "name": "GetMember",
    "group": "Member",
    "description": "<p>Retrieve a Member by their unique ID</p>",
    "filename": "hgnode/api/1.0/Member.js",
    "groupTitle": "Member",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "URL Params": [
          {
            "group": "URL",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Member's unique ID</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MissingMemberId",
            "description": "<p>Member Id is not provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMemberId",
            "description": "<p>An invalid Member Id was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MemberNotFound",
            "description": "<p>Member was not found in the system</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MemberId",
            "description": "<p>The Member's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "Birthdate",
            "description": "<p>The Member's birthdate</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "UserName",
            "description": "<p>The Member's username</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Email",
            "description": "<p>The Member's email</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "HomeZip",
            "description": "<p>The Member's home zip code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "WorkZip",
            "description": "<p>The Member's work zip code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "EmployeeId",
            "description": "<p>The Member's employee ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "FirstName",
            "description": "<p>The Member's first name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LastName",
            "description": "<p>The Member's last name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "FullName",
            "description": "<p>The Member's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Position",
            "description": "<p>The Member's position</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "StartingDate",
            "description": "<p>The Member's starting date</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "EndingDate",
            "description": "<p>The Member's offboarded date</p>"
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "MyManagers",
            "description": "<p>This is an array of Member's manager information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.MemberId",
            "description": "<p>The Manager's MemberId</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.Email",
            "description": "<p>The Manager's EmployeeId</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.FullName",
            "description": "<p>The Manager's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "Location",
            "description": "<p>The Member's location information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Location.LocationId",
            "description": "<p>The location's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Location.Name",
            "description": "<p>The location's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Role",
            "description": "<p>The Member's role</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "GroupDepartment",
            "description": "<p>Member's department information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.DepartmentId",
            "description": "<p>The department's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.Name",
            "description": "<p>The department's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GravatarEmail",
            "description": "<p>The Member's email associated with a Gravatar</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar header = {\n    host: 'api.highground.com',\n    port: 443,\n    clientkey: '[Your API Key]',\n    path: '/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    method: 'GET'\n};\n\nvar reqGet = https.request(header, function(response) {\n    var buffer = \"\", data;\n    \n    response.on('data', function (chunk) {\n        buffer += chunk;\n    });\n\n    response.on('end', function (err) {\n        data = JSON.parse(buffer);\n        console.log('statusCode: ', response.statusCode);\n        console.log('data:', data);\n    });\n});\n\nreqGet.on('error', function(e) {\n  console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\n\ndef get_departments\n    uri = URI.parse(\"https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c\")\n    request = Net::HTTP::Get.new(uri)\n    request['clientkey'] = \"Your API key\"\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef get_member_info():\n    headers = {\n        'Accept' : 'application/json',\n        'clientkey' : API_ACCESS_KEY\n    }\n    payload = {\n        'MemberId': 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    }\n    r = requests.get(\n                    'https://api.highground.com/1.0/Member/',\n                    headers=headers,\n                    params=payload,\n    )\n    print (r.status_code)\n    print (r.text)\n    \nget_member_info()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c';\n$curl = curl_init($service_url);\n\n$headers = array (\n    \"Accept: application/json\",\n    \"clientkey:[Your API Key]\"\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n    $info = curl_getinfo($curl);\n    curl_close($curl);\n    die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n    die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string EndPoint = \"https://api.highground.com/1.0/Member/\";\n        \n        public static void Main(string[] args)\n        {\n            public String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            var request = (HttpWebRequest)WebRequest.Create(EndPoint + MemberId);\n            request.Method = \"GET\";\n            request.ContentLength = 0;\n            request.ContentType = \"application/json\";\n            request.Headers.Add(\"clientkey\", \"[Your API Key]\");\n            using (var response = (HttpWebResponse)request.GetResponse())\n            {\n              var responseValue = string.Empty;\n              if (response.StatusCode != HttpStatusCode.OK)\n              {\n                var message = String.Format(\"Request failed. Received HTTP {0}\", response.StatusCode);\n                throw new ApplicationException(message);\n              }\n              using (var responseStream = response.GetResponseStream())\n              {\n                if (responseStream != null)\n                  using (var reader = new StreamReader(responseStream))\n                  {\n                    responseValue = reader.ReadToEnd();\n                  }\n              }\n              Console.Write(responseValue);\n            }\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\n\nclass Rextester\n{  \n    public static void main(String args[])\n    {\n        try \n        {\n            String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            URL url = new URL(\"https://api.highground.com/1.0/Member/\" + MemberId);\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"GET\");\n            conn.setRequestProperty(\"Accept\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X GET \"https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c\"",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "delete",
    "url": "/1.0/Member/:id",
    "title": "Offboard Member",
    "version": "1.0.0",
    "name": "Offboard_Member",
    "group": "Member",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Message confirming the Member was offboarded</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Example Successful Response:",
          "content": "{\n    \"message\": \"Member has been successfully offboarded.\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "hgnode/api/1.0/Member.js",
    "groupTitle": "Member",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "MemberId",
            "description": "<p>The Member's unique ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "UserName",
            "description": "<p>The Member's username</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "FirstName",
            "description": "<p>The Member's first name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "LastName",
            "description": "<p>The Member's last name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "allowedValues": [
              "Voluntary",
              "InVoluntary"
            ],
            "optional": false,
            "field": "OffBoardType",
            "description": "<p>Pick OffBoardType from available list.</p>"
          },
          {
            "group": "body",
            "type": "Date",
            "optional": false,
            "field": "OffBoardDate",
            "description": "<p>The date when member is being OffBoarded</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "NotificationEmail",
            "description": "<p>Email address where all future Member's email supposed to be forwarded.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MissingMemberId",
            "description": "<p>Member Id is not provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMemberId",
            "description": "<p>An invalid Member Id was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MemberNotFound",
            "description": "<p>Member was not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMembersInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar offBoardMember = {\n    MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    UserName: 'UserName',\n    FirstName: 'FirstName',\n    LastName: 'LastName',\n    OffBoardType: 'Voluntary',\n    OffBoardDate: 'MM/DD/YYYY',\n    NotificationEmail: 'notificationemail@highground.com'\n};\n\nvar dataString = JSON.stringify(offBoardMember);\nvar postheaders = {\n        'Accept' : 'application/json',  \n        'Content-Type' : 'application/json',\n        'clientkey' : '[Your API Key]',\n        'Content-Length' : dataString.length\n    };\n\nvar options = {\n    host: 'api.highground.com',\n    port: 443,\n    path: '/1.0/Member/',\n    method: 'DELETE',\n    headers: postheaders,\n    body: dataString\n};\n\nvar reqGet = https.request(options, function(response) {\n  var buffer = \"\", data;\n  response.on('data', function (chunk) {\n      buffer += chunk;\n  });\n  response.on('end', function (err) {\n      data = JSON.parse(buffer);\n      console.log('statusCode: ', response.statusCode);\n      console.log('data:', data);\n  });\n});\n\nreqGet.on('error', function(e) {\n    console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\nrequire \"json/ext\"\n\ndef offboard_member\n    uri = URI.parse(\"https://api.highground.com/1.0/Member/\")\n    request = Net::HTTP::Delete.new(uri, initheader = {'Content-Type' =>'application/json'})\n    request['clientkey'] = \"Your API key\"\n    request.body = {\n        MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n        UserName: 'UserName',\n        FirstName: 'FirstName',\n        LastName: 'LastName',\n        OffBoardType: 'Voluntary',\n        OffBoardDate: 'MM/DD/YYYY',\n        NotificationEmail: 'notificationemail@highground.com'\n    }.to_json\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import json\nimport requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef offboard_member():\n  headers = {\n      'Accept' : 'application/json',\n      'Content-type': 'application/json',\n      'clientkey' : API_ACCESS_KEY\n  }\n  payload = json.dumps({\n    \"MemberId\": \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\",\n    \"UserName\": \"UserName\",\n    \"FirstName\": \"FirstName\",\n    \"LastName\": \"LastName\",\n    \"OffBoardType\": \"Voluntary\",\n    \"OffBoardDate\": \"MM/DD/YYYY\",\n    \"NotificationEmail\": \"notificationemail@highground.com\"\n  })\n  r = requests.delete(\n                  'https://api.highground.com/1.0/Member/',\n                  headers=headers,\n                  data=payload,\n  )\n  print (r.status_code)\n  print (r.text)\n  \noffboard_member()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Member';\n$curl = curl_init($service_url);\n\n$headers = array (\n  \"Accept: application/json\",\n  \"Content-Type:application/json\",\n  \"clientkey:[Your API Key]\"\n);\n\n$curl_post_data = array(\n    'MemberId' => 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    'UserName' => 'UserName',\n    'FirstName' => 'FirstName',\n    'LastName' => 'LastName',\n    'OffBoardType' => 'Voluntary',\n    'OffBoardDate' => 'MM/DD/YYYY',\n    'NotificationEmail' => 'notificationemail@highground.com'\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_CUSTOMREQUEST, \"DELETE\");\ncurl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\nusing System.ServiceModel;\nusing System.Runtime.Serialization;\nusing System.ServiceModel.Web;\nusing System.Web.Script.Serialization;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string uri = \"https://api.highground.com/1.0/Member\";\n        public class MemberOffBoard\n        {\n            public String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            public String UserName = \"UserName\";\n            public String FirstName = \"FirstName\";\n            public String LastName = \"LastName\";\n            public String OffBoardType = \"Voluntary\";\n            public DateTime OffBoardDate = \"MM/DD/YYYY\";\n            public String NotificationEmail = \"notificationemail@highground.com\";\n        }\n        public static void Main(string[] args)\n        {\n            var offBoardMember = new MemberOffBoard();\n            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);\n            request.Method = \"DELETE\";\n            request.ContentType = \"application/json;charset=utf-8\";\n            var json = new JavaScriptSerializer().Serialize(offBoardMember);\n            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();\n            byte[] bytes = encoding.GetBytes(json);\n            request.ContentLength = bytes.Length;\n            using (Stream requestStream = request.GetRequestStream())\n            {\n                requestStream.Write(bytes, 0, bytes.Length);\n            }\n            request.BeginGetResponse((x) =>\n            {\n                using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))\n                {\n                    if (callback != null)\n                    {\n                        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));\n                        callback(ser.ReadObject(response.GetResponseStream()) as Response);\n                    }\n                }\n            }, null);\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.io.OutputStream;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\nimport java.util.HashMap;\nimport java.util.Map;\nimport com.google.gson.Gson;\n\n\nclass Rextester\n{\n    public static void main(String args[])\n    {\n        try \n        {\n            URL url = new URL(\"https://api.highground.com/1.0/Member/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"DELETE\");\n            conn.setRequestProperty(\"Content-Type\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            HashMap<String, Object> offBoardMember = new HashMap<String, Object>();\n            offBoardMember.put(\"MemberId\", \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\");\n            offBoardMember.put(\"UserName\", \"UserName\");\n            offBoardMember.put(\"FirstName\", \"FirstName\");\n            offBoardMember.put(\"LastName\", \"LastName\");\n            offBoardMember.put(\"OffBoardType\", \"Voluntary\");\n            offBoardMember.put(\"OffBoardDate\", \"MM/DD/YYYY\");\n            offBoardMember.put(\"NotificationEmail\", \"notificationemail@highground.com\");\n\n            Gson gson = new Gson();\n            String json = gson.toJson(offBoardMember);\n            \n            OutputStream os = conn.getOutputStream();\n            os.write(json.getBytes());\n            os.flush();\n            \n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X DELETE \"https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c\" \\\n--data '{\"UserName\":\"UserName\",\"FirstName\":\"FirstName\",\"LastName\":\"LastName\",\"OffBoardType\":\"Voluntary\",\"OffBoardDate\":\"MM/DD/YYYY\",\"NotificationEmail\":\"notificationemail@highground.com\"}'",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "post",
    "url": "/1.0/Member",
    "title": "Onboard Member",
    "version": "1.0.0",
    "name": "Onboard_Member",
    "group": "Member",
    "filename": "hgnode/api/1.0/Member.js",
    "groupTitle": "Member",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "Date",
            "optional": false,
            "field": "Birthdate",
            "description": "<p>The Member's birthdate</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "UserName",
            "description": "<p>The Member's username</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "Password",
            "description": "<p>The Member's password (only used during onboarding)</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Email",
            "description": "<p>The Member's email</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "HomeZip",
            "description": "<p>The Member's home zip code</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "WorkZip",
            "description": "<p>The Member's work zip code</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "EmployeeId",
            "description": "<p>The Member's employee ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "FirstName",
            "description": "<p>The Member's first name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "LastName",
            "description": "<p>The Member's last name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "FullName",
            "description": "<p>The Member's full name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Position",
            "description": "<p>The Member's position</p>"
          },
          {
            "group": "body",
            "type": "Date",
            "optional": false,
            "field": "StartingDate",
            "description": "<p>The Member's starting date</p>"
          },
          {
            "group": "body",
            "type": "Date",
            "optional": true,
            "field": "EndingDate",
            "description": "<p>The Member's offboarded date</p>"
          },
          {
            "group": "body",
            "type": "Object[]",
            "optional": true,
            "field": "MyManagers",
            "description": "<p>This is an array of Member's manager information. When Supplied, Manager EmployeeId or MemberId is required.</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MyManagers.EmployeeId",
            "description": "<p>The Manager's EmployeeId</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MyManagers.MemberId",
            "description": "<p>The Manager's MemberId</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MyManagers.FullName",
            "description": "<p>The Manager's full name</p>"
          },
          {
            "group": "body",
            "type": "Object",
            "optional": false,
            "field": "Location",
            "description": "<p>The Member's location information</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Location.LocationId",
            "description": "<p>The Location's unique ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Location.Name",
            "description": "<p>The Location's name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "allowedValues": [
              "Employee",
              "Manager",
              "Director",
              "Executive",
              "Admin",
              "Owner",
              "ResellerAdmin"
            ],
            "optional": false,
            "field": "Role",
            "description": "<p>The Member's role</p>"
          },
          {
            "group": "body",
            "type": "Object",
            "optional": false,
            "field": "GroupDepartment",
            "description": "<p>The Member's department information</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.DepartmentId",
            "description": "<p>The Department's unique ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.Name",
            "description": "<p>The Department's name</p>"
          },
          {
            "group": "body",
            "type": "string",
            "optional": true,
            "field": "GravatarEmail",
            "description": "<p>The Member's email associated with a Gravatar</p>"
          },
          {
            "group": "body",
            "type": "Boolean",
            "optional": true,
            "field": "SuppressWelcomeMessage",
            "defaultValue": "true",
            "description": "<p>The Member's option to receive a welcome message when onboarding</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMembersInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DepartmentNotFound",
            "description": "<p>Department Id is not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "LocationNotFound",
            "description": "<p>Location Id is not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DuplicateEmployeeId",
            "description": "<p>EmployeeId is already in use</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DuplicateManagerMemberId",
            "description": "<p>MemberIds is duplicated</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DuplicateManagerEmployeeId",
            "description": "<p>EmployeeIds is duplicated</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidManagerMemberId",
            "description": "<p>Manager MemberId is not valid</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidManagerEmployeeId",
            "description": "<p>Manager MemberId is not valid</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ManagerWithMemberIdIsNotActive",
            "description": "<p>Manager with MemberId is not active</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ManagerWithEmployeeIdIsNotActive",
            "description": "<p>Manager with EmployeeId is not active</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ManagerMemberIdDoesNotMatchEmployeeId",
            "description": "<p>Manager EmployeeId does not match Manager EmployeeId in the System</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar updateMember = {\n    Birthdate: 'MM/DD/YYYY',\n    UserName: 'UserName',\n    Email: 'email@highground.com',\n    HomeZip: '12345',\n    WorkZip: '98765',\n    FirstName: 'FirstName',\n    LastName: 'LastName',\n    FullName: 'FirstName LastName',      \n    Position: 'CEO',\n    StartingDate: 'MM/DD/YYYY',\n    MyManagers: [{ \n        MemberId: '1a7484e0-519c-11e5-8bbd-a385a1c75a10',\n        EmployeeId: 'Manager EmployeeId',\n        FullName: 'Manager FullName' \n    }],\n    Location: {\n        LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',\n        Name: 'Chicago'\n    },\n    GroupDepartment: {\n        DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',\n        Name: 'IT'\n    },\n    Role: 'Employee',\n    GravatarEmail: 'gravataremail@highground.com',\n    EmployeeId: 'HG001'\n};\nvar dataString = JSON.stringify(updateMember);\nvar postheaders = {\n        'Accept' : 'application/json',  \n        'Content-Type' : 'application/json',\n        'clientkey' : '[Your API Key]',\n        'Content-Length' : dataString.length\n    };\n\nvar options = {\n    host: 'api.highground.com',\n    port: 443,\n    path: '/1.0/Member/',\n    method: 'POST',\n    headers: postheaders,\n    body: dataString\n};\n\nvar reqGet = https.request(options, function(response) {\n  var buffer = \"\", data;\n  response.on('data', function (chunk) {\n    buffer += chunk;\n  });\n  response.on('end', function (err) {\n    data = JSON.parse(buffer);\n    console.log('statusCode: ', response.statusCode);\n    console.log('data:', data);\n  });\n});\n\nreqGet.on('error', function(e) {\n    console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\nrequire \"json/ext\"\n\ndef onboard_member\n    uri = URI.parse(\"https://api.highground.com/1.0/Member/\")\n    request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})\n    request['clientkey'] = \"Your API key\"\n    request.body = {\n        Birthdate: 'MM/DD/YYYY',\n        UserName: 'UserName',\n        Email: 'email@highground.com',\n        HomeZip: '12345',\n        WorkZip: '98765',\n        FirstName: 'FirstName',\n        LastName: 'LastName',\n        FullName: 'FirstName LastName',\n        Position: 'CEO',\n        StartingDate: 'MM/DD/YYYY',\n        MyManagers: [{\n            MemberId: '1a7484e0-519c-11e5-8bbd-a385a1c75a10',\n            EmployeeId: 'Manager EmployeeId',\n            FullName: 'Manager FullName'\n        }],\n        Location: {\n            LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',\n            Name: 'Chicago'\n        },\n        GroupDepartment: {\n            DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',\n            Name: 'IT'\n        },\n        Role: 'Employee',\n        GravatarEmail: 'gravataremail@highground.com',\n        EmployeeId: 'HG001'\n    }.to_json\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res.body}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import json\nimport requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef onboard_member():\n  headers = {\n      'Accept' : 'application/json',\n      'Content-type': 'application/json',\n      'clientkey' : API_ACCESS_KEY\n  }\n  payload = json.dumps({\n        \"Birthdate\": \"MM/DD/YYYY\",\n        \"UserName\": \"UserName\",\n        \"Email\": \"email@highground.com\",\n        \"HomeZip\": \"12345\",\n        \"WorkZip\": \"98765\",\n        \"FirstName\": \"FirstName\",\n        \"LastName\": \"LastName\",\n        \"FullName\": \"FirstName LastName\",\n        \"Position\": \"CEO\",\n        \"StartingDate\": \"MM/DD/YYYY\",\n        \"MyManagers\": [{\n            \"MemberId\": \"1a7484e0-519c-11e5-8bbd-a385a1c75a10\",\n            \"EmployeeId\": \"Manager EmployeeId\",\n            \"FullName\": \"Manager FullName\"\n        }],\n        \"Location\": {\n            \"LocationId\": \"158f0270-519c-11e5-927c-7d3b5e612a77\",\n            \"Name\": \"Chicago\"\n        },\n        \"GroupDepartment\": {\n            \"DepartmentId\": \"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\",\n            \"Name\": \"IT\"\n        },\n        \"Role\": \"Employee\",\n        \"GravatarEmail\": \"gravataremail@highground.com\",\n        \"EmployeeId\": \"HG001\"\n    })\n  r = requests.post(\n                  'https://api.highground.com/1.0/Member/',\n                  headers=headers,\n                  data=payload,\n  )\n  print (r.status_code)\n  print (r.text)\n  \nonboard_member()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Member/';\n$curl = curl_init($service_url);\n\n$headers = array (\n   \"Accept: application/json\",\n   \"Content-Type:application/json\",\n   \"clientkey:[Your API Key]\"\n);\n\n$curl_post_data = array(\n   'Birthdate' => 'MM/DD/YYYY',\n   'UserName' => 'UserName',\n   'Email' => 'email@highground.com',\n   'HomeZip' => '12345',\n   'WorkZip' => '98765',\n   'FirstName' => 'FirstName',\n   'LastName' => 'LastName',\n   'FullName' => 'FirstName LastName',\n   'Position' => 'CEO',\n   'StartingDate' => 'MM/DD/YYYY',\n   'Role' => 'Employee',\n   'GravatarEmail' => 'gravataremail@highground.com',\n   'EmployeeId' => 'HG001',\n   'MyManagers' =>  array(\n       'MemberId' =>  '1a7484e0-519c-11e5-8bbd-a385a1c75a10',\n       'EmployeeId' =>  'Manager EmployeeId',\n       'FullName' =>  'Manager FullName'\n    ),\n   'Location' =>  array(\n       'LocationId' =>  '158f0270-519c-11e5-927c-7d3b5e612a77',\n       'Name' =>  'Chicago'\n    ),\n   'GroupDepartment' =>  array(\n       'DepartmentId' =>  '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',\n       'Name' =>  'IT'\n   )\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_POST, true);\ncurl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\nusing System.ServiceModel;\nusing System.Runtime.Serialization;\nusing System.ServiceModel.Web;\nusing System.Web.Script.Serialization;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string uri = \"https://api.highground.com/1.0/Member\";\n        public class Member\n        {\n            public DateTime Birthdate = \"MM/DD/YYYY\";\n            public String UserName = \"UserName\";\n            public String Email = \"email@highground.com\";\n            public String HomeZip = \"12345\";\n            public String WorkZip = \"98765\";\n            public String EmployeeId = \"HG001\";\n            public String FirstName = \"FirstName\";\n            public String LastName = \"LastName\";\n            public String FullName = \"FullName\";\n            public String Position = \"CEO\";\n            public DateTime StartingDate = \"MM/DD/YYYY\";\n            public String Role = \"Employee\";\n            public String GravatarEmail = \"gravataremail@highground.com\";\n            public Manager MyManagers;\n            public Location Location;\n            public Department GroupDepartment;\n        }\n        public class Manager\n        {\n            public String MemberId = \"1a7484e0-519c-11e5-8bbd-a385a1c75a10\";\n            public String UserId = \"158f0270-519c-11e5-927c-7d3b5e612a77\";\n            public String FullName = \"Manager FullName\";\n        }\n        public class Location\n        {\n            public String LocationId = \"158f0270-519c-11e5-927c-7d3b5e612a77\";\n            public String Name = \"Chicago\"; \n        }\n        public class Department\n        {\n            public String DepartmentId = \"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\";\n            public String Name = \"IT\"; \n        }\n        public static void Main(string[] args)\n        {\n            var member = new Member();\n            member.MyManagers = new Manager();\n            member.Location = new Location();\n            member.GroupDepartment = new Department();\n            \n            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);\n            request.Method = \"POST\";\n            request.ContentType = \"application/json;charset=utf-8\";\n            var json = new JavaScriptSerializer().Serialize(member);\n            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();\n            byte[] bytes = encoding.GetBytes(json);\n            request.ContentLength = bytes.Length;\n            using (Stream requestStream = request.GetRequestStream())\n            {\n                requestStream.Write(bytes, 0, bytes.Length);\n            }\n            request.BeginGetResponse((x) =>\n            {\n                using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))\n                {\n                    if (callback != null)\n                    {\n                        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));\n                        callback(ser.ReadObject(response.GetResponseStream()) as Response);\n                    }\n                }\n            }, null);\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.io.OutputStream;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\nimport java.util.HashMap;\nimport java.util.Map;\nimport com.google.gson.Gson;\n\nclass Rextester\n{\n    public static void main(String args[])\n    {\n        try \n        {\n            URL url = new URL(\"https://api.highground.com/1.0/Member/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"POST\");\n            conn.setRequestProperty(\"Content-Type\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            HashMap<String, Object> memberData = new HashMap<String, Object>();\n            memberData.put(\"Birthdate\", \"MM/DD/YYYY\");\n            memberData.put(\"UserName\", \"UserName\");\n            memberData.put(\"Email\", \"email@highground.com\");\n            memberData.put(\"HomeZip\", \"12345\");\n            memberData.put(\"WorkZip\", \"98765\");\n            memberData.put(\"EmployeeId\", \"HG001\");\n            memberData.put(\"FirstName\", \"FirstName\");\n            memberData.put(\"LastName\", \"LastName\");\n            memberData.put(\"FullName\", \"FullName\");\n            memberData.put(\"Position\", \"CEO\");\n            memberData.put(\"StartingDate\", \"MM/DD/YYYY\");\n            memberData.put(\"Role\", \"Employee\");\n            memberData.put(\"GravatarEmail\", \"gravataremail@highground.com\");\n\n            HashMap<String, Object> managerData = new HashMap<String, Object>();\n            managerData.put(\"MemberId\", \"1a7484e0-519c-11e5-8bbd-a385a1c75a10\");\n            managerData.put(\"EmployeeId\", \"Manager EmployeeId\");\n            managerData.put(\"FullName\", \"Manager FullName\");\n            memberData.put(\"MyManagers\", managerData);\n            \n            HashMap<String, Object> locationData = new HashMap<String, Object>();\n            locationData.put(\"LocationId\", \"158f0270-519c-11e5-927c-7d3b5e612a77\");\n            locationData.put(\"Name\", \"FirstName\");\n            memberData.put(\"Location\", locationData);\n            \n            HashMap<String, Object> departmentData = new HashMap<String, Object>();\n            departmentData.put(\"LocationId\", \"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\");\n            departmentData.put(\"Name\", \"IT\");\n            memberData.put(\"GroupDepartment\", departmentData);\n            \n            Gson gson = new Gson();\n            String json = gson.toJson(memberData);\n            OutputStream os = conn.getOutputStream();\n            os.write(json.getBytes());\n            os.flush();\n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X POST \"https://api.highground.com/1.0/Member/\" \\\n--data '{\"Birthdate\":\"MM/DD/YYYY\",\"UserName\":\"UserName\",\"Email\":\"email@highground.com\",\"HomeZip\":\"12345\",\"WorkZip\":\"98765\",\"FirstName\":\"FirstName\",\"LastName\":\"LastName\",\"FullName\":\"FirstName LastName\",\"Position\":\"CEO\",\"StartingDate\":\"MM/DD/YYYY\",\"MyManagers\":{\"MemberId\":\"1a7484e0-519c-11e5-8bbd-a385a1c75a10\",\"EmployeeId\":\"Manager EmployeeId\",\"FullName\":\"Manager FullName\"},\"Location\":{\"LocationId\":\"158f0270-519c-11e5-927c-7d3b5e612a77\",\"Name\":\"Chicago\"},\"GroupDepartment\":{\"DepartmentId\":\"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\",\"Name\":\"IT\"},\"Role\":\"Employee\",\"GravatarEmail\":\"gravataremail@highground.com\",\"EmployeeId\":\"HG001\"}'",
        "type": "Curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MemberId",
            "description": "<p>The Member's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "Birthdate",
            "description": "<p>The Member's birthdate</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "UserName",
            "description": "<p>The Member's username</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Email",
            "description": "<p>The Member's email</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "HomeZip",
            "description": "<p>The Member's home zip code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "WorkZip",
            "description": "<p>The Member's work zip code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "EmployeeId",
            "description": "<p>The Member's employee ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "FirstName",
            "description": "<p>The Member's first name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LastName",
            "description": "<p>The Member's last name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "FullName",
            "description": "<p>The Member's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Position",
            "description": "<p>The Member's position</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "StartingDate",
            "description": "<p>The Member's starting date</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "EndingDate",
            "description": "<p>The Member's offboarded date</p>"
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "MyManagers",
            "description": "<p>This is an array of Member's manager information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.MemberId",
            "description": "<p>The Manager's MemberId</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.Email",
            "description": "<p>The Manager's EmployeeId</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.FullName",
            "description": "<p>The Manager's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "Location",
            "description": "<p>The Member's location information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Location.LocationId",
            "description": "<p>The location's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Location.Name",
            "description": "<p>The location's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Role",
            "description": "<p>The Member's role</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "GroupDepartment",
            "description": "<p>Member's department information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.DepartmentId",
            "description": "<p>The department's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.Name",
            "description": "<p>The department's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GravatarEmail",
            "description": "<p>The Member's email associated with a Gravatar</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/1.0/Member/reinstate",
    "title": "Reinstate Member",
    "version": "1.0.0",
    "name": "Reinstate_Member",
    "group": "Member",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Message confirming the Member was reinstated</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Example Successful Response:",
          "content": "{\n    \"message\": \"Member reinstated.\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "hgnode/api/1.0/Member.js",
    "groupTitle": "Member",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MemberId",
            "description": "<p>The Member's unique ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Email",
            "description": "<p>Member new email address</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MissingMemberId",
            "description": "<p>Member Id is not provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMemberId",
            "description": "<p>An invalid Member Id was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MemberNotFound",
            "description": "<p>Member was not found in the system</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar reinstateMember = {\n    MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    Email: 'membernewemail@highground.com'\n};\n\nvar dataString = JSON.stringify(reinstateMember);\nvar postheaders = {\n        'Accept' : 'application/json',  \n        'Content-Type' : 'application/json',\n        'clientkey' : '[Your API Key]',\n        'Content-Length' : dataString.length\n    };\n\nvar options = {\n    host: 'apipoc.highground.com',\n    port: 443,\n    path: '/1.0/Member/reinstate/',\n    method: 'POST',\n    headers: postheaders,\n    body: dataString\n};\n\nvar reqGet = https.request(options, function(response) {\n  var buffer = \"\", data;\n  response.on('data', function (chunk) {\n    console.log('here', chunk);\n      buffer += chunk;\n  });\n  response.on('end', function (err) {\n      data = JSON.parse(buffer);\n      console.log('statusCode: ', response.statusCode);\n      console.log('data:', data);\n  });\n});\n\nreqGet.on('error', function(e) {\n    console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\nrequire \"json/ext\"\n\ndef reinstate_member\n    uri = URI.parse(\"https://api.highground.com/1.0/Member/reinstate/\")\n    request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})\n    request['clientkey'] = \"Your API key\"\n    request.body = {\n        MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n        Email: 'email@highground.com'\n    }.to_json\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import json\nimport requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef reinstate_member():\n    headers = {\n        'Accept' : 'application/json',\n        'Content-type': 'application/json',\n        'clientkey' : API_ACCESS_KEY\n    }\n    payload = json.dumps({\n      \"MemberId\": \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\",\n      \"Email\": \"email@highground.com\"\n    })\n    r = requests.post(\n                    'https://api.highground.com/1.0/reinstate/',\n                    headers=headers,\n                    data=payload,\n    )\n    print (r.status_code)\n    print (r.text)\n    \nreinstate_member()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/reinstate/';\n$curl = curl_init($service_url);\n\n$headers = array (\n  \"Accept: application/json\",\n  \"Content-Type:application/json\",\n  \"clientkey:[Your API Key]\"\n);\n\n$curl_post_data = array(\n    'MemberId' => 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    'Email' => 'email@highground.com'\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_POST, true);\ncurl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\nusing System.ServiceModel;\nusing System.Runtime.Serialization;\nusing System.ServiceModel.Web;\nusing System.Web.Script.Serialization;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string uri = \"https://api.highground.com/1.0/reinstate/\";\n        public class MemberReinstate\n        {\n            public String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            public String Email = \"email@highground.com\";\n        }\n        public static void Main(string[] args)\n        {\n            var memberReinstate = new MemberReinstate();\n            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);\n            request.Method = \"POST\";\n            request.ContentType = \"application/json;charset=utf-8\";\n            var json = new JavaScriptSerializer().Serialize(memberReinstate);\n            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();\n            byte[] bytes = encoding.GetBytes(json);\n            request.ContentLength = bytes.Length;\n            using (Stream requestStream = request.GetRequestStream())\n            {\n                requestStream.Write(bytes, 0, bytes.Length);\n            }\n            request.BeginGetResponse((x) =>\n            {\n                using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))\n                {\n                    if (callback != null)\n                    {\n                        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));\n                        callback(ser.ReadObject(response.GetResponseStream()) as Response);\n                    }\n                }\n            }, null);\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.io.OutputStream;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\nimport java.util.HashMap;\nimport java.util.Map;\nimport com.google.gson.Gson;\n\n\nclass Rextester\n{\n    public static void main(String args[])\n    {\n        try \n        {\n            URL url = new URL(\"https://api.highground.com/1.0/Member/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"POST\");\n            conn.setRequestProperty(\"Content-Type\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            HashMap<String, Object> memberReinstate = new HashMap<String, Object>();\n            memberReinstate.put(\"MemberId\", \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\");\n            memberReinstate.put(\"Email\", \"email@highground.com\");\n\n            Gson gson = new Gson();\n            String json = gson.toJson(memberReinstate);\n            OutputStream os = conn.getOutputStream();\n            os.write(json.getBytes());\n            os.flush();\n            \n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X POST \"https://api.highground.com/1.0/Member/reinstate/\" \\\n--data '{\"MemberId\":\"d9d14d00-41ca-11e5-95f3-29dbd151f43c\",\"Email\":\"email@highground.com\"}'",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "post",
    "url": "/1.0/Member/resendWelcomeEmail/:id",
    "title": "Resend welcome email",
    "version": "1.0.0",
    "name": "Resend_Welcome_Email",
    "group": "Member",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>Message confirming the Member's welcome email was sent</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Example Successful Response:",
          "content": "{\n    \"message\": \"Member welcome email has been sent.\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "hgnode/api/1.0/Member.js",
    "groupTitle": "Member",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "URL Params": [
          {
            "group": "URL",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Member's unique ID</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MissingMemberId",
            "description": "<p>Member Id is not provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMemberId",
            "description": "<p>An invalid Member Id was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MemberNotFound",
            "description": "<p>Member was not found in the system</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar header = {\n    host: 'api.highground.com',\n    port: 443,\n    clientkey: '[Your API Key]',\n    path: '/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    method: 'POST'\n};\n\nvar reqGet = https.request(header, function(response) {\n    var buffer = \"\", data;\n    \n    response.on('data', function (chunk) {\n        buffer += chunk;\n    });\n\n    response.on('end', function (err) {\n        data = JSON.parse(buffer);\n        console.log('statusCode: ', response.statusCode);\n        console.log('data:', data);\n    });\n});\n\nreqGet.on('error', function(e) {\n  console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\n\ndef get_departments\n    uri = URI.parse(\"https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c\")\n    request = Net::HTTP::Post.new(uri)\n    request['clientkey'] = \"Your API key\"\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef resend_welcome_email_to_member():\n    headers = {\n        'Accept' : 'application/json',\n        'Content-type': 'application/json',\n        'clientkey' : API_ACCESS_KEY\n    }\n    r = requests.post(\n                    'https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c',\n                    headers=headers\n    )\n    print (r.status_code)\n    print (r.text)\n\nresend_welcome_email_to_member()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c';\n$curl = curl_init($service_url);\n\n$headers = array (\n  \"Accept: application/json\",\n  \"clientkey:[Your API Key]\"\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_POST, true);\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string EndPoint = \"https://api.highground.com/1.0/Member/resendWelcomeEmail/\";\n        \n        public static void Main(string[] args)\n        {\n            public String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            var request = (HttpWebRequest)WebRequest.Create(EndPoint + MemberId);\n            request.Method = \"POST\";\n            request.ContentLength = 0;\n            request.ContentType = \"application/json\";\n            request.Headers.Add(\"clientkey\", \"[Your API Key]\");\n            using (var response = (HttpWebResponse)request.GetResponse())\n            {\n              var responseValue = string.Empty;\n              if (response.StatusCode != HttpStatusCode.OK)\n              {\n                var message = String.Format(\"Request failed. Received HTTP {0}\", response.StatusCode);\n                throw new ApplicationException(message);\n              }\n              using (var responseStream = response.GetResponseStream())\n              {\n                if (responseStream != null)\n                  using (var reader = new StreamReader(responseStream))\n                  {\n                    responseValue = reader.ReadToEnd();\n                  }\n              }\n              Console.Write(responseValue);\n            }\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\n\nclass Rextester\n{  \n    public static void main(String args[])\n    {\n        try \n        {\n            String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            URL url = new URL(\"https://api.highground.com/1.0/Member/resendWelcomeEmail/\" + MemberId);\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"POST\");\n            conn.setRequestProperty(\"Accept\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X POST \"https://api.highground.com/1.0/Member/resendWelcomeEmail/d9d14d00-41ca-11e5-95f3-29dbd151f43c\"",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "put",
    "url": "/1.0/Member/:id",
    "title": "Update Member",
    "version": "1.0.0",
    "name": "UpdateMember",
    "group": "Member",
    "filename": "hgnode/api/1.0/Member.js",
    "groupTitle": "Member",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "URL Params": [
          {
            "group": "URL",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>Member's unique ID</p>"
          }
        ],
        "Request Body": [
          {
            "group": "body",
            "type": "Date",
            "optional": false,
            "field": "Birthdate",
            "description": "<p>The Member's birthdate</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "UserName",
            "description": "<p>The Member's username</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "Password",
            "description": "<p>The Member's password (only used during onboarding)</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Email",
            "description": "<p>The Member's email</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "HomeZip",
            "description": "<p>The Member's home zip code</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "WorkZip",
            "description": "<p>The Member's work zip code</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": true,
            "field": "EmployeeId",
            "description": "<p>The Member's employee ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "FirstName",
            "description": "<p>The Member's first name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "LastName",
            "description": "<p>The Member's last name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "FullName",
            "description": "<p>The Member's full name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Position",
            "description": "<p>The Member's position</p>"
          },
          {
            "group": "body",
            "type": "Date",
            "optional": false,
            "field": "StartingDate",
            "description": "<p>The Member's starting date</p>"
          },
          {
            "group": "body",
            "type": "Date",
            "optional": true,
            "field": "EndingDate",
            "description": "<p>The Member's offboarded date</p>"
          },
          {
            "group": "body",
            "type": "Object[]",
            "optional": true,
            "field": "MyManagers",
            "description": "<p>This is an array of Member's manager information. When Supplied, Manager EmployeeId or MemberId is required.</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MyManagers.EmployeeId",
            "description": "<p>The Manager's EmployeeId</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MyManagers.MemberId",
            "description": "<p>The Manager's MemberId</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "MyManagers.FullName",
            "description": "<p>The Manager's full name</p>"
          },
          {
            "group": "body",
            "type": "Object",
            "optional": false,
            "field": "Location",
            "description": "<p>The Member's location information</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Location.LocationId",
            "description": "<p>The Location's unique ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "Location.Name",
            "description": "<p>The Location's name</p>"
          },
          {
            "group": "body",
            "type": "String",
            "allowedValues": [
              "Employee",
              "Manager",
              "Director",
              "Executive",
              "Admin",
              "Owner",
              "ResellerAdmin"
            ],
            "optional": false,
            "field": "Role",
            "description": "<p>The Member's role</p>"
          },
          {
            "group": "body",
            "type": "Object",
            "optional": false,
            "field": "GroupDepartment",
            "description": "<p>The Member's department information</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.DepartmentId",
            "description": "<p>The Department's unique ID</p>"
          },
          {
            "group": "body",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.Name",
            "description": "<p>The Department's name</p>"
          },
          {
            "group": "body",
            "type": "string",
            "optional": true,
            "field": "GravatarEmail",
            "description": "<p>The Member's email associated with a Gravatar</p>"
          },
          {
            "group": "body",
            "type": "Boolean",
            "optional": true,
            "field": "SuppressWelcomeMessage",
            "defaultValue": "true",
            "description": "<p>The Member's option to receive a welcome message when onboarding</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MissingMemberId",
            "description": "<p>Member Id is not provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMemberId",
            "description": "<p>An invalid Member Id was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMembersInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MemberNotFound",
            "description": "<p>Member was not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DepartmentNotFound",
            "description": "<p>Department Id is not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "LocationNotFound",
            "description": "<p>Location Id is not found in the system</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DuplicateEmployeeId",
            "description": "<p>EmployeeId is already in use</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DuplicateManagerMemberId",
            "description": "<p>MemberIds is duplicated</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "DuplicateManagerEmployeeId",
            "description": "<p>EmployeeIds is duplicated</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidManagerMemberId",
            "description": "<p>Manager MemberId is not valid</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidManagerEmployeeId",
            "description": "<p>Manager MemberId is not valid</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ManagerWithMemberIdIsNotActive",
            "description": "<p>Manager with MemberId is not active</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ManagerWithEmployeeIdIsNotActive",
            "description": "<p>Manager with EmployeeId is not active</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "ManagerMemberIdDoesNotMatchEmployeeId",
            "description": "<p>Manager EmployeeId does not match Manager EmployeeId in the System</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MemberId",
            "description": "<p>The Member's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "Birthdate",
            "description": "<p>The Member's birthdate</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "UserName",
            "description": "<p>The Member's username</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Email",
            "description": "<p>The Member's email</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "HomeZip",
            "description": "<p>The Member's home zip code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "WorkZip",
            "description": "<p>The Member's work zip code</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "EmployeeId",
            "description": "<p>The Member's employee ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "FirstName",
            "description": "<p>The Member's first name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LastName",
            "description": "<p>The Member's last name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "FullName",
            "description": "<p>The Member's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Position",
            "description": "<p>The Member's position</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "StartingDate",
            "description": "<p>The Member's starting date</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "EndingDate",
            "description": "<p>The Member's offboarded date</p>"
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "MyManagers",
            "description": "<p>This is an array of Member's manager information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.MemberId",
            "description": "<p>The Manager's MemberId</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.Email",
            "description": "<p>The Manager's EmployeeId</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MyManagers.FullName",
            "description": "<p>The Manager's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "Location",
            "description": "<p>The Member's location information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Location.LocationId",
            "description": "<p>The location's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Location.Name",
            "description": "<p>The location's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Role",
            "description": "<p>The Member's role</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "GroupDepartment",
            "description": "<p>Member's department information</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.DepartmentId",
            "description": "<p>The department's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GroupDepartment.Name",
            "description": "<p>The department's name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "GravatarEmail",
            "description": "<p>The Member's email associated with a Gravatar</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar updateMember = {\n    MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n    Birthdate: 'MM/DD/YYYY',\n    UserName: 'UserName',\n    Email: 'email@highground.com',\n    HomeZip: '12345',\n    WorkZip: '98765',\n    FirstName: 'FirstName',\n    LastName: 'LastName',\n    FullName: 'FirstName LastName',      \n    Position: 'CEO',\n    StartingDate: 'MM/DD/YYYY',\n    MyManagers: [{\n         EmployeeId: 'Manager EmployeeId', //EmployeeId or MemberId is required\n         MemberId: '158f0270-519c-11e5-927c-7d3b5e612a77',\n         FullName: 'Manager FullName' // Optional\n    }],\n    Location: {\n        LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',\n        Name: 'Chicago'\n    },\n    GroupDepartment: {\n        DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',\n        Name: 'IT'\n    },\n    Role: 'Employee',\n    GravatarEmail: 'gravataremail@highground.com',\n    EmployeeId: 'HG001'\n};\nvar dataString = JSON.stringify(updateMember);\nvar postheaders = {\n        'Accept' : 'application/json',  \n        'Content-Type' : 'application/json',\n        'clientkey' : '[Your API Key]',\n        'Content-Length' : dataString.length\n    };\n\nvar options = {\n    host: 'api.highground.com',\n    port: 443,\n    path: '/1.0/Member/',\n    method: 'PUT',\n    headers: postheaders,\n    body: dataString\n};\n\nvar reqGet = https.request(options, function(response) {\n  var buffer = \"\", data;\n  response.on('data', function (chunk) {\n    buffer += chunk;\n  });\n  response.on('end', function (err) {\n    data = JSON.parse(buffer);\n    console.log('statusCode: ', response.statusCode);\n    console.log('data:', data);\n  });\n});\n\nreqGet.on('error', function(e) {\n    console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\nrequire \"json/ext\"\n\ndef update_member\n    uri = URI.parse(\"https://api.highground.com/1.0/Member/\")\n    request = Net::HTTP::Put.new(uri, initheader = {'Content-Type' =>'application/json'})\n    request['clientkey'] = \"Your API key\"\n    request.body = {\n        MemberId: 'd9d14d00-41ca-11e5-95f3-29dbd151f43c',\n        Birthdate: 'MM/DD/YYYY',\n        UserName: 'UserName',\n        Email: 'email@highground.com',\n        HomeZip: '12345',\n        WorkZip: '98765',\n        FirstName: 'FirstName',\n        LastName: 'LastName',\n        FullName: 'FirstName LastName',\n        Position: 'CEO',\n        StartingDate: 'MM/DD/YYYY',\n        MyManagers: [{\n            EmployeeId: 'Manager EmployeeId', //EmployeeId or MemberId is required\n            MemberId: '158f0270-519c-11e5-927c-7d3b5e612a77',\n            FullName: 'Manager FullName' // Optional\n        }],\n        Location: {\n            LocationId: '158f0270-519c-11e5-927c-7d3b5e612a77',\n            Name: 'Chicago'\n        },\n        GroupDepartment: {\n            DepartmentId: '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',\n            Name: 'IT'\n        },\n        Role: 'Employee',\n        GravatarEmail: 'gravataremail@highground.com',\n        EmployeeId: 'HG001'\n    }.to_json\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import json\nimport requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef update_member():\n  headers = {\n      'Accept' : 'application/json',\n      'Content-type': 'application/json',\n      'clientkey' : API_ACCESS_KEY\n  }\n  payload = json.dumps({\n        \"MemberId\": \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\",\n        \"Birthdate\": \"MM/DD/YYYY\",\n        \"UserName\": \"UserName\",\n        \"Email\": \"email@highground.com\",\n        \"HomeZip\": \"12345\",\n        \"WorkZip\": \"98765\",\n        \"FirstName\": \"FirstName\",\n        \"LastName\": \"LastName\",\n        \"FullName\": \"FirstName LastName\",\n        \"Position\": \"CEO\",\n        \"StartingDate\": \"MM/DD/YYYY\",\n        \"MyManagers\": [{\n             EmployeeId: 'Manager EmployeeId', //EmployeeId or MemberId is required\n             MemberId: '158f0270-519c-11e5-927c-7d3b5e612a77',\n             FullName: 'Manager FullName' // Optional\n        }],\n        \"Location\": {\n            \"LocationId\": \"158f0270-519c-11e5-927c-7d3b5e612a77\",\n            \"Name\": \"Chicago\"\n        },\n        \"GroupDepartment\": {\n            \"DepartmentId\": \"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\",\n            \"Name\": \"IT\"\n        },\n        \"Role\": \"Employee\",\n        \"GravatarEmail\": \"gravataremail@highground.com\",\n        \"EmployeeId\": \"HG001\"\n    })\n  r = requests.put(\n                  'https://api.highground.com/1.0/Member/',\n                  headers=headers,\n                  data=payload,\n  )\n  print (r.status_code)\n  print (r.text)\n  \nupdate_member()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/Member/';\n$curl = curl_init($service_url);\n\n$headers = array (\n   \"Accept: application/json\",\n   \"Content-Type:application/json\",\n   \"clientkey:[Your API Key]\"\n);\n\n$curl_post_data = array(\n   'Birthdate' => 'MM/DD/YYYY',\n   'UserName' => 'UserName',\n   'Email' => 'email@highground.com',\n   'HomeZip' => '12345',\n   'WorkZip' => '98765',\n   'FirstName' => 'FirstName',\n   'LastName' => 'LastName',\n   'FullName' => 'FirstName LastName',\n   'Position' => 'CEO',\n   'StartingDate' => 'MM/DD/YYYY',\n   'Role' => 'Employee',\n   'GravatarEmail' => 'gravataremail@highground.com',\n   'EmployeeId' => 'HG001',\n   'MyManagers' =>  array(\n       'MemberId' =>  '1a7484e0-519c-11e5-8bbd-a385a1c75a10', //EmployeeId or MemberId is required\n       'EmployeeId' => 'Manager EmployeeId',\n       'FullName' =>  'Manager FullName' // optional\n    ),\n   'Location' =>  array(\n       'LocationId' =>  '158f0270-519c-11e5-927c-7d3b5e612a77',\n       'Name' =>  'Chicago'\n    ),\n   'GroupDepartment' =>  array(\n       'DepartmentId' =>  '17ce6b20-519c-11e5-9f79-f10b3b47f7d2',\n       'Name' =>  'IT'\n   )\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_CUSTOMREQUEST, \"PUT\");\ncurl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\nusing System.ServiceModel;\nusing System.Runtime.Serialization;\nusing System.ServiceModel.Web;\nusing System.Web.Script.Serialization;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string uri = \"https://api.highground.com/1.0/Member\";\n        public class Member\n        {\n            public String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            public DateTime Birthdate = \"MM/DD/YYYY\";\n            public String UserName = \"UserName\";\n            public String Email = \"email@highground.com\";\n            public String HomeZip = \"12345\";\n            public String WorkZip = \"98765\";\n            public String EmployeeId = \"HG001\";\n            public String FirstName = \"FirstName\";\n            public String LastName = \"LastName\";\n            public String FullName = \"FullName\";\n            public String Position = \"CEO\";\n            public DateTime StartingDate = \"MM/DD/YYYY\";\n            public String Role = \"Employee\";\n            public String GravatarEmail = \"gravataremail@highground.com\";\n            public Manager MyManagers;\n            public Location Location;\n            public Department GroupDepartment;\n        }\n        public class Manager\n        {\n             //EmployeeId or MemberId is required\n            public String MemberId = \"1a7484e0-519c-11e5-8bbd-a385a1c75a10\";\n            public String EmployeeId = \"Manaver EmployeeId\";\n            public String FullName = \"Manager FullName\"; //optional\n        }\n        public class Location\n        {\n            public String LocationId = \"158f0270-519c-11e5-927c-7d3b5e612a77\";\n            public String Name = \"Chicago\"; \n        }\n        public class Department\n        {\n            public String DepartmentId = \"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\";\n            public String Name = \"IT\"; \n        }\n        public static void Main(string[] args)\n        {\n            var member = new Member();\n            member.MyManagers = new Manager();\n            member.Location = new Location();\n            member.GroupDepartment = new Department();\n            \n            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);\n            request.Method = \"PUT\";\n            request.ContentType = \"application/json;charset=utf-8\";\n            var json = new JavaScriptSerializer().Serialize(member);\n            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();\n            byte[] bytes = encoding.GetBytes(json);\n            request.ContentLength = bytes.Length;\n            using (Stream requestStream = request.GetRequestStream())\n            {\n                requestStream.Write(bytes, 0, bytes.Length);\n            }\n            request.BeginGetResponse((x) =>\n            {\n                using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))\n                {\n                    if (callback != null)\n                    {\n                        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));\n                        callback(ser.ReadObject(response.GetResponseStream()) as Response);\n                    }\n                }\n            }, null);\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.io.OutputStream;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\nimport java.util.HashMap;\nimport java.util.Map;\nimport com.google.gson.Gson;\n\nclass Rextester\n{\n    public static void main(String args[])\n    {\n        try \n        {\n            URL url = new URL(\"https://api.highground.com/1.0/Member/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"PUT\");\n            conn.setRequestProperty(\"Content-Type\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n            \n            HashMap<String, Object> memberData = new HashMap<String, Object>();\n            memberData.put(\"MemberId\", \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\");\n            memberData.put(\"Birthdate\", \"MM/DD/YYYY\");\n            memberData.put(\"UserName\", \"UserName\");\n            memberData.put(\"Email\", \"email@highground.com\");\n            memberData.put(\"HomeZip\", \"12345\");\n            memberData.put(\"WorkZip\", \"98765\");\n            memberData.put(\"EmployeeId\", \"HG001\");\n            memberData.put(\"FirstName\", \"FirstName\");\n            memberData.put(\"LastName\", \"LastName\");\n            memberData.put(\"FullName\", \"FullName\");\n            memberData.put(\"Position\", \"CEO\");\n            memberData.put(\"StartingDate\", \"MM/DD/YYYY\");\n            memberData.put(\"Role\", \"Employee\");\n            memberData.put(\"GravatarEmail\", \"gravataremail@highground.com\");\n\n            HashMap<String, Object> managerData = new HashMap<String, Object>();\n            //EmployeeId or MemberId is required\n            managerData.put(\"MemberId\", \"1a7484e0-519c-11e5-8bbd-a385a1c75a10\");\n            managerData.put(\"EmployeeId\", \"Manager EmployeeId\");\n             //Optional\n            managerData.put(\"FullName\", \"Manager FullName\");\n            memberData.put(\"MyManagers\", managerData);\n            \n            HashMap<String, Object> locationData = new HashMap<String, Object>();\n            locationData.put(\"LocationId\", \"158f0270-519c-11e5-927c-7d3b5e612a77\");\n            locationData.put(\"Name\", \"FirstName\");\n            memberData.put(\"Location\", locationData);\n            \n            HashMap<String, Object> departmentData = new HashMap<String, Object>();\n            departmentData.put(\"LocationId\", \"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\");\n            departmentData.put(\"Name\", \"IT\");\n            memberData.put(\"GroupDepartment\", departmentData);\n            \n            Gson gson = new Gson();\n            String json = gson.toJson(memberData);\n            OutputStream os = conn.getOutputStream();\n            os.write(json.getBytes());\n            os.flush();\n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       } \n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X PUT \"https://api.highground.com/1.0/Member/d9d14d00-41ca-11e5-95f3-29dbd151f43c\" \\\n--data '{\"Birthdate\":\"MM/DD/YYYY\",\"UserName\":\"UserName\",\"Email\":\"email@highground.com\",\"HomeZip\":\"12345\",\"WorkZip\":\"98765\",\"FirstName\":\"FirstName\",\"LastName\":\"LastName\",\"FullName\":\"FirstName LastName\",\"Position\":\"CEO\",\"StartingDate\":\"MM/DD/YYYY\",\"MyManagers\":{\"MemberId\":\"1a7484e0-519c-11e5-8bbd-a385a1c75a10\",\"Email\":\"manageremail@highground.com\",\"FullName\":\"Manager FullName\"},\"Location\":{\"LocationId\":\"158f0270-519c-11e5-927c-7d3b5e612a77\",\"Name\":\"Chicago\"},\"GroupDepartment\":{\"DepartmentId\":\"17ce6b20-519c-11e5-9f79-f10b3b47f7d2\",\"Name\":\"IT\"},\"Role\":\"Employee\",\"GravatarEmail\":\"gravataremail@highground.com\",\"EmployeeId\":\"HG001\"}'",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "get",
    "url": "/1.0/Members",
    "title": "Get Members",
    "version": "1.0.0",
    "name": "GetMembers",
    "group": "Members",
    "parameter": {
      "fields": {
        "Query String Params": [
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "skip",
            "description": "<p>The number of records to skip</p>"
          },
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "take",
            "description": "<p>The number of records to return (max 25)</p>"
          },
          {
            "group": "query",
            "type": "Date",
            "optional": true,
            "field": "since",
            "description": "<p>The beginning date range of a Member's StartingDate</p>"
          },
          {
            "group": "query",
            "type": "Date",
            "optional": true,
            "field": "until",
            "description": "<p>The end date range of a Member's StartingDate</p>"
          },
          {
            "group": "query",
            "type": "String",
            "optional": true,
            "field": "fullname",
            "description": "<p>Member's full name to search against. Default is exact match, or start with 'like:' for names containing that string</p>"
          },
          {
            "group": "query",
            "type": "String",
            "allowedValues": [
              "Active",
              "OffBoarded"
            ],
            "optional": true,
            "field": "status",
            "description": "<p>Member's status</p>"
          },
          {
            "group": "query",
            "type": "Boolean",
            "optional": true,
            "field": "hierarchy",
            "description": "<p>Pull member's information in the hierarchy format. If this option is used, you can only query by manager's exact full name. All other query string fields are ignored</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Member[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Members</p>"
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Members.js",
    "groupTitle": "Members",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidSearchCriteria",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MemberNotFound",
            "description": "<p>Member was not found in the system</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    }
  },
  {
    "type": "delete",
    "url": "/1.0/Members",
    "title": "Offboard Members",
    "version": "1.0.0",
    "name": "Offboard_Members",
    "group": "Members",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "BatchId",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "AuditId",
            "description": ""
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Members.js",
    "groupTitle": "Members",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "String[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Member unique IDs, max size is 100 records</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMembersInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMemberId",
            "description": "<p>An invalid Member Id was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "RateLimitExceeded",
            "description": "<p>The maximum limit is 100 records</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/1.0/Members",
    "title": "Onboard Members",
    "version": "1.0.0",
    "name": "Onboard_Members",
    "group": "Members",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "BatchId",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "AuditId",
            "description": ""
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Members.js",
    "groupTitle": "Members",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "Member[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Members</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMembersInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "RateLimitExceeded",
            "description": "<p>The maximum limit is 100 records</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/1.0/Members/resendWelcomeEmail",
    "title": "Resend welcome emails",
    "version": "1.0.0",
    "name": "ResendWelcomeEmail_To_Members",
    "group": "Members",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "BatchId",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "AuditId",
            "description": ""
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Members.js",
    "groupTitle": "Members",
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "String[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Member unique IDs, max size is 100 records</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "MissingMemberId",
            "description": "<p>Member Id is not provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMemberId",
            "description": "<p>An invalid Member Id was provided</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "RateLimitExceeded",
            "description": "<p>The maximum limit is 100 records</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMembersInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    }
  },
  {
    "type": "put",
    "url": "/1.0/Members",
    "title": "Update Members",
    "version": "1.0.0",
    "name": "Update_Members",
    "group": "Members",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "BatchId",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "AuditId",
            "description": ""
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Members.js",
    "groupTitle": "Members",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request Body": [
          {
            "group": "body",
            "type": "Member[]",
            "optional": false,
            "field": "body",
            "description": "<p>An array of Members</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidMembersInfo",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "RateLimitExceeded",
            "description": "<p>The maximum limit is 100 records</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/1.0/Recognition/",
    "title": "Get Recognitions",
    "version": "1.0.0",
    "name": "GetRecognition",
    "group": "Recognition",
    "parameter": {
      "fields": {
        "Query String Params": [
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "skip",
            "description": "<p>The number of records to skip</p>"
          },
          {
            "group": "query",
            "type": "Number",
            "optional": true,
            "field": "take",
            "description": "<p>The number of records to return (max 25)</p>"
          },
          {
            "group": "query",
            "type": "String",
            "optional": true,
            "field": "giveremail",
            "description": "<p>The email of the giver of the Recognition</p>"
          },
          {
            "group": "query",
            "type": "String",
            "optional": true,
            "field": "receiveremail",
            "description": "<p>The email of the receiver of the Recognition</p>"
          },
          {
            "group": "query",
            "type": "Date",
            "optional": true,
            "field": "startdate",
            "description": "<p>The beginning date range</p>"
          },
          {
            "group": "query",
            "type": "Date",
            "optional": true,
            "field": "enddate",
            "description": "<p>The ending date range</p>"
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/Recognition.js",
    "groupTitle": "Recognition",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidSearchCriteria",
            "description": "<p>The information provided did not pass validation. More information will be in the 'details' property</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Id",
            "description": "<p>The Recognition's unique ID</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "Giver",
            "description": "<p>The Giver of the Recognition</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Giver.FullName",
            "description": "<p>The Giver's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Giver.Department",
            "description": "<p>The Giver's department</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Giver.Position",
            "description": "<p>The Giver's position</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Giver.AvatarPath",
            "description": "<p>The Giver's avatar URL</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Giver.Email",
            "description": "<p>The Giver's email</p>"
          },
          {
            "group": "Success 200",
            "type": "Array",
            "optional": false,
            "field": "Receivers",
            "description": "<p>An array of the Receivers of a Recognition</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Receivers.FullName",
            "description": "<p>The Receiver's full name</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Receivers.Department",
            "description": "<p>The Receiver's department</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Receivers.Position",
            "description": "<p>The Receiver's position</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Receivers.AvatarPath",
            "description": "<p>The Receiver's avatar URL</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Receivers.Email",
            "description": "<p>The Receiver's email</p>"
          },
          {
            "group": "Success 200",
            "type": "Object",
            "optional": false,
            "field": "Recognition",
            "description": "<p>The Recognition</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recognition.Title",
            "description": "<p>The title of the recognition</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recognition.SubValue",
            "description": "<p>The subvalue of the recognition (optional)</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recognition.SubValueDescription",
            "description": "<p>The subvalue description of the recognition (optional)</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recognition.URL",
            "description": "<p>The URL of the recognition as viewed in HighGround</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recognition.BadgeURL",
            "description": "<p>The URL of the badge image of the recognition</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recognition.Description",
            "description": "<p>The description of the recognition</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recognition.Message",
            "description": "<p>The message of the recognition</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "Recognition.CreatedDate",
            "description": "<p>The date the recognition was given (in UTC Unix timestamp format)</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "Recognition.NumberOfLikes",
            "description": "<p>The number of likes the recognition has received</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "Recognition.NumberOfComments",
            "description": "<p>The number of comments the recognition has received</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "Recognition.NumberOfGifts",
            "description": "<p>The number of gifts the recognition has received</p>"
          }
        ]
      }
    }
  },
  {
    "type": "post",
    "url": "/1.0/RulesEngine/create/:EventType",
    "title": "Create a RulesEngine event",
    "version": "1.0.0",
    "name": "CreateRulesEngineEvent",
    "group": "RulesEngine",
    "description": "<p>Creates a RuleEngine Event</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "body.Result",
            "description": "<p>Success message</p>"
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/RulesEngine.js",
    "groupTitle": "RulesEngine",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ],
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidEventType",
            "description": "<p>Invalid Event Type.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidRulesEnginePayload",
            "description": "<p>Amount and UserEmail expected in payload.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "InvalidRulesEngineAmount",
            "description": "<p>Amount must be numeric value.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar payload = {\n    Amount: '100',\n    UserEmail: \"[A user's email]\"\n};\nvar dataString = JSON.stringify(payload);\nvar postheaders = {\n        'Accept' : 'application/json',\n        'Content-Type' : 'application/json',\n        'clientkey' : '[Your API Key]',\n        'Content-Length' : dataString.length\n    };\n\nvar options = {\n    host: 'api.highground.com',\n    port: 443,\n    path: '/1.0/RulesEngine/create/[EventType]',\n    method: 'POST',\n    headers: postheaders,\n    body: dataString\n};\n\nvar reqGet = https.request(options, function(response) {\n  var buffer = \"\", data;\n  response.on('data', function (chunk) {\n    buffer += chunk;\n  });\n  response.on('end', function (err) {\n    data = JSON.parse(buffer);\n    console.log('statusCode: ', response.statusCode);\n    console.log('data:', data);\n  });\n});\n\nreqGet.on('error', function(e) {\n    console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\nrequire \"json/ext\"\n\ndef onboard_member\n    uri = URI.parse(\"https://api.highground.com/1.0/RulesEngine/create/[EventType]\")\n    request = Net::HTTP::Post.new(uri, initheader = {'Content-Type' =>'application/json'})\n    request['clientkey'] = \"Your API key\"\n    request.body = {\n       Amount: '100',\n       UserEmail: \"[A user's email]\"\n    }.to_json\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res.body}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import json\nimport requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef onboard_member():\n  headers = {\n      'Accept' : 'application/json',\n      'Content-type': 'application/json',\n      'clientkey' : API_ACCESS_KEY\n  }\n  payload = json.dumps({\n       'Amount': '100',\n       'UserEmail': \"[A user's email]\"\n    })\n  r = requests.post(\n                  'https://api.highground.com/1.0/RulesEngine/create/[EventType]',\n                  headers=headers,\n                  data=payload,\n  )\n  print (r.status_code)\n  print (r.text)\n\nonboard_member()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/RulesEngine/create/[EventType]';\n$curl = curl_init($service_url);\n\n$headers = array (\n   \"Accept: application/json\",\n   \"Content-Type:application/json\",\n   \"clientkey:[Your API Key]\"\n);\n\n$curl_post_data = array(\n   'Amount' => '100',\n   'UserEmail' => \"[A user's email]\",\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\ncurl_setopt($curl, CURLOPT_POST, true);\ncurl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));\n\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n  $info = curl_getinfo($curl);\n  curl_close($curl);\n  die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n  die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\nusing System.ServiceModel;\nusing System.Runtime.Serialization;\nusing System.ServiceModel.Web;\nusing System.Web.Script.Serialization;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string uri = \"https://api.highground.com/1.0/RulesEngine/create/[EventType]\";\n        public class Payload\n        {\n            public String Amount = \"100\";\n            public String UserEmail = \"[A user's email]\";\n\n        }\n        public static void Main(string[] args)\n        {\n            var payload = new Payload();\n\n            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);\n            request.Method = \"POST\";\n            request.ContentType = \"application/json;charset=utf-8\";\n            var json = new JavaScriptSerializer().Serialize(member);\n            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();\n            byte[] bytes = encoding.GetBytes(json);\n            request.ContentLength = bytes.Length;\n            using (Stream requestStream = request.GetRequestStream())\n            {\n                requestStream.Write(bytes, 0, bytes.Length);\n            }\n            request.BeginGetResponse((x) =>\n            {\n                using (HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(x))\n                {\n                    if (callback != null)\n                    {\n                        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Response));\n                        callback(ser.ReadObject(response.GetResponseStream()) as Response);\n                    }\n                }\n            }, null);\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.io.OutputStream;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\nimport java.util.HashMap;\nimport java.util.Map;\nimport com.google.gson.Gson;\n\nclass Rextester\n{\n    public static void main(String args[])\n    {\n        try\n        {\n            URL url = new URL(\"https://api.highground.com/1.0/RulesEngine/create/[EventType]\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"POST\");\n            conn.setRequestProperty(\"Content-Type\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n\n            HashMap<String, Object> payload = new HashMap<String, Object>();\n            payload.put(\"Amout\", \"100\");\n            payload.put(\"UserEmail\", \"[A user's email]\");\n\n            Gson gson = new Gson();\n            String json = gson.toJson(payload);\n            OutputStream os = conn.getOutputStream();\n            os.write(json.getBytes());\n            os.flush();\n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       }\n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X POST \"https://api.highground.com/1.0/RulesEngine/create/[EventType]\" \\\n--data '{\"Amount\":\"100\",\"UserEmail\":\"[A user\\'s email]\"}'",
        "type": "Curl"
      }
    ]
  },
  {
    "type": "get",
    "url": "/1.0/RulesEngine",
    "title": "Get RulesEngine EventType names",
    "version": "1.0.0",
    "name": "GetRulesEngineEventTypes",
    "group": "RulesEngine",
    "description": "<p>Retrieve the list of EventTypes for a given client</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "body.RulesEngineEventType",
            "description": "<p>An array of RulesEngine EventTypes</p>"
          }
        ]
      }
    },
    "filename": "hgnode/api/1.0/RulesEngine.js",
    "groupTitle": "RulesEngine",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "clientkey",
            "description": "<p>Your API key</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "optional": false,
            "field": "UnknownError",
            "description": "<p>An unknown error occurred</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Node",
        "content": "var https = require('https');\n\nvar header = {\n    host: 'api.highground.com',\n    port: 443,\n    clientkey: '[Your API Key]',\n    path: '/1.0/RulesEngine',\n    method: 'GET'\n};\n\nvar reqGet = https.request(header, function(response) {\n    var buffer = \"\", data;\n\n    response.on('data', function (chunk) {\n        buffer += chunk;\n    });\n\n    response.on('end', function (err) {\n        data = JSON.parse(buffer);\n        console.log('statusCode: ', response.statusCode);\n        console.log('data:', data);\n    });\n});\n\nreqGet.on('error', function(e) {\n  console.error('error', e);\n})\n\nreqGet.end();",
        "type": "Node"
      },
      {
        "title": "Ruby",
        "content": "require \"net/http\"\nrequire \"net/https\"\nrequire \"uri\"\n\ndef get_departments\n    uri = URI.parse(\"https://api.highground.com/1.0/RulesEngine\")\n    request = Net::HTTP::Get.new(uri)\n    request['clientkey'] = \"Your API key\"\n    res = Net::HTTP.start(uri.host, uri.port,\n      :use_ssl => uri.scheme == 'https') {|http|\n      http.request(request)\n    }\n    puts \"response #{res}\"\n    rescue => e\n        puts \"failed #{e}\"\nend",
        "type": "Ruby"
      },
      {
        "title": "Python",
        "content": "import requests\n\nAPI_ACCESS_KEY='[Your API Key]'\n\ndef get_member_info():\n    headers = {\n        'Accept' : 'application/json',\n        'clientkey' : API_ACCESS_KEY\n    }\n    r = requests.get(\n                    'https://api.highground.com/1.0/RulesEngine',\n                    headers=headers,\n    )\n    print (r.status_code)\n    print (r.text)\n\nget_member_info()",
        "type": "Python"
      },
      {
        "title": "Php",
        "content": "<?php\n// You need to install and configure CURL to use following sample code\n$service_url = 'https://api.highground.com/1.0/RulesEngine';\n$curl = curl_init($service_url);\n\n$headers = array (\n    \"Accept: application/json\",\n    \"clientkey:[Your API Key]\"\n);\n\ncurl_setopt($ch, CURLOPT_URL, $service_url);\ncurl_setopt($ch, CURLOPT_HEADER, $headers);\ncurl_setopt($curl, CURLOPT_RETURNTRANSFER, true);\n$curl_response = curl_exec($curl);\nif ($curl_response === false) {\n    $info = curl_getinfo($curl);\n    curl_close($curl);\n    die('error occured during curl exec. Additioanl info: ' . var_export($info));\n}\ncurl_close($curl);\n$decoded = json_decode($curl_response);\nif (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {\n    die('error occured: ' . $decoded->response->errormessage);\n}\necho 'response ok!';\nvar_export($decoded->response);\n?>",
        "type": "Php"
      },
      {
        "title": "C#",
        "content": "using System;\nusing System.IO;\nusing System.Net;\nusing System.Text;\n\nnamespace Rextester\n{\n    public class Program\n    {\n        public const string EndPoint = \"https://api.highground.com/1.0/RulesEngine\";\n\n        public static void Main(string[] args)\n        {\n            var request = (HttpWebRequest)WebRequest.Create(EndPoint);\n            request.Method = \"GET\";\n            request.ContentLength = 0;\n            request.ContentType = \"application/json\";\n            request.Headers.Add(\"clientkey\", \"[Your API Key]\");\n            using (var response = (HttpWebResponse)request.GetResponse())\n            {\n              var responseValue = string.Empty;\n              if (response.StatusCode != HttpStatusCode.OK)\n              {\n                var message = String.Format(\"Request failed. Received HTTP {0}\", response.StatusCode);\n                throw new ApplicationException(message);\n              }\n              using (var responseStream = response.GetResponseStream())\n              {\n                if (responseStream != null)\n                  using (var reader = new StreamReader(responseStream))\n                  {\n                    responseValue = reader.ReadToEnd();\n                  }\n              }\n              Console.Write(responseValue);\n            }\n        }\n    }\n}",
        "type": "CSharp"
      },
      {
        "title": "Java",
        "content": "import java.io.BufferedReader;\nimport java.io.IOException;\nimport java.io.InputStreamReader;\nimport java.net.HttpURLConnection;\nimport java.net.MalformedURLException;\nimport java.net.URL;\n\nclass Rextester\n{\n    public static void main(String args[])\n    {\n        try\n        {\n            String MemberId = \"d9d14d00-41ca-11e5-95f3-29dbd151f43c\";\n            URL url = new URL(\"https://api.highground.com/1.0/RulesEngine/\");\n            HttpURLConnection conn = (HttpURLConnection) url.openConnection();\n            conn.setRequestMethod(\"GET\");\n            conn.setRequestProperty(\"Accept\", \"application/json\");\n            conn.setRequestProperty(\"clientkey\", \"[Your API Key]\");\n\n            if (conn.getResponseCode() != 200) {\n                throw new RuntimeException(\"Failed : HTTP error code : \" + conn.getResponseCode());\n            }\n            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));\n            String output;\n            while ((output = br.readLine()) != null) {\n                System.out.println(output);\n            }\n            conn.disconnect();\n       }\n        catch (MalformedURLException e) { e.printStackTrace(); }\n        catch (IOException e) { e.printStackTrace(); }\n    }\n}",
        "type": "Java"
      },
      {
        "title": "Curl",
        "content": "curl -i \\\n-H \"Accept: application/json\" \\\n-H \"Content-Type:application/json\" \\\n-H \"clientkey:[Your API Key]\" \\\n-X GET \"https://api.highground.com/1.0/RulesEngine\"",
        "type": "Curl"
      }
    ]
  }
] });
