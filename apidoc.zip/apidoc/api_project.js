define({
  "name": "HighGround API",
  "version": "1.0.0",
  "description": "HighGround API for HRIS Integrations",
  "title": "HighGround API",
  "url": "https://api.highground.com",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-04-13T09:50:06.690Z",
    "url": "http://apidocjs.com",
    "version": "0.13.2"
  }
});
