var fs = require("fs"),
    path = require("path"),
    potentialHooks = [
        "applypatch-msg",
        "commit-msg",
        "post-commit",
        "post-receive",
        "post-update",
        "post-checkout",
        "pre-applypatch",
        "pre-commit",
        "prepare-commit-msg",
        "pre-rebase",
        "pre-push",
        "update"
    ];

potentialHooks.forEach(function (hook) {
    var hookInSourceControl = path.resolve(__dirname, hook);

    if (fs.existsSync(hookInSourceControl)) {
        var hookInHiddenDirectory = path.resolve(__dirname, "..", ".git", "hooks", hook);

        if (fs.existsSync(hookInHiddenDirectory)) {
            fs.unlinkSync(hookInHiddenDirectory);
        }

        console.log('linking', hookInSourceControl, '->', hookInHiddenDirectory);
        fs.symlink(hookInSourceControl, hookInHiddenDirectory, function (err) {
            if (err) {
                console.log(err);
            }
        });
    }
});
